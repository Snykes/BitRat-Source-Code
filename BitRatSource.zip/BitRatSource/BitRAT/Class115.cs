﻿using System;

// Token: 0x02000073 RID: 115
internal sealed class Class115 : Class94
{
	// Token: 0x060003C7 RID: 967 RVA: 0x00004779 File Offset: 0x00002979
	public sbyte method_2()
	{
		return this.sbyte_0;
	}

	// Token: 0x060003C8 RID: 968 RVA: 0x00004781 File Offset: 0x00002981
	public void method_3(sbyte sbyte_1)
	{
		this.sbyte_0 = sbyte_1;
	}

	// Token: 0x060003C9 RID: 969 RVA: 0x0000478A File Offset: 0x0000298A
	public override object vmethod_0()
	{
		return this.method_2();
	}

	// Token: 0x060003CA RID: 970 RVA: 0x00020840 File Offset: 0x0001EA40
	public override void vmethod_1(object object_0)
	{
		if (object_0 is byte)
		{
			this.method_3((sbyte)((byte)object_0));
			return;
		}
		if (object_0 is short)
		{
			this.method_3((sbyte)((short)object_0));
			return;
		}
		if (object_0 is int)
		{
			this.method_3((sbyte)((int)object_0));
			return;
		}
		if (object_0 is long)
		{
			this.method_3((sbyte)((long)object_0));
			return;
		}
		if (object_0 is ushort)
		{
			this.method_3((sbyte)((ushort)object_0));
			return;
		}
		if (object_0 is uint)
		{
			this.method_3((sbyte)((uint)object_0));
			return;
		}
		if (object_0 is ulong)
		{
			this.method_3((sbyte)((ulong)object_0));
			return;
		}
		if (object_0 is float)
		{
			this.method_3((sbyte)((float)object_0));
			return;
		}
		if (object_0 is double)
		{
			this.method_3((sbyte)((double)object_0));
			return;
		}
		this.method_3(Convert.ToSByte(object_0));
	}

	// Token: 0x060003CB RID: 971 RVA: 0x00004797 File Offset: 0x00002997
	public override Class94 vmethod_4()
	{
		Class115 @class = new Class115();
		@class.method_3(this.sbyte_0);
		@class.method_1(base.method_0());
		return @class;
	}

	// Token: 0x060003CC RID: 972 RVA: 0x000047B6 File Offset: 0x000029B6
	public override int vmethod_2()
	{
		return 9;
	}

	// Token: 0x060003CD RID: 973 RVA: 0x00020920 File Offset: 0x0001EB20
	public override Class94 vmethod_3(Class94 class94_0)
	{
		base.method_1(class94_0.method_0());
		switch (class94_0.vmethod_2())
		{
		case 0:
			this.method_3((sbyte)((Class119)class94_0).method_2());
			return this;
		case 2:
			this.method_3(Convert.ToSByte(((Class103)class94_0).method_2()));
			return this;
		case 4:
			this.method_3(Convert.ToSByte(((Class102)class94_0).method_2()));
			return this;
		case 7:
			this.method_3((sbyte)((Class118)class94_0).method_2());
			return this;
		case 9:
			this.method_3(((Class115)class94_0).method_2());
			return this;
		case 10:
			this.method_3((sbyte)((Class114)class94_0).method_2());
			return this;
		case 11:
			this.method_3((sbyte)((Class99)class94_0).method_2());
			return this;
		case 14:
			this.method_3((sbyte)((int)((Class105)class94_0).method_2()));
			return this;
		case 15:
			this.method_3((sbyte)((Class101)class94_0).method_2());
			return this;
		case 17:
			this.method_3((sbyte)((Class117)class94_0).method_2());
			return this;
		case 19:
			this.method_3((sbyte)((Class120)class94_0).method_2());
			return this;
		case 21:
			this.method_3((sbyte)((Class104)class94_0).method_2());
			return this;
		case 22:
			this.method_3((sbyte)((Class121)class94_0).method_2());
			return this;
		case 24:
			this.method_3(Convert.ToSByte(((Class98)class94_0).method_2()));
			return this;
		}
		throw new ArgumentOutOfRangeException();
	}

	// Token: 0x040001B6 RID: 438
	private sbyte sbyte_0;
}
