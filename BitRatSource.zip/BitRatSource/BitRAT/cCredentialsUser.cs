﻿using System;
using System.Linq;
using System.Text;
using System.Xml;

namespace BitRAT
{
	// Token: 0x020001DC RID: 476
	public class cCredentialsUser
	{
		// Token: 0x06001A80 RID: 6784 RVA: 0x000BA798 File Offset: 0x000B8998
		public cCredentialsUser()
		{
			this.idxValues = new string[2];
			this.sLogins = new StringBuilder();
			checked
			{
				int num = this.idxValues.Count<string>() - 1;
				for (int i = 1; i <= num; i++)
				{
					this.idxValues[i] = "N/A";
				}
			}
		}

		// Token: 0x1700006A RID: 106
		// (get) Token: 0x06001A81 RID: 6785 RVA: 0x0000D8AE File Offset: 0x0000BAAE
		// (set) Token: 0x06001A82 RID: 6786 RVA: 0x0000D8B8 File Offset: 0x0000BAB8
		public string USER
		{
			get
			{
				return this.idxValues[0];
			}
			set
			{
				this.idxValues[0] = value;
			}
		}

		// Token: 0x1700006B RID: 107
		// (get) Token: 0x06001A83 RID: 6787 RVA: 0x0000D8C3 File Offset: 0x0000BAC3
		// (set) Token: 0x06001A84 RID: 6788 RVA: 0x0000D8CD File Offset: 0x0000BACD
		public string LOGINS
		{
			get
			{
				return this.idxValues[1];
			}
			set
			{
				this.idxValues[1] = value;
			}
		}

		// Token: 0x04000A0E RID: 2574
		public string[] idxValues;

		// Token: 0x04000A0F RID: 2575
		public string Key;

		// Token: 0x04000A10 RID: 2576
		public StringBuilder sLogins;

		// Token: 0x04000A11 RID: 2577
		public XmlNodeList xmlList;

		// Token: 0x04000A12 RID: 2578
		private string m_user;

		// Token: 0x04000A13 RID: 2579
		private string m_logins;

		// Token: 0x04000A14 RID: 2580
		private string m_tag;
	}
}
