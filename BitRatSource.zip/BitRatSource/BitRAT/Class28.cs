﻿using System;

// Token: 0x0200002E RID: 46
internal sealed class Class28 : Interface2
{
	// Token: 0x06000250 RID: 592 RVA: 0x00003CC2 File Offset: 0x00001EC2
	public Class28(byte[] byte_1)
	{
		if (byte_1 == null)
		{
			throw new ArgumentNullException("#=z5jI7l7s=");
		}
		this.byte_0 = (byte[])byte_1.Clone();
	}

	// Token: 0x06000251 RID: 593 RVA: 0x0001C958 File Offset: 0x0001AB58
	public Class28(byte[] byte_1, int int_0, int int_1)
	{
		if (byte_1 == null)
		{
			throw new ArgumentNullException("#=z5jI7l7s=");
		}
		if (int_0 < 0 || int_0 > byte_1.Length)
		{
			throw new ArgumentOutOfRangeException("#=zBBshIlI=");
		}
		if (int_1 < 0 || int_0 + int_1 > byte_1.Length)
		{
			throw new ArgumentOutOfRangeException("#=zQ4AtJgM=");
		}
		this.byte_0 = new byte[int_1];
		Array.Copy(byte_1, int_0, this.byte_0, 0, int_1);
	}

	// Token: 0x06000252 RID: 594 RVA: 0x00003CE9 File Offset: 0x00001EE9
	public byte[] method_0()
	{
		return (byte[])this.byte_0.Clone();
	}

	// Token: 0x0400014C RID: 332
	private readonly byte[] byte_0;
}
