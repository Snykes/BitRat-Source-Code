﻿using System;
using System.Net.Sockets;
using System.Text;

// Token: 0x020001BE RID: 446
public sealed class GClass10
{
	// Token: 0x06001861 RID: 6241 RVA: 0x0000C5F2 File Offset: 0x0000A7F2
	public GClass10()
	{
		this.socket_0 = null;
		this.int_0 = 8192;
		this.byte_0 = new byte[checked(this.int_0 + 1)];
		this.stringBuilder_0 = new StringBuilder();
	}

	// Token: 0x04000915 RID: 2325
	public Socket socket_0;

	// Token: 0x04000916 RID: 2326
	public int int_0;

	// Token: 0x04000917 RID: 2327
	public byte[] byte_0;

	// Token: 0x04000918 RID: 2328
	public StringBuilder stringBuilder_0;
}
