﻿using System;
using System.Linq;
using System.Runtime.InteropServices;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace BitRAT
{
	// Token: 0x020001EA RID: 490
	public class cSocks5cli
	{
		// Token: 0x06001AF6 RID: 6902 RVA: 0x000BB9A8 File Offset: 0x000B9BA8
		public cSocks5cli()
		{
			this.idxValues = new string[9];
			bool flag;
			checked
			{
				int num = this.idxValues.Count<string>() - 1;
				for (int i = 1; i <= num; i++)
				{
					this.idxValues[i] = "N/A";
				}
				Class136.Struct27 @struct = default(Class136.Struct27);
				@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
				flag = false;
				if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
				{
					flag = true;
				}
			}
			long num2;
			if (flag)
			{
				num2 = Class136.GetTickCount64();
			}
			else
			{
				num2 = (long)Class136.GetTickCount();
			}
			long num3 = num2;
			this.lStarted = num3;
		}

		// Token: 0x17000096 RID: 150
		// (get) Token: 0x06001AF7 RID: 6903 RVA: 0x0000DCC2 File Offset: 0x0000BEC2
		// (set) Token: 0x06001AF8 RID: 6904 RVA: 0x0000DCCC File Offset: 0x0000BECC
		public string USER
		{
			get
			{
				return this.idxValues[0];
			}
			set
			{
				this.idxValues[0] = value;
			}
		}

		// Token: 0x17000097 RID: 151
		// (get) Token: 0x06001AF9 RID: 6905 RVA: 0x0000DCD7 File Offset: 0x0000BED7
		// (set) Token: 0x06001AFA RID: 6906 RVA: 0x0000DCE1 File Offset: 0x0000BEE1
		public string PORT
		{
			get
			{
				return this.idxValues[1];
			}
			set
			{
				this.idxValues[1] = value;
			}
		}

		// Token: 0x17000098 RID: 152
		// (get) Token: 0x06001AFB RID: 6907 RVA: 0x0000DCEC File Offset: 0x0000BEEC
		// (set) Token: 0x06001AFC RID: 6908 RVA: 0x0000DCF6 File Offset: 0x0000BEF6
		public string DURATION
		{
			get
			{
				return this.idxValues[2];
			}
			set
			{
				this.idxValues[2] = value;
			}
		}

		// Token: 0x17000099 RID: 153
		// (get) Token: 0x06001AFD RID: 6909 RVA: 0x0000DD01 File Offset: 0x0000BF01
		// (set) Token: 0x06001AFE RID: 6910 RVA: 0x0000DD0B File Offset: 0x0000BF0B
		public string IP
		{
			get
			{
				return this.idxValues[3];
			}
			set
			{
				this.idxValues[3] = value;
			}
		}

		// Token: 0x1700009A RID: 154
		// (get) Token: 0x06001AFF RID: 6911 RVA: 0x000BBA48 File Offset: 0x000B9C48
		// (set) Token: 0x06001B00 RID: 6912 RVA: 0x0000DD16 File Offset: 0x0000BF16
		public string SENT
		{
			get
			{
				double num = this.dSent;
				bool flag = false;
				ref bool ptr = ref flag;
				double num2 = num;
				int num3;
				string result;
				int num4;
				object obj;
				try
				{
					ProjectData.ClearProjectError();
					num3 = 2;
					string text = string.Empty;
					if (num2 >= 1099511627776.0)
					{
						text = Strings.Format(num2 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
					}
					else if (num2 >= 1073741824.0)
					{
						text = Strings.Format(num2 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
					}
					else if (num2 >= 1048576.0)
					{
						text = Strings.Format(num2 / 1024.0 / 1024.0, "#0.00") + " MiB";
					}
					else if (num2 >= 1024.0)
					{
						text = Strings.Format(num2 / 1024.0, "#0.00") + " KiB";
					}
					else if (num2 < 1024.0)
					{
						text = Conversions.ToString(Conversion.Fix(num2)) + " B";
					}
					if (ptr)
					{
						text = Strings.Split(text, " ", -1, CompareMethod.Text)[0];
					}
					if (text.Length > 0)
					{
						result = text;
					}
					else
					{
						result = " 0 B";
					}
					IL_17B:
					goto IL_1CA;
					IL_17D:
					result = "0 B";
					goto IL_17B;
					IL_185:
					num4 = -1;
					@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
					IL_19B:;
				}
				catch when (endfilter(obj is Exception & num3 != 0 & num4 == 0))
				{
					Exception ex = (Exception)obj2;
					goto IL_185;
				}
				throw ProjectData.CreateProjectError(-2146828237);
				IL_1CA:
				if (num4 != 0)
				{
					ProjectData.ClearProjectError();
				}
				return result;
			}
			set
			{
				this.dSent = Conversions.ToDouble(value);
			}
		}

		// Token: 0x1700009B RID: 155
		// (get) Token: 0x06001B01 RID: 6913 RVA: 0x000BBC48 File Offset: 0x000B9E48
		// (set) Token: 0x06001B02 RID: 6914 RVA: 0x0000DD24 File Offset: 0x0000BF24
		public string RECV
		{
			get
			{
				double num = this.dRecv;
				bool flag = false;
				ref bool ptr = ref flag;
				double num2 = num;
				int num3;
				string result;
				int num4;
				object obj;
				try
				{
					ProjectData.ClearProjectError();
					num3 = 2;
					string text = string.Empty;
					if (num2 >= 1099511627776.0)
					{
						text = Strings.Format(num2 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
					}
					else if (num2 >= 1073741824.0)
					{
						text = Strings.Format(num2 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
					}
					else if (num2 >= 1048576.0)
					{
						text = Strings.Format(num2 / 1024.0 / 1024.0, "#0.00") + " MiB";
					}
					else if (num2 >= 1024.0)
					{
						text = Strings.Format(num2 / 1024.0, "#0.00") + " KiB";
					}
					else if (num2 < 1024.0)
					{
						text = Conversions.ToString(Conversion.Fix(num2)) + " B";
					}
					if (ptr)
					{
						text = Strings.Split(text, " ", -1, CompareMethod.Text)[0];
					}
					if (text.Length > 0)
					{
						result = text;
					}
					else
					{
						result = " 0 B";
					}
					IL_17B:
					goto IL_1CA;
					IL_17D:
					result = "0 B";
					goto IL_17B;
					IL_185:
					num4 = -1;
					@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
					IL_19B:;
				}
				catch when (endfilter(obj is Exception & num3 != 0 & num4 == 0))
				{
					Exception ex = (Exception)obj2;
					goto IL_185;
				}
				throw ProjectData.CreateProjectError(-2146828237);
				IL_1CA:
				if (num4 != 0)
				{
					ProjectData.ClearProjectError();
				}
				return result;
			}
			set
			{
				this.dRecv = Conversions.ToDouble(value);
			}
		}

		// Token: 0x1700009C RID: 156
		// (get) Token: 0x06001B03 RID: 6915 RVA: 0x0000DD32 File Offset: 0x0000BF32
		// (set) Token: 0x06001B04 RID: 6916 RVA: 0x0000DD3C File Offset: 0x0000BF3C
		public string TARGET
		{
			get
			{
				return this.idxValues[6];
			}
			set
			{
				this.idxValues[6] = value;
			}
		}

		// Token: 0x1700009D RID: 157
		// (get) Token: 0x06001B05 RID: 6917 RVA: 0x0000DD47 File Offset: 0x0000BF47
		// (set) Token: 0x06001B06 RID: 6918 RVA: 0x0000DD51 File Offset: 0x0000BF51
		public string SPEED_DL
		{
			get
			{
				return this.idxValues[7];
			}
			set
			{
				this.idxValues[7] = value;
			}
		}

		// Token: 0x1700009E RID: 158
		// (get) Token: 0x06001B07 RID: 6919 RVA: 0x0000DD5C File Offset: 0x0000BF5C
		// (set) Token: 0x06001B08 RID: 6920 RVA: 0x0000DD66 File Offset: 0x0000BF66
		public string SPEED_UL
		{
			get
			{
				return this.idxValues[8];
			}
			set
			{
				this.idxValues[8] = value;
			}
		}

		// Token: 0x1700009F RID: 159
		// (get) Token: 0x06001B09 RID: 6921 RVA: 0x0000DD71 File Offset: 0x0000BF71
		// (set) Token: 0x06001B0A RID: 6922 RVA: 0x0000DD79 File Offset: 0x0000BF79
		public string Tag
		{
			get
			{
				return this.m_tag;
			}
			set
			{
				this.m_tag = value;
			}
		}

		// Token: 0x04000A56 RID: 2646
		public string[] idxValues;

		// Token: 0x04000A57 RID: 2647
		public string Key;

		// Token: 0x04000A58 RID: 2648
		private string m_user;

		// Token: 0x04000A59 RID: 2649
		private string m_port;

		// Token: 0x04000A5A RID: 2650
		private string m_duration;

		// Token: 0x04000A5B RID: 2651
		private string m_tag;

		// Token: 0x04000A5C RID: 2652
		public bool bJustConnected;

		// Token: 0x04000A5D RID: 2653
		public bool pending_dc;

		// Token: 0x04000A5E RID: 2654
		public bool pending_dc_timeout;

		// Token: 0x04000A5F RID: 2655
		public bool rejected;

		// Token: 0x04000A60 RID: 2656
		public long lStarted;

		// Token: 0x04000A61 RID: 2657
		public double dRecv;

		// Token: 0x04000A62 RID: 2658
		public double dSent;
	}
}
