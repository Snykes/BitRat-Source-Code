﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using VisualPlus.Toolkit.Controls.Interactivity;

// Token: 0x02000155 RID: 341
[DesignerGenerated]
public sealed partial class fBuilder : Form
{
	// Token: 0x060012CD RID: 4813 RVA: 0x0000A5BE File Offset: 0x000087BE
	public fBuilder()
	{
		base.Load += this.fBuilder_Load;
		base.Closing += this.fBuilder_Closing;
		this.InitializeComponent();
	}

	// Token: 0x060012D0 RID: 4816 RVA: 0x0000A5F0 File Offset: 0x000087F0
	internal TextBox vmethod_0()
	{
		return this.textBox_0;
	}

	// Token: 0x060012D1 RID: 4817 RVA: 0x000885B4 File Offset: 0x000867B4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_1(TextBox textBox_6)
	{
		EventHandler value = new EventHandler(this.method_3);
		TextBox textBox = this.textBox_0;
		if (textBox != null)
		{
			textBox.TextChanged -= value;
		}
		this.textBox_0 = textBox_6;
		textBox = this.textBox_0;
		if (textBox != null)
		{
			textBox.TextChanged += value;
		}
	}

	// Token: 0x060012D2 RID: 4818 RVA: 0x0000A5F8 File Offset: 0x000087F8
	internal Label vmethod_2()
	{
		return this.label_0;
	}

	// Token: 0x060012D3 RID: 4819 RVA: 0x0000A600 File Offset: 0x00008800
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_3(Label label_11)
	{
		this.label_0 = label_11;
	}

	// Token: 0x060012D4 RID: 4820 RVA: 0x0000A609 File Offset: 0x00008809
	internal TextBox vmethod_4()
	{
		return this.textBox_1;
	}

	// Token: 0x060012D5 RID: 4821 RVA: 0x000885F8 File Offset: 0x000867F8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_5(TextBox textBox_6)
	{
		EventHandler value = new EventHandler(this.method_1);
		TextBox textBox = this.textBox_1;
		if (textBox != null)
		{
			textBox.TextChanged -= value;
		}
		this.textBox_1 = textBox_6;
		textBox = this.textBox_1;
		if (textBox != null)
		{
			textBox.TextChanged += value;
		}
	}

	// Token: 0x060012D6 RID: 4822 RVA: 0x0000A611 File Offset: 0x00008811
	internal Label vmethod_6()
	{
		return this.label_1;
	}

	// Token: 0x060012D7 RID: 4823 RVA: 0x0000A619 File Offset: 0x00008819
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_7(Label label_11)
	{
		this.label_1 = label_11;
	}

	// Token: 0x060012D8 RID: 4824 RVA: 0x0000A622 File Offset: 0x00008822
	internal Label vmethod_8()
	{
		return this.label_2;
	}

	// Token: 0x060012D9 RID: 4825 RVA: 0x0000A62A File Offset: 0x0000882A
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_9(Label label_11)
	{
		this.label_2 = label_11;
	}

	// Token: 0x060012DA RID: 4826 RVA: 0x0000A633 File Offset: 0x00008833
	internal TextBox vmethod_10()
	{
		return this.textBox_2;
	}

	// Token: 0x060012DB RID: 4827 RVA: 0x0008863C File Offset: 0x0008683C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_11(TextBox textBox_6)
	{
		EventHandler value = new EventHandler(this.method_19);
		TextBox textBox = this.textBox_2;
		if (textBox != null)
		{
			textBox.TextChanged -= value;
		}
		this.textBox_2 = textBox_6;
		textBox = this.textBox_2;
		if (textBox != null)
		{
			textBox.TextChanged += value;
		}
	}

	// Token: 0x060012DC RID: 4828 RVA: 0x0000A63B File Offset: 0x0000883B
	internal PictureBox vmethod_12()
	{
		return this.pictureBox_0;
	}

	// Token: 0x060012DD RID: 4829 RVA: 0x00088680 File Offset: 0x00086880
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_13(PictureBox pictureBox_6)
	{
		EventHandler value = new EventHandler(this.method_2);
		PictureBox pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_0 = pictureBox_6;
		pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x060012DE RID: 4830 RVA: 0x0000A643 File Offset: 0x00008843
	internal CheckBox vmethod_14()
	{
		return this.checkBox_0;
	}

	// Token: 0x060012DF RID: 4831 RVA: 0x000886C4 File Offset: 0x000868C4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_15(CheckBox checkBox_1)
	{
		EventHandler value = new EventHandler(this.method_4);
		CheckBox checkBox = this.checkBox_0;
		if (checkBox != null)
		{
			checkBox.CheckedChanged -= value;
		}
		this.checkBox_0 = checkBox_1;
		checkBox = this.checkBox_0;
		if (checkBox != null)
		{
			checkBox.CheckedChanged += value;
		}
	}

	// Token: 0x060012E0 RID: 4832 RVA: 0x0000A64B File Offset: 0x0000884B
	internal TextBox vmethod_16()
	{
		return this.textBox_3;
	}

	// Token: 0x060012E1 RID: 4833 RVA: 0x0000A653 File Offset: 0x00008853
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_17(TextBox textBox_6)
	{
		this.textBox_3 = textBox_6;
	}

	// Token: 0x060012E2 RID: 4834 RVA: 0x0000A65C File Offset: 0x0000885C
	internal Label vmethod_18()
	{
		return this.label_3;
	}

	// Token: 0x060012E3 RID: 4835 RVA: 0x0000A664 File Offset: 0x00008864
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_19(Label label_11)
	{
		this.label_3 = label_11;
	}

	// Token: 0x060012E4 RID: 4836 RVA: 0x0000A66D File Offset: 0x0000886D
	internal TextBox vmethod_20()
	{
		return this.textBox_4;
	}

	// Token: 0x060012E5 RID: 4837 RVA: 0x00088708 File Offset: 0x00086908
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_21(TextBox textBox_6)
	{
		EventHandler value = new EventHandler(this.method_20);
		TextBox textBox = this.textBox_4;
		if (textBox != null)
		{
			textBox.TextChanged -= value;
		}
		this.textBox_4 = textBox_6;
		textBox = this.textBox_4;
		if (textBox != null)
		{
			textBox.TextChanged += value;
		}
	}

	// Token: 0x060012E6 RID: 4838 RVA: 0x0000A675 File Offset: 0x00008875
	internal Label vmethod_22()
	{
		return this.label_4;
	}

	// Token: 0x060012E7 RID: 4839 RVA: 0x0000A67D File Offset: 0x0000887D
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_23(Label label_11)
	{
		this.label_4 = label_11;
	}

	// Token: 0x060012E8 RID: 4840 RVA: 0x0000A686 File Offset: 0x00008886
	internal Label vmethod_24()
	{
		return this.label_5;
	}

	// Token: 0x060012E9 RID: 4841 RVA: 0x0000A68E File Offset: 0x0000888E
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_25(Label label_11)
	{
		this.label_5 = label_11;
	}

	// Token: 0x060012EA RID: 4842 RVA: 0x0000A697 File Offset: 0x00008897
	internal Label vmethod_26()
	{
		return this.label_6;
	}

	// Token: 0x060012EB RID: 4843 RVA: 0x0000A69F File Offset: 0x0000889F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_27(Label label_11)
	{
		this.label_6 = label_11;
	}

	// Token: 0x060012EC RID: 4844 RVA: 0x0000A6A8 File Offset: 0x000088A8
	internal PictureBox vmethod_28()
	{
		return this.pictureBox_1;
	}

	// Token: 0x060012ED RID: 4845 RVA: 0x0008874C File Offset: 0x0008694C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_29(PictureBox pictureBox_6)
	{
		EventHandler value = new EventHandler(this.method_5);
		PictureBox pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_1 = pictureBox_6;
		pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x060012EE RID: 4846 RVA: 0x0000A6B0 File Offset: 0x000088B0
	internal PictureBox vmethod_30()
	{
		return this.pictureBox_2;
	}

	// Token: 0x060012EF RID: 4847 RVA: 0x00088790 File Offset: 0x00086990
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_31(PictureBox pictureBox_6)
	{
		EventHandler value = new EventHandler(this.method_6);
		PictureBox pictureBox = this.pictureBox_2;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_2 = pictureBox_6;
		pictureBox = this.pictureBox_2;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x060012F0 RID: 4848 RVA: 0x0000A6B8 File Offset: 0x000088B8
	internal VisualButton vmethod_32()
	{
		return this.visualButton_0;
	}

	// Token: 0x060012F1 RID: 4849 RVA: 0x000887D4 File Offset: 0x000869D4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_33(VisualButton visualButton_1)
	{
		EventHandler value = new EventHandler(this.method_11);
		VisualButton visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_0 = visualButton_1;
		visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x060012F2 RID: 4850 RVA: 0x0000A6C0 File Offset: 0x000088C0
	internal StatusStrip vmethod_34()
	{
		return this.statusStrip_0;
	}

	// Token: 0x060012F3 RID: 4851 RVA: 0x0000A6C8 File Offset: 0x000088C8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_35(StatusStrip statusStrip_1)
	{
		this.statusStrip_0 = statusStrip_1;
	}

	// Token: 0x060012F4 RID: 4852 RVA: 0x0000A6D1 File Offset: 0x000088D1
	internal ToolStripStatusLabel vmethod_36()
	{
		return this.toolStripStatusLabel_0;
	}

	// Token: 0x060012F5 RID: 4853 RVA: 0x0000A6D9 File Offset: 0x000088D9
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_37(ToolStripStatusLabel toolStripStatusLabel_1)
	{
		this.toolStripStatusLabel_0 = toolStripStatusLabel_1;
	}

	// Token: 0x060012F6 RID: 4854 RVA: 0x0000A6E2 File Offset: 0x000088E2
	internal GClass7 vmethod_38()
	{
		return this.gclass7_0;
	}

	// Token: 0x060012F7 RID: 4855 RVA: 0x0000A6EA File Offset: 0x000088EA
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_39(GClass7 gclass7_1)
	{
		this.gclass7_0 = gclass7_1;
	}

	// Token: 0x060012F8 RID: 4856 RVA: 0x0000A6F3 File Offset: 0x000088F3
	internal BackgroundWorker vmethod_40()
	{
		return this.backgroundWorker_0;
	}

	// Token: 0x060012F9 RID: 4857 RVA: 0x00088818 File Offset: 0x00086A18
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_41(BackgroundWorker backgroundWorker_1)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_14);
		BackgroundWorker backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_0 = backgroundWorker_1;
		backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x060012FA RID: 4858 RVA: 0x0000A6FB File Offset: 0x000088FB
	internal Label vmethod_42()
	{
		return this.label_7;
	}

	// Token: 0x060012FB RID: 4859 RVA: 0x0000A703 File Offset: 0x00008903
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_43(Label label_11)
	{
		this.label_7 = label_11;
	}

	// Token: 0x060012FC RID: 4860 RVA: 0x0000A70C File Offset: 0x0000890C
	internal Timer vmethod_44()
	{
		return this.timer_0;
	}

	// Token: 0x060012FD RID: 4861 RVA: 0x0008885C File Offset: 0x00086A5C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_45(Timer timer_1)
	{
		EventHandler value = new EventHandler(this.method_15);
		Timer timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_0 = timer_1;
		timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x060012FE RID: 4862 RVA: 0x0000A714 File Offset: 0x00008914
	internal Label vmethod_46()
	{
		return this.label_8;
	}

	// Token: 0x060012FF RID: 4863 RVA: 0x0000A71C File Offset: 0x0000891C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_47(Label label_11)
	{
		this.label_8 = label_11;
	}

	// Token: 0x06001300 RID: 4864 RVA: 0x0000A725 File Offset: 0x00008925
	internal PictureBox vmethod_48()
	{
		return this.pictureBox_3;
	}

	// Token: 0x06001301 RID: 4865 RVA: 0x000888A0 File Offset: 0x00086AA0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_49(PictureBox pictureBox_6)
	{
		EventHandler value = new EventHandler(this.method_16);
		PictureBox pictureBox = this.pictureBox_3;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_3 = pictureBox_6;
		pictureBox = this.pictureBox_3;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06001302 RID: 4866 RVA: 0x0000A72D File Offset: 0x0000892D
	internal RadioButton vmethod_50()
	{
		return this.radioButton_0;
	}

	// Token: 0x06001303 RID: 4867 RVA: 0x0000A735 File Offset: 0x00008935
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_51(RadioButton radioButton_2)
	{
		this.radioButton_0 = radioButton_2;
	}

	// Token: 0x06001304 RID: 4868 RVA: 0x0000A73E File Offset: 0x0000893E
	internal RadioButton vmethod_52()
	{
		return this.radioButton_1;
	}

	// Token: 0x06001305 RID: 4869 RVA: 0x0000A746 File Offset: 0x00008946
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_53(RadioButton radioButton_2)
	{
		this.radioButton_1 = radioButton_2;
	}

	// Token: 0x06001306 RID: 4870 RVA: 0x0000A74F File Offset: 0x0000894F
	internal TextBox vmethod_54()
	{
		return this.textBox_5;
	}

	// Token: 0x06001307 RID: 4871 RVA: 0x0000A757 File Offset: 0x00008957
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_55(TextBox textBox_6)
	{
		this.textBox_5 = textBox_6;
	}

	// Token: 0x06001308 RID: 4872 RVA: 0x0000A760 File Offset: 0x00008960
	internal Label vmethod_56()
	{
		return this.label_9;
	}

	// Token: 0x06001309 RID: 4873 RVA: 0x0000A768 File Offset: 0x00008968
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_57(Label label_11)
	{
		this.label_9 = label_11;
	}

	// Token: 0x0600130A RID: 4874 RVA: 0x0000A771 File Offset: 0x00008971
	internal Label vmethod_58()
	{
		return this.label_10;
	}

	// Token: 0x0600130B RID: 4875 RVA: 0x0000A779 File Offset: 0x00008979
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_59(Label label_11)
	{
		this.label_10 = label_11;
	}

	// Token: 0x0600130C RID: 4876 RVA: 0x0000A782 File Offset: 0x00008982
	internal PictureBox vmethod_60()
	{
		return this.pictureBox_4;
	}

	// Token: 0x0600130D RID: 4877 RVA: 0x000888E4 File Offset: 0x00086AE4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_61(PictureBox pictureBox_6)
	{
		EventHandler value = new EventHandler(this.method_17);
		PictureBox pictureBox = this.pictureBox_4;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_4 = pictureBox_6;
		pictureBox = this.pictureBox_4;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x0600130E RID: 4878 RVA: 0x0000A78A File Offset: 0x0000898A
	internal PictureBox vmethod_62()
	{
		return this.pictureBox_5;
	}

	// Token: 0x0600130F RID: 4879 RVA: 0x00088928 File Offset: 0x00086B28
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_63(PictureBox pictureBox_6)
	{
		EventHandler value = new EventHandler(this.method_18);
		PictureBox pictureBox = this.pictureBox_5;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_5 = pictureBox_6;
		pictureBox = this.pictureBox_5;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06001310 RID: 4880 RVA: 0x0008896C File Offset: 0x00086B6C
	public void method_0()
	{
		this.vmethod_50().Checked = Class135.smethod_0().BuilderTLS;
		this.vmethod_52().Checked = !Class135.smethod_0().BuilderTLS;
		this.vmethod_10().Text = Class135.smethod_0().BuilderHost;
		this.vmethod_4().Text = Class135.smethod_0().BuilderPort;
		this.vmethod_0().Text = Class135.smethod_0().BuilderPass;
		this.vmethod_54().Text = Class135.smethod_0().BuilderTorPrcname;
		this.vmethod_16().Text = Class135.smethod_0().BuilderFilename;
		this.vmethod_20().Text = Class135.smethod_0().BuilderInstallFolder;
		base.Opacity = 90.0;
	}

	// Token: 0x06001311 RID: 4881 RVA: 0x00088A34 File Offset: 0x00086C34
	private void fBuilder_Load(object sender, EventArgs e)
	{
		base.Visible = false;
		this.vmethod_38().Columns.Add("c1", string.Empty);
		this.vmethod_38().Columns[0].Width = checked(this.vmethod_38().Width - 25);
		this.vmethod_38().GridLines = Class135.smethod_0().Gridlines;
	}

	// Token: 0x06001312 RID: 4882 RVA: 0x00088A9C File Offset: 0x00086C9C
	private void method_1(object sender, EventArgs e)
	{
		if (!Versioned.IsNumeric(this.vmethod_4().Text) | Conversion.Val(this.vmethod_4().Text) < 1.0 | Conversion.Val(this.vmethod_4().Text) > 65535.0)
		{
			this.vmethod_4().BackColor = Color.Red;
			return;
		}
		this.vmethod_4().BackColor = Color.White;
	}

	// Token: 0x06001313 RID: 4883 RVA: 0x0000A792 File Offset: 0x00008992
	private void method_2(object sender, EventArgs e)
	{
		Interaction.MsgBox("Enter your IP, DNS or Tor service (.onion) to which the client will connect.\r\n\r\nIf you wish to create a Tor client and use a .onion, then navigate to Settings and click on \"Tor hidden service\" to generate your own .onion address and use it with your .exe for enhanced anonymity and security.\r\n\r\nGood news is that the Tor hidden service method (client connects to .onion) requires no port forwarding.\r\n\r\nNOTE: The Tor hidden service will use port 80 (when using .onion). This port should not be forwarded from your end.\r\nInstead, port 80 is used within the Tor network.", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06001314 RID: 4884 RVA: 0x00088B18 File Offset: 0x00086D18
	private void method_3(object sender, EventArgs e)
	{
		TextBox textBox;
		object text = (textBox = this.vmethod_0()).Text;
		ref object ptr = ref text;
		object obj = Strings.Len(RuntimeHelpers.GetObjectValue(ptr)) > 0 & Strings.Len(RuntimeHelpers.GetObjectValue(ptr)) <= 16;
		object operand = obj;
		textBox.Text = Conversions.ToString(text);
		if (Conversions.ToBoolean(Operators.NotObject(operand)))
		{
			this.vmethod_0().BackColor = Color.Red;
			return;
		}
		this.vmethod_0().BackColor = Color.White;
	}

	// Token: 0x06001315 RID: 4885 RVA: 0x00088BA0 File Offset: 0x00086DA0
	private void method_4(object sender, EventArgs e)
	{
		this.vmethod_18().Enabled = this.vmethod_14().Checked;
		this.vmethod_16().Enabled = this.vmethod_14().Checked;
		this.vmethod_24().Enabled = this.vmethod_14().Checked;
		this.vmethod_22().Enabled = this.vmethod_14().Checked;
		this.vmethod_20().Enabled = this.vmethod_14().Checked;
	}

	// Token: 0x06001316 RID: 4886 RVA: 0x0000A7A6 File Offset: 0x000089A6
	private void method_5(object sender, EventArgs e)
	{
		Interaction.MsgBox("The client will be installed in %LOCALAPPDATA%\\{FODLER_NAME} where {FODLER_NAME} represents the installation folder.", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06001317 RID: 4887 RVA: 0x0000A7BA File Offset: 0x000089BA
	private void method_6(object sender, EventArgs e)
	{
		Interaction.MsgBox("Do not select this option if you intend on using a Crypter.\r\nUse the startup and installation from the Crypter instead.", MsgBoxStyle.Exclamation, Application.ProductName);
	}

	// Token: 0x06001318 RID: 4888 RVA: 0x00088C1C File Offset: 0x00086E1C
	public void method_7(string string_0, Color color_0)
	{
		object[] object_ = new object[]
		{
			this,
			string_0,
			color_0
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O6&*?7]n", object_);
	}

	// Token: 0x06001319 RID: 4889 RVA: 0x00088C58 File Offset: 0x00086E58
	public void method_8()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O9#*?=8a", object_);
	}

	// Token: 0x0600131A RID: 4890 RVA: 0x00088C88 File Offset: 0x00086E88
	public void method_9(string string_0)
	{
		object[] object_ = new object[]
		{
			this,
			string_0
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O6>*?9PM", object_);
	}

	// Token: 0x0600131B RID: 4891 RVA: 0x00088CBC File Offset: 0x00086EBC
	public void method_10(byte[] byte_0)
	{
		object[] object_ = new object[]
		{
			this,
			byte_0
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O70*?8c7", object_);
	}

	// Token: 0x0600131C RID: 4892 RVA: 0x00088CF0 File Offset: 0x00086EF0
	private void method_11(object sender, EventArgs e)
	{
		object[] object_ = new object[]
		{
			this,
			sender,
			e
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O5!*?6pX", object_);
	}

	// Token: 0x0600131D RID: 4893 RVA: 0x00088D28 File Offset: 0x00086F28
	public bool method_12()
	{
		object[] object_ = new object[]
		{
			this
		};
		return (bool)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O:p*?5J/", object_);
	}

	// Token: 0x0600131E RID: 4894 RVA: 0x00088D60 File Offset: 0x00086F60
	public void method_13()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O61*?5t=", object_);
	}

	// Token: 0x0600131F RID: 4895 RVA: 0x00088D90 File Offset: 0x00086F90
	private void method_14(object sender, DoWorkEventArgs e)
	{
		object[] object_ = new object[]
		{
			this,
			sender,
			e
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O=O*?52'", object_);
	}

	// Token: 0x06001320 RID: 4896 RVA: 0x0000A7CE File Offset: 0x000089CE
	private void fBuilder_Closing(object sender, CancelEventArgs e)
	{
		if (Class130.struct18_7.method_0() && MessageBox.Show("A build is currently in progress. Closing this window will cancel the build. Proceed?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.No)
		{
			e.Cancel = true;
			return;
		}
		base.Visible = false;
		e.Cancel = true;
	}

	// Token: 0x06001321 RID: 4897 RVA: 0x00088DC8 File Offset: 0x00086FC8
	private void method_15(object sender, EventArgs e)
	{
		object[] object_ = new object[]
		{
			this,
			sender,
			e
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O5]*?8<*", object_);
	}

	// Token: 0x06001322 RID: 4898 RVA: 0x0000A807 File Offset: 0x00008A07
	private void method_16(object sender, EventArgs e)
	{
		Interaction.MsgBox("You have selected to use a .onion address as host.\r\nYou should NOT forward any port for this to work.\r\n\r\nWARNING: Forwarding the Tor port when using a .onion address is dangerous and should be kept closed from public access (WAN). Leaving the port accessible from WAN may expose you to correlation attacks, which may reveal your IP.\r\n\r\nHowever, the Tor port in settings should still be started when using a .onion address. This port is used only for local communication between Tor and " + Application.ProductName + ".", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06001323 RID: 4899 RVA: 0x0000A82A File Offset: 0x00008A2A
	private void method_17(object sender, EventArgs e)
	{
		this.vmethod_0().PasswordChar = '\0';
		this.vmethod_62().Visible = true;
		this.vmethod_60().Visible = false;
	}

	// Token: 0x06001324 RID: 4900 RVA: 0x0000A850 File Offset: 0x00008A50
	private void method_18(object sender, EventArgs e)
	{
		this.vmethod_0().PasswordChar = '*';
		this.vmethod_60().Visible = true;
		this.vmethod_62().Visible = false;
	}

	// Token: 0x06001325 RID: 4901 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_19(object sender, EventArgs e)
	{
	}

	// Token: 0x06001326 RID: 4902 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_20(object sender, EventArgs e)
	{
	}

	// Token: 0x04000753 RID: 1875
	private TextBox textBox_0;

	// Token: 0x04000754 RID: 1876
	private Label label_0;

	// Token: 0x04000755 RID: 1877
	private TextBox textBox_1;

	// Token: 0x04000756 RID: 1878
	private Label label_1;

	// Token: 0x04000757 RID: 1879
	private Label label_2;

	// Token: 0x04000758 RID: 1880
	private TextBox textBox_2;

	// Token: 0x04000759 RID: 1881
	private PictureBox pictureBox_0;

	// Token: 0x0400075A RID: 1882
	private CheckBox checkBox_0;

	// Token: 0x0400075B RID: 1883
	private TextBox textBox_3;

	// Token: 0x0400075C RID: 1884
	private Label label_3;

	// Token: 0x0400075D RID: 1885
	private TextBox textBox_4;

	// Token: 0x0400075E RID: 1886
	private Label label_4;

	// Token: 0x0400075F RID: 1887
	private Label label_5;

	// Token: 0x04000760 RID: 1888
	private Label label_6;

	// Token: 0x04000761 RID: 1889
	private PictureBox pictureBox_1;

	// Token: 0x04000762 RID: 1890
	private PictureBox pictureBox_2;

	// Token: 0x04000763 RID: 1891
	private VisualButton visualButton_0;

	// Token: 0x04000764 RID: 1892
	private StatusStrip statusStrip_0;

	// Token: 0x04000765 RID: 1893
	private ToolStripStatusLabel toolStripStatusLabel_0;

	// Token: 0x04000766 RID: 1894
	private GClass7 gclass7_0;

	// Token: 0x04000767 RID: 1895
	private BackgroundWorker backgroundWorker_0;

	// Token: 0x04000768 RID: 1896
	private Label label_7;

	// Token: 0x04000769 RID: 1897
	private Timer timer_0;

	// Token: 0x0400076A RID: 1898
	private Label label_8;

	// Token: 0x0400076B RID: 1899
	private PictureBox pictureBox_3;

	// Token: 0x0400076C RID: 1900
	private RadioButton radioButton_0;

	// Token: 0x0400076D RID: 1901
	private RadioButton radioButton_1;

	// Token: 0x0400076E RID: 1902
	private TextBox textBox_5;

	// Token: 0x0400076F RID: 1903
	private Label label_9;

	// Token: 0x04000770 RID: 1904
	private Label label_10;

	// Token: 0x04000771 RID: 1905
	private PictureBox pictureBox_4;

	// Token: 0x04000772 RID: 1906
	private PictureBox pictureBox_5;

	// Token: 0x04000773 RID: 1907
	private long long_0;

	// Token: 0x04000774 RID: 1908
	private Struct18 struct18_0;

	// Token: 0x04000775 RID: 1909
	private Struct18 struct18_1;

	// Token: 0x04000776 RID: 1910
	private Struct16 struct16_0;

	// Token: 0x04000777 RID: 1911
	private Struct7 struct7_0;

	// Token: 0x02000156 RID: 342
	// (Invoke) Token: 0x0600132C RID: 4908
	private delegate void Delegate111(byte[] byte_0);

	// Token: 0x02000157 RID: 343
	// (Invoke) Token: 0x06001330 RID: 4912
	private delegate void Delegate112();

	// Token: 0x02000158 RID: 344
	// (Invoke) Token: 0x06001334 RID: 4916
	private delegate void Delegate113(string string_0);

	// Token: 0x02000159 RID: 345
	// (Invoke) Token: 0x06001338 RID: 4920
	private delegate void Delegate114();

	// Token: 0x0200015A RID: 346
	// (Invoke) Token: 0x0600133C RID: 4924
	private delegate void Delegate115(string string_0, Color color_0);
}
