﻿// Token: 0x020000D8 RID: 216
[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
public sealed partial class fPreview : global::System.Windows.Forms.Form
{
	// Token: 0x06000A3C RID: 2620 RVA: 0x00051620 File Offset: 0x0004F820
	[global::System.Diagnostics.DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && this.icontainer_0 != null)
			{
				this.icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	// Token: 0x06000A3D RID: 2621 RVA: 0x00051660 File Offset: 0x0004F860
	[global::System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		this.vmethod_3(new global::System.Windows.Forms.Timer(this.icontainer_0));
		this.vmethod_5(new global::System.Windows.Forms.Timer(this.icontainer_0));
		this.vmethod_7(new global::System.Windows.Forms.Timer(this.icontainer_0));
		this.vmethod_9(new global::System.Windows.Forms.Label());
		this.vmethod_11(new global::System.Windows.Forms.Timer(this.icontainer_0));
		this.vmethod_1(new global::System.Windows.Forms.PictureBox());
		this.vmethod_13(new global::Zeroit.Framework.Progress.ZeroitWin8ProgressRing());
		this.vmethod_15(new global::System.Windows.Forms.Label());
		this.vmethod_17(new global::System.Windows.Forms.Timer(this.icontainer_0));
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_0()).BeginInit();
		base.SuspendLayout();
		this.vmethod_2().Interval = 1;
		this.vmethod_4().Interval = 1;
		this.vmethod_6().Interval = 1;
		this.vmethod_8().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_8().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_8().ForeColor = global::System.Drawing.Color.Black;
		this.vmethod_8().Location = new global::System.Drawing.Point(0, 0);
		this.vmethod_8().Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
		this.vmethod_8().Name = "lblCaption";
		this.vmethod_8().Size = new global::System.Drawing.Size(533, 14);
		this.vmethod_8().TabIndex = 29;
		this.vmethod_8().TextAlign = global::System.Drawing.ContentAlignment.TopCenter;
		this.vmethod_10().Interval = 1;
		this.vmethod_0().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_0().BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
		this.vmethod_0().Location = new global::System.Drawing.Point(1, 16);
		this.vmethod_0().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_0().Name = "pbPreview";
		this.vmethod_0().Size = new global::System.Drawing.Size(531, 262);
		this.vmethod_0().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_0().TabIndex = 28;
		this.vmethod_0().TabStop = false;
		this.vmethod_12().Animate = false;
		this.vmethod_12().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_12().ControlHeight = 80;
		this.vmethod_12().Location = new global::System.Drawing.Point(211, 96);
		this.vmethod_12().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_12().Name = "ziLoader";
		this.vmethod_12().RefreshRate = 100;
		this.vmethod_12().Size = new global::System.Drawing.Size(80, 80);
		this.vmethod_12().TabIndex = 30;
		this.vmethod_14().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_14().Dock = global::System.Windows.Forms.DockStyle.Bottom;
		this.vmethod_14().ForeColor = global::System.Drawing.Color.Black;
		this.vmethod_14().Location = new global::System.Drawing.Point(0, 278);
		this.vmethod_14().Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
		this.vmethod_14().Name = "lblData";
		this.vmethod_14().Size = new global::System.Drawing.Size(533, 14);
		this.vmethod_14().TabIndex = 31;
		this.vmethod_14().TextAlign = global::System.Drawing.ContentAlignment.TopRight;
		this.vmethod_16().Enabled = true;
		this.vmethod_16().Interval = 1;
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = global::System.Drawing.Color.SkyBlue;
		base.ClientSize = new global::System.Drawing.Size(533, 292);
		base.ControlBox = false;
		base.Controls.Add(this.vmethod_14());
		base.Controls.Add(this.vmethod_12());
		base.Controls.Add(this.vmethod_8());
		base.Controls.Add(this.vmethod_0());
		this.DoubleBuffered = true;
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
		base.Margin = new global::System.Windows.Forms.Padding(2);
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "fPreview";
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		this.Text = "fScreenPreview";
		base.TopMost = true;
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_0()).EndInit();
		base.ResumeLayout(false);
	}

	// Token: 0x040003E7 RID: 999
	private global::System.ComponentModel.IContainer icontainer_0;
}
