﻿using System;

// Token: 0x02000068 RID: 104
internal sealed class Class105 : Class94
{
	// Token: 0x0600037B RID: 891 RVA: 0x00004440 File Offset: 0x00002640
	public IntPtr method_2()
	{
		return this.intptr_0;
	}

	// Token: 0x0600037C RID: 892 RVA: 0x00004448 File Offset: 0x00002648
	public void method_3(IntPtr intptr_1)
	{
		this.intptr_0 = intptr_1;
	}

	// Token: 0x0600037D RID: 893 RVA: 0x00004451 File Offset: 0x00002651
	public override Class94 vmethod_4()
	{
		Class105 @class = new Class105();
		@class.method_3(this.intptr_0);
		@class.method_1(base.method_0());
		return @class;
	}

	// Token: 0x0600037E RID: 894 RVA: 0x00004470 File Offset: 0x00002670
	public override object vmethod_0()
	{
		return this.method_2();
	}

	// Token: 0x0600037F RID: 895 RVA: 0x0000447D File Offset: 0x0000267D
	public override void vmethod_1(object object_0)
	{
		this.method_3((IntPtr)object_0);
	}

	// Token: 0x06000380 RID: 896 RVA: 0x0000448B File Offset: 0x0000268B
	public override int vmethod_2()
	{
		return 14;
	}

	// Token: 0x06000381 RID: 897 RVA: 0x0001FC50 File Offset: 0x0001DE50
	public override Class94 vmethod_3(Class94 class94_0)
	{
		base.method_1(class94_0.method_0());
		switch (class94_0.vmethod_2())
		{
		case 0:
			this.method_3((IntPtr)((int)((Class119)class94_0).method_2()));
			return this;
		case 4:
			this.method_3((IntPtr)((Class102)class94_0).method_2());
			return this;
		case 7:
			this.method_3((IntPtr)((Class118)class94_0).method_2());
			return this;
		case 9:
			this.method_3((IntPtr)((int)((Class115)class94_0).method_2()));
			return this;
		case 10:
			this.method_3((IntPtr)((long)((Class114)class94_0).method_2()));
			return this;
		case 11:
			this.method_3((IntPtr)((Class99)class94_0).method_2());
			return this;
		case 14:
			this.method_3(((Class105)class94_0).method_2());
			return this;
		case 15:
			this.method_3((IntPtr)((int)((Class101)class94_0).method_2()));
			return this;
		case 17:
			this.method_3((IntPtr)((long)((Class117)class94_0).method_2()));
			return this;
		case 19:
			this.method_3((IntPtr)((long)((Class120)class94_0).method_2()));
			return this;
		case 21:
			this.method_3((IntPtr)((long)((ulong)((Class104)class94_0).method_2())));
			return this;
		case 22:
			this.method_3((IntPtr)((int)((Class121)class94_0).method_2()));
			return this;
		case 23:
		{
			Class97 @class = (Class97)class94_0;
			this.method_3(@class.method_4());
			return this;
		}
		case 24:
			this.method_3(new IntPtr(Convert.ToInt64(((Class98)class94_0).method_2())));
			return this;
		}
		throw new ArgumentOutOfRangeException();
	}

	// Token: 0x040001A8 RID: 424
	private IntPtr intptr_0;
}
