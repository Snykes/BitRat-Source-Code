﻿// Token: 0x0200014A RID: 330
[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
public sealed partial class fBuilderDownloader : global::System.Windows.Forms.Form
{
	// Token: 0x06001260 RID: 4704 RVA: 0x0008439C File Offset: 0x0008259C
	[global::System.Diagnostics.DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && this.icontainer_0 != null)
			{
				this.icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	// Token: 0x06001261 RID: 4705 RVA: 0x000843DC File Offset: 0x000825DC
	[global::System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		this.vmethod_1(new global::System.Windows.Forms.Label());
		this.vmethod_3(new global::System.Windows.Forms.TextBox());
		this.vmethod_11(new global::VisualPlus.Toolkit.Controls.Interactivity.VisualButton());
		this.vmethod_13(new global::System.Windows.Forms.RadioButton());
		this.vmethod_15(new global::System.Windows.Forms.RadioButton());
		this.vmethod_9(new global::System.Windows.Forms.PictureBox());
		this.vmethod_7(new global::System.Windows.Forms.PictureBox());
		this.vmethod_5(new global::System.Windows.Forms.PictureBox());
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_8()).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_6()).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_4()).BeginInit();
		base.SuspendLayout();
		this.vmethod_0().AutoSize = true;
		this.vmethod_0().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_0().FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.vmethod_0().Location = new global::System.Drawing.Point(10, 21);
		this.vmethod_0().Margin = new global::System.Windows.Forms.Padding(1, 0, 1, 0);
		this.vmethod_0().Name = "lblURL";
		this.vmethod_0().Size = new global::System.Drawing.Size(32, 13);
		this.vmethod_0().TabIndex = 41;
		this.vmethod_0().Text = "URL:";
		this.vmethod_0().TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
		this.vmethod_2().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Italic, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_2().ForeColor = global::System.Drawing.Color.Gray;
		this.vmethod_2().Location = new global::System.Drawing.Point(44, 18);
		this.vmethod_2().Margin = new global::System.Windows.Forms.Padding(1);
		this.vmethod_2().MaxLength = 255;
		this.vmethod_2().Name = "txtURL";
		this.vmethod_2().Size = new global::System.Drawing.Size(436, 20);
		this.vmethod_2().TabIndex = 2;
		this.vmethod_2().Text = "http://site.com/file.exe";
		this.vmethod_10().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_10().BackColorState.Disabled = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_10().BackColorState.Enabled = global::System.Drawing.Color.FromArgb(220, 220, 220);
		this.vmethod_10().BackColorState.Hover = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_10().BackColorState.Pressed = global::System.Drawing.Color.FromArgb(192, 192, 192);
		this.vmethod_10().Border.Color = global::System.Drawing.Color.FromArgb(180, 180, 180);
		this.vmethod_10().Border.HoverColor = global::System.Drawing.Color.FromArgb(120, 183, 230);
		this.vmethod_10().Border.HoverVisible = true;
		this.vmethod_10().Border.Rounding = 6;
		this.vmethod_10().Border.Thickness = 1;
		this.vmethod_10().Border.Type = 1;
		this.vmethod_10().Border.Visible = true;
		this.vmethod_10().DialogResult = global::System.Windows.Forms.DialogResult.None;
		this.vmethod_10().ForeColor = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_10().Image = null;
		this.vmethod_10().Location = new global::System.Drawing.Point(2, 97);
		this.vmethod_10().MouseState = 0;
		this.vmethod_10().Name = "btnBuild";
		this.vmethod_10().Size = new global::System.Drawing.Size(88, 26);
		this.vmethod_10().TabIndex = 3;
		this.vmethod_10().Text = "Build";
		this.vmethod_10().TextImageRelation = global::System.Windows.Forms.TextImageRelation.Overlay;
		this.vmethod_10().TextStyle.Disabled = global::System.Drawing.Color.FromArgb(131, 129, 129);
		this.vmethod_10().TextStyle.Enabled = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_10().TextStyle.Hover = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_10().TextStyle.Pressed = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_10().TextStyle.TextAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_10().TextStyle.TextLineAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_10().TextStyle.TextRenderingHint = global::System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
		this.vmethod_12().AutoSize = true;
		this.vmethod_12().Checked = true;
		this.vmethod_12().Location = new global::System.Drawing.Point(44, 50);
		this.vmethod_12().Name = "rbDisk";
		this.vmethod_12().Size = new global::System.Drawing.Size(90, 17);
		this.vmethod_12().TabIndex = 0;
		this.vmethod_12().TabStop = true;
		this.vmethod_12().Text = "Run from disk";
		this.vmethod_12().UseVisualStyleBackColor = true;
		this.vmethod_14().AutoSize = true;
		this.vmethod_14().Location = new global::System.Drawing.Point(186, 50);
		this.vmethod_14().Name = "rbMem";
		this.vmethod_14().Size = new global::System.Drawing.Size(114, 17);
		this.vmethod_14().TabIndex = 1;
		this.vmethod_14().Text = "Execute in memory";
		this.vmethod_14().UseVisualStyleBackColor = true;
		this.vmethod_8().Image = global::Class131.smethod_24();
		this.vmethod_8().Location = new global::System.Drawing.Point(301, 52);
		this.vmethod_8().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_8().Name = "pbMem";
		this.vmethod_8().Size = new global::System.Drawing.Size(15, 15);
		this.vmethod_8().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_8().TabIndex = 47;
		this.vmethod_8().TabStop = false;
		this.vmethod_6().Image = global::Class131.smethod_24();
		this.vmethod_6().Location = new global::System.Drawing.Point(134, 52);
		this.vmethod_6().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_6().Name = "pbDisk";
		this.vmethod_6().Size = new global::System.Drawing.Size(15, 15);
		this.vmethod_6().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_6().TabIndex = 46;
		this.vmethod_6().TabStop = false;
		this.vmethod_4().Image = global::Class131.smethod_24();
		this.vmethod_4().Location = new global::System.Drawing.Point(483, 21);
		this.vmethod_4().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_4().Name = "pbURL";
		this.vmethod_4().Size = new global::System.Drawing.Size(15, 15);
		this.vmethod_4().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_4().TabIndex = 43;
		this.vmethod_4().TabStop = false;
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = global::System.Drawing.SystemColors.AppWorkspace;
		base.ClientSize = new global::System.Drawing.Size(535, 126);
		base.Controls.Add(this.vmethod_14());
		base.Controls.Add(this.vmethod_12());
		base.Controls.Add(this.vmethod_10());
		base.Controls.Add(this.vmethod_8());
		base.Controls.Add(this.vmethod_6());
		base.Controls.Add(this.vmethod_4());
		base.Controls.Add(this.vmethod_2());
		base.Controls.Add(this.vmethod_0());
		this.DoubleBuffered = true;
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedToolWindow;
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "fBuilderDownloader";
		base.Opacity = 0.0;
		base.ShowIcon = false;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterParent;
		this.Text = "Builder - Downloader";
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_8()).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_6()).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_4()).EndInit();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x04000730 RID: 1840
	private global::System.ComponentModel.IContainer icontainer_0;
}
