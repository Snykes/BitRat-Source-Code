﻿using System;
using System.IO;

// Token: 0x02000088 RID: 136
internal sealed class Class52 : Class50, IDisposable
{
	// Token: 0x06000410 RID: 1040 RVA: 0x00004990 File Offset: 0x00002B90
	public Class52() : this(0)
	{
	}

	// Token: 0x06000411 RID: 1041 RVA: 0x00021600 File Offset: 0x0001F800
	public Class52(int int_4)
	{
		if (int_4 < 0)
		{
			throw new ArgumentOutOfRangeException();
		}
		this.byte_0 = new byte[int_4];
		this.int_3 = int_4;
		this.bool_0 = true;
		this.bool_1 = true;
		this.int_0 = 0;
		this.bool_2 = true;
	}

	// Token: 0x06000412 RID: 1042 RVA: 0x00004999 File Offset: 0x00002B99
	public Class52(byte[] byte_1) : this(byte_1, true)
	{
	}

	// Token: 0x06000413 RID: 1043 RVA: 0x0002164C File Offset: 0x0001F84C
	public Class52(byte[] byte_1, bool bool_4)
	{
		if (byte_1 == null)
		{
			throw new ArgumentNullException();
		}
		this.byte_0 = byte_1;
		this.int_2 = (this.int_3 = byte_1.Length);
		this.bool_1 = bool_4;
		this.int_0 = 0;
		this.bool_2 = true;
	}

	// Token: 0x06000414 RID: 1044 RVA: 0x000049A3 File Offset: 0x00002BA3
	public Class52(byte[] byte_1, int int_4, int int_5) : this(byte_1, int_4, int_5, true)
	{
	}

	// Token: 0x06000415 RID: 1045 RVA: 0x00021698 File Offset: 0x0001F898
	public Class52(byte[] byte_1, int int_4, int int_5, bool bool_4)
	{
		if (byte_1 == null)
		{
			throw new ArgumentNullException();
		}
		if (int_4 < 0)
		{
			throw new ArgumentOutOfRangeException();
		}
		if (int_5 < 0)
		{
			throw new ArgumentOutOfRangeException();
		}
		if (byte_1.Length - int_4 < int_5)
		{
			throw new ArgumentException();
		}
		this.byte_0 = byte_1;
		this.int_1 = int_4;
		this.int_0 = int_4;
		this.int_2 = (this.int_3 = int_4 + int_5);
		this.bool_1 = bool_4;
		this.bool_0 = false;
		this.bool_2 = true;
	}

	// Token: 0x06000416 RID: 1046 RVA: 0x000049AF File Offset: 0x00002BAF
	public override bool vmethod_0()
	{
		return this.bool_2;
	}

	// Token: 0x06000417 RID: 1047 RVA: 0x000049AF File Offset: 0x00002BAF
	public override bool vmethod_2()
	{
		return this.bool_2;
	}

	// Token: 0x06000418 RID: 1048 RVA: 0x000049B7 File Offset: 0x00002BB7
	public override bool vmethod_1()
	{
		return this.bool_1;
	}

	// Token: 0x06000419 RID: 1049 RVA: 0x000049BF File Offset: 0x00002BBF
	protected override void vmethod_7(bool bool_4)
	{
		if (!this.bool_3)
		{
			if (bool_4)
			{
				this.bool_2 = false;
				this.bool_1 = false;
				this.bool_0 = false;
			}
			this.bool_3 = true;
		}
	}

	// Token: 0x0600041A RID: 1050 RVA: 0x00021718 File Offset: 0x0001F918
	private bool method_0(int int_4)
	{
		if (int_4 < 0)
		{
			throw new IOException();
		}
		if (int_4 > this.int_3)
		{
			int num = int_4;
			if (num < 256)
			{
				num = 256;
			}
			if (num < this.int_3 * 2)
			{
				num = this.int_3 * 2;
			}
			this.method_6(num);
			return true;
		}
		return false;
	}

	// Token: 0x0600041B RID: 1051 RVA: 0x00002F44 File Offset: 0x00001144
	public override void vmethod_8()
	{
	}

	// Token: 0x0600041C RID: 1052 RVA: 0x000049E8 File Offset: 0x00002BE8
	internal byte[] method_1()
	{
		return this.byte_0;
	}

	// Token: 0x0600041D RID: 1053 RVA: 0x000049F0 File Offset: 0x00002BF0
	internal void method_2(out int int_4, out int int_5)
	{
		if (!this.bool_2)
		{
			throw new Exception();
		}
		int_4 = this.int_0;
		int_5 = this.int_2;
	}

	// Token: 0x0600041E RID: 1054 RVA: 0x00004A10 File Offset: 0x00002C10
	internal int method_3()
	{
		if (!this.bool_2)
		{
			throw new Exception();
		}
		return this.int_1;
	}

	// Token: 0x0600041F RID: 1055 RVA: 0x00021768 File Offset: 0x0001F968
	public int method_4(int int_4)
	{
		if (!this.bool_2)
		{
			throw new Exception();
		}
		int num = this.int_2 - this.int_1;
		if (num > int_4)
		{
			num = int_4;
		}
		if (num < 0)
		{
			num = 0;
		}
		this.int_1 += num;
		return num;
	}

	// Token: 0x06000420 RID: 1056 RVA: 0x00004A26 File Offset: 0x00002C26
	public int method_5()
	{
		if (!this.bool_2)
		{
			throw new Exception();
		}
		return this.int_3 - this.int_0;
	}

	// Token: 0x06000421 RID: 1057 RVA: 0x000217AC File Offset: 0x0001F9AC
	public void method_6(int int_4)
	{
		if (!this.bool_2)
		{
			throw new Exception();
		}
		if (int_4 != this.int_3)
		{
			if (!this.bool_0)
			{
				throw new Exception();
			}
			if (int_4 < this.int_2)
			{
				throw new ArgumentOutOfRangeException();
			}
			if (int_4 > 0)
			{
				byte[] dst = new byte[int_4];
				if (this.int_2 > 0)
				{
					Buffer.BlockCopy(this.byte_0, 0, dst, 0, this.int_2);
				}
				this.byte_0 = dst;
			}
			else
			{
				this.byte_0 = null;
			}
			this.int_3 = int_4;
		}
	}

	// Token: 0x06000422 RID: 1058 RVA: 0x00004A43 File Offset: 0x00002C43
	public override long vmethod_3()
	{
		if (!this.bool_2)
		{
			throw new Exception();
		}
		return (long)(this.int_2 - this.int_0);
	}

	// Token: 0x06000423 RID: 1059 RVA: 0x00004A61 File Offset: 0x00002C61
	public override long vmethod_4()
	{
		if (!this.bool_2)
		{
			throw new Exception();
		}
		return (long)(this.int_1 - this.int_0);
	}

	// Token: 0x06000424 RID: 1060 RVA: 0x0002182C File Offset: 0x0001FA2C
	public override void vmethod_5(long long_0)
	{
		if (!this.bool_2)
		{
			throw new Exception();
		}
		if (long_0 < 0L)
		{
			throw new ArgumentOutOfRangeException();
		}
		if (long_0 > 2147483647L)
		{
			throw new ArgumentOutOfRangeException();
		}
		this.int_1 = this.int_0 + (int)long_0;
	}

	// Token: 0x06000425 RID: 1061 RVA: 0x0002187C File Offset: 0x0001FA7C
	public override int vmethod_11(byte[] byte_1, int int_4, int int_5)
	{
		if (!this.bool_2)
		{
			throw new Exception();
		}
		if (byte_1 == null)
		{
			throw new ArgumentNullException();
		}
		if (int_4 < 0)
		{
			throw new ArgumentOutOfRangeException();
		}
		if (int_5 < 0)
		{
			throw new ArgumentOutOfRangeException();
		}
		if (byte_1.Length - int_4 < int_5)
		{
			throw new ArgumentException();
		}
		int num = this.int_2 - this.int_1;
		if (num > int_5)
		{
			num = int_5;
		}
		if (num <= 0)
		{
			return 0;
		}
		if (num <= 8)
		{
			int num2 = num;
			while (--num2 >= 0)
			{
				byte_1[int_4 + num2] = this.byte_0[this.int_1 + num2];
			}
		}
		else
		{
			Buffer.BlockCopy(this.byte_0, this.int_1, byte_1, int_4, num);
		}
		this.int_1 += num;
		return num;
	}

	// Token: 0x06000426 RID: 1062 RVA: 0x00021928 File Offset: 0x0001FB28
	public override int vmethod_12()
	{
		if (!this.bool_2)
		{
			throw new Exception();
		}
		if (this.int_1 >= this.int_2)
		{
			return -1;
		}
		byte[] array = this.byte_0;
		int num = this.int_1;
		this.int_1 = num + 1;
		return array[num];
	}

	// Token: 0x06000427 RID: 1063 RVA: 0x0002196C File Offset: 0x0001FB6C
	public override long vmethod_9(long long_0, int int_4)
	{
		if (!this.bool_2)
		{
			throw new Exception();
		}
		if (long_0 > 2147483647L)
		{
			throw new ArgumentOutOfRangeException();
		}
		switch (int_4)
		{
		case 0:
			if (long_0 < 0L)
			{
				throw new IOException();
			}
			this.int_1 = this.int_0 + (int)long_0;
			break;
		case 1:
			if (long_0 + (long)this.int_1 < (long)this.int_0)
			{
				throw new IOException();
			}
			this.int_1 += (int)long_0;
			break;
		case 2:
			if ((long)this.int_2 + long_0 < (long)this.int_0)
			{
				throw new IOException();
			}
			this.int_1 = this.int_2 + (int)long_0;
			break;
		default:
			throw new ArgumentException();
		}
		return (long)this.int_1;
	}

	// Token: 0x06000428 RID: 1064 RVA: 0x00021A2C File Offset: 0x0001FC2C
	public override void vmethod_10(long long_0)
	{
		if (!this.bool_1)
		{
			throw new Exception();
		}
		if (long_0 > 2147483647L)
		{
			throw new ArgumentOutOfRangeException();
		}
		if (long_0 >= 0L && long_0 <= (long)(2147483647 - this.int_0))
		{
			int num = this.int_0 + (int)long_0;
			if (!this.method_0(num) && num > this.int_2)
			{
				Array.Clear(this.byte_0, this.int_2, num - this.int_2);
			}
			this.int_2 = num;
			if (this.int_1 > num)
			{
				this.int_1 = num;
			}
			return;
		}
		throw new ArgumentOutOfRangeException();
	}

	// Token: 0x06000429 RID: 1065 RVA: 0x00021ACC File Offset: 0x0001FCCC
	public byte[] method_7()
	{
		byte[] array = new byte[this.int_2 - this.int_0];
		Buffer.BlockCopy(this.byte_0, this.int_0, array, 0, this.int_2 - this.int_0);
		return array;
	}

	// Token: 0x0600042A RID: 1066 RVA: 0x00021B10 File Offset: 0x0001FD10
	public override void vmethod_13(byte[] byte_1, int int_4, int int_5)
	{
		if (!this.bool_2)
		{
			throw new Exception();
		}
		if (!this.bool_1)
		{
			throw new Exception();
		}
		if (byte_1 == null)
		{
			throw new ArgumentNullException();
		}
		if (int_4 < 0)
		{
			throw new ArgumentOutOfRangeException();
		}
		if (int_5 < 0)
		{
			throw new ArgumentOutOfRangeException();
		}
		if (byte_1.Length - int_4 < int_5)
		{
			throw new ArgumentException();
		}
		int num = this.int_1 + int_5;
		if (num < 0)
		{
			throw new IOException();
		}
		if (num > this.int_2)
		{
			bool flag = this.int_1 > this.int_2;
			if (num > this.int_3 && this.method_0(num))
			{
				flag = false;
			}
			if (flag)
			{
				Array.Clear(this.byte_0, this.int_2, num - this.int_2);
			}
			this.int_2 = num;
		}
		if (int_5 <= 8)
		{
			int num2 = int_5;
			while (--num2 >= 0)
			{
				this.byte_0[this.int_1 + num2] = byte_1[int_4 + num2];
			}
		}
		else
		{
			Buffer.BlockCopy(byte_1, int_4, this.byte_0, this.int_1, int_5);
		}
		this.int_1 = num;
	}

	// Token: 0x0600042B RID: 1067 RVA: 0x00021C08 File Offset: 0x0001FE08
	public override void vmethod_14(byte byte_1)
	{
		if (!this.bool_2)
		{
			throw new Exception();
		}
		if (!this.bool_1)
		{
			throw new Exception();
		}
		if (this.int_1 >= this.int_2)
		{
			int num = this.int_1 + 1;
			bool flag = this.int_1 > this.int_2;
			if (num >= this.int_3 && this.method_0(num))
			{
				flag = false;
			}
			if (flag)
			{
				Array.Clear(this.byte_0, this.int_2, this.int_1 - this.int_2);
			}
			this.int_2 = num;
		}
		byte[] array = this.byte_0;
		int num2 = this.int_1;
		this.int_1 = num2 + 1;
		array[num2] = byte_1;
	}

	// Token: 0x0600042C RID: 1068 RVA: 0x00004A7F File Offset: 0x00002C7F
	public void method_8(Stream stream_0)
	{
		if (!this.bool_2)
		{
			throw new Exception();
		}
		if (stream_0 == null)
		{
			throw new ArgumentNullException();
		}
		stream_0.Write(this.byte_0, this.int_0, this.int_2 - this.int_0);
	}

	// Token: 0x0600042D RID: 1069 RVA: 0x00021CAC File Offset: 0x0001FEAC
	internal int method_9()
	{
		if (!this.bool_2)
		{
			throw new Exception();
		}
		int num = this.int_1 += 4;
		if (num > this.int_2)
		{
			this.int_1 = this.int_2;
			throw new Exception();
		}
		return (int)this.byte_0[num - 4] << 8 | (int)this.byte_0[num - 3] << 24 | (int)this.byte_0[num - 1] | (int)this.byte_0[num - 2] << 16;
	}

	// Token: 0x040001C7 RID: 455
	private byte[] byte_0;

	// Token: 0x040001C8 RID: 456
	private int int_0;

	// Token: 0x040001C9 RID: 457
	private int int_1;

	// Token: 0x040001CA RID: 458
	private int int_2;

	// Token: 0x040001CB RID: 459
	private int int_3;

	// Token: 0x040001CC RID: 460
	private bool bool_0;

	// Token: 0x040001CD RID: 461
	private bool bool_1;

	// Token: 0x040001CE RID: 462
	private bool bool_2;

	// Token: 0x040001CF RID: 463
	private bool bool_3;
}
