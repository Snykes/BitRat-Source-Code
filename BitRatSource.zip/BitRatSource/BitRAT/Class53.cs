﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000051 RID: 81
internal sealed class Class53
{
	// Token: 0x04000190 RID: 400 RVA: 0x00002A88 File Offset: 0x00000C88
	internal static readonly Class53.Struct13 struct13_0;

	// Token: 0x04000191 RID: 401 RVA: 0x00002550 File Offset: 0x00000750
	internal static readonly Class53.Struct12 struct12_0;

	// Token: 0x02000052 RID: 82
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 20)]
	private struct Struct12
	{
	}

	// Token: 0x02000053 RID: 83
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 256)]
	private struct Struct13
	{
	}
}
