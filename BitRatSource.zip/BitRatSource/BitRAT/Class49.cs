﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000049 RID: 73
internal sealed class Class49
{
	// Token: 0x04000189 RID: 393 RVA: 0x00002050 File Offset: 0x00000250
	internal static readonly Class49.Struct11 struct11_0;

	// Token: 0x0400018A RID: 394 RVA: 0x00002150 File Offset: 0x00000350
	internal static readonly Class49.Struct9 struct9_0;

	// Token: 0x0400018B RID: 395 RVA: 0x00002550 File Offset: 0x00000750
	internal static readonly Class49.Struct10 struct10_0;

	// Token: 0x0400018C RID: 396 RVA: 0x00002568 File Offset: 0x00000768
	internal static readonly Class49.Struct11 struct11_1;

	// Token: 0x0400018D RID: 397 RVA: 0x00002668 File Offset: 0x00000868
	internal static readonly Class49.Struct9 struct9_1;

	// Token: 0x0400018E RID: 398 RVA: 0x00002A68 File Offset: 0x00000C68
	internal static readonly Class49.Struct8 struct8_0;

	// Token: 0x0200004A RID: 74
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 30)]
	private struct Struct8
	{
	}

	// Token: 0x0200004B RID: 75
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 1024)]
	private struct Struct9
	{
	}

	// Token: 0x0200004C RID: 76
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 20)]
	private struct Struct10
	{
	}

	// Token: 0x0200004D RID: 77
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 256)]
	private struct Struct11
	{
	}
}
