﻿using System;
using System.Windows.Forms;

// Token: 0x02000181 RID: 385
public sealed class GClass7 : ListView
{
	// Token: 0x06001583 RID: 5507 RVA: 0x0000B177 File Offset: 0x00009377
	public GClass7()
	{
		this.DoubleBuffered = true;
	}
}
