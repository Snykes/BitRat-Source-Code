﻿using System;

// Token: 0x02000066 RID: 102
internal sealed class Class93 : Class91
{
	// Token: 0x06000371 RID: 881 RVA: 0x000043F0 File Offset: 0x000025F0
	public Class93(Interface1 interface1_1)
	{
		this.interface1_0 = interface1_1;
	}

	// Token: 0x06000372 RID: 882 RVA: 0x000043FF File Offset: 0x000025FF
	public override void Dispose()
	{
		this.interface1_0.imethod_15();
	}

	// Token: 0x06000373 RID: 883 RVA: 0x0000440C File Offset: 0x0000260C
	public override bool vmethod_0()
	{
		return true;
	}

	// Token: 0x06000374 RID: 884 RVA: 0x0000440F File Offset: 0x0000260F
	public override int vmethod_1()
	{
		return this.interface1_0.imethod_2();
	}

	// Token: 0x06000375 RID: 885 RVA: 0x0000441C File Offset: 0x0000261C
	public override int vmethod_2(byte[] byte_0, int int_0, int int_1, byte[] byte_1, int int_2)
	{
		return this.interface1_0.imethod_8(byte_0, int_0, int_1, byte_1, int_2);
	}

	// Token: 0x06000376 RID: 886 RVA: 0x00004430 File Offset: 0x00002630
	public override byte[] vmethod_3(byte[] byte_0, int int_0, int int_1)
	{
		return this.interface1_0.imethod_11(byte_0, int_0, int_1);
	}

	// Token: 0x040001A7 RID: 423
	private readonly Interface1 interface1_0;
}
