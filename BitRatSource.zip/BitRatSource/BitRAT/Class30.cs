﻿using System;

// Token: 0x02000032 RID: 50
internal static class Class30
{
	// Token: 0x0600025F RID: 607 RVA: 0x0001D390 File Offset: 0x0001B590
	public static void smethod_0(byte[] byte_0, int int_0, int int_1)
	{
		for (int i = 0; i < 4; i++)
		{
			int num = int_0++;
			byte_0[num] ^= (byte)(int_1 >> i * 8);
		}
	}

	// Token: 0x06000260 RID: 608 RVA: 0x0001D3C8 File Offset: 0x0001B5C8
	public static void smethod_1(byte[] byte_0, int int_0, int int_1)
	{
		for (int i = 0; i < 4; i++)
		{
			if (int_0 >= byte_0.Length)
			{
				return;
			}
			int num = int_0++;
			byte_0[num] ^= (byte)(int_1 >> i * 8);
		}
	}

	// Token: 0x06000261 RID: 609 RVA: 0x0001D404 File Offset: 0x0001B604
	public static void smethod_2(byte[] byte_0, int int_0, long long_0)
	{
		for (int i = 0; i < 8; i++)
		{
			int num = int_0++;
			byte_0[num] ^= (byte)(long_0 >> i * 8);
		}
	}
}
