﻿using System;

// Token: 0x02000055 RID: 85
internal interface Interface4<T> : Interface3, Interface5
{
	// Token: 0x06000326 RID: 806
	T imethod_3();
}
