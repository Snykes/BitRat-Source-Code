﻿using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

// Token: 0x0200010D RID: 269
[DebuggerNonUserCode]
[StandardModule]
[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
[HideModuleName]
internal sealed class Class131
{
	// Token: 0x06000E3B RID: 3643 RVA: 0x000085CD File Offset: 0x000067CD
	internal static ResourceManager smethod_0()
	{
		if (object.ReferenceEquals(Class131.resourceManager_0, null))
		{
			Class131.resourceManager_0 = new ResourceManager("BitRAT.Resources", typeof(Class131).Assembly);
		}
		return Class131.resourceManager_0;
	}

	// Token: 0x06000E3C RID: 3644 RVA: 0x000085FF File Offset: 0x000067FF
	internal static CultureInfo smethod_1()
	{
		return Class131.cultureInfo_0;
	}

	// Token: 0x06000E3D RID: 3645 RVA: 0x00008606 File Offset: 0x00006806
	internal static void smethod_2(CultureInfo cultureInfo_1)
	{
		Class131.cultureInfo_0 = cultureInfo_1;
	}

	// Token: 0x06000E3E RID: 3646 RVA: 0x0000860E File Offset: 0x0000680E
	internal static Bitmap smethod_3()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("417px-Checkmark_green.svg", Class131.cultureInfo_0));
	}

	// Token: 0x06000E3F RID: 3647 RVA: 0x0000862E File Offset: 0x0000682E
	internal static Bitmap smethod_4()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("error", Class131.cultureInfo_0));
	}

	// Token: 0x06000E40 RID: 3648 RVA: 0x0000864E File Offset: 0x0000684E
	internal static Bitmap smethod_5()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("active-search-24", Class131.cultureInfo_0));
	}

	// Token: 0x06000E41 RID: 3649 RVA: 0x0000866E File Offset: 0x0000686E
	internal static Bitmap smethod_6()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("application", Class131.cultureInfo_0));
	}

	// Token: 0x06000E42 RID: 3650 RVA: 0x0000868E File Offset: 0x0000688E
	internal static byte[] smethod_7()
	{
		return (byte[])RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("bnd", Class131.cultureInfo_0));
	}

	// Token: 0x06000E43 RID: 3651 RVA: 0x000086AE File Offset: 0x000068AE
	internal static Bitmap smethod_8()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("browser", Class131.cultureInfo_0));
	}

	// Token: 0x06000E44 RID: 3652 RVA: 0x000086CE File Offset: 0x000068CE
	internal static Bitmap smethod_9()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("ch", Class131.cultureInfo_0));
	}

	// Token: 0x06000E45 RID: 3653 RVA: 0x000086EE File Offset: 0x000068EE
	internal static Bitmap smethod_10()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("cog", Class131.cultureInfo_0));
	}

	// Token: 0x06000E46 RID: 3654 RVA: 0x0000870E File Offset: 0x0000690E
	internal static Bitmap smethod_11()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("connections", Class131.cultureInfo_0));
	}

	// Token: 0x06000E47 RID: 3655 RVA: 0x0000872E File Offset: 0x0000692E
	internal static byte[] smethod_12()
	{
		return (byte[])RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("dl", Class131.cultureInfo_0));
	}

	// Token: 0x06000E48 RID: 3656 RVA: 0x0000874E File Offset: 0x0000694E
	internal static Bitmap smethod_13()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("err", Class131.cultureInfo_0));
	}

	// Token: 0x06000E49 RID: 3657 RVA: 0x0000876E File Offset: 0x0000696E
	internal static Bitmap smethod_14()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("ex", Class131.cultureInfo_0));
	}

	// Token: 0x06000E4A RID: 3658 RVA: 0x0000878E File Offset: 0x0000698E
	internal static Bitmap smethod_15()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("eye", Class131.cultureInfo_0));
	}

	// Token: 0x06000E4B RID: 3659 RVA: 0x000087AE File Offset: 0x000069AE
	internal static Bitmap smethod_16()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("ff", Class131.cultureInfo_0));
	}

	// Token: 0x06000E4C RID: 3660 RVA: 0x000087CE File Offset: 0x000069CE
	internal static Bitmap smethod_17()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("help", Class131.cultureInfo_0));
	}

	// Token: 0x06000E4D RID: 3661 RVA: 0x000087EE File Offset: 0x000069EE
	internal static Bitmap smethod_18()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("hvnc", Class131.cultureInfo_0));
	}

	// Token: 0x06000E4E RID: 3662 RVA: 0x0000880E File Offset: 0x00006A0E
	internal static Bitmap smethod_19()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("icon-home-gr", Class131.cultureInfo_0));
	}

	// Token: 0x06000E4F RID: 3663 RVA: 0x0000882E File Offset: 0x00006A2E
	internal static Bitmap smethod_20()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("icon-home-gr1", Class131.cultureInfo_0));
	}

	// Token: 0x06000E50 RID: 3664 RVA: 0x0000884E File Offset: 0x00006A4E
	internal static Bitmap smethod_21()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("iconfinder_go-next_118773(2)", Class131.cultureInfo_0));
	}

	// Token: 0x06000E51 RID: 3665 RVA: 0x0000886E File Offset: 0x00006A6E
	internal static Bitmap smethod_22()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("iconfinder_go-previous_118774(2)", Class131.cultureInfo_0));
	}

	// Token: 0x06000E52 RID: 3666 RVA: 0x0000888E File Offset: 0x00006A8E
	internal static Bitmap smethod_23()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("ie", Class131.cultureInfo_0));
	}

	// Token: 0x06000E53 RID: 3667 RVA: 0x000088AE File Offset: 0x00006AAE
	internal static Bitmap smethod_24()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("information", Class131.cultureInfo_0));
	}

	// Token: 0x06000E54 RID: 3668 RVA: 0x000088CE File Offset: 0x00006ACE
	internal static Bitmap smethod_25()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("key", Class131.cultureInfo_0));
	}

	// Token: 0x06000E55 RID: 3669 RVA: 0x000088EE File Offset: 0x00006AEE
	internal static Bitmap smethod_26()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("keyboard", Class131.cultureInfo_0));
	}

	// Token: 0x06000E56 RID: 3670 RVA: 0x0000890E File Offset: 0x00006B0E
	internal static Bitmap smethod_27()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("left-arrow", Class131.cultureInfo_0));
	}

	// Token: 0x06000E57 RID: 3671 RVA: 0x0000892E File Offset: 0x00006B2E
	internal static Bitmap smethod_28()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("loading", Class131.cultureInfo_0));
	}

	// Token: 0x06000E58 RID: 3672 RVA: 0x0000894E File Offset: 0x00006B4E
	internal static Bitmap smethod_29()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("lock", Class131.cultureInfo_0));
	}

	// Token: 0x06000E59 RID: 3673 RVA: 0x0000896E File Offset: 0x00006B6E
	internal static Bitmap smethod_30()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("logo", Class131.cultureInfo_0));
	}

	// Token: 0x06000E5A RID: 3674 RVA: 0x0000898E File Offset: 0x00006B8E
	internal static Bitmap smethod_31()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("monitor", Class131.cultureInfo_0));
	}

	// Token: 0x06000E5B RID: 3675 RVA: 0x000089AE File Offset: 0x00006BAE
	internal static Bitmap smethod_32()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("page_white_copy", Class131.cultureInfo_0));
	}

	// Token: 0x06000E5C RID: 3676 RVA: 0x000089CE File Offset: 0x00006BCE
	internal static Bitmap smethod_33()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("page_white_copy1", Class131.cultureInfo_0));
	}

	// Token: 0x06000E5D RID: 3677 RVA: 0x000089EE File Offset: 0x00006BEE
	internal static Bitmap smethod_34()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("png-transparent-error-icon-attention-angle-triangle-logo", Class131.cultureInfo_0));
	}

	// Token: 0x06000E5E RID: 3678 RVA: 0x00008A0E File Offset: 0x00006C0E
	internal static Bitmap smethod_35()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("poweroff", Class131.cultureInfo_0));
	}

	// Token: 0x06000E5F RID: 3679 RVA: 0x00008A2E File Offset: 0x00006C2E
	internal static Bitmap smethod_36()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("poweroff1", Class131.cultureInfo_0));
	}

	// Token: 0x06000E60 RID: 3680 RVA: 0x00008A4E File Offset: 0x00006C4E
	internal static Bitmap smethod_37()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("previous", Class131.cultureInfo_0));
	}

	// Token: 0x06000E61 RID: 3681 RVA: 0x00008A6E File Offset: 0x00006C6E
	internal static Bitmap smethod_38()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("processes", Class131.cultureInfo_0));
	}

	// Token: 0x06000E62 RID: 3682 RVA: 0x00008A8E File Offset: 0x00006C8E
	internal static Bitmap smethod_39()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("refresh", Class131.cultureInfo_0));
	}

	// Token: 0x06000E63 RID: 3683 RVA: 0x00008AAE File Offset: 0x00006CAE
	internal static Bitmap smethod_40()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("refresh1", Class131.cultureInfo_0));
	}

	// Token: 0x06000E64 RID: 3684 RVA: 0x00008ACE File Offset: 0x00006CCE
	internal static Bitmap smethod_41()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("regedit", Class131.cultureInfo_0));
	}

	// Token: 0x06000E65 RID: 3685 RVA: 0x00008AEE File Offset: 0x00006CEE
	internal static Bitmap smethod_42()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("registry", Class131.cultureInfo_0));
	}

	// Token: 0x06000E66 RID: 3686 RVA: 0x00008B0E File Offset: 0x00006D0E
	internal static Bitmap smethod_43()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("right-arrow", Class131.cultureInfo_0));
	}

	// Token: 0x06000E67 RID: 3687 RVA: 0x00008B2E File Offset: 0x00006D2E
	internal static Bitmap smethod_44()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("rsz_1refresh", Class131.cultureInfo_0));
	}

	// Token: 0x06000E68 RID: 3688 RVA: 0x00008B4E File Offset: 0x00006D4E
	internal static Bitmap smethod_45()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("rsz_refresh-png-image-24498", Class131.cultureInfo_0));
	}

	// Token: 0x06000E69 RID: 3689 RVA: 0x00008B6E File Offset: 0x00006D6E
	internal static Bitmap smethod_46()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("run", Class131.cultureInfo_0));
	}

	// Token: 0x06000E6A RID: 3690 RVA: 0x00008B8E File Offset: 0x00006D8E
	internal static Bitmap smethod_47()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("shell", Class131.cultureInfo_0));
	}

	// Token: 0x06000E6B RID: 3691 RVA: 0x00008BAE File Offset: 0x00006DAE
	internal static Bitmap smethod_48()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("sound", Class131.cultureInfo_0));
	}

	// Token: 0x06000E6C RID: 3692 RVA: 0x00008BCE File Offset: 0x00006DCE
	internal static Bitmap smethod_49()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("ssl", Class131.cultureInfo_0));
	}

	// Token: 0x06000E6D RID: 3693 RVA: 0x00008BEE File Offset: 0x00006DEE
	internal static Bitmap smethod_50()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("tb", Class131.cultureInfo_0));
	}

	// Token: 0x06000E6E RID: 3694 RVA: 0x00008C0E File Offset: 0x00006E0E
	internal static Bitmap smethod_51()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("tor", Class131.cultureInfo_0));
	}

	// Token: 0x06000E6F RID: 3695 RVA: 0x00008C2E File Offset: 0x00006E2E
	internal static Bitmap smethod_52()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("unlock", Class131.cultureInfo_0));
	}

	// Token: 0x06000E70 RID: 3696 RVA: 0x00008C4E File Offset: 0x00006E4E
	internal static Bitmap smethod_53()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("update", Class131.cultureInfo_0));
	}

	// Token: 0x06000E71 RID: 3697 RVA: 0x00008C6E File Offset: 0x00006E6E
	internal static Bitmap smethod_54()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("webcam", Class131.cultureInfo_0));
	}

	// Token: 0x06000E72 RID: 3698 RVA: 0x00008C8E File Offset: 0x00006E8E
	internal static Bitmap smethod_55()
	{
		return (Bitmap)RuntimeHelpers.GetObjectValue(Class131.smethod_0().GetObject("windows", Class131.cultureInfo_0));
	}

	// Token: 0x040005AF RID: 1455
	private static ResourceManager resourceManager_0;

	// Token: 0x040005B0 RID: 1456
	private static CultureInfo cultureInfo_0;
}
