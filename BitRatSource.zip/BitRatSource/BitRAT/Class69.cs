﻿using System;

// Token: 0x02000078 RID: 120
internal static class Class69
{
	// Token: 0x060003D5 RID: 981 RVA: 0x000047BA File Offset: 0x000029BA
	public static Type smethod_0(Type type_0)
	{
		if (!type_0.IsByRef && !type_0.IsArray && !type_0.IsPointer)
		{
			return type_0;
		}
		return Class69.smethod_0(type_0.GetElementType());
	}

	// Token: 0x060003D6 RID: 982 RVA: 0x000047E1 File Offset: 0x000029E1
	public static Type smethod_1(Type type_0)
	{
		if (type_0.HasElementType && !type_0.IsArray)
		{
			type_0 = type_0.GetElementType();
		}
		return type_0;
	}

	// Token: 0x060003D7 RID: 983 RVA: 0x00020B34 File Offset: 0x0001ED34
	public static Class20<Struct17> smethod_2(Type type_0)
	{
		Class20<Struct17> @class = new Class20<Struct17>();
		Type type = type_0;
		for (;;)
		{
			if (type.IsArray)
			{
				@class.method_7(new Struct17
				{
					int_0 = 0,
					int_1 = type.GetArrayRank()
				});
			}
			else if (type.IsByRef)
			{
				@class.method_7(new Struct17
				{
					int_0 = 2
				});
			}
			else
			{
				if (!type.IsPointer)
				{
					break;
				}
				@class.method_7(new Struct17
				{
					int_0 = 1
				});
			}
			type = type.GetElementType();
		}
		return @class;
	}

	// Token: 0x060003D8 RID: 984 RVA: 0x00020BC8 File Offset: 0x0001EDC8
	public static Class20<Struct17> smethod_3(string string_0)
	{
		string text = string_0;
		Class20<Struct17> @class = new Class20<Struct17>();
		for (;;)
		{
			if (text.EndsWith("&", StringComparison.Ordinal))
			{
				@class.method_7(new Struct17
				{
					int_0 = 2
				});
				text = text.Substring(0, text.Length - 1);
			}
			else if (text.EndsWith("*", StringComparison.Ordinal))
			{
				@class.method_7(new Struct17
				{
					int_0 = 1
				});
				text = text.Substring(0, text.Length - 1);
			}
			else if (text.EndsWith("[]", StringComparison.Ordinal))
			{
				@class.method_7(new Struct17
				{
					int_0 = 0,
					int_1 = 1
				});
				text = text.Substring(0, text.Length - 2);
			}
			else
			{
				if (!text.EndsWith(",]", StringComparison.Ordinal))
				{
					return @class;
				}
				int num = 1;
				int num2 = -1;
				for (int i = text.Length - 2; i >= 0; i--)
				{
					char c = text[i];
					if (c != ',')
					{
						if (c != '[')
						{
							goto Block_5;
						}
						num2 = i;
						i = -1;
					}
					else
					{
						num++;
					}
				}
				if (num2 < 0)
				{
					goto IL_145;
				}
				text = text.Substring(0, num2);
				@class.method_7(new Struct17
				{
					int_0 = 0,
					int_1 = num
				});
			}
		}
		Block_5:
		throw new InvalidOperationException("VM-3012");
		IL_145:
		throw new InvalidOperationException("VM-3014");
	}

	// Token: 0x060003D9 RID: 985 RVA: 0x00020D34 File Offset: 0x0001EF34
	public static Type smethod_4(Type type_0, Class20<Struct17> class20_0)
	{
		Type type = type_0;
		while (class20_0.Count > 0)
		{
			Struct17 @struct = class20_0.method_6();
			switch (@struct.int_0)
			{
			case 0:
				if (@struct.int_1 == 1)
				{
					type = type.MakeArrayType();
				}
				else
				{
					type = type.MakeArrayType(@struct.int_1);
				}
				break;
			case 1:
				type = type.MakePointerType();
				break;
			case 2:
				type = type.MakeByRefType();
				break;
			}
		}
		return type;
	}
}
