﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Text;

// Token: 0x0200007F RID: 127
internal static class Class72
{
	// Token: 0x060003F9 RID: 1017 RVA: 0x00020F70 File Offset: 0x0001F170
	internal static long smethod_0()
	{
		if (Assembly.GetCallingAssembly() == typeof(Class72).Assembly && Class72.smethod_2())
		{
			long result;
			lock (Class72.class74_0)
			{
				long num = Class72.class74_0.method_0();
				if (num == 0L)
				{
					Assembly executingAssembly = Assembly.GetExecutingAssembly();
					List<byte> list = new List<byte>();
					AssemblyName assemblyName;
					try
					{
						assemblyName = executingAssembly.GetName();
					}
					catch
					{
						assemblyName = new AssemblyName(executingAssembly.FullName);
					}
					byte[] array = assemblyName.GetPublicKeyToken();
					if (array != null && array.Length == 0)
					{
						array = null;
					}
					if (array != null)
					{
						list.AddRange(array);
					}
					list.AddRange(Encoding.Unicode.GetBytes(assemblyName.Name));
					int num2 = Class72.smethod_4(typeof(Class72));
					int num3 = Class72.Class76.smethod_0();
					list.Add((byte)(num2 >> 16));
					list.Add((byte)(num3 >> 8));
					list.Add((byte)(num2 >> 8));
					list.Add((byte)(num3 >> 24));
					list.Add((byte)num2);
					list.Add((byte)(num3 >> 16));
					list.Add((byte)(num2 >> 24));
					list.Add((byte)num3);
					int count = list.Count;
					ulong num4 = 0UL;
					for (int num5 = 0; num5 != count; num5++)
					{
						num4 += (ulong)list[num5];
						num4 += num4 << 20;
						num4 ^= num4 >> 12;
						list[num5] = 0;
					}
					num4 += num4 << 6;
					num4 ^= num4 >> 22;
					num4 += num4 << 30;
					num = (long)num4;
					num ^= -5127325363398215413L;
					Class72.class74_0.method_1(num);
				}
				result = num;
			}
			return result;
		}
		return 0L;
	}

	// Token: 0x060003FA RID: 1018 RVA: 0x00021154 File Offset: 0x0001F354
	internal static void smethod_1(byte[] byte_0)
	{
		if (Assembly.GetCallingAssembly() == typeof(Class72).Assembly && Class72.smethod_2())
		{
			long num = Class72.smethod_0();
			byte[] array = new byte[]
			{
				(byte)num,
				(byte)(num >> 40),
				(byte)(num >> 56),
				(byte)(num >> 48),
				(byte)(num >> 32),
				(byte)(num >> 24),
				(byte)(num >> 16),
				(byte)(num >> 8)
			};
			int num2 = byte_0.Length;
			for (int num3 = 0; num3 != num2; num3++)
			{
				int num4 = num3;
				byte_0[num4] ^= (byte)((int)array[num3 & 7] + num3);
			}
			return;
		}
	}

	// Token: 0x060003FB RID: 1019 RVA: 0x00004901 File Offset: 0x00002B01
	private static bool smethod_2()
	{
		return Class72.smethod_3();
	}

	// Token: 0x060003FC RID: 1020 RVA: 0x000211F4 File Offset: 0x0001F3F4
	private static bool smethod_3()
	{
		StackTrace stackTrace = new StackTrace();
		StackFrame frame = stackTrace.GetFrame(3);
		MethodBase methodBase = (frame == null) ? null : frame.GetMethod();
		Type type = (methodBase == null) ? null : methodBase.DeclaringType;
		return type != typeof(RuntimeMethodHandle) && type != null && type.Assembly == typeof(Class72).Assembly;
	}

	// Token: 0x060003FD RID: 1021 RVA: 0x0000490D File Offset: 0x00002B0D
	private static int smethod_4(Type type_0)
	{
		return type_0.MetadataToken;
	}

	// Token: 0x040001C4 RID: 452
	private static Class72.Class74 class74_0 = new Class72.Class74();

	// Token: 0x02000080 RID: 128
	private sealed class Class73
	{
		// Token: 0x060003FF RID: 1023 RVA: 0x00021258 File Offset: 0x0001F458
		internal static int smethod_0()
		{
			return Class72.Class75.smethod_2(Class72.Class75.smethod_0(Class72.Class80.smethod_0() ^ 527758446, Class72.smethod_4(typeof(Class72.Class77))), Class72.Class75.smethod_1(Class72.smethod_4(typeof(Class72.Class76)) ^ Class72.smethod_4(typeof(Class72.Class78)), -1434132906));
		}
	}

	// Token: 0x02000081 RID: 129
	private sealed class Class74
	{
		// Token: 0x06000400 RID: 1024 RVA: 0x00004915 File Offset: 0x00002B15
		internal Class74()
		{
			this.method_1(0L);
		}

		// Token: 0x06000401 RID: 1025 RVA: 0x000212B4 File Offset: 0x0001F4B4
		internal long method_0()
		{
			if (Assembly.GetCallingAssembly() != typeof(Class72.Class74).Assembly)
			{
				return 2918384L;
			}
			if (!Class72.smethod_2())
			{
				return 2918384L;
			}
			int[] array = new int[]
			{
				0,
				0,
				0,
				1375320513
			};
			array[1] = 1820062432;
			array[2] = -1768535364;
			array[0] = -799872360;
			int num = this.int_0;
			int num2 = this.int_1;
			int num3 = -1640531527;
			int num4 = -957401312;
			for (int num5 = 0; num5 != 32; num5++)
			{
				num2 -= ((num << 4 ^ num >> 5) + num ^ num4 + array[num4 >> 11 & 3]);
				num4 -= num3;
				num -= ((num2 << 4 ^ num2 >> 5) + num2 ^ num4 + array[num4 & 3]);
			}
			for (int num6 = 0; num6 != 4; num6++)
			{
				array[num6] = 0;
			}
			ulong num7 = (ulong)((ulong)((long)num2) << 32);
			return (long)(num7 | (ulong)num);
		}

		// Token: 0x06000402 RID: 1026 RVA: 0x0002139C File Offset: 0x0001F59C
		internal void method_1(long long_0)
		{
			if (Assembly.GetCallingAssembly() != typeof(Class72.Class74).Assembly)
			{
				return;
			}
			if (!Class72.smethod_2())
			{
				return;
			}
			int[] array = new int[4];
			array[1] = 1820062432;
			array[0] = -799872360;
			array[2] = -1768535364;
			array[3] = 1375320513;
			int num = -1640531527;
			int num2 = (int)long_0;
			int num3 = (int)(long_0 >> 32);
			int num4 = 0;
			for (int num5 = 0; num5 != 32; num5++)
			{
				num2 += ((num3 << 4 ^ num3 >> 5) + num3 ^ num4 + array[num4 & 3]);
				num4 += num;
				num3 += ((num2 << 4 ^ num2 >> 5) + num2 ^ num4 + array[num4 >> 11 & 3]);
			}
			for (int num6 = 0; num6 != 4; num6++)
			{
				array[num6] = 0;
			}
			this.int_0 = num2;
			this.int_1 = num3;
		}

		// Token: 0x040001C5 RID: 453
		private int int_0;

		// Token: 0x040001C6 RID: 454
		private int int_1;
	}

	// Token: 0x02000082 RID: 130
	private static class Class75
	{
		// Token: 0x06000403 RID: 1027 RVA: 0x0000492C File Offset: 0x00002B2C
		internal static int smethod_0(int int_0, int int_1)
		{
			return int_0 ^ int_1 - 1317954024;
		}

		// Token: 0x06000404 RID: 1028 RVA: 0x00004937 File Offset: 0x00002B37
		internal static int smethod_1(int int_0, int int_1)
		{
			return int_0 - -695884082 ^ int_1 + -2101103186;
		}

		// Token: 0x06000405 RID: 1029 RVA: 0x00004948 File Offset: 0x00002B48
		internal static int smethod_2(int int_0, int int_1)
		{
			return int_0 ^ (int_1 - -378159800 ^ int_0 - int_1);
		}
	}

	// Token: 0x02000083 RID: 131
	private sealed class Class76
	{
		// Token: 0x06000407 RID: 1031 RVA: 0x00021468 File Offset: 0x0001F668
		internal static int smethod_0()
		{
			return Class72.Class75.smethod_2(Class72.Class75.smethod_1(Class72.smethod_4(typeof(Class72.Class80)), Class72.Class75.smethod_2(Class72.smethod_4(typeof(Class72.Class76)), Class72.smethod_4(typeof(Class72.Class79)))), Class72.Class78.smethod_0());
		}
	}

	// Token: 0x02000084 RID: 132
	private sealed class Class77
	{
		// Token: 0x06000409 RID: 1033 RVA: 0x000214B8 File Offset: 0x0001F6B8
		internal static int smethod_0()
		{
			return Class72.Class75.smethod_2(Class72.smethod_4(typeof(Class72.Class77)), Class72.Class75.smethod_0(Class72.smethod_4(typeof(Class72.Class76)), Class72.Class75.smethod_1(Class72.smethod_4(typeof(Class72.Class80)), Class72.Class75.smethod_2(Class72.smethod_4(typeof(Class72.Class73)), Class72.Class75.smethod_0(Class72.smethod_4(typeof(Class72.Class79)), Class72.smethod_4(typeof(Class72.Class78)))))));
		}
	}

	// Token: 0x02000085 RID: 133
	private sealed class Class78
	{
		// Token: 0x0600040B RID: 1035 RVA: 0x00021538 File Offset: 0x0001F738
		internal static int smethod_0()
		{
			return Class72.Class75.smethod_0(Class72.smethod_4(typeof(Class72.Class78)), Class72.Class75.smethod_2(Class72.Class75.smethod_1(Class72.smethod_4(typeof(Class72.Class79)), Class72.smethod_4(typeof(Class72.Class76))), Class72.Class75.smethod_2(Class72.smethod_4(typeof(Class72.Class73)) ^ 190156808, Class72.Class79.smethod_0())));
		}
	}

	// Token: 0x02000086 RID: 134
	private sealed class Class79
	{
		// Token: 0x0600040D RID: 1037 RVA: 0x00004957 File Offset: 0x00002B57
		internal static int smethod_0()
		{
			return Class72.Class75.smethod_1(Class72.Class75.smethod_1(Class72.Class73.smethod_0(), Class72.Class75.smethod_0(Class72.smethod_4(typeof(Class72.Class79)), Class72.Class80.smethod_0())), Class72.smethod_4(typeof(Class72.Class78)));
		}
	}

	// Token: 0x02000087 RID: 135
	private sealed class Class80
	{
		// Token: 0x0600040F RID: 1039 RVA: 0x000215A0 File Offset: 0x0001F7A0
		internal static int smethod_0()
		{
			return Class72.Class75.smethod_0(Class72.smethod_4(typeof(Class72.Class73)), Class72.smethod_4(typeof(Class72.Class77)) ^ Class72.Class75.smethod_1(Class72.smethod_4(typeof(Class72.Class80)), Class72.Class75.smethod_2(Class72.smethod_4(typeof(Class72.Class78)), Class72.Class77.smethod_0())));
		}
	}
}
