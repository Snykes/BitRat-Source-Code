﻿using System;

// Token: 0x02000075 RID: 117
internal enum Enum2
{

}
