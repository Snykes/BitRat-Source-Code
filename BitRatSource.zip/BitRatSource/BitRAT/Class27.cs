﻿using System;

// Token: 0x0200002D RID: 45
internal sealed class Class27
{
	// Token: 0x06000244 RID: 580 RVA: 0x00003C5C File Offset: 0x00001E5C
	public int method_0()
	{
		return this.int_0;
	}

	// Token: 0x06000245 RID: 581 RVA: 0x00003C64 File Offset: 0x00001E64
	public void method_1(int int_2)
	{
		this.int_0 = int_2;
	}

	// Token: 0x06000246 RID: 582 RVA: 0x00003C6D File Offset: 0x00001E6D
	public int method_2()
	{
		return this.int_1;
	}

	// Token: 0x06000247 RID: 583 RVA: 0x00003C75 File Offset: 0x00001E75
	public void method_3(int int_2)
	{
		this.int_1 = int_2;
	}

	// Token: 0x06000248 RID: 584 RVA: 0x00003C7E File Offset: 0x00001E7E
	public uint method_4()
	{
		return this.uint_0;
	}

	// Token: 0x06000249 RID: 585 RVA: 0x00003C86 File Offset: 0x00001E86
	public void method_5(uint uint_4)
	{
		this.uint_0 = uint_4;
	}

	// Token: 0x0600024A RID: 586 RVA: 0x00003C8F File Offset: 0x00001E8F
	public uint method_6()
	{
		return this.uint_1;
	}

	// Token: 0x0600024B RID: 587 RVA: 0x00003C97 File Offset: 0x00001E97
	public void method_7(uint uint_4)
	{
		this.uint_1 = uint_4;
	}

	// Token: 0x0600024C RID: 588 RVA: 0x00003CA0 File Offset: 0x00001EA0
	public uint method_8()
	{
		return this.uint_2;
	}

	// Token: 0x0600024D RID: 589 RVA: 0x00003CA8 File Offset: 0x00001EA8
	public void method_9(uint uint_4)
	{
		this.uint_2 = uint_4;
	}

	// Token: 0x0600024E RID: 590 RVA: 0x00003CB1 File Offset: 0x00001EB1
	public uint method_10()
	{
		return this.uint_3;
	}

	// Token: 0x0600024F RID: 591 RVA: 0x00003CB9 File Offset: 0x00001EB9
	public void method_11(uint uint_4)
	{
		this.uint_3 = uint_4;
	}

	// Token: 0x04000146 RID: 326
	private int int_0;

	// Token: 0x04000147 RID: 327
	private int int_1;

	// Token: 0x04000148 RID: 328
	private uint uint_0;

	// Token: 0x04000149 RID: 329
	private uint uint_1;

	// Token: 0x0400014A RID: 330
	private uint uint_2;

	// Token: 0x0400014B RID: 331
	private uint uint_3;
}
