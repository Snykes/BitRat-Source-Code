﻿using System;

// Token: 0x0200006A RID: 106
internal sealed class Class63
{
	// Token: 0x06000388 RID: 904 RVA: 0x00002B97 File Offset: 0x00000D97
	private Class63()
	{
	}

	// Token: 0x06000389 RID: 905 RVA: 0x000044B4 File Offset: 0x000026B4
	internal static void smethod_0(uint uint_0, byte[] byte_0, int int_0)
	{
		byte_0[int_0] = (byte)uint_0;
		byte_0[++int_0] = (byte)(uint_0 >> 8);
		byte_0[++int_0] = (byte)(uint_0 >> 16);
		byte_0[++int_0] = (byte)(uint_0 >> 24);
	}

	// Token: 0x0600038A RID: 906 RVA: 0x000044E7 File Offset: 0x000026E7
	internal static uint smethod_1(byte[] byte_0, int int_0)
	{
		return (uint)((int)byte_0[int_0] | (int)byte_0[++int_0] << 8 | (int)byte_0[++int_0] << 16 | (int)byte_0[++int_0] << 24);
	}
}
