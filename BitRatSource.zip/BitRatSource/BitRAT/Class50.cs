﻿using System;

// Token: 0x0200004F RID: 79
internal abstract class Class50 : IDisposable
{
	// Token: 0x0600030F RID: 783
	public abstract bool vmethod_0();

	// Token: 0x06000310 RID: 784
	public abstract bool vmethod_1();

	// Token: 0x06000311 RID: 785
	public abstract bool vmethod_2();

	// Token: 0x06000312 RID: 786
	public abstract long vmethod_3();

	// Token: 0x06000313 RID: 787
	public abstract long vmethod_4();

	// Token: 0x06000314 RID: 788
	public abstract void vmethod_5(long long_0);

	// Token: 0x06000315 RID: 789 RVA: 0x00004188 File Offset: 0x00002388
	public virtual void vmethod_6()
	{
		this.vmethod_7(true);
		GC.SuppressFinalize(this);
	}

	// Token: 0x06000316 RID: 790 RVA: 0x00004197 File Offset: 0x00002397
	public void Dispose()
	{
		this.vmethod_6();
	}

	// Token: 0x06000317 RID: 791 RVA: 0x00002F44 File Offset: 0x00001144
	protected virtual void vmethod_7(bool bool_0)
	{
	}

	// Token: 0x06000318 RID: 792
	public abstract void vmethod_8();

	// Token: 0x06000319 RID: 793
	public abstract long vmethod_9(long long_0, int int_0);

	// Token: 0x0600031A RID: 794
	public abstract void vmethod_10(long long_0);

	// Token: 0x0600031B RID: 795
	public abstract int vmethod_11(byte[] byte_0, int int_0, int int_1);

	// Token: 0x0600031C RID: 796 RVA: 0x0001F5F0 File Offset: 0x0001D7F0
	public virtual int vmethod_12()
	{
		byte[] array = new byte[1];
		if (this.vmethod_11(array, 0, 1) == 0)
		{
			return -1;
		}
		return (int)array[0];
	}

	// Token: 0x0600031D RID: 797
	public abstract void vmethod_13(byte[] byte_0, int int_0, int int_1);

	// Token: 0x0600031E RID: 798 RVA: 0x0001F614 File Offset: 0x0001D814
	public virtual void vmethod_14(byte byte_0)
	{
		this.vmethod_13(new byte[]
		{
			byte_0
		}, 0, 1);
	}
}
