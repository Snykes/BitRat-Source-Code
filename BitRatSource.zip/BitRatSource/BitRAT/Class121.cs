﻿using System;

// Token: 0x02000097 RID: 151
internal sealed class Class121 : Class94
{
	// Token: 0x0600049F RID: 1183 RVA: 0x00004E5C File Offset: 0x0000305C
	public byte method_2()
	{
		return this.byte_0;
	}

	// Token: 0x060004A0 RID: 1184 RVA: 0x00004E64 File Offset: 0x00003064
	public void method_3(byte byte_1)
	{
		this.byte_0 = byte_1;
	}

	// Token: 0x060004A1 RID: 1185 RVA: 0x00004E6D File Offset: 0x0000306D
	public override Class94 vmethod_4()
	{
		Class121 @class = new Class121();
		@class.method_3(this.byte_0);
		@class.method_1(base.method_0());
		return @class;
	}

	// Token: 0x060004A2 RID: 1186 RVA: 0x00004E8C File Offset: 0x0000308C
	public override object vmethod_0()
	{
		return this.method_2();
	}

	// Token: 0x060004A3 RID: 1187 RVA: 0x00022AF0 File Offset: 0x00020CF0
	public override void vmethod_1(object object_0)
	{
		if (object_0 is short)
		{
			this.method_3((byte)((short)object_0));
			return;
		}
		if (object_0 is int)
		{
			this.method_3((byte)((int)object_0));
			return;
		}
		if (object_0 is long)
		{
			this.method_3((byte)((long)object_0));
			return;
		}
		if (object_0 is ushort)
		{
			this.method_3((byte)((ushort)object_0));
			return;
		}
		if (object_0 is uint)
		{
			this.method_3((byte)((uint)object_0));
			return;
		}
		if (object_0 is ulong)
		{
			this.method_3((byte)((ulong)object_0));
			return;
		}
		if (object_0 is float)
		{
			this.method_3((byte)((float)object_0));
			return;
		}
		if (object_0 is double)
		{
			this.method_3((byte)((double)object_0));
			return;
		}
		this.method_3(Convert.ToByte(object_0));
	}

	// Token: 0x060004A4 RID: 1188 RVA: 0x00004E99 File Offset: 0x00003099
	public override int vmethod_2()
	{
		return 22;
	}

	// Token: 0x060004A5 RID: 1189 RVA: 0x00022BBC File Offset: 0x00020DBC
	public override Class94 vmethod_3(Class94 class94_0)
	{
		base.method_1(class94_0.method_0());
		switch (class94_0.vmethod_2())
		{
		case 0:
			this.method_3((byte)((Class119)class94_0).method_2());
			return this;
		case 2:
			this.method_3(Convert.ToByte(((Class103)class94_0).method_2()));
			return this;
		case 4:
			this.method_3(Convert.ToByte(((Class102)class94_0).method_2()));
			return this;
		case 7:
			this.method_3((byte)((Class118)class94_0).method_2());
			return this;
		case 8:
			this.method_3((byte)((uint)((Class100)class94_0).method_2()));
			return this;
		case 9:
			this.method_3((byte)((Class115)class94_0).method_2());
			return this;
		case 10:
			this.method_3((byte)((Class114)class94_0).method_2());
			return this;
		case 11:
			this.method_3((byte)((Class99)class94_0).method_2());
			return this;
		case 14:
			this.method_3((byte)((int)((Class105)class94_0).method_2()));
			return this;
		case 15:
			this.method_3((byte)((Class101)class94_0).method_2());
			return this;
		case 17:
			this.method_3((byte)((Class117)class94_0).method_2());
			return this;
		case 19:
			this.method_3((byte)((Class120)class94_0).method_2());
			return this;
		case 21:
			this.method_3((byte)((Class104)class94_0).method_2());
			return this;
		case 22:
			this.method_3(((Class121)class94_0).method_2());
			return this;
		case 24:
			this.method_3(Convert.ToByte(((Class98)class94_0).method_2()));
			return this;
		}
		throw new ArgumentOutOfRangeException();
	}

	// Token: 0x040001E5 RID: 485
	private byte byte_0;
}
