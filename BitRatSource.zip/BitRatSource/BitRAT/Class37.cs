﻿using System;

// Token: 0x02000069 RID: 105
internal sealed class Class37 : Class34
{
	// Token: 0x06000383 RID: 899 RVA: 0x0000448F File Offset: 0x0000268F
	public int method_0()
	{
		return this.int_0;
	}

	// Token: 0x06000384 RID: 900 RVA: 0x00004497 File Offset: 0x00002697
	public void method_1(int int_2)
	{
		this.int_0 = int_2;
	}

	// Token: 0x06000385 RID: 901 RVA: 0x000044A0 File Offset: 0x000026A0
	public int method_2()
	{
		return this.int_1;
	}

	// Token: 0x06000386 RID: 902 RVA: 0x000044A8 File Offset: 0x000026A8
	public void method_3(int int_2)
	{
		this.int_1 = int_2;
	}

	// Token: 0x06000387 RID: 903 RVA: 0x000044B1 File Offset: 0x000026B1
	public override byte vmethod_0()
	{
		return 3;
	}

	// Token: 0x040001A9 RID: 425
	private int int_0;

	// Token: 0x040001AA RID: 426
	private int int_1;
}
