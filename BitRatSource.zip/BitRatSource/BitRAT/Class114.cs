﻿using System;

// Token: 0x02000071 RID: 113
internal sealed class Class114 : Class94
{
	// Token: 0x060003B2 RID: 946 RVA: 0x00004678 File Offset: 0x00002878
	public float method_2()
	{
		return this.float_0;
	}

	// Token: 0x060003B3 RID: 947 RVA: 0x00004680 File Offset: 0x00002880
	public void method_3(float float_1)
	{
		this.float_0 = float_1;
	}

	// Token: 0x060003B4 RID: 948 RVA: 0x00004689 File Offset: 0x00002889
	public override object vmethod_0()
	{
		return this.method_2();
	}

	// Token: 0x060003B5 RID: 949 RVA: 0x00004696 File Offset: 0x00002896
	public override void vmethod_1(object object_0)
	{
		this.method_3(Convert.ToSingle(object_0));
	}

	// Token: 0x060003B6 RID: 950 RVA: 0x000046A4 File Offset: 0x000028A4
	public override Class94 vmethod_4()
	{
		Class114 @class = new Class114();
		@class.method_3(this.float_0);
		@class.method_1(base.method_0());
		return @class;
	}

	// Token: 0x060003B7 RID: 951 RVA: 0x000046C3 File Offset: 0x000028C3
	public override int vmethod_2()
	{
		return 10;
	}

	// Token: 0x060003B8 RID: 952 RVA: 0x000204E0 File Offset: 0x0001E6E0
	public override Class94 vmethod_3(Class94 class94_0)
	{
		base.method_1(class94_0.method_0());
		int num = class94_0.vmethod_2();
		if (num != 0)
		{
			switch (num)
			{
			case 4:
				this.method_3((float)((Class102)class94_0).method_2());
				return this;
			case 7:
				this.method_3((float)((Class118)class94_0).method_2());
				return this;
			case 9:
				this.method_3((float)((Class115)class94_0).method_2());
				return this;
			case 10:
				this.method_3(((Class114)class94_0).method_2());
				return this;
			case 11:
				this.method_3((float)((Class99)class94_0).method_2());
				return this;
			case 15:
				this.method_3((float)((Class101)class94_0).method_2());
				return this;
			case 17:
				this.method_3((float)((Class117)class94_0).method_2());
				return this;
			case 19:
				this.method_3(((Class120)class94_0).method_2());
				return this;
			case 21:
				this.method_3(((Class104)class94_0).method_2());
				return this;
			case 22:
				this.method_3((float)((Class121)class94_0).method_2());
				return this;
			case 24:
				this.method_3(Convert.ToSingle(((Class98)class94_0).method_2()));
				return this;
			}
			throw new ArgumentOutOfRangeException();
		}
		this.method_3((float)((Class119)class94_0).method_2());
		return this;
	}

	// Token: 0x040001B1 RID: 433
	private float float_0;
}
