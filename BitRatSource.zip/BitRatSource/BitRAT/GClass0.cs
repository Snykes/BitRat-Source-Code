﻿using System;

// Token: 0x020000A3 RID: 163
public sealed class GClass0
{
}
