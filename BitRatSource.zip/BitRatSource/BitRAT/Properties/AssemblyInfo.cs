﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: SuppressIldasm]
[assembly: ComVisible(false)]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyTrademark("")]
[assembly: Guid("cc2019bc-7e7d-401c-a51c-3d4f40364ecc")]
[assembly: AssemblyProduct("BitRAT")]
[assembly: AssemblyTitle("BitRAT")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyCopyright("Copyright ©  2020")]
