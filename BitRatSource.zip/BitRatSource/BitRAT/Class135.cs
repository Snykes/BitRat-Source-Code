﻿using System;
using System.Diagnostics;
using BitRAT.My;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

// Token: 0x02000140 RID: 320
[DebuggerNonUserCode]
[StandardModule]
[HideModuleName]
internal sealed class Class135
{
	// Token: 0x060011EB RID: 4587 RVA: 0x0000A046 File Offset: 0x00008246
	internal static MySettings smethod_0()
	{
		return MySettings.Default;
	}
}
