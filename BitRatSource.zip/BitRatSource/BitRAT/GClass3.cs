﻿using System;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

// Token: 0x020000E9 RID: 233
public sealed class GClass3 : Label
{
	// Token: 0x06000B72 RID: 2930 RVA: 0x00059474 File Offset: 0x00057674
	public GClass3()
	{
		base.HandleCreated += this.GClass3_HandleCreated;
		this.int_0 = 0;
		this.color_0 = Color.Blue;
		base.SetStyle(ControlStyles.Opaque, true);
		base.SetStyle(ControlStyles.OptimizedDoubleBuffer, false);
		base.SetStyle(ControlStyles.ResizeRedraw, true);
		this.Font = new Font("Microsoft Sans Serif", 28.2f);
	}

	// Token: 0x17000008 RID: 8
	// (get) Token: 0x06000B73 RID: 2931 RVA: 0x000074BB File Offset: 0x000056BB
	protected override CreateParams CreateParams
	{
		get
		{
			CreateParams createParams = base.CreateParams;
			createParams.ExStyle |= 32;
			return createParams;
		}
	}

	// Token: 0x06000B74 RID: 2932 RVA: 0x000074D2 File Offset: 0x000056D2
	public int method_0()
	{
		return this.int_0;
	}

	// Token: 0x06000B75 RID: 2933 RVA: 0x000074DA File Offset: 0x000056DA
	public void method_1(int int_1)
	{
		if (int_1 >= 0 & int_1 <= 255)
		{
			this.int_0 = int_1;
		}
		base.Invalidate();
	}

	// Token: 0x06000B76 RID: 2934 RVA: 0x000594E0 File Offset: 0x000576E0
	protected override void OnPaint(PaintEventArgs e)
	{
		Bitmap bitmap = new Bitmap(base.Width, base.Height);
		Graphics graphics = Graphics.FromImage(bitmap);
		Color backColor = this.color_0;
		if (this.color_0 == Color.Transparent && this.vmethod_0() != null)
		{
			backColor = this.vmethod_0().BackColor;
		}
		PaintEventArgs e2 = new PaintEventArgs(graphics, e.ClipRectangle);
		base.OnPaint(e2);
		checked
		{
			int num = base.Height - 1;
			for (int i = 0; i <= num; i++)
			{
				int num2 = base.Width - 1;
				for (int j = 0; j <= num2; j++)
				{
					Color pixel = bitmap.GetPixel(j, i);
					if (pixel.A != 0)
					{
						bitmap.SetPixel(j, i, Color.FromArgb(this.int_0, pixel));
					}
					else
					{
						bitmap.SetPixel(j, i, Color.FromArgb(255, backColor));
					}
				}
			}
			e.Graphics.DrawImage(bitmap, 0, 0);
		}
	}

	// Token: 0x06000B77 RID: 2935 RVA: 0x000074FE File Offset: 0x000056FE
	private void GClass3_HandleCreated(object sender, EventArgs e)
	{
		this.vmethod_1(base.Parent);
	}

	// Token: 0x06000B78 RID: 2936 RVA: 0x0000750C File Offset: 0x0000570C
	private Control vmethod_0()
	{
		return this.control_0;
	}

	// Token: 0x06000B79 RID: 2937 RVA: 0x00007514 File Offset: 0x00005714
	[MethodImpl(MethodImplOptions.Synchronized)]
	private void vmethod_1(Control control_1)
	{
		this.control_0 = control_1;
	}

	// Token: 0x17000009 RID: 9
	// (get) Token: 0x06000B7A RID: 2938 RVA: 0x0000751D File Offset: 0x0000571D
	// (set) Token: 0x06000B7B RID: 2939 RVA: 0x00007525 File Offset: 0x00005725
	public override Color BackColor
	{
		get
		{
			return this.color_0;
		}
		set
		{
			this.color_0 = value;
			base.Invalidate();
		}
	}

	// Token: 0x04000451 RID: 1105
	private int int_0;

	// Token: 0x04000452 RID: 1106
	private Control control_0;

	// Token: 0x04000453 RID: 1107
	private Color color_0;
}
