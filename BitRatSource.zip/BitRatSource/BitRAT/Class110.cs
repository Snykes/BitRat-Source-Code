﻿using System;

// Token: 0x02000094 RID: 148
internal sealed class Class110 : Class109
{
	// Token: 0x0600047C RID: 1148 RVA: 0x00004D0E File Offset: 0x00002F0E
	public Array method_4()
	{
		return this.array_0;
	}

	// Token: 0x0600047D RID: 1149 RVA: 0x00004D16 File Offset: 0x00002F16
	public void method_5(Array array_1)
	{
		this.array_0 = array_1;
	}

	// Token: 0x0600047E RID: 1150 RVA: 0x00004D1F File Offset: 0x00002F1F
	public long method_6()
	{
		return this.long_0;
	}

	// Token: 0x0600047F RID: 1151 RVA: 0x00004D27 File Offset: 0x00002F27
	public void method_7(long long_1)
	{
		this.long_0 = long_1;
	}

	// Token: 0x06000480 RID: 1152 RVA: 0x00004D30 File Offset: 0x00002F30
	public override object vmethod_5()
	{
		return this.array_0.GetValue(this.long_0);
	}

	// Token: 0x06000481 RID: 1153 RVA: 0x00004D43 File Offset: 0x00002F43
	public override void vmethod_6(object object_0)
	{
		this.array_0.SetValue(object_0, this.long_0);
	}

	// Token: 0x06000482 RID: 1154 RVA: 0x000044B1 File Offset: 0x000026B1
	public override int vmethod_2()
	{
		return 3;
	}

	// Token: 0x06000483 RID: 1155 RVA: 0x000227F0 File Offset: 0x000209F0
	public override Class94 vmethod_3(Class94 class94_0)
	{
		base.method_1(class94_0.method_0());
		int num = class94_0.vmethod_2();
		if (num == 3)
		{
			Class110 @class = (Class110)class94_0;
			this.method_5(@class.method_4());
			this.method_7(@class.method_6());
			base.method_3(@class.method_2());
			return this;
		}
		throw new ArgumentOutOfRangeException();
	}

	// Token: 0x06000484 RID: 1156 RVA: 0x00004D57 File Offset: 0x00002F57
	public override Class94 vmethod_4()
	{
		Class110 @class = new Class110();
		@class.method_5(this.array_0);
		@class.method_7(this.long_0);
		@class.method_3(base.method_2());
		@class.method_1(base.method_0());
		return @class;
	}

	// Token: 0x06000485 RID: 1157 RVA: 0x00022848 File Offset: 0x00020A48
	public override bool vmethod_7(Class109 class109_0)
	{
		Class110 @class = (Class110)class109_0;
		return this.method_6() == @class.method_6() && this.method_4() == @class.method_4();
	}

	// Token: 0x040001DC RID: 476
	private Array array_0;

	// Token: 0x040001DD RID: 477
	private long long_0;
}
