﻿using System;

// Token: 0x0200006B RID: 107
internal sealed class Class64
{
	// Token: 0x040001AB RID: 427
	public Class0 class0_0;
}
