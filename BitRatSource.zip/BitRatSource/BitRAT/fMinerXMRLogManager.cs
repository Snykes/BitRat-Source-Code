﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

// Token: 0x020000FD RID: 253
[DesignerGenerated]
public sealed partial class fMinerXMRLogManager : Form
{
	// Token: 0x06000D30 RID: 3376 RVA: 0x00008004 File Offset: 0x00006204
	public fMinerXMRLogManager()
	{
		base.Load += this.fMinerXMRLogManager_Load;
		base.Closing += this.fMinerXMRLogManager_Closing;
		this.collection_0 = new Collection();
		this.InitializeComponent();
	}

	// Token: 0x06000D33 RID: 3379 RVA: 0x00008041 File Offset: 0x00006241
	internal GClass7 vmethod_0()
	{
		return this.gclass7_0;
	}

	// Token: 0x06000D34 RID: 3380 RVA: 0x00066F50 File Offset: 0x00065150
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_1(GClass7 gclass7_1)
	{
		EventHandler value = new EventHandler(this.method_2);
		MouseEventHandler value2 = new MouseEventHandler(this.method_6);
		EventHandler value3 = new EventHandler(this.method_13);
		KeyEventHandler value4 = new KeyEventHandler(this.method_14);
		GClass7 gclass = this.gclass7_0;
		if (gclass != null)
		{
			gclass.DoubleClick -= value;
			gclass.MouseUp -= value2;
			gclass.SelectedIndexChanged -= value3;
			gclass.KeyDown -= value4;
		}
		this.gclass7_0 = gclass7_1;
		gclass = this.gclass7_0;
		if (gclass != null)
		{
			gclass.DoubleClick += value;
			gclass.MouseUp += value2;
			gclass.SelectedIndexChanged += value3;
			gclass.KeyDown += value4;
		}
	}

	// Token: 0x06000D35 RID: 3381 RVA: 0x00008049 File Offset: 0x00006249
	internal StatusStrip vmethod_2()
	{
		return this.statusStrip_0;
	}

	// Token: 0x06000D36 RID: 3382 RVA: 0x00008051 File Offset: 0x00006251
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_3(StatusStrip statusStrip_1)
	{
		this.statusStrip_0 = statusStrip_1;
	}

	// Token: 0x06000D37 RID: 3383 RVA: 0x0000805A File Offset: 0x0000625A
	internal ToolStripStatusLabel vmethod_4()
	{
		return this.toolStripStatusLabel_0;
	}

	// Token: 0x06000D38 RID: 3384 RVA: 0x00008062 File Offset: 0x00006262
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_5(ToolStripStatusLabel toolStripStatusLabel_3)
	{
		this.toolStripStatusLabel_0 = toolStripStatusLabel_3;
	}

	// Token: 0x06000D39 RID: 3385 RVA: 0x0000806B File Offset: 0x0000626B
	internal ToolStripStatusLabel vmethod_6()
	{
		return this.toolStripStatusLabel_1;
	}

	// Token: 0x06000D3A RID: 3386 RVA: 0x00008073 File Offset: 0x00006273
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_7(ToolStripStatusLabel toolStripStatusLabel_3)
	{
		this.toolStripStatusLabel_1 = toolStripStatusLabel_3;
	}

	// Token: 0x06000D3B RID: 3387 RVA: 0x0000807C File Offset: 0x0000627C
	internal RichTextBox vmethod_8()
	{
		return this.richTextBox_0;
	}

	// Token: 0x06000D3C RID: 3388 RVA: 0x00008084 File Offset: 0x00006284
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_9(RichTextBox richTextBox_1)
	{
		this.richTextBox_0 = richTextBox_1;
	}

	// Token: 0x06000D3D RID: 3389 RVA: 0x0000808D File Offset: 0x0000628D
	internal System.Windows.Forms.Timer vmethod_10()
	{
		return this.timer_0;
	}

	// Token: 0x06000D3E RID: 3390 RVA: 0x00066FE8 File Offset: 0x000651E8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_11(System.Windows.Forms.Timer timer_1)
	{
		EventHandler value = new EventHandler(this.method_3);
		System.Windows.Forms.Timer timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_0 = timer_1;
		timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x06000D3F RID: 3391 RVA: 0x00008095 File Offset: 0x00006295
	internal ToolStripStatusLabel vmethod_12()
	{
		return this.toolStripStatusLabel_2;
	}

	// Token: 0x06000D40 RID: 3392 RVA: 0x0000809D File Offset: 0x0000629D
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_13(ToolStripStatusLabel toolStripStatusLabel_3)
	{
		this.toolStripStatusLabel_2 = toolStripStatusLabel_3;
	}

	// Token: 0x06000D41 RID: 3393 RVA: 0x000080A6 File Offset: 0x000062A6
	internal ContextMenuStrip vmethod_14()
	{
		return this.contextMenuStrip_0;
	}

	// Token: 0x06000D42 RID: 3394 RVA: 0x000080AE File Offset: 0x000062AE
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_15(ContextMenuStrip contextMenuStrip_1)
	{
		this.contextMenuStrip_0 = contextMenuStrip_1;
	}

	// Token: 0x06000D43 RID: 3395 RVA: 0x000080B7 File Offset: 0x000062B7
	internal ToolStripMenuItem vmethod_16()
	{
		return this.toolStripMenuItem_0;
	}

	// Token: 0x06000D44 RID: 3396 RVA: 0x000080BF File Offset: 0x000062BF
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_17(ToolStripMenuItem toolStripMenuItem_6)
	{
		this.toolStripMenuItem_0 = toolStripMenuItem_6;
	}

	// Token: 0x06000D45 RID: 3397 RVA: 0x000080C8 File Offset: 0x000062C8
	internal ToolStripMenuItem vmethod_18()
	{
		return this.toolStripMenuItem_1;
	}

	// Token: 0x06000D46 RID: 3398 RVA: 0x0006702C File Offset: 0x0006522C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_19(ToolStripMenuItem toolStripMenuItem_6)
	{
		EventHandler value = new EventHandler(this.method_9);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_1;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_1 = toolStripMenuItem_6;
		toolStripMenuItem = this.toolStripMenuItem_1;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000D47 RID: 3399 RVA: 0x000080D0 File Offset: 0x000062D0
	internal ToolStripSeparator vmethod_20()
	{
		return this.toolStripSeparator_0;
	}

	// Token: 0x06000D48 RID: 3400 RVA: 0x000080D8 File Offset: 0x000062D8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_21(ToolStripSeparator toolStripSeparator_3)
	{
		this.toolStripSeparator_0 = toolStripSeparator_3;
	}

	// Token: 0x06000D49 RID: 3401 RVA: 0x000080E1 File Offset: 0x000062E1
	internal ToolStripMenuItem vmethod_22()
	{
		return this.toolStripMenuItem_2;
	}

	// Token: 0x06000D4A RID: 3402 RVA: 0x00067070 File Offset: 0x00065270
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_23(ToolStripMenuItem toolStripMenuItem_6)
	{
		EventHandler value = new EventHandler(this.method_10);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_2;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_2 = toolStripMenuItem_6;
		toolStripMenuItem = this.toolStripMenuItem_2;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000D4B RID: 3403 RVA: 0x000080E9 File Offset: 0x000062E9
	internal ToolStripSeparator vmethod_24()
	{
		return this.toolStripSeparator_1;
	}

	// Token: 0x06000D4C RID: 3404 RVA: 0x000080F1 File Offset: 0x000062F1
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_25(ToolStripSeparator toolStripSeparator_3)
	{
		this.toolStripSeparator_1 = toolStripSeparator_3;
	}

	// Token: 0x06000D4D RID: 3405 RVA: 0x000080FA File Offset: 0x000062FA
	internal ToolStripMenuItem vmethod_26()
	{
		return this.toolStripMenuItem_3;
	}

	// Token: 0x06000D4E RID: 3406 RVA: 0x00008102 File Offset: 0x00006302
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_27(ToolStripMenuItem toolStripMenuItem_6)
	{
		this.toolStripMenuItem_3 = toolStripMenuItem_6;
	}

	// Token: 0x06000D4F RID: 3407 RVA: 0x0000810B File Offset: 0x0000630B
	internal ToolStripMenuItem vmethod_28()
	{
		return this.toolStripMenuItem_4;
	}

	// Token: 0x06000D50 RID: 3408 RVA: 0x000670B4 File Offset: 0x000652B4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_29(ToolStripMenuItem toolStripMenuItem_6)
	{
		EventHandler value = new EventHandler(this.method_12);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_4;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_4 = toolStripMenuItem_6;
		toolStripMenuItem = this.toolStripMenuItem_4;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000D51 RID: 3409 RVA: 0x00008113 File Offset: 0x00006313
	internal ToolStripSeparator vmethod_30()
	{
		return this.toolStripSeparator_2;
	}

	// Token: 0x06000D52 RID: 3410 RVA: 0x0000811B File Offset: 0x0000631B
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_31(ToolStripSeparator toolStripSeparator_3)
	{
		this.toolStripSeparator_2 = toolStripSeparator_3;
	}

	// Token: 0x06000D53 RID: 3411 RVA: 0x00008124 File Offset: 0x00006324
	internal ToolStripMenuItem vmethod_32()
	{
		return this.toolStripMenuItem_5;
	}

	// Token: 0x06000D54 RID: 3412 RVA: 0x000670F8 File Offset: 0x000652F8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_33(ToolStripMenuItem toolStripMenuItem_6)
	{
		EventHandler value = new EventHandler(this.method_11);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_5;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_5 = toolStripMenuItem_6;
		toolStripMenuItem = this.toolStripMenuItem_5;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000D55 RID: 3413 RVA: 0x0006713C File Offset: 0x0006533C
	private void fMinerXMRLogManager_Load(object sender, EventArgs e)
	{
		this.vmethod_0().Columns.Add("Miner");
		this.vmethod_0().Columns[0].Width = checked(this.vmethod_0().Width - 6 - SystemInformation.VerticalScrollBarWidth);
		this.vmethod_0().GridLines = Class135.smethod_0().Gridlines;
	}

	// Token: 0x06000D56 RID: 3414 RVA: 0x000671A0 File Offset: 0x000653A0
	public void method_0(string string_0, string string_1, string string_2)
	{
		if (this.vmethod_0().InvokeRequired)
		{
			this.vmethod_0().Invoke(new fMinerXMRLogManager.Delegate64(this.method_0), new object[]
			{
				string_0,
				string_1,
				string_2
			});
			return;
		}
		string_2 = Encoding.UTF8.GetString(Convert.FromBase64String(string_2));
		if (Class136.smethod_31(ref this.collection_0, ref string_0))
		{
			this.vmethod_0().Items[string_0].Remove();
			this.collection_0.Remove(string_0);
		}
		this.collection_0.Add(string_2, string_0, null, null);
		this.vmethod_8().ReadOnly = true;
		this.vmethod_8().Text = Conversions.ToString(this.collection_0[string_0]);
		this.vmethod_12().Text = "Current log: " + string_1;
		ToolStripStatusLabel toolStripStatusLabel = this.vmethod_6();
		string text = "Log size: ";
		double num = (double)Strings.Len(RuntimeHelpers.GetObjectValue(this.collection_0[string_0]));
		bool flag = false;
		ref bool ptr = ref flag;
		double num2 = num;
		string str = text;
		ToolStripStatusLabel toolStripStatusLabel2 = toolStripStatusLabel;
		int num3;
		string text3;
		int num4;
		object obj;
		try
		{
			ProjectData.ClearProjectError();
			num3 = 2;
			string text2 = string.Empty;
			if (num2 >= 1099511627776.0)
			{
				text2 = Strings.Format(num2 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
			}
			else if (num2 >= 1073741824.0)
			{
				text2 = Strings.Format(num2 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
			}
			else if (num2 >= 1048576.0)
			{
				text2 = Strings.Format(num2 / 1024.0 / 1024.0, "#0.00") + " MiB";
			}
			else if (num2 >= 1024.0)
			{
				text2 = Strings.Format(num2 / 1024.0, "#0.00") + " KiB";
			}
			else if (num2 < 1024.0)
			{
				text2 = Conversions.ToString(Conversion.Fix(num2)) + " B";
			}
			if (ptr)
			{
				text2 = Strings.Split(text2, " ", -1, CompareMethod.Text)[0];
			}
			if (text2.Length > 0)
			{
				text3 = text2;
			}
			else
			{
				text3 = " 0 B";
			}
			IL_265:
			goto IL_2B4;
			IL_267:
			text3 = "0 B";
			goto IL_265;
			IL_26F:
			num4 = -1;
			@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
			IL_285:;
		}
		catch when (endfilter(obj is Exception & num3 != 0 & num4 == 0))
		{
			Exception ex = (Exception)obj2;
			goto IL_26F;
		}
		throw ProjectData.CreateProjectError(-2146828237);
		IL_2B4:
		if (num4 != 0)
		{
			ProjectData.ClearProjectError();
		}
		string str2 = text3;
		toolStripStatusLabel2.Text = str + str2;
		this.vmethod_0().Items.Add(string_0, string_1, 0);
		this.vmethod_0().Items[string_0].Tag = string_0;
	}

	// Token: 0x06000D57 RID: 3415 RVA: 0x000674C4 File Offset: 0x000656C4
	public void method_1(string string_0)
	{
		if (this.vmethod_0().InvokeRequired)
		{
			this.vmethod_0().Invoke(new fMinerXMRLogManager.Delegate63(this.method_1), new object[]
			{
				string_0
			});
			return;
		}
		this.collection_0.Remove(string_0);
		if (Operators.ConditionalCompareObjectEqual(this.vmethod_0().SelectedItems[0].Tag, string_0, true))
		{
			this.vmethod_8().Clear();
		}
		this.vmethod_0().Items[string_0].Remove();
	}

	// Token: 0x06000D58 RID: 3416 RVA: 0x00067550 File Offset: 0x00065750
	private void method_2(object sender, EventArgs e)
	{
		this.vmethod_8().ReadOnly = true;
		this.vmethod_8().Text = Conversions.ToString(this.collection_0[RuntimeHelpers.GetObjectValue(this.vmethod_0().SelectedItems[0].Tag)]);
		this.vmethod_12().Text = "Current log: " + this.vmethod_0().SelectedItems[0].Text;
		ToolStripStatusLabel toolStripStatusLabel = this.vmethod_6();
		string text = "Log size: ";
		double num = (double)Strings.Len(RuntimeHelpers.GetObjectValue(this.collection_0[RuntimeHelpers.GetObjectValue(this.vmethod_0().SelectedItems[0].Tag)]));
		bool flag = false;
		ref bool ptr = ref flag;
		double num2 = num;
		string str = text;
		ToolStripStatusLabel toolStripStatusLabel2 = toolStripStatusLabel;
		int num3;
		string text3;
		int num4;
		object obj;
		try
		{
			ProjectData.ClearProjectError();
			num3 = 2;
			string text2 = string.Empty;
			if (num2 >= 1099511627776.0)
			{
				text2 = Strings.Format(num2 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
			}
			else if (num2 >= 1073741824.0)
			{
				text2 = Strings.Format(num2 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
			}
			else if (num2 >= 1048576.0)
			{
				text2 = Strings.Format(num2 / 1024.0 / 1024.0, "#0.00") + " MiB";
			}
			else if (num2 >= 1024.0)
			{
				text2 = Strings.Format(num2 / 1024.0, "#0.00") + " KiB";
			}
			else if (num2 < 1024.0)
			{
				text2 = Conversions.ToString(Conversion.Fix(num2)) + " B";
			}
			if (ptr)
			{
				text2 = Strings.Split(text2, " ", -1, CompareMethod.Text)[0];
			}
			if (text2.Length > 0)
			{
				text3 = text2;
			}
			else
			{
				text3 = " 0 B";
			}
			IL_222:
			goto IL_271;
			IL_224:
			text3 = "0 B";
			goto IL_222;
			IL_22C:
			num4 = -1;
			@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
			IL_242:;
		}
		catch when (endfilter(obj is Exception & num3 != 0 & num4 == 0))
		{
			Exception ex = (Exception)obj2;
			goto IL_22C;
		}
		throw ProjectData.CreateProjectError(-2146828237);
		IL_271:
		if (num4 != 0)
		{
			ProjectData.ClearProjectError();
		}
		string str2 = text3;
		toolStripStatusLabel2.Text = str + str2;
	}

	// Token: 0x06000D59 RID: 3417 RVA: 0x0000812C File Offset: 0x0000632C
	private void method_3(object sender, EventArgs e)
	{
		this.vmethod_4().Text = "Logs: " + Conversions.ToString(this.vmethod_0().Items.Count);
	}

	// Token: 0x06000D5A RID: 3418 RVA: 0x00067808 File Offset: 0x00065A08
	private void method_4(object sender, EventArgs e)
	{
		this.vmethod_0().Items.Clear();
		this.collection_0.Clear();
		this.vmethod_8().Clear();
		this.vmethod_12().Text = "N/A";
		this.vmethod_6().Text = "N/A";
	}

	// Token: 0x06000D5B RID: 3419 RVA: 0x0006785C File Offset: 0x00065A5C
	private void method_5(object sender, EventArgs e)
	{
		checked
		{
			for (int i = this.vmethod_0().Items.Count - 1; i >= 0; i += -1)
			{
				if (this.vmethod_0().Items[i].Selected)
				{
					if (this.vmethod_0().SelectedItems.Count > 0 && this.vmethod_0().SelectedItems[0].Index == i)
					{
						this.vmethod_8().Clear();
						this.vmethod_12().Text = "N/A";
						this.vmethod_6().Text = "N/A";
					}
					this.method_1(Conversions.ToString(this.vmethod_0().Items[i].Tag));
					Application.DoEvents();
				}
			}
		}
	}

	// Token: 0x06000D5C RID: 3420 RVA: 0x00007348 File Offset: 0x00005548
	private void fMinerXMRLogManager_Closing(object sender, CancelEventArgs e)
	{
		base.Visible = false;
		e.Cancel = true;
	}

	// Token: 0x06000D5D RID: 3421 RVA: 0x00067924 File Offset: 0x00065B24
	private void method_6(object sender, MouseEventArgs e)
	{
		this.vmethod_16().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_0().SelectedItems.Count == 1, true, false));
		this.vmethod_32().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_0().SelectedItems.Count > 0, true, false));
		this.vmethod_28().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_0().Items.Count > 0, true, false));
		this.vmethod_26().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_0().Items.Count > 0, true, false));
	}

	// Token: 0x06000D5E RID: 3422 RVA: 0x00067550 File Offset: 0x00065750
	private void method_7(object sender, EventArgs e)
	{
		this.vmethod_8().ReadOnly = true;
		this.vmethod_8().Text = Conversions.ToString(this.collection_0[RuntimeHelpers.GetObjectValue(this.vmethod_0().SelectedItems[0].Tag)]);
		this.vmethod_12().Text = "Current log: " + this.vmethod_0().SelectedItems[0].Text;
		ToolStripStatusLabel toolStripStatusLabel = this.vmethod_6();
		string text = "Log size: ";
		double num = (double)Strings.Len(RuntimeHelpers.GetObjectValue(this.collection_0[RuntimeHelpers.GetObjectValue(this.vmethod_0().SelectedItems[0].Tag)]));
		bool flag = false;
		ref bool ptr = ref flag;
		double num2 = num;
		string str = text;
		ToolStripStatusLabel toolStripStatusLabel2 = toolStripStatusLabel;
		int num3;
		string text3;
		int num4;
		object obj;
		try
		{
			ProjectData.ClearProjectError();
			num3 = 2;
			string text2 = string.Empty;
			if (num2 >= 1099511627776.0)
			{
				text2 = Strings.Format(num2 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
			}
			else if (num2 >= 1073741824.0)
			{
				text2 = Strings.Format(num2 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
			}
			else if (num2 >= 1048576.0)
			{
				text2 = Strings.Format(num2 / 1024.0 / 1024.0, "#0.00") + " MiB";
			}
			else if (num2 >= 1024.0)
			{
				text2 = Strings.Format(num2 / 1024.0, "#0.00") + " KiB";
			}
			else if (num2 < 1024.0)
			{
				text2 = Conversions.ToString(Conversion.Fix(num2)) + " B";
			}
			if (ptr)
			{
				text2 = Strings.Split(text2, " ", -1, CompareMethod.Text)[0];
			}
			if (text2.Length > 0)
			{
				text3 = text2;
			}
			else
			{
				text3 = " 0 B";
			}
			IL_222:
			goto IL_271;
			IL_224:
			text3 = "0 B";
			goto IL_222;
			IL_22C:
			num4 = -1;
			@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
			IL_242:;
		}
		catch when (endfilter(obj is Exception & num3 != 0 & num4 == 0))
		{
			Exception ex = (Exception)obj2;
			goto IL_22C;
		}
		throw ProjectData.CreateProjectError(-2146828237);
		IL_271:
		if (num4 != 0)
		{
			ProjectData.ClearProjectError();
		}
		string str2 = text3;
		toolStripStatusLabel2.Text = str + str2;
	}

	// Token: 0x06000D5F RID: 3423 RVA: 0x00067A04 File Offset: 0x00065C04
	private void method_8(object sender, EventArgs e)
	{
		string text = Conversions.ToString(this.vmethod_0().SelectedItems[0].Tag);
		string string_ = "xmr_mine_log|1";
		string string_2 = text;
		Class136.Class138 @class = new Class136.Class138();
		@class.string_0 = string_2;
		@class.string_1 = string_;
		@class.long_0 = 0L;
		try
		{
			if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
			{
				new Thread(new ThreadStart(@class._Lambda$__0)).Start();
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x06000D60 RID: 3424 RVA: 0x00067550 File Offset: 0x00065750
	private void method_9(object sender, EventArgs e)
	{
		this.vmethod_8().ReadOnly = true;
		this.vmethod_8().Text = Conversions.ToString(this.collection_0[RuntimeHelpers.GetObjectValue(this.vmethod_0().SelectedItems[0].Tag)]);
		this.vmethod_12().Text = "Current log: " + this.vmethod_0().SelectedItems[0].Text;
		ToolStripStatusLabel toolStripStatusLabel = this.vmethod_6();
		string text = "Log size: ";
		double num = (double)Strings.Len(RuntimeHelpers.GetObjectValue(this.collection_0[RuntimeHelpers.GetObjectValue(this.vmethod_0().SelectedItems[0].Tag)]));
		bool flag = false;
		ref bool ptr = ref flag;
		double num2 = num;
		string str = text;
		ToolStripStatusLabel toolStripStatusLabel2 = toolStripStatusLabel;
		int num3;
		string text3;
		int num4;
		object obj;
		try
		{
			ProjectData.ClearProjectError();
			num3 = 2;
			string text2 = string.Empty;
			if (num2 >= 1099511627776.0)
			{
				text2 = Strings.Format(num2 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
			}
			else if (num2 >= 1073741824.0)
			{
				text2 = Strings.Format(num2 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
			}
			else if (num2 >= 1048576.0)
			{
				text2 = Strings.Format(num2 / 1024.0 / 1024.0, "#0.00") + " MiB";
			}
			else if (num2 >= 1024.0)
			{
				text2 = Strings.Format(num2 / 1024.0, "#0.00") + " KiB";
			}
			else if (num2 < 1024.0)
			{
				text2 = Conversions.ToString(Conversion.Fix(num2)) + " B";
			}
			if (ptr)
			{
				text2 = Strings.Split(text2, " ", -1, CompareMethod.Text)[0];
			}
			if (text2.Length > 0)
			{
				text3 = text2;
			}
			else
			{
				text3 = " 0 B";
			}
			IL_222:
			goto IL_271;
			IL_224:
			text3 = "0 B";
			goto IL_222;
			IL_22C:
			num4 = -1;
			@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
			IL_242:;
		}
		catch when (endfilter(obj is Exception & num3 != 0 & num4 == 0))
		{
			Exception ex = (Exception)obj2;
			goto IL_22C;
		}
		throw ProjectData.CreateProjectError(-2146828237);
		IL_271:
		if (num4 != 0)
		{
			ProjectData.ClearProjectError();
		}
		string str2 = text3;
		toolStripStatusLabel2.Text = str + str2;
	}

	// Token: 0x06000D61 RID: 3425 RVA: 0x00067A04 File Offset: 0x00065C04
	private void method_10(object sender, EventArgs e)
	{
		string text = Conversions.ToString(this.vmethod_0().SelectedItems[0].Tag);
		string string_ = "xmr_mine_log|1";
		string string_2 = text;
		Class136.Class138 @class = new Class136.Class138();
		@class.string_0 = string_2;
		@class.string_1 = string_;
		@class.long_0 = 0L;
		try
		{
			if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
			{
				new Thread(new ThreadStart(@class._Lambda$__0)).Start();
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x06000D62 RID: 3426 RVA: 0x0006785C File Offset: 0x00065A5C
	private void method_11(object sender, EventArgs e)
	{
		checked
		{
			for (int i = this.vmethod_0().Items.Count - 1; i >= 0; i += -1)
			{
				if (this.vmethod_0().Items[i].Selected)
				{
					if (this.vmethod_0().SelectedItems.Count > 0 && this.vmethod_0().SelectedItems[0].Index == i)
					{
						this.vmethod_8().Clear();
						this.vmethod_12().Text = "N/A";
						this.vmethod_6().Text = "N/A";
					}
					this.method_1(Conversions.ToString(this.vmethod_0().Items[i].Tag));
					Application.DoEvents();
				}
			}
		}
	}

	// Token: 0x06000D63 RID: 3427 RVA: 0x00067808 File Offset: 0x00065A08
	private void method_12(object sender, EventArgs e)
	{
		this.vmethod_0().Items.Clear();
		this.collection_0.Clear();
		this.vmethod_8().Clear();
		this.vmethod_12().Text = "N/A";
		this.vmethod_6().Text = "N/A";
	}

	// Token: 0x06000D64 RID: 3428 RVA: 0x00067AA0 File Offset: 0x00065CA0
	private void method_13(object sender, EventArgs e)
	{
		if (this.vmethod_0().SelectedItems.Count > 0)
		{
			this.vmethod_8().ReadOnly = true;
			this.vmethod_8().Text = Conversions.ToString(this.collection_0[RuntimeHelpers.GetObjectValue(this.vmethod_0().SelectedItems[0].Tag)]);
			this.vmethod_12().Text = "Current log: " + this.vmethod_0().SelectedItems[0].Text;
			ToolStripStatusLabel toolStripStatusLabel = this.vmethod_6();
			string text = "Log size: ";
			double num = (double)Strings.Len(RuntimeHelpers.GetObjectValue(this.collection_0[RuntimeHelpers.GetObjectValue(this.vmethod_0().SelectedItems[0].Tag)]));
			bool flag = false;
			ref bool ptr = ref flag;
			double num2 = num;
			string str = text;
			ToolStripStatusLabel toolStripStatusLabel2 = toolStripStatusLabel;
			int num3;
			string text3;
			int num4;
			object obj;
			try
			{
				ProjectData.ClearProjectError();
				num3 = 2;
				string text2 = string.Empty;
				if (num2 >= 1099511627776.0)
				{
					text2 = Strings.Format(num2 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
				}
				else if (num2 >= 1073741824.0)
				{
					text2 = Strings.Format(num2 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
				}
				else if (num2 >= 1048576.0)
				{
					text2 = Strings.Format(num2 / 1024.0 / 1024.0, "#0.00") + " MiB";
				}
				else if (num2 >= 1024.0)
				{
					text2 = Strings.Format(num2 / 1024.0, "#0.00") + " KiB";
				}
				else if (num2 < 1024.0)
				{
					text2 = Conversions.ToString(Conversion.Fix(num2)) + " B";
				}
				if (ptr)
				{
					text2 = Strings.Split(text2, " ", -1, CompareMethod.Text)[0];
				}
				if (text2.Length > 0)
				{
					text3 = text2;
				}
				else
				{
					text3 = " 0 B";
				}
				IL_238:
				goto IL_287;
				IL_23A:
				text3 = "0 B";
				goto IL_238;
				IL_242:
				num4 = -1;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
				IL_258:;
			}
			catch when (endfilter(obj is Exception & num3 != 0 & num4 == 0))
			{
				Exception ex = (Exception)obj2;
				goto IL_242;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			IL_287:
			if (num4 != 0)
			{
				ProjectData.ClearProjectError();
			}
			string str2 = text3;
			toolStripStatusLabel2.Text = str + str2;
		}
	}

	// Token: 0x06000D65 RID: 3429 RVA: 0x00067D6C File Offset: 0x00065F6C
	private void method_14(object sender, KeyEventArgs e)
	{
		if (e.KeyData == (Keys)131137)
		{
			try
			{
				foreach (object obj in this.vmethod_0().Items)
				{
					((ListViewItem)obj).Selected = true;
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x04000550 RID: 1360
	private GClass7 gclass7_0;

	// Token: 0x04000551 RID: 1361
	private StatusStrip statusStrip_0;

	// Token: 0x04000552 RID: 1362
	private ToolStripStatusLabel toolStripStatusLabel_0;

	// Token: 0x04000553 RID: 1363
	private ToolStripStatusLabel toolStripStatusLabel_1;

	// Token: 0x04000554 RID: 1364
	private RichTextBox richTextBox_0;

	// Token: 0x04000555 RID: 1365
	private System.Windows.Forms.Timer timer_0;

	// Token: 0x04000556 RID: 1366
	private ToolStripStatusLabel toolStripStatusLabel_2;

	// Token: 0x04000557 RID: 1367
	private ContextMenuStrip contextMenuStrip_0;

	// Token: 0x04000558 RID: 1368
	private ToolStripMenuItem toolStripMenuItem_0;

	// Token: 0x04000559 RID: 1369
	private ToolStripMenuItem toolStripMenuItem_1;

	// Token: 0x0400055A RID: 1370
	private ToolStripSeparator toolStripSeparator_0;

	// Token: 0x0400055B RID: 1371
	private ToolStripMenuItem toolStripMenuItem_2;

	// Token: 0x0400055C RID: 1372
	private ToolStripSeparator toolStripSeparator_1;

	// Token: 0x0400055D RID: 1373
	private ToolStripMenuItem toolStripMenuItem_3;

	// Token: 0x0400055E RID: 1374
	private ToolStripMenuItem toolStripMenuItem_4;

	// Token: 0x0400055F RID: 1375
	private ToolStripSeparator toolStripSeparator_2;

	// Token: 0x04000560 RID: 1376
	private ToolStripMenuItem toolStripMenuItem_5;

	// Token: 0x04000561 RID: 1377
	public Collection collection_0;

	// Token: 0x020000FE RID: 254
	// (Invoke) Token: 0x06000D69 RID: 3433
	private delegate void Delegate63(string string_0);

	// Token: 0x020000FF RID: 255
	// (Invoke) Token: 0x06000D6D RID: 3437
	private delegate void Delegate64(string string_0, string string_1, string string_2);
}
