﻿using System;
using System.Collections.Concurrent;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using BitRAT;
using BrightIdeasSoftware;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

// Token: 0x02000196 RID: 406
[DesignerGenerated]
public sealed partial class fConnectionLog : Form
{
	// Token: 0x06001640 RID: 5696 RVA: 0x000A8428 File Offset: 0x000A6628
	public fConnectionLog()
	{
		base.Load += this.fConnectionLog_Load;
		base.Closing += this.fConnectionLog_Closing;
		this.concurrentQueue_0 = new ConcurrentQueue<cLogCon>();
		this.concurrentQueue_1 = new ConcurrentQueue<cLogCon>();
		this.concurrentQueue_2 = new ConcurrentQueue<cLogCon>();
		this.InitializeComponent();
	}

	// Token: 0x06001643 RID: 5699 RVA: 0x0000B4D3 File Offset: 0x000096D3
	internal FastObjectListView vmethod_0()
	{
		return this.fastObjectListView_0;
	}

	// Token: 0x06001644 RID: 5700 RVA: 0x000A8F44 File Offset: 0x000A7144
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_1(FastObjectListView fastObjectListView_1)
	{
		EventHandler<FormatRowEventArgs> eventHandler = new EventHandler<FormatRowEventArgs>(this.method_7);
		MouseEventHandler value = new MouseEventHandler(this.method_13);
		FastObjectListView fastObjectListView = this.fastObjectListView_0;
		if (fastObjectListView != null)
		{
			fastObjectListView.FormatRow -= eventHandler;
			fastObjectListView.MouseUp -= value;
		}
		this.fastObjectListView_0 = fastObjectListView_1;
		fastObjectListView = this.fastObjectListView_0;
		if (fastObjectListView != null)
		{
			fastObjectListView.FormatRow += eventHandler;
			fastObjectListView.MouseUp += value;
		}
	}

	// Token: 0x06001645 RID: 5701 RVA: 0x0000B4DB File Offset: 0x000096DB
	internal OLVColumn vmethod_2()
	{
		return this.olvcolumn_0;
	}

	// Token: 0x06001646 RID: 5702 RVA: 0x0000B4E3 File Offset: 0x000096E3
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_3(OLVColumn olvcolumn_4)
	{
		this.olvcolumn_0 = olvcolumn_4;
	}

	// Token: 0x06001647 RID: 5703 RVA: 0x0000B4EC File Offset: 0x000096EC
	internal OLVColumn vmethod_4()
	{
		return this.olvcolumn_1;
	}

	// Token: 0x06001648 RID: 5704 RVA: 0x0000B4F4 File Offset: 0x000096F4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_5(OLVColumn olvcolumn_4)
	{
		this.olvcolumn_1 = olvcolumn_4;
	}

	// Token: 0x06001649 RID: 5705 RVA: 0x0000B4FD File Offset: 0x000096FD
	internal OLVColumn vmethod_6()
	{
		return this.olvcolumn_2;
	}

	// Token: 0x0600164A RID: 5706 RVA: 0x0000B505 File Offset: 0x00009705
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_7(OLVColumn olvcolumn_4)
	{
		this.olvcolumn_2 = olvcolumn_4;
	}

	// Token: 0x0600164B RID: 5707 RVA: 0x0000B50E File Offset: 0x0000970E
	internal StatusStrip vmethod_8()
	{
		return this.statusStrip_0;
	}

	// Token: 0x0600164C RID: 5708 RVA: 0x0000B516 File Offset: 0x00009716
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_9(StatusStrip statusStrip_1)
	{
		this.statusStrip_0 = statusStrip_1;
	}

	// Token: 0x0600164D RID: 5709 RVA: 0x0000B51F File Offset: 0x0000971F
	internal ToolStripStatusLabel vmethod_10()
	{
		return this.toolStripStatusLabel_0;
	}

	// Token: 0x0600164E RID: 5710 RVA: 0x0000B527 File Offset: 0x00009727
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_11(ToolStripStatusLabel toolStripStatusLabel_1)
	{
		this.toolStripStatusLabel_0 = toolStripStatusLabel_1;
	}

	// Token: 0x0600164F RID: 5711 RVA: 0x0000B530 File Offset: 0x00009730
	internal BackgroundWorker vmethod_12()
	{
		return this.backgroundWorker_0;
	}

	// Token: 0x06001650 RID: 5712 RVA: 0x000A8FA4 File Offset: 0x000A71A4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_13(BackgroundWorker backgroundWorker_1)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_5);
		BackgroundWorker backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_0 = backgroundWorker_1;
		backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x06001651 RID: 5713 RVA: 0x0000B538 File Offset: 0x00009738
	internal System.Windows.Forms.Timer vmethod_14()
	{
		return this.timer_0;
	}

	// Token: 0x06001652 RID: 5714 RVA: 0x000A8FE8 File Offset: 0x000A71E8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_15(System.Windows.Forms.Timer timer_1)
	{
		EventHandler value = new EventHandler(this.method_6);
		System.Windows.Forms.Timer timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_0 = timer_1;
		timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x06001653 RID: 5715 RVA: 0x0000B540 File Offset: 0x00009740
	internal OLVColumn vmethod_16()
	{
		return this.olvcolumn_3;
	}

	// Token: 0x06001654 RID: 5716 RVA: 0x0000B548 File Offset: 0x00009748
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_17(OLVColumn olvcolumn_4)
	{
		this.olvcolumn_3 = olvcolumn_4;
	}

	// Token: 0x06001655 RID: 5717 RVA: 0x0000B551 File Offset: 0x00009751
	internal ContextMenuStrip vmethod_18()
	{
		return this.contextMenuStrip_0;
	}

	// Token: 0x06001656 RID: 5718 RVA: 0x0000B559 File Offset: 0x00009759
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_19(ContextMenuStrip contextMenuStrip_1)
	{
		this.contextMenuStrip_0 = contextMenuStrip_1;
	}

	// Token: 0x06001657 RID: 5719 RVA: 0x0000B562 File Offset: 0x00009762
	internal ToolStripMenuItem vmethod_20()
	{
		return this.toolStripMenuItem_0;
	}

	// Token: 0x06001658 RID: 5720 RVA: 0x0000B56A File Offset: 0x0000976A
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_21(ToolStripMenuItem toolStripMenuItem_9)
	{
		this.toolStripMenuItem_0 = toolStripMenuItem_9;
	}

	// Token: 0x06001659 RID: 5721 RVA: 0x0000B573 File Offset: 0x00009773
	internal ToolStripMenuItem vmethod_22()
	{
		return this.toolStripMenuItem_1;
	}

	// Token: 0x0600165A RID: 5722 RVA: 0x000A902C File Offset: 0x000A722C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_23(ToolStripMenuItem toolStripMenuItem_9)
	{
		EventHandler value = new EventHandler(this.method_8);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_1;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_1 = toolStripMenuItem_9;
		toolStripMenuItem = this.toolStripMenuItem_1;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600165B RID: 5723 RVA: 0x0000B57B File Offset: 0x0000977B
	internal ToolStripSeparator vmethod_24()
	{
		return this.toolStripSeparator_0;
	}

	// Token: 0x0600165C RID: 5724 RVA: 0x0000B583 File Offset: 0x00009783
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_25(ToolStripSeparator toolStripSeparator_5)
	{
		this.toolStripSeparator_0 = toolStripSeparator_5;
	}

	// Token: 0x0600165D RID: 5725 RVA: 0x0000B58C File Offset: 0x0000978C
	internal ToolStripMenuItem vmethod_26()
	{
		return this.toolStripMenuItem_2;
	}

	// Token: 0x0600165E RID: 5726 RVA: 0x000A9070 File Offset: 0x000A7270
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_27(ToolStripMenuItem toolStripMenuItem_9)
	{
		EventHandler value = new EventHandler(this.method_9);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_2;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_2 = toolStripMenuItem_9;
		toolStripMenuItem = this.toolStripMenuItem_2;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600165F RID: 5727 RVA: 0x0000B594 File Offset: 0x00009794
	internal ToolStripSeparator vmethod_28()
	{
		return this.toolStripSeparator_1;
	}

	// Token: 0x06001660 RID: 5728 RVA: 0x0000B59C File Offset: 0x0000979C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_29(ToolStripSeparator toolStripSeparator_5)
	{
		this.toolStripSeparator_1 = toolStripSeparator_5;
	}

	// Token: 0x06001661 RID: 5729 RVA: 0x0000B5A5 File Offset: 0x000097A5
	internal ToolStripMenuItem vmethod_30()
	{
		return this.toolStripMenuItem_3;
	}

	// Token: 0x06001662 RID: 5730 RVA: 0x000A90B4 File Offset: 0x000A72B4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_31(ToolStripMenuItem toolStripMenuItem_9)
	{
		EventHandler value = new EventHandler(this.method_10);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_3;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_3 = toolStripMenuItem_9;
		toolStripMenuItem = this.toolStripMenuItem_3;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001663 RID: 5731 RVA: 0x0000B5AD File Offset: 0x000097AD
	internal ToolStripSeparator vmethod_32()
	{
		return this.toolStripSeparator_2;
	}

	// Token: 0x06001664 RID: 5732 RVA: 0x0000B5B5 File Offset: 0x000097B5
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_33(ToolStripSeparator toolStripSeparator_5)
	{
		this.toolStripSeparator_2 = toolStripSeparator_5;
	}

	// Token: 0x06001665 RID: 5733 RVA: 0x0000B5BE File Offset: 0x000097BE
	internal ToolStripMenuItem vmethod_34()
	{
		return this.toolStripMenuItem_4;
	}

	// Token: 0x06001666 RID: 5734 RVA: 0x0000B5C6 File Offset: 0x000097C6
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_35(ToolStripMenuItem toolStripMenuItem_9)
	{
		this.toolStripMenuItem_4 = toolStripMenuItem_9;
	}

	// Token: 0x06001667 RID: 5735 RVA: 0x0000B5CF File Offset: 0x000097CF
	internal ToolStripMenuItem vmethod_36()
	{
		return this.toolStripMenuItem_5;
	}

	// Token: 0x06001668 RID: 5736 RVA: 0x000A90F8 File Offset: 0x000A72F8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_37(ToolStripMenuItem toolStripMenuItem_9)
	{
		EventHandler value = new EventHandler(this.method_11);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_5;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_5 = toolStripMenuItem_9;
		toolStripMenuItem = this.toolStripMenuItem_5;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001669 RID: 5737 RVA: 0x0000B5D7 File Offset: 0x000097D7
	internal ToolStripSeparator vmethod_38()
	{
		return this.toolStripSeparator_3;
	}

	// Token: 0x0600166A RID: 5738 RVA: 0x0000B5DF File Offset: 0x000097DF
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_39(ToolStripSeparator toolStripSeparator_5)
	{
		this.toolStripSeparator_3 = toolStripSeparator_5;
	}

	// Token: 0x0600166B RID: 5739 RVA: 0x0000B5E8 File Offset: 0x000097E8
	internal ToolStripMenuItem vmethod_40()
	{
		return this.toolStripMenuItem_6;
	}

	// Token: 0x0600166C RID: 5740 RVA: 0x000A913C File Offset: 0x000A733C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_41(ToolStripMenuItem toolStripMenuItem_9)
	{
		EventHandler value = new EventHandler(this.method_12);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_6;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_6 = toolStripMenuItem_9;
		toolStripMenuItem = this.toolStripMenuItem_6;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600166D RID: 5741 RVA: 0x0000B5F0 File Offset: 0x000097F0
	internal ToolStripMenuItem vmethod_42()
	{
		return this.toolStripMenuItem_7;
	}

	// Token: 0x0600166E RID: 5742 RVA: 0x0000B5F8 File Offset: 0x000097F8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_43(ToolStripMenuItem toolStripMenuItem_9)
	{
		this.toolStripMenuItem_7 = toolStripMenuItem_9;
	}

	// Token: 0x0600166F RID: 5743 RVA: 0x0000B601 File Offset: 0x00009801
	internal ToolStripMenuItem vmethod_44()
	{
		return this.toolStripMenuItem_8;
	}

	// Token: 0x06001670 RID: 5744 RVA: 0x000A9180 File Offset: 0x000A7380
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_45(ToolStripMenuItem toolStripMenuItem_9)
	{
		EventHandler value = new EventHandler(this.method_14);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_8;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_8 = toolStripMenuItem_9;
		toolStripMenuItem = this.toolStripMenuItem_8;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001671 RID: 5745 RVA: 0x0000B609 File Offset: 0x00009809
	internal ToolStripSeparator vmethod_46()
	{
		return this.toolStripSeparator_4;
	}

	// Token: 0x06001672 RID: 5746 RVA: 0x0000B611 File Offset: 0x00009811
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_47(ToolStripSeparator toolStripSeparator_5)
	{
		this.toolStripSeparator_4 = toolStripSeparator_5;
	}

	// Token: 0x06001673 RID: 5747 RVA: 0x000A91C4 File Offset: 0x000A73C4
	private void fConnectionLog_Load(object sender, EventArgs e)
	{
		this.vmethod_0().VirtualMode = true;
		this.vmethod_0().View = View.Details;
		this.vmethod_0().FullRowSelect = true;
		this.vmethod_0().OwnerDraw = true;
		this.vmethod_0().Left = 0;
		this.vmethod_0().Top = 0;
		checked
		{
			this.vmethod_0().Width = base.Width - 10;
			this.vmethod_0().Height = base.Height - this.vmethod_8().Height - 30;
			this.vmethod_12().RunWorkerAsync();
		}
	}

	// Token: 0x06001674 RID: 5748 RVA: 0x0000A35C File Offset: 0x0000855C
	public void method_0()
	{
		base.Opacity = 100.0;
	}

	// Token: 0x06001675 RID: 5749 RVA: 0x00007348 File Offset: 0x00005548
	private void fConnectionLog_Closing(object sender, CancelEventArgs e)
	{
		base.Visible = false;
		e.Cancel = true;
	}

	// Token: 0x06001676 RID: 5750 RVA: 0x000A9258 File Offset: 0x000A7458
	public void method_1(string string_0, string string_1, int int_0)
	{
		if (this.vmethod_0().InvokeRequired)
		{
			this.vmethod_0().Invoke(new fConnectionLog.Delegate160(this.method_1), new object[]
			{
				string_0,
				string_1,
				int_0
			});
			return;
		}
		cLogCon cLogCon = new cLogCon();
		string action = "N/A";
		switch (int_0)
		{
		case 0:
			action = "Connection Attempt";
			cLogCon.bIsAttempt = true;
			break;
		case 1:
			action = "Connection Established";
			cLogCon.bIsEstablished = true;
			break;
		case 2:
			action = "Disconnected";
			cLogCon.bIsDC = true;
			break;
		}
		cLogCon.HOST = string_0;
		cLogCon.TYPE = string_1;
		cLogCon.ACTION = action;
		cLogCon.TIME = Conversions.ToString(DateAndTime.Now);
		this.concurrentQueue_0.Enqueue(cLogCon);
	}

	// Token: 0x06001677 RID: 5751 RVA: 0x000A9320 File Offset: 0x000A7520
	public void method_2()
	{
		if (this.vmethod_0().InvokeRequired)
		{
			this.vmethod_0().Invoke(new fConnectionLog.Delegate157(this.method_2), new object[0]);
			return;
		}
		if (this.concurrentQueue_0.Count > 0)
		{
			this.vmethod_0().AddObjects(this.concurrentQueue_0.ToList<cLogCon>());
			this.concurrentQueue_0 = new ConcurrentQueue<cLogCon>();
		}
	}

	// Token: 0x06001678 RID: 5752 RVA: 0x000A9388 File Offset: 0x000A7588
	public void method_3()
	{
		if (this.vmethod_0().InvokeRequired)
		{
			this.vmethod_0().Invoke(new fConnectionLog.Delegate158(this.method_3), new object[0]);
			return;
		}
		if (this.concurrentQueue_1.Count > 0)
		{
			this.vmethod_0().RefreshObjects(this.concurrentQueue_1.ToList<cLogCon>());
			this.concurrentQueue_0 = new ConcurrentQueue<cLogCon>();
		}
	}

	// Token: 0x06001679 RID: 5753 RVA: 0x000A93F0 File Offset: 0x000A75F0
	public void method_4()
	{
		if (this.vmethod_0().InvokeRequired)
		{
			this.vmethod_0().Invoke(new fConnectionLog.Delegate159(this.method_4), new object[0]);
			return;
		}
		if (this.concurrentQueue_2.Count > 0)
		{
			this.vmethod_0().RemoveObjects(this.concurrentQueue_2.ToList<cLogCon>());
			this.concurrentQueue_0 = new ConcurrentQueue<cLogCon>();
		}
	}

	// Token: 0x0600167A RID: 5754 RVA: 0x0000B61A File Offset: 0x0000981A
	private void method_5(object sender, DoWorkEventArgs e)
	{
		for (;;)
		{
			this.method_2();
			this.method_3();
			this.method_4();
			Thread.Sleep(100);
		}
	}

	// Token: 0x0600167B RID: 5755 RVA: 0x000A9458 File Offset: 0x000A7658
	private void method_6(object sender, EventArgs e)
	{
		this.vmethod_10().Text = "Entries: " + Conversions.ToString(this.vmethod_0().Items.Count);
		this.vmethod_44().Checked = Class135.smethod_0().ConLogColors;
	}

	// Token: 0x0600167C RID: 5756 RVA: 0x000A94A4 File Offset: 0x000A76A4
	private void method_7(object sender, FormatRowEventArgs e)
	{
		try
		{
			cLogCon cLogCon = (cLogCon)e.Model;
			if (Class135.smethod_0().ConLogColors)
			{
				if (cLogCon.bIsAttempt)
				{
					e.Item.BackColor = Color.DeepSkyBlue;
				}
				else if (cLogCon.bIsEstablished)
				{
					e.Item.BackColor = Color.LimeGreen;
				}
				else if (cLogCon.bIsDC)
				{
					e.Item.BackColor = Color.Red;
				}
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x0600167D RID: 5757 RVA: 0x000A9538 File Offset: 0x000A7738
	private void method_8(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		checked
		{
			if (this.vmethod_0().Items.Count != 0)
			{
				FastObjectListView fastObjectListView = this.vmethod_0();
				int num = fastObjectListView.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (fastObjectListView.Items[i].Selected)
					{
						stringBuilder.Append(fastObjectListView.Items[i].Text);
						int num2 = fastObjectListView.Columns.Count - 1;
						for (int j = 1; j <= num2; j++)
						{
							stringBuilder.Append("\t" + fastObjectListView.Items[i].SubItems[j].Text);
						}
						stringBuilder.Append("\r\n");
					}
				}
				if (stringBuilder.Length > 0)
				{
					string text = stringBuilder.ToString();
					Clipboard.Clear();
					Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
				}
			}
		}
	}

	// Token: 0x0600167E RID: 5758 RVA: 0x000A9634 File Offset: 0x000A7834
	private void method_9(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		checked
		{
			if (this.vmethod_0().Items.Count != 0)
			{
				FastObjectListView fastObjectListView = this.vmethod_0();
				int num = fastObjectListView.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					stringBuilder.Append(fastObjectListView.Items[i].Text);
					int num2 = fastObjectListView.Columns.Count - 1;
					for (int j = 1; j <= num2; j++)
					{
						stringBuilder.Append("\t" + fastObjectListView.Items[i].SubItems[j].Text);
					}
					stringBuilder.Append("\r\n");
				}
				if (stringBuilder.Length > 0)
				{
					string text = stringBuilder.ToString();
					Clipboard.Clear();
					Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
				}
			}
		}
	}

	// Token: 0x0600167F RID: 5759 RVA: 0x0000B636 File Offset: 0x00009836
	private void method_10(object sender, EventArgs e)
	{
		this.vmethod_0().ClearObjects();
	}

	// Token: 0x06001680 RID: 5760 RVA: 0x000A9718 File Offset: 0x000A7918
	private void method_11(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		checked
		{
			if (this.vmethod_0().Items.Count != 0)
			{
				FastObjectListView fastObjectListView = this.vmethod_0();
				int num = fastObjectListView.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (fastObjectListView.Items[i].Selected)
					{
						stringBuilder.Append(fastObjectListView.Items[i].Text);
						int num2 = fastObjectListView.Columns.Count - 1;
						for (int j = 1; j <= num2; j++)
						{
							stringBuilder.Append("\t" + fastObjectListView.Items[i].SubItems[j].Text);
						}
						stringBuilder.Append("\r\n");
					}
				}
				if (stringBuilder.Length > 0)
				{
					string s = stringBuilder.ToString();
					SaveFileDialog saveFileDialog = new SaveFileDialog();
					saveFileDialog.Filter = "Text file |*.txt";
					if (saveFileDialog.ShowDialog() == DialogResult.OK)
					{
						string fileName = saveFileDialog.FileName;
						byte[] bytes = Encoding.Unicode.GetBytes(s);
						bool flag = true;
						byte[] byte_ = bytes;
						string string_ = fileName;
						Class136.Class142 @class = new Class136.Class142();
						@class.string_0 = string_;
						@class.byte_0 = byte_;
						@class.bool_0 = false;
						try
						{
							if (flag)
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
							else
							{
								Class136.smethod_15(ref @class.string_0, ref @class.byte_0, @class.bool_0);
							}
						}
						catch (Exception ex)
						{
						}
					}
				}
			}
		}
	}

	// Token: 0x06001681 RID: 5761 RVA: 0x000A98B4 File Offset: 0x000A7AB4
	private void method_12(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		checked
		{
			if (this.vmethod_0().Items.Count != 0)
			{
				FastObjectListView fastObjectListView = this.vmethod_0();
				int num = fastObjectListView.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					stringBuilder.Append(fastObjectListView.Items[i].Text);
					int num2 = fastObjectListView.Columns.Count - 1;
					for (int j = 1; j <= num2; j++)
					{
						stringBuilder.Append("\t" + fastObjectListView.Items[i].SubItems[j].Text);
					}
					stringBuilder.Append("\r\n");
				}
				if (stringBuilder.Length > 0)
				{
					string s = stringBuilder.ToString();
					SaveFileDialog saveFileDialog = new SaveFileDialog();
					saveFileDialog.Filter = "Text file |*.txt";
					if (saveFileDialog.ShowDialog() == DialogResult.OK)
					{
						string fileName = saveFileDialog.FileName;
						byte[] bytes = Encoding.Unicode.GetBytes(s);
						bool flag = true;
						byte[] byte_ = bytes;
						string string_ = fileName;
						Class136.Class142 @class = new Class136.Class142();
						@class.string_0 = string_;
						@class.byte_0 = byte_;
						@class.bool_0 = false;
						try
						{
							if (flag)
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
							else
							{
								Class136.smethod_15(ref @class.string_0, ref @class.byte_0, @class.bool_0);
							}
						}
						catch (Exception ex)
						{
						}
					}
				}
			}
		}
	}

	// Token: 0x06001682 RID: 5762 RVA: 0x000A9A34 File Offset: 0x000A7C34
	private void method_13(object sender, MouseEventArgs e)
	{
		this.vmethod_20().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_0().Items.Count == 0, false, true));
		this.vmethod_30().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_0().Items.Count > 0, true, false));
		this.vmethod_36().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_0().SelectedObjects.Count > 0, true, false));
		this.vmethod_22().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_0().SelectedObjects.Count > 0, true, false));
		this.vmethod_34().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_0().Items.Count > 0, true, false));
	}

	// Token: 0x06001683 RID: 5763 RVA: 0x000A9B48 File Offset: 0x000A7D48
	private void method_14(object sender, EventArgs e)
	{
		if (this.vmethod_44().Checked)
		{
			this.vmethod_44().Checked = false;
			Class135.smethod_0().ConLogColors = this.vmethod_44().Checked;
		}
		else
		{
			this.vmethod_44().Checked = true;
			Class135.smethod_0().ConLogColors = this.vmethod_44().Checked;
		}
		Class135.smethod_0().Save();
	}

	// Token: 0x04000861 RID: 2145
	private FastObjectListView fastObjectListView_0;

	// Token: 0x04000862 RID: 2146
	private OLVColumn olvcolumn_0;

	// Token: 0x04000863 RID: 2147
	private OLVColumn olvcolumn_1;

	// Token: 0x04000864 RID: 2148
	private OLVColumn olvcolumn_2;

	// Token: 0x04000865 RID: 2149
	private StatusStrip statusStrip_0;

	// Token: 0x04000866 RID: 2150
	private ToolStripStatusLabel toolStripStatusLabel_0;

	// Token: 0x04000867 RID: 2151
	private BackgroundWorker backgroundWorker_0;

	// Token: 0x04000868 RID: 2152
	private System.Windows.Forms.Timer timer_0;

	// Token: 0x04000869 RID: 2153
	private OLVColumn olvcolumn_3;

	// Token: 0x0400086A RID: 2154
	private ContextMenuStrip contextMenuStrip_0;

	// Token: 0x0400086B RID: 2155
	private ToolStripMenuItem toolStripMenuItem_0;

	// Token: 0x0400086C RID: 2156
	private ToolStripMenuItem toolStripMenuItem_1;

	// Token: 0x0400086D RID: 2157
	private ToolStripSeparator toolStripSeparator_0;

	// Token: 0x0400086E RID: 2158
	private ToolStripMenuItem toolStripMenuItem_2;

	// Token: 0x0400086F RID: 2159
	private ToolStripSeparator toolStripSeparator_1;

	// Token: 0x04000870 RID: 2160
	private ToolStripMenuItem toolStripMenuItem_3;

	// Token: 0x04000871 RID: 2161
	private ToolStripSeparator toolStripSeparator_2;

	// Token: 0x04000872 RID: 2162
	private ToolStripMenuItem toolStripMenuItem_4;

	// Token: 0x04000873 RID: 2163
	private ToolStripMenuItem toolStripMenuItem_5;

	// Token: 0x04000874 RID: 2164
	private ToolStripSeparator toolStripSeparator_3;

	// Token: 0x04000875 RID: 2165
	private ToolStripMenuItem toolStripMenuItem_6;

	// Token: 0x04000876 RID: 2166
	private ToolStripMenuItem toolStripMenuItem_7;

	// Token: 0x04000877 RID: 2167
	private ToolStripMenuItem toolStripMenuItem_8;

	// Token: 0x04000878 RID: 2168
	private ToolStripSeparator toolStripSeparator_4;

	// Token: 0x04000879 RID: 2169
	public ConcurrentQueue<cLogCon> concurrentQueue_0;

	// Token: 0x0400087A RID: 2170
	public ConcurrentQueue<cLogCon> concurrentQueue_1;

	// Token: 0x0400087B RID: 2171
	public ConcurrentQueue<cLogCon> concurrentQueue_2;

	// Token: 0x02000197 RID: 407
	// (Invoke) Token: 0x06001687 RID: 5767
	private delegate void Delegate157();

	// Token: 0x02000198 RID: 408
	// (Invoke) Token: 0x0600168B RID: 5771
	private delegate void Delegate158();

	// Token: 0x02000199 RID: 409
	// (Invoke) Token: 0x0600168F RID: 5775
	private delegate void Delegate159();

	// Token: 0x0200019A RID: 410
	// (Invoke) Token: 0x06001693 RID: 5779
	private delegate void Delegate160(string string_0, string string_1, int int_0);
}
