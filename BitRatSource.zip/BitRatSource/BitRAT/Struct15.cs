﻿using System;

// Token: 0x0200007B RID: 123
internal struct Struct15
{
	// Token: 0x040001BC RID: 444
	public int int_0;

	// Token: 0x040001BD RID: 445
	public int int_1;

	// Token: 0x040001BE RID: 446
	public int int_2;

	// Token: 0x040001BF RID: 447
	public int int_3;
}
