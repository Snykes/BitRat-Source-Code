﻿using System;
using System.IO;

// Token: 0x02000062 RID: 98
internal sealed class Stream0 : Stream
{
	// Token: 0x0600034D RID: 845 RVA: 0x000042AD File Offset: 0x000024AD
	public Stream0(Stream stream_1, int int_1)
	{
		this.method_1(stream_1);
		this.int_0 = int_1;
	}

	// Token: 0x0600034E RID: 846 RVA: 0x000042C3 File Offset: 0x000024C3
	public Stream method_0()
	{
		return this.stream_0;
	}

	// Token: 0x0600034F RID: 847 RVA: 0x000042CB File Offset: 0x000024CB
	private void method_1(Stream stream_1)
	{
		this.stream_0 = stream_1;
	}

	// Token: 0x17000003 RID: 3
	// (get) Token: 0x06000350 RID: 848 RVA: 0x000042D4 File Offset: 0x000024D4
	public override bool CanRead
	{
		get
		{
			return this.method_0().CanRead;
		}
	}

	// Token: 0x17000004 RID: 4
	// (get) Token: 0x06000351 RID: 849 RVA: 0x000042E1 File Offset: 0x000024E1
	public override bool CanSeek
	{
		get
		{
			return this.method_0().CanSeek;
		}
	}

	// Token: 0x17000005 RID: 5
	// (get) Token: 0x06000352 RID: 850 RVA: 0x000042EE File Offset: 0x000024EE
	public override bool CanWrite
	{
		get
		{
			return this.method_0().CanWrite;
		}
	}

	// Token: 0x06000353 RID: 851 RVA: 0x000042FB File Offset: 0x000024FB
	public override void Flush()
	{
		this.method_0().Flush();
	}

	// Token: 0x17000006 RID: 6
	// (get) Token: 0x06000354 RID: 852 RVA: 0x00004308 File Offset: 0x00002508
	public override long Length
	{
		get
		{
			return this.method_0().Length;
		}
	}

	// Token: 0x17000007 RID: 7
	// (get) Token: 0x06000355 RID: 853 RVA: 0x00004315 File Offset: 0x00002515
	// (set) Token: 0x06000356 RID: 854 RVA: 0x00004322 File Offset: 0x00002522
	public override long Position
	{
		get
		{
			return this.method_0().Position;
		}
		set
		{
			this.method_0().Position = value;
		}
	}

	// Token: 0x06000357 RID: 855 RVA: 0x0001FAA4 File Offset: 0x0001DCA4
	private byte method_2(byte byte_0, long long_0)
	{
		byte b = (byte)((ulong)this.int_0 | (ulong)long_0);
		return byte_0 ^ b;
	}

	// Token: 0x06000358 RID: 856 RVA: 0x0001FAC0 File Offset: 0x0001DCC0
	public override void Write(byte[] buffer, int offset, int count)
	{
		byte[] array = new byte[count];
		Buffer.BlockCopy(buffer, offset, array, 0, count);
		long position = this.Position;
		for (int i = 0; i < count; i++)
		{
			array[i] = this.method_2(array[i], position + (long)i);
		}
		this.method_0().Write(array, 0, count);
	}

	// Token: 0x06000359 RID: 857 RVA: 0x0001FB10 File Offset: 0x0001DD10
	public override int Read(byte[] buffer, int offset, int count)
	{
		long position = this.Position;
		byte[] array = new byte[count];
		int num = this.method_0().Read(array, 0, count);
		for (int i = 0; i < num; i++)
		{
			buffer[i + offset] = this.method_2(array[i], position + (long)i);
		}
		return num;
	}

	// Token: 0x0600035A RID: 858 RVA: 0x00004330 File Offset: 0x00002530
	public override long Seek(long offset, SeekOrigin origin)
	{
		return this.method_0().Seek(offset, origin);
	}

	// Token: 0x0600035B RID: 859 RVA: 0x0000433F File Offset: 0x0000253F
	public override void SetLength(long value)
	{
		this.method_0().SetLength(value);
	}

	// Token: 0x040001A3 RID: 419
	private readonly int int_0;

	// Token: 0x040001A4 RID: 420
	private Stream stream_0;
}
