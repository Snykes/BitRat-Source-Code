﻿using System;

// Token: 0x02000050 RID: 80
internal interface Interface3
{
	// Token: 0x0600031F RID: 799
	void imethod_0();
}
