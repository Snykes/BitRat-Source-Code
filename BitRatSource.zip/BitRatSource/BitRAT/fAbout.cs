﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

// Token: 0x02000119 RID: 281
[DesignerGenerated]
public sealed partial class fAbout : Form
{
	// Token: 0x06000F52 RID: 3922 RVA: 0x000091A7 File Offset: 0x000073A7
	public fAbout()
	{
		base.Load += this.fAbout_Load;
		base.Closing += this.fAbout_Closing;
		this.InitializeComponent();
	}

	// Token: 0x06000F55 RID: 3925 RVA: 0x000091D9 File Offset: 0x000073D9
	internal PictureBox vmethod_0()
	{
		return this.pictureBox_0;
	}

	// Token: 0x06000F56 RID: 3926 RVA: 0x000091E1 File Offset: 0x000073E1
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_1(PictureBox pictureBox_4)
	{
		this.pictureBox_0 = pictureBox_4;
	}

	// Token: 0x06000F57 RID: 3927 RVA: 0x000091EA File Offset: 0x000073EA
	internal PictureBox vmethod_2()
	{
		return this.pictureBox_1;
	}

	// Token: 0x06000F58 RID: 3928 RVA: 0x00072CD0 File Offset: 0x00070ED0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_3(PictureBox pictureBox_4)
	{
		EventHandler value = new EventHandler(this.method_2);
		PictureBox pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_1 = pictureBox_4;
		pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06000F59 RID: 3929 RVA: 0x000091F2 File Offset: 0x000073F2
	internal PictureBox vmethod_4()
	{
		return this.pictureBox_2;
	}

	// Token: 0x06000F5A RID: 3930 RVA: 0x00072D14 File Offset: 0x00070F14
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_5(PictureBox pictureBox_4)
	{
		EventHandler value = new EventHandler(this.method_1);
		PictureBox pictureBox = this.pictureBox_2;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_2 = pictureBox_4;
		pictureBox = this.pictureBox_2;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06000F5B RID: 3931 RVA: 0x000091FA File Offset: 0x000073FA
	internal Label vmethod_6()
	{
		return this.label_0;
	}

	// Token: 0x06000F5C RID: 3932 RVA: 0x00072D58 File Offset: 0x00070F58
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_7(Label label_9)
	{
		EventHandler value = new EventHandler(this.method_3);
		Label label = this.label_0;
		if (label != null)
		{
			label.Click -= value;
		}
		this.label_0 = label_9;
		label = this.label_0;
		if (label != null)
		{
			label.Click += value;
		}
	}

	// Token: 0x06000F5D RID: 3933 RVA: 0x00009202 File Offset: 0x00007402
	internal Label vmethod_8()
	{
		return this.label_1;
	}

	// Token: 0x06000F5E RID: 3934 RVA: 0x0000920A File Offset: 0x0000740A
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_9(Label label_9)
	{
		this.label_1 = label_9;
	}

	// Token: 0x06000F5F RID: 3935 RVA: 0x00009213 File Offset: 0x00007413
	internal Label vmethod_10()
	{
		return this.label_2;
	}

	// Token: 0x06000F60 RID: 3936 RVA: 0x0000921B File Offset: 0x0000741B
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_11(Label label_9)
	{
		this.label_2 = label_9;
	}

	// Token: 0x06000F61 RID: 3937 RVA: 0x00009224 File Offset: 0x00007424
	internal Label vmethod_12()
	{
		return this.label_3;
	}

	// Token: 0x06000F62 RID: 3938 RVA: 0x0000922C File Offset: 0x0000742C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_13(Label label_9)
	{
		this.label_3 = label_9;
	}

	// Token: 0x06000F63 RID: 3939 RVA: 0x00009235 File Offset: 0x00007435
	internal Label vmethod_14()
	{
		return this.label_4;
	}

	// Token: 0x06000F64 RID: 3940 RVA: 0x00072D9C File Offset: 0x00070F9C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_15(Label label_9)
	{
		EventHandler value = new EventHandler(this.method_4);
		Label label = this.label_4;
		if (label != null)
		{
			label.Click -= value;
		}
		this.label_4 = label_9;
		label = this.label_4;
		if (label != null)
		{
			label.Click += value;
		}
	}

	// Token: 0x06000F65 RID: 3941 RVA: 0x0000923D File Offset: 0x0000743D
	internal Label vmethod_16()
	{
		return this.label_5;
	}

	// Token: 0x06000F66 RID: 3942 RVA: 0x00009245 File Offset: 0x00007445
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_17(Label label_9)
	{
		this.label_5 = label_9;
	}

	// Token: 0x06000F67 RID: 3943 RVA: 0x0000924E File Offset: 0x0000744E
	internal PictureBox vmethod_18()
	{
		return this.pictureBox_3;
	}

	// Token: 0x06000F68 RID: 3944 RVA: 0x00072DE0 File Offset: 0x00070FE0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_19(PictureBox pictureBox_4)
	{
		EventHandler value = new EventHandler(this.method_5);
		PictureBox pictureBox = this.pictureBox_3;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_3 = pictureBox_4;
		pictureBox = this.pictureBox_3;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06000F69 RID: 3945 RVA: 0x00009256 File Offset: 0x00007456
	internal Label vmethod_20()
	{
		return this.label_6;
	}

	// Token: 0x06000F6A RID: 3946 RVA: 0x0000925E File Offset: 0x0000745E
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_21(Label label_9)
	{
		this.label_6 = label_9;
	}

	// Token: 0x06000F6B RID: 3947 RVA: 0x00009267 File Offset: 0x00007467
	internal Label vmethod_22()
	{
		return this.label_7;
	}

	// Token: 0x06000F6C RID: 3948 RVA: 0x0000926F File Offset: 0x0000746F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_23(Label label_9)
	{
		this.label_7 = label_9;
	}

	// Token: 0x06000F6D RID: 3949 RVA: 0x00009278 File Offset: 0x00007478
	internal Label vmethod_24()
	{
		return this.label_8;
	}

	// Token: 0x06000F6E RID: 3950 RVA: 0x00009280 File Offset: 0x00007480
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_25(Label label_9)
	{
		this.label_8 = label_9;
	}

	// Token: 0x06000F6F RID: 3951 RVA: 0x00072E24 File Offset: 0x00071024
	private void fAbout_Load(object sender, EventArgs e)
	{
		this.method_0();
		this.vmethod_6().Text = Class130.struct3_6.method_1();
		checked
		{
			this.vmethod_4().Left = this.vmethod_6().Left + this.vmethod_6().Width + 2;
			this.vmethod_2().Left = this.vmethod_4().Left + this.vmethod_4().Width + 3;
			this.vmethod_18().Left = this.vmethod_14().Left + this.vmethod_14().Width + 2;
		}
	}

	// Token: 0x06000F70 RID: 3952 RVA: 0x00072EB8 File Offset: 0x000710B8
	private void method_0()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O:]*?=\\m", object_);
	}

	// Token: 0x06000F71 RID: 3953 RVA: 0x00009289 File Offset: 0x00007489
	private void method_1(object sender, EventArgs e)
	{
		Clipboard.Clear();
		Clipboard.SetText(this.vmethod_6().Text);
		Interaction.MsgBox("URL copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06000F72 RID: 3954 RVA: 0x00006FA7 File Offset: 0x000051A7
	private void method_2(object sender, EventArgs e)
	{
		if (MessageBox.Show("The URL cannot be visited from a regular web browser without configuring a proxy.\r\n\r\nTherefore, it is recommended to use TorBrowser.\r\nIt's very simple!\r\n\r\nNavigate to https://www.torproject.org/download/?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			Process.Start("https://www.torproject.org/download/");
		}
	}

	// Token: 0x06000F73 RID: 3955 RVA: 0x000092B2 File Offset: 0x000074B2
	private void method_3(object sender, EventArgs e)
	{
		Clipboard.Clear();
		Clipboard.SetText(this.vmethod_6().Text);
		Interaction.MsgBox("URL copied to clipboard!\r\nPlease, visit it from TorBrowser!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06000F74 RID: 3956 RVA: 0x000092DB File Offset: 0x000074DB
	private void method_4(object sender, EventArgs e)
	{
		Clipboard.Clear();
		Clipboard.SetText(this.vmethod_14().Text);
		Interaction.MsgBox("HWID copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06000F75 RID: 3957 RVA: 0x00007348 File Offset: 0x00005548
	private void fAbout_Closing(object sender, CancelEventArgs e)
	{
		base.Visible = false;
		e.Cancel = true;
	}

	// Token: 0x06000F76 RID: 3958 RVA: 0x000092DB File Offset: 0x000074DB
	private void method_5(object sender, EventArgs e)
	{
		Clipboard.Clear();
		Clipboard.SetText(this.vmethod_14().Text);
		Interaction.MsgBox("HWID copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x04000602 RID: 1538
	private PictureBox pictureBox_0;

	// Token: 0x04000603 RID: 1539
	private PictureBox pictureBox_1;

	// Token: 0x04000604 RID: 1540
	private PictureBox pictureBox_2;

	// Token: 0x04000605 RID: 1541
	private Label label_0;

	// Token: 0x04000606 RID: 1542
	private Label label_1;

	// Token: 0x04000607 RID: 1543
	private Label label_2;

	// Token: 0x04000608 RID: 1544
	private Label label_3;

	// Token: 0x04000609 RID: 1545
	private Label label_4;

	// Token: 0x0400060A RID: 1546
	private Label label_5;

	// Token: 0x0400060B RID: 1547
	private PictureBox pictureBox_3;

	// Token: 0x0400060C RID: 1548
	private Label label_6;

	// Token: 0x0400060D RID: 1549
	private Label label_7;

	// Token: 0x0400060E RID: 1550
	private Label label_8;
}
