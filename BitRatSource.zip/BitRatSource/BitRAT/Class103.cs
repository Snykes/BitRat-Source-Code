﻿using System;

// Token: 0x02000046 RID: 70
internal sealed class Class103 : Class94
{
	// Token: 0x060002E6 RID: 742 RVA: 0x00004068 File Offset: 0x00002268
	public bool method_2()
	{
		return this.bool_0;
	}

	// Token: 0x060002E7 RID: 743 RVA: 0x00004070 File Offset: 0x00002270
	public void method_3(bool bool_1)
	{
		this.bool_0 = bool_1;
	}

	// Token: 0x060002E8 RID: 744 RVA: 0x00004079 File Offset: 0x00002279
	public override object vmethod_0()
	{
		return this.method_2();
	}

	// Token: 0x060002E9 RID: 745 RVA: 0x00004086 File Offset: 0x00002286
	public override void vmethod_1(object object_0)
	{
		this.method_3(Convert.ToBoolean(object_0));
	}

	// Token: 0x060002EA RID: 746 RVA: 0x00004094 File Offset: 0x00002294
	public override int vmethod_2()
	{
		return 2;
	}

	// Token: 0x060002EB RID: 747 RVA: 0x0001EE70 File Offset: 0x0001D070
	public override Class94 vmethod_3(Class94 class94_0)
	{
		base.method_1(class94_0.method_0());
		switch (class94_0.vmethod_2())
		{
		case 0:
			this.method_3(Convert.ToBoolean(((Class119)class94_0).method_2()));
			return this;
		case 2:
			this.method_3(((Class103)class94_0).method_2());
			return this;
		case 4:
			this.method_3(Convert.ToBoolean(((Class102)class94_0).method_2()));
			return this;
		case 7:
			this.method_3(Convert.ToBoolean(((Class118)class94_0).method_2()));
			return this;
		case 8:
			this.method_3(Convert.ToBoolean(((Class100)class94_0).method_2()));
			return this;
		case 9:
			this.method_3(Convert.ToBoolean(((Class115)class94_0).method_2()));
			return this;
		case 11:
			this.method_3(Convert.ToBoolean(((Class99)class94_0).method_2()));
			return this;
		case 14:
			this.method_3(Convert.ToBoolean(((Class105)class94_0).method_2()));
			return this;
		case 15:
			this.method_3(Convert.ToBoolean(((Class101)class94_0).method_2()));
			return this;
		case 19:
			this.method_3(Convert.ToBoolean(((Class120)class94_0).method_2()));
			return this;
		case 21:
			this.method_3(Convert.ToBoolean(((Class104)class94_0).method_2()));
			return this;
		case 22:
			this.method_3(Convert.ToBoolean(((Class121)class94_0).method_2()));
			return this;
		case 24:
			this.method_3(Convert.ToBoolean(((Class98)class94_0).method_2()));
			return this;
		}
		throw new ArgumentOutOfRangeException();
	}

	// Token: 0x060002EC RID: 748 RVA: 0x00004097 File Offset: 0x00002297
	public override Class94 vmethod_4()
	{
		Class103 @class = new Class103();
		@class.method_3(this.bool_0);
		@class.method_1(base.method_0());
		return @class;
	}

	// Token: 0x04000186 RID: 390
	private bool bool_0;
}
