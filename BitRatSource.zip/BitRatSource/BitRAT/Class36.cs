﻿using System;

// Token: 0x02000058 RID: 88
internal sealed class Class36 : Class34
{
	// Token: 0x0600032C RID: 812 RVA: 0x000041F4 File Offset: 0x000023F4
	public byte method_0()
	{
		return this.byte_0;
	}

	// Token: 0x0600032D RID: 813 RVA: 0x000041FC File Offset: 0x000023FC
	public void method_1(byte byte_1)
	{
		this.byte_0 = byte_1;
	}

	// Token: 0x0600032E RID: 814 RVA: 0x00004205 File Offset: 0x00002405
	public bool method_2()
	{
		return (this.method_0() & 2) > 0;
	}

	// Token: 0x0600032F RID: 815 RVA: 0x00004212 File Offset: 0x00002412
	public bool method_3()
	{
		return (this.method_0() & 1) > 0;
	}

	// Token: 0x06000330 RID: 816 RVA: 0x0000421F File Offset: 0x0000241F
	public Class3 method_4()
	{
		return this.class3_0;
	}

	// Token: 0x06000331 RID: 817 RVA: 0x00004227 File Offset: 0x00002427
	public void method_5(Class3 class3_4)
	{
		this.class3_0 = class3_4;
	}

	// Token: 0x06000332 RID: 818 RVA: 0x00004230 File Offset: 0x00002430
	public string method_6()
	{
		return this.string_0;
	}

	// Token: 0x06000333 RID: 819 RVA: 0x00004238 File Offset: 0x00002438
	public void method_7(string string_1)
	{
		this.string_0 = string_1;
	}

	// Token: 0x06000334 RID: 820 RVA: 0x00004241 File Offset: 0x00002441
	public Class3[] method_8()
	{
		return this.class3_1;
	}

	// Token: 0x06000335 RID: 821 RVA: 0x00004249 File Offset: 0x00002449
	public void method_9(Class3[] class3_4)
	{
		this.class3_1 = class3_4;
	}

	// Token: 0x06000336 RID: 822 RVA: 0x00004252 File Offset: 0x00002452
	public Class3[] method_10()
	{
		return this.class3_2;
	}

	// Token: 0x06000337 RID: 823 RVA: 0x0000425A File Offset: 0x0000245A
	public void method_11(Class3[] class3_4)
	{
		this.class3_2 = class3_4;
	}

	// Token: 0x06000338 RID: 824 RVA: 0x00004263 File Offset: 0x00002463
	public Class3 method_12()
	{
		return this.class3_3;
	}

	// Token: 0x06000339 RID: 825 RVA: 0x0000426B File Offset: 0x0000246B
	public void method_13(Class3 class3_4)
	{
		this.class3_3 = class3_4;
	}

	// Token: 0x0600033A RID: 826 RVA: 0x00003E26 File Offset: 0x00002026
	public override byte vmethod_0()
	{
		return 4;
	}

	// Token: 0x04000194 RID: 404
	private byte byte_0;

	// Token: 0x04000195 RID: 405
	private Class3 class3_0;

	// Token: 0x04000196 RID: 406
	private string string_0;

	// Token: 0x04000197 RID: 407
	private Class3[] class3_1;

	// Token: 0x04000198 RID: 408
	private Class3[] class3_2;

	// Token: 0x04000199 RID: 409
	private Class3 class3_3;
}
