﻿using System;

// Token: 0x02000038 RID: 56
internal abstract class Class34
{
	// Token: 0x060002AA RID: 682
	public abstract byte vmethod_0();
}
