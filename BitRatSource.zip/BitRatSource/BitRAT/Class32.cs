﻿using System;

// Token: 0x02000036 RID: 54
internal static class Class32
{
	// Token: 0x0600029D RID: 669 RVA: 0x0001DE20 File Offset: 0x0001C020
	private static bool smethod_0<T>(Type type_0)
	{
		Type typeFromHandle = typeof(T);
		return type_0 == typeFromHandle || type_0.IsSubclassOf(typeFromHandle);
	}

	// Token: 0x0600029E RID: 670 RVA: 0x0001DE48 File Offset: 0x0001C048
	public static Class94 smethod_1(object object_0, Type type_0)
	{
		Class94 @class = object_0 as Class94;
		if (@class != null)
		{
			return @class;
		}
		if (type_0 == null)
		{
			if (object_0 == null)
			{
				return new Class102();
			}
			type_0 = object_0.GetType();
		}
		type_0 = Class69.smethod_1(type_0);
		if (type_0 == Class60.type_0)
		{
			@class = new Class102();
			if (object_0 != null && object_0.GetType() != Class60.type_0)
			{
				@class.method_1(object_0.GetType());
			}
		}
		else if (Class32.smethod_0<Array>(type_0))
		{
			@class = new Class116();
		}
		else if (Class32.smethod_0<string>(type_0))
		{
			@class = new Class113();
		}
		else if (Class32.smethod_0<IntPtr>(type_0))
		{
			@class = new Class105();
		}
		else if (Class32.smethod_0<UIntPtr>(type_0))
		{
			@class = new Class100();
		}
		else if (Class32.smethod_0<ulong>(type_0))
		{
			@class = new Class120();
		}
		else if (Class32.smethod_0<uint>(type_0))
		{
			@class = new Class104();
		}
		else if (Class32.smethod_0<ushort>(type_0))
		{
			@class = new Class119();
		}
		else if (Class32.smethod_0<long>(type_0))
		{
			@class = new Class99();
		}
		else if (Class32.smethod_0<int>(type_0))
		{
			@class = new Class118();
		}
		else if (Class32.smethod_0<short>(type_0))
		{
			@class = new Class101();
		}
		else if (Class32.smethod_0<byte>(type_0))
		{
			@class = new Class121();
		}
		else if (Class32.smethod_0<sbyte>(type_0))
		{
			@class = new Class115();
		}
		else if (Class32.smethod_0<double>(type_0))
		{
			@class = new Class117();
		}
		else if (Class32.smethod_0<float>(type_0))
		{
			@class = new Class114();
		}
		else if (Class32.smethod_0<bool>(type_0))
		{
			@class = new Class103();
		}
		else if (Class32.smethod_0<char>(type_0))
		{
			@class = new Class95();
		}
		else if (Class60.smethod_0(type_0))
		{
			Class102 class2 = new Class102();
			class2.method_1(type_0);
			@class = class2;
		}
		else
		{
			if (Class32.smethod_0<Enum>(type_0))
			{
				Enum enum_;
				if (object_0 == null)
				{
					if (type_0 == Class60.type_2)
					{
						enum_ = null;
					}
					else
					{
						enum_ = (Enum)Activator.CreateInstance(type_0);
					}
				}
				else if (type_0 == Class60.type_2 && object_0 is Enum)
				{
					enum_ = (Enum)object_0;
				}
				else
				{
					enum_ = (Enum)Enum.ToObject(type_0, object_0);
				}
				return new Class98(enum_);
			}
			if (Class32.smethod_0<ValueType>(type_0))
			{
				if (object_0 == null)
				{
					object object_;
					if (type_0 == Class60.type_3)
					{
						object_ = null;
					}
					else
					{
						object_ = Activator.CreateInstance(type_0);
					}
					@class = new Class96(object_);
				}
				else
				{
					if (object_0.GetType() != type_0)
					{
						try
						{
							object_0 = Convert.ChangeType(object_0, type_0);
						}
						catch
						{
						}
					}
					@class = new Class96(object_0);
				}
				return @class;
			}
			@class = new Class102();
		}
		if (object_0 != null)
		{
			@class.vmethod_1(object_0);
		}
		return @class;
	}
}
