﻿using System;
using System.IO;
using System.IO.Compression;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using System.Xml.Serialization;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace BitRAT
{
	// Token: 0x020001E0 RID: 480
	public sealed class cIPInfo
	{
		// Token: 0x06001AAA RID: 6826 RVA: 0x0000DA3D File Offset: 0x0000BC3D
		public cIPInfo()
		{
			this.bool_0 = false;
		}

		// Token: 0x06001AAB RID: 6827 RVA: 0x0000DA4C File Offset: 0x0000BC4C
		public void method_0(Form form_0)
		{
			Class130.fMain_0 = (fMain)form_0;
		}

		// Token: 0x06001AAC RID: 6828 RVA: 0x000BA8DC File Offset: 0x000B8ADC
		[MethodImpl(MethodImplOptions.NoOptimization)]
		public void method_1()
		{
			XmlSerializer xmlSerializer = new XmlSerializer(typeof(cIPInfo.STRUCT_GEO[]));
			if (File.Exists(Application.StartupPath + "\\data\\db\\ipdb.bin"))
			{
				try
				{
					using (FileStream fileStream = File.OpenRead(Application.StartupPath + "\\data\\db\\ipdb.bin"))
					{
						using (DeflateStream deflateStream = new DeflateStream(fileStream, CompressionMode.Decompress))
						{
							Class130.struct_GEO_0 = (cIPInfo.STRUCT_GEO[])xmlSerializer.Deserialize(deflateStream);
							this.bool_0 = true;
							Thread.Sleep(500);
						}
					}
					goto IL_BD;
				}
				catch (Exception ex)
				{
					Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical, Application.ProductName);
					ProjectData.EndApp();
					Thread.Sleep(2000);
					goto IL_BD;
				}
			}
			Thread.Sleep(2000);
			IL_BD:
			if (Class130.fMain_0.InvokeRequired)
			{
				Class130.fMain_0.Invoke(new cIPInfo.Delegate205(this.method_2), new object[0]);
			}
			else
			{
				fMain fMain_ = Class130.fMain_0;
				fMain fMain_2;
				ToolStripProgressBar toolStripProgressBar_ = (fMain_2 = Class130.fMain_0).vmethod_16();
				ToolStripProgressBar toolStripProgressBar;
				long num = (long)(toolStripProgressBar = Class130.fMain_0.vmethod_16()).Maximum;
				fMain_.method_40(ref toolStripProgressBar_, ref num);
				toolStripProgressBar.Maximum = checked((int)num);
				fMain_2.vmethod_17(toolStripProgressBar_);
				fMain fMain_3 = Class130.fMain_0;
				toolStripProgressBar = (fMain_2 = Class130.fMain_0).vmethod_16();
				num = 0L;
				fMain_3.method_40(ref toolStripProgressBar, ref num);
				fMain_2.vmethod_17(toolStripProgressBar);
				Class130.fMain_0.struct18_0.method_1(true);
				Class130.fMain_0.vmethod_156().RunWorkerAsync();
			}
		}

		// Token: 0x06001AAD RID: 6829 RVA: 0x000BAA98 File Offset: 0x000B8C98
		public void method_2()
		{
			if (Class130.fMain_0.InvokeRequired)
			{
				Class130.fMain_0.Invoke(new cIPInfo.Delegate205(this.method_2), new object[0]);
				return;
			}
			fMain fMain_ = Class130.fMain_0;
			fMain fMain_2;
			ToolStripProgressBar toolStripProgressBar_ = (fMain_2 = Class130.fMain_0).vmethod_16();
			ToolStripProgressBar toolStripProgressBar;
			long num = (long)(toolStripProgressBar = Class130.fMain_0.vmethod_16()).Maximum;
			fMain_.method_40(ref toolStripProgressBar_, ref num);
			toolStripProgressBar.Maximum = checked((int)num);
			fMain_2.vmethod_17(toolStripProgressBar_);
			fMain fMain_3 = Class130.fMain_0;
			toolStripProgressBar = (fMain_2 = Class130.fMain_0).vmethod_16();
			num = 0L;
			fMain_3.method_40(ref toolStripProgressBar, ref num);
			fMain_2.vmethod_17(toolStripProgressBar);
			Class130.fMain_0.struct18_0.method_1(true);
			Class130.fMain_0.vmethod_156().RunWorkerAsync();
		}

		// Token: 0x06001AAE RID: 6830 RVA: 0x000BAB58 File Offset: 0x000B8D58
		public cIPInfo.STRUCT_GEO method_3(string string_0)
		{
			long num = this.method_4(string_0);
			long num2 = 0L;
			long num3 = (long)Information.UBound(Class130.struct_GEO_0, 1);
			checked
			{
				while (num2 <= num3)
				{
					long num4 = (num3 - num2) / 2L + num2;
					if (num < Class130.struct_GEO_0[(int)num4].IPStart)
					{
						num3 = num4 - 1L;
					}
					else
					{
						if (num <= Class130.struct_GEO_0[(int)num4].IPEnd)
						{
							return Class130.struct_GEO_0[(int)num4];
						}
						num2 = num4 + 1L;
					}
				}
				return default(cIPInfo.STRUCT_GEO);
			}
		}

		// Token: 0x06001AAF RID: 6831 RVA: 0x000BABF8 File Offset: 0x000B8DF8
		public long method_4(string string_0)
		{
			string[] array = Strings.Split(string_0, ".", -1, CompareMethod.Text);
			int num = Information.UBound(array, 1);
			checked
			{
				long num2;
				for (int i = 0; i <= num; i++)
				{
					num2 = (long)Math.Round(unchecked((double)num2 + (double)Conversions.ToLong(array[i]) * Math.Pow(256.0, (double)(checked(3 - i)))));
				}
				return num2;
			}
		}

		// Token: 0x04000A28 RID: 2600
		public bool bool_0;

		// Token: 0x020001E1 RID: 481
		// (Invoke) Token: 0x06001AB3 RID: 6835
		private delegate void Delegate205();

		// Token: 0x020001E2 RID: 482
		[Serializable]
		public struct STRUCT_GEO
		{
			// Token: 0x04000A29 RID: 2601
			public string CountryCode;

			// Token: 0x04000A2A RID: 2602
			public long IPStart;

			// Token: 0x04000A2B RID: 2603
			public long IPEnd;
		}
	}
}
