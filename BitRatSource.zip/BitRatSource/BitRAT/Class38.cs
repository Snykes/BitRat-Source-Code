﻿using System;

// Token: 0x02000079 RID: 121
internal sealed class Class38 : Class34
{
	// Token: 0x060003DB RID: 987 RVA: 0x000047FE File Offset: 0x000029FE
	public Class3 method_0()
	{
		return this.class3_0;
	}

	// Token: 0x060003DC RID: 988 RVA: 0x00004806 File Offset: 0x00002A06
	public void method_1(Class3 class3_1)
	{
		this.class3_0 = class3_1;
	}

	// Token: 0x060003DD RID: 989 RVA: 0x0000480F File Offset: 0x00002A0F
	public string method_2()
	{
		return this.string_0;
	}

	// Token: 0x060003DE RID: 990 RVA: 0x00004817 File Offset: 0x00002A17
	public void method_3(string string_1)
	{
		this.string_0 = string_1;
	}

	// Token: 0x060003DF RID: 991 RVA: 0x00004820 File Offset: 0x00002A20
	public bool method_4()
	{
		return this.bool_0;
	}

	// Token: 0x060003E0 RID: 992 RVA: 0x00004828 File Offset: 0x00002A28
	public void method_5(bool bool_1)
	{
		this.bool_0 = bool_1;
	}

	// Token: 0x060003E1 RID: 993 RVA: 0x00002E1C File Offset: 0x0000101C
	public override byte vmethod_0()
	{
		return 0;
	}

	// Token: 0x040001B8 RID: 440
	private Class3 class3_0;

	// Token: 0x040001B9 RID: 441
	private string string_0;

	// Token: 0x040001BA RID: 442
	private bool bool_0;
}
