﻿using System;

// Token: 0x02000095 RID: 149
internal sealed class Class86
{
	// Token: 0x06000487 RID: 1159 RVA: 0x00004D8E File Offset: 0x00002F8E
	public Class12[] method_0()
	{
		return this.class12_0;
	}

	// Token: 0x06000488 RID: 1160 RVA: 0x00004D96 File Offset: 0x00002F96
	public void method_1(Class12[] class12_1)
	{
		this.class12_0 = class12_1;
	}

	// Token: 0x06000489 RID: 1161 RVA: 0x00004D9F File Offset: 0x00002F9F
	public Class70[] method_2()
	{
		return this.class70_0;
	}

	// Token: 0x0600048A RID: 1162 RVA: 0x00004DA7 File Offset: 0x00002FA7
	public void method_3(Class70[] class70_1)
	{
		this.class70_0 = class70_1;
	}

	// Token: 0x0600048B RID: 1163 RVA: 0x00004DB0 File Offset: 0x00002FB0
	public string method_4()
	{
		return this.string_0;
	}

	// Token: 0x0600048C RID: 1164 RVA: 0x00004DB8 File Offset: 0x00002FB8
	public void method_5(string string_1)
	{
		this.string_0 = string_1;
	}

	// Token: 0x0600048D RID: 1165 RVA: 0x00004DC1 File Offset: 0x00002FC1
	public int method_6()
	{
		return this.int_0;
	}

	// Token: 0x0600048E RID: 1166 RVA: 0x00004DC9 File Offset: 0x00002FC9
	public void method_7(int int_2)
	{
		this.int_0 = int_2;
	}

	// Token: 0x0600048F RID: 1167 RVA: 0x00004DD2 File Offset: 0x00002FD2
	public int method_8()
	{
		return this.int_1;
	}

	// Token: 0x06000490 RID: 1168 RVA: 0x00004DDA File Offset: 0x00002FDA
	public void method_9(int int_2)
	{
		this.int_1 = int_2;
	}

	// Token: 0x06000491 RID: 1169 RVA: 0x00004DE3 File Offset: 0x00002FE3
	public byte method_10()
	{
		return this.byte_0;
	}

	// Token: 0x06000492 RID: 1170 RVA: 0x00004DEB File Offset: 0x00002FEB
	public void method_11(byte byte_1)
	{
		this.byte_0 = byte_1;
	}

	// Token: 0x06000493 RID: 1171 RVA: 0x00004DF4 File Offset: 0x00002FF4
	public bool method_12()
	{
		return (this.method_10() & 8) > 0;
	}

	// Token: 0x06000494 RID: 1172 RVA: 0x00004E01 File Offset: 0x00003001
	public bool method_13()
	{
		return (this.method_10() & 4) > 0;
	}

	// Token: 0x06000495 RID: 1173 RVA: 0x00004E0E File Offset: 0x0000300E
	public bool method_14()
	{
		return (this.method_10() & 2) > 0;
	}

	// Token: 0x040001DE RID: 478
	private Class12[] class12_0;

	// Token: 0x040001DF RID: 479
	private int int_0;

	// Token: 0x040001E0 RID: 480
	private Class70[] class70_0;

	// Token: 0x040001E1 RID: 481
	private string string_0;

	// Token: 0x040001E2 RID: 482
	private int int_1;

	// Token: 0x040001E3 RID: 483
	private byte byte_0;
}
