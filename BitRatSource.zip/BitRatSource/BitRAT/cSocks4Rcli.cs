﻿using System;
using System.Linq;
using System.Runtime.InteropServices;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace BitRAT
{
	// Token: 0x020001E5 RID: 485
	public class cSocks4Rcli
	{
		// Token: 0x06001AD4 RID: 6868 RVA: 0x000BACE4 File Offset: 0x000B8EE4
		public cSocks4Rcli()
		{
			this.idxValues = new string[9];
			bool flag;
			checked
			{
				int num = this.idxValues.Count<string>() - 1;
				for (int i = 1; i <= num; i++)
				{
					this.idxValues[i] = "N/A";
				}
				Class136.Struct27 @struct = default(Class136.Struct27);
				@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
				flag = false;
				if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
				{
					flag = true;
				}
			}
			long num2;
			if (flag)
			{
				num2 = Class136.GetTickCount64();
			}
			else
			{
				num2 = (long)Class136.GetTickCount();
			}
			long num3 = num2;
			this.lStarted = num3;
		}

		// Token: 0x1700008C RID: 140
		// (get) Token: 0x06001AD5 RID: 6869 RVA: 0x0000DB92 File Offset: 0x0000BD92
		// (set) Token: 0x06001AD6 RID: 6870 RVA: 0x0000DB9C File Offset: 0x0000BD9C
		public string USER
		{
			get
			{
				return this.idxValues[0];
			}
			set
			{
				this.idxValues[0] = value;
			}
		}

		// Token: 0x1700008D RID: 141
		// (get) Token: 0x06001AD7 RID: 6871 RVA: 0x0000DBA7 File Offset: 0x0000BDA7
		// (set) Token: 0x06001AD8 RID: 6872 RVA: 0x0000DBB1 File Offset: 0x0000BDB1
		public string PORT
		{
			get
			{
				return this.idxValues[1];
			}
			set
			{
				this.idxValues[1] = value;
			}
		}

		// Token: 0x1700008E RID: 142
		// (get) Token: 0x06001AD9 RID: 6873 RVA: 0x0000DBBC File Offset: 0x0000BDBC
		// (set) Token: 0x06001ADA RID: 6874 RVA: 0x0000DBC6 File Offset: 0x0000BDC6
		public string DURATION
		{
			get
			{
				return this.idxValues[2];
			}
			set
			{
				this.idxValues[2] = value;
			}
		}

		// Token: 0x1700008F RID: 143
		// (get) Token: 0x06001ADB RID: 6875 RVA: 0x0000DBD1 File Offset: 0x0000BDD1
		// (set) Token: 0x06001ADC RID: 6876 RVA: 0x0000DBDB File Offset: 0x0000BDDB
		public string IP
		{
			get
			{
				return this.idxValues[3];
			}
			set
			{
				this.idxValues[3] = value;
			}
		}

		// Token: 0x17000090 RID: 144
		// (get) Token: 0x06001ADD RID: 6877 RVA: 0x000BAD84 File Offset: 0x000B8F84
		// (set) Token: 0x06001ADE RID: 6878 RVA: 0x0000DBE6 File Offset: 0x0000BDE6
		public string SENT
		{
			get
			{
				double num = this.dSent;
				bool flag = false;
				ref bool ptr = ref flag;
				double num2 = num;
				int num3;
				string result;
				int num4;
				object obj;
				try
				{
					ProjectData.ClearProjectError();
					num3 = 2;
					string text = string.Empty;
					if (num2 >= 1099511627776.0)
					{
						text = Strings.Format(num2 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
					}
					else if (num2 >= 1073741824.0)
					{
						text = Strings.Format(num2 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
					}
					else if (num2 >= 1048576.0)
					{
						text = Strings.Format(num2 / 1024.0 / 1024.0, "#0.00") + " MiB";
					}
					else if (num2 >= 1024.0)
					{
						text = Strings.Format(num2 / 1024.0, "#0.00") + " KiB";
					}
					else if (num2 < 1024.0)
					{
						text = Conversions.ToString(Conversion.Fix(num2)) + " B";
					}
					if (ptr)
					{
						text = Strings.Split(text, " ", -1, CompareMethod.Text)[0];
					}
					if (text.Length > 0)
					{
						result = text;
					}
					else
					{
						result = " 0 B";
					}
					IL_17B:
					goto IL_1CA;
					IL_17D:
					result = "0 B";
					goto IL_17B;
					IL_185:
					num4 = -1;
					@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
					IL_19B:;
				}
				catch when (endfilter(obj is Exception & num3 != 0 & num4 == 0))
				{
					Exception ex = (Exception)obj2;
					goto IL_185;
				}
				throw ProjectData.CreateProjectError(-2146828237);
				IL_1CA:
				if (num4 != 0)
				{
					ProjectData.ClearProjectError();
				}
				return result;
			}
			set
			{
				this.dSent = Conversions.ToDouble(value);
			}
		}

		// Token: 0x17000091 RID: 145
		// (get) Token: 0x06001ADF RID: 6879 RVA: 0x000BAF84 File Offset: 0x000B9184
		// (set) Token: 0x06001AE0 RID: 6880 RVA: 0x0000DBF4 File Offset: 0x0000BDF4
		public string RECV
		{
			get
			{
				double num = this.dRecv;
				bool flag = false;
				ref bool ptr = ref flag;
				double num2 = num;
				int num3;
				string result;
				int num4;
				object obj;
				try
				{
					ProjectData.ClearProjectError();
					num3 = 2;
					string text = string.Empty;
					if (num2 >= 1099511627776.0)
					{
						text = Strings.Format(num2 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
					}
					else if (num2 >= 1073741824.0)
					{
						text = Strings.Format(num2 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
					}
					else if (num2 >= 1048576.0)
					{
						text = Strings.Format(num2 / 1024.0 / 1024.0, "#0.00") + " MiB";
					}
					else if (num2 >= 1024.0)
					{
						text = Strings.Format(num2 / 1024.0, "#0.00") + " KiB";
					}
					else if (num2 < 1024.0)
					{
						text = Conversions.ToString(Conversion.Fix(num2)) + " B";
					}
					if (ptr)
					{
						text = Strings.Split(text, " ", -1, CompareMethod.Text)[0];
					}
					if (text.Length > 0)
					{
						result = text;
					}
					else
					{
						result = " 0 B";
					}
					IL_17B:
					goto IL_1CA;
					IL_17D:
					result = "0 B";
					goto IL_17B;
					IL_185:
					num4 = -1;
					@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
					IL_19B:;
				}
				catch when (endfilter(obj is Exception & num3 != 0 & num4 == 0))
				{
					Exception ex = (Exception)obj2;
					goto IL_185;
				}
				throw ProjectData.CreateProjectError(-2146828237);
				IL_1CA:
				if (num4 != 0)
				{
					ProjectData.ClearProjectError();
				}
				return result;
			}
			set
			{
				this.dRecv = Conversions.ToDouble(value);
			}
		}

		// Token: 0x17000092 RID: 146
		// (get) Token: 0x06001AE1 RID: 6881 RVA: 0x0000DC02 File Offset: 0x0000BE02
		// (set) Token: 0x06001AE2 RID: 6882 RVA: 0x0000DC0C File Offset: 0x0000BE0C
		public string TARGET
		{
			get
			{
				return this.idxValues[6];
			}
			set
			{
				this.idxValues[6] = value;
			}
		}

		// Token: 0x17000093 RID: 147
		// (get) Token: 0x06001AE3 RID: 6883 RVA: 0x0000DC17 File Offset: 0x0000BE17
		// (set) Token: 0x06001AE4 RID: 6884 RVA: 0x0000DC21 File Offset: 0x0000BE21
		public string SPEED_DL
		{
			get
			{
				return this.idxValues[7];
			}
			set
			{
				this.idxValues[7] = value;
			}
		}

		// Token: 0x17000094 RID: 148
		// (get) Token: 0x06001AE5 RID: 6885 RVA: 0x0000DC2C File Offset: 0x0000BE2C
		// (set) Token: 0x06001AE6 RID: 6886 RVA: 0x0000DC36 File Offset: 0x0000BE36
		public string SPEED_UL
		{
			get
			{
				return this.idxValues[8];
			}
			set
			{
				this.idxValues[8] = value;
			}
		}

		// Token: 0x17000095 RID: 149
		// (get) Token: 0x06001AE7 RID: 6887 RVA: 0x0000DC41 File Offset: 0x0000BE41
		// (set) Token: 0x06001AE8 RID: 6888 RVA: 0x0000DC49 File Offset: 0x0000BE49
		public string Tag
		{
			get
			{
				return this.m_tag;
			}
			set
			{
				this.m_tag = value;
			}
		}

		// Token: 0x04000A41 RID: 2625
		public string[] idxValues;

		// Token: 0x04000A42 RID: 2626
		public string Key;

		// Token: 0x04000A43 RID: 2627
		private string m_user;

		// Token: 0x04000A44 RID: 2628
		private string m_port;

		// Token: 0x04000A45 RID: 2629
		private string m_duration;

		// Token: 0x04000A46 RID: 2630
		private string m_tag;

		// Token: 0x04000A47 RID: 2631
		public bool bJustConnected;

		// Token: 0x04000A48 RID: 2632
		public bool pending_dc;

		// Token: 0x04000A49 RID: 2633
		public bool pending_dc_timeout;

		// Token: 0x04000A4A RID: 2634
		public bool rejected;

		// Token: 0x04000A4B RID: 2635
		public long lStarted;

		// Token: 0x04000A4C RID: 2636
		public double dRecv;

		// Token: 0x04000A4D RID: 2637
		public double dSent;
	}
}
