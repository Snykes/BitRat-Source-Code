﻿using System;

// Token: 0x020001BD RID: 445
public enum GEnum2
{

}
