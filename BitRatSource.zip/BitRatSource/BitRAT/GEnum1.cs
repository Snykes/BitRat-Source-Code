﻿using System;

// Token: 0x020001BB RID: 443
public enum GEnum1
{

}
