﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.ExceptionServices;
using System.Runtime.InteropServices;
using System.Security;
using System.Threading;

// Token: 0x02000008 RID: 8
internal sealed class Class4
{
	// Token: 0x0600002A RID: 42 RVA: 0x0000E4E8 File Offset: 0x0000C6E8
	public Class4(Class16 class16_1, Module module_1)
	{
		this.dictionary_2 = new Dictionary<MethodBase, object>();
		this.class20_1 = new Class20<Class4.Struct1>();
		this.class20_0 = new Class20<Class94>();
		base..ctor();
		this.class16_0 = class16_1;
		this.module_0 = module_1;
		this.method_233();
	}

	// Token: 0x0600002B RID: 43 RVA: 0x00002DB4 File Offset: 0x00000FB4
	public Class4(Class16 class16_1) : this(class16_1, typeof(Class4).Module)
	{
	}

	// Token: 0x0600002C RID: 44 RVA: 0x0000E550 File Offset: 0x0000C750
	// Note: this type is marked as 'beforefieldinit'.
	static Class4()
	{
		Class4.object_1 = new object();
		Class4.type_1 = typeof(void);
		Class4.type_0 = typeof(object[]);
		Class4.type_8 = typeof(IntPtr);
		Class4.type_5 = typeof(Assembly);
		Class4.type_3 = typeof(MethodBase);
		Class4.type_6 = typeof(RuntimeHelpers);
	}

	// Token: 0x0600002D RID: 45 RVA: 0x0000E5D8 File Offset: 0x0000C7D8
	private FieldInfo method_0(int int_0, Class3 class3_0, ref bool bool_2)
	{
		if (class3_0.method_0() == 1)
		{
			bool_2 = false;
			return this.module_0.ResolveField(class3_0.method_2());
		}
		Class38 @class = (Class38)class3_0.method_4();
		Type type = this.method_189(@class.method_0().method_2(), false);
		if (type.IsGenericType)
		{
			bool_2 = false;
		}
		BindingFlags bindingAttr = Class4.smethod_12(@class.method_4());
		return type.GetField(@class.method_2(), bindingAttr);
	}

	// Token: 0x0600002E RID: 46 RVA: 0x0000E644 File Offset: 0x0000C844
	private Class94 method_1(Class94 class94_2, Class94 class94_3)
	{
		if (class94_2.vmethod_2() == 7)
		{
			if (class94_3.vmethod_2() == 7)
			{
				int num = ((Class118)class94_2).method_2();
				int num2 = ((Class118)class94_3).method_2();
				Class118 @class = new Class118();
				@class.method_3(num & num2);
				return @class;
			}
			if (class94_3.vmethod_2() == 24)
			{
				int num3 = ((Class118)class94_2).method_2();
				Type underlyingType = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
				if (underlyingType != typeof(long))
				{
					if (underlyingType != typeof(ulong))
					{
						int num4 = Convert.ToInt32(class94_3.vmethod_0());
						Class118 class2 = new Class118();
						class2.method_3(num3 & num4);
						return class2;
					}
				}
				long num5 = Convert.ToInt64(class94_3.vmethod_0());
				Class99 class3 = new Class99();
				class3.method_3((long)num3 & num5);
				return class3;
			}
		}
		if (class94_2.vmethod_2() == 11)
		{
			if (class94_3.vmethod_2() == 11)
			{
				long num6 = ((Class99)class94_2).method_2();
				long num7 = ((Class99)class94_3).method_2();
				Class99 class4 = new Class99();
				class4.method_3(num6 & num7);
				return class4;
			}
			if (class94_3.vmethod_2() == 24)
			{
				int num8 = ((Class118)class94_2).method_2();
				long num9 = Convert.ToInt64(class94_3.vmethod_0());
				Class99 class5 = new Class99();
				class5.method_3((long)num8 & num9);
				return class5;
			}
		}
		if (class94_2.vmethod_2() == 24)
		{
			if (class94_3.vmethod_2() == 7)
			{
				int num10 = ((Class118)class94_3).method_2();
				Type underlyingType2 = Enum.GetUnderlyingType(class94_2.vmethod_0().GetType());
				if (underlyingType2 != typeof(long))
				{
					if (underlyingType2 != typeof(ulong))
					{
						int num11 = Convert.ToInt32(class94_2.vmethod_0());
						Class118 class6 = new Class118();
						class6.method_3(num11 & num10);
						return class6;
					}
				}
				long num12 = Convert.ToInt64(class94_3.vmethod_0());
				Class99 class7 = new Class99();
				class7.method_3(num12 & (long)num10);
				return class7;
			}
			if (class94_3.vmethod_2() == 11)
			{
				long num13 = Convert.ToInt64(class94_2.vmethod_0());
				long num14 = ((Class99)class94_3).method_2();
				Class99 class8 = new Class99();
				class8.method_3(num13 & num14);
				return class8;
			}
			if (class94_3.vmethod_2() == 24)
			{
				Type underlyingType3 = Enum.GetUnderlyingType(class94_2.vmethod_0().GetType());
				Type underlyingType4 = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
				if (underlyingType3 != typeof(long) && underlyingType3 != typeof(ulong) && underlyingType4 != typeof(long))
				{
					if (underlyingType4 != typeof(ulong))
					{
						int num15 = Convert.ToInt32(class94_2.vmethod_0());
						int num16 = Convert.ToInt32(class94_3.vmethod_0());
						Class118 class9 = new Class118();
						class9.method_3(num15 & num16);
						return class9;
					}
				}
				long num17 = Convert.ToInt64(class94_2.vmethod_0());
				long num18 = Convert.ToInt64(class94_3.vmethod_0());
				Class99 class10 = new Class99();
				class10.method_3(num17 & num18);
				return class10;
			}
		}
		throw new InvalidOperationException();
	}

	// Token: 0x0600002F RID: 47 RVA: 0x00002DCC File Offset: 0x00000FCC
	private void method_2(Class94 class94_2)
	{
		this.method_109(typeof(float));
	}

	// Token: 0x06000030 RID: 48 RVA: 0x0000E90C File Offset: 0x0000CB0C
	private void method_3(Class94 class94_2)
	{
		MethodBase methodBase_ = ((Class97)this.method_300()).method_2();
		this.method_124(methodBase_, false);
	}

	// Token: 0x06000031 RID: 49 RVA: 0x0000E934 File Offset: 0x0000CB34
	private object method_4(int int_0)
	{
		int num = Class54.smethod_0(int_0);
		object result;
		if (num > 67108864)
		{
			if (num <= 167772160)
			{
				if (num == 100663296)
				{
					goto IL_C4;
				}
				if (num != 167772160)
				{
					goto IL_BE;
				}
				try
				{
					return this.module_0.ModuleHandle.ResolveFieldHandle(int_0);
				}
				catch
				{
					try
					{
						result = this.module_0.ModuleHandle.ResolveMethodHandle(int_0);
					}
					catch
					{
						throw new InvalidOperationException();
					}
					return result;
				}
			}
			if (num == 452984832)
			{
				goto IL_E0;
			}
			if (num != 721420288)
			{
				goto IL_BE;
			}
			IL_C4:
			return this.module_0.ModuleHandle.ResolveMethodHandle(int_0);
		}
		if (num == 16777216 || num == 33554432)
		{
			goto IL_E0;
		}
		if (num == 67108864)
		{
			return this.module_0.ModuleHandle.ResolveFieldHandle(int_0);
		}
		IL_BE:
		throw new InvalidOperationException();
		IL_E0:
		result = this.module_0.ModuleHandle.ResolveTypeHandle(int_0);
		return result;
	}

	// Token: 0x06000032 RID: 50 RVA: 0x0000EA58 File Offset: 0x0000CC58
	private void method_5(bool bool_2)
	{
		Class94 @class = this.method_300();
		int num = @class.vmethod_2();
		long long_;
		if (num <= 11)
		{
			if (num != 7)
			{
				if (num == 11)
				{
					if (bool_2)
					{
						long_ = ((Class99)@class).method_2();
						goto IL_BA;
					}
					long_ = ((Class99)@class).method_2();
					goto IL_BA;
				}
			}
			else
			{
				if (bool_2)
				{
					long_ = (long)((Class118)@class).method_2();
					goto IL_BA;
				}
				long_ = (long)((Class118)@class).method_2();
				goto IL_BA;
			}
		}
		else if (num != 17)
		{
			if (num == 24)
			{
				if (bool_2)
				{
					long_ = checked((long)Convert.ToUInt64(((Class98)@class).method_2()));
					goto IL_BA;
				}
				long_ = (long)Convert.ToUInt64(((Class98)@class).method_2());
				goto IL_BA;
			}
		}
		else
		{
			if (bool_2)
			{
				long_ = checked((long)((Class117)@class).method_2());
				goto IL_BA;
			}
			long_ = (long)((Class117)@class).method_2();
			goto IL_BA;
		}
		throw new InvalidOperationException();
		IL_BA:
		Class99 class2 = new Class99();
		class2.method_3(long_);
		this.method_195(class2);
	}

	// Token: 0x06000033 RID: 51 RVA: 0x00002DDE File Offset: 0x00000FDE
	private void method_6(Class94 class94_2)
	{
		Class118 @class = new Class118();
		@class.method_3(1);
		this.method_195(@class);
	}

	// Token: 0x06000034 RID: 52 RVA: 0x0000EB34 File Offset: 0x0000CD34
	private void method_7(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		Class94 class94_4 = this.method_300();
		Class118 @class = new Class118();
		@class.method_3(Class4.smethod_20(class94_4, class94_3) ? 1 : 0);
		this.method_195(@class);
	}

	// Token: 0x06000035 RID: 53 RVA: 0x00002DF2 File Offset: 0x00000FF2
	private void method_8(Class94 class94_2)
	{
		this.method_275();
	}

	// Token: 0x06000036 RID: 54 RVA: 0x00002DF2 File Offset: 0x00000FF2
	private void method_9(Class94 class94_2)
	{
		this.method_275();
	}

	// Token: 0x06000037 RID: 55 RVA: 0x0000EB70 File Offset: 0x0000CD70
	private bool method_10(MethodBase methodBase_0, object object_3, Class94[] class94_2, object[] object_4, bool bool_2, ref object object_5)
	{
		Type declaringType = methodBase_0.DeclaringType;
		if (declaringType == null)
		{
			return false;
		}
		if (declaringType == Class4.type_6 && methodBase_0.Name == "InitializeArray" && object_4.Length == 2)
		{
			string a = methodBase_0.ToString();
			if (a == "Void InitializeArray(System.Array, System.RuntimeFieldHandle)")
			{
				Class10.smethod_0((Array)object_4[0], (RuntimeFieldHandle)object_4[1]);
				return true;
			}
		}
		return false;
	}

	// Token: 0x06000038 RID: 56 RVA: 0x0000EBD8 File Offset: 0x0000CDD8
	private long method_11(string string_0)
	{
		MemoryStream memoryStream = new MemoryStream(Class55.smethod_0(string_0));
		long result = new Class31(new Class51(memoryStream, this.method_57())).method_21();
		memoryStream.Dispose();
		return result;
	}

	// Token: 0x06000039 RID: 57 RVA: 0x0000EC10 File Offset: 0x0000CE10
	private void method_12(Class94 class94_2)
	{
		Class118 @class = (Class118)class94_2;
		MethodBase methodBase = this.method_234(@class.method_2());
		if (this.type_4 != null)
		{
			ParameterInfo[] parameters = methodBase.GetParameters();
			Type[] array = new Type[parameters.Length];
			int num = 0;
			foreach (ParameterInfo parameterInfo in parameters)
			{
				array[num++] = parameterInfo.ParameterType;
			}
			MethodInfo method = this.type_4.GetMethod(methodBase.Name, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.InvokeMethod | BindingFlags.GetProperty | BindingFlags.SetProperty, null, array, null);
			if (method != null)
			{
				methodBase = method;
			}
			this.type_4 = null;
		}
		this.method_124(methodBase, true);
	}

	// Token: 0x0600003A RID: 58 RVA: 0x0000ECA8 File Offset: 0x0000CEA8
	private void method_13(Class94 class94_2)
	{
		int int_ = ((Class118)class94_2).method_2();
		Type type_ = this.method_189(int_, true);
		Class94 class94_3 = this.method_300();
		if (!this.method_281(class94_3, type_))
		{
			throw new InvalidCastException();
		}
		this.method_195(class94_3);
	}

	// Token: 0x0600003B RID: 59 RVA: 0x0000ECE8 File Offset: 0x0000CEE8
	private void method_14(Class94 class94_2)
	{
		Class94 @class = this.method_300();
		int num = @class.vmethod_2();
		checked
		{
			sbyte int_;
			if (num <= 11)
			{
				if (num == 7)
				{
					int_ = (sbyte)((uint)((Class118)@class).method_2());
					goto IL_6F;
				}
				if (num == 11)
				{
					int_ = (sbyte)((ulong)((Class99)@class).method_2());
					goto IL_6F;
				}
			}
			else
			{
				if (num == 17)
				{
					int_ = (sbyte)((Class117)@class).method_2();
					goto IL_6F;
				}
				if (num == 24)
				{
					int_ = (sbyte)Convert.ToUInt64(((Class98)@class).method_2());
					goto IL_6F;
				}
			}
			throw new InvalidOperationException();
			IL_6F:
			Class118 class2 = new Class118();
			class2.method_3((int)int_);
			this.method_195(class2);
		}
	}

	// Token: 0x0600003C RID: 60 RVA: 0x0000ED78 File Offset: 0x0000CF78
	private MethodBase method_15(MethodBase methodBase_0, bool bool_2)
	{
		Dictionary<MethodBase, DynamicMethod> obj = Class4.dictionary_5;
		MethodBase result;
		lock (obj)
		{
			DynamicMethod dynamicMethod;
			if (Class4.dictionary_5.TryGetValue(methodBase_0, out dynamicMethod))
			{
				result = dynamicMethod;
			}
			else
			{
				string empty = string.Empty;
				MethodInfo methodInfo = methodBase_0 as MethodInfo;
				Type returnType;
				if (methodInfo != null)
				{
					returnType = methodInfo.ReturnType;
				}
				else
				{
					returnType = Class4.type_1;
				}
				ParameterInfo[] parameters = methodBase_0.GetParameters();
				Type[] array;
				if (methodBase_0.IsStatic)
				{
					array = new Type[parameters.Length];
					for (int i = 0; i < parameters.Length; i++)
					{
						array[i] = parameters[i].ParameterType;
					}
				}
				else
				{
					array = new Type[parameters.Length + 1];
					Type type = methodBase_0.DeclaringType;
					if (type.IsValueType)
					{
						type = type.MakeByRefType();
						bool_2 = false;
					}
					array[0] = type;
					for (int j = 0; j < parameters.Length; j++)
					{
						array[j + 1] = parameters[j].ParameterType;
					}
				}
				if (dynamicMethod == null)
				{
					dynamicMethod = new DynamicMethod(empty, returnType, array, this.method_189(this.class86_0.method_6(), true), true);
				}
				ILGenerator ilgenerator = dynamicMethod.GetILGenerator();
				for (int k = 0; k < array.Length; k++)
				{
					ilgenerator.Emit(OpCodes.Ldarg, k);
				}
				ConstructorInfo constructorInfo = methodBase_0 as ConstructorInfo;
				if (constructorInfo != null)
				{
					ilgenerator.Emit(bool_2 ? OpCodes.Callvirt : OpCodes.Call, constructorInfo);
				}
				else
				{
					ilgenerator.Emit(bool_2 ? OpCodes.Callvirt : OpCodes.Call, (MethodInfo)methodBase_0);
				}
				ilgenerator.Emit(OpCodes.Ret);
				Class4.dictionary_5.Add(methodBase_0, dynamicMethod);
				result = dynamicMethod;
			}
		}
		return result;
	}

	// Token: 0x0600003D RID: 61 RVA: 0x0000EF34 File Offset: 0x0000D134
	private Class94 method_16(Class94 class94_2, Class94 class94_3, bool bool_2, bool bool_3)
	{
		if (class94_2.vmethod_2() == 7)
		{
			if (class94_3.vmethod_2() == 7)
			{
				if (!bool_3)
				{
					int num = ((Class118)class94_2).method_2();
					int num2 = ((Class118)class94_3).method_2();
					int int_;
					if (bool_2)
					{
						int_ = checked(num * num2);
					}
					else
					{
						int_ = num * num2;
					}
					Class118 @class = new Class118();
					@class.method_3(int_);
					return @class;
				}
				uint num3 = (uint)((Class118)class94_2).method_2();
				uint num4 = (uint)((Class118)class94_3).method_2();
				uint int_2;
				if (bool_2)
				{
					int_2 = checked(num3 * num4);
				}
				else
				{
					int_2 = num3 * num4;
				}
				Class118 class2 = new Class118();
				class2.method_3((int)int_2);
				return class2;
			}
			else
			{
				if (class94_3.vmethod_2() == 11)
				{
					Class99 class3 = new Class99();
					class3.method_3((long)((Class118)class94_2).method_2());
					return Class4.smethod_27(class3, class94_3, bool_2, bool_3);
				}
				if (class94_3.vmethod_2() == 24)
				{
					Type underlyingType = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
					if (underlyingType != typeof(long))
					{
						if (underlyingType != typeof(ulong))
						{
							Class118 class4 = new Class118();
							class4.method_3(Convert.ToInt32(class94_3.vmethod_0()));
							return this.method_16(class94_2, class4, bool_2, bool_3);
						}
					}
					Class99 class5 = new Class99();
					class5.method_3((long)((Class118)class94_2).method_2());
					Class99 class6 = new Class99();
					class6.method_3(Convert.ToInt64(class94_3.vmethod_0()));
					return Class4.smethod_27(class5, class6, bool_2, bool_3);
				}
			}
		}
		if (class94_2.vmethod_2() == 11)
		{
			if (class94_3.vmethod_2() == 11)
			{
				return Class4.smethod_27(class94_2, class94_3, bool_2, bool_3);
			}
			if (class94_3.vmethod_2() == 7)
			{
				Class99 class7 = new Class99();
				class7.method_3((long)((Class118)class94_3).method_2());
				return Class4.smethod_27(class94_2, class7, bool_2, bool_3);
			}
			if (class94_3.vmethod_2() == 24)
			{
				Type underlyingType2 = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
				if (underlyingType2 != typeof(long))
				{
					if (underlyingType2 != typeof(ulong))
					{
						Class118 class8 = new Class118();
						class8.method_3(Convert.ToInt32(class94_3.vmethod_0()));
						return Class4.smethod_27(class94_2, class8, bool_2, bool_3);
					}
				}
				Class99 class9 = new Class99();
				class9.method_3(Convert.ToInt64(class94_3.vmethod_0()));
				return Class4.smethod_27(class94_2, class9, bool_2, bool_3);
			}
		}
		if (class94_2.vmethod_2() == 17 && class94_3.vmethod_2() == 17)
		{
			Class117 class10 = new Class117();
			class10.method_3(((Class117)class94_2).method_2() * ((Class117)class94_3).method_2());
			return class10;
		}
		if (class94_2.vmethod_2() == 24)
		{
			Type underlyingType3 = Enum.GetUnderlyingType(class94_2.vmethod_0().GetType());
			if (underlyingType3 != typeof(long))
			{
				if (underlyingType3 != typeof(ulong))
				{
					Class118 class11 = new Class118();
					class11.method_3(Convert.ToInt32(class94_2.vmethod_0()));
					return this.method_16(class11, class94_3, bool_2, bool_3);
				}
			}
			Class99 class12 = new Class99();
			class12.method_3(Convert.ToInt64(class94_2.vmethod_0()));
			return this.method_16(class12, class94_3, bool_2, bool_3);
		}
		throw new InvalidOperationException();
	}

	// Token: 0x0600003E RID: 62 RVA: 0x0000F204 File Offset: 0x0000D404
	private string method_17(int int_0)
	{
		Dictionary<int, object> obj = Class4.dictionary_3;
		string result;
		lock (obj)
		{
			bool flag = true;
			object obj2;
			if (Class4.dictionary_3.TryGetValue(int_0, out obj2))
			{
				result = (string)obj2;
			}
			else
			{
				Class3 @class = this.method_130(int_0);
				if (@class.method_0() == 1)
				{
					result = this.module_0.ResolveString(@class.method_2());
				}
				else
				{
					string text = ((Class35)@class.method_4()).method_0();
					if (flag)
					{
						Class4.dictionary_3.Add(int_0, text);
					}
					result = text;
				}
			}
		}
		return result;
	}

	// Token: 0x0600003F RID: 63 RVA: 0x0000F29C File Offset: 0x0000D49C
	private void method_18(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		Class94 class94_4 = this.method_300();
		this.method_195(this.method_131(class94_4, class94_3, true, false));
	}

	// Token: 0x06000040 RID: 64 RVA: 0x0000F2C8 File Offset: 0x0000D4C8
	private void method_19(Class94 class94_2)
	{
		int int_ = ((Class118)class94_2).method_2();
		FieldInfo fieldInfo = this.method_71(int_);
		Class94 @class = this.method_300();
		Class106 class106_;
		if ((class106_ = (@class as Class106)) != null)
		{
			@class = this.method_255(class106_);
		}
		object obj = @class.vmethod_0();
		if (obj == null)
		{
			throw new NullReferenceException();
		}
		this.method_195(Class32.smethod_1(fieldInfo.GetValue(obj), fieldInfo.FieldType));
	}

	// Token: 0x06000041 RID: 65 RVA: 0x0000F32C File Offset: 0x0000D52C
	private void method_20()
	{
		try
		{
			this.method_296();
		}
		catch (Exception object_)
		{
			this.method_298(object_, 0U);
			this.method_296();
		}
	}

	// Token: 0x06000042 RID: 66 RVA: 0x00002DFA File Offset: 0x00000FFA
	private static Exception smethod_0(string string_0, string string_1)
	{
		return new FieldAccessException(Class4.smethod_26(string.Format("security transparent method '{0}'", string_0), string.Format("security critical field '{0}'", string_1)));
	}

	// Token: 0x06000043 RID: 67 RVA: 0x0000F364 File Offset: 0x0000D564
	private Class94 method_21(Class94 class94_2, Class94 class94_3, bool bool_2)
	{
		if (class94_2.vmethod_2() == 7)
		{
			if (class94_3.vmethod_2() == 7)
			{
				if (!bool_2)
				{
					int num = ((Class118)class94_2).method_2();
					int num2 = ((Class118)class94_3).method_2();
					Class118 @class = new Class118();
					@class.method_3(num / num2);
					return @class;
				}
				uint num3 = (uint)((Class118)class94_2).method_2();
				uint num4 = (uint)((Class118)class94_3).method_2();
				Class118 class2 = new Class118();
				class2.method_3((int)(num3 / num4));
				return class2;
			}
			else
			{
				if (class94_3.vmethod_2() == 11)
				{
					Class99 class3 = new Class99();
					class3.method_3((long)((Class118)class94_2).method_2());
					return Class4.smethod_30(class3, class94_3, bool_2);
				}
				if (class94_3.vmethod_2() == 24)
				{
					Type underlyingType = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
					if (underlyingType != typeof(long))
					{
						if (underlyingType != typeof(ulong))
						{
							Class118 class4 = new Class118();
							class4.method_3(Convert.ToInt32(class94_3.vmethod_0()));
							return this.method_21(class94_2, class4, bool_2);
						}
					}
					Class99 class5 = new Class99();
					class5.method_3((long)((Class118)class94_2).method_2());
					Class99 class6 = new Class99();
					class6.method_3(Convert.ToInt64(class94_3.vmethod_0()));
					return Class4.smethod_30(class5, class6, bool_2);
				}
			}
		}
		if (class94_2.vmethod_2() == 11)
		{
			if (class94_3.vmethod_2() == 11)
			{
				return Class4.smethod_30(class94_2, class94_3, bool_2);
			}
			if (class94_3.vmethod_2() == 7)
			{
				Class99 class7 = new Class99();
				class7.method_3((long)((Class118)class94_3).method_2());
				return Class4.smethod_30(class94_2, class7, bool_2);
			}
			if (class94_3.vmethod_2() == 24)
			{
				Type underlyingType2 = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
				if (underlyingType2 != typeof(long))
				{
					if (underlyingType2 != typeof(ulong))
					{
						Class118 class8 = new Class118();
						class8.method_3(Convert.ToInt32(class94_3.vmethod_0()));
						return Class4.smethod_30(class94_2, class8, bool_2);
					}
				}
				Class99 class9 = new Class99();
				class9.method_3(Convert.ToInt64(class94_3.vmethod_0()));
				return Class4.smethod_30(class94_2, class9, bool_2);
			}
		}
		if (class94_2.vmethod_2() == 17 && class94_3.vmethod_2() == 17)
		{
			Class117 class10 = new Class117();
			class10.method_3(((Class117)class94_2).method_2() / ((Class117)class94_3).method_2());
			return class10;
		}
		if (class94_2.vmethod_2() == 24)
		{
			Type underlyingType3 = Enum.GetUnderlyingType(class94_2.vmethod_0().GetType());
			if (underlyingType3 != typeof(long))
			{
				if (underlyingType3 != typeof(ulong))
				{
					Class118 class11 = new Class118();
					class11.method_3(Convert.ToInt32(class94_2.vmethod_0()));
					return this.method_21(class11, class94_3, bool_2);
				}
			}
			Class99 class12 = new Class99();
			class12.method_3(Convert.ToInt64(class94_2.vmethod_0()));
			return this.method_21(class12, class94_3, bool_2);
		}
		throw new InvalidOperationException();
	}

	// Token: 0x06000044 RID: 68 RVA: 0x00002E1C File Offset: 0x0000101C
	private static bool smethod_1()
	{
		return false;
	}

	// Token: 0x06000045 RID: 69 RVA: 0x0000F600 File Offset: 0x0000D800
	private void method_22(Stream stream_1, long long_1, string string_0)
	{
		int int_ = this.method_259();
		Class51 class50_ = new Class51(stream_1, int_);
		this.class31_1 = new Class31(class50_);
		if (string_0 != null)
		{
			long_1 = this.method_11(string_0);
		}
		Class50 @class = this.class31_1.method_0();
		Class50 obj = @class;
		lock (obj)
		{
			@class.vmethod_9(long_1, 0);
			this.method_73(this.class31_1);
			this.class86_0 = this.method_222(this.class31_1);
			this.class27_0 = Class4.smethod_15(this.class31_1);
			this.byte_0 = Class4.smethod_7(this.class31_1);
		}
		this.method_24();
	}

	// Token: 0x06000046 RID: 70 RVA: 0x00002E1F File Offset: 0x0000101F
	private void method_23(Class94 class94_2)
	{
		this.method_175(false);
	}

	// Token: 0x06000047 RID: 71 RVA: 0x00002E28 File Offset: 0x00001028
	private void method_24()
	{
		Class4.smethod_13<Class27>(this.class27_0, new Comparison<Class27>(Class4.Class5.class5_0.method_0));
	}

	// Token: 0x06000048 RID: 72 RVA: 0x00002E54 File Offset: 0x00001054
	private void method_25(Class94 class94_2)
	{
		this.method_265(Class60.type_0);
	}

	// Token: 0x06000049 RID: 73 RVA: 0x00002E61 File Offset: 0x00001061
	private static void smethod_2(object object_3)
	{
		throw object_3;
	}

	// Token: 0x0600004A RID: 74 RVA: 0x0000F6B4 File Offset: 0x0000D8B4
	private Class94 method_26(Class94 class94_2, Class94 class94_3, bool bool_2)
	{
		if (class94_2.vmethod_2() == 7)
		{
			if (class94_3.vmethod_2() == 7)
			{
				if (!bool_2)
				{
					int num = ((Class118)class94_2).method_2();
					int num2 = ((Class118)class94_3).method_2();
					Class118 @class = new Class118();
					@class.method_3(num % num2);
					return @class;
				}
				uint num3 = (uint)((Class118)class94_2).method_2();
				uint num4 = (uint)((Class118)class94_3).method_2();
				Class118 class2 = new Class118();
				class2.method_3((int)(num3 % num4));
				return class2;
			}
			else
			{
				if (class94_3.vmethod_2() == 11)
				{
					Class99 class3 = new Class99();
					class3.method_3((long)((Class118)class94_2).method_2());
					return Class4.smethod_10(class3, class94_3, bool_2);
				}
				if (class94_3.vmethod_2() == 24)
				{
					Type underlyingType = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
					if (underlyingType != typeof(long))
					{
						if (underlyingType != typeof(ulong))
						{
							Class118 class4 = new Class118();
							class4.method_3(Convert.ToInt32(class94_3.vmethod_0()));
							return this.method_26(class94_2, class4, bool_2);
						}
					}
					Class99 class5 = new Class99();
					class5.method_3((long)((Class118)class94_2).method_2());
					Class99 class6 = new Class99();
					class6.method_3(Convert.ToInt64(class94_3.vmethod_0()));
					return Class4.smethod_10(class5, class6, bool_2);
				}
			}
		}
		if (class94_2.vmethod_2() == 11)
		{
			if (class94_3.vmethod_2() == 11)
			{
				return Class4.smethod_10(class94_2, class94_3, bool_2);
			}
			if (class94_3.vmethod_2() == 7)
			{
				Class99 class7 = new Class99();
				class7.method_3((long)((Class118)class94_3).method_2());
				return Class4.smethod_10(class94_2, class7, bool_2);
			}
			if (class94_3.vmethod_2() == 24)
			{
				Type underlyingType2 = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
				if (underlyingType2 != typeof(long))
				{
					if (underlyingType2 != typeof(ulong))
					{
						Class118 class8 = new Class118();
						class8.method_3(Convert.ToInt32(class94_3.vmethod_0()));
						return Class4.smethod_10(class94_2, class8, bool_2);
					}
				}
				Class99 class9 = new Class99();
				class9.method_3(Convert.ToInt64(class94_3.vmethod_0()));
				return Class4.smethod_10(class94_2, class9, bool_2);
			}
		}
		if (class94_2.vmethod_2() == 17 && class94_3.vmethod_2() == 17)
		{
			Class117 class10 = new Class117();
			class10.method_3(((Class117)class94_2).method_2() % ((Class117)class94_3).method_2());
			return class10;
		}
		if (class94_2.vmethod_2() == 24)
		{
			Type underlyingType3 = Enum.GetUnderlyingType(class94_2.vmethod_0().GetType());
			if (underlyingType3 != typeof(long))
			{
				if (underlyingType3 != typeof(ulong))
				{
					Class118 class11 = new Class118();
					class11.method_3(Convert.ToInt32(class94_2.vmethod_0()));
					return this.method_26(class11, class94_3, bool_2);
				}
			}
			Class99 class12 = new Class99();
			class12.method_3(Convert.ToInt64(class94_2.vmethod_0()));
			return this.method_26(class12, class94_3, bool_2);
		}
		throw new InvalidOperationException();
	}

	// Token: 0x0600004B RID: 75 RVA: 0x0000F950 File Offset: 0x0000DB50
	private Class4.Delegate0 method_27(Class4.Struct2 struct2_0)
	{
		Dictionary<Class4.Struct2, Class4.Delegate0> obj = this.dictionary_1;
		Class4.Delegate0 @delegate;
		lock (obj)
		{
			this.dictionary_1.TryGetValue(struct2_0, out @delegate);
		}
		if (@delegate != null)
		{
			return @delegate;
		}
		MethodBase methodBase = struct2_0.method_0();
		Dictionary<MethodBase, object> obj2 = this.dictionary_2;
		lock (obj2)
		{
			while (this.dictionary_2.ContainsKey(methodBase))
			{
				Monitor.Wait(this.dictionary_2);
			}
			this.dictionary_2[methodBase] = null;
		}
		Class4.Delegate0 result;
		try
		{
			obj = this.dictionary_1;
			lock (obj)
			{
				this.dictionary_1.TryGetValue(struct2_0, out @delegate);
			}
			if (@delegate == null)
			{
				@delegate = this.method_267(methodBase, struct2_0.method_1());
				obj = this.dictionary_1;
				lock (obj)
				{
					this.dictionary_1[struct2_0] = @delegate;
				}
			}
			result = @delegate;
		}
		finally
		{
			obj2 = this.dictionary_2;
			lock (obj2)
			{
				this.dictionary_2.Remove(methodBase);
				Monitor.PulseAll(this.dictionary_2);
			}
		}
		return result;
	}

	// Token: 0x0600004C RID: 76 RVA: 0x0000FAAC File Offset: 0x0000DCAC
	private void method_28(Class94 class94_2)
	{
		Class94 @class = this.method_300();
		int num = @class.vmethod_2();
		bool flag;
		if (num <= 11)
		{
			switch (num)
			{
			case 4:
				flag = (((Class102)@class).method_2() == null);
				goto IL_CD;
			case 5:
			case 6:
				break;
			case 7:
				flag = (((Class118)@class).method_2() == 0);
				goto IL_CD;
			case 8:
				flag = (((Class100)@class).method_2() == UIntPtr.Zero);
				goto IL_CD;
			default:
				if (num == 11)
				{
					flag = (((Class99)@class).method_2() == 0L);
					goto IL_CD;
				}
				break;
			}
		}
		else
		{
			if (num == 14)
			{
				flag = (((Class105)@class).method_2() == IntPtr.Zero);
				goto IL_CD;
			}
			if (num == 24)
			{
				flag = !Convert.ToBoolean(((Class98)@class).method_2());
				goto IL_CD;
			}
		}
		flag = (@class.vmethod_0() == null);
		IL_CD:
		if (flag)
		{
			uint uint_ = ((Class104)class94_2).method_2();
			this.method_244(uint_);
		}
	}

	// Token: 0x0600004D RID: 77 RVA: 0x0000FB9C File Offset: 0x0000DD9C
	private void method_29(Class94 class94_2)
	{
		Class94 @class = this.method_300();
		int num = @class.vmethod_2();
		double double_;
		if (num <= 11)
		{
			if (num == 7)
			{
				double_ = (double)((Class118)@class).method_2();
				goto IL_6D;
			}
			if (num == 11)
			{
				double_ = (double)((Class99)@class).method_2();
				goto IL_6D;
			}
		}
		else
		{
			if (num == 17)
			{
				double_ = ((Class117)@class).method_2();
				goto IL_6D;
			}
			if (num == 24)
			{
				double_ = Convert.ToUInt64(((Class98)@class).method_2());
				goto IL_6D;
			}
		}
		throw new InvalidOperationException();
		IL_6D:
		Class117 class2 = new Class117();
		class2.method_3(double_);
		this.method_195(class2);
	}

	// Token: 0x0600004E RID: 78 RVA: 0x00002E64 File Offset: 0x00001064
	private void method_30(Class94 class94_2)
	{
		Class118 @class = new Class118();
		@class.method_3(-1);
		this.method_195(@class);
	}

	// Token: 0x0600004F RID: 79 RVA: 0x0000FC28 File Offset: 0x0000DE28
	private void method_31(Class94 class94_2)
	{
		Class121 @class = (Class121)class94_2;
		this.method_195(this.class94_1[(int)@class.method_2()].vmethod_4());
	}

	// Token: 0x06000050 RID: 80 RVA: 0x0000FC58 File Offset: 0x0000DE58
	private void method_32(Class94 class94_2)
	{
		Class94 @class = this.method_300();
		int num = @class.vmethod_2();
		checked
		{
			byte int_;
			if (num <= 11)
			{
				if (num == 7)
				{
					int_ = (byte)((uint)((Class118)@class).method_2());
					goto IL_6F;
				}
				if (num == 11)
				{
					int_ = (byte)((ulong)((Class99)@class).method_2());
					goto IL_6F;
				}
			}
			else
			{
				if (num == 17)
				{
					int_ = (byte)((Class117)@class).method_2();
					goto IL_6F;
				}
				if (num == 24)
				{
					int_ = (byte)Convert.ToUInt64(((Class98)@class).method_2());
					goto IL_6F;
				}
			}
			throw new InvalidOperationException();
			IL_6F:
			Class118 class2 = new Class118();
			class2.method_3((int)int_);
			this.method_195(class2);
		}
	}

	// Token: 0x06000051 RID: 81 RVA: 0x0000FCE8 File Offset: 0x0000DEE8
	private void method_33(Class94 class94_2)
	{
		int int_ = ((Class118)class94_2).method_2();
		Type type_ = this.method_189(int_, true);
		this.method_109(type_);
	}

	// Token: 0x06000052 RID: 82 RVA: 0x00002E78 File Offset: 0x00001078
	private void method_34(Class94 class94_2)
	{
		this.method_144(typeof(float));
	}

	// Token: 0x06000053 RID: 83 RVA: 0x0000FD14 File Offset: 0x0000DF14
	private static Class94 smethod_3(Class94 class94_2, Class94 class94_3, bool bool_2, bool bool_3)
	{
		if (!bool_3)
		{
			long num = ((Class99)class94_2).method_2();
			long num2 = ((Class99)class94_3).method_2();
			long long_;
			if (bool_2)
			{
				long_ = checked(num - num2);
			}
			else
			{
				long_ = num - num2;
			}
			Class99 @class = new Class99();
			@class.method_3(long_);
			return @class;
		}
		ulong num3 = (ulong)((Class99)class94_2).method_2();
		ulong num4 = (ulong)((Class99)class94_3).method_2();
		ulong long_2;
		if (bool_2)
		{
			long_2 = checked(num3 - num4);
		}
		else
		{
			long_2 = num3 - num4;
		}
		Class99 class2 = new Class99();
		class2.method_3((long)long_2);
		return class2;
	}

	// Token: 0x06000054 RID: 84 RVA: 0x00002E8A File Offset: 0x0000108A
	private void method_35(Class94 class94_2)
	{
		this.method_150(true);
	}

	// Token: 0x06000055 RID: 85 RVA: 0x0000FD90 File Offset: 0x0000DF90
	private object method_36(object[] object_3, Type[] type_9, Type[] type_10, object[] object_4)
	{
		if (object_3 == null)
		{
			object_3 = Class71<object>.gparam_0;
		}
		if (type_9 == null)
		{
			type_9 = Type.EmptyTypes;
		}
		if (type_10 == null)
		{
			type_10 = Type.EmptyTypes;
		}
		this.object_0 = object_4;
		this.type_7 = type_9;
		this.type_2 = type_10;
		this.class94_0 = this.method_270(object_3);
		this.class94_1 = this.method_39();
		object result;
		try
		{
			Class52 @class = new Class52(this.byte_0);
			try
			{
				using (this.class31_0 = new Class31(@class))
				{
					this.bool_1 = false;
					this.nullable_0 = null;
					this.class20_0.method_0();
					this.method_20();
				}
			}
			finally
			{
				((IDisposable)@class).Dispose();
			}
			Type type = this.method_189(this.class86_0.method_8(), false);
			if (type != Class4.type_1 && this.class20_0.Count > 0)
			{
				result = Class32.smethod_1(null, type).vmethod_3(this.method_300()).vmethod_0();
			}
			else
			{
				result = null;
			}
		}
		finally
		{
			for (int i = 0; i < this.class86_0.method_2().Length; i++)
			{
				Class70 class3 = this.class86_0.method_2()[i];
				if (class3.method_2())
				{
					Class112 class4 = (Class112)this.class94_0[i];
					Type type2 = this.method_189(class3.method_0(), false);
					object_3[i] = Class32.smethod_1(null, type2.GetElementType()).vmethod_3(class4.method_2()).vmethod_0();
				}
			}
			this.object_0 = null;
			this.class94_0 = null;
			this.class94_1 = null;
		}
		return result;
	}

	// Token: 0x06000056 RID: 86 RVA: 0x0000FF4C File Offset: 0x0000E14C
	private void method_37(Class94 class94_2)
	{
		int int_ = ((Class118)class94_2).method_2();
		Type elementType = this.method_189(int_, true);
		Class94 @class = this.method_300();
		Class118 class2 = @class as Class118;
		int length;
		if (class2 != null)
		{
			length = class2.method_2();
		}
		else
		{
			Class105 class3 = @class as Class105;
			if (class3 != null)
			{
				length = class3.method_2().ToInt32();
			}
			else
			{
				Class100 class4 = @class as Class100;
				if (class4 == null)
				{
					throw new Exception();
				}
				length = (int)class4.method_2().ToUInt32();
			}
		}
		Array array_ = Array.CreateInstance(elementType, length);
		Class116 class5 = new Class116();
		class5.method_3(array_);
		this.method_195(class5);
	}

	// Token: 0x06000057 RID: 87 RVA: 0x00002E93 File Offset: 0x00001093
	private void method_38(Class94 class94_2)
	{
		this.method_109(typeof(sbyte));
	}

	// Token: 0x06000058 RID: 88 RVA: 0x0000FFE8 File Offset: 0x0000E1E8
	private Class94[] method_39()
	{
		Class12[] array = this.class86_0.method_0();
		int num = array.Length;
		Class94[] array2 = new Class94[num];
		for (int i = 0; i < num; i++)
		{
			array2[i] = Class32.smethod_1(null, this.method_189(array[i].method_0(), false));
		}
		return array2;
	}

	// Token: 0x06000059 RID: 89 RVA: 0x0001003C File Offset: 0x0000E23C
	private void method_40(Class94 class94_2)
	{
		object object_ = this.method_300().vmethod_0();
		long num = this.method_55();
		Array array = (Array)this.method_300().vmethod_0();
		Type elementType = array.GetType().GetElementType();
		checked
		{
			if (elementType == typeof(sbyte))
			{
				Class94 @class = Class32.smethod_1(object_, typeof(sbyte));
				((sbyte[])array)[(int)((IntPtr)num)] = (sbyte)@class.vmethod_0();
				return;
			}
			if (elementType == typeof(byte))
			{
				Class94 class2 = Class32.smethod_1(object_, typeof(byte));
				((byte[])array)[(int)((IntPtr)num)] = (byte)class2.vmethod_0();
				return;
			}
			if (elementType == typeof(bool))
			{
				Class94 class3 = Class32.smethod_1(object_, typeof(bool));
				((bool[])array)[(int)((IntPtr)num)] = (bool)class3.vmethod_0();
				return;
			}
			if (elementType.IsEnum)
			{
				this.method_147(elementType, object_, num, array);
				return;
			}
			this.method_147(typeof(sbyte), object_, num, array);
		}
	}

	// Token: 0x0600005A RID: 90 RVA: 0x00002EA5 File Offset: 0x000010A5
	private void method_41(Class94 class94_2)
	{
		this.method_195(this.class94_1[2].vmethod_4());
	}

	// Token: 0x0600005B RID: 91 RVA: 0x00010140 File Offset: 0x0000E340
	private Class94 method_42(Class94 class94_2)
	{
		if (class94_2.vmethod_2() == 7)
		{
			int num = ((Class118)class94_2).method_2();
			Class118 @class = new Class118();
			@class.method_3(~num);
			return @class;
		}
		if (class94_2.vmethod_2() == 11)
		{
			long num2 = ((Class99)class94_2).method_2();
			Class99 class2 = new Class99();
			class2.method_3(~num2);
			return class2;
		}
		if (class94_2.vmethod_2() == 24)
		{
			Type underlyingType = Enum.GetUnderlyingType(class94_2.vmethod_0().GetType());
			if (underlyingType != typeof(long))
			{
				if (underlyingType != typeof(ulong))
				{
					int num3 = Convert.ToInt32(class94_2.vmethod_0());
					Class118 class3 = new Class118();
					class3.method_3(~num3);
					return class3;
				}
			}
			long num4 = Convert.ToInt64(class94_2.vmethod_0());
			Class99 class4 = new Class99();
			class4.method_3(~num4);
			return class4;
		}
		throw new InvalidOperationException();
	}

	// Token: 0x0600005C RID: 92 RVA: 0x00010208 File Offset: 0x0000E408
	private void method_43(Class94 class94_2)
	{
		int int_ = ((Class118)class94_2).method_2();
		Type type_ = this.method_189(int_, true);
		this.method_265(type_);
	}

	// Token: 0x0600005D RID: 93 RVA: 0x00010234 File Offset: 0x0000E434
	private void method_44(bool bool_2)
	{
		Class94 @class = this.method_300();
		int num = @class.vmethod_2();
		uint int_;
		if (num <= 11)
		{
			if (num != 7)
			{
				if (num == 11)
				{
					if (bool_2)
					{
						int_ = checked((uint)((Class99)@class).method_2());
						goto IL_BD;
					}
					int_ = (uint)((Class99)@class).method_2();
					goto IL_BD;
				}
			}
			else
			{
				if (bool_2)
				{
					int_ = checked((uint)((Class118)@class).method_2());
					goto IL_BD;
				}
				int_ = (uint)((ushort)((Class118)@class).method_2());
				goto IL_BD;
			}
		}
		else if (num != 17)
		{
			if (num == 24)
			{
				if (bool_2)
				{
					int_ = checked((uint)Convert.ToUInt64(((Class98)@class).method_2()));
					goto IL_BD;
				}
				int_ = (uint)Convert.ToUInt64(((Class98)@class).method_2());
				goto IL_BD;
			}
		}
		else
		{
			if (bool_2)
			{
				int_ = checked((uint)((Class117)@class).method_2());
				goto IL_BD;
			}
			int_ = (uint)((Class117)@class).method_2();
			goto IL_BD;
		}
		throw new InvalidOperationException();
		IL_BD:
		Class118 class2 = new Class118();
		class2.method_3((int)int_);
		this.method_195(class2);
	}

	// Token: 0x0600005E RID: 94 RVA: 0x00010310 File Offset: 0x0000E510
	private void method_45(Class94 class94_2)
	{
		int int_ = ((Class118)class94_2).method_2();
		MethodBase methodBase = this.method_234(int_);
		Type declaringType = methodBase.DeclaringType;
		ParameterInfo[] parameters = methodBase.GetParameters();
		int num = parameters.Length;
		object[] array = new object[num];
		Dictionary<int, Class106> dictionary = new Dictionary<int, Class106>();
		for (int i = num - 1; i >= 0; i--)
		{
			Class94 @class = this.method_300();
			Class106 class2;
			if ((class2 = (@class as Class106)) != null)
			{
				dictionary.Add(i, class2);
				@class = this.method_255(class2);
			}
			if (@class.method_0() != null)
			{
				@class = Class32.smethod_1(null, @class.method_0()).vmethod_3(@class);
			}
			Class94 class3 = Class32.smethod_1(null, parameters[i].ParameterType).vmethod_3(@class);
			array[i] = class3.vmethod_0();
		}
		object obj;
		try
		{
			obj = this.method_159(methodBase, null, array, false);
		}
		catch (TargetInvocationException ex)
		{
			Exception object_ = ex.InnerException ?? ex;
			this.method_215(object_);
			return;
		}
		foreach (KeyValuePair<int, Class106> keyValuePair in dictionary)
		{
			this.method_142(keyValuePair.Value, Class32.smethod_1(array[keyValuePair.Key], null));
		}
		this.method_195(Class32.smethod_1(obj, declaringType));
	}

	// Token: 0x0600005F RID: 95 RVA: 0x00010468 File Offset: 0x0000E668
	private void method_46(Class94 class94_2)
	{
		Class119 @class = (Class119)class94_2;
		Class94 class2 = this.method_300();
		this.class94_0[(int)@class.method_2()].vmethod_3(class2);
	}

	// Token: 0x06000060 RID: 96 RVA: 0x0001049C File Offset: 0x0000E69C
	private void method_47(Class94 class94_2)
	{
		Class119 @class = (Class119)class94_2;
		this.method_291((int)@class.method_2());
	}

	// Token: 0x06000061 RID: 97 RVA: 0x000104BC File Offset: 0x0000E6BC
	private static Class94 smethod_4(Class94 class94_2, Class94 class94_3, bool bool_2, bool bool_3)
	{
		if (!bool_3)
		{
			long num = ((Class99)class94_2).method_2();
			long num2 = ((Class99)class94_3).method_2();
			long long_;
			if (bool_2)
			{
				long_ = checked(num + num2);
			}
			else
			{
				long_ = num + num2;
			}
			Class99 @class = new Class99();
			@class.method_3(long_);
			return @class;
		}
		ulong num3 = (ulong)((Class99)class94_2).method_2();
		ulong num4 = (ulong)((Class99)class94_3).method_2();
		ulong long_2;
		if (bool_2)
		{
			long_2 = checked(num3 + num4);
		}
		else
		{
			long_2 = num3 + num4;
		}
		Class99 class2 = new Class99();
		class2.method_3((long)long_2);
		return class2;
	}

	// Token: 0x06000062 RID: 98 RVA: 0x00002EBE File Offset: 0x000010BE
	public object method_48(Stream stream_1, string string_0, object[] object_3, Type[] type_9, Type[] type_10, object[] object_4)
	{
		this.stream_0 = stream_1;
		this.method_128(stream_1, string_0);
		return this.method_36(object_3, type_9, type_10, object_4);
	}

	// Token: 0x06000063 RID: 99 RVA: 0x00010538 File Offset: 0x0000E738
	private void method_49(Class86 class86_1)
	{
		if (Class4.smethod_5() && !this.class86_0.method_13() && class86_1.method_13() && !class86_1.method_14())
		{
			string string_ = this.method_192(class86_1);
			throw Class4.smethod_11(this.method_192(this.class86_0), string_);
		}
	}

	// Token: 0x06000064 RID: 100 RVA: 0x00010584 File Offset: 0x0000E784
	private void method_50(Class94 class94_2)
	{
		Class94 @class = this.method_300();
		int num = @class.vmethod_2();
		UIntPtr uintptr_;
		if (num <= 11)
		{
			if (num == 7)
			{
				uintptr_ = new UIntPtr((uint)((Class118)@class).method_2());
				goto IL_82;
			}
			if (num == 11)
			{
				uintptr_ = new UIntPtr((ulong)((Class99)@class).method_2());
				goto IL_82;
			}
		}
		else
		{
			if (num == 17)
			{
				uintptr_ = new UIntPtr((ulong)((Class117)@class).method_2());
				goto IL_82;
			}
			if (num == 24)
			{
				uintptr_ = new UIntPtr(Convert.ToUInt64(((Class98)@class).method_2()));
				goto IL_82;
			}
		}
		throw new InvalidOperationException();
		IL_82:
		Class100 class2 = new Class100();
		class2.method_3(uintptr_);
		this.method_195(class2);
	}

	// Token: 0x06000065 RID: 101 RVA: 0x00002EDC File Offset: 0x000010DC
	private void method_51(Class94 class94_2)
	{
		this.method_261(false);
	}

	// Token: 0x06000066 RID: 102 RVA: 0x00010628 File Offset: 0x0000E828
	private Class94 method_52(Class94 class94_2, Class94 class94_3, bool bool_2)
	{
		if (class94_2.vmethod_2() == 7)
		{
			if (class94_3.vmethod_2() == 7)
			{
				if (!bool_2)
				{
					int num = ((Class118)class94_2).method_2();
					int num2 = ((Class118)class94_3).method_2();
					Class118 @class = new Class118();
					@class.method_3(num >> num2);
					return @class;
				}
				uint num3 = (uint)((Class118)class94_2).method_2();
				int num4 = ((Class118)class94_3).method_2();
				Class118 class2 = new Class118();
				class2.method_3((int)(num3 >> num4));
				return class2;
			}
			else if (class94_3.vmethod_2() == 24)
			{
				Class118 class3 = new Class118();
				class3.method_3(Convert.ToInt32(class94_3.vmethod_0()));
				return this.method_52(class94_2, class3, bool_2);
			}
		}
		if (class94_2.vmethod_2() == 11)
		{
			if (class94_3.vmethod_2() == 7)
			{
				if (!bool_2)
				{
					long num5 = ((Class99)class94_2).method_2();
					int num6 = ((Class118)class94_3).method_2();
					Class99 class4 = new Class99();
					class4.method_3(num5 >> num6);
					return class4;
				}
				ulong num7 = (ulong)((Class99)class94_2).method_2();
				int num8 = ((Class118)class94_3).method_2();
				Class99 class5 = new Class99();
				class5.method_3((long)(num7 >> num8));
				return class5;
			}
			else if (class94_3.vmethod_2() == 24)
			{
				Class118 class6 = new Class118();
				class6.method_3(Convert.ToInt32(class94_3.vmethod_0()));
				return this.method_52(class94_2, class6, bool_2);
			}
		}
		if (class94_2.vmethod_2() == 24)
		{
			Type underlyingType = Enum.GetUnderlyingType(class94_2.vmethod_0().GetType());
			if (underlyingType != typeof(long))
			{
				if (underlyingType != typeof(ulong))
				{
					Class118 class7 = new Class118();
					class7.method_3(Convert.ToInt32(class94_2.vmethod_0()));
					return this.method_52(class7, class94_3, bool_2);
				}
			}
			Class99 class8 = new Class99();
			class8.method_3(Convert.ToInt64(class94_2.vmethod_0()));
			return this.method_52(class8, class94_3, bool_2);
		}
		throw new InvalidOperationException();
	}

	// Token: 0x06000067 RID: 103 RVA: 0x000107E4 File Offset: 0x0000E9E4
	private void method_53(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		Class94 class94_4 = this.method_300();
		this.method_195(this.method_131(class94_4, class94_3, true, true));
	}

	// Token: 0x06000068 RID: 104 RVA: 0x00002EE5 File Offset: 0x000010E5
	private void method_54(Class94 class94_2)
	{
		this.method_195(this.class94_0[0].vmethod_4());
	}

	// Token: 0x06000069 RID: 105 RVA: 0x00010810 File Offset: 0x0000EA10
	private long method_55()
	{
		Class94 @class = this.method_300();
		int num = @class.vmethod_2();
		if (num <= 8)
		{
			if (num == 7)
			{
				return (long)((Class118)@class).method_2();
			}
			if (num == 8)
			{
				return (long)((Class100)@class).method_2().ToUInt64();
			}
		}
		else
		{
			if (num == 14)
			{
				return ((Class105)@class).method_2().ToInt64();
			}
			if (num == 24)
			{
				return Convert.ToInt64(((Class98)@class).method_2());
			}
		}
		throw new Exception("Unexpected value on the stack.");
	}

	// Token: 0x0600006A RID: 106 RVA: 0x00002E1C File Offset: 0x0000101C
	private static bool smethod_5()
	{
		return false;
	}

	// Token: 0x0600006B RID: 107 RVA: 0x00002EFE File Offset: 0x000010FE
	private void method_56(Class94 class94_2)
	{
		this.method_265(typeof(byte));
	}

	// Token: 0x0600006C RID: 108 RVA: 0x00002F10 File Offset: 0x00001110
	private int method_57()
	{
		return -56926124;
	}

	// Token: 0x0600006D RID: 109 RVA: 0x0001089C File Offset: 0x0000EA9C
	private void method_58(Class94 class94_2)
	{
		int int_ = ((Class118)class94_2).method_2();
		Type type = this.method_189(int_, true);
		Class94 class94_3 = Class32.smethod_1(this.method_300().vmethod_0(), type);
		this.method_195(class94_3);
	}

	// Token: 0x0600006E RID: 110 RVA: 0x00002F17 File Offset: 0x00001117
	private void method_59(Class94 class94_2)
	{
		this.method_195(this.class94_0[2].vmethod_4());
	}

	// Token: 0x0600006F RID: 111 RVA: 0x00002F30 File Offset: 0x00001130
	private void method_60(Class94 class94_2)
	{
		Class118 @class = new Class118();
		@class.method_3(6);
		this.method_195(@class);
	}

	// Token: 0x06000070 RID: 112 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_61(Class94 class94_2)
	{
	}

	// Token: 0x06000071 RID: 113 RVA: 0x000108D8 File Offset: 0x0000EAD8
	private void method_62(Class94 class94_2)
	{
		int int_ = ((Class118)class94_2).method_2();
		this.type_4 = this.method_189(int_, true);
	}

	// Token: 0x06000072 RID: 114 RVA: 0x00010900 File Offset: 0x0000EB00
	private void method_63(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		Class94 class94_4 = this.method_300();
		this.method_195(this.method_131(class94_4, class94_3, false, false));
	}

	// Token: 0x06000073 RID: 115 RVA: 0x0001092C File Offset: 0x0000EB2C
	private void method_64(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		Class94 class94_4 = this.method_300();
		Class118 @class = new Class118();
		@class.method_3(Class4.smethod_18(class94_4, class94_3) ? 1 : 0);
		this.method_195(@class);
	}

	// Token: 0x06000074 RID: 116 RVA: 0x00002DF2 File Offset: 0x00000FF2
	private void method_65(Class94 class94_2)
	{
		this.method_275();
	}

	// Token: 0x06000075 RID: 117 RVA: 0x00010968 File Offset: 0x0000EB68
	private void method_66(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		if (!Class4.smethod_14(this.method_300(), class94_3))
		{
			uint uint_ = ((Class104)class94_2).method_2();
			this.method_244(uint_);
		}
	}

	// Token: 0x06000076 RID: 118 RVA: 0x00002F46 File Offset: 0x00001146
	private static void smethod_6(ILGenerator ilgenerator_0, Type type_9)
	{
		if (type_9.IsValueType || Class69.smethod_0(type_9).IsGenericParameter)
		{
			ilgenerator_0.Emit(OpCodes.Box, type_9);
		}
	}

	// Token: 0x06000077 RID: 119 RVA: 0x000109A0 File Offset: 0x0000EBA0
	private void method_67(Class94 class94_2)
	{
		Class118 @class = (Class118)class94_2;
		MethodBase methodBase_ = this.method_234(@class.method_2());
		Class97 class2 = new Class97();
		class2.method_3(methodBase_);
		this.method_195(class2);
	}

	// Token: 0x06000078 RID: 120 RVA: 0x000109D4 File Offset: 0x0000EBD4
	private static byte[] smethod_7(Class31 class31_2)
	{
		int num = class31_2.method_19();
		byte[] array = new byte[num];
		class31_2.method_14(array, 0, num);
		return array;
	}

	// Token: 0x06000079 RID: 121 RVA: 0x000109FC File Offset: 0x0000EBFC
	private void method_68(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		Class94 class94_4 = this.method_300();
		this.method_195(this.method_26(class94_4, class94_3, true));
	}

	// Token: 0x0600007A RID: 122 RVA: 0x00002F69 File Offset: 0x00001169
	private static void smethod_8(Exception exception_0)
	{
		ExceptionDispatchInfo.Capture(exception_0).Throw();
	}

	// Token: 0x0600007B RID: 123 RVA: 0x00002F76 File Offset: 0x00001176
	private Class12 method_69(Class31 class31_2)
	{
		Class12 @class = new Class12();
		@class.method_1(class31_2.method_19());
		return @class;
	}

	// Token: 0x0600007C RID: 124 RVA: 0x00002F89 File Offset: 0x00001189
	private void method_70(Class94 class94_2)
	{
		this.method_195(class94_2);
	}

	// Token: 0x0600007D RID: 125 RVA: 0x00010A28 File Offset: 0x0000EC28
	private FieldInfo method_71(int int_0)
	{
		Dictionary<int, object> obj = Class4.dictionary_3;
		FieldInfo result;
		lock (obj)
		{
			bool flag = true;
			object obj2;
			FieldInfo fieldInfo;
			if (Class4.dictionary_3.TryGetValue(int_0, out obj2))
			{
				fieldInfo = (FieldInfo)obj2;
			}
			else
			{
				Class3 class3_ = this.method_130(int_0);
				fieldInfo = this.method_0(int_0, class3_, ref flag);
				if (flag)
				{
					Class4.dictionary_3.Add(int_0, fieldInfo);
				}
			}
			this.method_135(fieldInfo);
			result = fieldInfo;
		}
		return result;
	}

	// Token: 0x0600007E RID: 126 RVA: 0x00002F92 File Offset: 0x00001192
	private void method_72()
	{
		this.bool_1 = true;
	}

	// Token: 0x0600007F RID: 127 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_73(Class31 class31_2)
	{
	}

	// Token: 0x06000080 RID: 128 RVA: 0x00002F9B File Offset: 0x0000119B
	private void method_74(Class94 class94_2)
	{
		this.method_109(typeof(byte));
	}

	// Token: 0x06000081 RID: 129 RVA: 0x00010AA4 File Offset: 0x0000ECA4
	private void method_75(Class94 class94_2)
	{
		Class119 @class = (Class119)class94_2;
		Class112 class2 = new Class112();
		class2.method_3(this.class94_0[(int)@class.method_2()]);
		this.method_195(class2);
	}

	// Token: 0x06000082 RID: 130 RVA: 0x00010ADC File Offset: 0x0000ECDC
	private void method_76(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		Class94 class94_4 = this.method_300();
		this.method_195(this.method_52(class94_4, class94_3, false));
	}

	// Token: 0x06000083 RID: 131 RVA: 0x00010B08 File Offset: 0x0000ED08
	private void method_77(Class94 class94_2)
	{
		Class94 @class = this.method_300();
		int num = @class.vmethod_2();
		checked
		{
			ushort int_;
			if (num <= 11)
			{
				if (num == 7)
				{
					int_ = (ushort)((uint)((Class118)@class).method_2());
					goto IL_6F;
				}
				if (num == 11)
				{
					int_ = (ushort)((ulong)((Class99)@class).method_2());
					goto IL_6F;
				}
			}
			else
			{
				if (num == 17)
				{
					int_ = (ushort)((Class117)@class).method_2();
					goto IL_6F;
				}
				if (num == 24)
				{
					int_ = (ushort)Convert.ToUInt64(((Class98)@class).method_2());
					goto IL_6F;
				}
			}
			throw new InvalidOperationException();
			IL_6F:
			Class118 class2 = new Class118();
			class2.method_3((int)int_);
			this.method_195(class2);
		}
	}

	// Token: 0x06000084 RID: 132 RVA: 0x00010B98 File Offset: 0x0000ED98
	private void method_78(Class94 class94_2)
	{
		Array array = (Array)this.method_300().vmethod_0();
		Class118 @class = new Class118();
		@class.method_3(array.Length);
		this.method_195(@class);
	}

	// Token: 0x06000085 RID: 133 RVA: 0x00002F89 File Offset: 0x00001189
	private void method_79(Class94 class94_2)
	{
		this.method_195(class94_2);
	}

	// Token: 0x06000086 RID: 134 RVA: 0x00002FAD File Offset: 0x000011AD
	private void method_80(Class94 class94_2)
	{
		this.method_144(typeof(double));
	}

	// Token: 0x06000087 RID: 135 RVA: 0x00002FBF File Offset: 0x000011BF
	private void method_81(Class94 class94_2)
	{
		this.method_291(0);
	}

	// Token: 0x06000088 RID: 136 RVA: 0x00002FC8 File Offset: 0x000011C8
	private Class70 method_82(Class31 class31_2)
	{
		Class70 @class = new Class70();
		@class.method_1(class31_2.method_19());
		@class.method_3(class31_2.method_5());
		return @class;
	}

	// Token: 0x06000089 RID: 137 RVA: 0x00002FE7 File Offset: 0x000011E7
	private void method_83(Class94 class94_2)
	{
		this.method_241(true);
	}

	// Token: 0x0600008A RID: 138 RVA: 0x00010BD0 File Offset: 0x0000EDD0
	private void method_84(Class94 class94_2)
	{
		Class94 @class = this.method_300();
		int num = @class.vmethod_2();
		uint num2;
		if (num != 7)
		{
			if (num != 11)
			{
				if (num != 24)
				{
					throw new InvalidOperationException();
				}
				num2 = (uint)Convert.ToInt64(@class.vmethod_0());
			}
			else
			{
				num2 = (uint)((Class99)@class).method_2();
			}
		}
		else
		{
			num2 = (uint)((Class118)@class).method_2();
		}
		Class118[] array = (Class118[])((Class116)class94_2).method_2();
		if ((ulong)num2 >= (ulong)((long)array.Length))
		{
			return;
		}
		uint uint_ = (uint)array[(int)num2].method_2();
		this.method_244(uint_);
	}

	// Token: 0x0600008B RID: 139 RVA: 0x00010C5C File Offset: 0x0000EE5C
	private void method_85(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		if (!Class4.smethod_17(this.method_300(), class94_3))
		{
			uint uint_ = ((Class104)class94_2).method_2();
			this.method_244(uint_);
		}
	}

	// Token: 0x0600008C RID: 140 RVA: 0x00002FF0 File Offset: 0x000011F0
	private void method_86(Class94 class94_2)
	{
		this.method_265(typeof(ushort));
	}

	// Token: 0x0600008D RID: 141 RVA: 0x00010C94 File Offset: 0x0000EE94
	private void method_87(Class94 class94_2)
	{
		uint uint_ = ((Class104)class94_2).method_2();
		this.method_244(uint_);
	}

	// Token: 0x0600008E RID: 142 RVA: 0x00010CB4 File Offset: 0x0000EEB4
	private void method_88(Class94 class94_2)
	{
		Class94 @class = this.method_300();
		Class94 class94_3 = @class.vmethod_4();
		this.method_195(@class);
		this.method_195(class94_3);
	}

	// Token: 0x0600008F RID: 143 RVA: 0x00010CE0 File Offset: 0x0000EEE0
	private void method_89(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		Class94 class94_4 = this.method_300();
		this.method_195(this.method_26(class94_4, class94_3, false));
	}

	// Token: 0x06000090 RID: 144 RVA: 0x00003002 File Offset: 0x00001202
	private static void smethod_9(ILGenerator ilgenerator_0, Type type_9)
	{
		if (type_9 == Class60.type_0)
		{
			return;
		}
		ilgenerator_0.Emit(OpCodes.Castclass, type_9);
	}

	// Token: 0x06000091 RID: 145 RVA: 0x00010D0C File Offset: 0x0000EF0C
	private void method_90(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		if (Class4.smethod_20(this.method_300(), class94_3))
		{
			uint uint_ = ((Class104)class94_2).method_2();
			this.method_244(uint_);
		}
	}

	// Token: 0x06000092 RID: 146 RVA: 0x00003019 File Offset: 0x00001219
	private void method_91(Class94 class94_2)
	{
		Class118 @class = new Class118();
		@class.method_3(2);
		this.method_195(@class);
	}

	// Token: 0x06000093 RID: 147 RVA: 0x00002DF2 File Offset: 0x00000FF2
	private void method_92(Class94 class94_2)
	{
		this.method_275();
	}

	// Token: 0x06000094 RID: 148 RVA: 0x00010D44 File Offset: 0x0000EF44
	private void method_93(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		Class94 class94_4 = this.method_300();
		this.method_195(this.method_127(class94_4, class94_3));
	}

	// Token: 0x06000095 RID: 149 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_94()
	{
	}

	// Token: 0x06000096 RID: 150 RVA: 0x00010D70 File Offset: 0x0000EF70
	private void method_95(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		Class94 class94_4 = this.method_300();
		this.method_195(this.method_214(class94_4, class94_3, false, false));
	}

	// Token: 0x06000097 RID: 151 RVA: 0x0000302D File Offset: 0x0000122D
	private void method_96(Class94 class94_2)
	{
		throw new NotSupportedException("Cpblk not supported.");
	}

	// Token: 0x06000098 RID: 152 RVA: 0x00010D9C File Offset: 0x0000EF9C
	private static Class94 smethod_10(Class94 class94_2, Class94 class94_3, bool bool_2)
	{
		if (!bool_2)
		{
			long num = ((Class99)class94_2).method_2();
			long num2 = ((Class99)class94_3).method_2();
			Class99 @class = new Class99();
			@class.method_3(num % num2);
			return @class;
		}
		ulong num3 = (ulong)((Class99)class94_2).method_2();
		ulong num4 = (ulong)((Class99)class94_3).method_2();
		Class99 class2 = new Class99();
		class2.method_3((long)(num3 % num4));
		return class2;
	}

	// Token: 0x06000099 RID: 153 RVA: 0x00002DF2 File Offset: 0x00000FF2
	private void method_97(Class94 class94_2)
	{
		this.method_275();
	}

	// Token: 0x0600009A RID: 154 RVA: 0x00003039 File Offset: 0x00001239
	private static Exception smethod_11(string string_0, string string_1)
	{
		return new MethodAccessException(Class4.smethod_26(string.Format("security transparent method '{0}'", string_0), string.Format("security critical method '{0}'", string_1)));
	}

	// Token: 0x0600009B RID: 155 RVA: 0x00002DF2 File Offset: 0x00000FF2
	private void method_98(Class94 class94_2)
	{
		this.method_275();
	}

	// Token: 0x0600009C RID: 156 RVA: 0x0000305B File Offset: 0x0000125B
	private void method_99(Class94 class94_2)
	{
		this.method_265(typeof(short));
	}

	// Token: 0x0600009D RID: 157 RVA: 0x0000306D File Offset: 0x0000126D
	private void method_100(Class94 class94_2)
	{
		this.method_109(typeof(uint));
	}

	// Token: 0x0600009E RID: 158 RVA: 0x00010DFC File Offset: 0x0000EFFC
	private void method_101(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		Class94 class94_4 = this.method_300();
		this.method_195(this.method_21(class94_4, class94_3, false));
	}

	// Token: 0x0600009F RID: 159 RVA: 0x0000307F File Offset: 0x0000127F
	private void method_102(Class94 class94_2)
	{
		this.method_195(this.class94_1[3].vmethod_4());
	}

	// Token: 0x060000A0 RID: 160 RVA: 0x00003098 File Offset: 0x00001298
	private void method_103(Class94 class94_2)
	{
		throw new NotSupportedException("Arglist is not supported.");
	}

	// Token: 0x060000A1 RID: 161 RVA: 0x00010E28 File Offset: 0x0000F028
	private bool method_104(MethodBase methodBase_0, object object_3, ref object object_4, object[] object_5)
	{
		Type declaringType = methodBase_0.DeclaringType;
		if (declaringType == null)
		{
			return false;
		}
		if (Class60.smethod_0(declaringType))
		{
			if (string.Equals(methodBase_0.Name, "get_HasValue", StringComparison.Ordinal))
			{
				object_4 = (object_3 != null);
			}
			else if (string.Equals(methodBase_0.Name, "get_Value", StringComparison.Ordinal))
			{
				if (object_3 == null)
				{
					return ((bool?)null).Value;
				}
				object_4 = object_3;
			}
			else if (methodBase_0.Name.Equals("GetValueOrDefault", StringComparison.Ordinal))
			{
				if (object_3 == null)
				{
					object_4 = Activator.CreateInstance(Nullable.GetUnderlyingType(methodBase_0.DeclaringType));
				}
				object_4 = object_3;
			}
			else
			{
				if (object_3 != null || methodBase_0.IsStatic)
				{
					return false;
				}
				object_4 = null;
			}
			return true;
		}
		if (declaringType == Class4.type_5)
		{
			if (methodBase_0.Name.Equals("GetExecutingAssembly", StringComparison.Ordinal))
			{
				object_4 = Class60.assembly_0;
				return true;
			}
			if (this.object_0 != null && methodBase_0.Name == "GetCallingAssembly")
			{
				object[] array = this.object_0;
				for (int i = 0; i < array.Length; i++)
				{
					Assembly assembly = array[i] as Assembly;
					if (assembly != null)
					{
						object_4 = assembly;
						return true;
					}
				}
			}
		}
		else if (declaringType == Class4.type_3)
		{
			if (methodBase_0.Name == "GetCurrentMethod")
			{
				if (this.object_0 != null)
				{
					object[] array = this.object_0;
					for (int i = 0; i < array.Length; i++)
					{
						MethodBase methodBase = array[i] as MethodBase;
						if (methodBase != null)
						{
							object_4 = methodBase;
							return true;
						}
					}
				}
				object_4 = MethodBase.GetCurrentMethod();
				return true;
			}
		}
		else if (declaringType.IsArray && declaringType.GetArrayRank() >= 2)
		{
			return this.method_165(methodBase_0, object_3, ref object_4, object_5);
		}
		return false;
	}

	// Token: 0x060000A2 RID: 162 RVA: 0x00010FBC File Offset: 0x0000F1BC
	private void method_105(Class94 class94_2)
	{
		int int_ = ((Class118)class94_2).method_2();
		Type type_ = this.method_189(int_, true);
		this.method_144(type_);
	}

	// Token: 0x060000A3 RID: 163 RVA: 0x00010FE8 File Offset: 0x0000F1E8
	private void method_106(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		this.method_195(this.method_42(class94_3));
	}

	// Token: 0x060000A4 RID: 164 RVA: 0x0001100C File Offset: 0x0000F20C
	private static BindingFlags smethod_12(bool bool_2)
	{
		BindingFlags bindingFlags = BindingFlags.Public | BindingFlags.NonPublic;
		if (bool_2)
		{
			bindingFlags |= BindingFlags.Static;
		}
		else
		{
			bindingFlags |= BindingFlags.Instance;
		}
		return bindingFlags;
	}

	// Token: 0x060000A5 RID: 165 RVA: 0x000030A4 File Offset: 0x000012A4
	private void method_107(Class94 class94_2)
	{
		this.method_245(false);
	}

	// Token: 0x060000A6 RID: 166 RVA: 0x0001102C File Offset: 0x0000F22C
	private void method_108(Class94 class94_2)
	{
		int int_ = ((Class118)class94_2).method_2();
		Type t = this.method_189(int_, true);
		Class118 @class = new Class118();
		@class.method_3(Marshal.SizeOf(t));
		this.method_195(@class);
	}

	// Token: 0x060000A7 RID: 167 RVA: 0x00011068 File Offset: 0x0000F268
	private void method_109(Type type_9)
	{
		Class106 class106_ = (Class106)this.method_300();
		this.method_195(Class32.smethod_1(this.method_255(class106_).vmethod_0(), type_9));
	}

	// Token: 0x060000A8 RID: 168 RVA: 0x000030AD File Offset: 0x000012AD
	private void method_110(Class94 class94_2)
	{
		this.method_265(typeof(float));
	}

	// Token: 0x060000A9 RID: 169 RVA: 0x0001109C File Offset: 0x0000F29C
	private void method_111(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		Class94 class94_4 = this.method_300();
		Class118 @class = new Class118();
		@class.method_3(Class4.smethod_29(class94_4, class94_3) ? 1 : 0);
		this.method_195(@class);
	}

	// Token: 0x060000AA RID: 170 RVA: 0x000110D8 File Offset: 0x0000F2D8
	public static void smethod_13<T>(T[] gparam_0, Comparison<T> comparison_0)
	{
		KeyValuePair<int, T>[] array = new KeyValuePair<int, T>[gparam_0.Length];
		for (int i = 0; i < gparam_0.Length; i++)
		{
			array[i] = new KeyValuePair<int, T>(i, gparam_0[i]);
		}
		Array.Sort<KeyValuePair<int, T>, T>(array, gparam_0, new Class4.Class8<T>(comparison_0));
	}

	// Token: 0x060000AB RID: 171 RVA: 0x00011120 File Offset: 0x0000F320
	private void method_112(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		Class94 @class = this.method_300();
		bool flag;
		if (@class.vmethod_2() == 17)
		{
			flag = !Class4.smethod_29(@class, class94_3);
		}
		else
		{
			flag = !Class4.smethod_18(@class, class94_3);
		}
		if (flag)
		{
			uint uint_ = ((Class104)class94_2).method_2();
			this.method_244(uint_);
		}
	}

	// Token: 0x060000AC RID: 172 RVA: 0x00011174 File Offset: 0x0000F374
	private void method_113(Class94 class94_2)
	{
		int int_ = ((Class118)class94_2).method_2();
		FieldInfo fieldInfo_ = this.method_71(int_);
		this.method_195(new Class107(fieldInfo_, null));
	}

	// Token: 0x060000AD RID: 173 RVA: 0x000111A4 File Offset: 0x0000F3A4
	private void method_114(Class94 class94_2)
	{
		Class121 @class = (Class121)class94_2;
		this.method_291((int)@class.method_2());
	}

	// Token: 0x060000AE RID: 174 RVA: 0x000111C4 File Offset: 0x0000F3C4
	private void method_115(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		Class94 class94_4 = this.method_300();
		this.method_195(this.method_16(class94_4, class94_3, false, false));
	}

	// Token: 0x060000AF RID: 175 RVA: 0x000030BF File Offset: 0x000012BF
	private void method_116(Class94 class94_2)
	{
		this.method_291(2);
	}

	// Token: 0x060000B0 RID: 176 RVA: 0x000030C8 File Offset: 0x000012C8
	private void method_117(Class94 class94_2)
	{
		this.method_245(true);
	}

	// Token: 0x060000B1 RID: 177 RVA: 0x000111F0 File Offset: 0x0000F3F0
	[DebuggerNonUserCode]
	private MethodBase method_118(int int_0, Class3 class3_0)
	{
		Dictionary<int, object> obj = Class4.dictionary_3;
		MethodBase result;
		lock (obj)
		{
			bool flag = true;
			object obj2;
			if (Class4.dictionary_3.TryGetValue(int_0, out obj2))
			{
				result = (MethodBase)obj2;
			}
			else if (class3_0.method_0() == 1)
			{
				MethodBase methodBase = this.module_0.ResolveMethod(class3_0.method_2());
				if (flag)
				{
					Class4.dictionary_3.Add(int_0, methodBase);
				}
				result = methodBase;
			}
			else
			{
				Class36 @class = (Class36)class3_0.method_4();
				if (@class.method_3())
				{
					result = this.method_243(@class);
				}
				else
				{
					Type type = this.method_189(@class.method_4().method_2(), false);
					Type type2 = this.method_189(@class.method_12().method_2(), true);
					Type[] array = new Type[@class.method_8().Length];
					for (int i = 0; i < array.Length; i++)
					{
						array[i] = this.method_189(@class.method_8()[i].method_2(), true);
					}
					if (type.IsGenericType)
					{
						flag = false;
					}
					if (@class.method_6() == ".ctor")
					{
						ConstructorInfo constructor = type.GetConstructor(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic, null, CallingConventions.Any, array, null);
						if (constructor == null)
						{
							throw new Exception();
						}
						if (flag)
						{
							Class4.dictionary_3.Add(int_0, constructor);
						}
						result = constructor;
					}
					else
					{
						BindingFlags bindingAttr = Class4.smethod_12(@class.method_2());
						MethodBase methodBase2 = null;
						try
						{
							methodBase2 = type.GetMethod(@class.method_6(), bindingAttr, null, CallingConventions.Any, array, null);
						}
						catch (AmbiguousMatchException)
						{
							foreach (MethodInfo methodInfo in type.GetMethods(bindingAttr))
							{
								if (!(methodInfo.Name != @class.method_6()) && methodInfo.ReturnType == type2)
								{
									ParameterInfo[] parameters = methodInfo.GetParameters();
									if (parameters.Length == array.Length)
									{
										bool flag2 = false;
										for (int k = 0; k < array.Length; k++)
										{
											if (parameters[k].ParameterType != array[k])
											{
												flag2 = true;
												break;
											}
										}
										if (!flag2)
										{
											methodBase2 = methodInfo;
											break;
										}
									}
								}
							}
						}
						if (methodBase2 == null)
						{
							throw new Exception(string.Format("Cannot bind method: {0}.{1}", type.Name, @class.method_6()));
						}
						if (flag)
						{
							Class4.dictionary_3.Add(int_0, methodBase2);
						}
						result = methodBase2;
					}
				}
			}
		}
		return result;
	}

	// Token: 0x060000B2 RID: 178 RVA: 0x000030D1 File Offset: 0x000012D1
	private void method_119(Class94 class94_2)
	{
		throw new NotSupportedException("Refanyval is not supported.");
	}

	// Token: 0x060000B3 RID: 179 RVA: 0x00011470 File Offset: 0x0000F670
	private void method_120(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		if (Class4.smethod_18(this.method_300(), class94_3))
		{
			uint uint_ = ((Class104)class94_2).method_2();
			this.method_244(uint_);
		}
	}

	// Token: 0x060000B4 RID: 180 RVA: 0x000114A8 File Offset: 0x0000F6A8
	private void method_121(Class94 class94_2)
	{
		int int_ = ((Class118)class94_2).method_2();
		Class3 @class = this.method_130(int_);
		object obj;
		if (@class.method_0() != 1)
		{
			switch (@class.method_4().vmethod_0())
			{
			case 0:
				obj = this.method_71(int_).FieldHandle;
				goto IL_95;
			case 1:
				obj = this.method_189(int_, true).TypeHandle;
				goto IL_95;
			case 4:
				obj = this.method_234(int_).MethodHandle;
				goto IL_95;
			}
			throw new InvalidOperationException();
		}
		obj = this.method_4(@class.method_2());
		IL_95:
		Class102 class2 = new Class102();
		class2.method_3(obj);
		this.method_195(class2);
	}

	// Token: 0x060000B5 RID: 181 RVA: 0x0001155C File Offset: 0x0000F75C
	private void method_122(Class94 class94_2)
	{
		Class118 @class = (Class118)class94_2;
		MethodBase methodBase_ = this.method_234(@class.method_2());
		foreach (Class94 class94_3 in this.class94_0)
		{
			this.method_195(class94_3);
		}
		this.method_124(methodBase_, false);
	}

	// Token: 0x060000B6 RID: 182 RVA: 0x000115AC File Offset: 0x0000F7AC
	private void method_123(Class94 class94_2)
	{
		Class94 @class = this.method_300();
		int num = @class.vmethod_2();
		checked
		{
			int int_;
			if (num <= 11)
			{
				if (num == 7)
				{
					int_ = (int)((uint)((Class118)@class).method_2());
					goto IL_6F;
				}
				if (num == 11)
				{
					int_ = (int)((ulong)((Class99)@class).method_2());
					goto IL_6F;
				}
			}
			else
			{
				if (num == 17)
				{
					int_ = (int)((Class117)@class).method_2();
					goto IL_6F;
				}
				if (num == 24)
				{
					int_ = (int)Convert.ToUInt64(((Class98)@class).method_2());
					goto IL_6F;
				}
			}
			throw new InvalidOperationException();
			IL_6F:
			Class118 class2 = new Class118();
			class2.method_3(int_);
			this.method_195(class2);
		}
	}

	// Token: 0x060000B7 RID: 183 RVA: 0x0001163C File Offset: 0x0000F83C
	private void method_124(MethodBase methodBase_0, bool bool_2)
	{
		if (!bool_2 && this.method_278(methodBase_0))
		{
			methodBase_0 = this.method_15(methodBase_0, bool_2);
		}
		ParameterInfo[] parameters = methodBase_0.GetParameters();
		int num = parameters.Length;
		Class94[] array = new Class94[num];
		object[] array2 = new object[num];
		Class4.Struct0 @struct = default(Class4.Struct0);
		try
		{
			this.method_200(ref @struct, methodBase_0, bool_2);
			for (int i = num - 1; i >= 0; i--)
			{
				Class94 @class = this.method_300();
				array[i] = @class;
				Class106 class106_;
				if ((class106_ = (@class as Class106)) != null)
				{
					@class = this.method_255(class106_);
				}
				if (@class.method_0() != null)
				{
					@class = Class32.smethod_1(null, @class.method_0()).vmethod_3(@class);
				}
				Class94 class2 = Class32.smethod_1(null, parameters[i].ParameterType).vmethod_3(@class);
				array2[i] = class2.vmethod_0();
			}
			Class94 class3 = null;
			if (!methodBase_0.IsStatic)
			{
				class3 = this.method_300();
				if (class3 != null && class3.method_0() != null)
				{
					class3 = Class32.smethod_1(null, class3.method_0()).vmethod_3(class3);
				}
			}
			object obj = null;
			try
			{
				Class106 class4;
				if (methodBase_0.IsConstructor)
				{
					obj = Activator.CreateInstance(methodBase_0.DeclaringType, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic, null, array2, null);
					class4 = (class3 as Class106);
					if (class4 == null)
					{
						throw new InvalidOperationException();
					}
				}
				else
				{
					object obj2 = null;
					if (class3 != null)
					{
						Class94 class5 = class3;
						Class106 class106_2;
						if ((class106_2 = (class3 as Class106)) != null)
						{
							class5 = this.method_255(class106_2);
						}
						obj2 = class5.vmethod_0();
					}
					try
					{
						if (!this.method_104(methodBase_0, obj2, ref obj, array2))
						{
							if (bool_2 && !methodBase_0.IsStatic && obj2 == null)
							{
								throw new NullReferenceException();
							}
							if (!this.method_10(methodBase_0, obj2, array, array2, bool_2, ref obj))
							{
								obj = this.method_159(methodBase_0, obj2, array2, bool_2);
							}
						}
						Class106 class106_3;
						if ((class106_3 = (class3 as Class106)) != null)
						{
							this.method_142(class106_3, Class32.smethod_1(obj2, methodBase_0.DeclaringType));
						}
						goto IL_217;
					}
					catch (TargetInvocationException ex)
					{
						Exception object_ = ex.InnerException ?? ex;
						this.method_215(object_);
						goto IL_217;
					}
				}
				this.method_142(class4, Class32.smethod_1(obj, methodBase_0.DeclaringType));
			}
			finally
			{
				for (int j = 0; j < array.Length; j++)
				{
					Class106 class106_4;
					if ((class106_4 = (array[j] as Class106)) != null)
					{
						object obj3 = array2[j];
						this.method_142(class106_4, Class32.smethod_1(obj3, null));
					}
				}
			}
			IL_217:
			MethodInfo methodInfo = methodBase_0 as MethodInfo;
			if (methodInfo != null)
			{
				Type returnType = methodInfo.ReturnType;
				if (returnType != Class4.type_1)
				{
					this.method_195(Class32.smethod_1(obj, returnType));
				}
			}
		}
		finally
		{
			this.method_235(ref @struct);
		}
	}

	// Token: 0x060000B8 RID: 184 RVA: 0x000118E4 File Offset: 0x0000FAE4
	private void method_125(Class94 class94_2)
	{
		int int_ = ((Class118)class94_2).method_2();
		Type type = this.method_189(int_, true);
		Class106 @class = (Class106)this.method_300();
		if (!type.IsValueType)
		{
			this.method_142(@class, new Class102());
			return;
		}
		object obj = this.method_255(@class).vmethod_0();
		if (Class60.smethod_0(type))
		{
			Class106 class106_ = @class;
			Class102 class2 = new Class102();
			class2.method_1(type);
			this.method_142(class106_, class2);
			return;
		}
		foreach (FieldInfo fieldInfo in type.GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.FlattenHierarchy))
		{
			fieldInfo.SetValue(obj, Class4.smethod_19(fieldInfo.FieldType));
		}
	}

	// Token: 0x060000B9 RID: 185 RVA: 0x000030DD File Offset: 0x000012DD
	private void method_126(Class94 class94_2)
	{
		this.method_291(1);
	}

	// Token: 0x060000BA RID: 186 RVA: 0x00011988 File Offset: 0x0000FB88
	private Class94 method_127(Class94 class94_2, Class94 class94_3)
	{
		if (class94_2.vmethod_2() == 7)
		{
			if (class94_3.vmethod_2() == 7)
			{
				int num = ((Class118)class94_2).method_2();
				int num2 = ((Class118)class94_3).method_2();
				int int_ = num << num2;
				Class118 @class = new Class118();
				@class.method_3(int_);
				return @class;
			}
			if (class94_3.vmethod_2() == 24)
			{
				Class118 class2 = new Class118();
				class2.method_3(Convert.ToInt32(class94_3.vmethod_0()));
				return this.method_127(class94_2, class2);
			}
		}
		if (class94_2.vmethod_2() == 11)
		{
			if (class94_3.vmethod_2() == 7)
			{
				long num3 = ((Class99)class94_2).method_2();
				int num4 = ((Class118)class94_3).method_2();
				long long_ = num3 << num4;
				Class99 class3 = new Class99();
				class3.method_3(long_);
				return class3;
			}
			if (class94_3.vmethod_2() == 24)
			{
				Class118 class4 = new Class118();
				class4.method_3(Convert.ToInt32(class94_3.vmethod_0()));
				return this.method_127(class94_2, class4);
			}
		}
		if (class94_2.vmethod_2() == 24)
		{
			Type underlyingType = Enum.GetUnderlyingType(class94_2.vmethod_0().GetType());
			if (underlyingType != typeof(long))
			{
				if (underlyingType != typeof(ulong))
				{
					Class118 class5 = new Class118();
					class5.method_3(Convert.ToInt32(class94_2.vmethod_0()));
					return this.method_127(class5, class94_3);
				}
			}
			Class99 class6 = new Class99();
			class6.method_3(Convert.ToInt64(class94_2.vmethod_0()));
			return this.method_127(class6, class94_3);
		}
		throw new InvalidOperationException();
	}

	// Token: 0x060000BB RID: 187 RVA: 0x000030E6 File Offset: 0x000012E6
	private void method_128(Stream stream_1, string string_0)
	{
		this.method_22(stream_1, 0L, string_0);
	}

	// Token: 0x060000BC RID: 188 RVA: 0x00011AD8 File Offset: 0x0000FCD8
	private Class12[] method_129(Class31 class31_2)
	{
		Class12[] array = new Class12[(int)class31_2.method_23()];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = this.method_69(class31_2);
		}
		return array;
	}

	// Token: 0x060000BD RID: 189 RVA: 0x00011B10 File Offset: 0x0000FD10
	private Class3 method_130(int int_0)
	{
		if (this.class31_1 == null)
		{
			throw new InvalidOperationException();
		}
		Class50 obj = this.class31_1.method_0();
		Class3 result;
		lock (obj)
		{
			this.class31_1.method_0().vmethod_9((long)int_0, 0);
			Class3 @class = new Class3();
			@class.method_1(this.class31_1.method_6());
			if (@class.method_0() == 1)
			{
				@class.method_3(this.class31_1.method_19());
			}
			else
			{
				@class.method_5(this.method_187(this.class31_1));
			}
			result = @class;
		}
		return result;
	}

	// Token: 0x060000BE RID: 190 RVA: 0x00011BB4 File Offset: 0x0000FDB4
	private Class94 method_131(Class94 class94_2, Class94 class94_3, bool bool_2, bool bool_3)
	{
		if (class94_2.vmethod_2() == 7)
		{
			if (class94_3.vmethod_2() == 7)
			{
				if (!bool_3)
				{
					int num = ((Class118)class94_2).method_2();
					int num2 = ((Class118)class94_3).method_2();
					int int_;
					if (bool_2)
					{
						int_ = checked(num - num2);
					}
					else
					{
						int_ = num - num2;
					}
					Class118 @class = new Class118();
					@class.method_3(int_);
					return @class;
				}
				uint num3 = (uint)((Class118)class94_2).method_2();
				uint num4 = (uint)((Class118)class94_3).method_2();
				uint int_2;
				if (bool_2)
				{
					int_2 = checked(num3 - num4);
				}
				else
				{
					int_2 = num3 - num4;
				}
				Class118 class2 = new Class118();
				class2.method_3((int)int_2);
				return class2;
			}
			else
			{
				if (class94_3.vmethod_2() == 11)
				{
					Class99 class3 = new Class99();
					class3.method_3((long)((Class118)class94_2).method_2());
					return Class4.smethod_3(class3, class94_3, bool_2, bool_3);
				}
				if (class94_3.vmethod_2() == 24)
				{
					Type underlyingType = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
					if (underlyingType != typeof(long))
					{
						if (underlyingType != typeof(ulong))
						{
							Class118 class4 = new Class118();
							class4.method_3(Convert.ToInt32(class94_3.vmethod_0()));
							return this.method_131(class94_2, class4, bool_2, bool_3);
						}
					}
					Class99 class5 = new Class99();
					class5.method_3((long)((Class118)class94_2).method_2());
					Class99 class6 = new Class99();
					class6.method_3(Convert.ToInt64(class94_3.vmethod_0()));
					return Class4.smethod_3(class5, class6, bool_2, bool_3);
				}
			}
		}
		if (class94_2.vmethod_2() == 11)
		{
			if (class94_3.vmethod_2() == 11)
			{
				return Class4.smethod_3(class94_2, class94_3, bool_2, bool_3);
			}
			if (class94_3.vmethod_2() == 7)
			{
				Class99 class7 = new Class99();
				class7.method_3((long)((Class118)class94_3).method_2());
				return Class4.smethod_3(class94_2, class7, bool_2, bool_3);
			}
			if (class94_3.vmethod_2() == 24)
			{
				Type underlyingType2 = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
				if (underlyingType2 != typeof(long))
				{
					if (underlyingType2 != typeof(ulong))
					{
						Class118 class8 = new Class118();
						class8.method_3(Convert.ToInt32(class94_3.vmethod_0()));
						return Class4.smethod_3(class94_2, class8, bool_2, bool_3);
					}
				}
				Class99 class9 = new Class99();
				class9.method_3(Convert.ToInt64(class94_3.vmethod_0()));
				return Class4.smethod_3(class94_2, class9, bool_2, bool_3);
			}
		}
		if (class94_2.vmethod_2() == 17 && class94_3.vmethod_2() == 17)
		{
			Class117 class10 = new Class117();
			class10.method_3(((Class117)class94_2).method_2() - ((Class117)class94_3).method_2());
			return class10;
		}
		if (class94_2.vmethod_2() == 24)
		{
			Type underlyingType3 = Enum.GetUnderlyingType(class94_2.vmethod_0().GetType());
			if (underlyingType3 != typeof(long))
			{
				if (underlyingType3 != typeof(ulong))
				{
					Class118 class11 = new Class118();
					class11.method_3(Convert.ToInt32(class94_2.vmethod_0()));
					return this.method_131(class11, class94_3, bool_2, bool_3);
				}
			}
			Class99 class12 = new Class99();
			class12.method_3(Convert.ToInt64(class94_2.vmethod_0()));
			return this.method_131(class12, class94_3, bool_2, bool_3);
		}
		throw new InvalidOperationException();
	}

	// Token: 0x060000BF RID: 191 RVA: 0x00011E84 File Offset: 0x00010084
	private void method_132(Class94 class94_2)
	{
		int int_ = ((Class118)class94_2).method_2();
		Type type = this.method_189(int_, true);
		Class94 @class = Class32.smethod_1(this.method_300().vmethod_0(), type);
		@class.method_1(type);
		this.method_195(@class);
	}

	// Token: 0x060000C0 RID: 192 RVA: 0x00002F89 File Offset: 0x00001189
	private void method_133(Class94 class94_2)
	{
		this.method_195(class94_2);
	}

	// Token: 0x060000C1 RID: 193 RVA: 0x00011EC8 File Offset: 0x000100C8
	private void method_134(Class94 class94_2)
	{
		int int_ = ((Class118)class94_2).method_2();
		string string_ = this.method_17(int_);
		Class113 @class = new Class113();
		@class.method_3(string_);
		this.method_195(@class);
	}

	// Token: 0x060000C2 RID: 194 RVA: 0x00011EFC File Offset: 0x000100FC
	private void method_135(MemberInfo memberInfo_0)
	{
		if (Class4.smethod_5() && !this.class86_0.method_13())
		{
			bool flag = false;
			Assembly assembly = typeof(SecurityCriticalAttribute).Assembly;
			MemberInfo memberInfo = memberInfo_0;
			while (memberInfo != null)
			{
				object[] customAttributes = memberInfo.GetCustomAttributes(false);
				for (int i = 0; i < customAttributes.Length; i++)
				{
					Type type = customAttributes[i].GetType();
					if (type.Assembly == assembly)
					{
						string fullName = type.FullName;
						if ("System.Security.SecurityCriticalAttribute".Equals(fullName, StringComparison.Ordinal))
						{
							flag = true;
							goto IL_91;
						}
						if ("System.Security.SecuritySafeCriticalAttribute".Equals(fullName, StringComparison.Ordinal))
						{
							goto IL_91;
						}
					}
				}
				memberInfo = memberInfo.DeclaringType;
				continue;
				IL_91:
				if (!flag)
				{
					return;
				}
				if (memberInfo_0 is MethodBase)
				{
					string string_ = Class4.smethod_21((MethodBase)memberInfo_0);
					throw Class4.smethod_11(this.method_192(this.class86_0), string_);
				}
				if (memberInfo_0 is FieldInfo)
				{
					Type declaringType = memberInfo_0.DeclaringType;
					string string_2 = string.Format("{0}.{1}", declaringType.FullName, memberInfo_0.Name);
					throw Class4.smethod_0(this.method_192(this.class86_0), string_2);
				}
				if (memberInfo_0 is Type)
				{
					string fullName2 = ((Type)memberInfo_0).FullName;
					throw Class4.smethod_16(this.method_192(this.class86_0), fullName2);
				}
				throw new SecurityException("A caller does not have the permissions required to access a resource.");
			}
			goto IL_91;
		}
	}

	// Token: 0x060000C3 RID: 195 RVA: 0x000030F9 File Offset: 0x000012F9
	private void method_136(Class94 class94_2)
	{
		this.method_44(false);
	}

	// Token: 0x060000C4 RID: 196 RVA: 0x0001203C File Offset: 0x0001023C
	private void method_137(Class94 class94_2)
	{
		int int_ = ((Class118)class94_2).method_2();
		FieldInfo fieldInfo = this.method_71(int_);
		this.method_195(Class32.smethod_1(fieldInfo.GetValue(null), fieldInfo.FieldType));
	}

	// Token: 0x060000C5 RID: 197 RVA: 0x00003102 File Offset: 0x00001302
	private void method_138(Class94 class94_2)
	{
		Debugger.Break();
	}

	// Token: 0x060000C6 RID: 198 RVA: 0x00003109 File Offset: 0x00001309
	public void method_139(Stream stream_1, string string_0, object[] object_3)
	{
		this.method_256(stream_1, string_0, object_3);
	}

	// Token: 0x060000C7 RID: 199 RVA: 0x00003115 File Offset: 0x00001315
	private void method_140(Class94 class94_2)
	{
		throw new NotSupportedException("Mkrefany is not supported.");
	}

	// Token: 0x060000C8 RID: 200 RVA: 0x00012078 File Offset: 0x00010278
	private void method_141(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		Class94 class94_4 = this.method_300();
		this.method_195(this.method_229(class94_4, class94_3));
	}

	// Token: 0x060000C9 RID: 201 RVA: 0x000120A4 File Offset: 0x000102A4
	private void method_142(Class106 class106_0, Class94 class94_2)
	{
		int num = class106_0.vmethod_2();
		if (num != 3)
		{
			switch (num)
			{
			case 12:
				((Class112)class106_0).method_2().vmethod_3(class94_2);
				return;
			case 13:
				this.class94_1[((Class108)class106_0).method_2()].vmethod_3(class94_2);
				return;
			case 16:
				goto IL_CC;
			case 18:
			{
				Class107 @class = (Class107)class106_0;
				FieldInfo fieldInfo = @class.method_4();
				Class94 class2 = Class32.smethod_1(class94_2.vmethod_0(), fieldInfo.FieldType);
				fieldInfo.SetValue(@class.method_2(), class2.vmethod_0());
				Class106 class3 = @class.method_6();
				if (class3 != null && fieldInfo.DeclaringType.IsValueType)
				{
					this.method_142(class3, Class32.smethod_1(@class.method_2(), null));
					return;
				}
				return;
			}
			}
			throw new ArgumentOutOfRangeException();
		}
		IL_CC:
		Class109 class4 = (Class109)class106_0;
		Class94 class5 = Class32.smethod_1(class94_2.vmethod_0(), class4.method_2());
		class4.vmethod_6(class5.vmethod_0());
	}

	// Token: 0x060000CA RID: 202 RVA: 0x000121A8 File Offset: 0x000103A8
	private void method_143(Class94 class94_2)
	{
		Class121 @class = (Class121)class94_2;
		this.method_195(this.class94_0[(int)@class.method_2()].vmethod_4());
	}

	// Token: 0x060000CB RID: 203 RVA: 0x000121D8 File Offset: 0x000103D8
	private void method_144(Type type_9)
	{
		object object_ = this.method_300().vmethod_0();
		long long_ = this.method_55();
		Array array_ = (Array)this.method_300().vmethod_0();
		this.method_147(type_9, object_, long_, array_);
	}

	// Token: 0x060000CC RID: 204 RVA: 0x00002DF2 File Offset: 0x00000FF2
	private void method_145(Class94 class94_2)
	{
		this.method_275();
	}

	// Token: 0x060000CD RID: 205 RVA: 0x00012214 File Offset: 0x00010414
	private static bool smethod_14(Class94 class94_2, Class94 class94_3)
	{
		bool result = false;
		int num = class94_2.vmethod_2();
		if (num <= 11)
		{
			if (num != 7)
			{
				if (num == 11)
				{
					if (class94_3.vmethod_2() == 24)
					{
						Class99 @class = new Class99();
						@class.method_3(Convert.ToInt64(((Class98)class94_3).method_2()));
						return Class4.smethod_14(class94_2, @class);
					}
					if (class94_3.vmethod_2() == 7)
					{
						Class99 class2 = new Class99();
						class2.method_3((long)((Class118)class94_3).method_2());
						return Class4.smethod_14(class94_2, class2);
					}
					result = (((Class99)class94_2).method_2() < ((Class99)class94_3).method_2());
				}
			}
			else
			{
				if (class94_3.vmethod_2() == 24)
				{
					Class118 class3 = new Class118();
					class3.method_3(Convert.ToInt32(((Class98)class94_3).method_2()));
					return Class4.smethod_14(class94_2, class3);
				}
				result = (((Class118)class94_2).method_2() < ((Class118)class94_3).method_2());
			}
		}
		else if (num != 17)
		{
			if (num == 24)
			{
				Class99 class4 = new Class99();
				class4.method_3(Convert.ToInt64(((Class98)class94_2).method_2()));
				return Class4.smethod_14(class4, class94_3);
			}
		}
		else
		{
			result = (((Class117)class94_2).method_2() < ((Class117)class94_3).method_2());
		}
		return result;
	}

	// Token: 0x060000CE RID: 206 RVA: 0x00003121 File Offset: 0x00001321
	private void method_146(Class94 class94_2)
	{
		this.method_291(3);
	}

	// Token: 0x060000CF RID: 207 RVA: 0x00012340 File Offset: 0x00010540
	private void method_147(Type type_9, object object_3, long long_1, Array array_0)
	{
		Class94 @class = Class32.smethod_1(object_3, type_9);
		array_0.SetValue(@class.vmethod_0(), long_1);
	}

	// Token: 0x060000D0 RID: 208 RVA: 0x00012364 File Offset: 0x00010564
	private void method_148(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		if (Class4.smethod_14(this.method_300(), class94_3))
		{
			uint uint_ = ((Class104)class94_2).method_2();
			this.method_244(uint_);
		}
	}

	// Token: 0x060000D1 RID: 209 RVA: 0x0000312A File Offset: 0x0000132A
	private void method_149(Class94 class94_2)
	{
		this.method_258(true);
	}

	// Token: 0x060000D2 RID: 210 RVA: 0x0001239C File Offset: 0x0001059C
	private void method_150(bool bool_2)
	{
		Class94 @class = this.method_300();
		int num = @class.vmethod_2();
		short int_;
		if (num <= 11)
		{
			if (num != 7)
			{
				if (num == 11)
				{
					if (bool_2)
					{
						int_ = checked((short)((Class99)@class).method_2());
						goto IL_BD;
					}
					int_ = (short)((Class99)@class).method_2();
					goto IL_BD;
				}
			}
			else
			{
				if (bool_2)
				{
					int_ = checked((short)((Class118)@class).method_2());
					goto IL_BD;
				}
				int_ = (short)((Class118)@class).method_2();
				goto IL_BD;
			}
		}
		else if (num != 17)
		{
			if (num == 24)
			{
				if (bool_2)
				{
					int_ = checked((short)Convert.ToUInt64(((Class98)@class).method_2()));
					goto IL_BD;
				}
				int_ = (short)Convert.ToUInt64(((Class98)@class).method_2());
				goto IL_BD;
			}
		}
		else
		{
			if (bool_2)
			{
				int_ = checked((short)((Class117)@class).method_2());
				goto IL_BD;
			}
			int_ = (short)((Class117)@class).method_2();
			goto IL_BD;
		}
		throw new InvalidOperationException();
		IL_BD:
		Class118 class2 = new Class118();
		class2.method_3((int)int_);
		this.method_195(class2);
	}

	// Token: 0x060000D3 RID: 211 RVA: 0x00012478 File Offset: 0x00010678
	private void method_151(Class94 class94_2)
	{
		uint uint_ = ((Class104)class94_2).method_2();
		this.method_298(null, uint_);
	}

	// Token: 0x060000D4 RID: 212 RVA: 0x0001249C File Offset: 0x0001069C
	private void method_152()
	{
		long num = this.class31_0.method_0().vmethod_4();
		int key = this.class31_0.method_19();
		Class4.Class6 @class;
		if (!this.dictionary_0.TryGetValue(key, out @class))
		{
			throw new InvalidOperationException("Unsupported instruction.");
		}
		this.long_0 = num;
		@class.delegate1_0(this.method_230(this.class31_0, @class.class33_0.method_2()));
	}

	// Token: 0x060000D5 RID: 213 RVA: 0x0001250C File Offset: 0x0001070C
	private void method_153(Class94 class94_2)
	{
		Class94 @class = this.method_300();
		int num = @class.vmethod_2();
		checked
		{
			uint int_;
			if (num <= 11)
			{
				if (num == 7)
				{
					int_ = (uint)((Class118)@class).method_2();
					goto IL_6E;
				}
				if (num == 11)
				{
					int_ = (uint)((ulong)((Class99)@class).method_2());
					goto IL_6E;
				}
			}
			else
			{
				if (num == 17)
				{
					int_ = (uint)((Class117)@class).method_2();
					goto IL_6E;
				}
				if (num == 24)
				{
					int_ = (uint)Convert.ToUInt64(((Class98)@class).method_2());
					goto IL_6E;
				}
			}
			throw new InvalidOperationException();
			IL_6E:
			Class118 class2 = new Class118();
			class2.method_3((int)int_);
			this.method_195(class2);
		}
	}

	// Token: 0x060000D6 RID: 214 RVA: 0x0001259C File Offset: 0x0001079C
	private static Class27[] smethod_15(Class31 class31_2)
	{
		int num = (int)class31_2.method_23();
		Class27[] array = new Class27[num];
		for (int i = 0; i < num; i++)
		{
			array[i] = Class4.smethod_23(class31_2);
		}
		return array;
	}

	// Token: 0x060000D7 RID: 215 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_154(Class94 class94_2)
	{
	}

	// Token: 0x060000D8 RID: 216 RVA: 0x000125D4 File Offset: 0x000107D4
	private void method_155(Class94 class94_2)
	{
		Class94 @class = this.method_300();
		int num = @class.vmethod_2();
		checked
		{
			IntPtr intptr_;
			if (num <= 11)
			{
				if (num == 7)
				{
					intptr_ = new IntPtr((long)(unchecked((ulong)(checked((uint)((Class118)@class).method_2())))));
					goto IL_87;
				}
				if (num == 11)
				{
					intptr_ = new IntPtr((long)((ulong)((Class99)@class).method_2()));
					goto IL_87;
				}
			}
			else
			{
				if (num == 17)
				{
					intptr_ = new IntPtr((long)((Class117)@class).method_2());
					goto IL_87;
				}
				if (num == 24)
				{
					intptr_ = new IntPtr((long)Convert.ToUInt64(((Class98)@class).method_2()));
					goto IL_87;
				}
			}
			throw new InvalidOperationException();
			IL_87:
			Class105 class2 = new Class105();
			class2.method_3(intptr_);
			this.method_195(class2);
		}
	}

	// Token: 0x060000D9 RID: 217 RVA: 0x00003133 File Offset: 0x00001333
	private void method_156(Class94 class94_2)
	{
		this.method_195(this.class94_0[1].vmethod_4());
	}

	// Token: 0x060000DA RID: 218 RVA: 0x0001267C File Offset: 0x0001087C
	private void method_157(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		Class94 class94_4 = this.method_300();
		this.method_195(this.method_1(class94_4, class94_3));
	}

	// Token: 0x060000DB RID: 219 RVA: 0x000126A8 File Offset: 0x000108A8
	private void method_158(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		this.method_195(this.method_160(class94_3));
	}

	// Token: 0x060000DC RID: 220 RVA: 0x000126CC File Offset: 0x000108CC
	private object method_159(MethodBase methodBase_0, object object_3, object[] object_4, bool bool_2)
	{
		Class4.Struct2 struct2_ = new Class4.Struct2(methodBase_0, bool_2);
		Class4.Delegate0 @delegate = this.method_232(struct2_);
		if (@delegate == null)
		{
			Dictionary<MethodBase, int> obj = this.dictionary_4;
			bool flag;
			lock (obj)
			{
				int num;
				this.dictionary_4.TryGetValue(methodBase_0, out num);
				if (!(flag = (num >= 50)))
				{
					this.dictionary_4[methodBase_0] = num + 1;
				}
			}
			if (!(flag = (flag || (!bool_2 && object_3 == null && !methodBase_0.IsStatic && !methodBase_0.IsConstructor) || Class4.smethod_24(methodBase_0) || (methodBase_0.CallingConvention & CallingConventions.Any) == CallingConventions.VarArgs)))
			{
				return this.method_247(methodBase_0, object_3, object_4);
			}
			@delegate = this.method_27(struct2_);
			obj = this.dictionary_4;
			lock (obj)
			{
				this.dictionary_4.Remove(methodBase_0);
			}
		}
		return @delegate(object_3, object_4);
	}

	// Token: 0x060000DD RID: 221 RVA: 0x000127C0 File Offset: 0x000109C0
	private Class94 method_160(Class94 class94_2)
	{
		if (class94_2.vmethod_2() == 7)
		{
			int num = ((Class118)class94_2).method_2();
			Class118 @class = new Class118();
			@class.method_3(-num);
			return @class;
		}
		if (class94_2.vmethod_2() == 11)
		{
			long num2 = ((Class99)class94_2).method_2();
			Class99 class2 = new Class99();
			class2.method_3(-num2);
			return class2;
		}
		if (class94_2.vmethod_2() == 17)
		{
			Class117 class3 = new Class117();
			class3.method_3(-((Class117)class94_2).method_2());
			return class3;
		}
		if (class94_2.vmethod_2() == 24)
		{
			Type underlyingType = Enum.GetUnderlyingType(class94_2.vmethod_0().GetType());
			if (underlyingType != typeof(long))
			{
				if (underlyingType != typeof(ulong))
				{
					Class118 class4 = new Class118();
					class4.method_3(Convert.ToInt32(class94_2.vmethod_0()));
					return this.method_160(class4);
				}
			}
			Class99 class5 = new Class99();
			class5.method_3(Convert.ToInt64(class94_2.vmethod_0()));
			return this.method_160(class5);
		}
		throw new InvalidOperationException();
	}

	// Token: 0x060000DE RID: 222 RVA: 0x0000314C File Offset: 0x0000134C
	private void method_161(Class94 class94_2)
	{
		this.method_72();
	}

	// Token: 0x060000DF RID: 223 RVA: 0x000128AC File Offset: 0x00010AAC
	private void method_162(Class37 class37_0)
	{
		Class3 @class = this.method_130(class37_0.method_2());
		Class36 class2 = (Class36)@class.method_4();
		MethodBase methodBase = this.method_118(class37_0.method_2(), @class);
		methodBase.GetParameters();
		int num = class37_0.method_0();
		bool bool_ = (num & 1073741824) != 0;
		num &= -1073741825;
		Type[] array = this.type_7;
		Type[] array2 = this.type_2;
		try
		{
			this.type_7 = ((methodBase is ConstructorInfo) ? Type.EmptyTypes : methodBase.GetGenericArguments());
			this.type_2 = methodBase.DeclaringType.GetGenericArguments();
			this.method_205(num, this.type_7, this.type_2, bool_);
		}
		finally
		{
			this.type_7 = array;
			this.type_2 = array2;
		}
	}

	// Token: 0x060000E0 RID: 224 RVA: 0x00012974 File Offset: 0x00010B74
	private void method_163(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		Class94 class94_4 = this.method_300();
		this.method_195(this.method_16(class94_4, class94_3, true, false));
	}

	// Token: 0x060000E1 RID: 225 RVA: 0x00003154 File Offset: 0x00001354
	private void method_164(Class94 class94_2)
	{
		Class118 @class = new Class118();
		@class.method_3(5);
		this.method_195(@class);
	}

	// Token: 0x060000E2 RID: 226 RVA: 0x000129A0 File Offset: 0x00010BA0
	private bool method_165(MethodBase methodBase_0, object object_3, ref object object_4, object[] object_5)
	{
		if (!methodBase_0.IsStatic && methodBase_0.Name == "Address")
		{
			MethodInfo methodInfo = methodBase_0 as MethodInfo;
			if (methodInfo != null)
			{
				Type type = methodInfo.ReturnType;
				if (type.IsByRef)
				{
					type = type.GetElementType();
					int num = object_5.Length;
					if (num >= 1 && object_5[0] is int)
					{
						int[] array = new int[num];
						for (int i = 0; i < num; i++)
						{
							array[i] = (int)object_5[i];
						}
						Class111 @class = new Class111();
						@class.method_5((Array)object_3);
						@class.method_7(array);
						@class.method_3(type);
						object_4 = @class;
						return true;
					}
				}
			}
		}
		return false;
	}

	// Token: 0x060000E3 RID: 227 RVA: 0x00012A44 File Offset: 0x00010C44
	private Dictionary<int, Class4.Class6> method_166()
	{
		return new Dictionary<int, Class4.Class6>(256)
		{
			{
				this.class16_0.class33_103.method_0(),
				new Class4.Class6(this.class16_0.class33_103, new Class4.Delegate1(this.method_216))
			},
			{
				this.class16_0.class33_21.method_0(),
				new Class4.Class6(this.class16_0.class33_21, new Class4.Delegate1(this.method_29))
			},
			{
				this.class16_0.class33_155.method_0(),
				new Class4.Class6(this.class16_0.class33_155, new Class4.Delegate1(this.method_237))
			},
			{
				this.class16_0.class33_90.method_0(),
				new Class4.Class6(this.class16_0.class33_90, new Class4.Delegate1(this.method_219))
			},
			{
				this.class16_0.class33_52.method_0(),
				new Class4.Class6(this.class16_0.class33_52, new Class4.Delegate1(this.method_66))
			},
			{
				this.class16_0.class33_76.method_0(),
				new Class4.Class6(this.class16_0.class33_76, new Class4.Delegate1(this.method_190))
			},
			{
				this.class16_0.class33_98.method_0(),
				new Class4.Class6(this.class16_0.class33_98, new Class4.Delegate1(this.method_113))
			},
			{
				this.class16_0.class33_8.method_0(),
				new Class4.Class6(this.class16_0.class33_8, new Class4.Delegate1(this.method_50))
			},
			{
				this.class16_0.class33_45.method_0(),
				new Class4.Class6(this.class16_0.class33_45, new Class4.Delegate1(this.method_100))
			},
			{
				this.class16_0.class33_193.method_0(),
				new Class4.Class6(this.class16_0.class33_193, new Class4.Delegate1(this.method_277))
			},
			{
				this.class16_0.class33_6.method_0(),
				new Class4.Class6(this.class16_0.class33_6, new Class4.Delegate1(this.method_74))
			},
			{
				this.class16_0.class33_148.method_0(),
				new Class4.Class6(this.class16_0.class33_148, new Class4.Delegate1(this.method_110))
			},
			{
				this.class16_0.class33_195.method_0(),
				new Class4.Class6(this.class16_0.class33_195, new Class4.Delegate1(this.method_149))
			},
			{
				this.class16_0.class33_29.method_0(),
				new Class4.Class6(this.class16_0.class33_29, new Class4.Delegate1(this.method_156))
			},
			{
				this.class16_0.class33_113.method_0(),
				new Class4.Class6(this.class16_0.class33_113, new Class4.Delegate1(this.method_91))
			},
			{
				this.class16_0.class33_27.method_0(),
				new Class4.Class6(this.class16_0.class33_27, new Class4.Delegate1(this.method_210))
			},
			{
				this.class16_0.class33_31.method_0(),
				new Class4.Class6(this.class16_0.class33_31, new Class4.Delegate1(this.method_108))
			},
			{
				this.class16_0.class33_139.method_0(),
				new Class4.Class6(this.class16_0.class33_139, new Class4.Delegate1(this.method_13))
			},
			{
				this.class16_0.class33_47.method_0(),
				new Class4.Class6(this.class16_0.class33_47, new Class4.Delegate1(this.method_269))
			},
			{
				this.class16_0.class33_196.method_0(),
				new Class4.Class6(this.class16_0.class33_196, new Class4.Delegate1(this.method_240))
			},
			{
				this.class16_0.class33_100.method_0(),
				new Class4.Class6(this.class16_0.class33_100, new Class4.Delegate1(this.method_264))
			},
			{
				this.class16_0.class33_2.method_0(),
				new Class4.Class6(this.class16_0.class33_2, new Class4.Delegate1(this.method_199))
			},
			{
				this.class16_0.class33_163.method_0(),
				new Class4.Class6(this.class16_0.class33_163, new Class4.Delegate1(this.method_107))
			},
			{
				this.class16_0.class33_93.method_0(),
				new Class4.Class6(this.class16_0.class33_93, new Class4.Delegate1(this.method_155))
			},
			{
				this.class16_0.class33_14.method_0(),
				new Class4.Class6(this.class16_0.class33_14, new Class4.Delegate1(this.method_120))
			},
			{
				this.class16_0.class33_212.method_0(),
				new Class4.Class6(this.class16_0.class33_212, new Class4.Delegate1(this.method_56))
			},
			{
				this.class16_0.class33_116.method_0(),
				new Class4.Class6(this.class16_0.class33_116, new Class4.Delegate1(this.method_254))
			},
			{
				this.class16_0.class33_207.method_0(),
				new Class4.Class6(this.class16_0.class33_207, new Class4.Delegate1(this.method_40))
			},
			{
				this.class16_0.class33_82.method_0(),
				new Class4.Class6(this.class16_0.class33_82, new Class4.Delegate1(this.method_85))
			},
			{
				this.class16_0.class33_156.method_0(),
				new Class4.Class6(this.class16_0.class33_156, new Class4.Delegate1(this.method_86))
			},
			{
				this.class16_0.class33_28.method_0(),
				new Class4.Class6(this.class16_0.class33_28, new Class4.Delegate1(this.method_177))
			},
			{
				this.class16_0.class33_119.method_0(),
				new Class4.Class6(this.class16_0.class33_119, new Class4.Delegate1(this.method_38))
			},
			{
				this.class16_0.class33_15.method_0(),
				new Class4.Class6(this.class16_0.class33_15, new Class4.Delegate1(this.method_271))
			},
			{
				this.class16_0.class33_70.method_0(),
				new Class4.Class6(this.class16_0.class33_70, new Class4.Delegate1(this.method_33))
			},
			{
				this.class16_0.class33_205.method_0(),
				new Class4.Class6(this.class16_0.class33_205, new Class4.Delegate1(this.method_191))
			},
			{
				this.class16_0.class33_78.method_0(),
				new Class4.Class6(this.class16_0.class33_78, new Class4.Delegate1(this.method_141))
			},
			{
				this.class16_0.class33_62.method_0(),
				new Class4.Class6(this.class16_0.class33_62, new Class4.Delegate1(this.method_89))
			},
			{
				this.class16_0.class33_181.method_0(),
				new Class4.Class6(this.class16_0.class33_181, new Class4.Delegate1(this.method_257))
			},
			{
				this.class16_0.class33_11.method_0(),
				new Class4.Class6(this.class16_0.class33_11, new Class4.Delegate1(this.method_97))
			},
			{
				this.class16_0.class33_166.method_0(),
				new Class4.Class6(this.class16_0.class33_166, new Class4.Delegate1(this.method_198))
			},
			{
				this.class16_0.class33_134.method_0(),
				new Class4.Class6(this.class16_0.class33_134, new Class4.Delegate1(this.method_236))
			},
			{
				this.class16_0.class33_69.method_0(),
				new Class4.Class6(this.class16_0.class33_69, new Class4.Delegate1(this.method_92))
			},
			{
				this.class16_0.class33_53.method_0(),
				new Class4.Class6(this.class16_0.class33_53, new Class4.Delegate1(this.method_196))
			},
			{
				this.class16_0.class33_13.method_0(),
				new Class4.Class6(this.class16_0.class33_13, new Class4.Delegate1(this.method_203))
			},
			{
				this.class16_0.class33_59.method_0(),
				new Class4.Class6(this.class16_0.class33_59, new Class4.Delegate1(this.method_246))
			},
			{
				this.class16_0.class33_127.method_0(),
				new Class4.Class6(this.class16_0.class33_127, new Class4.Delegate1(this.method_102))
			},
			{
				this.class16_0.class33_105.method_0(),
				new Class4.Class6(this.class16_0.class33_105, new Class4.Delegate1(this.method_176))
			},
			{
				this.class16_0.class33_140.method_0(),
				new Class4.Class6(this.class16_0.class33_140, new Class4.Delegate1(this.method_182))
			},
			{
				this.class16_0.class33_154.method_0(),
				new Class4.Class6(this.class16_0.class33_154, new Class4.Delegate1(this.method_8))
			},
			{
				this.class16_0.class33_169.method_0(),
				new Class4.Class6(this.class16_0.class33_169, new Class4.Delegate1(this.method_95))
			},
			{
				this.class16_0.class33_137.method_0(),
				new Class4.Class6(this.class16_0.class33_137, new Class4.Delegate1(this.method_140))
			},
			{
				this.class16_0.class33_152.method_0(),
				new Class4.Class6(this.class16_0.class33_152, new Class4.Delegate1(this.method_169))
			},
			{
				this.class16_0.class33_194.method_0(),
				new Class4.Class6(this.class16_0.class33_194, new Class4.Delegate1(this.method_101))
			},
			{
				this.class16_0.class33_142.method_0(),
				new Class4.Class6(this.class16_0.class33_142, new Class4.Delegate1(this.method_7))
			},
			{
				this.class16_0.class33_12.method_0(),
				new Class4.Class6(this.class16_0.class33_12, new Class4.Delegate1(this.method_173))
			},
			{
				this.class16_0.class33_202.method_0(),
				new Class4.Class6(this.class16_0.class33_202, new Class4.Delegate1(this.method_218))
			},
			{
				this.class16_0.class33_206.method_0(),
				new Class4.Class6(this.class16_0.class33_206, new Class4.Delegate1(this.method_167))
			},
			{
				this.class16_0.class33_67.method_0(),
				new Class4.Class6(this.class16_0.class33_67, new Class4.Delegate1(this.method_252))
			},
			{
				this.class16_0.class33_141.method_0(),
				new Class4.Class6(this.class16_0.class33_141, new Class4.Delegate1(this.method_83))
			},
			{
				this.class16_0.class33_133.method_0(),
				new Class4.Class6(this.class16_0.class33_133, new Class4.Delegate1(this.method_282))
			},
			{
				this.class16_0.class33_68.method_0(),
				new Class4.Class6(this.class16_0.class33_68, new Class4.Delegate1(this.method_286))
			},
			{
				this.class16_0.class33_151.method_0(),
				new Class4.Class6(this.class16_0.class33_151, new Class4.Delegate1(this.method_297))
			},
			{
				this.class16_0.class33_91.method_0(),
				new Class4.Class6(this.class16_0.class33_91, new Class4.Delegate1(this.method_18))
			},
			{
				this.class16_0.class33_192.method_0(),
				new Class4.Class6(this.class16_0.class33_192, new Class4.Delegate1(this.method_231))
			},
			{
				this.class16_0.class33_115.method_0(),
				new Class4.Class6(this.class16_0.class33_115, new Class4.Delegate1(this.method_145))
			},
			{
				this.class16_0.class33_30.method_0(),
				new Class4.Class6(this.class16_0.class33_30, new Class4.Delegate1(this.method_59))
			},
			{
				this.class16_0.class33_201.method_0(),
				new Class4.Class6(this.class16_0.class33_201, new Class4.Delegate1(this.method_90))
			},
			{
				this.class16_0.class33_132.method_0(),
				new Class4.Class6(this.class16_0.class33_132, new Class4.Delegate1(this.method_225))
			},
			{
				this.class16_0.class33_125.method_0(),
				new Class4.Class6(this.class16_0.class33_125, new Class4.Delegate1(this.method_151))
			},
			{
				this.class16_0.class33_183.method_0(),
				new Class4.Class6(this.class16_0.class33_183, new Class4.Delegate1(this.method_68))
			},
			{
				this.class16_0.class33_110.method_0(),
				new Class4.Class6(this.class16_0.class33_110, new Class4.Delegate1(this.method_132))
			},
			{
				this.class16_0.class33_182.method_0(),
				new Class4.Class6(this.class16_0.class33_182, new Class4.Delegate1(this.method_116))
			},
			{
				this.class16_0.class33_89.method_0(),
				new Class4.Class6(this.class16_0.class33_89, new Class4.Delegate1(this.method_238))
			},
			{
				this.class16_0.class33_108.method_0(),
				new Class4.Class6(this.class16_0.class33_147, new Class4.Delegate1(this.method_61))
			},
			{
				this.class16_0.class33_54.method_0(),
				new Class4.Class6(this.class16_0.class33_54, new Class4.Delegate1(this.method_60))
			},
			{
				this.class16_0.class33_120.method_0(),
				new Class4.Class6(this.class16_0.class33_120, new Class4.Delegate1(this.method_163))
			},
			{
				this.class16_0.class33_46.method_0(),
				new Class4.Class6(this.class16_0.class33_46, new Class4.Delegate1(this.method_126))
			},
			{
				this.class16_0.class33_189.method_0(),
				new Class4.Class6(this.class16_0.class33_189, new Class4.Delegate1(this.method_153))
			},
			{
				this.class16_0.class33_146.method_0(),
				new Class4.Class6(this.class16_0.class33_146, new Class4.Delegate1(this.method_186))
			},
			{
				this.class16_0.class33_5.method_0(),
				new Class4.Class6(this.class16_0.class33_5, new Class4.Delegate1(this.method_12))
			},
			{
				this.class16_0.class33_138.method_0(),
				new Class4.Class6(this.class16_0.class33_138, new Class4.Delegate1(this.method_204))
			},
			{
				this.class16_0.class33_143.method_0(),
				new Class4.Class6(this.class16_0.class33_143, new Class4.Delegate1(this.method_285))
			},
			{
				this.class16_0.class33_88.method_0(),
				new Class4.Class6(this.class16_0.class33_88, new Class4.Delegate1(this.method_202))
			},
			{
				this.class16_0.class33_3.method_0(),
				new Class4.Class6(this.class16_0.class33_3, new Class4.Delegate1(this.method_295))
			},
			{
				this.class16_0.class33_44.method_0(),
				new Class4.Class6(this.class16_0.class33_44, new Class4.Delegate1(this.method_76))
			},
			{
				this.class16_0.class33_130.method_0(),
				new Class4.Class6(this.class16_0.class33_130, new Class4.Delegate1(this.method_115))
			},
			{
				this.class16_0.class33_180.method_0(),
				new Class4.Class6(this.class16_0.class33_180, new Class4.Delegate1(this.method_125))
			},
			{
				this.class16_0.class33_104.method_0(),
				new Class4.Class6(this.class16_0.class33_104, new Class4.Delegate1(this.method_183))
			},
			{
				this.class16_0.class33_102.method_0(),
				new Class4.Class6(this.class16_0.class33_102, new Class4.Delegate1(this.method_157))
			},
			{
				this.class16_0.class33_66.method_0(),
				new Class4.Class6(this.class16_0.class33_66, new Class4.Delegate1(this.method_138))
			},
			{
				this.class16_0.class33_153.method_0(),
				new Class4.Class6(this.class16_0.class33_153, new Class4.Delegate1(this.method_6))
			},
			{
				this.class16_0.class33_36.method_0(),
				new Class4.Class6(this.class16_0.class33_36, new Class4.Delegate1(this.method_193))
			},
			{
				this.class16_0.class33_81.method_0(),
				new Class4.Class6(this.class16_0.class33_81, new Class4.Delegate1(this.method_93))
			},
			{
				this.class16_0.class33_208.method_0(),
				new Class4.Class6(this.class16_0.class33_208, new Class4.Delegate1(this.method_194))
			},
			{
				this.class16_0.class33_144.method_0(),
				new Class4.Class6(this.class16_0.class33_144, new Class4.Delegate1(this.method_188))
			},
			{
				this.class16_0.class33_57.method_0(),
				new Class4.Class6(this.class16_0.class33_57, new Class4.Delegate1(this.method_137))
			},
			{
				this.class16_0.class33_171.method_0(),
				new Class4.Class6(this.class16_0.class33_171, new Class4.Delegate1(this.method_260))
			},
			{
				this.class16_0.class33_121.method_0(),
				new Class4.Class6(this.class16_0.class33_121, new Class4.Delegate1(this.method_87))
			},
			{
				this.class16_0.class33_199.method_0(),
				new Class4.Class6(this.class16_0.class33_199, new Class4.Delegate1(this.method_32))
			},
			{
				this.class16_0.class33_32.method_0(),
				new Class4.Class6(this.class16_0.class33_32, new Class4.Delegate1(this.method_78))
			},
			{
				this.class16_0.class33_157.method_0(),
				new Class4.Class6(this.class16_0.class33_157, new Class4.Delegate1(this.method_226))
			},
			{
				this.class16_0.class33_86.method_0(),
				new Class4.Class6(this.class16_0.class33_86, new Class4.Delegate1(this.method_212))
			},
			{
				this.class16_0.class33_109.method_0(),
				new Class4.Class6(this.class16_0.class33_109, new Class4.Delegate1(this.method_181))
			},
			{
				this.class16_0.class33_63.method_0(),
				new Class4.Class6(this.class16_0.class33_63, new Class4.Delegate1(this.method_81))
			},
			{
				this.class16_0.class33_97.method_0(),
				new Class4.Class6(this.class16_0.class33_97, new Class4.Delegate1(this.method_170))
			},
			{
				this.class16_0.class33_38.method_0(),
				new Class4.Class6(this.class16_0.class33_38, new Class4.Delegate1(this.method_84))
			},
			{
				this.class16_0.class33_118.method_0(),
				new Class4.Class6(this.class16_0.class33_118, new Class4.Delegate1(this.method_211))
			},
			{
				this.class16_0.class33_7.method_0(),
				new Class4.Class6(this.class16_0.class33_7, new Class4.Delegate1(this.method_25))
			},
			{
				this.class16_0.class33_58.method_0(),
				new Class4.Class6(this.class16_0.class33_58, new Class4.Delegate1(this.method_28))
			},
			{
				this.class16_0.class33_107.method_0(),
				new Class4.Class6(this.class16_0.class33_107, new Class4.Delegate1(this.method_9))
			},
			{
				this.class16_0.class33_84.method_0(),
				new Class4.Class6(this.class16_0.class33_84, new Class4.Delegate1(this.method_123))
			},
			{
				this.class16_0.class33_168.method_0(),
				new Class4.Class6(this.class16_0.class33_168, new Class4.Delegate1(this.method_250))
			},
			{
				this.class16_0.class33_200.method_0(),
				new Class4.Class6(this.class16_0.class33_200, new Class4.Delegate1(this.method_262))
			},
			{
				this.class16_0.class33_197.method_0(),
				new Class4.Class6(this.class16_0.class33_197, new Class4.Delegate1(this.method_77))
			},
			{
				this.class16_0.class33_213.method_0(),
				new Class4.Class6(this.class16_0.class33_213, new Class4.Delegate1(this.method_58))
			},
			{
				this.class16_0.class33_209.method_0(),
				new Class4.Class6(this.class16_0.class33_209, new Class4.Delegate1(this.method_65))
			},
			{
				this.class16_0.class33_37.method_0(),
				new Class4.Class6(this.class16_0.class33_37, new Class4.Delegate1(this.method_290))
			},
			{
				this.class16_0.class33_117.method_0(),
				new Class4.Class6(this.class16_0.class33_117, new Class4.Delegate1(this.method_80))
			},
			{
				this.class16_0.class33_85.method_0(),
				new Class4.Class6(this.class16_0.class33_85, new Class4.Delegate1(this.method_122))
			},
			{
				this.class16_0.class33_64.method_0(),
				new Class4.Class6(this.class16_0.class33_64, new Class4.Delegate1(this.method_283))
			},
			{
				this.class16_0.class33_35.method_0(),
				new Class4.Class6(this.class16_0.class33_35, new Class4.Delegate1(this.method_37))
			},
			{
				this.class16_0.class33_99.method_0(),
				new Class4.Class6(this.class16_0.class33_99, new Class4.Delegate1(this.method_294))
			},
			{
				this.class16_0.class33_55.method_0(),
				new Class4.Class6(this.class16_0.class33_55, new Class4.Delegate1(this.method_208))
			},
			{
				this.class16_0.class33_128.method_0(),
				new Class4.Class6(this.class16_0.class33_128, new Class4.Delegate1(this.method_161))
			},
			{
				this.class16_0.class33_186.method_0(),
				new Class4.Class6(this.class16_0.class33_186, new Class4.Delegate1(this.method_217))
			},
			{
				this.class16_0.class33_210.method_0(),
				new Class4.Class6(this.class16_0.class33_210, new Class4.Delegate1(this.method_224))
			},
			{
				this.class16_0.class33_123.method_0(),
				new Class4.Class6(this.class16_0.class33_123, new Class4.Delegate1(this.method_112))
			},
			{
				this.class16_0.class33_83.method_0(),
				new Class4.Class6(this.class16_0.class33_83, new Class4.Delegate1(this.method_88))
			},
			{
				this.class16_0.class33_73.method_0(),
				new Class4.Class6(this.class16_0.class33_73, new Class4.Delegate1(this.method_19))
			},
			{
				this.class16_0.class33_170.method_0(),
				new Class4.Class6(this.class16_0.class33_170, new Class4.Delegate1(this.method_114))
			},
			{
				this.class16_0.class33_172.method_0(),
				new Class4.Class6(this.class16_0.class33_172, new Class4.Delegate1(this.method_79))
			},
			{
				this.class16_0.class33_71.method_0(),
				new Class4.Class6(this.class16_0.class33_71, new Class4.Delegate1(this.method_111))
			},
			{
				this.class16_0.class33_18.method_0(),
				new Class4.Class6(this.class16_0.class33_18, new Class4.Delegate1(this.method_276))
			},
			{
				this.class16_0.class33_42.method_0(),
				new Class4.Class6(this.class16_0.class33_42, new Class4.Delegate1(this.method_96))
			},
			{
				this.class16_0.class33_16.method_0(),
				new Class4.Class6(this.class16_0.class33_16, new Class4.Delegate1(this.method_106))
			},
			{
				this.class16_0.class33_61.method_0(),
				new Class4.Class6(this.class16_0.class33_61, new Class4.Delegate1(this.method_180))
			},
			{
				this.class16_0.class33_40.method_0(),
				new Class4.Class6(this.class16_0.class33_40, new Class4.Delegate1(this.method_228))
			},
			{
				this.class16_0.class33_145.method_0(),
				new Class4.Class6(this.class16_0.class33_145, new Class4.Delegate1(this.method_136))
			},
			{
				this.class16_0.class33_204.method_0(),
				new Class4.Class6(this.class16_0.class33_204, new Class4.Delegate1(this.method_248))
			},
			{
				this.class16_0.class33_10.method_0(),
				new Class4.Class6(this.class16_0.class33_10, new Class4.Delegate1(this.method_99))
			},
			{
				this.class16_0.class33_101.method_0(),
				new Class4.Class6(this.class16_0.class33_101, new Class4.Delegate1(this.method_43))
			},
			{
				this.class16_0.class33_25.method_0(),
				new Class4.Class6(this.class16_0.class33_25, new Class4.Delegate1(this.method_301))
			},
			{
				this.class16_0.class33_198.method_0(),
				new Class4.Class6(this.class16_0.class33_198, new Class4.Delegate1(this.method_31))
			},
			{
				this.class16_0.class33_177.method_0(),
				new Class4.Class6(this.class16_0.class33_177, new Class4.Delegate1(this.method_41))
			},
			{
				this.class16_0.class33_165.method_0(),
				new Class4.Class6(this.class16_0.class33_165, new Class4.Delegate1(this.method_287))
			},
			{
				this.class16_0.class33_203.method_0(),
				new Class4.Class6(this.class16_0.class33_203, new Class4.Delegate1(this.method_207))
			},
			{
				this.class16_0.class33_1.method_0(),
				new Class4.Class6(this.class16_0.class33_1, new Class4.Delegate1(this.method_103))
			},
			{
				this.class16_0.class33_33.method_0(),
				new Class4.Class6(this.class16_0.class33_33, new Class4.Delegate1(this.method_47))
			},
			{
				this.class16_0.class33_19.method_0(),
				new Class4.Class6(this.class16_0.class33_19, new Class4.Delegate1(this.method_158))
			},
			{
				this.class16_0.class33_162.method_0(),
				new Class4.Class6(this.class16_0.class33_162, new Class4.Delegate1(this.method_249))
			},
			{
				this.class16_0.class33_79.method_0(),
				new Class4.Class6(this.class16_0.class33_79, new Class4.Delegate1(this.method_35))
			},
			{
				this.class16_0.class33_96.method_0(),
				new Class4.Class6(this.class16_0.class33_96, new Class4.Delegate1(this.method_220))
			},
			{
				this.class16_0.class33_159.method_0(),
				new Class4.Class6(this.class16_0.class33_159, new Class4.Delegate1(this.method_179))
			},
			{
				this.class16_0.class33_87.method_0(),
				new Class4.Class6(this.class16_0.class33_87, new Class4.Delegate1(this.method_46))
			},
			{
				this.class16_0.class33_124.method_0(),
				new Class4.Class6(this.class16_0.class33_124, new Class4.Delegate1(this.method_45))
			},
			{
				this.class16_0.class33_188.method_0(),
				new Class4.Class6(this.class16_0.class33_188, new Class4.Delegate1(this.method_117))
			},
			{
				this.class16_0.class33_174.method_0(),
				new Class4.Class6(this.class16_0.class33_174, new Class4.Delegate1(this.method_14))
			},
			{
				this.class16_0.class33_34.method_0(),
				new Class4.Class6(this.class16_0.class33_34, new Class4.Delegate1(this.method_23))
			},
			{
				this.class16_0.class33_56.method_0(),
				new Class4.Class6(this.class16_0.class33_56, new Class4.Delegate1(this.method_134))
			},
			{
				this.class16_0.class33_74.method_0(),
				new Class4.Class6(this.class16_0.class33_74, new Class4.Delegate1(this.method_293))
			},
			{
				this.class16_0.class33_175.method_0(),
				new Class4.Class6(this.class16_0.class33_175, new Class4.Delegate1(this.method_146))
			},
			{
				this.class16_0.class33_191.method_0(),
				new Class4.Class6(this.class16_0.class33_191, new Class4.Delegate1(this.method_105))
			},
			{
				this.class16_0.class33_158.method_0(),
				new Class4.Class6(this.class16_0.class33_158, new Class4.Delegate1(this.method_178))
			},
			{
				this.class16_0.class33_131.method_0(),
				new Class4.Class6(this.class16_0.class33_131, new Class4.Delegate1(this.method_299))
			},
			{
				this.class16_0.class33_179.method_0(),
				new Class4.Class6(this.class16_0.class33_179, new Class4.Delegate1(this.method_266))
			},
			{
				this.class16_0.class33_23.method_0(),
				new Class4.Class6(this.class16_0.class33_23, new Class4.Delegate1(this.method_184))
			},
			{
				this.class16_0.class33_173.method_0(),
				new Class4.Class6(this.class16_0.class33_173, new Class4.Delegate1(this.method_253))
			},
			{
				this.class16_0.class33_72.method_0(),
				new Class4.Class6(this.class16_0.class33_72, new Class4.Delegate1(this.method_284))
			},
			{
				this.class16_0.class33_147.method_0(),
				new Class4.Class6(this.class16_0.class33_147, new Class4.Delegate1(this.method_154))
			},
			{
				this.class16_0.class33_65.method_0(),
				new Class4.Class6(this.class16_0.class33_65, new Class4.Delegate1(this.method_30))
			},
			{
				this.class16_0.class33_126.method_0(),
				new Class4.Class6(this.class16_0.class33_126, new Class4.Delegate1(this.method_143))
			},
			{
				this.class16_0.class33_39.method_0(),
				new Class4.Class6(this.class16_0.class33_39, new Class4.Delegate1(this.method_148))
			},
			{
				this.class16_0.class33_176.method_0(),
				new Class4.Class6(this.class16_0.class33_176, new Class4.Delegate1(this.method_53))
			},
			{
				this.class16_0.class33_167.method_0(),
				new Class4.Class6(this.class16_0.class33_167, new Class4.Delegate1(this.method_133))
			},
			{
				this.class16_0.class33_161.method_0(),
				new Class4.Class6(this.class16_0.class33_161, new Class4.Delegate1(this.method_273))
			},
			{
				this.class16_0.class33_211.method_0(),
				new Class4.Class6(this.class16_0.class33_211, new Class4.Delegate1(this.method_288))
			},
			{
				this.class16_0.class33_112.method_0(),
				new Class4.Class6(this.class16_0.class33_112, new Class4.Delegate1(this.method_272))
			},
			{
				this.class16_0.class33_129.method_0(),
				new Class4.Class6(this.class16_0.class33_129, new Class4.Delegate1(this.method_263))
			},
			{
				this.class16_0.class33_75.method_0(),
				new Class4.Class6(this.class16_0.class33_75, new Class4.Delegate1(this.method_171))
			},
			{
				this.class16_0.class33_136.method_0(),
				new Class4.Class6(this.class16_0.class33_136, new Class4.Delegate1(this.method_67))
			},
			{
				this.class16_0.class33_135.method_0(),
				new Class4.Class6(this.class16_0.class33_135, new Class4.Delegate1(this.method_34))
			},
			{
				this.class16_0.class33_17.method_0(),
				new Class4.Class6(this.class16_0.class33_17, new Class4.Delegate1(this.method_274))
			},
			{
				this.class16_0.class33_0.method_0(),
				new Class4.Class6(this.class16_0.class33_0, new Class4.Delegate1(this.method_268))
			},
			{
				this.class16_0.class33_94.method_0(),
				new Class4.Class6(this.class16_0.class33_94, new Class4.Delegate1(this.method_172))
			},
			{
				this.class16_0.class33_49.method_0(),
				new Class4.Class6(this.class16_0.class33_49, new Class4.Delegate1(this.method_63))
			},
			{
				this.class16_0.class33_24.method_0(),
				new Class4.Class6(this.class16_0.class33_24, new Class4.Delegate1(this.method_98))
			},
			{
				this.class16_0.class33_150.method_0(),
				new Class4.Class6(this.class16_0.class33_150, new Class4.Delegate1(this.method_168))
			},
			{
				this.class16_0.class33_80.method_0(),
				new Class4.Class6(this.class16_0.class33_80, new Class4.Delegate1(this.method_64))
			},
			{
				this.class16_0.class33_184.method_0(),
				new Class4.Class6(this.class16_0.class33_184, new Class4.Delegate1(this.method_280))
			},
			{
				this.class16_0.class33_41.method_0(),
				new Class4.Class6(this.class16_0.class33_41, new Class4.Delegate1(this.method_3))
			},
			{
				this.class16_0.class33_26.method_0(),
				new Class4.Class6(this.class16_0.class33_26, new Class4.Delegate1(this.method_197))
			},
			{
				this.class16_0.class33_149.method_0(),
				new Class4.Class6(this.class16_0.class33_149, new Class4.Delegate1(this.method_164))
			},
			{
				this.class16_0.class33_114.method_0(),
				new Class4.Class6(this.class16_0.class33_114, new Class4.Delegate1(this.method_75))
			},
			{
				this.class16_0.class33_190.method_0(),
				new Class4.Class6(this.class16_0.class33_190, new Class4.Delegate1(this.method_62))
			},
			{
				this.class16_0.class33_9.method_0(),
				new Class4.Class6(this.class16_0.class33_9, new Class4.Delegate1(this.method_121))
			},
			{
				this.class16_0.class33_22.method_0(),
				new Class4.Class6(this.class16_0.class33_22, new Class4.Delegate1(this.method_223))
			},
			{
				this.class16_0.class33_48.method_0(),
				new Class4.Class6(this.class16_0.class33_48, new Class4.Delegate1(this.method_2))
			},
			{
				this.class16_0.class33_178.method_0(),
				new Class4.Class6(this.class16_0.class33_178, new Class4.Delegate1(this.method_51))
			},
			{
				this.class16_0.class33_20.method_0(),
				new Class4.Class6(this.class16_0.class33_20, new Class4.Delegate1(this.method_206))
			},
			{
				this.class16_0.class33_160.method_0(),
				new Class4.Class6(this.class16_0.class33_160, new Class4.Delegate1(this.method_119))
			},
			{
				this.class16_0.class33_60.method_0(),
				new Class4.Class6(this.class16_0.class33_60, new Class4.Delegate1(this.method_70))
			},
			{
				this.class16_0.class33_122.method_0(),
				new Class4.Class6(this.class16_0.class33_122, new Class4.Delegate1(this.method_174))
			},
			{
				this.class16_0.class33_95.method_0(),
				new Class4.Class6(this.class16_0.class33_95, new Class4.Delegate1(this.method_54))
			}
		};
	}

	// Token: 0x060000E4 RID: 228 RVA: 0x00003168 File Offset: 0x00001368
	private void method_167(Class94 class94_2)
	{
		this.method_109(typeof(long));
	}

	// Token: 0x060000E5 RID: 229 RVA: 0x0000317A File Offset: 0x0000137A
	private void method_168(Class94 class94_2)
	{
		this.method_195(this.class94_1[1].vmethod_4());
	}

	// Token: 0x060000E6 RID: 230 RVA: 0x00015204 File Offset: 0x00013404
	private void method_169(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		Class94 class94_4 = this.method_300();
		this.method_195(this.method_21(class94_4, class94_3, true));
	}

	// Token: 0x060000E7 RID: 231 RVA: 0x00015230 File Offset: 0x00013430
	private void method_170(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		Class94 @class = this.method_300();
		bool flag;
		if (@class.vmethod_2() == 17)
		{
			flag = !Class4.smethod_18(@class, class94_3);
		}
		else
		{
			flag = !Class4.smethod_29(@class, class94_3);
		}
		if (flag)
		{
			uint uint_ = ((Class104)class94_2).method_2();
			this.method_244(uint_);
		}
	}

	// Token: 0x060000E8 RID: 232 RVA: 0x00003193 File Offset: 0x00001393
	private void method_171(Class94 class94_2)
	{
		throw new NotSupportedException("Refanytype is not supported.");
	}

	// Token: 0x060000E9 RID: 233 RVA: 0x0000319F File Offset: 0x0000139F
	private void method_172(Class94 class94_2)
	{
		this.method_109(typeof(ushort));
	}

	// Token: 0x060000EA RID: 234 RVA: 0x00015284 File Offset: 0x00013484
	private void method_173(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		Class94 class94_4 = this.method_300();
		this.method_195(this.method_242(class94_4, class94_3));
	}

	// Token: 0x060000EB RID: 235 RVA: 0x000031B1 File Offset: 0x000013B1
	private void method_174(Class94 class94_2)
	{
		Class118 @class = new Class118();
		@class.method_3(0);
		this.method_195(@class);
	}

	// Token: 0x060000EC RID: 236 RVA: 0x000152B0 File Offset: 0x000134B0
	private void method_175(bool bool_2)
	{
		Class94 @class = this.method_300();
		int num = @class.vmethod_2();
		ulong long_;
		if (num <= 11)
		{
			if (num != 7)
			{
				if (num == 11)
				{
					if (bool_2)
					{
						long_ = checked((ulong)((Class99)@class).method_2());
						goto IL_BB;
					}
					long_ = (ulong)((Class99)@class).method_2();
					goto IL_BB;
				}
			}
			else
			{
				if (bool_2)
				{
					long_ = (ulong)(checked((uint)((Class118)@class).method_2()));
					goto IL_BB;
				}
				long_ = (ulong)((Class118)@class).method_2();
				goto IL_BB;
			}
		}
		else if (num != 17)
		{
			if (num == 24)
			{
				if (bool_2)
				{
					long_ = Convert.ToUInt64(((Class98)@class).method_2());
					goto IL_BB;
				}
				long_ = Convert.ToUInt64(((Class98)@class).method_2());
				goto IL_BB;
			}
		}
		else
		{
			if (bool_2)
			{
				long_ = checked((ulong)((Class117)@class).method_2());
				goto IL_BB;
			}
			long_ = (ulong)((Class117)@class).method_2();
			goto IL_BB;
		}
		throw new InvalidOperationException();
		IL_BB:
		Class99 class2 = new Class99();
		class2.method_3((long)long_);
		this.method_195(class2);
	}

	// Token: 0x060000ED RID: 237 RVA: 0x0001538C File Offset: 0x0001358C
	private void method_176(Class94 class94_2)
	{
		int int_ = ((Class118)class94_2).method_2();
		FieldInfo fieldInfo_ = this.method_71(int_);
		Class94 @class = this.method_300();
		Class106 class2 = @class as Class106;
		object obj;
		if (class2 != null)
		{
			obj = this.method_255(class2).vmethod_0();
		}
		else
		{
			obj = @class.vmethod_0();
		}
		this.method_195(new Class107(fieldInfo_, obj, class2));
	}

	// Token: 0x060000EE RID: 238 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_177(Class94 class94_2)
	{
	}

	// Token: 0x060000EF RID: 239 RVA: 0x00002DF2 File Offset: 0x00000FF2
	private void method_178(Class94 class94_2)
	{
		this.method_275();
	}

	// Token: 0x060000F0 RID: 240 RVA: 0x000031C5 File Offset: 0x000013C5
	private static Exception smethod_16(string string_0, string string_1)
	{
		return new TypeLoadException(Class4.smethod_26(string.Format("security transparent method '{0}'", string_0), string.Format("security critical type '{0}'", string_1)));
	}

	// Token: 0x060000F1 RID: 241 RVA: 0x000153E4 File Offset: 0x000135E4
	private void method_179(Class94 class94_2)
	{
		Class119 @class = (Class119)class94_2;
		this.method_195(this.class94_1[(int)@class.method_2()].vmethod_4());
	}

	// Token: 0x060000F2 RID: 242 RVA: 0x000031E7 File Offset: 0x000013E7
	private void method_180(Class94 class94_2)
	{
		this.method_265(typeof(sbyte));
	}

	// Token: 0x060000F3 RID: 243 RVA: 0x000031F9 File Offset: 0x000013F9
	private void method_181(Class94 class94_2)
	{
		this.method_258(false);
	}

	// Token: 0x060000F4 RID: 244 RVA: 0x00003202 File Offset: 0x00001402
	private void method_182(Class94 class94_2)
	{
		Class118 @class = new Class118();
		@class.method_3(4);
		this.method_195(@class);
	}

	// Token: 0x060000F5 RID: 245 RVA: 0x00003216 File Offset: 0x00001416
	private void method_183(Class94 class94_2)
	{
		this.method_300();
	}

	// Token: 0x060000F6 RID: 246 RVA: 0x00015414 File Offset: 0x00013614
	private void method_184(Class94 class94_2)
	{
		if (((Class118)this.method_300()).method_2() != 0)
		{
			this.class20_1.method_7(new Class4.Struct1((uint)this.class31_0.method_0().vmethod_4(), this.object_2));
			this.bool_0 = false;
		}
		this.method_227();
	}

	// Token: 0x060000F7 RID: 247 RVA: 0x0000321F File Offset: 0x0000141F
	private object method_185(Stream stream_1, int int_0, object[] object_3, Type[] type_9, Type[] type_10, object[] object_4)
	{
		this.stream_0 = stream_1;
		this.method_22(stream_1, (long)int_0, null);
		return this.method_36(object_3, type_9, type_10, object_4);
	}

	// Token: 0x060000F8 RID: 248 RVA: 0x0000323F File Offset: 0x0000143F
	private void method_186(Class94 class94_2)
	{
		this.method_195(this.class94_1[0].vmethod_4());
	}

	// Token: 0x060000F9 RID: 249 RVA: 0x00015468 File Offset: 0x00013668
	private Class34 method_187(Class31 class31_2)
	{
		switch (class31_2.method_6())
		{
		case 0:
		{
			Class38 @class = new Class38();
			Class3 class2 = new Class3();
			class2.method_1(0);
			class2.method_3(class31_2.method_19());
			@class.method_1(class2);
			@class.method_3(class31_2.method_9());
			@class.method_5(class31_2.method_5());
			return @class;
		}
		case 1:
		{
			Class39 class3 = new Class39();
			class3.method_11(class31_2.method_19());
			class3.method_9(class31_2.method_19());
			class3.method_3(class31_2.method_5());
			class3.method_1(class31_2.method_9());
			class3.method_5(class31_2.method_5());
			int num = (int)class31_2.method_23();
			Class3[] array = new Class3[num];
			for (int i = 0; i < num; i++)
			{
				Class3[] array2 = array;
				int num2 = i;
				Class3 class4 = new Class3();
				class4.method_1(0);
				class4.method_3(class31_2.method_19());
				array2[num2] = class4;
			}
			class3.method_7(array);
			return class3;
		}
		case 2:
		{
			Class35 class5 = new Class35();
			class5.method_1(class31_2.method_9());
			return class5;
		}
		case 3:
		{
			Class37 class6 = new Class37();
			class6.method_1(class31_2.method_19());
			class6.method_3(class31_2.method_19());
			return class6;
		}
		case 4:
		{
			Class36 class7 = new Class36();
			Class36 class8 = class7;
			Class3 class9 = new Class3();
			class9.method_1(0);
			class9.method_3(class31_2.method_19());
			class8.method_5(class9);
			class7.method_1(class31_2.method_6());
			class7.method_7(class31_2.method_9());
			Class36 class10 = class7;
			Class3 class11 = new Class3();
			class11.method_1(0);
			class11.method_3(class31_2.method_19());
			class10.method_13(class11);
			int num3 = (int)class31_2.method_23();
			Class3[] array3 = new Class3[num3];
			for (int j = 0; j < num3; j++)
			{
				Class3[] array4 = array3;
				int num4 = j;
				Class3 class12 = new Class3();
				class12.method_1(0);
				class12.method_3(class31_2.method_19());
				array4[num4] = class12;
			}
			class7.method_9(array3);
			int num5 = (int)class31_2.method_23();
			Class3[] array5 = new Class3[num5];
			for (int k = 0; k < num5; k++)
			{
				Class3[] array6 = array5;
				int num6 = k;
				Class3 class13 = new Class3();
				class13.method_1(0);
				class13.method_3(class31_2.method_19());
				array6[num6] = class13;
			}
			class7.method_11(array5);
			return class7;
		}
		default:
			throw new ArgumentOutOfRangeException();
		}
	}

	// Token: 0x060000FA RID: 250 RVA: 0x00015674 File Offset: 0x00013874
	private static bool smethod_17(Class94 class94_2, Class94 class94_3)
	{
		bool result = false;
		int num = class94_2.vmethod_2();
		if (num <= 11)
		{
			if (num != 7)
			{
				if (num == 11)
				{
					if (class94_3.vmethod_2() == 24)
					{
						Class99 @class = new Class99();
						@class.method_3(Convert.ToInt64(((Class98)class94_3).method_2()));
						return Class4.smethod_17(class94_2, @class);
					}
					if (class94_3.vmethod_2() == 7)
					{
						Class99 class2 = new Class99();
						class2.method_3((long)((Class118)class94_3).method_2());
						return Class4.smethod_17(class94_2, class2);
					}
					result = (((Class99)class94_2).method_2() < ((Class99)class94_3).method_2());
				}
			}
			else
			{
				if (class94_3.vmethod_2() == 24)
				{
					Class118 class3 = new Class118();
					class3.method_3(Convert.ToInt32(((Class98)class94_3).method_2()));
					return Class4.smethod_17(class94_2, class3);
				}
				result = (((Class118)class94_2).method_2() < ((Class118)class94_3).method_2());
			}
		}
		else if (num != 17)
		{
			if (num == 24)
			{
				Class99 class4 = new Class99();
				class4.method_3(Convert.ToInt64(((Class98)class94_2).method_2()));
				return Class4.smethod_17(class4, class94_3);
			}
		}
		else
		{
			double num2 = ((Class117)class94_2).method_2();
			double num3 = ((Class117)class94_3).method_2();
			result = (num2 < num3 || double.IsNaN(num2) || double.IsNaN(num3));
		}
		return result;
	}

	// Token: 0x060000FB RID: 251 RVA: 0x000157B8 File Offset: 0x000139B8
	private static bool smethod_18(Class94 class94_2, Class94 class94_3)
	{
		bool result = false;
		int num = class94_2.vmethod_2();
		if (num <= 11)
		{
			if (num != 7)
			{
				if (num == 11)
				{
					if (class94_3.vmethod_2() == 24)
					{
						Class99 @class = new Class99();
						@class.method_3(Convert.ToInt64(((Class98)class94_3).method_2()));
						return Class4.smethod_18(class94_2, @class);
					}
					if (class94_3.vmethod_2() == 7)
					{
						Class99 class2 = new Class99();
						class2.method_3((long)((Class118)class94_3).method_2());
						return Class4.smethod_18(class94_2, class2);
					}
					result = (((Class99)class94_2).method_2() > ((Class99)class94_3).method_2());
				}
			}
			else
			{
				if (class94_3.vmethod_2() == 24)
				{
					Class118 class3 = new Class118();
					class3.method_3(Convert.ToInt32(((Class98)class94_3).method_2()));
					return Class4.smethod_18(class94_2, class3);
				}
				result = (((Class118)class94_2).method_2() > ((Class118)class94_3).method_2());
			}
		}
		else if (num != 17)
		{
			if (num == 24)
			{
				Class99 class4 = new Class99();
				class4.method_3(Convert.ToInt64(((Class98)class94_2).method_2()));
				return Class4.smethod_18(class4, class94_3);
			}
		}
		else
		{
			double num2 = ((Class117)class94_2).method_2();
			double num3 = ((Class117)class94_3).method_2();
			result = (!double.IsNaN(num2) && !double.IsNaN(num3) && num2 > num3);
		}
		return result;
	}

	// Token: 0x060000FC RID: 252 RVA: 0x00003258 File Offset: 0x00001458
	public static object smethod_19(Type type_9)
	{
		if (type_9.IsValueType)
		{
			return Activator.CreateInstance(type_9);
		}
		return null;
	}

	// Token: 0x060000FD RID: 253 RVA: 0x000158FC File Offset: 0x00013AFC
	private void method_188(Class94 class94_2)
	{
		int int_ = ((Class118)class94_2).method_2();
		FieldInfo fieldInfo = this.method_71(int_);
		Class94 @class = this.method_300();
		Class94 class2 = this.method_300();
		Class106 class3 = class2 as Class106;
		object obj;
		if (class3 != null)
		{
			obj = this.method_255(class3).vmethod_0();
		}
		else
		{
			obj = class2.vmethod_0();
		}
		if (obj == null)
		{
			throw new NullReferenceException();
		}
		Class94 class4 = Class32.smethod_1(@class.vmethod_0(), fieldInfo.FieldType);
		fieldInfo.SetValue(obj, class4.vmethod_0());
		if (class3 != null && obj != null && obj.GetType().IsValueType)
		{
			this.method_142(class3, Class32.smethod_1(obj, null));
		}
	}

	// Token: 0x060000FE RID: 254 RVA: 0x00015998 File Offset: 0x00013B98
	private Type method_189(int int_0, bool bool_2)
	{
		Dictionary<int, object> obj = Class4.dictionary_3;
		Type type;
		lock (obj)
		{
			bool flag = true;
			object obj2;
			if (Class4.dictionary_3.TryGetValue(int_0, out obj2))
			{
				type = (Type)obj2;
			}
			else
			{
				Class3 class3_ = this.method_130(int_0);
				type = this.method_292(int_0, class3_, ref flag, bool_2);
				if (flag)
				{
					Class4.dictionary_3.Add(int_0, type);
				}
			}
		}
		if (bool_2)
		{
			this.method_135(type);
		}
		return type;
	}

	// Token: 0x060000FF RID: 255 RVA: 0x0000326A File Offset: 0x0000146A
	private void method_190(Class94 class94_2)
	{
		this.method_265(typeof(double));
	}

	// Token: 0x06000100 RID: 256 RVA: 0x0000327C File Offset: 0x0000147C
	private void method_191(Class94 class94_2)
	{
		this.method_265(typeof(uint));
	}

	// Token: 0x06000101 RID: 257 RVA: 0x00015A14 File Offset: 0x00013C14
	private string method_192(Class86 class86_1)
	{
		Type type = this.method_189(class86_1.method_6(), false);
		Class70[] array = class86_1.method_2();
		string[] array2 = new string[array.Length];
		for (int i = 0; i < array.Length; i++)
		{
			string[] array3 = array2;
			int num = i;
			Type type2 = this.method_189(array[i].method_0(), false);
			array3[num] = ((type2 != null) ? type2.FullName : null);
		}
		string arg = string.Join(", ", array2);
		return string.Format("{0}.{1}({2})", type.FullName, class86_1.method_4(), arg);
	}

	// Token: 0x06000102 RID: 258 RVA: 0x0000328E File Offset: 0x0000148E
	private void method_193(Class94 class94_2)
	{
		this.method_109(typeof(double));
	}

	// Token: 0x06000103 RID: 259 RVA: 0x000032A0 File Offset: 0x000014A0
	private void method_194(Class94 class94_2)
	{
		throw new NotSupportedException("Cpobj is not supported.");
	}

	// Token: 0x06000104 RID: 260 RVA: 0x00015A94 File Offset: 0x00013C94
	private void method_195(Class94 class94_2)
	{
		if (class94_2 == null)
		{
			throw new ArgumentNullException("obj");
		}
		Class94 gparam_;
		if (class94_2.method_0() != null)
		{
			gparam_ = class94_2;
		}
		else
		{
			int num = class94_2.vmethod_2();
			switch (num)
			{
			case 0:
			{
				Class118 @class = new Class118();
				@class.method_3((int)((Class119)class94_2).method_2());
				@class.method_1(class94_2.method_0());
				gparam_ = @class;
				goto IL_234;
			}
			case 1:
			case 3:
			case 5:
			case 7:
			case 8:
				break;
			case 2:
			{
				Class118 class2 = new Class118();
				class2.method_3(((Class103)class94_2).method_2() ? 1 : 0);
				class2.method_1(class94_2.method_0());
				gparam_ = class2;
				goto IL_234;
			}
			case 4:
			{
				object obj = class94_2.vmethod_0();
				if (obj == null)
				{
					gparam_ = class94_2;
					goto IL_234;
				}
				Type type = obj.GetType();
				if (type.HasElementType && !type.IsArray)
				{
					type = type.GetElementType();
				}
				if (type != null && !type.IsValueType && !type.IsEnum)
				{
					gparam_ = class94_2;
					goto IL_234;
				}
				gparam_ = Class32.smethod_1(obj, type);
				goto IL_234;
			}
			case 6:
			{
				Class118 class3 = new Class118();
				class3.method_3((int)((Class95)class94_2).method_2());
				class3.method_1(class94_2.method_0());
				gparam_ = class3;
				goto IL_234;
			}
			case 9:
			{
				Class118 class4 = new Class118();
				class4.method_3((int)((Class115)class94_2).method_2());
				class4.method_1(class94_2.method_0());
				gparam_ = class4;
				goto IL_234;
			}
			case 10:
			{
				Class117 class5 = new Class117();
				class5.method_3((double)((Class114)class94_2).method_2());
				class5.method_1(class94_2.method_0());
				gparam_ = class5;
				goto IL_234;
			}
			default:
				if (num == 15)
				{
					Class118 class6 = new Class118();
					class6.method_3((int)((Class101)class94_2).method_2());
					class6.method_1(class94_2.method_0());
					gparam_ = class6;
					goto IL_234;
				}
				switch (num)
				{
				case 19:
				{
					Class99 class7 = new Class99();
					class7.method_3((long)((Class120)class94_2).method_2());
					class7.method_1(class94_2.method_0());
					gparam_ = class7;
					goto IL_234;
				}
				case 21:
				{
					Class118 class8 = new Class118();
					class8.method_3((int)((Class104)class94_2).method_2());
					class8.method_1(class94_2.method_0());
					gparam_ = class8;
					goto IL_234;
				}
				case 22:
				{
					Class118 class9 = new Class118();
					class9.method_3((int)((Class121)class94_2).method_2());
					class9.method_1(class94_2.method_0());
					gparam_ = class9;
					goto IL_234;
				}
				}
				break;
			}
			gparam_ = class94_2;
		}
		IL_234:
		this.class20_0.method_7(gparam_);
	}

	// Token: 0x06000105 RID: 261 RVA: 0x000032AC File Offset: 0x000014AC
	private void method_196(Class94 class94_2)
	{
		this.method_265(typeof(long));
	}

	// Token: 0x06000106 RID: 262 RVA: 0x00015CE4 File Offset: 0x00013EE4
	private void method_197(Class94 class94_2)
	{
		int int_ = ((Class118)class94_2).method_2();
		FieldInfo fieldInfo = this.method_71(int_);
		Class94 @class = Class32.smethod_1(this.method_300().vmethod_0(), fieldInfo.FieldType);
		fieldInfo.SetValue(null, @class.vmethod_0());
	}

	// Token: 0x06000107 RID: 263 RVA: 0x000032BE File Offset: 0x000014BE
	private void method_198(Class94 class94_2)
	{
		this.method_5(false);
	}

	// Token: 0x06000108 RID: 264 RVA: 0x000032C7 File Offset: 0x000014C7
	private void method_199(Class94 class94_2)
	{
		this.method_221(false);
	}

	// Token: 0x06000109 RID: 265 RVA: 0x00015D2C File Offset: 0x00013F2C
	private static bool smethod_20(Class94 class94_2, Class94 class94_3)
	{
		bool result = false;
		switch (class94_2.vmethod_2())
		{
		case 3:
		case 16:
		{
			Class109 @class = (Class109)class94_2;
			Class109 class109_ = (Class109)class94_3;
			return @class.vmethod_7(class109_);
		}
		case 4:
			return class94_2.vmethod_0() == class94_3.vmethod_0();
		case 7:
			if (class94_3.vmethod_2() == 24)
			{
				return (long)((Class118)class94_2).method_2() == Convert.ToInt64(((Class98)class94_3).method_2());
			}
			if (class94_3.vmethod_2() == 4 && class94_3.vmethod_0() == null)
			{
				return ((Class118)class94_2).method_2() == 0;
			}
			return ((Class118)class94_2).method_2() == ((Class118)class94_3).method_2();
		case 8:
			if (class94_3.vmethod_2() == 4 && class94_3.vmethod_0() == null)
			{
				return ((Class100)class94_2).method_2() == UIntPtr.Zero;
			}
			if (class94_3.vmethod_2() == 7)
			{
				return ((Class100)class94_2).method_2() == new UIntPtr((uint)((Class118)class94_3).method_2());
			}
			if (class94_3.vmethod_2() == 11)
			{
				return ((Class100)class94_2).method_2() == new UIntPtr((ulong)((Class99)class94_3).method_2());
			}
			return ((Class100)class94_2).method_2() == ((Class100)class94_3).method_2();
		case 11:
			if (class94_3.vmethod_2() == 24)
			{
				return ((Class99)class94_2).method_2() == Convert.ToInt64(((Class98)class94_3).method_2());
			}
			if (class94_3.vmethod_2() == 4 && class94_3.vmethod_0() == null)
			{
				return ((Class99)class94_2).method_2() == 0L;
			}
			return ((Class99)class94_2).method_2() == ((Class99)class94_3).method_2();
		case 12:
		{
			Class112 class2 = (Class112)class94_2;
			Class112 class3 = (Class112)class94_3;
			return Class4.smethod_20(class2.method_2(), class3.method_2());
		}
		case 13:
		{
			Class108 class4 = (Class108)class94_2;
			Class108 class5 = (Class108)class94_3;
			return class4.method_2() == class5.method_2();
		}
		case 14:
			if (class94_3.vmethod_2() == 4 && class94_3.vmethod_0() == null)
			{
				return ((Class105)class94_2).method_2() == IntPtr.Zero;
			}
			if (class94_3.vmethod_2() == 7)
			{
				return ((Class105)class94_2).method_2() == new IntPtr(((Class118)class94_3).method_2());
			}
			if (class94_3.vmethod_2() == 11)
			{
				return ((Class105)class94_2).method_2() == new IntPtr(((Class99)class94_3).method_2());
			}
			return ((Class105)class94_2).method_2() == ((Class105)class94_3).method_2();
		case 17:
		{
			double d = ((Class117)class94_2).method_2();
			double num = ((Class117)class94_3).method_2();
			return !double.IsNaN(d) && !double.IsNaN(num) && d.Equals(num);
		}
		case 18:
		{
			Class107 class6 = (Class107)class94_2;
			Class107 class7 = (Class107)class94_3;
			return class6.method_2() == class7.method_2() && class6.method_4() == class7.method_4();
		}
		case 20:
			return (class94_3.vmethod_2() != 4 || class94_3.vmethod_0() != null) && ((Class96)class94_2).method_2() == ((Class96)class94_3).method_2();
		case 24:
		{
			Class98 class8 = (Class98)class94_2;
			if (class94_3.vmethod_2() == 24)
			{
				return Convert.ToInt64(class8.method_2()) == Convert.ToInt64(((Class98)class94_3).method_2());
			}
			if (class8.method_2() == null)
			{
				return class94_3.vmethod_0() == null;
			}
			if (class94_3.vmethod_0() != null)
			{
				return Convert.ToInt64(class8.method_2()) == Convert.ToInt64(class94_3.vmethod_0());
			}
			return result;
		}
		}
		result = (class94_2.vmethod_0() == class94_3.vmethod_0());
		return result;
	}

	// Token: 0x0600010A RID: 266 RVA: 0x00016180 File Offset: 0x00014380
	private void method_200(ref Class4.Struct0 struct0_0, MethodBase methodBase_0, bool bool_2)
	{
		bool flag = false;
		if (methodBase_0.DeclaringType == typeof(Interlocked) && methodBase_0.IsStatic)
		{
			string name = methodBase_0.Name;
			if (name == "Add" || name == "CompareExchange" || name == "Decrement" || name == "Exchange" || name == "Increment" || name == "Read")
			{
				flag = true;
			}
		}
		if (flag)
		{
			try
			{
			}
			finally
			{
				Monitor.Enter(Class4.object_1);
				struct0_0.bool_0 = true;
			}
		}
	}

	// Token: 0x0600010B RID: 267 RVA: 0x00016228 File Offset: 0x00014428
	private void method_201(bool bool_2)
	{
		Class94 @class = this.method_300();
		int num = @class.vmethod_2();
		int int_;
		if (num <= 11)
		{
			if (num != 7)
			{
				if (num == 11)
				{
					if (bool_2)
					{
						int_ = checked((int)((Class99)@class).method_2());
						goto IL_BB;
					}
					int_ = (int)((Class99)@class).method_2();
					goto IL_BB;
				}
			}
			else
			{
				if (bool_2)
				{
					int_ = ((Class118)@class).method_2();
					goto IL_BB;
				}
				int_ = ((Class118)@class).method_2();
				goto IL_BB;
			}
		}
		else if (num != 17)
		{
			if (num == 24)
			{
				if (bool_2)
				{
					int_ = checked((int)Convert.ToUInt64(((Class98)@class).method_2()));
					goto IL_BB;
				}
				int_ = (int)Convert.ToUInt64(((Class98)@class).method_2());
				goto IL_BB;
			}
		}
		else
		{
			if (bool_2)
			{
				int_ = checked((int)((Class117)@class).method_2());
				goto IL_BB;
			}
			int_ = (int)((Class117)@class).method_2();
			goto IL_BB;
		}
		throw new InvalidOperationException();
		IL_BB:
		Class118 class2 = new Class118();
		class2.method_3(int_);
		this.method_195(class2);
	}

	// Token: 0x0600010C RID: 268 RVA: 0x00016304 File Offset: 0x00014504
	private void method_202(Class94 class94_2)
	{
		object object_ = this.method_300().vmethod_0();
		long num = this.method_55();
		Array array = (Array)this.method_300().vmethod_0();
		Type elementType = array.GetType().GetElementType();
		checked
		{
			if (elementType == typeof(short))
			{
				Class94 @class = Class32.smethod_1(object_, typeof(short));
				((short[])array)[(int)((IntPtr)num)] = (short)@class.vmethod_0();
				return;
			}
			if (elementType == typeof(ushort))
			{
				Class94 class2 = Class32.smethod_1(object_, typeof(ushort));
				((ushort[])array)[(int)((IntPtr)num)] = (ushort)class2.vmethod_0();
				return;
			}
			if (elementType == typeof(char))
			{
				Class94 class3 = Class32.smethod_1(object_, typeof(char));
				((char[])array)[(int)((IntPtr)num)] = (char)class3.vmethod_0();
				return;
			}
			if (elementType.IsEnum)
			{
				this.method_147(elementType, object_, num, array);
				return;
			}
			this.method_147(typeof(short), object_, num, array);
		}
	}

	// Token: 0x0600010D RID: 269 RVA: 0x00016408 File Offset: 0x00014608
	private void method_203(Class94 class94_2)
	{
		Class94 @class = this.method_300();
		int num = @class.vmethod_2();
		float num2;
		if (num <= 11)
		{
			if (num == 7)
			{
				num2 = (float)((Class118)@class).method_2();
				goto IL_6E;
			}
			if (num == 11)
			{
				num2 = (float)((Class99)@class).method_2();
				goto IL_6E;
			}
		}
		else
		{
			if (num == 17)
			{
				num2 = (float)((Class117)@class).method_2();
				goto IL_6E;
			}
			if (num == 24)
			{
				num2 = Convert.ToUInt64(((Class98)@class).method_2());
				goto IL_6E;
			}
		}
		throw new InvalidOperationException();
		IL_6E:
		Class117 class2 = new Class117();
		class2.method_3((double)num2);
		this.method_195(class2);
	}

	// Token: 0x0600010E RID: 270 RVA: 0x00016498 File Offset: 0x00014698
	private static string smethod_21(MethodBase methodBase_0)
	{
		Type declaringType = methodBase_0.DeclaringType;
		ParameterInfo[] parameters = methodBase_0.GetParameters();
		string[] array = new string[parameters.Length];
		for (int i = 0; i < parameters.Length; i++)
		{
			ParameterInfo parameterInfo = parameters[i];
			array[i] = string.Format("{0} {1}", parameterInfo.ParameterType, parameterInfo.Name);
		}
		string arg = string.Join(", ", array);
		return string.Format("{0}.{1}({2})", declaringType.FullName, methodBase_0.Name, arg);
	}

	// Token: 0x0600010F RID: 271 RVA: 0x000032D0 File Offset: 0x000014D0
	private void method_204(Class94 class94_2)
	{
		this.method_44(true);
	}

	// Token: 0x06000110 RID: 272 RVA: 0x00016518 File Offset: 0x00014718
	private void method_205(int int_0, Type[] type_9, Type[] type_10, bool bool_2)
	{
		this.class31_1.method_0().vmethod_9((long)int_0, 0);
		this.method_73(this.class31_1);
		Class86 @class = this.method_222(this.class31_1);
		this.method_49(@class);
		int num = @class.method_2().Length;
		object[] array = new object[num];
		Class94[] array2 = new Class94[num];
		if (this.type_4 != null && bool_2)
		{
			int num2 = @class.method_12() ? 0 : 1;
			Type[] array3 = new Type[num - num2];
			for (int i = num - 1; i >= num2; i--)
			{
				array3[i] = this.method_189(@class.method_2()[i].method_0(), true);
			}
			MethodInfo method = this.type_4.GetMethod(@class.method_4(), BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.InvokeMethod | BindingFlags.GetProperty | BindingFlags.SetProperty, null, array3, null);
			this.type_4 = null;
			if (method != null)
			{
				this.method_124(method, true);
				return;
			}
		}
		for (int j = num - 1; j >= 0; j--)
		{
			Class94 class2 = this.method_300();
			array2[j] = class2;
			Class106 class106_;
			if ((class106_ = (class2 as Class106)) != null)
			{
				class2 = this.method_255(class106_);
			}
			if (class2.method_0() != null)
			{
				class2 = Class32.smethod_1(null, class2.method_0()).vmethod_3(class2);
			}
			Class94 class3 = Class32.smethod_1(null, this.method_189(@class.method_2()[j].method_0(), true)).vmethod_3(class2);
			array[j] = class3.vmethod_0();
			if (j == 0 && bool_2 && !@class.method_12() && array[j] == null)
			{
				throw new NullReferenceException();
			}
		}
		Class4 class4 = new Class4(this.class16_0);
		object[] object_ = new object[]
		{
			this.module_0.Assembly
		};
		object obj;
		try
		{
			obj = class4.method_185(this.stream_0, int_0, array, type_9, type_10, object_);
		}
		finally
		{
			for (int k = 0; k < array2.Length; k++)
			{
				Class106 class106_2;
				if ((class106_2 = (array2[k] as Class106)) != null)
				{
					object obj2 = array[k];
					this.method_142(class106_2, Class32.smethod_1(obj2, null));
				}
			}
		}
		Type type = class4.method_189(class4.class86_0.method_8(), true);
		if (type != Class4.type_1)
		{
			this.method_195(Class32.smethod_1(obj, type));
		}
	}

	// Token: 0x06000111 RID: 273 RVA: 0x000032D9 File Offset: 0x000014D9
	private void method_206(Class94 class94_2)
	{
		this.method_109(typeof(int));
	}

	// Token: 0x06000112 RID: 274 RVA: 0x00002F89 File Offset: 0x00001189
	private void method_207(Class94 class94_2)
	{
		this.method_195(class94_2);
	}

	// Token: 0x06000113 RID: 275 RVA: 0x000032EB File Offset: 0x000014EB
	private void method_208(Class94 class94_2)
	{
		Class118 @class = new Class118();
		@class.method_3(3);
		this.method_195(@class);
	}

	// Token: 0x06000114 RID: 276 RVA: 0x0001675C File Offset: 0x0001495C
	private void method_209()
	{
		try
		{
			this.method_152();
		}
		catch (object object_)
		{
			this.method_298(object_, 0U);
		}
	}

	// Token: 0x06000115 RID: 277 RVA: 0x000032FF File Offset: 0x000014FF
	private static void smethod_22(ILGenerator ilgenerator_0, Type type_9)
	{
		if (!type_9.IsValueType && !Class69.smethod_0(type_9).IsGenericParameter)
		{
			Class4.smethod_9(ilgenerator_0, type_9);
			return;
		}
		ilgenerator_0.Emit(OpCodes.Unbox_Any, type_9);
	}

	// Token: 0x06000116 RID: 278 RVA: 0x0000332A File Offset: 0x0000152A
	private void method_210(Class94 class94_2)
	{
		this.method_109(Class60.type_0);
	}

	// Token: 0x06000117 RID: 279 RVA: 0x0001678C File Offset: 0x0001498C
	private void method_211(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		Class94 class94_4 = this.method_300();
		this.method_195(this.method_16(class94_4, class94_3, true, true));
	}

	// Token: 0x06000118 RID: 280 RVA: 0x00003337 File Offset: 0x00001537
	private void method_212(Class94 class94_2)
	{
		this.method_201(false);
	}

	// Token: 0x06000119 RID: 281 RVA: 0x000167B8 File Offset: 0x000149B8
	private bool method_213(Type type_9, Class3 class3_0)
	{
		Class39 @class = (Class39)class3_0.method_4();
		if (Class69.smethod_0(type_9).IsGenericParameter)
		{
			return @class == null || @class.method_2();
		}
		Type type = this.method_189(class3_0.method_2(), false);
		return Class21.smethod_0(type_9, type);
	}

	// Token: 0x0600011A RID: 282 RVA: 0x00016808 File Offset: 0x00014A08
	private Class94 method_214(Class94 class94_2, Class94 class94_3, bool bool_2, bool bool_3)
	{
		if (class94_2.vmethod_2() == 7)
		{
			if (class94_3.vmethod_2() == 7)
			{
				if (!bool_3)
				{
					int num = ((Class118)class94_2).method_2();
					int num2 = ((Class118)class94_3).method_2();
					int int_;
					if (bool_2)
					{
						int_ = checked(num + num2);
					}
					else
					{
						int_ = num + num2;
					}
					Class118 @class = new Class118();
					@class.method_3(int_);
					return @class;
				}
				uint num3 = (uint)((Class118)class94_2).method_2();
				uint num4 = (uint)((Class118)class94_3).method_2();
				uint int_2;
				if (bool_2)
				{
					int_2 = checked(num3 + num4);
				}
				else
				{
					int_2 = num3 + num4;
				}
				Class118 class2 = new Class118();
				class2.method_3((int)int_2);
				return class2;
			}
			else
			{
				if (class94_3.vmethod_2() == 11)
				{
					Class99 class3 = new Class99();
					class3.method_3((long)((Class118)class94_2).method_2());
					return Class4.smethod_4(class3, class94_3, bool_2, bool_3);
				}
				if (class94_3.vmethod_2() == 24)
				{
					Type underlyingType = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
					if (underlyingType != typeof(long))
					{
						if (underlyingType != typeof(ulong))
						{
							Class118 class4 = new Class118();
							class4.method_3(Convert.ToInt32(class94_3.vmethod_0()));
							return this.method_214(class94_2, class4, bool_2, bool_3);
						}
					}
					Class99 class5 = new Class99();
					class5.method_3((long)((Class118)class94_2).method_2());
					Class99 class6 = new Class99();
					class6.method_3(Convert.ToInt64(class94_3.vmethod_0()));
					return Class4.smethod_4(class5, class6, bool_2, bool_3);
				}
			}
		}
		if (class94_2.vmethod_2() == 11)
		{
			if (class94_3.vmethod_2() == 11)
			{
				return Class4.smethod_4(class94_2, class94_3, bool_2, bool_3);
			}
			if (class94_3.vmethod_2() == 7)
			{
				Class99 class7 = new Class99();
				class7.method_3((long)((Class118)class94_3).method_2());
				return Class4.smethod_4(class94_2, class7, bool_2, bool_3);
			}
			if (class94_3.vmethod_2() == 24)
			{
				Type underlyingType2 = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
				if (underlyingType2 != typeof(long))
				{
					if (underlyingType2 != typeof(ulong))
					{
						Class118 class8 = new Class118();
						class8.method_3(Convert.ToInt32(class94_3.vmethod_0()));
						return Class4.smethod_4(class94_2, class8, bool_2, bool_3);
					}
				}
				Class99 class9 = new Class99();
				class9.method_3(Convert.ToInt64(class94_3.vmethod_0()));
				return Class4.smethod_4(class94_2, class9, bool_2, bool_3);
			}
		}
		if (class94_2.vmethod_2() == 17 && class94_3.vmethod_2() == 17)
		{
			Class117 class10 = new Class117();
			class10.method_3(((Class117)class94_2).method_2() + ((Class117)class94_3).method_2());
			return class10;
		}
		if (class94_2.vmethod_2() == 24)
		{
			Type underlyingType3 = Enum.GetUnderlyingType(class94_2.vmethod_0().GetType());
			if (underlyingType3 != typeof(long))
			{
				if (underlyingType3 != typeof(ulong))
				{
					Class118 class11 = new Class118();
					class11.method_3(Convert.ToInt32(class94_2.vmethod_0()));
					return this.method_214(class11, class94_3, bool_2, bool_3);
				}
			}
			Class99 class12 = new Class99();
			class12.method_3(Convert.ToInt64(class94_2.vmethod_0()));
			return this.method_214(class12, class94_3, bool_2, bool_3);
		}
		throw new InvalidOperationException();
	}

	// Token: 0x0600011B RID: 283 RVA: 0x00016AD8 File Offset: 0x00014CD8
	private void method_215(object object_3)
	{
		Exception ex = object_3 as Exception;
		if (ex != null)
		{
			Class4.smethod_8(ex);
		}
		Class4.smethod_2(object_3);
	}

	// Token: 0x0600011C RID: 284 RVA: 0x00003340 File Offset: 0x00001540
	private void method_216(Class94 class94_2)
	{
		if (this.object_2 == null)
		{
			throw new InvalidOperationException();
		}
		this.method_215(this.object_2);
	}

	// Token: 0x0600011D RID: 285 RVA: 0x00016AFC File Offset: 0x00014CFC
	private void method_217(Class94 class94_2)
	{
		object object_ = this.method_300().vmethod_0();
		long num = this.method_55();
		Array array = (Array)this.method_300().vmethod_0();
		Type elementType = array.GetType().GetElementType();
		checked
		{
			if (elementType == typeof(long))
			{
				Class94 @class = Class32.smethod_1(object_, typeof(long));
				((long[])array)[(int)((IntPtr)num)] = (long)@class.vmethod_0();
				return;
			}
			if (elementType == typeof(ulong))
			{
				Class94 class2 = Class32.smethod_1(object_, typeof(ulong));
				((ulong[])array)[(int)((IntPtr)num)] = (ulong)class2.vmethod_0();
				return;
			}
			if (elementType.IsEnum)
			{
				this.method_147(elementType, object_, num, array);
				return;
			}
			this.method_147(typeof(long), object_, num, array);
		}
	}

	// Token: 0x0600011E RID: 286 RVA: 0x0000335C File Offset: 0x0000155C
	private void method_218(Class94 class94_2)
	{
		this.method_201(true);
	}

	// Token: 0x0600011F RID: 287 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_219(Class94 class94_2)
	{
	}

	// Token: 0x06000120 RID: 288 RVA: 0x00016BCC File Offset: 0x00014DCC
	private static Class27 smethod_23(Class31 class31_2)
	{
		Class27 @class = new Class27();
		@class.method_3((int)class31_2.method_6());
		@class.method_1(class31_2.method_19());
		@class.method_7(class31_2.method_20());
		@class.method_5(class31_2.method_20());
		@class.method_11(class31_2.method_20());
		@class.method_9(class31_2.method_20());
		return @class;
	}

	// Token: 0x06000121 RID: 289 RVA: 0x00003365 File Offset: 0x00001565
	private void method_220(Class94 class94_2)
	{
		this.method_195(new Class102());
	}

	// Token: 0x06000122 RID: 290 RVA: 0x00016C28 File Offset: 0x00014E28
	private void method_221(bool bool_2)
	{
		Class94 @class = this.method_300();
		int num = @class.vmethod_2();
		ushort int_;
		if (num <= 11)
		{
			if (num != 7)
			{
				if (num == 11)
				{
					if (bool_2)
					{
						int_ = checked((ushort)((ulong)((Class99)@class).method_2()));
						goto IL_BF;
					}
					int_ = (ushort)((Class99)@class).method_2();
					goto IL_BF;
				}
			}
			else
			{
				if (bool_2)
				{
					int_ = checked((ushort)((uint)((Class118)@class).method_2()));
					goto IL_BF;
				}
				int_ = (ushort)((Class118)@class).method_2();
				goto IL_BF;
			}
		}
		else if (num != 17)
		{
			if (num == 24)
			{
				if (bool_2)
				{
					int_ = checked((ushort)Convert.ToUInt64(((Class98)@class).method_2()));
					goto IL_BF;
				}
				int_ = (ushort)Convert.ToUInt64(((Class98)@class).method_2());
				goto IL_BF;
			}
		}
		else
		{
			if (bool_2)
			{
				int_ = checked((ushort)((Class117)@class).method_2());
				goto IL_BF;
			}
			int_ = (ushort)((Class117)@class).method_2();
			goto IL_BF;
		}
		throw new InvalidOperationException();
		IL_BF:
		Class118 class2 = new Class118();
		class2.method_3((int)int_);
		this.method_195(class2);
	}

	// Token: 0x06000123 RID: 291 RVA: 0x00016D08 File Offset: 0x00014F08
	private Class86 method_222(Class31 class31_2)
	{
		Class86 @class = new Class86();
		@class.method_9(class31_2.method_19());
		@class.method_1(this.method_129(class31_2));
		@class.method_7(class31_2.method_19());
		@class.method_3(this.method_279(class31_2));
		@class.method_5(class31_2.method_9());
		@class.method_11(class31_2.method_6());
		return @class;
	}

	// Token: 0x06000124 RID: 292 RVA: 0x00003372 File Offset: 0x00001572
	private void method_223(Class94 class94_2)
	{
		this.method_144(Class4.type_8);
	}

	// Token: 0x06000125 RID: 293 RVA: 0x0000337F File Offset: 0x0000157F
	private void method_224(Class94 class94_2)
	{
		this.method_5(true);
	}

	// Token: 0x06000126 RID: 294 RVA: 0x00016D64 File Offset: 0x00014F64
	private static bool smethod_24(MethodBase methodBase_0)
	{
		ParameterInfo[] parameters = methodBase_0.GetParameters();
		for (int i = 0; i < parameters.Length; i++)
		{
			if (parameters[i].ParameterType.IsByRef)
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x06000127 RID: 295 RVA: 0x00003388 File Offset: 0x00001588
	private void method_225(Class94 class94_2)
	{
		this.method_221(true);
	}

	// Token: 0x06000128 RID: 296 RVA: 0x00003391 File Offset: 0x00001591
	private void method_226(Class94 class94_2)
	{
		this.method_109(Class4.type_8);
	}

	// Token: 0x06000129 RID: 297 RVA: 0x00016D9C File Offset: 0x00014F9C
	private void method_227()
	{
		if (this.class20_1.Count == 0)
		{
			if (this.bool_0)
			{
				this.method_215(this.object_2);
			}
			return;
		}
		Class4.Struct1 @struct = this.class20_1.method_6();
		if (@struct.method_1() != null)
		{
			Class102 @class = new Class102();
			@class.vmethod_1(@struct.method_1());
			this.method_195(@class);
		}
		else
		{
			this.class20_0.method_0();
		}
		this.method_244(@struct.method_0());
	}

	// Token: 0x0600012A RID: 298 RVA: 0x0000339E File Offset: 0x0000159E
	private void method_228(Class94 class94_2)
	{
		this.method_109(typeof(short));
	}

	// Token: 0x0600012B RID: 299 RVA: 0x00016E14 File Offset: 0x00015014
	private Class94 method_229(Class94 class94_2, Class94 class94_3)
	{
		if (class94_2.vmethod_2() == 7)
		{
			if (class94_3.vmethod_2() == 7)
			{
				int num = ((Class118)class94_2).method_2();
				int num2 = ((Class118)class94_3).method_2();
				Class118 @class = new Class118();
				@class.method_3(num ^ num2);
				return @class;
			}
			if (class94_3.vmethod_2() == 24)
			{
				int num3 = ((Class118)class94_2).method_2();
				Type underlyingType = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
				if (underlyingType != typeof(long))
				{
					if (underlyingType != typeof(ulong))
					{
						int num4 = Convert.ToInt32(class94_3.vmethod_0());
						Class118 class2 = new Class118();
						class2.method_3(num3 ^ num4);
						return class2;
					}
				}
				long num5 = Convert.ToInt64(class94_3.vmethod_0());
				Class99 class3 = new Class99();
				class3.method_3((long)num3 ^ num5);
				return class3;
			}
		}
		if (class94_2.vmethod_2() == 11)
		{
			if (class94_3.vmethod_2() == 11)
			{
				long num6 = ((Class99)class94_2).method_2();
				long num7 = ((Class99)class94_3).method_2();
				Class99 class4 = new Class99();
				class4.method_3(num6 ^ num7);
				return class4;
			}
			if (class94_3.vmethod_2() == 24)
			{
				int num8 = ((Class118)class94_2).method_2();
				long num9 = Convert.ToInt64(class94_3.vmethod_0());
				Class99 class5 = new Class99();
				class5.method_3((long)num8 ^ num9);
				return class5;
			}
		}
		if (class94_2.vmethod_2() == 24)
		{
			if (class94_3.vmethod_2() == 7)
			{
				int num10 = ((Class118)class94_3).method_2();
				Type underlyingType2 = Enum.GetUnderlyingType(class94_2.vmethod_0().GetType());
				if (underlyingType2 != typeof(long))
				{
					if (underlyingType2 != typeof(ulong))
					{
						int num11 = Convert.ToInt32(class94_2.vmethod_0());
						Class118 class6 = new Class118();
						class6.method_3(num11 ^ num10);
						return class6;
					}
				}
				long num12 = Convert.ToInt64(class94_3.vmethod_0());
				Class99 class7 = new Class99();
				class7.method_3(num12 ^ (long)num10);
				return class7;
			}
			if (class94_3.vmethod_2() == 11)
			{
				long num13 = Convert.ToInt64(class94_2.vmethod_0());
				long num14 = ((Class99)class94_3).method_2();
				Class99 class8 = new Class99();
				class8.method_3(num13 ^ num14);
				return class8;
			}
			if (class94_3.vmethod_2() == 24)
			{
				Type underlyingType3 = Enum.GetUnderlyingType(class94_2.vmethod_0().GetType());
				Type underlyingType4 = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
				if (underlyingType3 != typeof(long) && underlyingType3 != typeof(ulong) && underlyingType4 != typeof(long))
				{
					if (underlyingType4 != typeof(ulong))
					{
						int num15 = Convert.ToInt32(class94_2.vmethod_0());
						int num16 = Convert.ToInt32(class94_3.vmethod_0());
						Class118 class9 = new Class118();
						class9.method_3(num15 ^ num16);
						return class9;
					}
				}
				long num17 = Convert.ToInt64(class94_2.vmethod_0());
				long num18 = Convert.ToInt64(class94_3.vmethod_0());
				Class99 class10 = new Class99();
				class10.method_3(num17 ^ num18);
				return class10;
			}
		}
		throw new InvalidOperationException();
	}

	// Token: 0x0600012C RID: 300 RVA: 0x000170DC File Offset: 0x000152DC
	private Class94 method_230(Class31 class31_2, int int_0)
	{
		switch (int_0)
		{
		case 0:
		case 8:
		{
			Class119 @class = new Class119();
			@class.method_3(class31_2.method_24());
			return @class;
		}
		case 1:
		{
			int num = class31_2.method_19();
			Class118[] array = new Class118[num];
			for (int i = 0; i < num; i++)
			{
				Class118[] array2 = array;
				int num2 = i;
				Class118 class2 = new Class118();
				class2.method_3(class31_2.method_19());
				array2[num2] = class2;
			}
			Class116 class3 = new Class116();
			class3.method_3(array);
			return class3;
		}
		case 2:
		case 11:
		{
			Class118 class4 = new Class118();
			class4.method_3(class31_2.method_19());
			return class4;
		}
		case 3:
		case 4:
		{
			Class121 class5 = new Class121();
			class5.method_3(class31_2.method_6());
			return class5;
		}
		case 5:
		{
			Class114 class6 = new Class114();
			class6.method_3(class31_2.method_26());
			return class6;
		}
		case 6:
		{
			Class117 class7 = new Class117();
			class7.method_3(class31_2.method_27());
			return class7;
		}
		case 7:
		{
			Class99 class8 = new Class99();
			class8.method_3(class31_2.method_21());
			return class8;
		}
		case 9:
		{
			Class104 class9 = new Class104();
			class9.method_3(class31_2.method_20());
			return class9;
		}
		case 10:
			return null;
		case 12:
		{
			Class115 class10 = new Class115();
			class10.method_3(class31_2.method_7());
			return class10;
		}
		default:
			throw new Exception("Unknown operand type.");
		}
	}

	// Token: 0x0600012D RID: 301 RVA: 0x000171FC File Offset: 0x000153FC
	private void method_231(Class94 class94_2)
	{
		Class94 @class = this.method_300();
		this.method_215(@class.vmethod_0());
	}

	// Token: 0x0600012E RID: 302 RVA: 0x0001721C File Offset: 0x0001541C
	private Class4.Delegate0 method_232(Class4.Struct2 struct2_0)
	{
		Dictionary<Class4.Struct2, Class4.Delegate0> obj = this.dictionary_1;
		Class4.Delegate0 result;
		lock (obj)
		{
			this.dictionary_1.TryGetValue(struct2_0, out result);
		}
		return result;
	}

	// Token: 0x0600012F RID: 303 RVA: 0x00017260 File Offset: 0x00015460
	private void method_233()
	{
		if (!this.class16_0.method_1())
		{
			Class16 obj = this.class16_0;
			lock (obj)
			{
				if (!this.class16_0.method_1())
				{
					this.dictionary_0 = this.method_166();
					this.method_94();
					this.class16_0.method_2(true);
				}
			}
		}
		if (this.dictionary_0 == null)
		{
			this.dictionary_0 = this.method_166();
		}
	}

	// Token: 0x06000130 RID: 304 RVA: 0x000172E0 File Offset: 0x000154E0
	[DebuggerNonUserCode]
	private MethodBase method_234(int int_0)
	{
		Class3 class3_ = this.method_130(int_0);
		MethodBase methodBase = this.method_118(int_0, class3_);
		this.method_135(methodBase);
		return methodBase;
	}

	// Token: 0x06000131 RID: 305 RVA: 0x000033B0 File Offset: 0x000015B0
	private void method_235(ref Class4.Struct0 struct0_0)
	{
		if (struct0_0.bool_0)
		{
			Monitor.Exit(Class4.object_1);
		}
	}

	// Token: 0x06000132 RID: 306 RVA: 0x00017308 File Offset: 0x00015508
	private void method_236(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		Class94 class94_4 = this.method_300();
		this.method_195(this.method_214(class94_4, class94_3, true, true));
	}

	// Token: 0x06000133 RID: 307 RVA: 0x00017334 File Offset: 0x00015534
	private void method_237(Class94 class94_2)
	{
		Class121 @class = (Class121)class94_2;
		Class112 class2 = new Class112();
		class2.method_3(this.class94_0[(int)@class.method_2()]);
		this.method_195(class2);
	}

	// Token: 0x06000134 RID: 308 RVA: 0x0001736C File Offset: 0x0001556C
	private void method_238(Class94 class94_2)
	{
		int int_ = ((Class118)class94_2).method_2();
		Type type = this.method_189(int_, true);
		long long_ = this.method_55();
		Array array_ = (Array)this.method_300().vmethod_0();
		Class110 @class = new Class110();
		@class.method_5(array_);
		@class.method_3(type);
		@class.method_7(long_);
		this.method_195(@class);
	}

	// Token: 0x06000135 RID: 309 RVA: 0x00002F44 File Offset: 0x00001144
	[Conditional("DEBUG")]
	private void method_239(object object_3)
	{
	}

	// Token: 0x06000136 RID: 310 RVA: 0x000173C8 File Offset: 0x000155C8
	private void method_240(Class94 class94_2)
	{
		object object_ = this.method_300().vmethod_0();
		long num = this.method_55();
		Array array = (Array)this.method_300().vmethod_0();
		Type elementType = array.GetType().GetElementType();
		checked
		{
			if (elementType == typeof(int))
			{
				Class94 @class = Class32.smethod_1(object_, typeof(int));
				((int[])array)[(int)((IntPtr)num)] = (int)@class.vmethod_0();
				return;
			}
			if (elementType == typeof(uint))
			{
				Class94 class2 = Class32.smethod_1(object_, typeof(uint));
				((uint[])array)[(int)((IntPtr)num)] = (uint)class2.vmethod_0();
				return;
			}
			if (elementType.IsEnum)
			{
				this.method_147(elementType, object_, num, array);
				return;
			}
			this.method_147(typeof(int), object_, num, array);
		}
	}

	// Token: 0x06000137 RID: 311 RVA: 0x00017498 File Offset: 0x00015698
	private static void smethod_25(ILGenerator ilgenerator_0, int int_0)
	{
		switch (int_0)
		{
		case -1:
			ilgenerator_0.Emit(OpCodes.Ldc_I4_M1);
			return;
		case 0:
			ilgenerator_0.Emit(OpCodes.Ldc_I4_0);
			return;
		case 1:
			ilgenerator_0.Emit(OpCodes.Ldc_I4_1);
			return;
		case 2:
			ilgenerator_0.Emit(OpCodes.Ldc_I4_2);
			return;
		case 3:
			ilgenerator_0.Emit(OpCodes.Ldc_I4_3);
			return;
		case 4:
			ilgenerator_0.Emit(OpCodes.Ldc_I4_4);
			return;
		case 5:
			ilgenerator_0.Emit(OpCodes.Ldc_I4_5);
			return;
		case 6:
			ilgenerator_0.Emit(OpCodes.Ldc_I4_6);
			return;
		case 7:
			ilgenerator_0.Emit(OpCodes.Ldc_I4_7);
			return;
		case 8:
			ilgenerator_0.Emit(OpCodes.Ldc_I4_8);
			return;
		default:
			if (int_0 > -129 && int_0 < 128)
			{
				ilgenerator_0.Emit(OpCodes.Ldc_I4_S, (sbyte)int_0);
				return;
			}
			ilgenerator_0.Emit(OpCodes.Ldc_I4, int_0);
			return;
		}
	}

	// Token: 0x06000138 RID: 312 RVA: 0x00017578 File Offset: 0x00015778
	private void method_241(bool bool_2)
	{
		Class94 @class = this.method_300();
		int num = @class.vmethod_2();
		byte int_;
		if (num <= 11)
		{
			if (num != 7)
			{
				if (num == 11)
				{
					if (bool_2)
					{
						int_ = checked((byte)((ulong)((Class99)@class).method_2()));
						goto IL_BF;
					}
					int_ = (byte)((Class99)@class).method_2();
					goto IL_BF;
				}
			}
			else
			{
				if (bool_2)
				{
					int_ = checked((byte)((uint)((Class118)@class).method_2()));
					goto IL_BF;
				}
				int_ = (byte)((Class118)@class).method_2();
				goto IL_BF;
			}
		}
		else if (num != 17)
		{
			if (num == 24)
			{
				if (bool_2)
				{
					int_ = checked((byte)Convert.ToUInt64(((Class98)@class).method_2()));
					goto IL_BF;
				}
				int_ = (byte)Convert.ToUInt64(((Class98)@class).method_2());
				goto IL_BF;
			}
		}
		else
		{
			if (bool_2)
			{
				int_ = checked((byte)((Class117)@class).method_2());
				goto IL_BF;
			}
			int_ = (byte)((Class117)@class).method_2();
			goto IL_BF;
		}
		throw new InvalidOperationException();
		IL_BF:
		Class118 class2 = new Class118();
		class2.method_3((int)int_);
		this.method_195(class2);
	}

	// Token: 0x06000139 RID: 313 RVA: 0x00017658 File Offset: 0x00015858
	private Class94 method_242(Class94 class94_2, Class94 class94_3)
	{
		if (class94_2.vmethod_2() == 7)
		{
			if (class94_3.vmethod_2() == 7)
			{
				int num = ((Class118)class94_2).method_2();
				int num2 = ((Class118)class94_3).method_2();
				Class118 @class = new Class118();
				@class.method_3(num | num2);
				return @class;
			}
			if (class94_3.vmethod_2() == 24)
			{
				int num3 = ((Class118)class94_2).method_2();
				Type underlyingType = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
				if (underlyingType != typeof(long))
				{
					if (underlyingType != typeof(ulong))
					{
						int num4 = Convert.ToInt32(class94_3.vmethod_0());
						Class118 class2 = new Class118();
						class2.method_3(num3 | num4);
						return class2;
					}
				}
				long num5 = Convert.ToInt64(class94_3.vmethod_0());
				Class99 class3 = new Class99();
				class3.method_3((long)num3 | num5);
				return class3;
			}
		}
		if (class94_2.vmethod_2() == 11)
		{
			if (class94_3.vmethod_2() == 11)
			{
				long num6 = ((Class99)class94_2).method_2();
				long num7 = ((Class99)class94_3).method_2();
				Class99 class4 = new Class99();
				class4.method_3(num6 | num7);
				return class4;
			}
			if (class94_3.vmethod_2() == 24)
			{
				int num8 = ((Class118)class94_2).method_2();
				long num9 = Convert.ToInt64(class94_3.vmethod_0());
				Class99 class5 = new Class99();
				class5.method_3((long)num8 | num9);
				return class5;
			}
		}
		if (class94_2.vmethod_2() == 24)
		{
			if (class94_3.vmethod_2() == 7)
			{
				int num10 = ((Class118)class94_3).method_2();
				Type underlyingType2 = Enum.GetUnderlyingType(class94_2.vmethod_0().GetType());
				if (underlyingType2 != typeof(long))
				{
					if (underlyingType2 != typeof(ulong))
					{
						int num11 = Convert.ToInt32(class94_2.vmethod_0());
						Class118 class6 = new Class118();
						class6.method_3(num11 | num10);
						return class6;
					}
				}
				long num12 = Convert.ToInt64(class94_3.vmethod_0());
				Class99 class7 = new Class99();
				class7.method_3(num12 | (long)num10);
				return class7;
			}
			if (class94_3.vmethod_2() == 11)
			{
				long num13 = Convert.ToInt64(class94_2.vmethod_0());
				long num14 = ((Class99)class94_3).method_2();
				Class99 class8 = new Class99();
				class8.method_3(num13 | num14);
				return class8;
			}
			if (class94_3.vmethod_2() == 24)
			{
				Type underlyingType3 = Enum.GetUnderlyingType(class94_2.vmethod_0().GetType());
				Type underlyingType4 = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
				if (underlyingType3 != typeof(long) && underlyingType3 != typeof(ulong) && underlyingType4 != typeof(long))
				{
					if (underlyingType4 != typeof(ulong))
					{
						int num15 = Convert.ToInt32(class94_2.vmethod_0());
						int num16 = Convert.ToInt32(class94_3.vmethod_0());
						Class118 class9 = new Class118();
						class9.method_3(num15 | num16);
						return class9;
					}
				}
				long num17 = Convert.ToInt64(class94_2.vmethod_0());
				long num18 = Convert.ToInt64(class94_3.vmethod_0());
				Class99 class10 = new Class99();
				class10.method_3(num17 | num18);
				return class10;
			}
		}
		throw new InvalidOperationException();
	}

	// Token: 0x0600013A RID: 314 RVA: 0x00017920 File Offset: 0x00015B20
	private MethodBase method_243(Class36 class36_0)
	{
		Type type = this.method_189(class36_0.method_4().method_2(), false);
		BindingFlags bindingAttr = Class4.smethod_12(class36_0.method_2());
		MemberInfo[] member = type.GetMember(class36_0.method_6(), bindingAttr);
		MethodInfo methodInfo = null;
		foreach (MethodInfo methodInfo2 in member)
		{
			if (methodInfo2.IsGenericMethodDefinition)
			{
				ParameterInfo[] parameters = methodInfo2.GetParameters();
				if (parameters.Length == class36_0.method_8().Length && methodInfo2.GetGenericArguments().Length == class36_0.method_10().Length && this.method_213(methodInfo2.ReturnType, class36_0.method_12()))
				{
					bool flag = true;
					int j = 0;
					while (j < parameters.Length)
					{
						if (this.method_213(parameters[j].ParameterType, class36_0.method_8()[j]))
						{
							j++;
						}
						else
						{
							flag = false;
							IL_C6:
							if (!flag)
							{
								goto IL_CA;
							}
							methodInfo = methodInfo2;
							goto IL_DD;
						}
					}
					goto IL_C6;
					IL_DD:
					if (methodInfo == null)
					{
						throw new Exception(string.Format("Cannot bind method: {0}.{1}", type.Name, class36_0.method_6()));
					}
					Type[] array2 = new Type[class36_0.method_10().Length];
					for (int k = 0; k < array2.Length; k++)
					{
						array2[k] = this.method_189(class36_0.method_10()[k].method_2(), true);
					}
					return methodInfo.MakeGenericMethod(array2);
				}
			}
			IL_CA:;
		}
		goto IL_DD;
	}

	// Token: 0x0600013B RID: 315 RVA: 0x000033C4 File Offset: 0x000015C4
	private void method_244(uint uint_0)
	{
		this.nullable_0 = new uint?(uint_0);
	}

	// Token: 0x0600013C RID: 316 RVA: 0x00017A74 File Offset: 0x00015C74
	private static string smethod_26(string string_0, string string_1)
	{
		string fullName = typeof(Class4).Assembly.FullName;
		return string.Concat(new string[]
		{
			string.Format("Attempt by {0} to access {1} failed.", string_0, string_1),
			Environment.NewLine,
			Environment.NewLine,
			string.Format("Assembly '{0}' is marked with the AllowPartiallyTrustedCallersAttribute, and uses the level 2 security transparency model. ", fullName),
			"Level 2 transparency causes all methods in AllowPartiallyTrustedCallers assemblies to become security transparent by default, which may be the cause of this exception."
		});
	}

	// Token: 0x0600013D RID: 317 RVA: 0x00017AD8 File Offset: 0x00015CD8
	private void method_245(bool bool_2)
	{
		Class94 @class = this.method_300();
		int num = @class.vmethod_2();
		IntPtr intptr_;
		if (num <= 11)
		{
			if (num != 7)
			{
				if (num == 11)
				{
					if (bool_2)
					{
						intptr_ = new IntPtr(((Class99)@class).method_2());
						goto IL_EE;
					}
					intptr_ = new IntPtr(((Class99)@class).method_2());
					goto IL_EE;
				}
			}
			else
			{
				if (bool_2)
				{
					intptr_ = new IntPtr(((Class118)@class).method_2());
					goto IL_EE;
				}
				intptr_ = new IntPtr(((Class118)@class).method_2());
				goto IL_EE;
			}
		}
		else if (num != 17)
		{
			if (num == 24)
			{
				if (bool_2)
				{
					intptr_ = new IntPtr(checked((long)Convert.ToUInt64(((Class98)@class).method_2())));
					goto IL_EE;
				}
				intptr_ = new IntPtr((long)Convert.ToUInt64(((Class98)@class).method_2()));
				goto IL_EE;
			}
		}
		else
		{
			if (bool_2)
			{
				intptr_ = new IntPtr(checked((long)((Class117)@class).method_2()));
				goto IL_EE;
			}
			intptr_ = new IntPtr((long)((Class117)@class).method_2());
			goto IL_EE;
		}
		throw new InvalidOperationException();
		IL_EE:
		Class105 class2 = new Class105();
		class2.method_3(intptr_);
		this.method_195(class2);
	}

	// Token: 0x0600013E RID: 318 RVA: 0x000033D2 File Offset: 0x000015D2
	private void method_246(Class94 class94_2)
	{
		this.method_227();
	}

	// Token: 0x0600013F RID: 319 RVA: 0x000033DA File Offset: 0x000015DA
	private object method_247(MethodBase methodBase_0, object object_3, object[] object_4)
	{
		if (methodBase_0.IsConstructor)
		{
			return Activator.CreateInstance(methodBase_0.DeclaringType, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic, null, object_4, null);
		}
		return methodBase_0.Invoke(object_3, object_4);
	}

	// Token: 0x06000140 RID: 320 RVA: 0x000033FD File Offset: 0x000015FD
	private void method_248(Class94 class94_2)
	{
		this.method_195(this.class94_0[3].vmethod_4());
	}

	// Token: 0x06000141 RID: 321 RVA: 0x00003416 File Offset: 0x00001616
	private void method_249(Class94 class94_2)
	{
		throw new NotSupportedException("Localloc not supported.");
	}

	// Token: 0x06000142 RID: 322 RVA: 0x00017BE8 File Offset: 0x00015DE8
	private static Class94 smethod_27(Class94 class94_2, Class94 class94_3, bool bool_2, bool bool_3)
	{
		if (!bool_3)
		{
			long num = ((Class99)class94_2).method_2();
			long num2 = ((Class99)class94_3).method_2();
			long long_;
			if (bool_2)
			{
				long_ = checked(num * num2);
			}
			else
			{
				long_ = num * num2;
			}
			Class99 @class = new Class99();
			@class.method_3(long_);
			return @class;
		}
		ulong num3 = (ulong)((Class99)class94_2).method_2();
		ulong num4 = (ulong)((Class99)class94_3).method_2();
		ulong long_2;
		if (bool_2)
		{
			long_2 = checked(num3 * num4);
		}
		else
		{
			long_2 = num3 * num4;
		}
		Class99 class2 = new Class99();
		class2.method_3((long)long_2);
		return class2;
	}

	// Token: 0x06000143 RID: 323 RVA: 0x00017C64 File Offset: 0x00015E64
	private void method_250(Class94 class94_2)
	{
		Class118 @class = (Class118)class94_2;
		MethodBase methodBase = this.method_234(@class.method_2());
		Type declaringType = methodBase.DeclaringType;
		Type type = this.method_300().vmethod_0().GetType();
		ParameterInfo[] parameters = methodBase.GetParameters();
		Type[] array = new Type[parameters.Length];
		for (int i = 0; i < parameters.Length; i++)
		{
			array[i] = parameters[i].ParameterType;
		}
		MethodBase methodBase2 = null;
		for (Type type2 = type; type2 != null; type2 = type2.BaseType)
		{
			if (type2 == declaringType)
			{
				break;
			}
			MethodInfo method = type2.GetMethod(methodBase.Name, BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.GetProperty | BindingFlags.SetProperty | BindingFlags.ExactBinding, null, CallingConventions.Any, array, null);
			if (method != null && method.GetBaseDefinition() == methodBase)
			{
				methodBase2 = method;
				break;
			}
		}
		if (methodBase2 == null)
		{
			methodBase2 = methodBase;
		}
		Class97 class2 = new Class97();
		class2.method_3(methodBase2);
		this.method_195(class2);
	}

	// Token: 0x06000144 RID: 324 RVA: 0x00003422 File Offset: 0x00001622
	private bool method_251(long long_1, uint uint_0, uint uint_1)
	{
		return long_1 >= (long)((ulong)uint_0) && long_1 <= (long)((ulong)(uint_0 + uint_1));
	}

	// Token: 0x06000145 RID: 325 RVA: 0x00003435 File Offset: 0x00001635
	private void method_252(Class94 class94_2)
	{
		this.method_175(true);
	}

	// Token: 0x06000146 RID: 326 RVA: 0x00017D34 File Offset: 0x00015F34
	private void method_253(Class94 class94_2)
	{
		Class94 @class = this.method_300();
		int num = @class.vmethod_2();
		checked
		{
			long long_;
			if (num <= 11)
			{
				if (num == 7)
				{
					long_ = (long)(unchecked((ulong)(checked((uint)((Class118)@class).method_2()))));
					goto IL_6F;
				}
				if (num == 11)
				{
					long_ = (long)((ulong)((Class99)@class).method_2());
					goto IL_6F;
				}
			}
			else
			{
				if (num == 17)
				{
					long_ = (long)((Class117)@class).method_2();
					goto IL_6F;
				}
				if (num == 24)
				{
					long_ = (long)Convert.ToUInt64(((Class98)@class).method_2());
					goto IL_6F;
				}
			}
			throw new InvalidOperationException();
			IL_6F:
			Class99 class2 = new Class99();
			class2.method_3(long_);
			this.method_195(class2);
		}
	}

	// Token: 0x06000147 RID: 327 RVA: 0x00017DC4 File Offset: 0x00015FC4
	private void method_254(Class94 class94_2)
	{
		Class119 @class = (Class119)class94_2;
		this.method_195(this.class94_0[(int)@class.method_2()].vmethod_4());
	}

	// Token: 0x06000148 RID: 328 RVA: 0x00017DF4 File Offset: 0x00015FF4
	private Class94 method_255(Class106 class106_0)
	{
		int num = class106_0.vmethod_2();
		if (num != 3)
		{
			switch (num)
			{
			case 12:
				return ((Class112)class106_0).method_2();
			case 13:
				return this.class94_1[((Class108)class106_0).method_2()];
			case 16:
				goto IL_7A;
			case 18:
			{
				Class107 @class = (Class107)class106_0;
				return Class32.smethod_1(@class.method_4().GetValue(@class.method_2()), null);
			}
			}
			throw new ArgumentOutOfRangeException();
		}
		IL_7A:
		Class109 class2 = (Class109)class106_0;
		return Class32.smethod_1(class2.vmethod_5(), class2.method_2());
	}

	// Token: 0x06000149 RID: 329 RVA: 0x0000343E File Offset: 0x0000163E
	public object method_256(Stream stream_1, string string_0, object[] object_3)
	{
		return this.method_48(stream_1, string_0, object_3, null, null, null);
	}

	// Token: 0x0600014A RID: 330 RVA: 0x00017E94 File Offset: 0x00016094
	private void method_257(Class94 class94_2)
	{
		int int_ = ((Class118)class94_2).method_2();
		Type type_ = this.method_189(int_, true);
		Class94 class94_3 = this.method_300();
		if (this.method_281(class94_3, type_))
		{
			this.method_195(class94_3);
			return;
		}
		this.method_195(new Class102());
	}

	// Token: 0x0600014B RID: 331 RVA: 0x00017EDC File Offset: 0x000160DC
	private void method_258(bool bool_2)
	{
		Class94 @class = this.method_300();
		int num = @class.vmethod_2();
		checked
		{
			UIntPtr uintptr_;
			if (num <= 11)
			{
				if (num != 7)
				{
					if (num == 11)
					{
						if (bool_2)
						{
							uintptr_ = new UIntPtr((ulong)((Class99)@class).method_2());
							goto IL_EF;
						}
						uintptr_ = new UIntPtr((ulong)((Class99)@class).method_2());
						goto IL_EF;
					}
				}
				else
				{
					if (bool_2)
					{
						uintptr_ = new UIntPtr((uint)((Class118)@class).method_2());
						goto IL_EF;
					}
					uintptr_ = new UIntPtr((uint)((Class118)@class).method_2());
					goto IL_EF;
				}
			}
			else if (num != 17)
			{
				if (num == 24)
				{
					if (bool_2)
					{
						uintptr_ = new UIntPtr(Convert.ToUInt64(((Class98)@class).method_2()));
						goto IL_EF;
					}
					uintptr_ = new UIntPtr(Convert.ToUInt64(((Class98)@class).method_2()));
					goto IL_EF;
				}
			}
			else
			{
				if (bool_2)
				{
					uintptr_ = new UIntPtr((ulong)((Class117)@class).method_2());
					goto IL_EF;
				}
				uintptr_ = new UIntPtr(unchecked((ulong)((Class117)@class).method_2()));
				goto IL_EF;
			}
			throw new InvalidOperationException();
			IL_EF:
			Class100 class2 = new Class100();
			class2.method_3(uintptr_);
			this.method_195(class2);
		}
	}

	// Token: 0x0600014C RID: 332 RVA: 0x0000344C File Offset: 0x0000164C
	private int method_259()
	{
		return -2144188571;
	}

	// Token: 0x0600014D RID: 333 RVA: 0x00003453 File Offset: 0x00001653
	private void method_260(Class94 class94_2)
	{
		this.method_261(true);
	}

	// Token: 0x0600014E RID: 334 RVA: 0x00017FEC File Offset: 0x000161EC
	private void method_261(bool bool_2)
	{
		Class94 @class = this.method_300();
		int num = @class.vmethod_2();
		sbyte int_;
		if (num <= 11)
		{
			if (num != 7)
			{
				if (num == 11)
				{
					if (bool_2)
					{
						int_ = checked((sbyte)((Class99)@class).method_2());
						goto IL_BD;
					}
					int_ = (sbyte)((Class99)@class).method_2();
					goto IL_BD;
				}
			}
			else
			{
				if (bool_2)
				{
					int_ = checked((sbyte)((Class118)@class).method_2());
					goto IL_BD;
				}
				int_ = (sbyte)((Class118)@class).method_2();
				goto IL_BD;
			}
		}
		else if (num != 17)
		{
			if (num == 24)
			{
				if (bool_2)
				{
					int_ = checked((sbyte)Convert.ToUInt64(((Class98)@class).method_2()));
					goto IL_BD;
				}
				int_ = (sbyte)Convert.ToUInt64(((Class98)@class).method_2());
				goto IL_BD;
			}
		}
		else
		{
			if (bool_2)
			{
				int_ = checked((sbyte)((Class117)@class).method_2());
				goto IL_BD;
			}
			int_ = (sbyte)((Class117)@class).method_2();
			goto IL_BD;
		}
		throw new InvalidOperationException();
		IL_BD:
		Class118 class2 = new Class118();
		class2.method_3((int)int_);
		this.method_195(class2);
	}

	// Token: 0x0600014F RID: 335 RVA: 0x000180C8 File Offset: 0x000162C8
	private void method_262(Class94 class94_2)
	{
		Class94 @class = this.method_300();
		int num = @class.vmethod_2();
		ulong long_;
		if (num <= 11)
		{
			if (num == 7)
			{
				long_ = (ulong)(checked((uint)((Class118)@class).method_2()));
				goto IL_6D;
			}
			if (num == 11)
			{
				long_ = checked((ulong)((Class99)@class).method_2());
				goto IL_6D;
			}
		}
		else
		{
			if (num == 17)
			{
				long_ = checked((ulong)((Class117)@class).method_2());
				goto IL_6D;
			}
			if (num == 24)
			{
				long_ = Convert.ToUInt64(((Class98)@class).method_2());
				goto IL_6D;
			}
		}
		throw new InvalidOperationException();
		IL_6D:
		Class99 class2 = new Class99();
		class2.method_3((long)long_);
		this.method_195(class2);
	}

	// Token: 0x06000150 RID: 336 RVA: 0x0000345C File Offset: 0x0000165C
	private void method_263(Class94 class94_2)
	{
		this.method_150(false);
	}

	// Token: 0x06000151 RID: 337 RVA: 0x00003465 File Offset: 0x00001665
	private void method_264(Class94 class94_2)
	{
		this.method_144(Class60.type_0);
	}

	// Token: 0x06000152 RID: 338 RVA: 0x00018154 File Offset: 0x00016354
	private void method_265(Type type_9)
	{
		long index = this.method_55();
		Array array = (Array)this.method_300().vmethod_0();
		this.method_195(Class32.smethod_1(array.GetValue(index), type_9));
	}

	// Token: 0x06000153 RID: 339 RVA: 0x0001818C File Offset: 0x0001638C
	private void method_266(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		if (Class4.smethod_17(this.method_300(), class94_3))
		{
			uint uint_ = ((Class104)class94_2).method_2();
			this.method_244(uint_);
		}
	}

	// Token: 0x06000154 RID: 340 RVA: 0x000181C4 File Offset: 0x000163C4
	private Class4.Delegate0 method_267(MethodBase methodBase_0, bool bool_2)
	{
		DynamicMethod dynamicMethod = new DynamicMethod(string.Empty, Class60.type_0, new Type[]
		{
			Class60.type_0,
			Class4.type_0
		}, typeof(Class4).Module, true);
		ILGenerator ilgenerator = dynamicMethod.GetILGenerator();
		ParameterInfo[] parameters = methodBase_0.GetParameters();
		Type[] array = new Type[parameters.Length];
		bool flag = false;
		for (int i = 0; i < parameters.Length; i++)
		{
			Type type = parameters[i].ParameterType;
			if (type.IsByRef)
			{
				flag = true;
				type = type.GetElementType();
			}
			array[i] = type;
		}
		LocalBuilder[] array2 = new LocalBuilder[array.Length];
		if (array2.Length != 0)
		{
			dynamicMethod.InitLocals = true;
		}
		for (int j = 0; j < array.Length; j++)
		{
			array2[j] = ilgenerator.DeclareLocal(array[j]);
		}
		for (int k = 0; k < array.Length; k++)
		{
			ilgenerator.Emit(OpCodes.Ldarg_1);
			Class4.smethod_25(ilgenerator, k);
			ilgenerator.Emit(OpCodes.Ldelem_Ref);
			Class4.smethod_22(ilgenerator, array[k]);
			ilgenerator.Emit(OpCodes.Stloc, array2[k]);
		}
		if (flag)
		{
			ilgenerator.BeginExceptionBlock();
		}
		if (!methodBase_0.IsStatic && !methodBase_0.IsConstructor)
		{
			ilgenerator.Emit(OpCodes.Ldarg_0);
			Type declaringType = methodBase_0.DeclaringType;
			if (declaringType.IsValueType)
			{
				ilgenerator.Emit(OpCodes.Unbox, declaringType);
				bool_2 = false;
			}
			else
			{
				Class4.smethod_9(ilgenerator, declaringType);
			}
		}
		for (int l = 0; l < array.Length; l++)
		{
			if (parameters[l].ParameterType.IsByRef)
			{
				ilgenerator.Emit(OpCodes.Ldloca_S, array2[l]);
			}
			else
			{
				ilgenerator.Emit(OpCodes.Ldloc, array2[l]);
			}
		}
		if (methodBase_0.IsConstructor)
		{
			ilgenerator.Emit(OpCodes.Newobj, (ConstructorInfo)methodBase_0);
			Class4.smethod_6(ilgenerator, methodBase_0.DeclaringType);
		}
		else
		{
			MethodInfo methodInfo = (MethodInfo)methodBase_0;
			if (bool_2 && !methodBase_0.IsStatic)
			{
				ilgenerator.EmitCall(OpCodes.Callvirt, methodInfo, null);
			}
			else
			{
				ilgenerator.EmitCall(OpCodes.Call, methodInfo, null);
			}
			if (methodInfo.ReturnType == Class4.type_1)
			{
				ilgenerator.Emit(OpCodes.Ldnull);
			}
			else
			{
				Class4.smethod_6(ilgenerator, methodInfo.ReturnType);
			}
		}
		if (flag)
		{
			LocalBuilder local = ilgenerator.DeclareLocal(Class60.type_0);
			ilgenerator.Emit(OpCodes.Stloc, local);
			ilgenerator.BeginFinallyBlock();
			for (int m = 0; m < array.Length; m++)
			{
				if (parameters[m].ParameterType.IsByRef)
				{
					ilgenerator.Emit(OpCodes.Ldarg_1);
					Class4.smethod_25(ilgenerator, m);
					ilgenerator.Emit(OpCodes.Ldloc, array2[m]);
					if (array2[m].LocalType.IsValueType || Class69.smethod_0(array2[m].LocalType).IsGenericParameter)
					{
						ilgenerator.Emit(OpCodes.Box, array2[m].LocalType);
					}
					ilgenerator.Emit(OpCodes.Stelem_Ref);
				}
			}
			ilgenerator.EndExceptionBlock();
			ilgenerator.Emit(OpCodes.Ldloc, local);
		}
		ilgenerator.Emit(OpCodes.Ret);
		return (Class4.Delegate0)dynamicMethod.CreateDelegate(typeof(Class4.Delegate0));
	}

	// Token: 0x06000155 RID: 341 RVA: 0x00018510 File Offset: 0x00016710
	private void method_268(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		if (!Class4.smethod_20(this.method_300(), class94_3))
		{
			uint uint_ = ((Class104)class94_2).method_2();
			this.method_244(uint_);
		}
	}

	// Token: 0x06000156 RID: 342 RVA: 0x00018548 File Offset: 0x00016748
	private void method_269(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		if (Class4.smethod_29(this.method_300(), class94_3))
		{
			uint uint_ = ((Class104)class94_2).method_2();
			this.method_244(uint_);
		}
	}

	// Token: 0x06000157 RID: 343 RVA: 0x00018580 File Offset: 0x00016780
	private Class94[] method_270(object[] object_3)
	{
		Class70[] array = this.class86_0.method_2();
		int num = array.Length;
		Class94[] array2 = new Class94[num];
		for (int i = 0; i < num; i++)
		{
			object obj = object_3[i];
			Type type = this.method_189(array[i].method_0(), false);
			Type type2 = Class69.smethod_1(type);
			Type type3;
			if (type2 != Class60.type_0 && !Class60.smethod_0(type2))
			{
				type3 = ((obj != null) ? obj.GetType() : type);
			}
			else
			{
				type3 = type;
			}
			if (obj != null && !type.IsAssignableFrom(type3) && type.IsByRef && !type.GetElementType().IsAssignableFrom(type3))
			{
				throw new ArgumentException(string.Format("Object of type {0} cannot be converted to type {1}.", type3, type));
			}
			array2[i] = Class32.smethod_1(obj, type3);
		}
		if (!this.class86_0.method_12() && this.method_189(this.class86_0.method_6(), false).IsValueType)
		{
			Class94[] array3 = array2;
			int num2 = 0;
			Class112 @class = new Class112();
			@class.method_3(array2[0]);
			array3[num2] = @class;
		}
		for (int j = 0; j < num; j++)
		{
			if (array[j].method_2())
			{
				Class94[] array4 = array2;
				int num3 = j;
				Class112 class2 = new Class112();
				class2.method_3(array2[j]);
				array4[num3] = class2;
			}
		}
		return array2;
	}

	// Token: 0x06000158 RID: 344 RVA: 0x000186C4 File Offset: 0x000168C4
	private void method_271(Class94 class94_2)
	{
		Class121 @class = (Class121)class94_2;
		Class108 class2 = new Class108();
		class2.method_3((int)@class.method_2());
		this.method_195(class2);
	}

	// Token: 0x06000159 RID: 345 RVA: 0x000186F0 File Offset: 0x000168F0
	private void method_272(Class94 class94_2)
	{
		Class94 @class = this.method_300();
		int num = @class.vmethod_2();
		double double_;
		if (num != 7)
		{
			if (num != 11)
			{
				if (num != 24)
				{
					throw new InvalidOperationException();
				}
				double_ = Convert.ToUInt64(((Class98)@class).method_2());
			}
			else
			{
				double_ = ((Class99)@class).method_2();
			}
		}
		else
		{
			double_ = ((Class118)@class).method_2();
		}
		Class117 class2 = new Class117();
		class2.method_3(double_);
		this.method_195(class2);
	}

	// Token: 0x0600015A RID: 346 RVA: 0x00003472 File Offset: 0x00001672
	private void method_273(Class94 class94_2)
	{
		Class118 @class = new Class118();
		@class.method_3(7);
		this.method_195(@class);
	}

	// Token: 0x0600015B RID: 347 RVA: 0x00018764 File Offset: 0x00016964
	private void method_274(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		Class94 class94_4 = this.method_300();
		Class118 @class = new Class118();
		@class.method_3(Class4.smethod_17(class94_4, class94_3) ? 1 : 0);
		this.method_195(@class);
	}

	// Token: 0x0600015C RID: 348 RVA: 0x000187A0 File Offset: 0x000169A0
	private void method_275()
	{
		Class94 class94_ = this.method_300();
		Class106 class106_ = (Class106)this.method_300();
		this.method_142(class106_, class94_);
	}

	// Token: 0x0600015D RID: 349 RVA: 0x00003486 File Offset: 0x00001686
	private void method_276(Class94 class94_2)
	{
		this.method_241(false);
	}

	// Token: 0x0600015E RID: 350 RVA: 0x000187C8 File Offset: 0x000169C8
	private void method_277(Class94 class94_2)
	{
		Class117 @class = (Class117)this.method_300();
		if (double.IsNaN(@class.method_2()) || double.IsInfinity(@class.method_2()))
		{
			throw new OverflowException("The value is not finite real number.");
		}
		this.method_195(@class);
	}

	// Token: 0x0600015F RID: 351 RVA: 0x0000348F File Offset: 0x0000168F
	private bool method_278(MethodBase methodBase_0)
	{
		return methodBase_0.IsVirtual && this.method_189(this.class86_0.method_6(), true).IsSubclassOf(methodBase_0.DeclaringType);
	}

	// Token: 0x06000160 RID: 352 RVA: 0x00018810 File Offset: 0x00016A10
	private Class70[] method_279(Class31 class31_2)
	{
		Class70[] array = new Class70[(int)class31_2.method_23()];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = this.method_82(class31_2);
		}
		return array;
	}

	// Token: 0x06000161 RID: 353 RVA: 0x000034BD File Offset: 0x000016BD
	private void method_280(Class94 class94_2)
	{
		this.method_265(Class4.type_8);
	}

	// Token: 0x06000162 RID: 354 RVA: 0x00018848 File Offset: 0x00016A48
	private bool method_281(Class94 class94_2, Type type_9)
	{
		if (class94_2.vmethod_0() == null)
		{
			return true;
		}
		Type type = class94_2.method_0() ?? class94_2.vmethod_0().GetType();
		if (type != type_9 && !type_9.IsAssignableFrom(type))
		{
			if (!type.IsValueType && !type_9.IsValueType && Marshal.IsComObject(class94_2.vmethod_0()))
			{
				IntPtr intPtr;
				try
				{
					intPtr = Marshal.GetComInterfaceForObject(class94_2.vmethod_0(), type_9);
				}
				catch (InvalidCastException)
				{
					intPtr = IntPtr.Zero;
				}
				if (intPtr != IntPtr.Zero)
				{
					try
					{
						Marshal.Release(intPtr);
					}
					catch
					{
					}
					return true;
				}
			}
			return false;
		}
		return true;
	}

	// Token: 0x06000163 RID: 355 RVA: 0x000188F4 File Offset: 0x00016AF4
	private void method_282(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		Class94 class94_4 = this.method_300();
		this.method_195(this.method_52(class94_4, class94_3, true));
	}

	// Token: 0x06000164 RID: 356 RVA: 0x00002F89 File Offset: 0x00001189
	private void method_283(Class94 class94_2)
	{
		this.method_195(class94_2);
	}

	// Token: 0x06000165 RID: 357 RVA: 0x00002F44 File Offset: 0x00001144
	[Conditional("DEBUG")]
	public static void smethod_28(string string_0)
	{
	}

	// Token: 0x06000166 RID: 358 RVA: 0x00002DF2 File Offset: 0x00000FF2
	private void method_284(Class94 class94_2)
	{
		this.method_275();
	}

	// Token: 0x06000167 RID: 359 RVA: 0x00018920 File Offset: 0x00016B20
	private void method_285(Class94 class94_2)
	{
		Class118 @class = (Class118)class94_2;
		MethodBase methodBase_ = this.method_234(@class.method_2());
		this.method_124(methodBase_, false);
	}

	// Token: 0x06000168 RID: 360 RVA: 0x0001894C File Offset: 0x00016B4C
	private void method_286(Class94 class94_2)
	{
		Class94 @class = this.method_300();
		int num = @class.vmethod_2();
		bool flag;
		if (num <= 11)
		{
			switch (num)
			{
			case 4:
				flag = (((Class102)@class).method_2() != null);
				goto IL_CA;
			case 5:
			case 6:
				break;
			case 7:
				flag = (((Class118)@class).method_2() != 0);
				goto IL_CA;
			case 8:
				flag = (((Class100)@class).method_2() != UIntPtr.Zero);
				goto IL_CA;
			default:
				if (num == 11)
				{
					flag = (((Class99)@class).method_2() != 0L);
					goto IL_CA;
				}
				break;
			}
		}
		else
		{
			if (num == 14)
			{
				flag = (((Class105)@class).method_2() != IntPtr.Zero);
				goto IL_CA;
			}
			if (num == 24)
			{
				flag = Convert.ToBoolean(((Class98)@class).method_2());
				goto IL_CA;
			}
		}
		flag = (@class.vmethod_0() != null);
		IL_CA:
		if (flag)
		{
			uint uint_ = ((Class104)class94_2).method_2();
			this.method_244(uint_);
		}
	}

	// Token: 0x06000169 RID: 361 RVA: 0x00018A3C File Offset: 0x00016C3C
	private void method_287(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		Class94 class94_4 = this.method_300();
		Class118 @class = new Class118();
		@class.method_3(Class4.smethod_14(class94_4, class94_3) ? 1 : 0);
		this.method_195(@class);
	}

	// Token: 0x0600016A RID: 362 RVA: 0x000034CA File Offset: 0x000016CA
	private void method_288(Class94 class94_2)
	{
		Class118 @class = new Class118();
		@class.method_3(8);
		this.method_195(@class);
	}

	// Token: 0x0600016B RID: 363 RVA: 0x00018A78 File Offset: 0x00016C78
	private Class33 method_289(int int_0)
	{
		foreach (Class33 @class in this.class16_0.method_0())
		{
			if (@class.method_0() == int_0)
			{
				return @class;
			}
		}
		return null;
	}

	// Token: 0x0600016C RID: 364 RVA: 0x00018AD8 File Offset: 0x00016CD8
	private static bool smethod_29(Class94 class94_2, Class94 class94_3)
	{
		int num = class94_2.vmethod_2();
		if (num <= 14)
		{
			switch (num)
			{
			case 4:
				return ((Class102)class94_2).method_2() != ((Class102)class94_3).method_2();
			case 5:
			case 6:
				break;
			case 7:
				return ((Class118)class94_2).method_2() > ((Class118)class94_3).method_2();
			case 8:
				if (class94_3.vmethod_2() == 4 && class94_3.vmethod_0() == null)
				{
					return ((Class100)class94_2).method_2() != UIntPtr.Zero;
				}
				return ((Class100)class94_2).method_2() != ((Class100)class94_3).method_2();
			default:
				if (num == 11)
				{
					return ((Class99)class94_2).method_2() > ((Class99)class94_3).method_2();
				}
				if (num == 14)
				{
					if (class94_3.vmethod_2() == 4 && class94_3.vmethod_0() == null)
					{
						return ((Class105)class94_2).method_2() != IntPtr.Zero;
					}
					return ((Class105)class94_2).method_2() != ((Class105)class94_3).method_2();
				}
				break;
			}
		}
		else
		{
			if (num == 17)
			{
				double num2 = ((Class117)class94_2).method_2();
				double num3 = ((Class117)class94_3).method_2();
				return num2 > num3 || double.IsNaN(num2) || double.IsNaN(num3);
			}
			if (num == 20)
			{
				return (class94_3.vmethod_2() == 4 && class94_3.vmethod_0() == null) || ((Class96)class94_2).method_2() != ((Class96)class94_3).method_2();
			}
			if (num == 24)
			{
				long num4 = Convert.ToInt64(((Class98)class94_2).method_2());
				long num5;
				if (class94_3.vmethod_2() == 7)
				{
					num5 = (long)((Class118)class94_3).method_2();
				}
				else
				{
					num5 = Convert.ToInt64(((Class98)class94_3).method_2());
				}
				return num4 > num5;
			}
		}
		return class94_2.vmethod_0() != class94_3.vmethod_0();
	}

	// Token: 0x0600016D RID: 365 RVA: 0x00018CE8 File Offset: 0x00016EE8
	private void method_290(Class94 class94_2)
	{
		Class94 class94_3 = this.method_300();
		Class94 class94_4 = this.method_300();
		this.method_195(this.method_214(class94_4, class94_3, true, false));
	}

	// Token: 0x0600016E RID: 366 RVA: 0x00018D14 File Offset: 0x00016F14
	private void method_291(int int_0)
	{
		Class94 @class = this.method_300();
		if (@class is Class106)
		{
			this.class94_1[int_0] = @class;
			return;
		}
		this.class94_1[int_0].vmethod_3(@class);
	}

	// Token: 0x0600016F RID: 367 RVA: 0x00018D54 File Offset: 0x00016F54
	private Type method_292(int int_0, Class3 class3_0, ref bool bool_2, bool bool_3)
	{
		if (class3_0.method_0() == 1)
		{
			return this.module_0.ResolveType(class3_0.method_2());
		}
		Class39 @class = (Class39)class3_0.method_4();
		Type type;
		if (@class.method_2())
		{
			if (@class.method_10() != -1)
			{
				type = this.type_7[@class.method_10()];
			}
			else
			{
				if (@class.method_8() == -1)
				{
					throw new Exception();
				}
				type = this.type_2[@class.method_8()];
			}
			Class20<Struct17> class2 = Class69.smethod_3(@class.method_0());
			type = Class69.smethod_4(type, class2);
			bool_2 = false;
			return type;
		}
		string text = @class.method_0();
		type = Type.GetType(text);
		if (type == null)
		{
			int num = text.IndexOf(',');
			string text2 = text.Substring(0, num);
			string text3 = text.Substring(num + 1).Trim();
			Assembly assembly_ = Class60.assembly_0;
			if (text3.Equals(assembly_.FullName, StringComparison.Ordinal))
			{
				type = assembly_.GetType(text2);
			}
			else
			{
				Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
				int i = 0;
				while (i < assemblies.Length)
				{
					Assembly assembly = assemblies[i];
					string value = null;
					try
					{
						value = assembly.Location;
						goto IL_13C;
					}
					catch (NotSupportedException)
					{
						goto IL_13C;
					}
					goto IL_119;
					IL_136:
					i++;
					continue;
					IL_119:
					if (!assembly.FullName.Equals(text3, StringComparison.Ordinal))
					{
						goto IL_136;
					}
					type = assembly.GetType(text2);
					if (type == null)
					{
						goto IL_136;
					}
					break;
					IL_13C:
					if (string.IsNullOrEmpty(value))
					{
						goto IL_119;
					}
					goto IL_136;
				}
			}
			if (type == null && text2.StartsWith("<PrivateImplementationDetails><", StringComparison.Ordinal) && text2.Contains("."))
			{
				try
				{
					foreach (Type type2 in Assembly.Load(text3).GetTypes())
					{
						if (type2.FullName == text2)
						{
							type = type2;
							break;
						}
					}
				}
				catch
				{
				}
			}
		}
		if (@class.method_4())
		{
			Type[] array = new Type[@class.method_6().Length];
			for (int j = 0; j < @class.method_6().Length; j++)
			{
				array[j] = this.method_189(@class.method_6()[j].method_2(), bool_3);
			}
			Type genericTypeDefinition = Class69.smethod_0(type).GetGenericTypeDefinition();
			Class20<Struct17> class3 = Class69.smethod_2(type);
			type = genericTypeDefinition.MakeGenericType(array);
			type = Class69.smethod_4(type, class3);
			bool_2 = false;
		}
		return type;
	}

	// Token: 0x06000170 RID: 368 RVA: 0x00018FA0 File Offset: 0x000171A0
	private void method_293(Class94 class94_2)
	{
		Class119 @class = (Class119)class94_2;
		Class108 class2 = new Class108();
		class2.method_3((int)@class.method_2());
		this.method_195(class2);
	}

	// Token: 0x06000171 RID: 369 RVA: 0x000034DE File Offset: 0x000016DE
	private void method_294(Class94 class94_2)
	{
		this.method_265(typeof(int));
	}

	// Token: 0x06000172 RID: 370 RVA: 0x00018FCC File Offset: 0x000171CC
	private void method_295(Class94 class94_2)
	{
		Class121 @class = (Class121)class94_2;
		this.class94_0[(int)@class.method_2()].vmethod_3(this.method_300());
	}

	// Token: 0x06000173 RID: 371 RVA: 0x00019000 File Offset: 0x00017200
	private void method_296()
	{
		long num = this.class31_0.method_0().vmethod_3();
		while (!this.bool_1)
		{
			if (this.nullable_0 != null)
			{
				this.class31_0.method_0().vmethod_5((long)((ulong)this.nullable_0.Value));
				this.nullable_0 = null;
			}
			this.method_209();
			if (this.class31_0.method_0().vmethod_4() >= num && this.nullable_0 == null)
			{
				break;
			}
		}
	}

	// Token: 0x06000174 RID: 372 RVA: 0x00019084 File Offset: 0x00017284
	private void method_297(Class94 class94_2)
	{
		int num = ((Class118)class94_2).method_2();
		bool flag = (num & int.MinValue) != 0;
		bool bool_ = (num & 1073741824) != 0;
		num &= 1073741823;
		if (flag)
		{
			this.method_205(num, null, null, bool_);
			return;
		}
		Class37 class37_ = (Class37)this.method_130(num).method_4();
		this.method_162(class37_);
	}

	// Token: 0x06000175 RID: 373 RVA: 0x000190E0 File Offset: 0x000172E0
	private void method_298(object object_3, uint uint_0)
	{
		bool flag = object_3 != null;
		this.object_2 = object_3;
		if (flag)
		{
			this.class20_1.method_0();
		}
		this.bool_0 = flag;
		if (!flag)
		{
			this.class20_1.method_7(new Class4.Struct1(uint_0));
		}
		foreach (Class27 @class in this.class27_0)
		{
			if (this.method_251(this.long_0, @class.method_6(), @class.method_10()))
			{
				switch (@class.method_2())
				{
				case 0:
					if (flag)
					{
						Type type = object_3.GetType();
						Type type2 = this.method_189(@class.method_0(), true);
						if (type == type2 || type.IsSubclassOf(type2))
						{
							this.class20_1.method_7(new Class4.Struct1(@class.method_8(), object_3));
							this.bool_0 = false;
						}
					}
					break;
				case 1:
					if (flag)
					{
						this.class20_1.method_7(new Class4.Struct1(@class.method_8()));
					}
					break;
				case 2:
					if (flag || !this.method_251((long)((ulong)uint_0), @class.method_6(), @class.method_10()))
					{
						this.class20_1.method_7(new Class4.Struct1(@class.method_8()));
					}
					break;
				case 4:
					if (flag)
					{
						this.class20_1.method_7(new Class4.Struct1(@class.method_4(), object_3));
					}
					break;
				}
			}
		}
		this.method_227();
	}

	// Token: 0x06000176 RID: 374 RVA: 0x00019248 File Offset: 0x00017448
	private void method_299(Class94 class94_2)
	{
		Class94 @class = this.method_300();
		int num = @class.vmethod_2();
		checked
		{
			short int_;
			if (num <= 11)
			{
				if (num == 7)
				{
					int_ = (short)((uint)((Class118)@class).method_2());
					goto IL_6F;
				}
				if (num == 11)
				{
					int_ = (short)((ulong)((Class99)@class).method_2());
					goto IL_6F;
				}
			}
			else
			{
				if (num == 17)
				{
					int_ = (short)((Class117)@class).method_2();
					goto IL_6F;
				}
				if (num == 24)
				{
					int_ = (short)Convert.ToUInt64(((Class98)@class).method_2());
					goto IL_6F;
				}
			}
			throw new InvalidOperationException();
			IL_6F:
			Class118 class2 = new Class118();
			class2.method_3((int)int_);
			this.method_195(class2);
		}
	}

	// Token: 0x06000177 RID: 375 RVA: 0x000034F0 File Offset: 0x000016F0
	private Class94 method_300()
	{
		return this.class20_0.method_6();
	}

	// Token: 0x06000178 RID: 376 RVA: 0x000192D8 File Offset: 0x000174D8
	private static Class94 smethod_30(Class94 class94_2, Class94 class94_3, bool bool_2)
	{
		if (!bool_2)
		{
			long num = ((Class99)class94_2).method_2();
			long num2 = ((Class99)class94_3).method_2();
			Class99 @class = new Class99();
			@class.method_3(num / num2);
			return @class;
		}
		ulong num3 = (ulong)((Class99)class94_2).method_2();
		ulong num4 = (ulong)((Class99)class94_3).method_2();
		Class99 class2 = new Class99();
		class2.method_3((long)(num3 / num4));
		return class2;
	}

	// Token: 0x06000179 RID: 377 RVA: 0x000034FD File Offset: 0x000016FD
	private void method_301(Class94 class94_2)
	{
		throw new NotSupportedException("Initblk not supported.");
	}

	// Token: 0x0400000E RID: 14
	private Class86 class86_0;

	// Token: 0x0400000F RID: 15
	private Dictionary<int, Class4.Class6> dictionary_0;

	// Token: 0x04000010 RID: 16
	private static Type type_0;

	// Token: 0x04000011 RID: 17
	private byte[] byte_0;

	// Token: 0x04000012 RID: 18
	private static Type type_1;

	// Token: 0x04000013 RID: 19
	private readonly Dictionary<Class4.Struct2, Class4.Delegate0> dictionary_1 = new Dictionary<Class4.Struct2, Class4.Delegate0>(256);

	// Token: 0x04000014 RID: 20
	private object[] object_0;

	// Token: 0x04000015 RID: 21
	private Type[] type_2;

	// Token: 0x04000016 RID: 22
	private Class27[] class27_0;

	// Token: 0x04000017 RID: 23
	private readonly Module module_0;

	// Token: 0x04000018 RID: 24
	private static Type type_3;

	// Token: 0x04000019 RID: 25
	private Class31 class31_0;

	// Token: 0x0400001A RID: 26
	private Type type_4;

	// Token: 0x0400001B RID: 27
	private Class94[] class94_0;

	// Token: 0x0400001C RID: 28
	private static Type type_5;

	// Token: 0x0400001D RID: 29
	private long long_0;

	// Token: 0x0400001E RID: 30
	private static object object_1;

	// Token: 0x0400001F RID: 31
	private Dictionary<MethodBase, object> dictionary_2;

	// Token: 0x04000020 RID: 32
	private readonly Class16 class16_0;

	// Token: 0x04000021 RID: 33
	private static Type type_6;

	// Token: 0x04000022 RID: 34
	private readonly Class20<Class94> class20_0;

	// Token: 0x04000023 RID: 35
	private Type[] type_7;

	// Token: 0x04000024 RID: 36
	private readonly Class20<Class4.Struct1> class20_1;

	// Token: 0x04000025 RID: 37
	private bool bool_0;

	// Token: 0x04000026 RID: 38
	private static readonly Dictionary<int, object> dictionary_3 = new Dictionary<int, object>();

	// Token: 0x04000027 RID: 39
	private object object_2;

	// Token: 0x04000028 RID: 40
	private readonly Dictionary<MethodBase, int> dictionary_4 = new Dictionary<MethodBase, int>(256);

	// Token: 0x04000029 RID: 41
	private Stream stream_0;

	// Token: 0x0400002A RID: 42
	private bool bool_1;

	// Token: 0x0400002B RID: 43
	private static Type type_8;

	// Token: 0x0400002C RID: 44
	private Class31 class31_1;

	// Token: 0x0400002D RID: 45
	private Class94[] class94_1;

	// Token: 0x0400002E RID: 46
	private static readonly Dictionary<MethodBase, DynamicMethod> dictionary_5 = new Dictionary<MethodBase, DynamicMethod>();

	// Token: 0x0400002F RID: 47
	private uint? nullable_0;

	// Token: 0x02000009 RID: 9
	// (Invoke) Token: 0x0600017B RID: 379
	private delegate object Delegate0(object object_0, object[] object_1);

	// Token: 0x0200000A RID: 10
	[Serializable]
	private sealed class Class5
	{
		// Token: 0x06000180 RID: 384 RVA: 0x00019338 File Offset: 0x00017538
		internal int method_0(Class27 class27_0, Class27 class27_1)
		{
			if (class27_0.method_6() == class27_1.method_6())
			{
				return class27_1.method_10().CompareTo(class27_0.method_10());
			}
			return class27_0.method_6().CompareTo(class27_1.method_6());
		}

		// Token: 0x04000030 RID: 48
		public static readonly Class4.Class5 class5_0 = new Class4.Class5();

		// Token: 0x04000031 RID: 49
		public static Comparison<Class27> comparison_0;
	}

	// Token: 0x0200000B RID: 11
	private struct Struct0
	{
		// Token: 0x04000032 RID: 50
		public bool bool_0;
	}

	// Token: 0x0200000C RID: 12
	private sealed class Class6
	{
		// Token: 0x06000181 RID: 385 RVA: 0x00003515 File Offset: 0x00001715
		public Class6(Class33 class33_1, Class4.Delegate1 delegate1_1)
		{
			this.class33_0 = class33_1;
			this.delegate1_0 = delegate1_1;
		}

		// Token: 0x04000033 RID: 51
		public Class33 class33_0;

		// Token: 0x04000034 RID: 52
		public Class4.Delegate1 delegate1_0;
	}

	// Token: 0x0200000D RID: 13
	private struct Struct1
	{
		// Token: 0x06000182 RID: 386 RVA: 0x0000352B File Offset: 0x0000172B
		public Struct1(uint uint_1)
		{
			this.uint_0 = uint_1;
			this.object_0 = null;
		}

		// Token: 0x06000183 RID: 387 RVA: 0x0000353B File Offset: 0x0000173B
		public Struct1(uint uint_1, object object_1)
		{
			this.uint_0 = uint_1;
			this.object_0 = object_1;
		}

		// Token: 0x06000184 RID: 388 RVA: 0x0000354B File Offset: 0x0000174B
		public uint method_0()
		{
			return this.uint_0;
		}

		// Token: 0x06000185 RID: 389 RVA: 0x00003553 File Offset: 0x00001753
		public object method_1()
		{
			return this.object_0;
		}

		// Token: 0x04000035 RID: 53
		private readonly uint uint_0;

		// Token: 0x04000036 RID: 54
		private readonly object object_0;
	}

	// Token: 0x0200000E RID: 14
	private struct Struct2 : IEquatable<Class4.Struct2>
	{
		// Token: 0x06000186 RID: 390 RVA: 0x0000355B File Offset: 0x0000175B
		public Struct2(MethodBase methodBase_1, bool bool_1)
		{
			this.methodBase_0 = methodBase_1;
			this.bool_0 = bool_1;
		}

		// Token: 0x06000187 RID: 391 RVA: 0x0000356B File Offset: 0x0000176B
		public MethodBase method_0()
		{
			return this.methodBase_0;
		}

		// Token: 0x06000188 RID: 392 RVA: 0x00003573 File Offset: 0x00001773
		public bool method_1()
		{
			return this.bool_0;
		}

		// Token: 0x06000189 RID: 393 RVA: 0x0001937C File Offset: 0x0001757C
		public override int GetHashCode()
		{
			return this.method_0().GetHashCode() ^ this.method_1().GetHashCode();
		}

		// Token: 0x0600018A RID: 394 RVA: 0x000193A4 File Offset: 0x000175A4
		public override bool Equals(object obj)
		{
			if (obj is Class4.Struct2)
			{
				Class4.Struct2 other = (Class4.Struct2)obj;
				return this.Equals(other);
			}
			return false;
		}

		// Token: 0x0600018B RID: 395 RVA: 0x0000357B File Offset: 0x0000177B
		public bool Equals(Class4.Struct2 other)
		{
			return this.method_0() == other.method_0() && this.method_1() == other.method_1();
		}

		// Token: 0x04000037 RID: 55
		private readonly MethodBase methodBase_0;

		// Token: 0x04000038 RID: 56
		private readonly bool bool_0;
	}

	// Token: 0x0200000F RID: 15
	private sealed class Class7
	{
		// Token: 0x0600018D RID: 397 RVA: 0x0000359D File Offset: 0x0000179D
		public string method_0()
		{
			return this.string_0;
		}

		// Token: 0x0600018E RID: 398 RVA: 0x000035A5 File Offset: 0x000017A5
		public void method_1(string string_1)
		{
			this.string_0 = string_1;
		}

		// Token: 0x0600018F RID: 399 RVA: 0x000035AE File Offset: 0x000017AE
		public Type method_2()
		{
			return this.type_0;
		}

		// Token: 0x06000190 RID: 400 RVA: 0x000035B6 File Offset: 0x000017B6
		public void method_3(Type type_1)
		{
			this.type_0 = type_1;
		}

		// Token: 0x04000039 RID: 57
		private string string_0;

		// Token: 0x0400003A RID: 58
		private Type type_0;
	}

	// Token: 0x02000010 RID: 16
	private sealed class Class8<T> : IComparer<KeyValuePair<int, T>>
	{
		// Token: 0x06000191 RID: 401 RVA: 0x000035BF File Offset: 0x000017BF
		public Class8(Comparison<T> comparison_1)
		{
			this.comparison_0 = comparison_1;
		}

		// Token: 0x06000192 RID: 402 RVA: 0x000193CC File Offset: 0x000175CC
		public int Compare(KeyValuePair<int, T> x, KeyValuePair<int, T> y)
		{
			int num = this.comparison_0(x.Value, y.Value);
			if (num == 0)
			{
				return y.Key.CompareTo(x.Key);
			}
			return num;
		}

		// Token: 0x0400003B RID: 59
		private readonly Comparison<T> comparison_0;
	}

	// Token: 0x02000011 RID: 17
	// (Invoke) Token: 0x06000194 RID: 404
	private delegate void Delegate1(Class94 class94_0);
}
