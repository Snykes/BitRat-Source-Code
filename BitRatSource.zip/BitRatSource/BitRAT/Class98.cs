﻿using System;

// Token: 0x02000020 RID: 32
internal sealed class Class98 : Class94
{
	// Token: 0x060001F9 RID: 505 RVA: 0x00003924 File Offset: 0x00001B24
	public Class98(Enum enum_1)
	{
		this.enum_0 = (enum_1 ?? Class98.Enum1.Value);
	}

	// Token: 0x060001FA RID: 506 RVA: 0x0000393D File Offset: 0x00001B3D
	public Enum method_2()
	{
		return this.enum_0;
	}

	// Token: 0x060001FB RID: 507 RVA: 0x00003945 File Offset: 0x00001B45
	public void method_3(Enum enum_1)
	{
		if (enum_1 == null)
		{
			throw new ArgumentException();
		}
		this.enum_0 = enum_1;
	}

	// Token: 0x060001FC RID: 508 RVA: 0x00003957 File Offset: 0x00001B57
	public override object vmethod_0()
	{
		return this.method_2();
	}

	// Token: 0x060001FD RID: 509 RVA: 0x0000395F File Offset: 0x00001B5F
	public override void vmethod_1(object object_0)
	{
		this.method_3((Enum)Enum.Parse(this.method_2().GetType(), object_0.ToString()));
	}

	// Token: 0x060001FE RID: 510 RVA: 0x00003982 File Offset: 0x00001B82
	public override int vmethod_2()
	{
		return 24;
	}

	// Token: 0x060001FF RID: 511 RVA: 0x0001BB90 File Offset: 0x00019D90
	public override Class94 vmethod_3(Class94 class94_0)
	{
		base.method_1(class94_0.method_0());
		int num = class94_0.vmethod_2();
		if (num <= 4)
		{
			if (num == 0)
			{
				this.method_3((Enum)Enum.ToObject(this.enum_0.GetType(), ((Class119)class94_0).method_2()));
				return this;
			}
			if (num == 4)
			{
				this.method_3((Enum)Enum.ToObject(this.enum_0.GetType(), ((Class102)class94_0).method_2()));
				return this;
			}
		}
		else
		{
			switch (num)
			{
			case 7:
				this.method_3((Enum)Enum.ToObject(this.enum_0.GetType(), ((Class118)class94_0).method_2()));
				return this;
			case 8:
			case 10:
				break;
			case 9:
				this.method_3((Enum)Enum.ToObject(this.enum_0.GetType(), ((Class115)class94_0).method_2()));
				return this;
			case 11:
				this.method_3((Enum)Enum.ToObject(this.enum_0.GetType(), ((Class99)class94_0).method_2()));
				return this;
			default:
				if (num == 15)
				{
					this.method_3((Enum)Enum.ToObject(this.enum_0.GetType(), ((Class101)class94_0).method_2()));
					return this;
				}
				switch (num)
				{
				case 19:
					this.method_3((Enum)Enum.ToObject(this.enum_0.GetType(), ((Class120)class94_0).method_2()));
					return this;
				case 21:
					this.method_3((Enum)Enum.ToObject(this.enum_0.GetType(), ((Class104)class94_0).method_2()));
					return this;
				case 22:
					this.method_3((Enum)Enum.ToObject(this.enum_0.GetType(), ((Class121)class94_0).method_2()));
					return this;
				case 24:
				{
					Type type = this.enum_0.GetType();
					Enum @enum = ((Class98)class94_0).method_2();
					if (@enum.GetType() == type)
					{
						this.method_3(@enum);
						return this;
					}
					this.method_3((Enum)Enum.ToObject(type, @enum));
					return this;
				}
				}
				break;
			}
		}
		throw new ArgumentOutOfRangeException();
	}

	// Token: 0x06000200 RID: 512 RVA: 0x00003986 File Offset: 0x00001B86
	public override Class94 vmethod_4()
	{
		Class98 @class = new Class98(this.enum_0);
		@class.method_1(base.method_0());
		return @class;
	}

	// Token: 0x04000131 RID: 305
	private Enum enum_0;

	// Token: 0x02000021 RID: 33
	private enum Enum1
	{
		// Token: 0x04000133 RID: 307
		Value
	}
}
