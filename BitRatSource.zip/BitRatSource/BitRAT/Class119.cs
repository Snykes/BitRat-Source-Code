﻿using System;

// Token: 0x02000092 RID: 146
internal sealed class Class119 : Class94
{
	// Token: 0x06000474 RID: 1140 RVA: 0x00004CC9 File Offset: 0x00002EC9
	public ushort method_2()
	{
		return this.ushort_0;
	}

	// Token: 0x06000475 RID: 1141 RVA: 0x00004CD1 File Offset: 0x00002ED1
	public void method_3(ushort ushort_1)
	{
		this.ushort_0 = ushort_1;
	}

	// Token: 0x06000476 RID: 1142 RVA: 0x00004CDA File Offset: 0x00002EDA
	public override object vmethod_0()
	{
		return this.method_2();
	}

	// Token: 0x06000477 RID: 1143 RVA: 0x00022550 File Offset: 0x00020750
	public override void vmethod_1(object object_0)
	{
		if (object_0 is short)
		{
			this.method_3((ushort)((short)object_0));
			return;
		}
		if (object_0 is int)
		{
			this.method_3((ushort)((int)object_0));
			return;
		}
		if (object_0 is long)
		{
			this.method_3((ushort)((long)object_0));
			return;
		}
		if (object_0 is uint)
		{
			this.method_3((ushort)((uint)object_0));
			return;
		}
		if (object_0 is ulong)
		{
			this.method_3((ushort)((ulong)object_0));
			return;
		}
		if (object_0 is float)
		{
			this.method_3((ushort)((float)object_0));
			return;
		}
		if (object_0 is double)
		{
			this.method_3((ushort)((double)object_0));
			return;
		}
		this.method_3(Convert.ToUInt16(object_0));
	}

	// Token: 0x06000478 RID: 1144 RVA: 0x00004CE7 File Offset: 0x00002EE7
	public override Class94 vmethod_4()
	{
		Class119 @class = new Class119();
		@class.method_3(this.ushort_0);
		@class.method_1(base.method_0());
		return @class;
	}

	// Token: 0x06000479 RID: 1145 RVA: 0x00002E1C File Offset: 0x0000101C
	public override int vmethod_2()
	{
		return 0;
	}

	// Token: 0x0600047A RID: 1146 RVA: 0x00022604 File Offset: 0x00020804
	public override Class94 vmethod_3(Class94 class94_0)
	{
		base.method_1(class94_0.method_0());
		switch (class94_0.vmethod_2())
		{
		case 0:
			this.method_3(((Class119)class94_0).method_2());
			return this;
		case 2:
			this.method_3((ushort)Convert.ToByte(((Class103)class94_0).method_2()));
			return this;
		case 4:
			this.method_3(Convert.ToUInt16(((Class102)class94_0).method_2()));
			return this;
		case 7:
			this.method_3((ushort)((Class118)class94_0).method_2());
			return this;
		case 8:
			this.method_3((ushort)((uint)((Class100)class94_0).method_2()));
			return this;
		case 9:
			this.method_3((ushort)((Class115)class94_0).method_2());
			return this;
		case 10:
			this.method_3((ushort)((Class114)class94_0).method_2());
			return this;
		case 11:
			this.method_3((ushort)((Class99)class94_0).method_2());
			return this;
		case 14:
			this.method_3((ushort)((int)((Class105)class94_0).method_2()));
			return this;
		case 15:
			this.method_3((ushort)((Class101)class94_0).method_2());
			return this;
		case 17:
			this.method_3((ushort)((Class117)class94_0).method_2());
			return this;
		case 19:
			this.method_3((ushort)((Class120)class94_0).method_2());
			return this;
		case 21:
			this.method_3((ushort)((Class104)class94_0).method_2());
			return this;
		case 22:
			this.method_3((ushort)((Class121)class94_0).method_2());
			return this;
		case 24:
			this.method_3(Convert.ToUInt16(((Class98)class94_0).method_2()));
			return this;
		}
		throw new ArgumentOutOfRangeException();
	}

	// Token: 0x040001DB RID: 475
	private ushort ushort_0;
}
