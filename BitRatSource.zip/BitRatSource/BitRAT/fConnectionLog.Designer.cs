﻿// Token: 0x02000196 RID: 406
[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
public sealed partial class fConnectionLog : global::System.Windows.Forms.Form
{
	// Token: 0x06001641 RID: 5697 RVA: 0x000A8488 File Offset: 0x000A6688
	[global::System.Diagnostics.DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && this.icontainer_0 != null)
			{
				this.icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	// Token: 0x06001642 RID: 5698 RVA: 0x000A84C8 File Offset: 0x000A66C8
	[global::System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		this.vmethod_1(new global::BrightIdeasSoftware.FastObjectListView());
		this.vmethod_3(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_17(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_5(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_7(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_19(new global::System.Windows.Forms.ContextMenuStrip(this.icontainer_0));
		this.vmethod_43(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_45(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_47(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_21(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_23(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_25(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_27(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_29(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_31(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_33(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_35(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_37(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_39(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_41(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_9(new global::System.Windows.Forms.StatusStrip());
		this.vmethod_11(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_13(new global::System.ComponentModel.BackgroundWorker());
		this.vmethod_15(new global::System.Windows.Forms.Timer(this.icontainer_0));
		this.vmethod_0().BeginInit();
		this.vmethod_18().SuspendLayout();
		this.vmethod_8().SuspendLayout();
		base.SuspendLayout();
		this.vmethod_0().Alignment = global::System.Windows.Forms.ListViewAlignment.Left;
		this.vmethod_0().AllColumns.Add(this.vmethod_2());
		this.vmethod_0().AllColumns.Add(this.vmethod_16());
		this.vmethod_0().AllColumns.Add(this.vmethod_4());
		this.vmethod_0().AllColumns.Add(this.vmethod_6());
		this.vmethod_0().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_0().AutoArrange = false;
		this.vmethod_0().BackColor = global::System.Drawing.Color.White;
		this.vmethod_0().BorderStyle = global::System.Windows.Forms.BorderStyle.None;
		this.vmethod_0().CellEditUseWholeCell = false;
		this.vmethod_0().Columns.AddRange(new global::System.Windows.Forms.ColumnHeader[]
		{
			this.vmethod_2(),
			this.vmethod_16(),
			this.vmethod_4(),
			this.vmethod_6()
		});
		this.vmethod_0().ContextMenuStrip = this.vmethod_18();
		this.vmethod_0().Cursor = global::System.Windows.Forms.Cursors.Default;
		this.vmethod_0().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.142858f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_0().FullRowSelect = true;
		this.vmethod_0().HeaderStyle = global::System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
		this.vmethod_0().HideSelection = false;
		this.vmethod_0().Location = new global::System.Drawing.Point(0, 0);
		this.vmethod_0().Margin = new global::System.Windows.Forms.Padding(1);
		this.vmethod_0().Name = "lvLog";
		this.vmethod_0().ShowGroups = false;
		this.vmethod_0().Size = new global::System.Drawing.Size(738, 359);
		this.vmethod_0().TabIndex = 65;
		this.vmethod_0().UseCompatibleStateImageBehavior = false;
		this.vmethod_0().UseHotControls = false;
		this.vmethod_0().UseOverlays = false;
		this.vmethod_0().View = global::System.Windows.Forms.View.Details;
		this.vmethod_0().VirtualMode = true;
		this.vmethod_2().AspectName = "HOST";
		this.vmethod_2().Hideable = false;
		this.vmethod_2().IsEditable = false;
		this.vmethod_2().Searchable = false;
		this.vmethod_2().Text = "IP";
		this.vmethod_2().Width = 160;
		this.vmethod_16().AspectName = "TYPE";
		this.vmethod_16().Hideable = false;
		this.vmethod_16().Text = "Type";
		this.vmethod_16().Width = 120;
		this.vmethod_4().AspectName = "ACTION";
		this.vmethod_4().Hideable = false;
		this.vmethod_4().IsEditable = false;
		this.vmethod_4().Searchable = false;
		this.vmethod_4().Text = "Action";
		this.vmethod_4().Width = 200;
		this.vmethod_6().AspectName = "TIME";
		this.vmethod_6().Hideable = false;
		this.vmethod_6().IsEditable = false;
		this.vmethod_6().Searchable = false;
		this.vmethod_6().Text = "Time";
		this.vmethod_6().Width = 140;
		this.vmethod_18().ImageScalingSize = new global::System.Drawing.Size(24, 24);
		this.vmethod_18().Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_42(),
			this.vmethod_46(),
			this.vmethod_20(),
			this.vmethod_28(),
			this.vmethod_30(),
			this.vmethod_32(),
			this.vmethod_34()
		});
		this.vmethod_18().Name = "ContextMenuStrip1";
		this.vmethod_18().Size = new global::System.Drawing.Size(170, 110);
		this.vmethod_42().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_44()
		});
		this.vmethod_42().Name = "UIToolStripMenuItem";
		this.vmethod_42().Size = new global::System.Drawing.Size(169, 22);
		this.vmethod_42().Text = "UI";
		this.vmethod_44().Checked = true;
		this.vmethod_44().CheckState = global::System.Windows.Forms.CheckState.Checked;
		this.vmethod_44().Name = "UseColorsToolStripMenuItem";
		this.vmethod_44().Size = new global::System.Drawing.Size(128, 22);
		this.vmethod_44().Text = "Use colors";
		this.vmethod_46().Name = "ToolStripMenuItem5";
		this.vmethod_46().Size = new global::System.Drawing.Size(166, 6);
		this.vmethod_20().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_22(),
			this.vmethod_24(),
			this.vmethod_26()
		});
		this.vmethod_20().Name = "CopyToClipboardToolStripMenuItem1";
		this.vmethod_20().Size = new global::System.Drawing.Size(169, 22);
		this.vmethod_20().Text = "Copy to clipboard";
		this.vmethod_22().Name = "SelectedToolStripMenuItem";
		this.vmethod_22().Size = new global::System.Drawing.Size(118, 22);
		this.vmethod_22().Text = "Selected";
		this.vmethod_24().Name = "ToolStripMenuItem1";
		this.vmethod_24().Size = new global::System.Drawing.Size(115, 6);
		this.vmethod_26().Name = "AllToolStripMenuItem";
		this.vmethod_26().Size = new global::System.Drawing.Size(118, 22);
		this.vmethod_26().Text = "All";
		this.vmethod_28().Name = "ToolStripMenuItem2";
		this.vmethod_28().Size = new global::System.Drawing.Size(166, 6);
		this.vmethod_30().Name = "ClearLogToolStripMenuItem";
		this.vmethod_30().Size = new global::System.Drawing.Size(169, 22);
		this.vmethod_30().Text = "Clear log";
		this.vmethod_32().Name = "ToolStripMenuItem3";
		this.vmethod_32().Size = new global::System.Drawing.Size(166, 6);
		this.vmethod_34().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_36(),
			this.vmethod_38(),
			this.vmethod_40()
		});
		this.vmethod_34().Name = "SaveToFileToolStripMenuItem1";
		this.vmethod_34().Size = new global::System.Drawing.Size(169, 22);
		this.vmethod_34().Text = "Save to file";
		this.vmethod_36().Name = "SelectedToolStripMenuItem1";
		this.vmethod_36().Size = new global::System.Drawing.Size(118, 22);
		this.vmethod_36().Text = "Selected";
		this.vmethod_38().Name = "ToolStripMenuItem4";
		this.vmethod_38().Size = new global::System.Drawing.Size(115, 6);
		this.vmethod_40().Name = "AllToolStripMenuItem1";
		this.vmethod_40().Size = new global::System.Drawing.Size(118, 22);
		this.vmethod_40().Text = "All";
		this.vmethod_8().AutoSize = false;
		this.vmethod_8().BackColor = global::System.Drawing.Color.FromArgb(235, 237, 239);
		this.vmethod_8().ImageScalingSize = new global::System.Drawing.Size(28, 28);
		this.vmethod_8().Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_10()
		});
		this.vmethod_8().Location = new global::System.Drawing.Point(0, 360);
		this.vmethod_8().Name = "ssStatus";
		this.vmethod_8().Padding = new global::System.Windows.Forms.Padding(1, 0, 7, 0);
		this.vmethod_8().Size = new global::System.Drawing.Size(738, 19);
		this.vmethod_8().SizingGrip = false;
		this.vmethod_8().Stretch = false;
		this.vmethod_8().TabIndex = 67;
		this.vmethod_8().Text = "stStatus";
		this.vmethod_10().AutoSize = false;
		this.vmethod_10().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_10().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_10().Margin = new global::System.Windows.Forms.Padding(0, 3, -4, 0);
		this.vmethod_10().Name = "tsEntries";
		this.vmethod_10().Size = new global::System.Drawing.Size(734, 16);
		this.vmethod_10().Spring = true;
		this.vmethod_10().Text = "Entries: 0";
		this.vmethod_10().TextAlign = global::System.Drawing.ContentAlignment.TopLeft;
		this.vmethod_14().Enabled = true;
		this.vmethod_14().Interval = 10;
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = global::System.Drawing.SystemColors.AppWorkspace;
		base.ClientSize = new global::System.Drawing.Size(738, 379);
		base.Controls.Add(this.vmethod_8());
		base.Controls.Add(this.vmethod_0());
		this.DoubleBuffered = true;
		base.Name = "fConnectionLog";
		base.Opacity = 0.0;
		base.ShowIcon = false;
		this.Text = "Connection log";
		this.vmethod_0().EndInit();
		this.vmethod_18().ResumeLayout(false);
		this.vmethod_8().ResumeLayout(false);
		this.vmethod_8().PerformLayout();
		base.ResumeLayout(false);
	}

	// Token: 0x04000860 RID: 2144
	private global::System.ComponentModel.IContainer icontainer_0;
}
