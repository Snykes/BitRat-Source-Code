﻿using System;
using System.Linq;

namespace BitRAT
{
	// Token: 0x020001DB RID: 475
	public class cCredentialsLogin
	{
		// Token: 0x06001A73 RID: 6771 RVA: 0x000BA750 File Offset: 0x000B8950
		public cCredentialsLogin()
		{
			this.idxValues = new string[6];
			checked
			{
				int num = this.idxValues.Count<string>() - 1;
				for (int i = 1; i <= num; i++)
				{
					this.idxValues[i] = "N/A";
				}
			}
		}

		// Token: 0x17000064 RID: 100
		// (get) Token: 0x06001A74 RID: 6772 RVA: 0x0000D830 File Offset: 0x0000BA30
		// (set) Token: 0x06001A75 RID: 6773 RVA: 0x0000D83A File Offset: 0x0000BA3A
		public string USER
		{
			get
			{
				return this.idxValues[0];
			}
			set
			{
				this.idxValues[0] = value;
			}
		}

		// Token: 0x17000065 RID: 101
		// (get) Token: 0x06001A76 RID: 6774 RVA: 0x0000D845 File Offset: 0x0000BA45
		// (set) Token: 0x06001A77 RID: 6775 RVA: 0x0000D84F File Offset: 0x0000BA4F
		public string TYPE
		{
			get
			{
				return this.idxValues[1];
			}
			set
			{
				this.idxValues[1] = value;
			}
		}

		// Token: 0x17000066 RID: 102
		// (get) Token: 0x06001A78 RID: 6776 RVA: 0x0000D85A File Offset: 0x0000BA5A
		// (set) Token: 0x06001A79 RID: 6777 RVA: 0x0000D864 File Offset: 0x0000BA64
		public string SOFTWARE
		{
			get
			{
				return this.idxValues[2];
			}
			set
			{
				this.idxValues[2] = value;
			}
		}

		// Token: 0x17000067 RID: 103
		// (get) Token: 0x06001A7A RID: 6778 RVA: 0x0000D86F File Offset: 0x0000BA6F
		// (set) Token: 0x06001A7B RID: 6779 RVA: 0x0000D879 File Offset: 0x0000BA79
		public string SERVER
		{
			get
			{
				return this.idxValues[3];
			}
			set
			{
				this.idxValues[3] = value;
			}
		}

		// Token: 0x17000068 RID: 104
		// (get) Token: 0x06001A7C RID: 6780 RVA: 0x0000D884 File Offset: 0x0000BA84
		// (set) Token: 0x06001A7D RID: 6781 RVA: 0x0000D88E File Offset: 0x0000BA8E
		public string USERNAME
		{
			get
			{
				return this.idxValues[4];
			}
			set
			{
				this.idxValues[4] = value;
			}
		}

		// Token: 0x17000069 RID: 105
		// (get) Token: 0x06001A7E RID: 6782 RVA: 0x0000D899 File Offset: 0x0000BA99
		// (set) Token: 0x06001A7F RID: 6783 RVA: 0x0000D8A3 File Offset: 0x0000BAA3
		public string PASSWORD
		{
			get
			{
				return this.idxValues[5];
			}
			set
			{
				this.idxValues[5] = value;
			}
		}

		// Token: 0x04000A06 RID: 2566
		public string[] idxValues;

		// Token: 0x04000A07 RID: 2567
		public string Key;

		// Token: 0x04000A08 RID: 2568
		private string m_user;

		// Token: 0x04000A09 RID: 2569
		private string m_type;

		// Token: 0x04000A0A RID: 2570
		private string m_software;

		// Token: 0x04000A0B RID: 2571
		private string m_username;

		// Token: 0x04000A0C RID: 2572
		private string m_password;

		// Token: 0x04000A0D RID: 2573
		private string m_tag;
	}
}
