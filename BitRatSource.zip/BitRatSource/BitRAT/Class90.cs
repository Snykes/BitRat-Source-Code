﻿using System;

// Token: 0x0200009E RID: 158
internal sealed class Class90 : Interface0
{
	// Token: 0x060004CF RID: 1231 RVA: 0x0002313C File Offset: 0x0002133C
	public Class90(Interface0 interface0_1)
	{
		this.interface0_0 = interface0_1;
		this.int_0 = interface0_1.imethod_2();
		this.byte_0 = new byte[this.int_0];
		this.byte_1 = new byte[this.int_0];
		this.byte_2 = new byte[this.int_0];
	}

	// Token: 0x060004D0 RID: 1232 RVA: 0x00005035 File Offset: 0x00003235
	public Interface0 method_0()
	{
		return this.interface0_0;
	}

	// Token: 0x060004D1 RID: 1233 RVA: 0x00023198 File Offset: 0x00021398
	public void imethod_1(bool bool_1, Interface2 interface2_0)
	{
		this.bool_0 = bool_1;
		if (interface2_0 is Class40)
		{
			Class40 @class = (Class40)interface2_0;
			byte[] array = @class.method_0();
			if (array.Length != this.int_0)
			{
				throw new ArgumentException("initialisation vector must be the same length as block size");
			}
			Array.Copy(array, 0, this.byte_0, 0, array.Length);
			interface2_0 = @class.method_1();
		}
		this.imethod_5();
		this.interface0_0.imethod_1(this.bool_0, interface2_0);
	}

	// Token: 0x060004D2 RID: 1234 RVA: 0x0000503D File Offset: 0x0000323D
	public string imethod_0()
	{
		return this.interface0_0.imethod_0() + "/CBC";
	}

	// Token: 0x060004D3 RID: 1235 RVA: 0x00002E1C File Offset: 0x0000101C
	public bool imethod_3()
	{
		return false;
	}

	// Token: 0x060004D4 RID: 1236 RVA: 0x00005054 File Offset: 0x00003254
	public int imethod_2()
	{
		return this.interface0_0.imethod_2();
	}

	// Token: 0x060004D5 RID: 1237 RVA: 0x00005061 File Offset: 0x00003261
	public int imethod_4(byte[] byte_3, int int_1, byte[] byte_4, int int_2)
	{
		if (!this.bool_0)
		{
			return this.method_2(byte_3, int_1, byte_4, int_2);
		}
		return this.method_1(byte_3, int_1, byte_4, int_2);
	}

	// Token: 0x060004D6 RID: 1238 RVA: 0x00005082 File Offset: 0x00003282
	public void imethod_5()
	{
		Array.Copy(this.byte_0, 0, this.byte_1, 0, this.byte_0.Length);
		Array.Clear(this.byte_2, 0, this.byte_2.Length);
		this.interface0_0.imethod_5();
	}

	// Token: 0x060004D7 RID: 1239 RVA: 0x0002320C File Offset: 0x0002140C
	private int method_1(byte[] byte_3, int int_1, byte[] byte_4, int int_2)
	{
		if (int_1 + this.int_0 > byte_3.Length)
		{
			throw new Exception1("input buffer too short");
		}
		for (int i = 0; i < this.int_0; i++)
		{
			byte[] array = this.byte_1;
			int num = i;
			array[num] ^= byte_3[int_1 + i];
		}
		int result = this.interface0_0.imethod_4(this.byte_1, 0, byte_4, int_2);
		Array.Copy(byte_4, int_2, this.byte_1, 0, this.byte_1.Length);
		return result;
	}

	// Token: 0x060004D8 RID: 1240 RVA: 0x00023284 File Offset: 0x00021484
	private int method_2(byte[] byte_3, int int_1, byte[] byte_4, int int_2)
	{
		if (int_1 + this.int_0 > byte_3.Length)
		{
			throw new Exception1("input buffer too short");
		}
		Array.Copy(byte_3, int_1, this.byte_2, 0, this.int_0);
		int result = this.interface0_0.imethod_4(byte_3, int_1, byte_4, int_2);
		for (int i = 0; i < this.int_0; i++)
		{
			int num = int_2 + i;
			byte_4[num] ^= this.byte_1[i];
		}
		byte[] array = this.byte_1;
		this.byte_1 = this.byte_2;
		this.byte_2 = array;
		return result;
	}

	// Token: 0x040001F1 RID: 497
	private byte[] byte_0;

	// Token: 0x040001F2 RID: 498
	private byte[] byte_1;

	// Token: 0x040001F3 RID: 499
	private byte[] byte_2;

	// Token: 0x040001F4 RID: 500
	private int int_0;

	// Token: 0x040001F5 RID: 501
	private Interface0 interface0_0;

	// Token: 0x040001F6 RID: 502
	private bool bool_0;
}
