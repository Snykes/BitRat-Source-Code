﻿// Token: 0x0200015E RID: 350
[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
public sealed partial class fMain : global::System.Windows.Forms.Form
{
	// Token: 0x060013E9 RID: 5097 RVA: 0x000A1E00 File Offset: 0x000A0000
	[global::System.Diagnostics.DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && this.icontainer_0 != null)
			{
				this.icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	// Token: 0x060013EA RID: 5098 RVA: 0x000A1E40 File Offset: 0x000A0040
	[global::System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::fMain));
		this.vmethod_5(new global::System.Windows.Forms.StatusStrip());
		this.vmethod_7(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_9(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_11(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_13(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_15(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_17(new global::System.Windows.Forms.ToolStripProgressBar());
		this.vmethod_19(new global::BrightIdeasSoftware.FastObjectListView());
		this.vmethod_41(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_25(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_27(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_217(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_251(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_29(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_31(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_33(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_95(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_35(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_97(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_83(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_219(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_37(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_43(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_39(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_89(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_45(new global::System.Windows.Forms.ContextMenuStrip(this.icontainer_0));
		this.vmethod_117(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_205(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_249(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_247(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_261(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_259(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_207(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_119(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_121(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_191(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_193(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_195(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_197(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_161(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_163(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_169(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_171(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_173(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_175(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_177(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_179(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_181(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_183(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_185(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_187(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_165(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_125(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_127(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_135(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_129(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_131(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_137(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_139(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_133(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_141(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_143(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_145(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_201(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_203(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_123(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_47(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_49(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_51(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_53(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_55(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_57(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_59(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_61(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_229(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_231(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_233(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_239(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_237(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_241(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_243(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_235(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_63(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_67(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_71(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_73(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_79(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_81(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_113(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_115(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_189(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_151(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_75(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_77(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_69(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_85(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_87(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_159(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_105(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_111(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_109(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_107(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_209(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_211(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_253(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_255(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_263(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_265(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_257(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_213(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_227(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_245(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_65(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_221(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_21(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_23(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_91(new global::System.Windows.Forms.Timer(this.icontainer_0));
		this.vmethod_93(new global::Zeroit.Framework.Progress.ZeroitWin8ProgressRing());
		this.vmethod_99(new global::System.ComponentModel.BackgroundWorker());
		this.vmethod_101(new global::System.ComponentModel.BackgroundWorker());
		this.vmethod_103(new global::System.ComponentModel.BackgroundWorker());
		this.vmethod_147(new global::System.ComponentModel.BackgroundWorker());
		this.vmethod_149(new global::System.ComponentModel.BackgroundWorker());
		this.vmethod_153(new global::System.ComponentModel.BackgroundWorker());
		this.vmethod_155(new global::System.ComponentModel.BackgroundWorker());
		this.vmethod_157(new global::System.ComponentModel.BackgroundWorker());
		this.vmethod_167(new global::System.ComponentModel.BackgroundWorker());
		this.vmethod_199(new global::System.ComponentModel.BackgroundWorker());
		this.vmethod_215(new global::System.Windows.Forms.Timer(this.icontainer_0));
		this.vmethod_223(new global::System.ComponentModel.BackgroundWorker());
		this.vmethod_225(new global::System.ComponentModel.BackgroundWorker());
		this.vmethod_269(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_267(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_4().SuspendLayout();
		this.vmethod_18().BeginInit();
		this.vmethod_44().SuspendLayout();
		base.SuspendLayout();
		this.vmethod_4().AutoSize = false;
		this.vmethod_4().ImageScalingSize = new global::System.Drawing.Size(28, 28);
		this.vmethod_4().Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_6(),
			this.vmethod_8(),
			this.vmethod_10(),
			this.vmethod_12(),
			this.vmethod_14(),
			this.vmethod_16()
		});
		this.vmethod_4().Location = new global::System.Drawing.Point(0, 441);
		this.vmethod_4().Name = "ssStatus";
		this.vmethod_4().Padding = new global::System.Windows.Forms.Padding(1, 0, 7, 0);
		this.vmethod_4().Size = new global::System.Drawing.Size(1404, 20);
		this.vmethod_4().SizingGrip = false;
		this.vmethod_4().Stretch = false;
		this.vmethod_4().TabIndex = 4;
		this.vmethod_4().Text = "stStatus";
		this.vmethod_6().AutoSize = false;
		this.vmethod_6().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_6().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_6().Margin = new global::System.Windows.Forms.Padding(0, 4, 0, 2);
		this.vmethod_6().Name = "tsStatus";
		this.vmethod_6().Size = new global::System.Drawing.Size(721, 14);
		this.vmethod_6().Spring = true;
		this.vmethod_6().Text = "Status: Pending...";
		this.vmethod_6().TextAlign = global::System.Drawing.ContentAlignment.TopLeft;
		this.vmethod_8().AutoSize = false;
		this.vmethod_8().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_8().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_8().Margin = new global::System.Windows.Forms.Padding(0, 4, 0, 2);
		this.vmethod_8().Name = "tsPort";
		this.vmethod_8().Size = new global::System.Drawing.Size(125, 14);
		this.vmethod_8().Text = "Port: N/A";
		this.vmethod_8().TextAlign = global::System.Drawing.ContentAlignment.TopLeft;
		this.vmethod_10().AutoSize = false;
		this.vmethod_10().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_10().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_10().Margin = new global::System.Windows.Forms.Padding(0, 4, 0, 2);
		this.vmethod_10().Name = "tsClients";
		this.vmethod_10().Overflow = global::System.Windows.Forms.ToolStripItemOverflow.Never;
		this.vmethod_10().Size = new global::System.Drawing.Size(125, 14);
		this.vmethod_10().Text = "Clients: 0/0";
		this.vmethod_10().TextAlign = global::System.Drawing.ContentAlignment.TopLeft;
		this.vmethod_12().AutoSize = false;
		this.vmethod_12().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_12().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_12().Font = new global::System.Drawing.Font("Segoe UI", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_12().Margin = new global::System.Windows.Forms.Padding(0, 4, 0, 2);
		this.vmethod_12().Name = "tsDataInOut";
		this.vmethod_12().Size = new global::System.Drawing.Size(170, 14);
		this.vmethod_12().Text = "In/Out: 0 B/0 B";
		this.vmethod_12().TextAlign = global::System.Drawing.ContentAlignment.TopLeft;
		this.vmethod_14().AutoSize = false;
		this.vmethod_14().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_14().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_14().Margin = new global::System.Windows.Forms.Padding(0, 4, 0, 2);
		this.vmethod_14().Name = "tsSpeed";
		this.vmethod_14().Size = new global::System.Drawing.Size(180, 14);
		this.vmethod_14().Text = "D: 0 B/s, U: 0 B/s";
		this.vmethod_14().TextAlign = global::System.Drawing.ContentAlignment.TopLeft;
		this.vmethod_16().Alignment = global::System.Windows.Forms.ToolStripItemAlignment.Right;
		this.vmethod_16().ForeColor = global::System.Drawing.Color.FromArgb(192, 192, 0);
		this.vmethod_16().Margin = new global::System.Windows.Forms.Padding(2, 4, -5, 3);
		this.vmethod_16().Maximum = 1000;
		this.vmethod_16().Name = "tsProgress";
		this.vmethod_16().Size = new global::System.Drawing.Size(78, 13);
		this.vmethod_16().Step = 1;
		this.vmethod_16().Style = global::System.Windows.Forms.ProgressBarStyle.Continuous;
		this.vmethod_18().AllColumns.Add(this.vmethod_40());
		this.vmethod_18().AllColumns.Add(this.vmethod_24());
		this.vmethod_18().AllColumns.Add(this.vmethod_26());
		this.vmethod_18().AllColumns.Add(this.vmethod_216());
		this.vmethod_18().AllColumns.Add(this.vmethod_250());
		this.vmethod_18().AllColumns.Add(this.vmethod_28());
		this.vmethod_18().AllColumns.Add(this.vmethod_30());
		this.vmethod_18().AllColumns.Add(this.vmethod_32());
		this.vmethod_18().AllColumns.Add(this.vmethod_94());
		this.vmethod_18().AllColumns.Add(this.vmethod_34());
		this.vmethod_18().AllColumns.Add(this.vmethod_96());
		this.vmethod_18().AllColumns.Add(this.vmethod_82());
		this.vmethod_18().AllColumns.Add(this.vmethod_218());
		this.vmethod_18().AllColumns.Add(this.vmethod_36());
		this.vmethod_18().AllColumns.Add(this.vmethod_42());
		this.vmethod_18().AllColumns.Add(this.vmethod_38());
		this.vmethod_18().AllColumns.Add(this.vmethod_88());
		this.vmethod_18().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_18().BorderStyle = global::System.Windows.Forms.BorderStyle.None;
		this.vmethod_18().CellEditUseWholeCell = false;
		this.vmethod_18().Columns.AddRange(new global::System.Windows.Forms.ColumnHeader[]
		{
			this.vmethod_40(),
			this.vmethod_24(),
			this.vmethod_26(),
			this.vmethod_216(),
			this.vmethod_250(),
			this.vmethod_28(),
			this.vmethod_30(),
			this.vmethod_32(),
			this.vmethod_94(),
			this.vmethod_34(),
			this.vmethod_96(),
			this.vmethod_82(),
			this.vmethod_218(),
			this.vmethod_36(),
			this.vmethod_42(),
			this.vmethod_38(),
			this.vmethod_88()
		});
		this.vmethod_18().ContextMenuStrip = this.vmethod_44();
		this.vmethod_18().Cursor = global::System.Windows.Forms.Cursors.Default;
		this.vmethod_18().FullRowSelect = true;
		this.vmethod_18().HideSelection = false;
		this.vmethod_18().Location = new global::System.Drawing.Point(0, -1);
		this.vmethod_18().Margin = new global::System.Windows.Forms.Padding(1, 1, 0, 1);
		this.vmethod_18().Name = "lvClients";
		this.vmethod_18().OwnerDraw = false;
		this.vmethod_18().ShowGroups = false;
		this.vmethod_18().Size = new global::System.Drawing.Size(1404, 444);
		this.vmethod_18().SortGroupItemsByPrimaryColumn = false;
		this.vmethod_18().TabIndex = 6;
		this.vmethod_18().UseCellFormatEvents = true;
		this.vmethod_18().UseCompatibleStateImageBehavior = false;
		this.vmethod_18().UseHotControls = false;
		this.vmethod_18().UseOverlays = false;
		this.vmethod_18().View = global::System.Windows.Forms.View.Details;
		this.vmethod_18().VirtualMode = true;
		this.vmethod_40().AspectName = string.Empty;
		this.vmethod_40().Groupable = false;
		this.vmethod_40().Hideable = false;
		this.vmethod_40().ImageAspectName = "ICO_STATUS";
		this.vmethod_40().IsEditable = false;
		this.vmethod_40().Sortable = false;
		this.vmethod_40().Text = string.Empty;
		this.vmethod_40().Width = 32;
		this.vmethod_24().AspectName = "IP";
		this.vmethod_24().Hideable = false;
		this.vmethod_24().IsEditable = false;
		this.vmethod_24().Text = "IP";
		this.vmethod_24().Width = 100;
		this.vmethod_26().AspectName = "USER";
		this.vmethod_26().Hideable = false;
		this.vmethod_26().IsEditable = false;
		this.vmethod_26().Text = "User";
		this.vmethod_26().Width = 100;
		this.vmethod_216().AspectName = "SYS_SHORT";
		this.vmethod_216().Hideable = false;
		this.vmethod_216().ImageAspectName = string.Empty;
		this.vmethod_216().Text = "System";
		this.vmethod_250().AspectName = "UACLEVEL";
		this.vmethod_250().Hideable = false;
		this.vmethod_250().Text = "UAC Level";
		this.vmethod_250().Width = 80;
		this.vmethod_28().AspectName = "OS";
		this.vmethod_28().Hideable = false;
		this.vmethod_28().IsEditable = false;
		this.vmethod_28().Text = "Operating System";
		this.vmethod_28().Width = 140;
		this.vmethod_30().AspectName = "AV";
		this.vmethod_30().Groupable = false;
		this.vmethod_30().Hideable = false;
		this.vmethod_30().IsEditable = false;
		this.vmethod_30().Text = "Active Window";
		this.vmethod_30().Width = 160;
		this.vmethod_32().AspectName = "IDLE";
		this.vmethod_32().Groupable = false;
		this.vmethod_32().Hideable = false;
		this.vmethod_32().IsEditable = false;
		this.vmethod_32().Text = "Idle";
		this.vmethod_32().Width = 100;
		this.vmethod_94().AspectName = "BANDWIDTHDL";
		this.vmethod_94().Hideable = false;
		this.vmethod_94().Text = "Bandwidth";
		this.vmethod_94().Width = 80;
		this.vmethod_34().AspectName = "INOUT";
		this.vmethod_34().Groupable = false;
		this.vmethod_34().Hideable = false;
		this.vmethod_34().IsEditable = false;
		this.vmethod_34().Text = "In/Out";
		this.vmethod_34().Width = 100;
		this.vmethod_96().AspectName = "SPEED";
		this.vmethod_96().Hideable = false;
		this.vmethod_96().Text = "Speed";
		this.vmethod_96().Width = 80;
		this.vmethod_82().AspectName = "CPU_USAGE";
		this.vmethod_82().Hideable = false;
		this.vmethod_82().Text = "CPU";
		this.vmethod_218().AspectName = "RAM";
		this.vmethod_218().Hideable = false;
		this.vmethod_218().Text = "RAM";
		this.vmethod_36().AspectName = "CAM";
		this.vmethod_36().Hideable = false;
		this.vmethod_36().IsEditable = false;
		this.vmethod_36().Text = "Cam";
		this.vmethod_42().AspectName = "COUNTRY";
		this.vmethod_42().Hideable = false;
		this.vmethod_42().ImageAspectName = "ICO_FLAG";
		this.vmethod_42().Text = "Country";
		this.vmethod_42().Width = 80;
		this.vmethod_38().AspectName = "PING";
		this.vmethod_38().Groupable = false;
		this.vmethod_38().Hideable = false;
		this.vmethod_38().ImageAspectName = "ICO_CON";
		this.vmethod_38().IsEditable = false;
		this.vmethod_38().Text = "Ping";
		this.vmethod_38().Width = 80;
		this.vmethod_88().AspectName = string.Empty;
		this.vmethod_88().Hideable = false;
		this.vmethod_88().ImageAspectName = "ICO_TYPE";
		this.vmethod_88().Sortable = false;
		this.vmethod_88().Text = string.Empty;
		this.vmethod_88().Width = 32;
		this.vmethod_44().ImageScalingSize = new global::System.Drawing.Size(24, 24);
		this.vmethod_44().Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_116(),
			this.vmethod_122(),
			this.vmethod_46(),
			this.vmethod_62(),
			this.vmethod_66(),
			this.vmethod_68(),
			this.vmethod_84(),
			this.vmethod_86(),
			this.vmethod_158(),
			this.vmethod_104(),
			this.vmethod_208(),
			this.vmethod_210(),
			this.vmethod_212(),
			this.vmethod_226(),
			this.vmethod_244(),
			this.vmethod_64(),
			this.vmethod_220()
		});
		this.vmethod_44().Name = "cmsClients";
		this.vmethod_44().Size = new global::System.Drawing.Size(181, 304);
		this.vmethod_116().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_204(),
			this.vmethod_248(),
			this.vmethod_246(),
			this.vmethod_260(),
			this.vmethod_258(),
			this.vmethod_206(),
			this.vmethod_118(),
			this.vmethod_120(),
			this.vmethod_190(),
			this.vmethod_160(),
			this.vmethod_178(),
			this.vmethod_164(),
			this.vmethod_124(),
			this.vmethod_126(),
			this.vmethod_200(),
			this.vmethod_202()
		});
		this.vmethod_116().Name = "ClientToolStripMenuItem";
		this.vmethod_116().Size = new global::System.Drawing.Size(180, 22);
		this.vmethod_116().Text = "Client";
		this.vmethod_204().Name = "BuildToolStripMenuItem";
		this.vmethod_204().Size = new global::System.Drawing.Size(239, 22);
		this.vmethod_204().Text = "Open dashboard";
		this.vmethod_248().Name = "ToolStripMenuItem21";
		this.vmethod_248().Size = new global::System.Drawing.Size(236, 6);
		this.vmethod_246().Name = "AttemptUACElevationBypassToolStripMenuItem";
		this.vmethod_246().Size = new global::System.Drawing.Size(239, 22);
		this.vmethod_246().Text = "Attempt UAC bypass (Exploit)";
		this.vmethod_260().Name = "AttemptKillWindowsDefenderToolStripMenuItem";
		this.vmethod_260().Size = new global::System.Drawing.Size(239, 22);
		this.vmethod_260().Text = "Attempt kill Windows Defender";
		this.vmethod_258().Name = "AttemptProtectProcessBSODOnKillToolStripMenuItem";
		this.vmethod_258().Size = new global::System.Drawing.Size(239, 22);
		this.vmethod_258().Text = "Attempt protect process";
		this.vmethod_206().Name = "ToolStripMenuItem17";
		this.vmethod_206().Size = new global::System.Drawing.Size(236, 6);
		this.vmethod_118().Name = "ReconnectToolStripMenuItem";
		this.vmethod_118().Size = new global::System.Drawing.Size(239, 22);
		this.vmethod_118().Text = "Reconnect";
		this.vmethod_120().Name = "ToolStripMenuItem8";
		this.vmethod_120().Size = new global::System.Drawing.Size(236, 6);
		this.vmethod_190().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_192(),
			this.vmethod_194(),
			this.vmethod_196()
		});
		this.vmethod_190().Name = "ShowPreviewToolStripMenuItem";
		this.vmethod_190().Size = new global::System.Drawing.Size(239, 22);
		this.vmethod_190().Text = "Show preview";
		this.vmethod_192().Name = "ScreenToolStripMenuItem";
		this.vmethod_192().Size = new global::System.Drawing.Size(121, 22);
		this.vmethod_192().Text = "Screen";
		this.vmethod_194().Name = "ToolStripMenuItem15";
		this.vmethod_194().Size = new global::System.Drawing.Size(118, 6);
		this.vmethod_196().Name = "WebcamToolStripMenuItem";
		this.vmethod_196().Size = new global::System.Drawing.Size(121, 22);
		this.vmethod_196().Text = "Webcam";
		this.vmethod_160().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_162(),
			this.vmethod_168(),
			this.vmethod_170(),
			this.vmethod_266(),
			this.vmethod_268()
		});
		this.vmethod_160().Name = "MaintenenceToolStripMenuItem";
		this.vmethod_160().Size = new global::System.Drawing.Size(239, 22);
		this.vmethod_160().Text = "Maintenance";
		this.vmethod_162().Name = "RefreshBandwidthToolStripMenuItem";
		this.vmethod_162().Size = new global::System.Drawing.Size(195, 22);
		this.vmethod_162().Text = "Refresh bandwidth";
		this.vmethod_168().Name = "ToolStripMenuItem12";
		this.vmethod_168().Size = new global::System.Drawing.Size(192, 6);
		this.vmethod_170().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_172(),
			this.vmethod_174(),
			this.vmethod_176()
		});
		this.vmethod_170().Name = "DownloadAndExecuteToolStripMenuItem";
		this.vmethod_170().Size = new global::System.Drawing.Size(195, 22);
		this.vmethod_170().Text = "Download and execute";
		this.vmethod_172().Name = "ExecuteInMemoryToolStripMenuItem";
		this.vmethod_172().Size = new global::System.Drawing.Size(180, 22);
		this.vmethod_172().Text = "Memory";
		this.vmethod_174().Name = "ToolStripMenuItem13";
		this.vmethod_174().Size = new global::System.Drawing.Size(177, 6);
		this.vmethod_176().Name = "ExecuteFromDiskToolStripMenuItem";
		this.vmethod_176().Size = new global::System.Drawing.Size(180, 22);
		this.vmethod_176().Text = "To disk";
		this.vmethod_178().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_180()
		});
		this.vmethod_178().Name = "NetworkingToolStripMenuItem";
		this.vmethod_178().Size = new global::System.Drawing.Size(239, 22);
		this.vmethod_178().Text = "Networking";
		this.vmethod_180().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_182(),
			this.vmethod_184(),
			this.vmethod_186()
		});
		this.vmethod_180().Name = "ReverseSocks4ToolStripMenuItem";
		this.vmethod_180().Size = new global::System.Drawing.Size(180, 22);
		this.vmethod_180().Text = "Reverse SOCKS4";
		this.vmethod_182().Name = "StartToolStripMenuItem";
		this.vmethod_182().Size = new global::System.Drawing.Size(98, 22);
		this.vmethod_182().Text = "Start";
		this.vmethod_184().Name = "ToolStripMenuItem14";
		this.vmethod_184().Size = new global::System.Drawing.Size(95, 6);
		this.vmethod_186().Name = "StopToolStripMenuItem";
		this.vmethod_186().Size = new global::System.Drawing.Size(98, 22);
		this.vmethod_186().Text = "Stop";
		this.vmethod_164().Name = "ToolStripMenuItem5";
		this.vmethod_164().Size = new global::System.Drawing.Size(236, 6);
		this.vmethod_124().Name = "DisconnectToolStripMenuItem";
		this.vmethod_124().Size = new global::System.Drawing.Size(239, 22);
		this.vmethod_124().Text = "Disconnect";
		this.vmethod_126().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_134(),
			this.vmethod_128(),
			this.vmethod_130(),
			this.vmethod_136(),
			this.vmethod_138(),
			this.vmethod_132(),
			this.vmethod_140(),
			this.vmethod_142(),
			this.vmethod_144()
		});
		this.vmethod_126().Name = "SystemToolStripMenuItem";
		this.vmethod_126().Size = new global::System.Drawing.Size(239, 22);
		this.vmethod_126().Text = "System";
		this.vmethod_134().Name = "SleepToolStripMenuItem";
		this.vmethod_134().Size = new global::System.Drawing.Size(136, 22);
		this.vmethod_134().Text = "Sleep";
		this.vmethod_128().Name = "LogOutToolStripMenuItem";
		this.vmethod_128().Size = new global::System.Drawing.Size(136, 22);
		this.vmethod_128().Text = "Log out";
		this.vmethod_130().Name = "ToolStripMenuItem9";
		this.vmethod_130().Size = new global::System.Drawing.Size(133, 6);
		this.vmethod_136().Name = "HibernateToolStripMenuItem";
		this.vmethod_136().Size = new global::System.Drawing.Size(136, 22);
		this.vmethod_136().Text = "Hibernate";
		this.vmethod_138().Name = "ToolStripMenuItem11";
		this.vmethod_138().Size = new global::System.Drawing.Size(133, 6);
		this.vmethod_132().Name = "RestartToolStripMenuItem";
		this.vmethod_132().Size = new global::System.Drawing.Size(136, 22);
		this.vmethod_132().Text = "Reboot";
		this.vmethod_140().Name = "ShutdownToolStripMenuItem";
		this.vmethod_140().Size = new global::System.Drawing.Size(136, 22);
		this.vmethod_140().Text = "Shutdown";
		this.vmethod_142().Name = "ToolStripMenuItem10";
		this.vmethod_142().Size = new global::System.Drawing.Size(133, 6);
		this.vmethod_144().Name = "BSODToolStripMenuItem";
		this.vmethod_144().Size = new global::System.Drawing.Size(136, 22);
		this.vmethod_144().Text = "Force BSOD";
		this.vmethod_200().Name = "ToolStripMenuItem16";
		this.vmethod_200().Size = new global::System.Drawing.Size(236, 6);
		this.vmethod_202().Name = "UninstallToolStripMenuItem";
		this.vmethod_202().Size = new global::System.Drawing.Size(239, 22);
		this.vmethod_202().Text = "Uninstall";
		this.vmethod_122().Name = "ToolStripMenuItem7";
		this.vmethod_122().Size = new global::System.Drawing.Size(177, 6);
		this.vmethod_46().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_48(),
			this.vmethod_58(),
			this.vmethod_228(),
			this.vmethod_230()
		});
		this.vmethod_46().Name = "LayoutToolStripMenuItem";
		this.vmethod_46().Size = new global::System.Drawing.Size(180, 22);
		this.vmethod_46().Text = "Layout";
		this.vmethod_48().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_50(),
			this.vmethod_52(),
			this.vmethod_56()
		});
		this.vmethod_48().Name = "GroupsToolStripMenuItem";
		this.vmethod_48().Size = new global::System.Drawing.Size(134, 22);
		this.vmethod_48().Text = "Groups";
		this.vmethod_50().Name = "ShowToolStripMenuItem";
		this.vmethod_50().Size = new global::System.Drawing.Size(119, 22);
		this.vmethod_50().Text = "Show";
		this.vmethod_52().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_54()
		});
		this.vmethod_52().Name = "SubtitlesToolStripMenuItem";
		this.vmethod_52().Size = new global::System.Drawing.Size(119, 22);
		this.vmethod_52().Text = "Subtitles";
		this.vmethod_54().Name = "ShowToolStripMenuItem1";
		this.vmethod_54().Size = new global::System.Drawing.Size(103, 22);
		this.vmethod_54().Text = "Show";
		this.vmethod_56().Name = "CollapseToolStripMenuItem";
		this.vmethod_56().Size = new global::System.Drawing.Size(119, 22);
		this.vmethod_56().Text = "Collapse";
		this.vmethod_58().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_60()
		});
		this.vmethod_58().Name = "ClientTableToolStripMenuItem";
		this.vmethod_58().Size = new global::System.Drawing.Size(134, 22);
		this.vmethod_58().Text = "Client table";
		this.vmethod_60().Checked = true;
		this.vmethod_60().CheckState = global::System.Windows.Forms.CheckState.Checked;
		this.vmethod_60().Name = "AutoRefreshToolStripMenuItem";
		this.vmethod_60().Size = new global::System.Drawing.Size(139, 22);
		this.vmethod_60().Text = "Auto refresh";
		this.vmethod_228().Name = "ToolStripMenuItem20";
		this.vmethod_228().Size = new global::System.Drawing.Size(131, 6);
		this.vmethod_230().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_232(),
			this.vmethod_238(),
			this.vmethod_236(),
			this.vmethod_240(),
			this.vmethod_242(),
			this.vmethod_234()
		});
		this.vmethod_230().Name = "ThemeToolStripMenuItem";
		this.vmethod_230().Size = new global::System.Drawing.Size(134, 22);
		this.vmethod_230().Text = "Theme";
		this.vmethod_232().Checked = true;
		this.vmethod_232().CheckState = global::System.Windows.Forms.CheckState.Checked;
		this.vmethod_232().Name = "RoyalBlueToolStripMenuItem";
		this.vmethod_232().Size = new global::System.Drawing.Size(161, 22);
		this.vmethod_232().Text = "Royal blue";
		this.vmethod_238().Name = "AluminumAlloyToolStripMenuItem";
		this.vmethod_238().Size = new global::System.Drawing.Size(161, 22);
		this.vmethod_238().Text = "Aluminum Alloy";
		this.vmethod_236().Name = "LunaToolStripMenuItem";
		this.vmethod_236().Size = new global::System.Drawing.Size(161, 22);
		this.vmethod_236().Text = "Luna";
		this.vmethod_240().Name = "OSXTigerToolStripMenuItem";
		this.vmethod_240().Size = new global::System.Drawing.Size(161, 22);
		this.vmethod_240().Text = "OSX Tiger";
		this.vmethod_242().Name = "Office2010ToolStripMenuItem";
		this.vmethod_242().Size = new global::System.Drawing.Size(161, 22);
		this.vmethod_242().Text = "Office 2010";
		this.vmethod_234().Name = "DarkModeToolStripMenuItem";
		this.vmethod_234().Size = new global::System.Drawing.Size(161, 22);
		this.vmethod_234().Text = "Dark mode";
		this.vmethod_62().Name = "ToolStripMenuItem1";
		this.vmethod_62().Size = new global::System.Drawing.Size(177, 6);
		this.vmethod_66().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_70(),
			this.vmethod_78(),
			this.vmethod_112(),
			this.vmethod_150(),
			this.vmethod_74(),
			this.vmethod_76()
		});
		this.vmethod_66().Name = "PluginsToolStripMenuItem";
		this.vmethod_66().Size = new global::System.Drawing.Size(180, 22);
		this.vmethod_66().Text = "Plugins";
		this.vmethod_70().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_72()
		});
		this.vmethod_70().Name = "MiningToolStripMenuItem";
		this.vmethod_70().Size = new global::System.Drawing.Size(190, 22);
		this.vmethod_70().Text = "Mining";
		this.vmethod_72().Name = "XMRToolStripMenuItem";
		this.vmethod_72().Size = new global::System.Drawing.Size(99, 22);
		this.vmethod_72().Text = "XMR";
		this.vmethod_78().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_80()
		});
		this.vmethod_78().Name = "CredentialsToolStripMenuItem";
		this.vmethod_78().Size = new global::System.Drawing.Size(190, 22);
		this.vmethod_78().Text = "Passwords";
		this.vmethod_80().Name = "LoginsToolStripMenuItem1";
		this.vmethod_80().Size = new global::System.Drawing.Size(109, 22);
		this.vmethod_80().Text = "Logins";
		this.vmethod_112().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_114(),
			this.vmethod_188()
		});
		this.vmethod_112().Name = "ProxyToolStripMenuItem";
		this.vmethod_112().Size = new global::System.Drawing.Size(190, 22);
		this.vmethod_112().Text = "Proxy";
		this.vmethod_114().Name = "SOCKS5ServerToolStripMenuItem";
		this.vmethod_114().Size = new global::System.Drawing.Size(209, 22);
		this.vmethod_114().Text = "SOCKS5 Manager";
		this.vmethod_188().Name = "ReverseSOCKS4ToolStripMenuItem1";
		this.vmethod_188().Size = new global::System.Drawing.Size(209, 22);
		this.vmethod_188().Text = "Reverse SOCKS4 Manager";
		this.vmethod_150().Name = "DDoSToolStripMenuItem";
		this.vmethod_150().Size = new global::System.Drawing.Size(190, 22);
		this.vmethod_150().Text = "DDoS";
		this.vmethod_74().Name = "ToolStripMenuItem3";
		this.vmethod_74().Size = new global::System.Drawing.Size(187, 6);
		this.vmethod_76().Name = "OpenPluginDirectoryToolStripMenuItem";
		this.vmethod_76().Size = new global::System.Drawing.Size(190, 22);
		this.vmethod_76().Text = "Open plugin directory";
		this.vmethod_68().Name = "ToolStripMenuItem2";
		this.vmethod_68().Size = new global::System.Drawing.Size(177, 6);
		this.vmethod_84().Name = "TransferManagerToolStripMenuItem";
		this.vmethod_84().Size = new global::System.Drawing.Size(180, 22);
		this.vmethod_84().Text = "Transfer manager";
		this.vmethod_86().Name = "ToolStripMenuItem4";
		this.vmethod_86().Size = new global::System.Drawing.Size(177, 6);
		this.vmethod_158().Name = "ClearStatisticsToolStripMenuItem";
		this.vmethod_158().Size = new global::System.Drawing.Size(180, 22);
		this.vmethod_158().Text = "Clear statistics";
		this.vmethod_104().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_110(),
			this.vmethod_108(),
			this.vmethod_106()
		});
		this.vmethod_104().Name = "CopyToolStripMenuItem";
		this.vmethod_104().Size = new global::System.Drawing.Size(180, 22);
		this.vmethod_104().Text = "Copy to clipboard";
		this.vmethod_110().Name = "SelectedToolStripMenuItem";
		this.vmethod_110().Size = new global::System.Drawing.Size(118, 22);
		this.vmethod_110().Text = "Selected";
		this.vmethod_108().Name = "ToolStripMenuItem6";
		this.vmethod_108().Size = new global::System.Drawing.Size(115, 6);
		this.vmethod_106().Name = "AllToolStripMenuItem";
		this.vmethod_106().Size = new global::System.Drawing.Size(118, 22);
		this.vmethod_106().Text = "All";
		this.vmethod_208().Name = "ToolStripMenuItem18";
		this.vmethod_208().Size = new global::System.Drawing.Size(177, 6);
		this.vmethod_210().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_252(),
			this.vmethod_254(),
			this.vmethod_262(),
			this.vmethod_264(),
			this.vmethod_256()
		});
		this.vmethod_210().Name = "BuilderToolStripMenuItem";
		this.vmethod_210().Size = new global::System.Drawing.Size(180, 22);
		this.vmethod_210().Text = "Builder";
		this.vmethod_252().Name = "ClientToolStripMenuItem1";
		this.vmethod_252().Size = new global::System.Drawing.Size(138, 22);
		this.vmethod_252().Text = "Client";
		this.vmethod_254().Name = "ToolStripMenuItem22";
		this.vmethod_254().Size = new global::System.Drawing.Size(135, 6);
		this.vmethod_262().Name = "BinderToolStripMenuItem";
		this.vmethod_262().Size = new global::System.Drawing.Size(138, 22);
		this.vmethod_262().Text = "Binder";
		this.vmethod_264().Name = "ToolStripMenuItem23";
		this.vmethod_264().Size = new global::System.Drawing.Size(135, 6);
		this.vmethod_256().Name = "DownloaderToolStripMenuItem";
		this.vmethod_256().Size = new global::System.Drawing.Size(138, 22);
		this.vmethod_256().Text = "Downloader";
		this.vmethod_212().Name = "ToolStripMenuItem19";
		this.vmethod_212().Size = new global::System.Drawing.Size(177, 6);
		this.vmethod_226().Name = "ConnectionLogToolStripMenuItem";
		this.vmethod_226().Size = new global::System.Drawing.Size(180, 22);
		this.vmethod_226().Text = "Connection log";
		this.vmethod_244().Name = "OnjoinTasksToolStripMenuItem";
		this.vmethod_244().Size = new global::System.Drawing.Size(180, 22);
		this.vmethod_244().Text = "On-join tasks";
		this.vmethod_64().Name = "SettingsToolStripMenuItem";
		this.vmethod_64().Size = new global::System.Drawing.Size(180, 22);
		this.vmethod_64().Text = "Settings";
		this.vmethod_220().Name = "AboutToolStripMenuItem";
		this.vmethod_220().Size = new global::System.Drawing.Size(180, 22);
		this.vmethod_220().Text = "About";
		this.vmethod_20().AspectName = "Name";
		this.vmethod_20().DisplayIndex = 0;
		this.vmethod_20().ImageAspectName = "Img";
		this.vmethod_20().Text = "Name";
		this.vmethod_20().Width = 164;
		this.vmethod_22().AspectName = "Address";
		this.vmethod_22().DisplayIndex = 1;
		this.vmethod_22().Text = "Address";
		this.vmethod_22().Width = 159;
		this.vmethod_90().Interval = 2000;
		this.vmethod_92().Animate = false;
		this.vmethod_92().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_92().IndicatorColor = global::System.Drawing.Color.SkyBlue;
		this.vmethod_92().Location = new global::System.Drawing.Point(617, 187);
		this.vmethod_92().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_92().Name = "pbSplash";
		this.vmethod_92().RefreshRate = 100;
		this.vmethod_92().Size = new global::System.Drawing.Size(100, 100);
		this.vmethod_92().TabIndex = 31;
		this.vmethod_154().WorkerSupportsCancellation = true;
		this.vmethod_214().Enabled = true;
		this.vmethod_214().Interval = 1000;
		this.vmethod_224().WorkerSupportsCancellation = true;
		this.vmethod_268().Name = "UpdateToolStripMenuItem";
		this.vmethod_268().Size = new global::System.Drawing.Size(195, 22);
		this.vmethod_268().Text = "Update";
		this.vmethod_266().Name = "ToolStripMenuItem24";
		this.vmethod_266().Size = new global::System.Drawing.Size(192, 6);
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new global::System.Drawing.Size(1404, 461);
		base.Controls.Add(this.vmethod_92());
		base.Controls.Add(this.vmethod_4());
		base.Controls.Add(this.vmethod_18());
		this.DoubleBuffered = true;
		base.Enabled = false;
		base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
		base.Margin = new global::System.Windows.Forms.Padding(2);
		base.Name = "fMain";
		base.Opacity = 0.0;
		base.ShowInTaskbar = false;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "BitRAT";
		this.vmethod_4().ResumeLayout(false);
		this.vmethod_4().PerformLayout();
		this.vmethod_18().EndInit();
		this.vmethod_44().ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x0400079F RID: 1951
	private global::System.ComponentModel.IContainer icontainer_0;
}
