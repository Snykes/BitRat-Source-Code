﻿using System;
using System.Linq;

namespace BitRAT
{
	// Token: 0x020001DD RID: 477
	public class cDOScli
	{
		// Token: 0x06001A85 RID: 6789 RVA: 0x000BA7EC File Offset: 0x000B89EC
		public cDOScli()
		{
			this.idxValues = new string[13];
			checked
			{
				int num = this.idxValues.Count<string>() - 1;
				for (int i = 1; i <= num; i++)
				{
					this.idxValues[i] = "N/A";
				}
			}
		}

		// Token: 0x1700006C RID: 108
		// (get) Token: 0x06001A86 RID: 6790 RVA: 0x0000D8D8 File Offset: 0x0000BAD8
		// (set) Token: 0x06001A87 RID: 6791 RVA: 0x0000D8E2 File Offset: 0x0000BAE2
		public string USER
		{
			get
			{
				return this.idxValues[0];
			}
			set
			{
				this.idxValues[0] = value;
			}
		}

		// Token: 0x1700006D RID: 109
		// (get) Token: 0x06001A88 RID: 6792 RVA: 0x0000D8ED File Offset: 0x0000BAED
		// (set) Token: 0x06001A89 RID: 6793 RVA: 0x0000D8F7 File Offset: 0x0000BAF7
		public string TARGET_HOST
		{
			get
			{
				return this.idxValues[1];
			}
			set
			{
				this.idxValues[1] = value;
			}
		}

		// Token: 0x1700006E RID: 110
		// (get) Token: 0x06001A8A RID: 6794 RVA: 0x0000D902 File Offset: 0x0000BB02
		// (set) Token: 0x06001A8B RID: 6795 RVA: 0x0000D90C File Offset: 0x0000BB0C
		public string TARGET_PORT
		{
			get
			{
				return this.idxValues[2];
			}
			set
			{
				this.idxValues[2] = value;
			}
		}

		// Token: 0x1700006F RID: 111
		// (get) Token: 0x06001A8C RID: 6796 RVA: 0x0000D917 File Offset: 0x0000BB17
		// (set) Token: 0x06001A8D RID: 6797 RVA: 0x0000D921 File Offset: 0x0000BB21
		public string PROTOCOL
		{
			get
			{
				return this.idxValues[3];
			}
			set
			{
				this.idxValues[3] = value;
			}
		}

		// Token: 0x17000070 RID: 112
		// (get) Token: 0x06001A8E RID: 6798 RVA: 0x0000D92C File Offset: 0x0000BB2C
		// (set) Token: 0x06001A8F RID: 6799 RVA: 0x0000D936 File Offset: 0x0000BB36
		public string METHOD
		{
			get
			{
				return this.idxValues[4];
			}
			set
			{
				this.idxValues[4] = value;
			}
		}

		// Token: 0x17000071 RID: 113
		// (get) Token: 0x06001A90 RID: 6800 RVA: 0x0000D941 File Offset: 0x0000BB41
		// (set) Token: 0x06001A91 RID: 6801 RVA: 0x0000D94B File Offset: 0x0000BB4B
		public string THREADS
		{
			get
			{
				return this.idxValues[5];
			}
			set
			{
				this.idxValues[5] = value;
			}
		}

		// Token: 0x17000072 RID: 114
		// (get) Token: 0x06001A92 RID: 6802 RVA: 0x0000D956 File Offset: 0x0000BB56
		// (set) Token: 0x06001A93 RID: 6803 RVA: 0x0000D960 File Offset: 0x0000BB60
		public string BYTES_SENT
		{
			get
			{
				return this.idxValues[6];
			}
			set
			{
				this.idxValues[6] = value;
			}
		}

		// Token: 0x17000073 RID: 115
		// (get) Token: 0x06001A94 RID: 6804 RVA: 0x0000D96B File Offset: 0x0000BB6B
		// (set) Token: 0x06001A95 RID: 6805 RVA: 0x0000D975 File Offset: 0x0000BB75
		public string SPEED
		{
			get
			{
				return this.idxValues[7];
			}
			set
			{
				this.idxValues[7] = value;
			}
		}

		// Token: 0x17000074 RID: 116
		// (get) Token: 0x06001A96 RID: 6806 RVA: 0x0000D980 File Offset: 0x0000BB80
		// (set) Token: 0x06001A97 RID: 6807 RVA: 0x0000D98A File Offset: 0x0000BB8A
		public string PPS
		{
			get
			{
				return this.idxValues[8];
			}
			set
			{
				this.idxValues[8] = value;
			}
		}

		// Token: 0x17000075 RID: 117
		// (get) Token: 0x06001A98 RID: 6808 RVA: 0x0000D995 File Offset: 0x0000BB95
		// (set) Token: 0x06001A99 RID: 6809 RVA: 0x0000D9A0 File Offset: 0x0000BBA0
		public string INTENSITY
		{
			get
			{
				return this.idxValues[9];
			}
			set
			{
				this.idxValues[9] = value;
			}
		}

		// Token: 0x17000076 RID: 118
		// (get) Token: 0x06001A9A RID: 6810 RVA: 0x0000D9AC File Offset: 0x0000BBAC
		// (set) Token: 0x06001A9B RID: 6811 RVA: 0x0000D9B7 File Offset: 0x0000BBB7
		public string PACKET_SIZE
		{
			get
			{
				return this.idxValues[10];
			}
			set
			{
				this.idxValues[10] = value;
			}
		}

		// Token: 0x17000077 RID: 119
		// (get) Token: 0x06001A9C RID: 6812 RVA: 0x0000D9C3 File Offset: 0x0000BBC3
		// (set) Token: 0x06001A9D RID: 6813 RVA: 0x0000D9CE File Offset: 0x0000BBCE
		public string DURATION
		{
			get
			{
				return this.idxValues[11];
			}
			set
			{
				this.idxValues[11] = value;
			}
		}

		// Token: 0x17000078 RID: 120
		// (get) Token: 0x06001A9E RID: 6814 RVA: 0x0000D9DA File Offset: 0x0000BBDA
		// (set) Token: 0x06001A9F RID: 6815 RVA: 0x0000D9E5 File Offset: 0x0000BBE5
		public string STATUS
		{
			get
			{
				return this.idxValues[12];
			}
			set
			{
				this.idxValues[12] = value;
			}
		}

		// Token: 0x17000079 RID: 121
		// (get) Token: 0x06001AA0 RID: 6816 RVA: 0x0000D9F1 File Offset: 0x0000BBF1
		// (set) Token: 0x06001AA1 RID: 6817 RVA: 0x0000D9F9 File Offset: 0x0000BBF9
		public string Tag
		{
			get
			{
				return this.m_tag;
			}
			set
			{
				this.m_tag = value;
			}
		}

		// Token: 0x04000A15 RID: 2581
		public string[] idxValues;

		// Token: 0x04000A16 RID: 2582
		public string Key;

		// Token: 0x04000A17 RID: 2583
		private string m_tag;

		// Token: 0x04000A18 RID: 2584
		public long speed_bytes;

		// Token: 0x04000A19 RID: 2585
		public long sent_bytes;

		// Token: 0x04000A1A RID: 2586
		public bool bJustConnected;

		// Token: 0x04000A1B RID: 2587
		public bool pending_dc;

		// Token: 0x04000A1C RID: 2588
		public bool pending_dc_timeout;
	}
}
