﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using SkinSoft.VisualStyler;
using SkinSoft.VisualStyler.Licensing;

// Token: 0x020000FC RID: 252
[DesignerGenerated]
public sealed partial class fStartup : Form
{
	// Token: 0x06000D2A RID: 3370 RVA: 0x00007FD3 File Offset: 0x000061D3
	public fStartup()
	{
		base.Load += this.fStartup_Load;
		this.InitializeComponent();
	}

	// Token: 0x06000D2D RID: 3373 RVA: 0x00007FF3 File Offset: 0x000061F3
	public VisualStyler vmethod_0()
	{
		return this.visualStyler_0;
	}

	// Token: 0x06000D2E RID: 3374 RVA: 0x00007FFB File Offset: 0x000061FB
	[MethodImpl(MethodImplOptions.Synchronized)]
	public void vmethod_1(VisualStyler visualStyler_1)
	{
		this.visualStyler_0 = visualStyler_1;
	}

	// Token: 0x06000D2F RID: 3375 RVA: 0x00066644 File Offset: 0x00064844
	[MethodImpl(MethodImplOptions.NoOptimization)]
	private void fStartup_Load(object sender, EventArgs e)
	{
		object[] object_ = new object[]
		{
			this,
			sender,
			e
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O=\"*?;\"!", object_);
	}

	// Token: 0x0400054E RID: 1358
	private VisualStyler visualStyler_0;
}
