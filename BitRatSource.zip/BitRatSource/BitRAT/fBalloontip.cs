﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using BitRAT;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

// Token: 0x0200012A RID: 298
[DesignerGenerated]
public sealed partial class fBalloontip : Form
{
	// Token: 0x06001086 RID: 4230 RVA: 0x000098C2 File Offset: 0x00007AC2
	public fBalloontip()
	{
		base.Load += this.fBalloontip_Load;
		this.InitializeComponent();
	}

	// Token: 0x06001089 RID: 4233 RVA: 0x000098E2 File Offset: 0x00007AE2
	internal PictureBox vmethod_0()
	{
		return this.pictureBox_0;
	}

	// Token: 0x0600108A RID: 4234 RVA: 0x0007BE28 File Offset: 0x0007A028
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_1(PictureBox pictureBox_3)
	{
		EventHandler value = new EventHandler(this.method_2);
		PictureBox pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_0 = pictureBox_3;
		pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x0600108B RID: 4235 RVA: 0x000098EA File Offset: 0x00007AEA
	internal Label vmethod_2()
	{
		return this.label_0;
	}

	// Token: 0x0600108C RID: 4236 RVA: 0x0007BE6C File Offset: 0x0007A06C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_3(Label label_5)
	{
		EventHandler value = new EventHandler(this.method_4);
		Label label = this.label_0;
		if (label != null)
		{
			label.Click -= value;
		}
		this.label_0 = label_5;
		label = this.label_0;
		if (label != null)
		{
			label.Click += value;
		}
	}

	// Token: 0x0600108D RID: 4237 RVA: 0x000098F2 File Offset: 0x00007AF2
	internal PictureBox vmethod_4()
	{
		return this.pictureBox_1;
	}

	// Token: 0x0600108E RID: 4238 RVA: 0x0007BEB0 File Offset: 0x0007A0B0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_5(PictureBox pictureBox_3)
	{
		EventHandler value = new EventHandler(this.method_3);
		PictureBox pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_1 = pictureBox_3;
		pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x0600108F RID: 4239 RVA: 0x000098FA File Offset: 0x00007AFA
	internal Label vmethod_6()
	{
		return this.label_1;
	}

	// Token: 0x06001090 RID: 4240 RVA: 0x0007BEF4 File Offset: 0x0007A0F4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_7(Label label_5)
	{
		EventHandler value = new EventHandler(this.method_13);
		Label label = this.label_1;
		if (label != null)
		{
			label.Click -= value;
		}
		this.label_1 = label_5;
		label = this.label_1;
		if (label != null)
		{
			label.Click += value;
		}
	}

	// Token: 0x06001091 RID: 4241 RVA: 0x00009902 File Offset: 0x00007B02
	internal Label vmethod_8()
	{
		return this.label_2;
	}

	// Token: 0x06001092 RID: 4242 RVA: 0x0007BF38 File Offset: 0x0007A138
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_9(Label label_5)
	{
		EventHandler value = new EventHandler(this.method_5);
		Label label = this.label_2;
		if (label != null)
		{
			label.Click -= value;
		}
		this.label_2 = label_5;
		label = this.label_2;
		if (label != null)
		{
			label.Click += value;
		}
	}

	// Token: 0x06001093 RID: 4243 RVA: 0x0000990A File Offset: 0x00007B0A
	internal Label vmethod_10()
	{
		return this.label_3;
	}

	// Token: 0x06001094 RID: 4244 RVA: 0x0007BF7C File Offset: 0x0007A17C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_11(Label label_5)
	{
		EventHandler value = new EventHandler(this.method_6);
		Label label = this.label_3;
		if (label != null)
		{
			label.Click -= value;
		}
		this.label_3 = label_5;
		label = this.label_3;
		if (label != null)
		{
			label.Click += value;
		}
	}

	// Token: 0x06001095 RID: 4245 RVA: 0x00009912 File Offset: 0x00007B12
	internal PictureBox vmethod_12()
	{
		return this.pictureBox_2;
	}

	// Token: 0x06001096 RID: 4246 RVA: 0x0007BFC0 File Offset: 0x0007A1C0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_13(PictureBox pictureBox_3)
	{
		EventHandler value = new EventHandler(this.method_7);
		PictureBox pictureBox = this.pictureBox_2;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_2 = pictureBox_3;
		pictureBox = this.pictureBox_2;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06001097 RID: 4247 RVA: 0x0000991A File Offset: 0x00007B1A
	internal BackgroundWorker vmethod_14()
	{
		return this.backgroundWorker_0;
	}

	// Token: 0x06001098 RID: 4248 RVA: 0x0007C004 File Offset: 0x0007A204
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_15(BackgroundWorker backgroundWorker_4)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_10);
		BackgroundWorker backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_0 = backgroundWorker_4;
		backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x06001099 RID: 4249 RVA: 0x00009922 File Offset: 0x00007B22
	internal BackgroundWorker vmethod_16()
	{
		return this.backgroundWorker_1;
	}

	// Token: 0x0600109A RID: 4250 RVA: 0x0007C048 File Offset: 0x0007A248
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_17(BackgroundWorker backgroundWorker_4)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_11);
		BackgroundWorker backgroundWorker = this.backgroundWorker_1;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_1 = backgroundWorker_4;
		backgroundWorker = this.backgroundWorker_1;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x0600109B RID: 4251 RVA: 0x0000992A File Offset: 0x00007B2A
	internal BackgroundWorker vmethod_18()
	{
		return this.backgroundWorker_2;
	}

	// Token: 0x0600109C RID: 4252 RVA: 0x0007C08C File Offset: 0x0007A28C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_19(BackgroundWorker backgroundWorker_4)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_14);
		BackgroundWorker backgroundWorker = this.backgroundWorker_2;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_2 = backgroundWorker_4;
		backgroundWorker = this.backgroundWorker_2;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x0600109D RID: 4253 RVA: 0x00009932 File Offset: 0x00007B32
	internal BackgroundWorker vmethod_20()
	{
		return this.backgroundWorker_3;
	}

	// Token: 0x0600109E RID: 4254 RVA: 0x0007C0D0 File Offset: 0x0007A2D0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_21(BackgroundWorker backgroundWorker_4)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_15);
		BackgroundWorker backgroundWorker = this.backgroundWorker_3;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_3 = backgroundWorker_4;
		backgroundWorker = this.backgroundWorker_3;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x0600109F RID: 4255 RVA: 0x0000993A File Offset: 0x00007B3A
	internal Label vmethod_22()
	{
		return this.label_4;
	}

	// Token: 0x060010A0 RID: 4256 RVA: 0x00009942 File Offset: 0x00007B42
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_23(Label label_5)
	{
		this.label_4 = label_5;
	}

	// Token: 0x060010A1 RID: 4257 RVA: 0x0007C114 File Offset: 0x0007A314
	private void method_0()
	{
		base.Visible = true;
		base.Activate();
		checked
		{
			base.Top = Screen.PrimaryScreen.Bounds.Height - this.int_1 - 1;
			base.Left = Screen.PrimaryScreen.Bounds.Width - base.Width;
			this.vmethod_0().Top = 0;
			this.vmethod_0().Left = 0;
			this.vmethod_0().Width = base.Width;
			this.vmethod_0().Height = base.Height;
			this.vmethod_12().Image = this.image_0;
			this.vmethod_2().Text = this.string_1;
			this.vmethod_22().Text = "Host: " + this.string_2;
			this.vmethod_8().Text = "User: " + this.string_3;
			this.vmethod_10().Text = "Window: " + this.string_4;
			this.vmethod_14().RunWorkerAsync();
		}
	}

	// Token: 0x060010A2 RID: 4258 RVA: 0x0007C228 File Offset: 0x0007A428
	public void method_1(string string_5, string string_6, string string_7, string string_8, string string_9, Image image_1)
	{
		this.string_0 = string_5;
		this.string_1 = string_6;
		this.string_2 = string_7;
		this.string_3 = string_8;
		this.string_4 = string_9;
		this.image_0 = image_1;
		this.int_1 = checked(Class145.smethod_0().Screen.Bounds.Height - Class145.smethod_0().Screen.WorkingArea.Height);
		this.method_0();
	}

	// Token: 0x060010A3 RID: 4259 RVA: 0x0000994B File Offset: 0x00007B4B
	private void fBalloontip_Load(object sender, EventArgs e)
	{
		base.Visible = false;
	}

	// Token: 0x060010A4 RID: 4260 RVA: 0x00009954 File Offset: 0x00007B54
	private void method_2(object sender, EventArgs e)
	{
		this.vmethod_20().RunWorkerAsync();
	}

	// Token: 0x060010A5 RID: 4261 RVA: 0x00009954 File Offset: 0x00007B54
	private void method_3(object sender, EventArgs e)
	{
		this.vmethod_20().RunWorkerAsync();
	}

	// Token: 0x060010A6 RID: 4262 RVA: 0x00009954 File Offset: 0x00007B54
	private void method_4(object sender, EventArgs e)
	{
		this.vmethod_20().RunWorkerAsync();
	}

	// Token: 0x060010A7 RID: 4263 RVA: 0x00009954 File Offset: 0x00007B54
	private void method_5(object sender, EventArgs e)
	{
		this.vmethod_20().RunWorkerAsync();
	}

	// Token: 0x060010A8 RID: 4264 RVA: 0x00009954 File Offset: 0x00007B54
	private void method_6(object sender, EventArgs e)
	{
		this.vmethod_20().RunWorkerAsync();
	}

	// Token: 0x060010A9 RID: 4265 RVA: 0x00009954 File Offset: 0x00007B54
	private void method_7(object sender, EventArgs e)
	{
		this.vmethod_20().RunWorkerAsync();
	}

	// Token: 0x060010AA RID: 4266 RVA: 0x0007C2A0 File Offset: 0x0007A4A0
	public void method_8(int int_2)
	{
		if (base.InvokeRequired)
		{
			base.Invoke(new fBalloontip.Delegate87(this.method_8), new object[]
			{
				int_2
			});
			return;
		}
		base.Opacity = Conversion.Val((double)this.int_0 / 100.0);
	}

	// Token: 0x060010AB RID: 4267 RVA: 0x00009961 File Offset: 0x00007B61
	public void method_9(int int_2)
	{
		if (base.InvokeRequired)
		{
			base.Invoke(new fBalloontip.Delegate86(this.method_9), new object[]
			{
				int_2
			});
			return;
		}
		checked
		{
			base.Top -= int_2;
		}
	}

	// Token: 0x060010AC RID: 4268 RVA: 0x0007C2FC File Offset: 0x0007A4FC
	private void method_10(object sender, DoWorkEventArgs e)
	{
		Thread.Sleep(3000);
		this.vmethod_16().RunWorkerAsync();
		this.int_0 = 0;
		while (this.int_0 < 100)
		{
			ref int ptr = ref this.int_0;
			this.int_0 = checked(ptr + 1);
			this.method_8(this.int_0);
			Thread.Sleep(1);
		}
		this.vmethod_18().RunWorkerAsync();
	}

	// Token: 0x060010AD RID: 4269 RVA: 0x0007C35C File Offset: 0x0007A55C
	private void method_11(object sender, DoWorkEventArgs e)
	{
		int height = base.Height;
		checked
		{
			for (int i = 1; i <= height; i++)
			{
				this.method_9(1);
				Thread.Sleep(1);
			}
		}
	}

	// Token: 0x060010AE RID: 4270 RVA: 0x0000999C File Offset: 0x00007B9C
	public void method_12()
	{
		if (base.InvokeRequired)
		{
			base.Invoke(new fBalloontip.Delegate85(this.method_12), new object[0]);
			return;
		}
		base.Close();
	}

	// Token: 0x060010AF RID: 4271 RVA: 0x0007C38C File Offset: 0x0007A58C
	private void method_13(object sender, EventArgs e)
	{
		base.Visible = false;
		CClient cclient3;
		CClient cclient2;
		CClient cclient = cclient2 = (cclient3 = Class130.concurrentDictionary_3[this.string_0]);
		checked
		{
			if (cclient2.fDB == null)
			{
				cclient2.fDB = new fDashboard();
				cclient2.fDB.method_1(ref cclient2.sock_async, ref cclient2.sIP, ref cclient2.sPort, ref cclient2.sLANIP, ref cclient2.sUser, ref cclient2.sSettingPassword);
				cclient2.fDB.Show();
				Form fDB = cclient2.fDB;
				Form fMain_ = Class130.fMain_0;
				bool flag = false;
				Form form = fMain_;
				Form form2 = fDB;
				CClient cclient4 = cclient;
				Rectangle rectangle;
				if (form != null)
				{
					rectangle = form.RectangleToScreen(form.ClientRectangle);
				}
				else
				{
					rectangle = Screen.FromPoint(form2.Location).WorkingArea;
				}
				int x = rectangle.Left + (rectangle.Width - form2.Width) / 2;
				int y = rectangle.Top + (rectangle.Height - form2.Height) / 2;
				form2.Location = new Point(x, y);
				if (flag)
				{
					form2.Visible = true;
				}
				cclient3 = cclient4;
			}
			else if (!cclient2.fDB.Visible)
			{
				cclient2.fDB.method_147();
				Form fDB2 = cclient2.fDB;
				Form fMain_2 = Class130.fMain_0;
				bool flag = false;
				Form form = fMain_2;
				Form form2 = fDB2;
				CClient cclient5 = cclient;
				Rectangle rectangle;
				if (form != null)
				{
					rectangle = form.RectangleToScreen(form.ClientRectangle);
				}
				else
				{
					rectangle = Screen.FromPoint(form2.Location).WorkingArea;
				}
				int x = rectangle.Left + (rectangle.Width - form2.Width) / 2;
				int y = rectangle.Top + (rectangle.Height - form2.Height) / 2;
				form2.Location = new Point(x, y);
				if (flag)
				{
					form2.Visible = true;
				}
				cclient3 = cclient5;
			}
			cclient3.fDB.Activate();
		}
	}

	// Token: 0x060010B0 RID: 4272 RVA: 0x0007C538 File Offset: 0x0007A738
	private void method_14(object sender, DoWorkEventArgs e)
	{
		Thread.Sleep(5000);
		checked
		{
			int num = this.int_1 + base.Height;
			for (int i = 1; i <= num; i++)
			{
				this.method_9(-1);
				Thread.Sleep(1);
			}
			this.method_12();
		}
	}

	// Token: 0x060010B1 RID: 4273 RVA: 0x0007C57C File Offset: 0x0007A77C
	private void method_15(object sender, DoWorkEventArgs e)
	{
		checked
		{
			int num = this.int_1 + base.Height;
			for (int i = 1; i <= num; i++)
			{
				this.method_9(-1);
				Thread.Sleep(1);
			}
			this.method_12();
		}
	}

	// Token: 0x0400068C RID: 1676
	private PictureBox pictureBox_0;

	// Token: 0x0400068D RID: 1677
	private Label label_0;

	// Token: 0x0400068E RID: 1678
	private PictureBox pictureBox_1;

	// Token: 0x0400068F RID: 1679
	private Label label_1;

	// Token: 0x04000690 RID: 1680
	private Label label_2;

	// Token: 0x04000691 RID: 1681
	private Label label_3;

	// Token: 0x04000692 RID: 1682
	private PictureBox pictureBox_2;

	// Token: 0x04000693 RID: 1683
	private BackgroundWorker backgroundWorker_0;

	// Token: 0x04000694 RID: 1684
	private BackgroundWorker backgroundWorker_1;

	// Token: 0x04000695 RID: 1685
	private BackgroundWorker backgroundWorker_2;

	// Token: 0x04000696 RID: 1686
	private BackgroundWorker backgroundWorker_3;

	// Token: 0x04000697 RID: 1687
	private Label label_4;

	// Token: 0x04000698 RID: 1688
	private string string_0;

	// Token: 0x04000699 RID: 1689
	private string string_1;

	// Token: 0x0400069A RID: 1690
	private string string_2;

	// Token: 0x0400069B RID: 1691
	private string string_3;

	// Token: 0x0400069C RID: 1692
	private string string_4;

	// Token: 0x0400069D RID: 1693
	private Image image_0;

	// Token: 0x0400069E RID: 1694
	private int int_0;

	// Token: 0x0400069F RID: 1695
	private int int_1;

	// Token: 0x040006A0 RID: 1696
	private CClient cclient_0;

	// Token: 0x0200012B RID: 299
	// (Invoke) Token: 0x060010B5 RID: 4277
	private delegate void Delegate85();

	// Token: 0x0200012C RID: 300
	// (Invoke) Token: 0x060010B9 RID: 4281
	private delegate void Delegate86(int int_0);

	// Token: 0x0200012D RID: 301
	// (Invoke) Token: 0x060010BD RID: 4285
	private delegate void Delegate87(int int_0);
}
