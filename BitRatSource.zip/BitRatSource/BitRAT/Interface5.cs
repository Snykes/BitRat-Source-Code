﻿using System;

// Token: 0x0200005E RID: 94
internal interface Interface5
{
	// Token: 0x06000344 RID: 836
	bool imethod_2();

	// Token: 0x06000345 RID: 837
	object imethod_0();

	// Token: 0x06000346 RID: 838
	void imethod_1();
}
