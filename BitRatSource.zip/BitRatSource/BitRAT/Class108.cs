﻿using System;

// Token: 0x02000054 RID: 84
internal sealed class Class108 : Class106
{
	// Token: 0x06000321 RID: 801 RVA: 0x0000419F File Offset: 0x0000239F
	public int method_2()
	{
		return this.int_0;
	}

	// Token: 0x06000322 RID: 802 RVA: 0x000041A7 File Offset: 0x000023A7
	public void method_3(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x06000323 RID: 803 RVA: 0x000041B0 File Offset: 0x000023B0
	public override int vmethod_2()
	{
		return 13;
	}

	// Token: 0x06000324 RID: 804 RVA: 0x0001F638 File Offset: 0x0001D838
	public override Class94 vmethod_3(Class94 class94_0)
	{
		base.method_1(class94_0.method_0());
		int num = class94_0.vmethod_2();
		if (num == 13)
		{
			this.method_3(((Class108)class94_0).method_2());
			return this;
		}
		throw new ArgumentOutOfRangeException();
	}

	// Token: 0x06000325 RID: 805 RVA: 0x000041B4 File Offset: 0x000023B4
	public override Class94 vmethod_4()
	{
		Class108 @class = new Class108();
		@class.method_3(this.int_0);
		@class.method_1(base.method_0());
		return @class;
	}

	// Token: 0x04000192 RID: 402
	private int int_0;
}
