﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;

// Token: 0x02000022 RID: 34
internal sealed class Class20<T> : IEnumerable<T>, IEnumerable, ICollection
{
	// Token: 0x06000201 RID: 513 RVA: 0x0000399F File Offset: 0x00001B9F
	public Class20()
	{
		this.gparam_0 = Class71<T>.gparam_0;
		this.int_0 = 0;
		this.int_1 = 0;
	}

	// Token: 0x06000202 RID: 514 RVA: 0x000039C0 File Offset: 0x00001BC0
	public Class20(int int_2)
	{
		if (int_2 < 0)
		{
			throw new ArgumentOutOfRangeException();
		}
		this.gparam_0 = new T[int_2];
		this.int_0 = 0;
		this.int_1 = 0;
	}

	// Token: 0x06000203 RID: 515 RVA: 0x0001BDCC File Offset: 0x00019FCC
	public Class20(IEnumerable<T> ienumerable_0)
	{
		if (ienumerable_0 == null)
		{
			throw new ArgumentNullException();
		}
		ICollection<T> collection = ienumerable_0 as ICollection<T>;
		if (collection != null)
		{
			int count = collection.Count;
			this.gparam_0 = new T[count];
			collection.CopyTo(this.gparam_0, 0);
			this.int_0 = count;
			return;
		}
		this.int_0 = 0;
		this.gparam_0 = new T[4];
		foreach (T gparam_ in ienumerable_0)
		{
			this.method_7(gparam_);
		}
	}

	// Token: 0x17000001 RID: 1
	// (get) Token: 0x06000204 RID: 516 RVA: 0x000039EC File Offset: 0x00001BEC
	public int Count
	{
		get
		{
			return this.int_0;
		}
	}

	// Token: 0x170000AF RID: 175
	// (get) Token: 0x06000205 RID: 517 RVA: 0x00002E1C File Offset: 0x0000101C
	bool ICollection.IsSynchronized
	{
		get
		{
			return false;
		}
	}

	// Token: 0x170000B0 RID: 176
	// (get) Token: 0x06000206 RID: 518 RVA: 0x000039F4 File Offset: 0x00001BF4
	object ICollection.SyncRoot
	{
		get
		{
			if (this.object_0 == null)
			{
				Interlocked.CompareExchange(ref this.object_0, new object(), null);
			}
			return this.object_0;
		}
	}

	// Token: 0x06000207 RID: 519 RVA: 0x00003A16 File Offset: 0x00001C16
	public void method_0()
	{
		Array.Clear(this.gparam_0, 0, this.int_0);
		this.int_0 = 0;
		this.int_1++;
	}

	// Token: 0x06000208 RID: 520 RVA: 0x0001BE68 File Offset: 0x0001A068
	public bool method_1(T gparam_1)
	{
		int num = this.int_0;
		EqualityComparer<T> @default = EqualityComparer<T>.Default;
		while (num-- > 0)
		{
			if (gparam_1 == null)
			{
				if (this.gparam_0[num] == null)
				{
					return true;
				}
			}
			else if (this.gparam_0[num] != null && @default.Equals(this.gparam_0[num], gparam_1))
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x06000209 RID: 521 RVA: 0x0001BED8 File Offset: 0x0001A0D8
	public void method_2(T[] gparam_1, int int_2)
	{
		if (gparam_1 == null)
		{
			throw new ArgumentNullException("#=z5jI7l7s=");
		}
		if (int_2 < 0 || int_2 > gparam_1.Length)
		{
			throw new ArgumentOutOfRangeException("#=zBBshIlI=", "arrayIndex < 0 || arrayIndex > array.Length");
		}
		if (gparam_1.Length - int_2 < this.int_0)
		{
			throw new ArgumentException("Invalid Off Len");
		}
		Array.Copy(this.gparam_0, 0, gparam_1, int_2, this.int_0);
		Array.Reverse(gparam_1, int_2, this.int_0);
	}

	// Token: 0x0600020A RID: 522 RVA: 0x0001BF48 File Offset: 0x0001A148
	void ICollection.CopyTo(Array array, int index)
	{
		if (array == null)
		{
			throw new ArgumentNullException();
		}
		if (array.Rank != 1)
		{
			throw new ArgumentException();
		}
		if (array.GetLowerBound(0) != 0)
		{
			throw new ArgumentException();
		}
		if (index >= 0 && index <= array.Length)
		{
			if (array.Length - index < this.int_0)
			{
				throw new ArgumentException();
			}
			try
			{
				Array.Copy(this.gparam_0, 0, array, index, this.int_0);
				Array.Reverse(array, index, this.int_0);
				return;
			}
			catch (ArrayTypeMismatchException)
			{
				throw new ArgumentException();
			}
		}
		throw new ArgumentOutOfRangeException();
	}

	// Token: 0x0600020B RID: 523 RVA: 0x00003A3F File Offset: 0x00001C3F
	public Class20<T>.Struct4 method_3()
	{
		return new Class20<T>.Struct4(this);
	}

	// Token: 0x0600020C RID: 524 RVA: 0x00003A47 File Offset: 0x00001C47
	IEnumerator<T> IEnumerable<!0>.GetEnumerator()
	{
		return new Class20<T>.Struct4(this);
	}

	// Token: 0x0600020D RID: 525 RVA: 0x00003A47 File Offset: 0x00001C47
	IEnumerator IEnumerable.GetEnumerator()
	{
		return new Class20<T>.Struct4(this);
	}

	// Token: 0x0600020E RID: 526 RVA: 0x0001BFE0 File Offset: 0x0001A1E0
	public void method_4()
	{
		int num = (int)((double)this.gparam_0.Length * 0.9);
		if (this.int_0 < num)
		{
			T[] destinationArray = new T[this.int_0];
			Array.Copy(this.gparam_0, 0, destinationArray, 0, this.int_0);
			this.gparam_0 = destinationArray;
			this.int_1++;
		}
	}

	// Token: 0x0600020F RID: 527 RVA: 0x00003A54 File Offset: 0x00001C54
	public T method_5()
	{
		if (this.int_0 == 0)
		{
			throw new InvalidOperationException();
		}
		return this.gparam_0[this.int_0 - 1];
	}

	// Token: 0x06000210 RID: 528 RVA: 0x0001C040 File Offset: 0x0001A240
	public T method_6()
	{
		if (this.int_0 == 0)
		{
			throw new InvalidOperationException();
		}
		this.int_1++;
		T[] array = this.gparam_0;
		int num = this.int_0 - 1;
		this.int_0 = num;
		T result = array[num];
		this.gparam_0[this.int_0] = default(T);
		return result;
	}

	// Token: 0x06000211 RID: 529 RVA: 0x0001C0A0 File Offset: 0x0001A2A0
	public void method_7(T gparam_1)
	{
		if (this.int_0 == this.gparam_0.Length)
		{
			T[] destinationArray = new T[(this.gparam_0.Length == 0) ? 4 : (2 * this.gparam_0.Length)];
			Array.Copy(this.gparam_0, 0, destinationArray, 0, this.int_0);
			this.gparam_0 = destinationArray;
		}
		T[] array = this.gparam_0;
		int num = this.int_0;
		this.int_0 = num + 1;
		array[num] = gparam_1;
		this.int_1++;
	}

	// Token: 0x06000212 RID: 530 RVA: 0x0001C120 File Offset: 0x0001A320
	public T[] method_8()
	{
		T[] array = new T[this.int_0];
		for (int i = 0; i < this.int_0; i++)
		{
			array[i] = this.gparam_0[this.int_0 - i - 1];
		}
		return array;
	}

	// Token: 0x04000134 RID: 308
	private T[] gparam_0;

	// Token: 0x04000135 RID: 309
	private int int_0;

	// Token: 0x04000136 RID: 310
	private int int_1;

	// Token: 0x04000137 RID: 311
	private object object_0;

	// Token: 0x02000023 RID: 35
	public struct Struct4 : IEnumerator<T>, IDisposable, IEnumerator
	{
		// Token: 0x06000213 RID: 531 RVA: 0x00003A77 File Offset: 0x00001C77
		internal Struct4(Class20<T> class20_1)
		{
			this.class20_0 = class20_1;
			this.int_1 = this.class20_0.int_1;
			this.int_0 = -2;
			this.gparam_0 = default(T);
		}

		// Token: 0x06000214 RID: 532 RVA: 0x00003AA5 File Offset: 0x00001CA5
		public void Dispose()
		{
			this.int_0 = -1;
		}

		// Token: 0x06000215 RID: 533 RVA: 0x0001C168 File Offset: 0x0001A368
		public bool MoveNext()
		{
			if (this.int_1 != this.class20_0.int_1)
			{
				throw new InvalidOperationException("EnumFailedVersion");
			}
			if (this.int_0 == -2)
			{
				this.int_0 = this.class20_0.int_0 - 1;
				bool flag = this.int_0 >= 0;
				if (flag)
				{
					this.gparam_0 = this.class20_0.gparam_0[this.int_0];
				}
				return flag;
			}
			if (this.int_0 == -1)
			{
				return false;
			}
			int num = this.int_0 - 1;
			this.int_0 = num;
			bool flag2 = num >= 0;
			if (flag2)
			{
				this.gparam_0 = this.class20_0.gparam_0[this.int_0];
				return flag2;
			}
			this.gparam_0 = default(T);
			return flag2;
		}

		// Token: 0x17000002 RID: 2
		// (get) Token: 0x06000216 RID: 534 RVA: 0x00003AAE File Offset: 0x00001CAE
		public T Current
		{
			get
			{
				if (this.int_0 == -2)
				{
					throw new InvalidOperationException();
				}
				if (this.int_0 == -1)
				{
					throw new InvalidOperationException();
				}
				return this.gparam_0;
			}
		}

		// Token: 0x170000B1 RID: 177
		// (get) Token: 0x06000217 RID: 535 RVA: 0x00003AD5 File Offset: 0x00001CD5
		object IEnumerator.Current
		{
			get
			{
				if (this.int_0 == -2)
				{
					throw new InvalidOperationException();
				}
				if (this.int_0 == -1)
				{
					throw new InvalidOperationException();
				}
				return this.gparam_0;
			}
		}

		// Token: 0x06000218 RID: 536 RVA: 0x00003B01 File Offset: 0x00001D01
		void IEnumerator.Reset()
		{
			if (this.int_1 != this.class20_0.int_1)
			{
				throw new InvalidOperationException();
			}
			this.int_0 = -2;
			this.gparam_0 = default(T);
		}

		// Token: 0x04000138 RID: 312
		private Class20<T> class20_0;

		// Token: 0x04000139 RID: 313
		private int int_0;

		// Token: 0x0400013A RID: 314
		private int int_1;

		// Token: 0x0400013B RID: 315
		private T gparam_0;
	}
}
