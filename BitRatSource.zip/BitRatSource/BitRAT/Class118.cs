﻿using System;

// Token: 0x0200008E RID: 142
internal sealed class Class118 : Class94
{
	// Token: 0x06000454 RID: 1108 RVA: 0x00004B98 File Offset: 0x00002D98
	public int method_2()
	{
		return this.int_0;
	}

	// Token: 0x06000455 RID: 1109 RVA: 0x00004BA0 File Offset: 0x00002DA0
	public void method_3(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x06000456 RID: 1110 RVA: 0x00004BA9 File Offset: 0x00002DA9
	public override object vmethod_0()
	{
		return this.method_2();
	}

	// Token: 0x06000457 RID: 1111 RVA: 0x00022108 File Offset: 0x00020308
	public override void vmethod_1(object object_0)
	{
		if (object_0 is long)
		{
			this.method_3((int)((long)object_0));
			return;
		}
		if (object_0 is ushort)
		{
			this.method_3((int)((ushort)object_0));
			return;
		}
		if (object_0 is uint)
		{
			this.method_3((int)((uint)object_0));
			return;
		}
		if (object_0 is ulong)
		{
			this.method_3((int)((ulong)object_0));
			return;
		}
		if (object_0 is float)
		{
			this.method_3((int)((float)object_0));
			return;
		}
		if (object_0 is double)
		{
			this.method_3((int)((double)object_0));
			return;
		}
		this.method_3(Convert.ToInt32(object_0));
	}

	// Token: 0x06000458 RID: 1112 RVA: 0x00004BB6 File Offset: 0x00002DB6
	public override Class94 vmethod_4()
	{
		Class118 @class = new Class118();
		@class.method_3(this.int_0);
		@class.method_1(base.method_0());
		return @class;
	}

	// Token: 0x06000459 RID: 1113 RVA: 0x00004BD5 File Offset: 0x00002DD5
	public override int vmethod_2()
	{
		return 7;
	}

	// Token: 0x0600045A RID: 1114 RVA: 0x000221A4 File Offset: 0x000203A4
	public override Class94 vmethod_3(Class94 class94_0)
	{
		base.method_1(class94_0.method_0());
		switch (class94_0.vmethod_2())
		{
		case 0:
			this.method_3((int)((Class119)class94_0).method_2());
			return this;
		case 2:
			this.method_3((int)Convert.ToByte(((Class103)class94_0).method_2()));
			return this;
		case 4:
			this.method_3(Convert.ToInt32(((Class102)class94_0).method_2()));
			return this;
		case 7:
			this.method_3(((Class118)class94_0).method_2());
			return this;
		case 8:
			this.method_3((int)((uint)((Class100)class94_0).method_2()));
			return this;
		case 9:
			this.method_3((int)((Class115)class94_0).method_2());
			return this;
		case 10:
			this.method_3((int)((Class114)class94_0).method_2());
			return this;
		case 11:
			this.method_3(Convert.ToInt32(((Class99)class94_0).method_2()));
			return this;
		case 14:
			this.method_3((int)((Class105)class94_0).method_2());
			return this;
		case 15:
			this.method_3((int)((Class101)class94_0).method_2());
			return this;
		case 17:
			this.method_3((int)((Class117)class94_0).method_2());
			return this;
		case 19:
			this.method_3((int)((Class120)class94_0).method_2());
			return this;
		case 21:
			this.method_3((int)((Class104)class94_0).method_2());
			return this;
		case 22:
			this.method_3((int)((Class121)class94_0).method_2());
			return this;
		case 24:
			this.method_3(Convert.ToInt32(((Class98)class94_0).method_2()));
			return this;
		}
		throw new ArgumentOutOfRangeException();
	}

	// Token: 0x040001D6 RID: 470
	private int int_0;
}
