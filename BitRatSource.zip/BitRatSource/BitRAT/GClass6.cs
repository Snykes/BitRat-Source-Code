﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

// Token: 0x0200015C RID: 348
public sealed class GClass6
{
	// Token: 0x0600133F RID: 4927 RVA: 0x0000A896 File Offset: 0x00008A96
	public GClass6(string string_1)
	{
		this.byte_0 = new byte[48];
		this.string_0 = string_1;
	}

	// Token: 0x06001340 RID: 4928 RVA: 0x00088F40 File Offset: 0x00087140
	public GEnum1 method_0()
	{
		GEnum1 result;
		switch ((byte)((uint)this.byte_0[0] >> 6))
		{
		case 0:
			result = (GEnum1)0;
			break;
		case 1:
			result = (GEnum1)1;
			break;
		case 2:
			result = (GEnum1)2;
			break;
		case 3:
			result = (GEnum1)3;
			break;
		default:
			result = (GEnum1)3;
			break;
		}
		return result;
	}

	// Token: 0x06001341 RID: 4929 RVA: 0x0000A8B2 File Offset: 0x00008AB2
	public byte method_1()
	{
		return checked((byte)((this.byte_0[0] & 56) >> 3));
	}

	// Token: 0x06001342 RID: 4930 RVA: 0x00088F84 File Offset: 0x00087184
	public object method_2()
	{
		object result;
		switch (this.byte_0[0] & 7)
		{
		case 0:
		case 6:
		case 7:
			result = GEnum0.Unknown;
			break;
		case 1:
			result = GEnum0.SymmetricActive;
			break;
		case 2:
			result = GEnum0.SymmetricPassive;
			break;
		case 3:
			result = GEnum0.Client;
			break;
		case 4:
			result = GEnum0.Server;
			break;
		case 5:
			result = GEnum0.Broadcast;
			break;
		}
		return result;
	}

	// Token: 0x06001343 RID: 4931 RVA: 0x00088FFC File Offset: 0x000871FC
	public GEnum2 method_3()
	{
		byte b = this.byte_0[1];
		GEnum2 result;
		if (b == 0)
		{
			result = (GEnum2)0;
		}
		else if (b == 1)
		{
			result = (GEnum2)1;
		}
		else if (b <= 15)
		{
			result = (GEnum2)2;
		}
		else
		{
			result = (GEnum2)3;
		}
		return result;
	}

	// Token: 0x06001344 RID: 4932 RVA: 0x0000A8C2 File Offset: 0x00008AC2
	public int method_4()
	{
		return checked((int)Math.Round(Math.Pow(2.0, (double)this.byte_0[2])));
	}

	// Token: 0x06001345 RID: 4933 RVA: 0x0000A8E1 File Offset: 0x00008AE1
	public double method_5()
	{
		return Math.Pow(2.0, (double)this.byte_0[3]);
	}

	// Token: 0x06001346 RID: 4934 RVA: 0x00089030 File Offset: 0x00087230
	public double method_6()
	{
		long num = (long)(checked(256 * (256 * (256 * (int)this.byte_0[4] + (int)this.byte_0[5]) + (int)this.byte_0[6]) + (int)this.byte_0[7]));
		return 1000.0 * ((double)num / 65536.0);
	}

	// Token: 0x06001347 RID: 4935 RVA: 0x00089094 File Offset: 0x00087294
	public double method_7()
	{
		long num = (long)(checked(256 * (256 * (256 * (int)this.byte_0[8] + (int)this.byte_0[9]) + (int)this.byte_0[10]) + (int)this.byte_0[11]));
		return 1000.0 * ((double)num / 65536.0);
	}

	// Token: 0x06001348 RID: 4936 RVA: 0x000890FC File Offset: 0x000872FC
	public string method_8()
	{
		string text = string.Empty;
		GEnum2 genum = this.method_3();
		if (genum != (GEnum2)1)
		{
			if (genum != (GEnum2)2)
			{
				return text;
			}
			byte b = this.method_1();
			if (b != 3)
			{
				if (b != 4)
				{
					return "N/A";
				}
				DateTime dateTime = this.method_16(this.method_17(12));
				TimeSpan utcOffset = TimeZone.CurrentTimeZone.GetUtcOffset(DateTime.Now);
				return dateTime.Add(utcOffset).ToString();
			}
			else
			{
				string text2 = string.Concat(new string[]
				{
					this.byte_0[12].ToString(),
					".",
					this.byte_0[13].ToString(),
					".",
					this.byte_0[14].ToString(),
					".",
					this.byte_0[15].ToString()
				});
				try
				{
					return Dns.GetHostByAddress(text2).HostName + " (" + text2 + ")";
				}
				catch (Exception ex)
				{
					return "N/A";
				}
			}
		}
		if (this.byte_0[12] != 0)
		{
			text += Conversions.ToString(Strings.Chr((int)this.byte_0[12]));
		}
		if (this.byte_0[13] != 0)
		{
			text += Conversions.ToString(Strings.Chr((int)this.byte_0[13]));
		}
		if (this.byte_0[14] != 0)
		{
			text += Conversions.ToString(Strings.Chr((int)this.byte_0[14]));
		}
		if (this.byte_0[15] != 0)
		{
			text += Conversions.ToString(Strings.Chr((int)this.byte_0[15]));
		}
		return text;
	}

	// Token: 0x06001349 RID: 4937 RVA: 0x000892D0 File Offset: 0x000874D0
	public DateTime method_9()
	{
		DateTime dateTime = this.method_16(this.method_17(16));
		TimeSpan utcOffset = TimeZone.CurrentTimeZone.GetUtcOffset(DateTime.Now);
		return dateTime.Add(utcOffset);
	}

	// Token: 0x0600134A RID: 4938 RVA: 0x0000A8FA File Offset: 0x00008AFA
	public DateTime method_10()
	{
		return this.method_16(this.method_17(24));
	}

	// Token: 0x0600134B RID: 4939 RVA: 0x00089304 File Offset: 0x00087504
	public DateTime method_11()
	{
		DateTime dateTime = this.method_16(this.method_17(32));
		TimeSpan utcOffset = TimeZone.CurrentTimeZone.GetUtcOffset(DateTime.Now);
		return dateTime.Add(utcOffset);
	}

	// Token: 0x0600134C RID: 4940 RVA: 0x00089338 File Offset: 0x00087538
	public DateTime method_12()
	{
		DateTime dateTime = this.method_16(this.method_17(40));
		TimeSpan utcOffset = TimeZone.CurrentTimeZone.GetUtcOffset(DateTime.Now);
		return dateTime.Add(utcOffset);
	}

	// Token: 0x0600134D RID: 4941 RVA: 0x0000A90A File Offset: 0x00008B0A
	public void method_13(DateTime dateTime_1)
	{
		this.method_18(40, dateTime_1);
	}

	// Token: 0x0600134E RID: 4942 RVA: 0x0008936C File Offset: 0x0008756C
	public long method_14()
	{
		return checked((long)Math.Round(this.dateTime_0.Subtract(this.method_10()).Subtract(this.method_11().Subtract(this.method_12())).TotalMilliseconds));
	}

	// Token: 0x0600134F RID: 4943 RVA: 0x000893B4 File Offset: 0x000875B4
	public long method_15()
	{
		return checked((long)Math.Round(this.method_11().Subtract(this.method_10()).Add(this.method_12().Subtract(this.dateTime_0)).TotalMilliseconds / 2.0));
	}

	// Token: 0x06001350 RID: 4944 RVA: 0x0008940C File Offset: 0x0008760C
	private DateTime method_16(decimal decimal_0)
	{
		TimeSpan value = TimeSpan.FromMilliseconds(Convert.ToDouble(decimal_0));
		DateTime result = new DateTime(1900, 1, 1);
		result = result.Add(value);
		return result;
	}

	// Token: 0x06001351 RID: 4945 RVA: 0x00089440 File Offset: 0x00087640
	private decimal method_17(byte byte_1)
	{
		decimal num = 0m;
		decimal num2 = 0m;
		int num3 = 0;
		checked
		{
			do
			{
				num = Conversion.Int(decimal.Add(decimal.Multiply(256m, num), new decimal((int)this.byte_0[(int)byte_1 + num3])));
				num3++;
			}
			while (num3 <= 3);
			num3 = 4;
			do
			{
				num2 = Conversion.Int(decimal.Add(decimal.Multiply(256m, num2), new decimal((int)this.byte_0[(int)byte_1 + num3])));
				num3++;
			}
			while (num3 <= 7);
			return Conversion.Int(decimal.Add(decimal.Multiply(num, 1000m), decimal.Divide(decimal.Multiply(num2, 1000m), 4294967296m)));
		}
	}

	// Token: 0x06001352 RID: 4946 RVA: 0x00089510 File Offset: 0x00087710
	private void method_18(byte byte_1, DateTime dateTime_1)
	{
		decimal num = 0m;
		decimal number = 0m;
		DateTime value = new DateTime(1900, 1, 1, 0, 0, 0);
		decimal d = new decimal(Conversion.Int(dateTime_1.Subtract(value).TotalMilliseconds));
		num = Conversion.Int(decimal.Divide(d, 1000m));
		number = Conversion.Int(decimal.Divide(decimal.Multiply(decimal.Remainder(d, 1000m), 4294967296m), 1000m));
		decimal d2 = num;
		decimal num2 = 3m;
		while (decimal.Compare(num2, 0m) >= 0)
		{
			this.byte_0[Convert.ToInt32(decimal.Add(new decimal((int)byte_1), num2))] = Convert.ToByte(Conversion.Int(decimal.Remainder(d2, 256m)));
			d2 = Conversion.Int(decimal.Divide(d2, 256m));
			num2 = decimal.Add(num2, -1m);
		}
		d2 = Conversion.Int(number);
		decimal num3 = 7m;
		decimal d3 = 4m;
		num2 = num3;
		while (decimal.Compare(num2, d3) >= 0)
		{
			this.byte_0[Convert.ToInt32(decimal.Add(new decimal((int)byte_1), num2))] = Convert.ToByte(Conversion.Int(decimal.Remainder(d2, 256m)));
			d2 = Conversion.Int(decimal.Divide(d2, 256m));
			num2 = decimal.Add(num2, -1m);
		}
	}

	// Token: 0x06001353 RID: 4947 RVA: 0x000896BC File Offset: 0x000878BC
	private void method_19()
	{
		this.byte_0[0] = 27;
		int num = 1;
		checked
		{
			do
			{
				this.byte_0[num] = 0;
				num++;
			}
			while (num <= 47);
			this.method_13(DateTime.Now);
		}
	}

	// Token: 0x06001354 RID: 4948 RVA: 0x000896F4 File Offset: 0x000878F4
	public bool method_20(bool bool_0)
	{
		try
		{
			IPHostEntry iphostEntry = Dns.Resolve(this.string_0);
			IPEndPoint endPoint = new IPEndPoint(iphostEntry.AddressList[0], 123);
			UdpClient udpClient = new UdpClient();
			udpClient.Connect(endPoint);
			udpClient.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReceiveTimeout, 3000);
			this.method_19();
			udpClient.Send(this.byte_0, this.byte_0.Length);
			this.byte_0 = udpClient.Receive(ref endPoint);
			if (!this.method_21())
			{
				throw new Exception("Invalid response from " + this.string_0);
			}
			this.dateTime_0 = DateTime.Now;
		}
		catch (SocketException ex)
		{
			return false;
		}
		if (bool_0)
		{
			this.method_22();
		}
		return true;
	}

	// Token: 0x06001355 RID: 4949 RVA: 0x000897C4 File Offset: 0x000879C4
	public bool method_21()
	{
		return !Conversions.ToBoolean(Operators.OrObject(this.byte_0.Length < 47, Operators.CompareObjectNotEqual(this.method_2(), GEnum0.Server, true)));
	}

	// Token: 0x06001356 RID: 4950 RVA: 0x00089808 File Offset: 0x00087A08
	[Obsolete]
	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder("Leap Indicator: ");
		switch (this.method_0())
		{
		case (GEnum1)0:
			stringBuilder.Append("No warning");
			break;
		case (GEnum1)1:
			stringBuilder.Append("Last minute has 61 seconds");
			break;
		case (GEnum1)2:
			stringBuilder.Append("Last minute has 59 seconds");
			break;
		case (GEnum1)3:
			stringBuilder.Append("Alarm Condition (clock not synchronized)");
			break;
		}
		stringBuilder.Append("\r\nVersion number: " + this.method_1().ToString());
		stringBuilder.Append("\r\nMode: ");
		object left = this.method_2();
		if (Operators.ConditionalCompareObjectEqual(left, GEnum0.Unknown, true))
		{
			stringBuilder.Append("Unknown");
		}
		else if (Operators.ConditionalCompareObjectEqual(left, GEnum0.SymmetricActive, true))
		{
			stringBuilder.Append("Symmetric Active");
		}
		else if (Operators.ConditionalCompareObjectEqual(left, GEnum0.SymmetricPassive, true))
		{
			stringBuilder.Append("Symmetric Pasive");
		}
		else if (Operators.ConditionalCompareObjectEqual(left, GEnum0.Client, true))
		{
			stringBuilder.Append("Client");
		}
		else if (Operators.ConditionalCompareObjectEqual(left, GEnum0.Server, true))
		{
			stringBuilder.Append("Server");
		}
		else if (Operators.ConditionalCompareObjectEqual(left, GEnum0.Broadcast, true))
		{
			stringBuilder.Append("Broadcast");
		}
		stringBuilder.Append("\r\nStratum: ");
		switch (this.method_3())
		{
		case (GEnum2)1:
			stringBuilder.Append("Primary Reference");
			break;
		case (GEnum2)2:
			stringBuilder.Append("Secondary Reference");
			break;
		case (GEnum2)3:
			stringBuilder.Append("Unspecified");
			break;
		}
		stringBuilder.Append("\r\nLocal time: " + this.method_12().ToString());
		stringBuilder.Append("\r\nPrecision: " + this.method_5().ToString() + " ms");
		stringBuilder.Append("\r\nPoll Interval: " + this.method_4().ToString() + " s");
		stringBuilder.Append("\r\nReference ID: " + this.method_8().ToString());
		stringBuilder.Append("\r\nRoot Delay: " + this.method_6().ToString() + " ms");
		stringBuilder.Append("\r\nRoot Dispersion: " + this.method_7().ToString() + " ms");
		stringBuilder.Append("\r\nRound Trip Delay: " + this.method_14().ToString() + " ms");
		stringBuilder.Append("\r\nLocal Clock Offset: " + this.method_15().ToString() + " ms");
		stringBuilder.Append("\r\n");
		return stringBuilder.ToString();
	}

	// Token: 0x06001357 RID: 4951
	[DllImport("KERNEL32.DLL", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Unicode, SetLastError = true)]
	private static extern int SetLocalTime(ref GClass6.Struct29 struct29_0);

	// Token: 0x06001358 RID: 4952 RVA: 0x00089AD8 File Offset: 0x00087CD8
	private void method_22()
	{
		DateTime dateTime = DateTime.Now.AddMilliseconds((double)this.method_15());
		checked
		{
			GClass6.Struct29 @struct;
			@struct.short_0 = (short)dateTime.Year;
			@struct.short_1 = (short)dateTime.Month;
			@struct.short_2 = (short)dateTime.DayOfWeek;
			@struct.short_3 = (short)dateTime.Day;
			@struct.short_4 = (short)dateTime.Hour;
			@struct.short_5 = (short)dateTime.Minute;
			@struct.short_6 = (short)dateTime.Second;
			@struct.short_7 = (short)dateTime.Millisecond;
			GClass6.SetLocalTime(ref @struct);
		}
	}

	// Token: 0x0400077A RID: 1914
	private byte[] byte_0;

	// Token: 0x0400077B RID: 1915
	public DateTime dateTime_0;

	// Token: 0x0400077C RID: 1916
	private string string_0;

	// Token: 0x0200015D RID: 349
	private struct Struct29
	{
		// Token: 0x0400077D RID: 1917
		public short short_0;

		// Token: 0x0400077E RID: 1918
		public short short_1;

		// Token: 0x0400077F RID: 1919
		public short short_2;

		// Token: 0x04000780 RID: 1920
		public short short_3;

		// Token: 0x04000781 RID: 1921
		public short short_4;

		// Token: 0x04000782 RID: 1922
		public short short_5;

		// Token: 0x04000783 RID: 1923
		public short short_6;

		// Token: 0x04000784 RID: 1924
		public short short_7;
	}
}
