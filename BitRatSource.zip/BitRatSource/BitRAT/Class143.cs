﻿using System;
using System.Collections;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

// Token: 0x0200015B RID: 347
internal sealed class Class143 : IComparer
{
	// Token: 0x0600133D RID: 4925 RVA: 0x0000A880 File Offset: 0x00008A80
	public Class143(int int_1, SortOrder sortOrder_1)
	{
		this.int_0 = int_1;
		this.sortOrder_0 = sortOrder_1;
	}

	// Token: 0x0600133E RID: 4926 RVA: 0x00088E00 File Offset: 0x00087000
	public int Compare(object x, object y)
	{
		ListViewItem listViewItem = (ListViewItem)x;
		ListViewItem listViewItem2 = (ListViewItem)y;
		string text;
		if (listViewItem.SubItems.Count <= this.int_0)
		{
			text = string.Empty;
		}
		else
		{
			text = listViewItem.SubItems[this.int_0].Text;
		}
		string text2;
		if (listViewItem2.SubItems.Count <= this.int_0)
		{
			text2 = string.Empty;
		}
		else
		{
			text2 = listViewItem2.SubItems[this.int_0].Text;
		}
		int result;
		if (this.sortOrder_0 == SortOrder.Ascending)
		{
			if (Versioned.IsNumeric(text) & Versioned.IsNumeric(text2))
			{
				result = Conversion.Val(text).CompareTo(Conversion.Val(text2));
			}
			else if (Information.IsDate(text) & Information.IsDate(text2))
			{
				result = DateTime.Parse(text).CompareTo(DateTime.Parse(text2));
			}
			else
			{
				result = string.Compare(text, text2);
			}
		}
		else if (Versioned.IsNumeric(text) & Versioned.IsNumeric(text2))
		{
			result = Conversion.Val(text2).CompareTo(Conversion.Val(text));
		}
		else if (Information.IsDate(text) & Information.IsDate(text2))
		{
			result = DateTime.Parse(text2).CompareTo(DateTime.Parse(text));
		}
		else
		{
			result = string.Compare(text2, text);
		}
		return result;
	}

	// Token: 0x04000778 RID: 1912
	private int int_0;

	// Token: 0x04000779 RID: 1913
	private SortOrder sortOrder_0;
}
