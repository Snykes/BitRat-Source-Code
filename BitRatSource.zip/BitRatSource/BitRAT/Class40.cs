﻿using System;

// Token: 0x02000039 RID: 57
internal sealed class Class40 : Interface2
{
	// Token: 0x060002AB RID: 683 RVA: 0x00003EB7 File Offset: 0x000020B7
	public Class40(Interface2 interface2_1, byte[] byte_1) : this(interface2_1, byte_1, 0, byte_1.Length)
	{
	}

	// Token: 0x060002AC RID: 684 RVA: 0x0001E120 File Offset: 0x0001C320
	public Class40(Interface2 interface2_1, byte[] byte_1, int int_0, int int_1)
	{
		if (interface2_1 == null)
		{
			throw new ArgumentNullException("parameters");
		}
		if (byte_1 == null)
		{
			throw new ArgumentNullException("iv");
		}
		this.interface2_0 = interface2_1;
		this.byte_0 = new byte[int_1];
		Array.Copy(byte_1, int_0, this.byte_0, 0, int_1);
	}

	// Token: 0x060002AD RID: 685 RVA: 0x00003EC5 File Offset: 0x000020C5
	public byte[] method_0()
	{
		return (byte[])this.byte_0.Clone();
	}

	// Token: 0x060002AE RID: 686 RVA: 0x00003ED7 File Offset: 0x000020D7
	public Interface2 method_1()
	{
		return this.interface2_0;
	}

	// Token: 0x04000160 RID: 352
	private readonly Interface2 interface2_0;

	// Token: 0x04000161 RID: 353
	private readonly byte[] byte_0;
}
