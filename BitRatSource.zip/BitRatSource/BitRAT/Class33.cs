﻿using System;

// Token: 0x02000037 RID: 55
internal sealed class Class33
{
	// Token: 0x0600029F RID: 671 RVA: 0x00003E63 File Offset: 0x00002063
	public Class33(int int_2, int int_3)
	{
		this.method_1(int_2);
		this.int_1 = int_3;
	}

	// Token: 0x060002A0 RID: 672 RVA: 0x00003E79 File Offset: 0x00002079
	public int method_0()
	{
		return this.int_0;
	}

	// Token: 0x060002A1 RID: 673 RVA: 0x00003E81 File Offset: 0x00002081
	public void method_1(int int_2)
	{
		this.int_0 = int_2;
	}

	// Token: 0x060002A2 RID: 674 RVA: 0x00003E8A File Offset: 0x0000208A
	public int method_2()
	{
		return this.int_1;
	}

	// Token: 0x060002A3 RID: 675 RVA: 0x0001E0C0 File Offset: 0x0001C2C0
	public override bool Equals(object obj)
	{
		Class33 class33_ = obj as Class33;
		return !(class33_ == null) && this.method_3(class33_);
	}

	// Token: 0x060002A4 RID: 676 RVA: 0x00003E92 File Offset: 0x00002092
	public bool method_3(Class33 class33_0)
	{
		return class33_0.method_0() == this.method_0();
	}

	// Token: 0x060002A5 RID: 677 RVA: 0x00003EA2 File Offset: 0x000020A2
	public static bool operator ==(Class33 class33_0, Class33 class33_1)
	{
		return class33_0.method_3(class33_1);
	}

	// Token: 0x060002A6 RID: 678 RVA: 0x00003EAB File Offset: 0x000020AB
	public static bool operator !=(Class33 class33_0, Class33 class33_1)
	{
		return !(class33_0 == class33_1);
	}

	// Token: 0x060002A7 RID: 679 RVA: 0x0001E0E8 File Offset: 0x0001C2E8
	public override int GetHashCode()
	{
		return this.method_0().GetHashCode();
	}

	// Token: 0x060002A8 RID: 680 RVA: 0x0001E104 File Offset: 0x0001C304
	public override string ToString()
	{
		return this.method_0().ToString();
	}

	// Token: 0x0400015E RID: 350
	private int int_0;

	// Token: 0x0400015F RID: 351
	private readonly int int_1;
}
