﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using VisualPlus.Toolkit.Controls.Interactivity;

// Token: 0x020000EB RID: 235
[DesignerGenerated]
public sealed partial class fHWIDUpdate : Form
{
	// Token: 0x06000B82 RID: 2946 RVA: 0x00007565 File Offset: 0x00005765
	public fHWIDUpdate()
	{
		base.Load += this.fHWIDUpdate_Load;
		base.Closing += this.fHWIDUpdate_Closing;
		this.InitializeComponent();
	}

	// Token: 0x06000B85 RID: 2949 RVA: 0x00007597 File Offset: 0x00005797
	internal Label vmethod_0()
	{
		return this.label_0;
	}

	// Token: 0x06000B86 RID: 2950 RVA: 0x0000759F File Offset: 0x0000579F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_1(Label label_5)
	{
		this.label_0 = label_5;
	}

	// Token: 0x06000B87 RID: 2951 RVA: 0x000075A8 File Offset: 0x000057A8
	internal VisualButton vmethod_2()
	{
		return this.visualButton_0;
	}

	// Token: 0x06000B88 RID: 2952 RVA: 0x00059F9C File Offset: 0x0005819C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_3(VisualButton visualButton_1)
	{
		EventHandler value = new EventHandler(this.method_0);
		VisualButton visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_0 = visualButton_1;
		visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06000B89 RID: 2953 RVA: 0x000075B0 File Offset: 0x000057B0
	internal TextBox vmethod_4()
	{
		return this.textBox_0;
	}

	// Token: 0x06000B8A RID: 2954 RVA: 0x000075B8 File Offset: 0x000057B8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_5(TextBox textBox_1)
	{
		this.textBox_0 = textBox_1;
	}

	// Token: 0x06000B8B RID: 2955 RVA: 0x000075C1 File Offset: 0x000057C1
	internal Label vmethod_6()
	{
		return this.label_1;
	}

	// Token: 0x06000B8C RID: 2956 RVA: 0x000075C9 File Offset: 0x000057C9
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_7(Label label_5)
	{
		this.label_1 = label_5;
	}

	// Token: 0x06000B8D RID: 2957 RVA: 0x000075D2 File Offset: 0x000057D2
	internal Label vmethod_8()
	{
		return this.label_2;
	}

	// Token: 0x06000B8E RID: 2958 RVA: 0x000075DA File Offset: 0x000057DA
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_9(Label label_5)
	{
		this.label_2 = label_5;
	}

	// Token: 0x06000B8F RID: 2959 RVA: 0x000075E3 File Offset: 0x000057E3
	internal Label vmethod_10()
	{
		return this.label_3;
	}

	// Token: 0x06000B90 RID: 2960 RVA: 0x000075EB File Offset: 0x000057EB
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_11(Label label_5)
	{
		this.label_3 = label_5;
	}

	// Token: 0x06000B91 RID: 2961 RVA: 0x000075F4 File Offset: 0x000057F4
	internal BackgroundWorker vmethod_12()
	{
		return this.backgroundWorker_0;
	}

	// Token: 0x06000B92 RID: 2962 RVA: 0x00059FE0 File Offset: 0x000581E0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_13(BackgroundWorker backgroundWorker_1)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_4);
		BackgroundWorker backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_0 = backgroundWorker_1;
		backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x06000B93 RID: 2963 RVA: 0x000075FC File Offset: 0x000057FC
	internal PictureBox vmethod_14()
	{
		return this.pictureBox_0;
	}

	// Token: 0x06000B94 RID: 2964 RVA: 0x0005A024 File Offset: 0x00058224
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_15(PictureBox pictureBox_1)
	{
		EventHandler value = new EventHandler(this.method_5);
		PictureBox pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_0 = pictureBox_1;
		pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06000B95 RID: 2965 RVA: 0x00007604 File Offset: 0x00005804
	internal Label vmethod_16()
	{
		return this.label_4;
	}

	// Token: 0x06000B96 RID: 2966 RVA: 0x0000760C File Offset: 0x0000580C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_17(Label label_5)
	{
		this.label_4 = label_5;
	}

	// Token: 0x06000B97 RID: 2967 RVA: 0x0005A068 File Offset: 0x00058268
	private void fHWIDUpdate_Load(object sender, EventArgs e)
	{
		this.vmethod_0().Text = "If you already own a license and have changed system, then simply update your HWID and restart BitRAT.\r\n\r\nIf you've haven't changed sytem and seeing this window,\r\nthen it could be due to an unexpected HWID change of your system.\r\n\r\nNOTE: This can also happen if you've just updated " + Application.ProductName + "\r\n and a change in HWID mechanism was made by us in the updated version.";
		this.vmethod_10().Text = Class136.smethod_41();
		this.vmethod_16().Left = checked(this.vmethod_10().Left + this.vmethod_10().Width + 5);
	}

	// Token: 0x06000B98 RID: 2968 RVA: 0x00007348 File Offset: 0x00005548
	private void fHWIDUpdate_Closing(object sender, CancelEventArgs e)
	{
		base.Visible = false;
		e.Cancel = true;
	}

	// Token: 0x06000B99 RID: 2969 RVA: 0x0005A0C8 File Offset: 0x000582C8
	private void method_0(object sender, EventArgs e)
	{
		if (this.vmethod_4().TextLength < 16 | !Class136.smethod_39(this.vmethod_4().Text))
		{
			Interaction.MsgBox("Invalid HWID format!", MsgBoxStyle.Critical, Application.ProductName);
			return;
		}
		this.vmethod_2().Enabled = false;
		new Thread(new ThreadStart(this.method_3)).Start();
	}

	// Token: 0x06000B9A RID: 2970 RVA: 0x0005A130 File Offset: 0x00058330
	public bool method_1()
	{
		object[] object_ = new object[]
		{
			this
		};
		return (bool)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O=%*?=Jg", object_);
	}

	// Token: 0x06000B9B RID: 2971 RVA: 0x0005A168 File Offset: 0x00058368
	public void method_2()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O<[*?<TN", object_);
	}

	// Token: 0x06000B9C RID: 2972 RVA: 0x0005A198 File Offset: 0x00058398
	public void method_3()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O<;*?>#!", object_);
	}

	// Token: 0x06000B9D RID: 2973 RVA: 0x0005A1C8 File Offset: 0x000583C8
	private void method_4(object sender, DoWorkEventArgs e)
	{
		int num = 1;
		checked
		{
			do
			{
				Thread.Sleep(1000);
				if (this.vmethod_12().CancellationPending)
				{
					return;
				}
				num++;
			}
			while (num <= 300);
			Interaction.MsgBox("Failed to connect via Tor! (Time-out)\r\n\r\nPlease, restart " + Application.ProductName + " and try again later.", MsgBoxStyle.Critical, Application.ProductName);
		}
	}

	// Token: 0x06000B9E RID: 2974 RVA: 0x00007615 File Offset: 0x00005815
	private void method_5(object sender, EventArgs e)
	{
		Interaction.MsgBox("This field should be the old HWID that you were told to save and displayed in the payment form.\r\n\r\nIf you for whatever reason have forgot your first HWID, then then old way to recover your license is to provide support with payment information, i.e a link to the transaction in the blockchain.\r\n\r\nShould you not have access to any of the above, then there is sadly no way for support to verify your license, hence why it was explicitly stated in the payment form that the HWID needs to be saved.", MsgBoxStyle.Question, Application.ProductName);
	}

	// Token: 0x04000457 RID: 1111
	private Label label_0;

	// Token: 0x04000458 RID: 1112
	private VisualButton visualButton_0;

	// Token: 0x04000459 RID: 1113
	private TextBox textBox_0;

	// Token: 0x0400045A RID: 1114
	private Label label_1;

	// Token: 0x0400045B RID: 1115
	private Label label_2;

	// Token: 0x0400045C RID: 1116
	private Label label_3;

	// Token: 0x0400045D RID: 1117
	private BackgroundWorker backgroundWorker_0;

	// Token: 0x0400045E RID: 1118
	private PictureBox pictureBox_0;

	// Token: 0x0400045F RID: 1119
	private Label label_4;

	// Token: 0x04000460 RID: 1120
	private readonly Struct18 struct18_0;

	// Token: 0x04000461 RID: 1121
	private Struct18 struct18_1;

	// Token: 0x04000462 RID: 1122
	private Struct16 struct16_0;

	// Token: 0x020000EC RID: 236
	// (Invoke) Token: 0x06000BA4 RID: 2980
	private delegate void Delegate56();

	// Token: 0x020000ED RID: 237
	// (Invoke) Token: 0x06000BA8 RID: 2984
	private delegate void Delegate57();
}
