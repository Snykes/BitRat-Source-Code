﻿// Token: 0x020001C7 RID: 455
[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
public sealed partial class fSearch : global::System.Windows.Forms.Form
{
	// Token: 0x060018C8 RID: 6344 RVA: 0x000B36B4 File Offset: 0x000B18B4
	[global::System.Diagnostics.DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && this.icontainer_0 != null)
			{
				this.icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	// Token: 0x060018C9 RID: 6345 RVA: 0x000B36F4 File Offset: 0x000B18F4
	[global::System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		this.vmethod_1(new global::System.Windows.Forms.Timer(this.icontainer_0));
		this.vmethod_3(new global::System.Windows.Forms.StatusStrip());
		this.vmethod_103(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_17(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_109(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_15(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_5(new global::System.Windows.Forms.Panel());
		this.vmethod_7(new global::BrightIdeasSoftware.FastObjectListView());
		this.vmethod_9(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_11(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_13(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_19(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_21(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_23(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_33(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_37(new global::System.Windows.Forms.ContextMenuStrip(this.icontainer_0));
		this.vmethod_39(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_41(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_43(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_45(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_47(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_49(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_51(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_53(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_55(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_57(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_59(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_61(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_63(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_65(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_67(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_69(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_71(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_73(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_75(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_77(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_79(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_81(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_83(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_85(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_87(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_89(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_91(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_93(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_95(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_111(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_97(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_99(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_101(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_25(new global::System.Windows.Forms.TextBox());
		this.vmethod_27(new global::System.Windows.Forms.Label());
		this.vmethod_29(new global::System.Windows.Forms.Label());
		this.vmethod_31(new global::System.Windows.Forms.TextBox());
		this.vmethod_35(new global::System.Windows.Forms.Label());
		this.vmethod_105(new global::System.ComponentModel.BackgroundWorker());
		this.vmethod_107(new global::System.ComponentModel.BackgroundWorker());
		this.vmethod_113(new global::VisualPlus.Toolkit.Controls.Interactivity.VisualButton());
		this.vmethod_115(new global::VisualPlus.Toolkit.Controls.Interactivity.VisualButton());
		this.vmethod_2().SuspendLayout();
		this.vmethod_4().SuspendLayout();
		this.vmethod_6().BeginInit();
		this.vmethod_36().SuspendLayout();
		base.SuspendLayout();
		this.vmethod_0().Enabled = true;
		this.vmethod_0().Interval = 1000;
		this.vmethod_2().AutoSize = false;
		this.vmethod_2().BackColor = global::System.Drawing.Color.FromArgb(235, 237, 239);
		this.vmethod_2().ImageScalingSize = new global::System.Drawing.Size(28, 28);
		this.vmethod_2().Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_102(),
			this.vmethod_16(),
			this.vmethod_108(),
			this.vmethod_14()
		});
		this.vmethod_2().Location = new global::System.Drawing.Point(0, 471);
		this.vmethod_2().Name = "ssTransferStatus";
		this.vmethod_2().Padding = new global::System.Windows.Forms.Padding(1, 0, 7, 0);
		this.vmethod_2().Size = new global::System.Drawing.Size(1008, 20);
		this.vmethod_2().SizingGrip = false;
		this.vmethod_2().Stretch = false;
		this.vmethod_2().TabIndex = 32;
		this.vmethod_2().Text = "stStatus";
		this.vmethod_102().AutoSize = false;
		this.vmethod_102().BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.None;
		this.vmethod_102().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_102().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_102().Name = "tsSearchedItems";
		this.vmethod_102().Size = new global::System.Drawing.Size(110, 15);
		this.vmethod_102().Text = "Searched: 0";
		this.vmethod_102().TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
		this.vmethod_16().AutoSize = false;
		this.vmethod_16().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_16().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_16().Name = "tsSearchItems";
		this.vmethod_16().Size = new global::System.Drawing.Size(100, 15);
		this.vmethod_16().Text = "Items: 0";
		this.vmethod_16().TextAlign = global::System.Drawing.ContentAlignment.TopLeft;
		this.vmethod_108().AutoSize = false;
		this.vmethod_108().BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.None;
		this.vmethod_108().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_108().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_108().Name = "tsSelectedtems";
		this.vmethod_108().Size = new global::System.Drawing.Size(110, 15);
		this.vmethod_108().Text = "Selected: 0";
		this.vmethod_108().TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
		this.vmethod_14().AutoSize = false;
		this.vmethod_14().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_14().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_14().Name = "tsSearchPath";
		this.vmethod_14().Size = new global::System.Drawing.Size(680, 15);
		this.vmethod_14().Spring = true;
		this.vmethod_14().Text = "Current path: N/A";
		this.vmethod_14().TextAlign = global::System.Drawing.ContentAlignment.TopLeft;
		this.vmethod_4().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_4().BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
		this.vmethod_4().Controls.Add(this.vmethod_6());
		this.vmethod_4().Location = new global::System.Drawing.Point(0, 79);
		this.vmethod_4().Name = "pnlSearch";
		this.vmethod_4().Size = new global::System.Drawing.Size(1008, 393);
		this.vmethod_4().TabIndex = 33;
		this.vmethod_6().Alignment = global::System.Windows.Forms.ListViewAlignment.Left;
		this.vmethod_6().AllColumns.Add(this.vmethod_8());
		this.vmethod_6().AllColumns.Add(this.vmethod_10());
		this.vmethod_6().AllColumns.Add(this.vmethod_12());
		this.vmethod_6().AllColumns.Add(this.vmethod_18());
		this.vmethod_6().AllColumns.Add(this.vmethod_20());
		this.vmethod_6().AllColumns.Add(this.vmethod_22());
		this.vmethod_6().AllColumns.Add(this.vmethod_32());
		this.vmethod_6().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_6().AutoArrange = false;
		this.vmethod_6().BorderStyle = global::System.Windows.Forms.BorderStyle.None;
		this.vmethod_6().CellEditUseWholeCell = false;
		this.vmethod_6().Columns.AddRange(new global::System.Windows.Forms.ColumnHeader[]
		{
			this.vmethod_8(),
			this.vmethod_10(),
			this.vmethod_12(),
			this.vmethod_18(),
			this.vmethod_20(),
			this.vmethod_22(),
			this.vmethod_32()
		});
		this.vmethod_6().ContextMenuStrip = this.vmethod_36();
		this.vmethod_6().Cursor = global::System.Windows.Forms.Cursors.Default;
		this.vmethod_6().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.142858f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_6().FullRowSelect = true;
		this.vmethod_6().HideSelection = false;
		this.vmethod_6().Location = new global::System.Drawing.Point(1, 1);
		this.vmethod_6().Margin = new global::System.Windows.Forms.Padding(1);
		this.vmethod_6().Name = "lvFiles";
		this.vmethod_6().ShowGroups = false;
		this.vmethod_6().Size = new global::System.Drawing.Size(1002, 389);
		this.vmethod_6().TabIndex = 32;
		this.vmethod_6().UseCompatibleStateImageBehavior = false;
		this.vmethod_6().UseHotControls = false;
		this.vmethod_6().UseOverlays = false;
		this.vmethod_6().View = global::System.Windows.Forms.View.Details;
		this.vmethod_6().VirtualMode = true;
		this.vmethod_8().AspectName = "NAME";
		this.vmethod_8().Hideable = false;
		this.vmethod_8().Text = "Name";
		this.vmethod_10().AspectName = "SIZE";
		this.vmethod_10().Hideable = false;
		this.vmethod_10().Text = "Size";
		this.vmethod_12().AspectName = "TYPE";
		this.vmethod_12().Hideable = false;
		this.vmethod_12().Text = "Type";
		this.vmethod_18().AspectName = "ATTR";
		this.vmethod_18().Hideable = false;
		this.vmethod_18().Text = "Attributes";
		this.vmethod_20().AspectName = "LMOD";
		this.vmethod_20().Hideable = false;
		this.vmethod_20().Text = "Last modified";
		this.vmethod_22().AspectName = "PATH";
		this.vmethod_22().Hideable = false;
		this.vmethod_22().Text = "Path";
		this.vmethod_32().AspectName = "STATUS";
		this.vmethod_32().Hideable = false;
		this.vmethod_32().Text = "Status";
		this.vmethod_36().BackColor = global::System.Drawing.Color.FromArgb(235, 237, 239);
		this.vmethod_36().ImageScalingSize = new global::System.Drawing.Size(24, 24);
		this.vmethod_36().Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_38(),
			this.vmethod_76(),
			this.vmethod_78(),
			this.vmethod_80(),
			this.vmethod_82(),
			this.vmethod_86(),
			this.vmethod_88(),
			this.vmethod_110(),
			this.vmethod_96(),
			this.vmethod_98(),
			this.vmethod_100()
		});
		this.vmethod_36().Name = "cmsInfo";
		this.vmethod_36().Size = new global::System.Drawing.Size(170, 182);
		this.vmethod_38().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_40(),
			this.vmethod_46(),
			this.vmethod_48(),
			this.vmethod_50(),
			this.vmethod_52()
		});
		this.vmethod_38().Name = "OperationsToolStripMenuItem";
		this.vmethod_38().Size = new global::System.Drawing.Size(169, 22);
		this.vmethod_38().Text = "Operations";
		this.vmethod_40().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_42(),
			this.vmethod_44()
		});
		this.vmethod_40().Name = "ExecuteToolStripMenuItem";
		this.vmethod_40().Size = new global::System.Drawing.Size(117, 22);
		this.vmethod_40().Text = "Execute";
		this.vmethod_42().Name = "VisibleToolStripMenuItem";
		this.vmethod_42().Size = new global::System.Drawing.Size(113, 22);
		this.vmethod_42().Text = "Visible";
		this.vmethod_44().Name = "HiddenToolStripMenuItem";
		this.vmethod_44().Size = new global::System.Drawing.Size(113, 22);
		this.vmethod_44().Text = "Hidden";
		this.vmethod_46().Name = "ToolStripMenuItem10";
		this.vmethod_46().Size = new global::System.Drawing.Size(114, 6);
		this.vmethod_48().Name = "RenameToolStripMenuItem";
		this.vmethod_48().Size = new global::System.Drawing.Size(117, 22);
		this.vmethod_48().Text = "Rename";
		this.vmethod_50().Name = "ToolStripMenuItem11";
		this.vmethod_50().Size = new global::System.Drawing.Size(114, 6);
		this.vmethod_52().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_54(),
			this.vmethod_56()
		});
		this.vmethod_52().Name = "DeleteToolStripMenuItem";
		this.vmethod_52().Size = new global::System.Drawing.Size(117, 22);
		this.vmethod_52().Text = "Delete";
		this.vmethod_54().Name = "NormalToolStripMenuItem1";
		this.vmethod_54().Size = new global::System.Drawing.Size(114, 22);
		this.vmethod_54().Text = "Normal";
		this.vmethod_56().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_58(),
			this.vmethod_60(),
			this.vmethod_62(),
			this.vmethod_64(),
			this.vmethod_66(),
			this.vmethod_68(),
			this.vmethod_70(),
			this.vmethod_72(),
			this.vmethod_74()
		});
		this.vmethod_56().Name = "SecureToolStripMenuItem";
		this.vmethod_56().Size = new global::System.Drawing.Size(114, 22);
		this.vmethod_56().Text = "Secure";
		this.vmethod_58().Name = "GermanVSITR7PassToolStripMenuItem";
		this.vmethod_58().Size = new global::System.Drawing.Size(229, 22);
		this.vmethod_58().Text = "German VSITR (7 pass)";
		this.vmethod_60().Name = "BruceSchneier7PassToolStripMenuItem";
		this.vmethod_60().Size = new global::System.Drawing.Size(229, 22);
		this.vmethod_60().Text = "Bruce Schneier (7 pass)";
		this.vmethod_62().Name = "BritishHMGIS53PassToolStripMenuItem";
		this.vmethod_62().Size = new global::System.Drawing.Size(229, 22);
		this.vmethod_62().Text = "British HMG IS5 (3 pass)";
		this.vmethod_64().Name = "UsDOD522022M3PassToolStripMenuItem";
		this.vmethod_64().Size = new global::System.Drawing.Size(229, 22);
		this.vmethod_64().Text = "US DOD 5220.22-M (3 pass)";
		this.vmethod_66().Name = "NIST800883PassToolStripMenuItem";
		this.vmethod_66().Size = new global::System.Drawing.Size(229, 22);
		this.vmethod_66().Text = "NIST 800-88 (2 pass)";
		this.vmethod_68().Name = "RussianGOSTP507392PassToolStripMenuItem";
		this.vmethod_68().Size = new global::System.Drawing.Size(229, 22);
		this.vmethod_68().Text = "Russian GOST P50739 (2 pass)";
		this.vmethod_70().Name = "ZeroFillerToolStripMenuItem";
		this.vmethod_70().Size = new global::System.Drawing.Size(229, 22);
		this.vmethod_70().Text = "Zero filler (1 pass)";
		this.vmethod_72().Name = "OneFillerToolStripMenuItem";
		this.vmethod_72().Size = new global::System.Drawing.Size(229, 22);
		this.vmethod_72().Text = "One filler (1 pass)";
		this.vmethod_74().Name = "RandomFiller1PassToolStripMenuItem";
		this.vmethod_74().Size = new global::System.Drawing.Size(229, 22);
		this.vmethod_74().Text = "Random filler (1 pass)";
		this.vmethod_76().Name = "ToolStripMenuItem5";
		this.vmethod_76().Size = new global::System.Drawing.Size(166, 6);
		this.vmethod_78().Name = "tsFilemanagerFilesDownload";
		this.vmethod_78().Size = new global::System.Drawing.Size(169, 22);
		this.vmethod_78().Text = "Download";
		this.vmethod_80().Name = "ToolStripMenuItem7";
		this.vmethod_80().Size = new global::System.Drawing.Size(166, 6);
		this.vmethod_82().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_84()
		});
		this.vmethod_82().Name = "CompressToolStripMenuItem";
		this.vmethod_82().Size = new global::System.Drawing.Size(169, 22);
		this.vmethod_82().Text = "Compress";
		this.vmethod_84().Name = "AddToZIPToolStripMenuItem";
		this.vmethod_84().Size = new global::System.Drawing.Size(130, 22);
		this.vmethod_84().Text = "Add to ZIP";
		this.vmethod_86().Name = "ToolStripMenuItem9";
		this.vmethod_86().Size = new global::System.Drawing.Size(166, 6);
		this.vmethod_88().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_90(),
			this.vmethod_92(),
			this.vmethod_94()
		});
		this.vmethod_88().Name = "CopyToClipboardToolStripMenuItem";
		this.vmethod_88().Size = new global::System.Drawing.Size(169, 22);
		this.vmethod_88().Text = "Copy to clipboard";
		this.vmethod_90().Name = "FilemanagerCopySelectedToolStripMenuItem1";
		this.vmethod_90().Size = new global::System.Drawing.Size(118, 22);
		this.vmethod_90().Text = "Selected";
		this.vmethod_92().Name = "ToolStripMenuItem19";
		this.vmethod_92().Size = new global::System.Drawing.Size(115, 6);
		this.vmethod_94().Name = "FilemanagerCopyAllToolStripMenuItem";
		this.vmethod_94().Size = new global::System.Drawing.Size(118, 22);
		this.vmethod_94().Text = "All";
		this.vmethod_110().Name = "ShowThumbnailToolStripMenuItem";
		this.vmethod_110().Size = new global::System.Drawing.Size(169, 22);
		this.vmethod_110().Text = "Show thumbnail";
		this.vmethod_96().Name = "TransferManagerToolStripMenuItem";
		this.vmethod_96().Size = new global::System.Drawing.Size(169, 22);
		this.vmethod_96().Text = "Transfer manager";
		this.vmethod_98().Name = "ToolStripMenuItem1";
		this.vmethod_98().Size = new global::System.Drawing.Size(166, 6);
		this.vmethod_100().Name = "ClearToolStripMenuItem";
		this.vmethod_100().Size = new global::System.Drawing.Size(169, 22);
		this.vmethod_100().Text = "Clear";
		this.vmethod_24().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_24().Location = new global::System.Drawing.Point(136, 15);
		this.vmethod_24().Margin = new global::System.Windows.Forms.Padding(1);
		this.vmethod_24().MaxLength = 16;
		this.vmethod_24().Name = "txtPath";
		this.vmethod_24().Size = new global::System.Drawing.Size(868, 20);
		this.vmethod_24().TabIndex = 36;
		this.vmethod_26().AutoSize = true;
		this.vmethod_26().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_26().FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.vmethod_26().Location = new global::System.Drawing.Point(102, 18);
		this.vmethod_26().Margin = new global::System.Windows.Forms.Padding(1, 0, 1, 0);
		this.vmethod_26().Name = "lblPath";
		this.vmethod_26().Size = new global::System.Drawing.Size(32, 13);
		this.vmethod_26().TabIndex = 35;
		this.vmethod_26().Text = "Path:";
		this.vmethod_28().AutoSize = true;
		this.vmethod_28().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_28().FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.vmethod_28().Location = new global::System.Drawing.Point(67, 47);
		this.vmethod_28().Margin = new global::System.Windows.Forms.Padding(1, 0, 1, 0);
		this.vmethod_28().Name = "Label1";
		this.vmethod_28().Size = new global::System.Drawing.Size(67, 13);
		this.vmethod_28().TabIndex = 37;
		this.vmethod_28().Text = "Filter (regex):";
		this.vmethod_30().Font = new global::System.Drawing.Font("Arial", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_30().Location = new global::System.Drawing.Point(136, 43);
		this.vmethod_30().Margin = new global::System.Windows.Forms.Padding(1);
		this.vmethod_30().MaxLength = 128;
		this.vmethod_30().Name = "txtFilter";
		this.vmethod_30().Size = new global::System.Drawing.Size(233, 21);
		this.vmethod_30().TabIndex = 38;
		this.vmethod_30().Text = ".*\\.gif|.jpe?g|.tiff|.png|.bmp$";
		this.vmethod_34().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_34().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_34().FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.vmethod_34().Location = new global::System.Drawing.Point(434, 47);
		this.vmethod_34().Margin = new global::System.Windows.Forms.Padding(1, 0, 1, 0);
		this.vmethod_34().Name = "lblStatus";
		this.vmethod_34().Size = new global::System.Drawing.Size(564, 13);
		this.vmethod_34().TabIndex = 39;
		this.vmethod_34().Text = "Status: N/A";
		this.vmethod_112().BackColorState.Disabled = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_112().BackColorState.Enabled = global::System.Drawing.Color.FromArgb(220, 220, 220);
		this.vmethod_112().BackColorState.Hover = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_112().BackColorState.Pressed = global::System.Drawing.Color.FromArgb(192, 192, 192);
		this.vmethod_112().Border.Color = global::System.Drawing.Color.FromArgb(180, 180, 180);
		this.vmethod_112().Border.HoverColor = global::System.Drawing.Color.FromArgb(120, 183, 230);
		this.vmethod_112().Border.HoverVisible = true;
		this.vmethod_112().Border.Rounding = 6;
		this.vmethod_112().Border.Thickness = 1;
		this.vmethod_112().Border.Type = 1;
		this.vmethod_112().Border.Visible = true;
		this.vmethod_112().DialogResult = global::System.Windows.Forms.DialogResult.None;
		this.vmethod_112().ForeColor = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_112().Image = null;
		this.vmethod_112().Location = new global::System.Drawing.Point(375, 45);
		this.vmethod_112().MouseState = 0;
		this.vmethod_112().Name = "btnReset";
		this.vmethod_112().Size = new global::System.Drawing.Size(42, 18);
		this.vmethod_112().TabIndex = 40;
		this.vmethod_112().TabStop = false;
		this.vmethod_112().Text = "Reset";
		this.vmethod_112().TextImageRelation = global::System.Windows.Forms.TextImageRelation.Overlay;
		this.vmethod_112().TextStyle.Disabled = global::System.Drawing.Color.FromArgb(131, 129, 129);
		this.vmethod_112().TextStyle.Enabled = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_112().TextStyle.Hover = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_112().TextStyle.Pressed = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_112().TextStyle.TextAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_112().TextStyle.TextLineAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_112().TextStyle.TextRenderingHint = global::System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
		this.vmethod_114().BackColorState.Disabled = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_114().BackColorState.Enabled = global::System.Drawing.Color.FromArgb(220, 220, 220);
		this.vmethod_114().BackColorState.Hover = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_114().BackColorState.Pressed = global::System.Drawing.Color.FromArgb(192, 192, 192);
		this.vmethod_114().Border.Color = global::System.Drawing.Color.FromArgb(180, 180, 180);
		this.vmethod_114().Border.HoverColor = global::System.Drawing.Color.FromArgb(120, 183, 230);
		this.vmethod_114().Border.HoverVisible = true;
		this.vmethod_114().Border.Rounding = 6;
		this.vmethod_114().Border.Thickness = 1;
		this.vmethod_114().Border.Type = 1;
		this.vmethod_114().Border.Visible = true;
		this.vmethod_114().DialogResult = global::System.Windows.Forms.DialogResult.None;
		this.vmethod_114().ForeColor = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_114().Image = null;
		this.vmethod_114().Location = new global::System.Drawing.Point(12, 12);
		this.vmethod_114().MouseState = 0;
		this.vmethod_114().Name = "btnSearchStop";
		this.vmethod_114().Size = new global::System.Drawing.Size(75, 32);
		this.vmethod_114().TabIndex = 33;
		this.vmethod_114().TabStop = false;
		this.vmethod_114().Text = "Search";
		this.vmethod_114().TextImageRelation = global::System.Windows.Forms.TextImageRelation.Overlay;
		this.vmethod_114().TextStyle.Disabled = global::System.Drawing.Color.FromArgb(131, 129, 129);
		this.vmethod_114().TextStyle.Enabled = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_114().TextStyle.Hover = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_114().TextStyle.Pressed = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_114().TextStyle.TextAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_114().TextStyle.TextLineAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_114().TextStyle.TextRenderingHint = global::System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new global::System.Drawing.Size(1008, 491);
		base.Controls.Add(this.vmethod_114());
		base.Controls.Add(this.vmethod_112());
		base.Controls.Add(this.vmethod_34());
		base.Controls.Add(this.vmethod_30());
		base.Controls.Add(this.vmethod_28());
		base.Controls.Add(this.vmethod_24());
		base.Controls.Add(this.vmethod_26());
		base.Controls.Add(this.vmethod_4());
		base.Controls.Add(this.vmethod_2());
		this.DoubleBuffered = true;
		base.Name = "fSearch";
		base.Opacity = 0.0;
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterParent;
		this.Text = "Search files";
		this.vmethod_2().ResumeLayout(false);
		this.vmethod_2().PerformLayout();
		this.vmethod_4().ResumeLayout(false);
		this.vmethod_6().EndInit();
		this.vmethod_36().ResumeLayout(false);
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x04000937 RID: 2359
	private global::System.ComponentModel.IContainer icontainer_0;
}
