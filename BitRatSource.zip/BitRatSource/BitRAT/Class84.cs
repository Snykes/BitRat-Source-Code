﻿using System;
using System.Reflection;
using System.Security;

// Token: 0x02000091 RID: 145
internal static class Class84
{
	// Token: 0x06000471 RID: 1137 RVA: 0x00022484 File Offset: 0x00020684
	private static bool smethod_0()
	{
		bool result;
		try
		{
			if (Environment.Version.Major < 4)
			{
				result = false;
			}
			else
			{
				Assembly assembly = typeof(Class4).Assembly;
				Assembly assembly2 = typeof(SecurityCriticalAttribute).Assembly;
				bool flag = false;
				foreach (object obj in assembly.GetCustomAttributes(false))
				{
					if (obj is AllowPartiallyTrustedCallersAttribute)
					{
						flag = true;
					}
					else
					{
						Type type = obj.GetType();
						if (type.Assembly == assembly2 && "System.Security.SecurityRulesAttribute".Equals(type.FullName, StringComparison.Ordinal) && (byte)type.GetProperty("RuleSet").GetValue(obj, null) != 2)
						{
							return false;
						}
					}
				}
				result = flag;
			}
		}
		catch
		{
			result = false;
		}
		return result;
	}

	// Token: 0x06000472 RID: 1138 RVA: 0x00004CC2 File Offset: 0x00002EC2
	public static bool smethod_1()
	{
		return Class84.bool_0;
	}

	// Token: 0x040001DA RID: 474
	private static readonly bool bool_0 = Class84.smethod_0();
}
