﻿using System;
using System.Linq;

namespace BitRAT
{
	// Token: 0x020001E4 RID: 484
	public class cMinerXMRcli
	{
		// Token: 0x06001ABD RID: 6845 RVA: 0x000BAC9C File Offset: 0x000B8E9C
		public cMinerXMRcli()
		{
			this.idxValues = new string[10];
			checked
			{
				int num = this.idxValues.Count<string>() - 1;
				for (int i = 1; i <= num; i++)
				{
					this.idxValues[i] = "N/A";
				}
			}
		}

		// Token: 0x17000081 RID: 129
		// (get) Token: 0x06001ABE RID: 6846 RVA: 0x0000DAAD File Offset: 0x0000BCAD
		// (set) Token: 0x06001ABF RID: 6847 RVA: 0x0000DAB7 File Offset: 0x0000BCB7
		public string USER
		{
			get
			{
				return this.idxValues[0];
			}
			set
			{
				this.idxValues[0] = value;
			}
		}

		// Token: 0x17000082 RID: 130
		// (get) Token: 0x06001AC0 RID: 6848 RVA: 0x0000DAC2 File Offset: 0x0000BCC2
		// (set) Token: 0x06001AC1 RID: 6849 RVA: 0x0000DACC File Offset: 0x0000BCCC
		public string THREADS
		{
			get
			{
				return this.idxValues[1];
			}
			set
			{
				this.idxValues[1] = value;
			}
		}

		// Token: 0x17000083 RID: 131
		// (get) Token: 0x06001AC2 RID: 6850 RVA: 0x0000DAD7 File Offset: 0x0000BCD7
		// (set) Token: 0x06001AC3 RID: 6851 RVA: 0x0000DAE1 File Offset: 0x0000BCE1
		public string POOL
		{
			get
			{
				return this.idxValues[2];
			}
			set
			{
				this.idxValues[2] = value;
			}
		}

		// Token: 0x17000084 RID: 132
		// (get) Token: 0x06001AC4 RID: 6852 RVA: 0x0000DAEC File Offset: 0x0000BCEC
		// (set) Token: 0x06001AC5 RID: 6853 RVA: 0x0000DAF6 File Offset: 0x0000BCF6
		public string ALGO
		{
			get
			{
				return this.idxValues[3];
			}
			set
			{
				this.idxValues[3] = value;
			}
		}

		// Token: 0x17000085 RID: 133
		// (get) Token: 0x06001AC6 RID: 6854 RVA: 0x0000DB01 File Offset: 0x0000BD01
		// (set) Token: 0x06001AC7 RID: 6855 RVA: 0x0000DB0B File Offset: 0x0000BD0B
		public string OPENCL
		{
			get
			{
				return this.idxValues[4];
			}
			set
			{
				this.idxValues[4] = value;
			}
		}

		// Token: 0x17000086 RID: 134
		// (get) Token: 0x06001AC8 RID: 6856 RVA: 0x0000DB16 File Offset: 0x0000BD16
		// (set) Token: 0x06001AC9 RID: 6857 RVA: 0x0000DB20 File Offset: 0x0000BD20
		public string CPU
		{
			get
			{
				return this.idxValues[5];
			}
			set
			{
				this.idxValues[5] = value;
			}
		}

		// Token: 0x17000087 RID: 135
		// (get) Token: 0x06001ACA RID: 6858 RVA: 0x0000DB2B File Offset: 0x0000BD2B
		// (set) Token: 0x06001ACB RID: 6859 RVA: 0x0000DB35 File Offset: 0x0000BD35
		public string SHARES
		{
			get
			{
				return this.idxValues[6];
			}
			set
			{
				this.idxValues[6] = value;
			}
		}

		// Token: 0x17000088 RID: 136
		// (get) Token: 0x06001ACC RID: 6860 RVA: 0x0000DB40 File Offset: 0x0000BD40
		// (set) Token: 0x06001ACD RID: 6861 RVA: 0x0000DB4A File Offset: 0x0000BD4A
		public string DONATE
		{
			get
			{
				return this.idxValues[7];
			}
			set
			{
				this.idxValues[7] = value;
			}
		}

		// Token: 0x17000089 RID: 137
		// (get) Token: 0x06001ACE RID: 6862 RVA: 0x0000DB55 File Offset: 0x0000BD55
		// (set) Token: 0x06001ACF RID: 6863 RVA: 0x0000DB5F File Offset: 0x0000BD5F
		public string SPEED
		{
			get
			{
				return this.idxValues[8];
			}
			set
			{
				this.idxValues[8] = value;
			}
		}

		// Token: 0x1700008A RID: 138
		// (get) Token: 0x06001AD0 RID: 6864 RVA: 0x0000DB6A File Offset: 0x0000BD6A
		// (set) Token: 0x06001AD1 RID: 6865 RVA: 0x0000DB75 File Offset: 0x0000BD75
		public string DURATION
		{
			get
			{
				return this.idxValues[9];
			}
			set
			{
				this.idxValues[9] = value;
			}
		}

		// Token: 0x1700008B RID: 139
		// (get) Token: 0x06001AD2 RID: 6866 RVA: 0x0000DB81 File Offset: 0x0000BD81
		// (set) Token: 0x06001AD3 RID: 6867 RVA: 0x0000DB89 File Offset: 0x0000BD89
		public string Tag
		{
			get
			{
				return this.m_tag;
			}
			set
			{
				this.m_tag = value;
			}
		}

		// Token: 0x04000A30 RID: 2608
		public string[] idxValues;

		// Token: 0x04000A31 RID: 2609
		public string Key;

		// Token: 0x04000A32 RID: 2610
		private string m_user;

		// Token: 0x04000A33 RID: 2611
		private string m_threads;

		// Token: 0x04000A34 RID: 2612
		private string m_pool;

		// Token: 0x04000A35 RID: 2613
		private string m_algo;

		// Token: 0x04000A36 RID: 2614
		private string m_opencl;

		// Token: 0x04000A37 RID: 2615
		private string m_cpu;

		// Token: 0x04000A38 RID: 2616
		private string m_shares;

		// Token: 0x04000A39 RID: 2617
		private string m_donate;

		// Token: 0x04000A3A RID: 2618
		private string m_speed;

		// Token: 0x04000A3B RID: 2619
		private string m_duration;

		// Token: 0x04000A3C RID: 2620
		private string m_tag;

		// Token: 0x04000A3D RID: 2621
		public bool bJustConnected;

		// Token: 0x04000A3E RID: 2622
		public bool pending_dc;

		// Token: 0x04000A3F RID: 2623
		public bool pending_dc_timeout;

		// Token: 0x04000A40 RID: 2624
		public bool rejected;
	}
}
