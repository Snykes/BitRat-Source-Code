﻿using System;

// Token: 0x0200002F RID: 47
internal sealed class Class101 : Class94
{
	// Token: 0x06000254 RID: 596 RVA: 0x00003CFB File Offset: 0x00001EFB
	public short method_2()
	{
		return this.short_0;
	}

	// Token: 0x06000255 RID: 597 RVA: 0x00003D03 File Offset: 0x00001F03
	public void method_3(short short_1)
	{
		this.short_0 = short_1;
	}

	// Token: 0x06000256 RID: 598 RVA: 0x00003D0C File Offset: 0x00001F0C
	public override object vmethod_0()
	{
		return this.method_2();
	}

	// Token: 0x06000257 RID: 599 RVA: 0x0001C9C0 File Offset: 0x0001ABC0
	public override void vmethod_1(object object_0)
	{
		if (object_0 is int)
		{
			this.method_3((short)((int)object_0));
			return;
		}
		if (object_0 is long)
		{
			this.method_3((short)((long)object_0));
			return;
		}
		if (object_0 is ushort)
		{
			this.method_3((short)((ushort)object_0));
			return;
		}
		if (object_0 is uint)
		{
			this.method_3((short)((uint)object_0));
			return;
		}
		if (object_0 is ulong)
		{
			this.method_3((short)((ulong)object_0));
			return;
		}
		if (object_0 is float)
		{
			this.method_3((short)((float)object_0));
			return;
		}
		if (object_0 is double)
		{
			this.method_3((short)((double)object_0));
			return;
		}
		this.method_3(Convert.ToInt16(object_0));
	}

	// Token: 0x06000258 RID: 600 RVA: 0x00003D19 File Offset: 0x00001F19
	public override Class94 vmethod_4()
	{
		Class101 @class = new Class101();
		@class.method_3(this.short_0);
		@class.method_1(base.method_0());
		return @class;
	}

	// Token: 0x06000259 RID: 601 RVA: 0x00003D38 File Offset: 0x00001F38
	public override int vmethod_2()
	{
		return 15;
	}

	// Token: 0x0600025A RID: 602 RVA: 0x0001CA74 File Offset: 0x0001AC74
	public override Class94 vmethod_3(Class94 class94_0)
	{
		base.method_1(class94_0.method_0());
		switch (class94_0.vmethod_2())
		{
		case 0:
			this.method_3((short)((Class119)class94_0).method_2());
			return this;
		case 2:
			this.method_3((short)Convert.ToByte(((Class103)class94_0).method_2()));
			return this;
		case 4:
			this.method_3(Convert.ToInt16(((Class102)class94_0).method_2()));
			return this;
		case 7:
			this.method_3((short)((Class118)class94_0).method_2());
			return this;
		case 9:
			this.method_3((short)((Class115)class94_0).method_2());
			return this;
		case 10:
			this.method_3((short)((Class114)class94_0).method_2());
			return this;
		case 11:
			this.method_3((short)((Class99)class94_0).method_2());
			return this;
		case 14:
			this.method_3((short)((int)((Class105)class94_0).method_2()));
			return this;
		case 15:
			this.method_3(((Class101)class94_0).method_2());
			return this;
		case 17:
			this.method_3((short)((Class117)class94_0).method_2());
			return this;
		case 19:
			this.method_3((short)((Class120)class94_0).method_2());
			return this;
		case 21:
			this.method_3((short)((Class104)class94_0).method_2());
			return this;
		case 22:
			this.method_3((short)((Class121)class94_0).method_2());
			return this;
		case 24:
			this.method_3(Convert.ToInt16(((Class98)class94_0).method_2()));
			return this;
		}
		throw new ArgumentOutOfRangeException();
	}

	// Token: 0x0400014D RID: 333
	private short short_0;
}
