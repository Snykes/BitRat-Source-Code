﻿using System;

// Token: 0x0200005B RID: 91
internal static class Class58
{
}
