﻿using System;

// Token: 0x02000025 RID: 37
internal static class Class22
{
	// Token: 0x0600021A RID: 538 RVA: 0x00003B30 File Offset: 0x00001D30
	static Class22()
	{
		Class22.smethod_2();
	}

	// Token: 0x0600021B RID: 539 RVA: 0x0001C324 File Offset: 0x0001A524
	public static int smethod_0(string string_0)
	{
		object[] object_ = new object[]
		{
			string_0
		};
		return (int)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O8!*?;4'", object_);
	}

	// Token: 0x0600021C RID: 540 RVA: 0x00003B37 File Offset: 0x00001D37
	public static bool smethod_1(int? nullable_0)
	{
		return Class22.smethod_5(nullable_0, false);
	}

	// Token: 0x0600021D RID: 541 RVA: 0x00003B40 File Offset: 0x00001D40
	private static void smethod_2()
	{
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O8N*?;R1", null);
	}

	// Token: 0x0600021E RID: 542 RVA: 0x00003B57 File Offset: 0x00001D57
	private static int smethod_3()
	{
		return (int)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O82*?<ZP", null);
	}

	// Token: 0x0600021F RID: 543 RVA: 0x0001C35C File Offset: 0x0001A55C
	public static int smethod_4(bool bool_0)
	{
		object[] object_ = new object[]
		{
			bool_0
		};
		return (int)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O7m*?<<F", object_);
	}

	// Token: 0x06000220 RID: 544 RVA: 0x0001C398 File Offset: 0x0001A598
	private static bool smethod_5(int? nullable_0, bool bool_0)
	{
		object[] object_ = new object[]
		{
			nullable_0,
			bool_0
		};
		return (bool)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O9M*?<$>", object_);
	}

	// Token: 0x0400013C RID: 316
	private static int int_0;
}
