﻿using System;

// Token: 0x02000056 RID: 86
internal static class Class54
{
	// Token: 0x06000327 RID: 807 RVA: 0x000041D3 File Offset: 0x000023D3
	public static int smethod_0(int int_0)
	{
		return int_0 & -16777216;
	}
}
