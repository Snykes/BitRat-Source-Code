﻿using System;

// Token: 0x02000002 RID: 2
internal sealed class Class0
{
	// Token: 0x04000001 RID: 1
	public WeakReference weakReference_0;

	// Token: 0x04000002 RID: 2
	public WeakReference weakReference_1;

	// Token: 0x04000003 RID: 3
	public Class48 class48_0;
}
