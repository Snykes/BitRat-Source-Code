﻿using System;

// Token: 0x02000019 RID: 25
internal sealed class Class12
{
	// Token: 0x060001C5 RID: 453 RVA: 0x000037D2 File Offset: 0x000019D2
	public int method_0()
	{
		return this.int_0;
	}

	// Token: 0x060001C6 RID: 454 RVA: 0x000037DA File Offset: 0x000019DA
	public void method_1(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x0400004C RID: 76
	private int int_0;
}
