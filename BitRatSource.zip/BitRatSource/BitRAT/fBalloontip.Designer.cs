﻿// Token: 0x0200012A RID: 298
[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
public sealed partial class fBalloontip : global::System.Windows.Forms.Form
{
	// Token: 0x06001087 RID: 4231 RVA: 0x0007B754 File Offset: 0x00079954
	[global::System.Diagnostics.DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && this.icontainer_0 != null)
			{
				this.icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	// Token: 0x06001088 RID: 4232 RVA: 0x0007B794 File Offset: 0x00079994
	[global::System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.vmethod_1(new global::System.Windows.Forms.PictureBox());
		this.vmethod_3(new global::System.Windows.Forms.Label());
		this.vmethod_5(new global::System.Windows.Forms.PictureBox());
		this.vmethod_7(new global::System.Windows.Forms.Label());
		this.vmethod_9(new global::System.Windows.Forms.Label());
		this.vmethod_11(new global::System.Windows.Forms.Label());
		this.vmethod_13(new global::System.Windows.Forms.PictureBox());
		this.vmethod_15(new global::System.ComponentModel.BackgroundWorker());
		this.vmethod_17(new global::System.ComponentModel.BackgroundWorker());
		this.vmethod_19(new global::System.ComponentModel.BackgroundWorker());
		this.vmethod_21(new global::System.ComponentModel.BackgroundWorker());
		this.vmethod_23(new global::System.Windows.Forms.Label());
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_0()).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_4()).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_12()).BeginInit();
		base.SuspendLayout();
		this.vmethod_0().BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
		this.vmethod_0().Location = new global::System.Drawing.Point(2, 0);
		this.vmethod_0().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_0().Name = "pbMain";
		this.vmethod_0().Size = new global::System.Drawing.Size(385, 94);
		this.vmethod_0().TabIndex = 18;
		this.vmethod_0().TabStop = false;
		this.vmethod_2().Anchor = (global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_2().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_2().FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.vmethod_2().Location = new global::System.Drawing.Point(33, 4);
		this.vmethod_2().Margin = new global::System.Windows.Forms.Padding(1, 0, 1, 0);
		this.vmethod_2().Name = "lblTitle";
		this.vmethod_2().Size = new global::System.Drawing.Size(334, 14);
		this.vmethod_2().TabIndex = 20;
		this.vmethod_2().Text = "New connection";
		this.vmethod_2().TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
		this.vmethod_4().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_4().Image = global::Class131.smethod_30();
		this.vmethod_4().Location = new global::System.Drawing.Point(9, 5);
		this.vmethod_4().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_4().Name = "pIcon";
		this.vmethod_4().Size = new global::System.Drawing.Size(13, 13);
		this.vmethod_4().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_4().TabIndex = 19;
		this.vmethod_4().TabStop = false;
		this.vmethod_6().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_6().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_6().Cursor = global::System.Windows.Forms.Cursors.Hand;
		this.vmethod_6().FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.vmethod_6().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.142858f, global::System.Drawing.FontStyle.Underline, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_6().ForeColor = global::System.Drawing.Color.DarkSlateBlue;
		this.vmethod_6().Location = new global::System.Drawing.Point(346, 76);
		this.vmethod_6().Margin = new global::System.Windows.Forms.Padding(1, 0, 1, 0);
		this.vmethod_6().Name = "lblOpen";
		this.vmethod_6().Size = new global::System.Drawing.Size(36, 14);
		this.vmethod_6().TabIndex = 21;
		this.vmethod_6().Text = "Open";
		this.vmethod_6().TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
		this.vmethod_8().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_8().FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.vmethod_8().Location = new global::System.Drawing.Point(6, 52);
		this.vmethod_8().Margin = new global::System.Windows.Forms.Padding(1, 0, 1, 0);
		this.vmethod_8().Name = "lblUser";
		this.vmethod_8().Size = new global::System.Drawing.Size(365, 14);
		this.vmethod_8().TabIndex = 22;
		this.vmethod_8().Text = "User: N/A";
		this.vmethod_8().TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
		this.vmethod_10().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_10().FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.vmethod_10().Location = new global::System.Drawing.Point(6, 76);
		this.vmethod_10().Margin = new global::System.Windows.Forms.Padding(1, 0, 1, 0);
		this.vmethod_10().Name = "lblActiveWindow";
		this.vmethod_10().Size = new global::System.Drawing.Size(330, 14);
		this.vmethod_10().TabIndex = 23;
		this.vmethod_10().Text = "Window: N/A";
		this.vmethod_10().TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
		this.vmethod_12().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_12().Location = new global::System.Drawing.Point(370, 5);
		this.vmethod_12().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_12().Name = "pbType";
		this.vmethod_12().Size = new global::System.Drawing.Size(13, 13);
		this.vmethod_12().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_12().TabIndex = 24;
		this.vmethod_12().TabStop = false;
		this.vmethod_22().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_22().FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.vmethod_22().Location = new global::System.Drawing.Point(6, 28);
		this.vmethod_22().Margin = new global::System.Windows.Forms.Padding(1, 0, 1, 0);
		this.vmethod_22().Name = "lblIP";
		this.vmethod_22().Size = new global::System.Drawing.Size(365, 14);
		this.vmethod_22().TabIndex = 25;
		this.vmethod_22().Text = "IP: N/A";
		this.vmethod_22().TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = global::System.Drawing.Color.LightSkyBlue;
		base.ClientSize = new global::System.Drawing.Size(389, 95);
		base.Controls.Add(this.vmethod_22());
		base.Controls.Add(this.vmethod_12());
		base.Controls.Add(this.vmethod_10());
		base.Controls.Add(this.vmethod_8());
		base.Controls.Add(this.vmethod_6());
		base.Controls.Add(this.vmethod_2());
		base.Controls.Add(this.vmethod_4());
		base.Controls.Add(this.vmethod_0());
		this.DoubleBuffered = true;
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
		base.Margin = new global::System.Windows.Forms.Padding(2);
		base.Name = "fBalloontip";
		base.Opacity = 0.0;
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_0()).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_4()).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_12()).EndInit();
		base.ResumeLayout(false);
	}

	// Token: 0x0400068B RID: 1675
	private global::System.ComponentModel.IContainer icontainer_0;
}
