﻿using System;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;

// Token: 0x020000E7 RID: 231
public sealed class GClass2 : ApplicationContext
{
	// Token: 0x06000B56 RID: 2902 RVA: 0x00059138 File Offset: 0x00057338
	public GClass2(fMain fMain_1)
	{
		base.ThreadExit += this.GClass2_ThreadExit;
		this.fMain_0 = fMain_1;
		this.vmethod_3(new ToolStripMenuItem("Restore"));
		this.vmethod_5(new ToolStripSeparator());
		this.vmethod_11(new ToolStripMenuItem("Settings"));
		this.vmethod_7(new ToolStripSeparator());
		this.vmethod_9(new ToolStripMenuItem("Exit"));
		this.vmethod_1(new ContextMenuStrip());
		this.vmethod_0().Items.AddRange(new ToolStripItem[]
		{
			this.vmethod_2(),
			this.vmethod_4(),
			this.vmethod_10(),
			this.vmethod_6(),
			this.vmethod_8()
		});
		this.vmethod_0().Enabled = false;
		this.vmethod_13(new NotifyIcon());
		this.vmethod_12().Icon = this.fMain_0.Icon;
		this.vmethod_12().ContextMenuStrip = this.vmethod_0();
		this.vmethod_12().Text = "BitRAT v" + Class130.struct3_8.method_1();
		this.vmethod_12().Visible = true;
		new Thread(delegate()
		{
			this.method_0();
		}).Start();
	}

	// Token: 0x06000B57 RID: 2903 RVA: 0x00007385 File Offset: 0x00005585
	private ContextMenuStrip vmethod_0()
	{
		return this.contextMenuStrip_0;
	}

	// Token: 0x06000B58 RID: 2904 RVA: 0x0000738D File Offset: 0x0000558D
	[MethodImpl(MethodImplOptions.Synchronized)]
	private void vmethod_1(ContextMenuStrip contextMenuStrip_1)
	{
		this.contextMenuStrip_0 = contextMenuStrip_1;
	}

	// Token: 0x06000B59 RID: 2905 RVA: 0x00007396 File Offset: 0x00005596
	private ToolStripMenuItem vmethod_2()
	{
		return this.toolStripMenuItem_0;
	}

	// Token: 0x06000B5A RID: 2906 RVA: 0x00059278 File Offset: 0x00057478
	[MethodImpl(MethodImplOptions.Synchronized)]
	private void vmethod_3(ToolStripMenuItem toolStripMenuItem_3)
	{
		EventHandler value = new EventHandler(this.method_2);
		EventHandler value2 = new EventHandler(this.method_5);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_0;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
			toolStripMenuItem.Click -= value2;
		}
		this.toolStripMenuItem_0 = toolStripMenuItem_3;
		toolStripMenuItem = this.toolStripMenuItem_0;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
			toolStripMenuItem.Click += value2;
		}
	}

	// Token: 0x06000B5B RID: 2907 RVA: 0x0000739E File Offset: 0x0000559E
	private ToolStripSeparator vmethod_4()
	{
		return this.toolStripSeparator_0;
	}

	// Token: 0x06000B5C RID: 2908 RVA: 0x000073A6 File Offset: 0x000055A6
	[MethodImpl(MethodImplOptions.Synchronized)]
	private void vmethod_5(ToolStripSeparator toolStripSeparator_2)
	{
		this.toolStripSeparator_0 = toolStripSeparator_2;
	}

	// Token: 0x06000B5D RID: 2909 RVA: 0x000073AF File Offset: 0x000055AF
	private ToolStripSeparator vmethod_6()
	{
		return this.toolStripSeparator_1;
	}

	// Token: 0x06000B5E RID: 2910 RVA: 0x000073B7 File Offset: 0x000055B7
	[MethodImpl(MethodImplOptions.Synchronized)]
	private void vmethod_7(ToolStripSeparator toolStripSeparator_2)
	{
		this.toolStripSeparator_1 = toolStripSeparator_2;
	}

	// Token: 0x06000B5F RID: 2911 RVA: 0x000073C0 File Offset: 0x000055C0
	private ToolStripMenuItem vmethod_8()
	{
		return this.toolStripMenuItem_1;
	}

	// Token: 0x06000B60 RID: 2912 RVA: 0x000592D8 File Offset: 0x000574D8
	[MethodImpl(MethodImplOptions.Synchronized)]
	private void vmethod_9(ToolStripMenuItem toolStripMenuItem_3)
	{
		EventHandler value = new EventHandler(this.method_3);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_1;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_1 = toolStripMenuItem_3;
		toolStripMenuItem = this.toolStripMenuItem_1;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000B61 RID: 2913 RVA: 0x000073C8 File Offset: 0x000055C8
	private ToolStripMenuItem vmethod_10()
	{
		return this.toolStripMenuItem_2;
	}

	// Token: 0x06000B62 RID: 2914 RVA: 0x0005931C File Offset: 0x0005751C
	[MethodImpl(MethodImplOptions.Synchronized)]
	private void vmethod_11(ToolStripMenuItem toolStripMenuItem_3)
	{
		EventHandler value = new EventHandler(this.method_4);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_2;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_2 = toolStripMenuItem_3;
		toolStripMenuItem = this.toolStripMenuItem_2;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000B63 RID: 2915 RVA: 0x000073D0 File Offset: 0x000055D0
	private NotifyIcon vmethod_12()
	{
		return this.notifyIcon_0;
	}

	// Token: 0x06000B64 RID: 2916 RVA: 0x00059360 File Offset: 0x00057560
	[MethodImpl(MethodImplOptions.Synchronized)]
	private void vmethod_13(NotifyIcon notifyIcon_1)
	{
		EventHandler value = new EventHandler(this.method_5);
		NotifyIcon notifyIcon = this.notifyIcon_0;
		if (notifyIcon != null)
		{
			notifyIcon.DoubleClick -= value;
		}
		this.notifyIcon_0 = notifyIcon_1;
		notifyIcon = this.notifyIcon_0;
		if (notifyIcon != null)
		{
			notifyIcon.DoubleClick += value;
		}
	}

	// Token: 0x06000B65 RID: 2917 RVA: 0x000073D8 File Offset: 0x000055D8
	private void method_0()
	{
		while (!this.fMain_0.struct18_0.method_0())
		{
			Thread.Sleep(1000);
		}
		this.method_1();
	}

	// Token: 0x06000B66 RID: 2918 RVA: 0x000073FF File Offset: 0x000055FF
	public void method_1()
	{
		if (this.vmethod_0().InvokeRequired)
		{
			this.vmethod_0().Invoke(new GClass2.Delegate55(this.method_1), new object[0]);
			return;
		}
		this.vmethod_0().Enabled = true;
	}

	// Token: 0x06000B67 RID: 2919 RVA: 0x00007439 File Offset: 0x00005639
	private void GClass2_ThreadExit(object sender, EventArgs e)
	{
		this.vmethod_12().Visible = false;
	}

	// Token: 0x06000B68 RID: 2920 RVA: 0x00007447 File Offset: 0x00005647
	private void method_2(object sender, EventArgs e)
	{
		this.fMain_0.Visible = true;
		this.fMain_0.WindowState = FormWindowState.Normal;
	}

	// Token: 0x06000B69 RID: 2921 RVA: 0x00007461 File Offset: 0x00005661
	private void method_3(object sender, EventArgs e)
	{
		if (MessageBox.Show("Are you sure want to exit?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			this.vmethod_12().Visible = false;
			Class130.fMain_0.method_50();
		}
	}

	// Token: 0x06000B6A RID: 2922 RVA: 0x000593A4 File Offset: 0x000575A4
	private void method_4(object sender, EventArgs e)
	{
		Class130.fSettings_0.Visible = true;
		Class130.fSettings_0.method_0(Class145.smethod_3().method_14());
		checked
		{
			Class130.fSettings_0.Left = (int)Math.Round(unchecked((double)Class145.smethod_3().method_14().Left + (double)Class145.smethod_3().method_14().Width / 2.0 - (double)Class130.fSettings_0.Width / 2.0));
			Class130.fSettings_0.Top = (int)Math.Round(unchecked((double)Class145.smethod_3().method_14().Top + (double)Class145.smethod_3().method_14().Height / 2.0 - (double)Class130.fSettings_0.Height / 2.0));
		}
	}

	// Token: 0x06000B6B RID: 2923 RVA: 0x0000748E File Offset: 0x0000568E
	private void method_5(object sender, EventArgs e)
	{
		this.fMain_0.Visible = true;
		this.fMain_0.WindowState = FormWindowState.Normal;
		this.fMain_0.Activate();
	}

	// Token: 0x06000B6C RID: 2924 RVA: 0x00007439 File Offset: 0x00005639
	public void method_6()
	{
		this.vmethod_12().Visible = false;
	}

	// Token: 0x04000449 RID: 1097
	private ContextMenuStrip contextMenuStrip_0;

	// Token: 0x0400044A RID: 1098
	private ToolStripMenuItem toolStripMenuItem_0;

	// Token: 0x0400044B RID: 1099
	private ToolStripSeparator toolStripSeparator_0;

	// Token: 0x0400044C RID: 1100
	private ToolStripSeparator toolStripSeparator_1;

	// Token: 0x0400044D RID: 1101
	private ToolStripMenuItem toolStripMenuItem_1;

	// Token: 0x0400044E RID: 1102
	private ToolStripMenuItem toolStripMenuItem_2;

	// Token: 0x0400044F RID: 1103
	private NotifyIcon notifyIcon_0;

	// Token: 0x04000450 RID: 1104
	private fMain fMain_0;

	// Token: 0x020000E8 RID: 232
	// (Invoke) Token: 0x06000B71 RID: 2929
	private delegate void Delegate55();
}
