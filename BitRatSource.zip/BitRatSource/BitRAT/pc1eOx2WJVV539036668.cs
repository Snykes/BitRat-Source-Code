﻿using System;

// Token: 0x020001EC RID: 492
internal static class pc1eOx2WJVV539036668
{
	// Token: 0x06001B26 RID: 6950 RVA: 0x00002F44 File Offset: 0x00001144
	private static void a()
	{
	}
}
