﻿using System;

// Token: 0x02000029 RID: 41
internal sealed class Class24<T>
{
	// Token: 0x0400013F RID: 319
	public static readonly int int_0 = Buffer.ByteLength(new T[1]);
}
