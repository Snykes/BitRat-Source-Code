﻿using System;

// Token: 0x0200001B RID: 27
internal abstract class Class13 : Interface1
{
	// Token: 0x060001D0 RID: 464
	public abstract string imethod_0();

	// Token: 0x060001D1 RID: 465
	public abstract void imethod_1(bool bool_0, Interface2 interface2_0);

	// Token: 0x060001D2 RID: 466
	public abstract int imethod_2();

	// Token: 0x060001D3 RID: 467
	public abstract int imethod_3(int int_0);

	// Token: 0x060001D4 RID: 468
	public abstract int imethod_4(int int_0);

	// Token: 0x060001D5 RID: 469 RVA: 0x00003828 File Offset: 0x00001A28
	public virtual byte[] imethod_5(byte[] byte_1)
	{
		return this.imethod_6(byte_1, 0, byte_1.Length);
	}

	// Token: 0x060001D6 RID: 470
	public abstract byte[] imethod_6(byte[] byte_1, int int_0, int int_1);

	// Token: 0x060001D7 RID: 471 RVA: 0x00003835 File Offset: 0x00001A35
	public virtual int imethod_7(byte[] byte_1, byte[] byte_2, int int_0)
	{
		return this.imethod_8(byte_1, 0, byte_1.Length, byte_2, int_0);
	}

	// Token: 0x060001D8 RID: 472 RVA: 0x0001A9D4 File Offset: 0x00018BD4
	public virtual int imethod_8(byte[] byte_1, int int_0, int int_1, byte[] byte_2, int int_2)
	{
		byte[] array = this.imethod_6(byte_1, int_0, int_1);
		if (array == null)
		{
			return 0;
		}
		if (int_2 + array.Length > byte_2.Length)
		{
			throw new Exception1("output buffer too short");
		}
		array.CopyTo(byte_2, int_2);
		return array.Length;
	}

	// Token: 0x060001D9 RID: 473
	public abstract byte[] imethod_9();

	// Token: 0x060001DA RID: 474 RVA: 0x00003844 File Offset: 0x00001A44
	public virtual byte[] imethod_10(byte[] byte_1)
	{
		return this.imethod_11(byte_1, 0, byte_1.Length);
	}

	// Token: 0x060001DB RID: 475
	public abstract byte[] imethod_11(byte[] byte_1, int int_0, int int_1);

	// Token: 0x060001DC RID: 476 RVA: 0x0001AA14 File Offset: 0x00018C14
	public virtual int imethod_12(byte[] byte_1, int int_0)
	{
		byte[] array = this.imethod_9();
		if (int_0 + array.Length > byte_1.Length)
		{
			throw new Exception1("output buffer too short");
		}
		array.CopyTo(byte_1, int_0);
		return array.Length;
	}

	// Token: 0x060001DD RID: 477 RVA: 0x00003851 File Offset: 0x00001A51
	public virtual int imethod_13(byte[] byte_1, byte[] byte_2, int int_0)
	{
		return this.imethod_14(byte_1, 0, byte_1.Length, byte_2, int_0);
	}

	// Token: 0x060001DE RID: 478 RVA: 0x0001AA48 File Offset: 0x00018C48
	public virtual int imethod_14(byte[] byte_1, int int_0, int int_1, byte[] byte_2, int int_2)
	{
		int num = this.imethod_8(byte_1, int_0, int_1, byte_2, int_2);
		return num + this.imethod_12(byte_2, int_2 + num);
	}

	// Token: 0x060001DF RID: 479
	public abstract void imethod_15();

	// Token: 0x04000050 RID: 80
	protected static readonly byte[] byte_0 = new byte[0];
}
