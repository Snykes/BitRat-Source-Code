﻿// Token: 0x020001A6 RID: 422
[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
public sealed partial class fTransferManager : global::System.Windows.Forms.Form
{
	// Token: 0x0600175C RID: 5980 RVA: 0x000AC520 File Offset: 0x000AA720
	[global::System.Diagnostics.DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && this.icontainer_0 != null)
			{
				this.icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	// Token: 0x0600175D RID: 5981 RVA: 0x000AC560 File Offset: 0x000AA760
	[global::System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		this.vmethod_1(new global::System.Windows.Forms.ContextMenuStrip(this.icontainer_0));
		this.vmethod_7(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_15(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_17(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_19(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_13(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_73(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_75(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_77(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_93(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_79(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_81(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_85(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_87(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_89(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_91(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_83(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_5(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_9(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_11(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_59(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_61(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_63(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_65(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_67(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_3(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_21(new global::BrightIdeasSoftware.FastObjectListView());
		this.vmethod_23(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_25(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_27(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_29(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_31(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_33(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_35(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_37(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_47(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_71(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_39(new global::System.Windows.Forms.StatusStrip());
		this.vmethod_41(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_69(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_55(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_43(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_49(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_53(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_51(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_45(new global::System.Windows.Forms.Timer(this.icontainer_0));
		this.vmethod_57(new global::System.ComponentModel.BackgroundWorker());
		this.vmethod_95(new global::BrightIdeasSoftware.BarRenderer());
		this.vmethod_0().SuspendLayout();
		this.vmethod_20().BeginInit();
		this.vmethod_38().SuspendLayout();
		base.SuspendLayout();
		this.vmethod_0().ImageScalingSize = new global::System.Drawing.Size(24, 24);
		this.vmethod_0().Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_6(),
			this.vmethod_72(),
			this.vmethod_4(),
			this.vmethod_8(),
			this.vmethod_10(),
			this.vmethod_58(),
			this.vmethod_66(),
			this.vmethod_2()
		});
		this.vmethod_0().Name = "ContextMenuStrip1";
		this.vmethod_0().Size = new global::System.Drawing.Size(198, 132);
		this.vmethod_6().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_14(),
			this.vmethod_16(),
			this.vmethod_18(),
			this.vmethod_12()
		});
		this.vmethod_6().Name = "OperationsToolStripMenuItem";
		this.vmethod_6().Size = new global::System.Drawing.Size(197, 22);
		this.vmethod_6().Text = "Operations";
		this.vmethod_14().Name = "PauseToolStripMenuItem";
		this.vmethod_14().Size = new global::System.Drawing.Size(116, 22);
		this.vmethod_14().Text = "Pause";
		this.vmethod_16().Name = "ResumeToolStripMenuItem";
		this.vmethod_16().Size = new global::System.Drawing.Size(116, 22);
		this.vmethod_16().Text = "Resume";
		this.vmethod_18().Name = "ToolStripMenuItem3";
		this.vmethod_18().Size = new global::System.Drawing.Size(113, 6);
		this.vmethod_12().Name = "CancelToolStripMenuItem";
		this.vmethod_12().Size = new global::System.Drawing.Size(116, 22);
		this.vmethod_12().Text = "Cancel";
		this.vmethod_72().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_74()
		});
		this.vmethod_72().Name = "LayoutToolStripMenuItem";
		this.vmethod_72().Size = new global::System.Drawing.Size(197, 22);
		this.vmethod_72().Text = "Layout";
		this.vmethod_74().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_76(),
			this.vmethod_92(),
			this.vmethod_78(),
			this.vmethod_84(),
			this.vmethod_82()
		});
		this.vmethod_74().Name = "GroupsToolStripMenuItem";
		this.vmethod_74().Size = new global::System.Drawing.Size(112, 22);
		this.vmethod_74().Text = "Groups";
		this.vmethod_76().Name = "ShowToolStripMenuItem";
		this.vmethod_76().Size = new global::System.Drawing.Size(119, 22);
		this.vmethod_76().Text = "Show";
		this.vmethod_92().Name = "ToolStripMenuItem7";
		this.vmethod_92().Size = new global::System.Drawing.Size(116, 6);
		this.vmethod_78().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_80()
		});
		this.vmethod_78().Name = "SubtitlesToolStripMenuItem";
		this.vmethod_78().Size = new global::System.Drawing.Size(119, 22);
		this.vmethod_78().Text = "Subtitles";
		this.vmethod_80().Name = "ShowToolStripMenuItem1";
		this.vmethod_80().Size = new global::System.Drawing.Size(103, 22);
		this.vmethod_80().Text = "Show";
		this.vmethod_84().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_86(),
			this.vmethod_88(),
			this.vmethod_90()
		});
		this.vmethod_84().Name = "SortingToolStripMenuItem";
		this.vmethod_84().Size = new global::System.Drawing.Size(119, 22);
		this.vmethod_84().Text = "Sorting";
		this.vmethod_86().Checked = true;
		this.vmethod_86().CheckState = global::System.Windows.Forms.CheckState.Checked;
		this.vmethod_86().Name = "DirectoryToolStripMenuItem";
		this.vmethod_86().Size = new global::System.Drawing.Size(122, 22);
		this.vmethod_86().Text = "Directory";
		this.vmethod_88().Name = "ToolStripMenuItem6";
		this.vmethod_88().Size = new global::System.Drawing.Size(119, 6);
		this.vmethod_90().Name = "UserToolStripMenuItem";
		this.vmethod_90().Size = new global::System.Drawing.Size(122, 22);
		this.vmethod_90().Text = "User";
		this.vmethod_82().Name = "CollapseToolStripMenuItem";
		this.vmethod_82().Size = new global::System.Drawing.Size(119, 22);
		this.vmethod_82().Text = "Collapse";
		this.vmethod_4().Name = "ToolStripMenuItem1";
		this.vmethod_4().Size = new global::System.Drawing.Size(194, 6);
		this.vmethod_8().Name = "OpenContainingFolderToolStripMenuItem";
		this.vmethod_8().Size = new global::System.Drawing.Size(197, 22);
		this.vmethod_8().Text = "Open containing folder";
		this.vmethod_10().Name = "ToolStripMenuItem2";
		this.vmethod_10().Size = new global::System.Drawing.Size(194, 6);
		this.vmethod_58().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_60(),
			this.vmethod_62(),
			this.vmethod_64()
		});
		this.vmethod_58().Name = "CopyToClipboardToolStripMenuItem";
		this.vmethod_58().Size = new global::System.Drawing.Size(197, 22);
		this.vmethod_58().Text = "Copy to clipboard";
		this.vmethod_60().Name = "SelectedToolStripMenuItem";
		this.vmethod_60().Size = new global::System.Drawing.Size(118, 22);
		this.vmethod_60().Text = "Selected";
		this.vmethod_62().Name = "ToolStripMenuItem5";
		this.vmethod_62().Size = new global::System.Drawing.Size(115, 6);
		this.vmethod_64().Name = "AllToolStripMenuItem";
		this.vmethod_64().Size = new global::System.Drawing.Size(118, 22);
		this.vmethod_64().Text = "All";
		this.vmethod_66().Name = "ToolStripMenuItem4";
		this.vmethod_66().Size = new global::System.Drawing.Size(194, 6);
		this.vmethod_2().Name = "ClearTransfersToolStripMenuItem";
		this.vmethod_2().Size = new global::System.Drawing.Size(197, 22);
		this.vmethod_2().Text = "Clear transfers";
		this.vmethod_20().Alignment = global::System.Windows.Forms.ListViewAlignment.Left;
		this.vmethod_20().AllColumns.Add(this.vmethod_22());
		this.vmethod_20().AllColumns.Add(this.vmethod_24());
		this.vmethod_20().AllColumns.Add(this.vmethod_26());
		this.vmethod_20().AllColumns.Add(this.vmethod_28());
		this.vmethod_20().AllColumns.Add(this.vmethod_30());
		this.vmethod_20().AllColumns.Add(this.vmethod_32());
		this.vmethod_20().AllColumns.Add(this.vmethod_34());
		this.vmethod_20().AllColumns.Add(this.vmethod_36());
		this.vmethod_20().AllColumns.Add(this.vmethod_46());
		this.vmethod_20().AllColumns.Add(this.vmethod_70());
		this.vmethod_20().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_20().AutoArrange = false;
		this.vmethod_20().BorderStyle = global::System.Windows.Forms.BorderStyle.None;
		this.vmethod_20().CellEditUseWholeCell = false;
		this.vmethod_20().Columns.AddRange(new global::System.Windows.Forms.ColumnHeader[]
		{
			this.vmethod_22(),
			this.vmethod_24(),
			this.vmethod_26(),
			this.vmethod_28(),
			this.vmethod_30(),
			this.vmethod_32(),
			this.vmethod_34(),
			this.vmethod_36(),
			this.vmethod_46(),
			this.vmethod_70()
		});
		this.vmethod_20().ContextMenuStrip = this.vmethod_0();
		this.vmethod_20().Cursor = global::System.Windows.Forms.Cursors.Default;
		this.vmethod_20().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.142858f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_20().FullRowSelect = true;
		this.vmethod_20().HideSelection = false;
		this.vmethod_20().Location = new global::System.Drawing.Point(1, 1);
		this.vmethod_20().Margin = new global::System.Windows.Forms.Padding(1);
		this.vmethod_20().Name = "lvFiles";
		this.vmethod_20().ShowGroups = false;
		this.vmethod_20().Size = new global::System.Drawing.Size(978, 399);
		this.vmethod_20().SortGroupItemsByPrimaryColumn = false;
		this.vmethod_20().TabIndex = 29;
		this.vmethod_20().UseCellFormatEvents = true;
		this.vmethod_20().UseCompatibleStateImageBehavior = false;
		this.vmethod_20().UseHotControls = false;
		this.vmethod_20().UseOverlays = false;
		this.vmethod_20().View = global::System.Windows.Forms.View.Details;
		this.vmethod_20().VirtualMode = true;
		this.vmethod_22().AspectName = "USER";
		this.vmethod_22().Hideable = false;
		this.vmethod_22().Text = "User";
		this.vmethod_24().AspectName = "FILE";
		this.vmethod_24().Text = "File";
		this.vmethod_26().AspectName = "SIZE";
		this.vmethod_26().Text = "Size";
		this.vmethod_28().AspectName = "PROGRESS";
		this.vmethod_28().Text = "Progress";
		this.vmethod_30().AspectName = "SPEED";
		this.vmethod_30().Text = "Speed";
		this.vmethod_32().AspectName = "STATUS";
		this.vmethod_32().Text = "Status";
		this.vmethod_34().AspectName = "ELAPSED";
		this.vmethod_34().Text = "Elapsed";
		this.vmethod_36().AspectName = "ETA";
		this.vmethod_36().Text = "ETA";
		this.vmethod_46().AspectName = "DIRECTION";
		this.vmethod_46().Text = string.Empty;
		this.vmethod_46().Width = 120;
		this.vmethod_70().AspectName = "GROUP_ID";
		this.vmethod_70().IsEditable = false;
		this.vmethod_70().Searchable = false;
		this.vmethod_70().Text = string.Empty;
		this.vmethod_70().Width = 0;
		this.vmethod_38().AutoSize = false;
		this.vmethod_38().BackColor = global::System.Drawing.Color.FromArgb(235, 237, 239);
		this.vmethod_38().ImageScalingSize = new global::System.Drawing.Size(28, 28);
		this.vmethod_38().Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_40(),
			this.vmethod_68(),
			this.vmethod_54(),
			this.vmethod_42(),
			this.vmethod_48(),
			this.vmethod_52(),
			this.vmethod_50()
		});
		this.vmethod_38().Location = new global::System.Drawing.Point(0, 401);
		this.vmethod_38().Name = "ssTransferStatus";
		this.vmethod_38().Padding = new global::System.Windows.Forms.Padding(1, 0, 7, 0);
		this.vmethod_38().Size = new global::System.Drawing.Size(979, 20);
		this.vmethod_38().SizingGrip = false;
		this.vmethod_38().Stretch = false;
		this.vmethod_38().TabIndex = 30;
		this.vmethod_38().Text = "stStatus";
		this.vmethod_40().AutoSize = false;
		this.vmethod_40().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_40().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_40().Name = "tsFilesCount";
		this.vmethod_40().Size = new global::System.Drawing.Size(160, 15);
		this.vmethod_40().Text = "Files: 0";
		this.vmethod_40().TextAlign = global::System.Drawing.ContentAlignment.TopLeft;
		this.vmethod_68().AutoSize = false;
		this.vmethod_68().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_68().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_68().Name = "tsFilesSize";
		this.vmethod_68().Size = new global::System.Drawing.Size(160, 15);
		this.vmethod_68().Text = "Size: 0 B";
		this.vmethod_68().TextAlign = global::System.Drawing.ContentAlignment.TopLeft;
		this.vmethod_54().AutoSize = false;
		this.vmethod_54().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_54().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_54().Name = "tsFilesSelected";
		this.vmethod_54().Size = new global::System.Drawing.Size(160, 15);
		this.vmethod_54().Text = "Selected: 0";
		this.vmethod_54().TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
		this.vmethod_42().AutoSize = false;
		this.vmethod_42().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_42().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_42().Name = "tsTransfers";
		this.vmethod_42().Overflow = global::System.Windows.Forms.ToolStripItemOverflow.Never;
		this.vmethod_42().Size = new global::System.Drawing.Size(120, 15);
		this.vmethod_42().Text = "Transfers: 0/0";
		this.vmethod_42().TextAlign = global::System.Drawing.ContentAlignment.TopLeft;
		this.vmethod_48().AutoSize = false;
		this.vmethod_48().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_48().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_48().Name = "tsCompleted";
		this.vmethod_48().Size = new global::System.Drawing.Size(120, 15);
		this.vmethod_48().Text = "Completed: 0";
		this.vmethod_48().TextAlign = global::System.Drawing.ContentAlignment.TopLeft;
		this.vmethod_52().AutoSize = false;
		this.vmethod_52().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_52().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_52().Name = "tsCancelled";
		this.vmethod_52().Size = new global::System.Drawing.Size(120, 15);
		this.vmethod_52().Text = "Cancelled: 0";
		this.vmethod_52().TextAlign = global::System.Drawing.ContentAlignment.TopLeft;
		this.vmethod_50().AutoSize = false;
		this.vmethod_50().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_50().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_50().Margin = new global::System.Windows.Forms.Padding(0, 3, -6, 2);
		this.vmethod_50().Name = "tsFailed";
		this.vmethod_50().Size = new global::System.Drawing.Size(137, 15);
		this.vmethod_50().Spring = true;
		this.vmethod_50().Text = "Failed: 0";
		this.vmethod_50().TextAlign = global::System.Drawing.ContentAlignment.TopLeft;
		this.vmethod_44().Enabled = true;
		this.vmethod_44().Interval = 1000;
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new global::System.Drawing.Size(979, 421);
		base.Controls.Add(this.vmethod_38());
		base.Controls.Add(this.vmethod_20());
		this.DoubleBuffered = true;
		base.Margin = new global::System.Windows.Forms.Padding(2);
		base.Name = "fTransferManager";
		base.Opacity = 0.0;
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterParent;
		this.Text = "Transfer manager";
		this.vmethod_0().ResumeLayout(false);
		this.vmethod_20().EndInit();
		this.vmethod_38().ResumeLayout(false);
		this.vmethod_38().PerformLayout();
		base.ResumeLayout(false);
	}

	// Token: 0x040008C7 RID: 2247
	private global::System.ComponentModel.IContainer icontainer_0;
}
