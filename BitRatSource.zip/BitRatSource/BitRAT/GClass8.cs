﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

// Token: 0x0200018A RID: 394
public sealed class GClass8
{
	// Token: 0x0600160A RID: 5642 RVA: 0x0000B464 File Offset: 0x00009664
	public GClass8(int int_1, bool bool_2)
	{
		this.manualResetEvent_0 = new ManualResetEvent(false);
		this.int_0 = int_1;
		this.bool_0 = bool_2;
	}

	// Token: 0x0600160B RID: 5643 RVA: 0x000A802C File Offset: 0x000A622C
	public void method_0(GClass8.GDelegate8 gdelegate8_1)
	{
		GClass8.GDelegate8 gdelegate = this.gdelegate8_0;
		GClass8.GDelegate8 gdelegate2;
		do
		{
			gdelegate2 = gdelegate;
			GClass8.GDelegate8 value = (GClass8.GDelegate8)Delegate.Combine(gdelegate2, gdelegate8_1);
			gdelegate = Interlocked.CompareExchange<GClass8.GDelegate8>(ref this.gdelegate8_0, value, gdelegate2);
		}
		while (gdelegate != gdelegate2);
	}

	// Token: 0x0600160C RID: 5644 RVA: 0x000A8064 File Offset: 0x000A6264
	public void method_1(GClass8.GDelegate8 gdelegate8_1)
	{
		GClass8.GDelegate8 gdelegate = this.gdelegate8_0;
		GClass8.GDelegate8 gdelegate2;
		do
		{
			gdelegate2 = gdelegate;
			GClass8.GDelegate8 value = (GClass8.GDelegate8)Delegate.Remove(gdelegate2, gdelegate8_1);
			gdelegate = Interlocked.CompareExchange<GClass8.GDelegate8>(ref this.gdelegate8_0, value, gdelegate2);
		}
		while (gdelegate != gdelegate2);
	}

	// Token: 0x0600160D RID: 5645 RVA: 0x000A809C File Offset: 0x000A629C
	public void method_2()
	{
		IPEndPoint localEP = new IPEndPoint(Class130.ipaddress_0, this.int_0);
		if (this.bool_1)
		{
			this.bool_1 = false;
			return;
		}
		this.socket_0 = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
		try
		{
			this.socket_0.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
			this.socket_0.LingerState.Enabled = true;
			this.socket_0.Bind(localEP);
			this.socket_0.Listen(int.MaxValue);
			this.socket_0.BeginAccept(new AsyncCallback(this.method_4), this.socket_0);
		}
		catch (ThreadAbortException ex)
		{
		}
		catch (Exception ex2)
		{
			Interaction.MsgBox("Error while attempting to start the socket (" + ex2.Message + ").", MsgBoxStyle.Critical, Application.ProductName);
		}
	}

	// Token: 0x0600160E RID: 5646 RVA: 0x0000B486 File Offset: 0x00009686
	public void method_3()
	{
		this.socket_0.Close();
		this.bool_1 = true;
	}

	// Token: 0x0600160F RID: 5647 RVA: 0x000A8194 File Offset: 0x000A6394
	private void method_4(IAsyncResult iasyncResult_0)
	{
		Socket socket = (Socket)iasyncResult_0.AsyncState;
		try
		{
			Socket socket2 = socket.EndAccept(iasyncResult_0);
			if (this.bool_1)
			{
				socket2.Shutdown(SocketShutdown.Both);
				socket2.Close();
			}
			else
			{
				string string_ = this.method_5();
				IPEndPoint ipendPoint = (IPEndPoint)socket2.RemoteEndPoint;
				IPEndPoint ipendPoint2 = (IPEndPoint)socket2.LocalEndPoint;
				if (Conversions.ToBoolean(Operators.NotObject(Class136.smethod_4(ipendPoint.Address.ToString()))))
				{
					Class130.fConnectionLog_0.method_1(ipendPoint.Address.ToString() + ":" + ipendPoint.Port.ToString(), Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Interaction.IIf(this.bool_0, "TLS 1.2", "Tor"), ", src: "), ipendPoint2.Port)), 0);
					GClass8.GDelegate8 gdelegate = this.gdelegate8_0;
					if (gdelegate != null)
					{
						gdelegate(new GClass1(socket2, string_, this.bool_0));
					}
				}
				else
				{
					socket2.Shutdown(SocketShutdown.Both);
					socket2.Close();
				}
			}
		}
		catch (Exception ex)
		{
		}
		try
		{
			socket.BeginAccept(new AsyncCallback(this.method_4), socket);
		}
		catch (Exception ex2)
		{
		}
	}

	// Token: 0x06001610 RID: 5648 RVA: 0x000A82F4 File Offset: 0x000A64F4
	private string method_5()
	{
		return Guid.NewGuid().ToString();
	}

	// Token: 0x04000855 RID: 2133
	private readonly bool bool_0;

	// Token: 0x04000856 RID: 2134
	public int int_0;

	// Token: 0x04000857 RID: 2135
	private GClass8.GDelegate8 gdelegate8_0;

	// Token: 0x04000858 RID: 2136
	private bool bool_1;

	// Token: 0x04000859 RID: 2137
	private Socket socket_0;

	// Token: 0x0400085A RID: 2138
	public ManualResetEvent manualResetEvent_0;

	// Token: 0x0200018B RID: 395
	// (Invoke) Token: 0x06001614 RID: 5652
	public delegate void GDelegate8(GClass1 gclass1_0);
}
