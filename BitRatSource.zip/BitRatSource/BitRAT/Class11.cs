﻿using System;
using System.Threading;

// Token: 0x02000017 RID: 23
internal static class Class11
{
	// Token: 0x060001B7 RID: 439 RVA: 0x00003763 File Offset: 0x00001963
	public static Interface7 smethod_0()
	{
		return Class11.smethod_1() ?? new Class19();
	}

	// Token: 0x060001B8 RID: 440 RVA: 0x0001A670 File Offset: 0x00018870
	private static Interface7 smethod_1()
	{
		Interface7 result;
		try
		{
			Class81 @class = new Class81();
			if (!Class11.smethod_3(@class))
			{
				@class.Dispose();
				result = null;
			}
			else
			{
				result = @class;
			}
		}
		catch (Exception exception_) when (!Class11.smethod_2(exception_))
		{
			result = null;
		}
		return result;
	}

	// Token: 0x060001B9 RID: 441 RVA: 0x00003773 File Offset: 0x00001973
	private static bool smethod_2(Exception exception_0)
	{
		return exception_0 is ThreadAbortException || exception_0 is ThreadInterruptedException;
	}

	// Token: 0x060001BA RID: 442 RVA: 0x0001A6C8 File Offset: 0x000188C8
	private static bool smethod_3(Interface7 interface7_0)
	{
		byte[] array = new byte[]
		{
			0,
			130,
			byte.MaxValue
		};
		for (int i = 0; i < array.Length; i++)
		{
			byte b = array[i];
			interface7_0.imethod_2(i, ref b);
		}
		if (interface7_0.imethod_0() != array.Length)
		{
			return false;
		}
		for (int j = 0; j < array.Length; j++)
		{
			byte b2;
			interface7_0.imethod_1(j, out b2);
			if (b2 != array[j])
			{
				return false;
			}
		}
		interface7_0.imethod_3();
		return interface7_0.imethod_0() == 0;
	}
}
