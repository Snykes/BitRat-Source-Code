﻿using System;

// Token: 0x0200005A RID: 90
internal static class Class57
{
	// Token: 0x0600033E RID: 830 RVA: 0x0001F870 File Offset: 0x0001DA70
	public static int smethod_0(string string_0)
	{
		object[] object_ = new object[]
		{
			string_0
		};
		return (int)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O=m*?6\">", object_);
	}

	// Token: 0x0600033F RID: 831 RVA: 0x0001F8A8 File Offset: 0x0001DAA8
	public static int smethod_1(int int_0)
	{
		object[] object_ = new object[]
		{
			int_0
		};
		return (int)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O<a*?5;*", object_);
	}

	// Token: 0x06000340 RID: 832 RVA: 0x0001F8E4 File Offset: 0x0001DAE4
	public static int smethod_2(int? nullable_0)
	{
		object[] object_ = new object[]
		{
			nullable_0
		};
		return (int)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O=k*?5,%", object_);
	}
}
