﻿using System;

// Token: 0x02000034 RID: 52
internal interface Interface1
{
	// Token: 0x06000285 RID: 645
	string imethod_0();

	// Token: 0x06000286 RID: 646
	void imethod_1(bool bool_0, Interface2 interface2_0);

	// Token: 0x06000287 RID: 647
	int imethod_2();

	// Token: 0x06000288 RID: 648
	int imethod_3(int int_0);

	// Token: 0x06000289 RID: 649
	int imethod_4(int int_0);

	// Token: 0x0600028A RID: 650
	byte[] imethod_5(byte[] byte_0);

	// Token: 0x0600028B RID: 651
	byte[] imethod_6(byte[] byte_0, int int_0, int int_1);

	// Token: 0x0600028C RID: 652
	int imethod_7(byte[] byte_0, byte[] byte_1, int int_0);

	// Token: 0x0600028D RID: 653
	int imethod_8(byte[] byte_0, int int_0, int int_1, byte[] byte_1, int int_2);

	// Token: 0x0600028E RID: 654
	byte[] imethod_9();

	// Token: 0x0600028F RID: 655
	byte[] imethod_10(byte[] byte_0);

	// Token: 0x06000290 RID: 656
	byte[] imethod_11(byte[] byte_0, int int_0, int int_1);

	// Token: 0x06000291 RID: 657
	int imethod_12(byte[] byte_0, int int_0);

	// Token: 0x06000292 RID: 658
	int imethod_13(byte[] byte_0, byte[] byte_1, int int_0);

	// Token: 0x06000293 RID: 659
	int imethod_14(byte[] byte_0, int int_0, int int_1, byte[] byte_1, int int_2);

	// Token: 0x06000294 RID: 660
	void imethod_15();
}
