﻿using System;

namespace BitRAT
{
	// Token: 0x020001EB RID: 491
	public class cTransfer
	{
		// Token: 0x06001B0B RID: 6923 RVA: 0x000BBE48 File Offset: 0x000BA048
		public cTransfer()
		{
			this.idxValues = new string[9];
			this.m_group_id = "N/A";
			this.m_user_key = "N/A";
			this.m_user = "N/A";
			this.m_file = "N/A";
			this.m_size = "N/A";
			this.m_size_bytes = 0L;
			this.m_progress = "N/A";
			this.m_status = "N/A";
			this.m_speed = "N/A";
			this.m_elapsed = "N/A";
			this.m_eta = "N/A";
			this.m_direction = "N/A";
		}

		// Token: 0x170000A0 RID: 160
		// (get) Token: 0x06001B0C RID: 6924 RVA: 0x0000DD82 File Offset: 0x0000BF82
		// (set) Token: 0x06001B0D RID: 6925 RVA: 0x0000DD8A File Offset: 0x0000BF8A
		public string GROUP_ID
		{
			get
			{
				return this.m_group_id;
			}
			set
			{
				this.m_group_id = value;
			}
		}

		// Token: 0x170000A1 RID: 161
		// (get) Token: 0x06001B0E RID: 6926 RVA: 0x0000DD93 File Offset: 0x0000BF93
		// (set) Token: 0x06001B0F RID: 6927 RVA: 0x0000DD9B File Offset: 0x0000BF9B
		public string USER_KEY
		{
			get
			{
				return this.m_user_key;
			}
			set
			{
				this.m_user_key = value;
			}
		}

		// Token: 0x170000A2 RID: 162
		// (get) Token: 0x06001B10 RID: 6928 RVA: 0x0000DDA4 File Offset: 0x0000BFA4
		// (set) Token: 0x06001B11 RID: 6929 RVA: 0x0000DDAE File Offset: 0x0000BFAE
		public string USER
		{
			get
			{
				return this.idxValues[0];
			}
			set
			{
				this.idxValues[0] = value;
			}
		}

		// Token: 0x170000A3 RID: 163
		// (get) Token: 0x06001B12 RID: 6930 RVA: 0x0000DDB9 File Offset: 0x0000BFB9
		// (set) Token: 0x06001B13 RID: 6931 RVA: 0x0000DDC3 File Offset: 0x0000BFC3
		public string FILE
		{
			get
			{
				return this.idxValues[1];
			}
			set
			{
				this.idxValues[1] = value;
			}
		}

		// Token: 0x170000A4 RID: 164
		// (get) Token: 0x06001B14 RID: 6932 RVA: 0x0000DDCE File Offset: 0x0000BFCE
		// (set) Token: 0x06001B15 RID: 6933 RVA: 0x0000DDD8 File Offset: 0x0000BFD8
		public string SIZE
		{
			get
			{
				return this.idxValues[2];
			}
			set
			{
				this.idxValues[2] = value;
			}
		}

		// Token: 0x170000A5 RID: 165
		// (get) Token: 0x06001B16 RID: 6934 RVA: 0x0000DDE3 File Offset: 0x0000BFE3
		// (set) Token: 0x06001B17 RID: 6935 RVA: 0x0000DDEB File Offset: 0x0000BFEB
		public long SIZE_BYTES
		{
			get
			{
				return this.m_size_bytes;
			}
			set
			{
				this.m_size_bytes = value;
			}
		}

		// Token: 0x170000A6 RID: 166
		// (get) Token: 0x06001B18 RID: 6936 RVA: 0x0000DDF4 File Offset: 0x0000BFF4
		// (set) Token: 0x06001B19 RID: 6937 RVA: 0x0000DDFE File Offset: 0x0000BFFE
		public string PROGRESS
		{
			get
			{
				return this.idxValues[3];
			}
			set
			{
				this.idxValues[3] = value;
			}
		}

		// Token: 0x170000A7 RID: 167
		// (get) Token: 0x06001B1A RID: 6938 RVA: 0x0000DE09 File Offset: 0x0000C009
		// (set) Token: 0x06001B1B RID: 6939 RVA: 0x0000DE13 File Offset: 0x0000C013
		public string SPEED
		{
			get
			{
				return this.idxValues[4];
			}
			set
			{
				this.idxValues[4] = value;
			}
		}

		// Token: 0x170000A8 RID: 168
		// (get) Token: 0x06001B1C RID: 6940 RVA: 0x0000DE1E File Offset: 0x0000C01E
		// (set) Token: 0x06001B1D RID: 6941 RVA: 0x0000DE28 File Offset: 0x0000C028
		public string STATUS
		{
			get
			{
				return this.idxValues[5];
			}
			set
			{
				this.idxValues[5] = value;
			}
		}

		// Token: 0x170000A9 RID: 169
		// (get) Token: 0x06001B1E RID: 6942 RVA: 0x0000DE33 File Offset: 0x0000C033
		// (set) Token: 0x06001B1F RID: 6943 RVA: 0x0000DE3D File Offset: 0x0000C03D
		public string ELAPSED
		{
			get
			{
				return this.idxValues[6];
			}
			set
			{
				this.idxValues[6] = value;
			}
		}

		// Token: 0x170000AA RID: 170
		// (get) Token: 0x06001B20 RID: 6944 RVA: 0x0000DE48 File Offset: 0x0000C048
		// (set) Token: 0x06001B21 RID: 6945 RVA: 0x0000DE52 File Offset: 0x0000C052
		public string ETA
		{
			get
			{
				return this.idxValues[7];
			}
			set
			{
				this.idxValues[7] = value;
			}
		}

		// Token: 0x170000AB RID: 171
		// (get) Token: 0x06001B22 RID: 6946 RVA: 0x0000DE5D File Offset: 0x0000C05D
		// (set) Token: 0x06001B23 RID: 6947 RVA: 0x0000DE67 File Offset: 0x0000C067
		public string DIRECTION
		{
			get
			{
				return this.idxValues[8];
			}
			set
			{
				this.idxValues[8] = value;
			}
		}

		// Token: 0x170000AC RID: 172
		// (get) Token: 0x06001B24 RID: 6948 RVA: 0x0000DE72 File Offset: 0x0000C072
		// (set) Token: 0x06001B25 RID: 6949 RVA: 0x0000DE7A File Offset: 0x0000C07A
		public string Tag
		{
			get
			{
				return this.m_tag;
			}
			set
			{
				this.m_tag = value;
			}
		}

		// Token: 0x04000A63 RID: 2659
		public string[] idxValues;

		// Token: 0x04000A64 RID: 2660
		public string Key;

		// Token: 0x04000A65 RID: 2661
		public string sKey;

		// Token: 0x04000A66 RID: 2662
		public bool TRANSFER_ACTIVE;

		// Token: 0x04000A67 RID: 2663
		private string m_group_id;

		// Token: 0x04000A68 RID: 2664
		private string m_user_key;

		// Token: 0x04000A69 RID: 2665
		private string m_user;

		// Token: 0x04000A6A RID: 2666
		private string m_file;

		// Token: 0x04000A6B RID: 2667
		private string m_size;

		// Token: 0x04000A6C RID: 2668
		private long m_size_bytes;

		// Token: 0x04000A6D RID: 2669
		private string m_progress;

		// Token: 0x04000A6E RID: 2670
		private string m_status;

		// Token: 0x04000A6F RID: 2671
		private string m_speed;

		// Token: 0x04000A70 RID: 2672
		private string m_elapsed;

		// Token: 0x04000A71 RID: 2673
		private string m_eta;

		// Token: 0x04000A72 RID: 2674
		private string m_direction;

		// Token: 0x04000A73 RID: 2675
		private string m_tag;

		// Token: 0x04000A74 RID: 2676
		public bool bJustConnected;

		// Token: 0x04000A75 RID: 2677
		public bool pending_dc;

		// Token: 0x04000A76 RID: 2678
		public bool pending_dc_timeout;
	}
}
