﻿using System;

// Token: 0x0200007C RID: 124
internal sealed class Class70
{
	// Token: 0x060003EB RID: 1003 RVA: 0x00004877 File Offset: 0x00002A77
	public int method_0()
	{
		return this.int_0;
	}

	// Token: 0x060003EC RID: 1004 RVA: 0x0000487F File Offset: 0x00002A7F
	public void method_1(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x060003ED RID: 1005 RVA: 0x00004888 File Offset: 0x00002A88
	public bool method_2()
	{
		return this.bool_0;
	}

	// Token: 0x060003EE RID: 1006 RVA: 0x00004890 File Offset: 0x00002A90
	public void method_3(bool bool_1)
	{
		this.bool_0 = bool_1;
	}

	// Token: 0x040001C0 RID: 448
	private int int_0;

	// Token: 0x040001C1 RID: 449
	private bool bool_0;
}
