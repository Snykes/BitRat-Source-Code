﻿using System;

// Token: 0x02000065 RID: 101
internal interface Interface6
{
	// Token: 0x0600036D RID: 877
	void imethod_0();

	// Token: 0x0600036E RID: 878
	string imethod_1();

	// Token: 0x0600036F RID: 879
	int imethod_2(byte[] byte_0, int int_0);

	// Token: 0x06000370 RID: 880
	int imethod_3(byte[] byte_0);
}
