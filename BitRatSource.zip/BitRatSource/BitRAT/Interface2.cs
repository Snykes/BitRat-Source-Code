﻿using System;

// Token: 0x0200003A RID: 58
internal interface Interface2
{
}
