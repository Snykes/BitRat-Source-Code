﻿using System;

// Token: 0x02000045 RID: 69
internal class Exception0 : Exception
{
	// Token: 0x060002E2 RID: 738 RVA: 0x0000404D File Offset: 0x0000224D
	public Exception0()
	{
	}

	// Token: 0x060002E3 RID: 739 RVA: 0x00004055 File Offset: 0x00002255
	public Exception0(string string_0) : base(string_0)
	{
	}

	// Token: 0x060002E4 RID: 740 RVA: 0x0000405E File Offset: 0x0000225E
	public Exception0(string string_0, Exception exception_0) : base(string_0, exception_0)
	{
	}
}
