﻿using System;

// Token: 0x0200008B RID: 139
internal struct Struct17
{
	// Token: 0x040001D2 RID: 466
	public int int_0;

	// Token: 0x040001D3 RID: 467
	public int int_1;
}
