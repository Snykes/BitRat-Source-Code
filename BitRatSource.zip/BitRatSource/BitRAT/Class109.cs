﻿using System;

// Token: 0x02000089 RID: 137
internal abstract class Class109 : Class106
{
	// Token: 0x0600042F RID: 1071 RVA: 0x00004AB7 File Offset: 0x00002CB7
	public Type method_2()
	{
		return this.type_1;
	}

	// Token: 0x06000430 RID: 1072 RVA: 0x00004ABF File Offset: 0x00002CBF
	public void method_3(Type type_2)
	{
		this.type_1 = type_2;
	}

	// Token: 0x06000431 RID: 1073
	public abstract object vmethod_5();

	// Token: 0x06000432 RID: 1074
	public abstract void vmethod_6(object object_0);

	// Token: 0x06000433 RID: 1075
	public abstract bool vmethod_7(Class109 class109_0);

	// Token: 0x040001D0 RID: 464
	private Type type_1;
}
