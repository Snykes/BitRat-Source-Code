﻿using System;
using System.Linq;

namespace BitRAT
{
	// Token: 0x020001DE RID: 478
	public class cFWIP
	{
		// Token: 0x06001AA2 RID: 6818 RVA: 0x000BA834 File Offset: 0x000B8A34
		public cFWIP()
		{
			this.idxValues = new string[2];
			checked
			{
				int num = this.idxValues.Count<string>() - 1;
				for (int i = 1; i <= num; i++)
				{
					this.idxValues[i] = "N/A";
				}
			}
		}

		// Token: 0x1700007A RID: 122
		// (get) Token: 0x06001AA3 RID: 6819 RVA: 0x0000DA02 File Offset: 0x0000BC02
		// (set) Token: 0x06001AA4 RID: 6820 RVA: 0x0000DA0C File Offset: 0x0000BC0C
		public string IP
		{
			get
			{
				return this.idxValues[0];
			}
			set
			{
				this.idxValues[0] = value;
			}
		}

		// Token: 0x1700007B RID: 123
		// (get) Token: 0x06001AA5 RID: 6821 RVA: 0x0000DA17 File Offset: 0x0000BC17
		// (set) Token: 0x06001AA6 RID: 6822 RVA: 0x0000DA21 File Offset: 0x0000BC21
		public string ATTEMPTS
		{
			get
			{
				return this.idxValues[1];
			}
			set
			{
				this.idxValues[1] = value;
			}
		}

		// Token: 0x1700007C RID: 124
		// (get) Token: 0x06001AA7 RID: 6823 RVA: 0x0000DA2C File Offset: 0x0000BC2C
		// (set) Token: 0x06001AA8 RID: 6824 RVA: 0x0000DA34 File Offset: 0x0000BC34
		public string Tag
		{
			get
			{
				return this.m_tag;
			}
			set
			{
				this.m_tag = value;
			}
		}

		// Token: 0x04000A1D RID: 2589
		public string[] idxValues;

		// Token: 0x04000A1E RID: 2590
		public string Key;

		// Token: 0x04000A1F RID: 2591
		private string m_tag;
	}
}
