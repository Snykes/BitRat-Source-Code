﻿using System;

// Token: 0x02000048 RID: 72
internal sealed class Class104 : Class94
{
	// Token: 0x06000303 RID: 771 RVA: 0x0000412E File Offset: 0x0000232E
	public uint method_2()
	{
		return this.uint_0;
	}

	// Token: 0x06000304 RID: 772 RVA: 0x00004136 File Offset: 0x00002336
	public void method_3(uint uint_1)
	{
		this.uint_0 = uint_1;
	}

	// Token: 0x06000305 RID: 773 RVA: 0x0000413F File Offset: 0x0000233F
	public override object vmethod_0()
	{
		return this.method_2();
	}

	// Token: 0x06000306 RID: 774 RVA: 0x0001F36C File Offset: 0x0001D56C
	public override void vmethod_1(object object_0)
	{
		if (object_0 is short)
		{
			this.method_3((uint)((short)object_0));
			return;
		}
		if (object_0 is int)
		{
			this.method_3((uint)((int)object_0));
			return;
		}
		if (object_0 is long)
		{
			this.method_3((uint)((long)object_0));
			return;
		}
		if (object_0 is ulong)
		{
			this.method_3((uint)((ulong)object_0));
			return;
		}
		if (object_0 is float)
		{
			this.method_3((uint)((float)object_0));
			return;
		}
		if (object_0 is double)
		{
			this.method_3((uint)((double)object_0));
			return;
		}
		this.method_3(Convert.ToUInt32(object_0));
	}

	// Token: 0x06000307 RID: 775 RVA: 0x0000414C File Offset: 0x0000234C
	public override Class94 vmethod_4()
	{
		Class104 @class = new Class104();
		@class.method_3(this.uint_0);
		@class.method_1(base.method_0());
		return @class;
	}

	// Token: 0x06000308 RID: 776 RVA: 0x0000416B File Offset: 0x0000236B
	public override int vmethod_2()
	{
		return 21;
	}

	// Token: 0x06000309 RID: 777 RVA: 0x0001F408 File Offset: 0x0001D608
	public override Class94 vmethod_3(Class94 class94_0)
	{
		base.method_1(class94_0.method_0());
		switch (class94_0.vmethod_2())
		{
		case 0:
			this.method_3((uint)((Class119)class94_0).method_2());
			return this;
		case 2:
			this.method_3((uint)Convert.ToByte(((Class103)class94_0).method_2()));
			return this;
		case 4:
			this.method_3(Convert.ToUInt32(((Class102)class94_0).method_2()));
			return this;
		case 7:
			this.method_3((uint)((Class118)class94_0).method_2());
			return this;
		case 8:
			this.method_3((uint)((Class100)class94_0).method_2());
			return this;
		case 9:
			this.method_3((uint)((Class115)class94_0).method_2());
			return this;
		case 10:
			this.method_3((uint)((Class114)class94_0).method_2());
			return this;
		case 11:
			this.method_3((uint)((Class99)class94_0).method_2());
			return this;
		case 14:
			this.method_3((uint)((int)((Class105)class94_0).method_2()));
			return this;
		case 15:
			this.method_3((uint)((Class101)class94_0).method_2());
			return this;
		case 17:
			this.method_3((uint)((Class117)class94_0).method_2());
			return this;
		case 19:
			this.method_3((uint)((Class120)class94_0).method_2());
			return this;
		case 21:
			this.method_3(((Class104)class94_0).method_2());
			return this;
		case 22:
			this.method_3((uint)((Class121)class94_0).method_2());
			return this;
		case 24:
			this.method_3(Convert.ToUInt32(((Class98)class94_0).method_2()));
			return this;
		}
		throw new ArgumentOutOfRangeException();
	}

	// Token: 0x04000188 RID: 392
	private uint uint_0;
}
