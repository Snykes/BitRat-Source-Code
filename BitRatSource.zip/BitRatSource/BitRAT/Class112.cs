﻿using System;

// Token: 0x0200009C RID: 156
internal sealed class Class112 : Class106
{
	// Token: 0x060004BF RID: 1215 RVA: 0x00004F81 File Offset: 0x00003181
	public Class94 method_2()
	{
		return this.class94_0;
	}

	// Token: 0x060004C0 RID: 1216 RVA: 0x00004F89 File Offset: 0x00003189
	public void method_3(Class94 class94_1)
	{
		this.class94_0 = class94_1;
	}

	// Token: 0x060004C1 RID: 1217 RVA: 0x00004F92 File Offset: 0x00003192
	public override int vmethod_2()
	{
		return 12;
	}

	// Token: 0x060004C2 RID: 1218 RVA: 0x00023068 File Offset: 0x00021268
	public override Class94 vmethod_3(Class94 class94_1)
	{
		base.method_1(class94_1.method_0());
		int num = class94_1.vmethod_2();
		if (num == 12)
		{
			this.method_3(((Class112)class94_1).method_2());
			return this;
		}
		throw new ArgumentOutOfRangeException();
	}

	// Token: 0x060004C3 RID: 1219 RVA: 0x00004F96 File Offset: 0x00003196
	public override Class94 vmethod_4()
	{
		Class112 @class = new Class112();
		@class.method_3(this.method_2());
		@class.method_1(base.method_0());
		return @class;
	}

	// Token: 0x040001EE RID: 494
	private Class94 class94_0;
}
