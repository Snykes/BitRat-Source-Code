﻿// Token: 0x020001BF RID: 447
[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
public sealed partial class fSplash : global::System.Windows.Forms.Form
{
	// Token: 0x06001864 RID: 6244 RVA: 0x000B1A4C File Offset: 0x000AFC4C
	[global::System.Diagnostics.DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && this.icontainer_0 != null)
			{
				this.icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	// Token: 0x06001865 RID: 6245 RVA: 0x000B1A8C File Offset: 0x000AFC8C
	[global::System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		this.vmethod_1(new global::System.Windows.Forms.Timer(this.icontainer_0));
		this.vmethod_3(new global::System.ComponentModel.BackgroundWorker());
		this.vmethod_5(new global::VisualPlus.Toolkit.Controls.Interactivity.VisualLabel());
		this.vmethod_7(new global::VisualPlus.Toolkit.Controls.Interactivity.VisualLabel());
		this.vmethod_11(new global::System.Windows.Forms.Timer(this.icontainer_0));
		this.vmethod_15(new global::VisualPlus.Toolkit.Controls.Interactivity.VisualLabel());
		this.vmethod_13(new global::System.Windows.Forms.PictureBox());
		this.vmethod_9(new global::System.Windows.Forms.PictureBox());
		this.vmethod_17(new global::System.ComponentModel.BackgroundWorker());
		this.vmethod_19(new global::System.ComponentModel.BackgroundWorker());
		this.vmethod_21(new global::VisualPlus.Toolkit.Controls.Interactivity.VisualLabel());
		this.vmethod_23(new global::VisualPlus.Toolkit.Controls.Interactivity.VisualLabel());
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_12()).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_8()).BeginInit();
		base.SuspendLayout();
		this.vmethod_0().Enabled = true;
		this.vmethod_0().Interval = 1;
		this.vmethod_4().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_4().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_4().ForeColor = global::System.Drawing.Color.White;
		this.vmethod_4().Location = new global::System.Drawing.Point(11, 314);
		this.vmethod_4().MouseState = 0;
		this.vmethod_4().Name = "lblStatus";
		this.vmethod_4().Orientation = global::System.Windows.Forms.Orientation.Horizontal;
		this.vmethod_4().Outline = false;
		this.vmethod_4().OutlineColor = global::System.Drawing.Color.Red;
		this.vmethod_4().OutlineLocation = new global::System.Drawing.Point(0, 0);
		this.vmethod_4().ReflectionColor = global::System.Drawing.Color.FromArgb(120, 0, 0, 0);
		this.vmethod_4().ReflectionSpacing = 0;
		this.vmethod_4().ShadowColor = global::System.Drawing.Color.Black;
		this.vmethod_4().ShadowDirection = 315;
		this.vmethod_4().ShadowLocation = new global::System.Drawing.Point(0, 0);
		this.vmethod_4().ShadowOpacity = 100;
		this.vmethod_4().Size = new global::System.Drawing.Size(592, 18);
		this.vmethod_4().TabIndex = 0;
		this.vmethod_4().Text = "Loading...";
		this.vmethod_4().TextAlignment = global::System.Drawing.StringAlignment.Near;
		this.vmethod_4().TextLineAlignment = global::System.Drawing.StringAlignment.Far;
		this.vmethod_4().TextStyle.Disabled = global::System.Drawing.Color.FromArgb(131, 129, 129);
		this.vmethod_4().TextStyle.Enabled = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_4().TextStyle.Hover = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_4().TextStyle.Pressed = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_4().TextStyle.TextAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_4().TextStyle.TextLineAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_4().TextStyle.TextRenderingHint = global::System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
		this.vmethod_6().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_6().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_6().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 14.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_6().ForeColor = global::System.Drawing.Color.White;
		this.vmethod_6().Location = new global::System.Drawing.Point(11, 194);
		this.vmethod_6().MouseState = 0;
		this.vmethod_6().Name = "lblLicenseStatus";
		this.vmethod_6().Orientation = global::System.Windows.Forms.Orientation.Horizontal;
		this.vmethod_6().Outline = false;
		this.vmethod_6().OutlineColor = global::System.Drawing.Color.Red;
		this.vmethod_6().OutlineLocation = new global::System.Drawing.Point(0, 0);
		this.vmethod_6().ReflectionColor = global::System.Drawing.Color.FromArgb(120, 0, 0, 0);
		this.vmethod_6().ReflectionSpacing = 0;
		this.vmethod_6().ShadowColor = global::System.Drawing.Color.Black;
		this.vmethod_6().ShadowDirection = 315;
		this.vmethod_6().ShadowLocation = new global::System.Drawing.Point(0, 0);
		this.vmethod_6().ShadowOpacity = 100;
		this.vmethod_6().Size = new global::System.Drawing.Size(691, 23);
		this.vmethod_6().TabIndex = 1;
		this.vmethod_6().Text = "License status: N/A";
		this.vmethod_6().TextAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_6().TextLineAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_6().TextStyle.Disabled = global::System.Drawing.Color.FromArgb(131, 129, 129);
		this.vmethod_6().TextStyle.Enabled = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_6().TextStyle.Hover = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_6().TextStyle.Pressed = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_6().TextStyle.TextAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_6().TextStyle.TextLineAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_6().TextStyle.TextRenderingHint = global::System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
		this.vmethod_6().Visible = false;
		this.vmethod_10().Interval = 1;
		this.vmethod_14().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_14().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_14().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_14().ForeColor = global::System.Drawing.Color.White;
		this.vmethod_14().Location = new global::System.Drawing.Point(609, 314);
		this.vmethod_14().MouseState = 0;
		this.vmethod_14().Name = "lblVersion";
		this.vmethod_14().Orientation = global::System.Windows.Forms.Orientation.Horizontal;
		this.vmethod_14().Outline = false;
		this.vmethod_14().OutlineColor = global::System.Drawing.Color.Red;
		this.vmethod_14().OutlineLocation = new global::System.Drawing.Point(0, 0);
		this.vmethod_14().ReflectionColor = global::System.Drawing.Color.FromArgb(120, 0, 0, 0);
		this.vmethod_14().ReflectionSpacing = 0;
		this.vmethod_14().ShadowColor = global::System.Drawing.Color.Black;
		this.vmethod_14().ShadowDirection = 315;
		this.vmethod_14().ShadowLocation = new global::System.Drawing.Point(0, 0);
		this.vmethod_14().ShadowOpacity = 100;
		this.vmethod_14().Size = new global::System.Drawing.Size(93, 18);
		this.vmethod_14().TabIndex = 41;
		this.vmethod_14().Text = "BitRAT";
		this.vmethod_14().TextAlignment = global::System.Drawing.StringAlignment.Far;
		this.vmethod_14().TextLineAlignment = global::System.Drawing.StringAlignment.Far;
		this.vmethod_14().TextStyle.Disabled = global::System.Drawing.Color.FromArgb(131, 129, 129);
		this.vmethod_14().TextStyle.Enabled = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_14().TextStyle.Hover = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_14().TextStyle.Pressed = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_14().TextStyle.TextAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_14().TextStyle.TextLineAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_14().TextStyle.TextRenderingHint = global::System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
		this.vmethod_12().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_12().Image = global::Class131.smethod_30();
		this.vmethod_12().Location = new global::System.Drawing.Point(301, 64);
		this.vmethod_12().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_12().Name = "pbLogo";
		this.vmethod_12().Size = new global::System.Drawing.Size(125, 125);
		this.vmethod_12().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_12().TabIndex = 40;
		this.vmethod_12().TabStop = false;
		this.vmethod_8().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_8().Image = global::Class131.smethod_36();
		this.vmethod_8().Location = new global::System.Drawing.Point(694, 4);
		this.vmethod_8().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_8().Name = "pbExit";
		this.vmethod_8().Size = new global::System.Drawing.Size(16, 16);
		this.vmethod_8().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.AutoSize;
		this.vmethod_8().TabIndex = 39;
		this.vmethod_8().TabStop = false;
		this.vmethod_20().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_20().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_20().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Italic, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_20().ForeColor = global::System.Drawing.Color.Orange;
		this.vmethod_20().Location = new global::System.Drawing.Point(15, 235);
		this.vmethod_20().MouseState = 0;
		this.vmethod_20().Name = "lblPhraseRU";
		this.vmethod_20().Orientation = global::System.Windows.Forms.Orientation.Horizontal;
		this.vmethod_20().Outline = false;
		this.vmethod_20().OutlineColor = global::System.Drawing.Color.Red;
		this.vmethod_20().OutlineLocation = new global::System.Drawing.Point(0, 0);
		this.vmethod_20().ReflectionColor = global::System.Drawing.Color.FromArgb(120, 0, 0, 0);
		this.vmethod_20().ReflectionSpacing = 0;
		this.vmethod_20().ShadowColor = global::System.Drawing.Color.Black;
		this.vmethod_20().ShadowDirection = 315;
		this.vmethod_20().ShadowLocation = new global::System.Drawing.Point(0, 0);
		this.vmethod_20().ShadowOpacity = 100;
		this.vmethod_20().Size = new global::System.Drawing.Size(686, 18);
		this.vmethod_20().TabIndex = 46;
		this.vmethod_20().Text = "Russian";
		this.vmethod_20().TextAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_20().TextLineAlignment = global::System.Drawing.StringAlignment.Far;
		this.vmethod_20().TextStyle.Disabled = global::System.Drawing.Color.FromArgb(131, 129, 129);
		this.vmethod_20().TextStyle.Enabled = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_20().TextStyle.Hover = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_20().TextStyle.Pressed = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_20().TextStyle.TextAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_20().TextStyle.TextLineAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_20().TextStyle.TextRenderingHint = global::System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
		this.vmethod_20().Visible = false;
		this.vmethod_22().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_22().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_22().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Italic, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_22().ForeColor = global::System.Drawing.Color.White;
		this.vmethod_22().Location = new global::System.Drawing.Point(15, 251);
		this.vmethod_22().MouseState = 0;
		this.vmethod_22().Name = "lblPhraseEN";
		this.vmethod_22().Orientation = global::System.Windows.Forms.Orientation.Horizontal;
		this.vmethod_22().Outline = false;
		this.vmethod_22().OutlineColor = global::System.Drawing.Color.Red;
		this.vmethod_22().OutlineLocation = new global::System.Drawing.Point(0, 0);
		this.vmethod_22().ReflectionColor = global::System.Drawing.Color.FromArgb(120, 0, 0, 0);
		this.vmethod_22().ReflectionSpacing = 0;
		this.vmethod_22().ShadowColor = global::System.Drawing.Color.Black;
		this.vmethod_22().ShadowDirection = 315;
		this.vmethod_22().ShadowLocation = new global::System.Drawing.Point(0, 0);
		this.vmethod_22().ShadowOpacity = 100;
		this.vmethod_22().Size = new global::System.Drawing.Size(686, 18);
		this.vmethod_22().TabIndex = 47;
		this.vmethod_22().Text = "English";
		this.vmethod_22().TextAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_22().TextLineAlignment = global::System.Drawing.StringAlignment.Far;
		this.vmethod_22().TextStyle.Disabled = global::System.Drawing.Color.FromArgb(131, 129, 129);
		this.vmethod_22().TextStyle.Enabled = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_22().TextStyle.Hover = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_22().TextStyle.Pressed = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_22().TextStyle.TextAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_22().TextStyle.TextLineAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_22().TextStyle.TextRenderingHint = global::System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
		this.vmethod_22().Visible = false;
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = global::System.Drawing.Color.FromArgb(45, 45, 48);
		base.ClientSize = new global::System.Drawing.Size(714, 344);
		base.ControlBox = false;
		base.Controls.Add(this.vmethod_22());
		base.Controls.Add(this.vmethod_20());
		base.Controls.Add(this.vmethod_12());
		base.Controls.Add(this.vmethod_8());
		base.Controls.Add(this.vmethod_6());
		base.Controls.Add(this.vmethod_4());
		base.Controls.Add(this.vmethod_14());
		this.DoubleBuffered = true;
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "fSplash";
		base.Opacity = 0.0;
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		base.SizeGripStyle = global::System.Windows.Forms.SizeGripStyle.Hide;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
		base.TopMost = true;
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_12()).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_8()).EndInit();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x04000919 RID: 2329
	private global::System.ComponentModel.IContainer icontainer_0;
}
