﻿using System;
using System.ComponentModel;
using System.Diagnostics;

// Token: 0x0200005C RID: 92
internal static class Class59
{
	// Token: 0x06000341 RID: 833 RVA: 0x00004274 File Offset: 0x00002474
	[EditorBrowsable(EditorBrowsableState.Advanced)]
	[STAThread]
	[DebuggerHidden]
	private static void Main(string[] args)
	{
		Form0.smethod_0(args);
	}
}
