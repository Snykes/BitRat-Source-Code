﻿using System;
using System.Collections;
using System.Windows.Forms;

// Token: 0x02000107 RID: 263
public sealed class GClass4 : IComparer
{
	// Token: 0x06000E15 RID: 3605 RVA: 0x000084C1 File Offset: 0x000066C1
	public GClass4()
	{
		this.int_0 = 0;
		this.sortOrder_0 = SortOrder.None;
		this.caseInsensitiveComparer_0 = new CaseInsensitiveComparer();
	}

	// Token: 0x06000E16 RID: 3606 RVA: 0x000084E2 File Offset: 0x000066E2
	public int method_0()
	{
		return this.int_0;
	}

	// Token: 0x06000E17 RID: 3607 RVA: 0x000084EA File Offset: 0x000066EA
	public void method_1(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x06000E18 RID: 3608 RVA: 0x000084F3 File Offset: 0x000066F3
	public SortOrder method_2()
	{
		return this.sortOrder_0;
	}

	// Token: 0x06000E19 RID: 3609 RVA: 0x000084FB File Offset: 0x000066FB
	public void method_3(SortOrder sortOrder_1)
	{
		this.sortOrder_0 = sortOrder_1;
	}

	// Token: 0x06000E1A RID: 3610 RVA: 0x0006CE08 File Offset: 0x0006B008
	public int Compare(object x, object y)
	{
		string text = ((ListViewItem)x).SubItems[this.int_0].Text;
		string text2 = ((ListViewItem)y).SubItems[this.int_0].Text;
		int num;
		int num2;
		int num3;
		DateTime dateTime;
		DateTime dateTime2;
		if (int.TryParse(text, out num) && int.TryParse(text2, out num2))
		{
			num3 = this.caseInsensitiveComparer_0.Compare(num, num2);
		}
		else if (DateTime.TryParse(text, out dateTime) && DateTime.TryParse(text2, out dateTime2))
		{
			num3 = this.caseInsensitiveComparer_0.Compare(dateTime, dateTime2);
		}
		else
		{
			num3 = this.caseInsensitiveComparer_0.Compare(text, text2);
		}
		int result;
		if (this.sortOrder_0 == SortOrder.Ascending)
		{
			result = num3;
		}
		else if (this.sortOrder_0 == SortOrder.Descending)
		{
			result = checked(0 - num3);
		}
		else
		{
			result = 0;
		}
		return result;
	}

	// Token: 0x0400059F RID: 1439
	private int int_0;

	// Token: 0x040005A0 RID: 1440
	private SortOrder sortOrder_0;

	// Token: 0x040005A1 RID: 1441
	private CaseInsensitiveComparer caseInsensitiveComparer_0;
}
