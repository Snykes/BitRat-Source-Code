﻿// Token: 0x020000FC RID: 252
[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
public sealed partial class fStartup : global::System.Windows.Forms.Form
{
	// Token: 0x06000D2B RID: 3371 RVA: 0x000664E8 File Offset: 0x000646E8
	[global::System.Diagnostics.DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && this.icontainer_0 != null)
			{
				this.icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	// Token: 0x06000D2C RID: 3372 RVA: 0x00066528 File Offset: 0x00064728
	[global::System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::fStartup));
		this.vmethod_1(new global::SkinSoft.VisualStyler.VisualStyler(this.icontainer_0));
		this.vmethod_0().BeginInit();
		base.SuspendLayout();
		this.vmethod_0().HookVisualStyles = true;
		this.vmethod_0().HostForm = this;
		this.vmethod_0().License = (global::SkinSoft.VisualStyler.Licensing.VisualStylerLicense)componentResourceManager.GetObject("vStyle.License");
		this.vmethod_0().ShadowStyle = 0;
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new global::System.Drawing.Size(19, 18);
		base.ControlBox = false;
		this.DoubleBuffered = true;
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "fStartup";
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		base.SizeGripStyle = global::System.Windows.Forms.SizeGripStyle.Hide;
		this.Text = "fStartup";
		base.WindowState = global::System.Windows.Forms.FormWindowState.Minimized;
		this.vmethod_0().EndInit();
		base.ResumeLayout(false);
	}

	// Token: 0x0400054D RID: 1357
	private global::System.ComponentModel.IContainer icontainer_0;
}
