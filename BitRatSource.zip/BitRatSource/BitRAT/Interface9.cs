﻿using System;

// Token: 0x0200009A RID: 154
internal interface Interface9<T> : Interface8
{
	// Token: 0x060004B8 RID: 1208
	Interface4<T> imethod_1();
}
