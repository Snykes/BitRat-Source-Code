﻿using System;
using System.Reflection;
using System.Security.Cryptography;

// Token: 0x02000098 RID: 152
internal sealed class Class87 : IDisposable
{
	// Token: 0x060004A6 RID: 1190 RVA: 0x00004E9D File Offset: 0x0000309D
	public Class87()
	{
		this.method_1((Enum2)1);
	}

	// Token: 0x060004A7 RID: 1191 RVA: 0x00022DAC File Offset: 0x00020FAC
	public void Dispose()
	{
		IDisposable disposable = this.symmetricAlgorithm_0;
		if (disposable != null)
		{
			disposable.Dispose();
		}
	}

	// Token: 0x060004A8 RID: 1192 RVA: 0x00004EAC File Offset: 0x000030AC
	public Enum2 method_0()
	{
		return this.enum2_0;
	}

	// Token: 0x060004A9 RID: 1193 RVA: 0x00004EB4 File Offset: 0x000030B4
	public void method_1(Enum2 enum2_1)
	{
		if (this.enum2_0 == enum2_1)
		{
			return;
		}
		this.enum2_0 = enum2_1;
		this.bool_1 = true;
	}

	// Token: 0x060004AA RID: 1194 RVA: 0x00004ECE File Offset: 0x000030CE
	public Enum0 method_2()
	{
		return this.enum0_0;
	}

	// Token: 0x060004AB RID: 1195 RVA: 0x00004ED6 File Offset: 0x000030D6
	public void method_3(Enum0 enum0_1)
	{
		if (this.enum0_0 == enum0_1)
		{
			return;
		}
		this.enum0_0 = enum0_1;
		this.bool_1 = true;
	}

	// Token: 0x060004AC RID: 1196 RVA: 0x00004EF0 File Offset: 0x000030F0
	public byte[] method_4()
	{
		return this.byte_0;
	}

	// Token: 0x060004AD RID: 1197 RVA: 0x00004EF8 File Offset: 0x000030F8
	public void method_5(byte[] byte_2)
	{
		this.byte_0 = byte_2;
		this.bool_1 = true;
	}

	// Token: 0x060004AE RID: 1198 RVA: 0x00004F08 File Offset: 0x00003108
	public byte[] method_6()
	{
		return this.byte_1;
	}

	// Token: 0x060004AF RID: 1199 RVA: 0x00004F10 File Offset: 0x00003110
	public void method_7(byte[] byte_2)
	{
		this.byte_1 = byte_2;
		this.bool_1 = true;
	}

	// Token: 0x060004B0 RID: 1200 RVA: 0x00022DCC File Offset: 0x00020FCC
	private static SymmetricAlgorithm smethod_0()
	{
		if (Class87.type_0 != null)
		{
			if (Class87.type_0 == typeof(Class87.Class88))
			{
				return null;
			}
			return Activator.CreateInstance(Class87.type_0) as SymmetricAlgorithm;
		}
		else
		{
			Class87.type_0 = typeof(Class87.Class88);
			Assembly assembly = null;
			try
			{
				assembly = Assembly.Load("System.Core, Version=3.5.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089");
			}
			catch
			{
			}
			if (assembly == null)
			{
				return null;
			}
			try
			{
				Type type = assembly.GetType("System.Security.Cryptography.AesCryptoServiceProvider");
				if (type != null)
				{
					SymmetricAlgorithm result = Activator.CreateInstance(type) as SymmetricAlgorithm;
					Class87.type_0 = type;
					return result;
				}
			}
			catch
			{
			}
			try
			{
				Type type2 = assembly.GetType("System.Security.Cryptography.AesManaged");
				if (type2 != null)
				{
					SymmetricAlgorithm result2 = Activator.CreateInstance(type2) as SymmetricAlgorithm;
					Class87.type_0 = type2;
					return result2;
				}
			}
			catch
			{
			}
			return null;
		}
	}

	// Token: 0x060004B1 RID: 1201 RVA: 0x00004F20 File Offset: 0x00003120
	private static CipherMode smethod_1(Enum2 enum2_1)
	{
		if (enum2_1 == (Enum2)1)
		{
			return CipherMode.CBC;
		}
		throw new InvalidOperationException("Cipher mode is not supported");
	}

	// Token: 0x060004B2 RID: 1202 RVA: 0x00004F34 File Offset: 0x00003134
	private static PaddingMode smethod_2(Enum0 enum0_1)
	{
		if (enum0_1 == (Enum0)1)
		{
			return PaddingMode.None;
		}
		if (enum0_1 != (Enum0)2)
		{
			throw new InvalidOperationException("Padding mode is not supported");
		}
		return PaddingMode.PKCS7;
	}

	// Token: 0x060004B3 RID: 1203 RVA: 0x00004F4C File Offset: 0x0000314C
	public Class91 method_8()
	{
		return this.method_10(true);
	}

	// Token: 0x060004B4 RID: 1204 RVA: 0x00004F55 File Offset: 0x00003155
	public Class91 method_9()
	{
		return this.method_10(false);
	}

	// Token: 0x060004B5 RID: 1205 RVA: 0x00022ED0 File Offset: 0x000210D0
	private Class91 method_10(bool bool_2)
	{
		if (!this.bool_0)
		{
			bool flag = this.bool_1 || this.symmetricAlgorithm_0 == null;
			if (this.symmetricAlgorithm_0 == null)
			{
				this.symmetricAlgorithm_0 = Class87.smethod_0();
				if (this.symmetricAlgorithm_0 == null)
				{
					this.bool_0 = true;
				}
			}
			if (this.symmetricAlgorithm_0 != null)
			{
				if (flag)
				{
					this.symmetricAlgorithm_0.Key = this.method_4();
					this.symmetricAlgorithm_0.IV = this.method_6();
					this.symmetricAlgorithm_0.Mode = Class87.smethod_1(this.method_0());
					this.symmetricAlgorithm_0.Padding = Class87.smethod_2(this.method_2());
				}
				return new Class92(bool_2 ? this.symmetricAlgorithm_0.CreateEncryptor() : this.symmetricAlgorithm_0.CreateDecryptor());
			}
		}
		Class90 interface0_ = new Class90(new Class9());
		Class14 @class;
		if (this.method_2() != (Enum0)1)
		{
			@class = new Class15(interface0_, Class87.smethod_3(this.method_2()));
		}
		else
		{
			@class = new Class14(interface0_);
		}
		Class40 interface2_ = new Class40(new Class28(this.method_4()), this.method_6());
		@class.imethod_1(bool_2, interface2_);
		return new Class93(@class);
	}

	// Token: 0x060004B6 RID: 1206 RVA: 0x00004F5E File Offset: 0x0000315E
	private static Interface6 smethod_3(Enum0 enum0_1)
	{
		if (enum0_1 == (Enum0)1)
		{
			return null;
		}
		if (enum0_1 != (Enum0)2)
		{
			throw new InvalidOperationException("Padding mode is not supported");
		}
		return new Class89();
	}

	// Token: 0x040001E6 RID: 486
	private Enum2 enum2_0;

	// Token: 0x040001E7 RID: 487
	private Enum0 enum0_0;

	// Token: 0x040001E8 RID: 488
	private byte[] byte_0;

	// Token: 0x040001E9 RID: 489
	private byte[] byte_1;

	// Token: 0x040001EA RID: 490
	private static Type type_0;

	// Token: 0x040001EB RID: 491
	private bool bool_0;

	// Token: 0x040001EC RID: 492
	private bool bool_1;

	// Token: 0x040001ED RID: 493
	private SymmetricAlgorithm symmetricAlgorithm_0;

	// Token: 0x02000099 RID: 153
	private sealed class Class88
	{
	}
}
