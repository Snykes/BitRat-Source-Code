﻿using System;

// Token: 0x020000A0 RID: 160
internal abstract class Class94
{
	// Token: 0x060004E0 RID: 1248
	public abstract object vmethod_0();

	// Token: 0x060004E1 RID: 1249
	public abstract void vmethod_1(object object_0);

	// Token: 0x060004E2 RID: 1250
	public abstract int vmethod_2();

	// Token: 0x060004E3 RID: 1251
	public abstract Class94 vmethod_3(Class94 class94_0);

	// Token: 0x060004E4 RID: 1252
	public abstract Class94 vmethod_4();

	// Token: 0x060004E5 RID: 1253 RVA: 0x000050BE File Offset: 0x000032BE
	public Type method_0()
	{
		return this.type_0;
	}

	// Token: 0x060004E6 RID: 1254 RVA: 0x000050C6 File Offset: 0x000032C6
	public void method_1(Type type_1)
	{
		this.type_0 = type_1;
	}

	// Token: 0x040001F7 RID: 503
	private Type type_0;
}
