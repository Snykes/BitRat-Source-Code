﻿// Token: 0x0200011A RID: 282
[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
public sealed partial class fRegAdd : global::System.Windows.Forms.Form
{
	// Token: 0x06000F78 RID: 3960 RVA: 0x00072EE8 File Offset: 0x000710E8
	[global::System.Diagnostics.DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && this.icontainer_0 != null)
			{
				this.icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	// Token: 0x06000F79 RID: 3961 RVA: 0x00072F28 File Offset: 0x00071128
	[global::System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		this.vmethod_1(new global::System.Windows.Forms.TextBox());
		this.vmethod_3(new global::System.Windows.Forms.Label());
		this.vmethod_5(new global::System.Windows.Forms.Label());
		this.vmethod_7(new global::System.Windows.Forms.ComboBox());
		this.vmethod_9(new global::System.Windows.Forms.Label());
		this.vmethod_11(new global::System.Windows.Forms.TextBox());
		this.vmethod_13(new global::VisualPlus.Toolkit.Controls.Interactivity.VisualButton());
		this.vmethod_15(new global::System.Windows.Forms.StatusStrip());
		this.vmethod_17(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_19(new global::System.Windows.Forms.Timer(this.icontainer_0));
		this.vmethod_14().SuspendLayout();
		base.SuspendLayout();
		this.vmethod_0().Location = new global::System.Drawing.Point(78, 6);
		this.vmethod_0().Margin = new global::System.Windows.Forms.Padding(1);
		this.vmethod_0().MaxLength = 255;
		this.vmethod_0().Name = "txtValueName";
		this.vmethod_0().Size = new global::System.Drawing.Size(223, 20);
		this.vmethod_0().TabIndex = 19;
		this.vmethod_2().AutoSize = true;
		this.vmethod_2().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_2().FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.vmethod_2().Location = new global::System.Drawing.Point(10, 9);
		this.vmethod_2().Margin = new global::System.Windows.Forms.Padding(1, 0, 1, 0);
		this.vmethod_2().Name = "lblValueName";
		this.vmethod_2().Size = new global::System.Drawing.Size(66, 13);
		this.vmethod_2().TabIndex = 18;
		this.vmethod_2().Text = "Value name:";
		this.vmethod_2().TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
		this.vmethod_4().AutoSize = true;
		this.vmethod_4().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_4().FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.vmethod_4().Location = new global::System.Drawing.Point(303, 9);
		this.vmethod_4().Margin = new global::System.Windows.Forms.Padding(1, 0, 1, 0);
		this.vmethod_4().Name = "lblValueType";
		this.vmethod_4().Size = new global::System.Drawing.Size(60, 13);
		this.vmethod_4().TabIndex = 20;
		this.vmethod_4().Text = "Value type:";
		this.vmethod_4().TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
		this.vmethod_6().BackColor = global::System.Drawing.Color.White;
		this.vmethod_6().DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.vmethod_6().ForeColor = global::System.Drawing.Color.Black;
		this.vmethod_6().FormattingEnabled = true;
		this.vmethod_6().ImeMode = global::System.Windows.Forms.ImeMode.NoControl;
		this.vmethod_6().Location = new global::System.Drawing.Point(366, 6);
		this.vmethod_6().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_6().Name = "cbValueType";
		this.vmethod_6().Size = new global::System.Drawing.Size(173, 21);
		this.vmethod_6().TabIndex = 46;
		this.vmethod_6().TabStop = false;
		this.vmethod_8().AutoSize = true;
		this.vmethod_8().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_8().FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.vmethod_8().Location = new global::System.Drawing.Point(15, 41);
		this.vmethod_8().Margin = new global::System.Windows.Forms.Padding(1, 0, 1, 0);
		this.vmethod_8().Name = "lblValueData";
		this.vmethod_8().Size = new global::System.Drawing.Size(61, 13);
		this.vmethod_8().TabIndex = 47;
		this.vmethod_8().Text = "Value data:";
		this.vmethod_8().TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
		this.vmethod_10().Location = new global::System.Drawing.Point(78, 41);
		this.vmethod_10().MaxLength = 16383;
		this.vmethod_10().Multiline = true;
		this.vmethod_10().Name = "txtValueData";
		this.vmethod_10().Size = new global::System.Drawing.Size(461, 91);
		this.vmethod_10().TabIndex = 48;
		this.vmethod_12().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_12().BackColorState.Disabled = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_12().BackColorState.Enabled = global::System.Drawing.Color.FromArgb(220, 220, 220);
		this.vmethod_12().BackColorState.Hover = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_12().BackColorState.Pressed = global::System.Drawing.Color.FromArgb(192, 192, 192);
		this.vmethod_12().Border.Color = global::System.Drawing.Color.FromArgb(180, 180, 180);
		this.vmethod_12().Border.HoverColor = global::System.Drawing.Color.FromArgb(120, 183, 230);
		this.vmethod_12().Border.HoverVisible = true;
		this.vmethod_12().Border.Rounding = 6;
		this.vmethod_12().Border.Thickness = 1;
		this.vmethod_12().Border.Type = 1;
		this.vmethod_12().Border.Visible = true;
		this.vmethod_12().DialogResult = global::System.Windows.Forms.DialogResult.None;
		this.vmethod_12().ForeColor = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_12().Image = null;
		this.vmethod_12().Location = new global::System.Drawing.Point(471, 138);
		this.vmethod_12().MouseState = 0;
		this.vmethod_12().Name = "btnAdd";
		this.vmethod_12().Size = new global::System.Drawing.Size(68, 19);
		this.vmethod_12().TabIndex = 49;
		this.vmethod_12().Text = "Add";
		this.vmethod_12().TextImageRelation = global::System.Windows.Forms.TextImageRelation.Overlay;
		this.vmethod_12().TextStyle.Disabled = global::System.Drawing.Color.FromArgb(131, 129, 129);
		this.vmethod_12().TextStyle.Enabled = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_12().TextStyle.Hover = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_12().TextStyle.Pressed = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_12().TextStyle.TextAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_12().TextStyle.TextLineAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_12().TextStyle.TextRenderingHint = global::System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
		this.vmethod_14().AutoSize = false;
		this.vmethod_14().BackColor = global::System.Drawing.Color.FromArgb(235, 237, 239);
		this.vmethod_14().ImageScalingSize = new global::System.Drawing.Size(28, 28);
		this.vmethod_14().Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_16()
		});
		this.vmethod_14().Location = new global::System.Drawing.Point(0, 161);
		this.vmethod_14().Name = "ssStatus";
		this.vmethod_14().Padding = new global::System.Windows.Forms.Padding(1, 0, 7, 0);
		this.vmethod_14().Size = new global::System.Drawing.Size(541, 19);
		this.vmethod_14().SizingGrip = false;
		this.vmethod_14().Stretch = false;
		this.vmethod_14().TabIndex = 50;
		this.vmethod_14().Text = "stStatus";
		this.vmethod_16().AutoSize = false;
		this.vmethod_16().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_16().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_16().Margin = new global::System.Windows.Forms.Padding(0, 3, -6, 0);
		this.vmethod_16().Name = "tsPath";
		this.vmethod_16().Size = new global::System.Drawing.Size(539, 16);
		this.vmethod_16().Spring = true;
		this.vmethod_16().Text = "Path: N/A";
		this.vmethod_16().TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
		this.vmethod_18().Enabled = true;
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = global::System.Drawing.SystemColors.AppWorkspace;
		base.ClientSize = new global::System.Drawing.Size(541, 180);
		base.Controls.Add(this.vmethod_14());
		base.Controls.Add(this.vmethod_12());
		base.Controls.Add(this.vmethod_10());
		base.Controls.Add(this.vmethod_8());
		base.Controls.Add(this.vmethod_6());
		base.Controls.Add(this.vmethod_4());
		base.Controls.Add(this.vmethod_0());
		base.Controls.Add(this.vmethod_2());
		this.DoubleBuffered = true;
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedToolWindow;
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "fRegAdd";
		base.Opacity = 0.0;
		base.ShowIcon = false;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterParent;
		this.Text = "Registry - Add value";
		base.TopMost = true;
		this.vmethod_14().ResumeLayout(false);
		this.vmethod_14().PerformLayout();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x0400060F RID: 1551
	private global::System.ComponentModel.IContainer icontainer_0;
}
