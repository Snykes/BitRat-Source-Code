﻿using System;

// Token: 0x0200008F RID: 143
internal static class Class83
{
	// Token: 0x0600045C RID: 1116 RVA: 0x00004BD8 File Offset: 0x00002DD8
	public static void smethod_0(ref byte byte_0)
	{
		byte_0 = (byte)Class83.int_0;
		Class83.int_1 = (int)byte_0;
	}

	// Token: 0x0600045D RID: 1117 RVA: 0x00004BED File Offset: 0x00002DED
	public static void smethod_1(ref int int_2)
	{
		int_2 = Class83.int_0;
		Class83.int_1 = int_2;
	}

	// Token: 0x0600045E RID: 1118 RVA: 0x00004C01 File Offset: 0x00002E01
	public static void smethod_2(ref long long_0)
	{
		long_0 = (long)Class83.int_0;
		Class83.int_1 = (int)long_0;
	}

	// Token: 0x0600045F RID: 1119 RVA: 0x00004C17 File Offset: 0x00002E17
	public static void smethod_3(ref char char_0)
	{
		char_0 = (char)Class83.int_0;
		Class83.int_1 = (int)char_0;
	}

	// Token: 0x06000460 RID: 1120 RVA: 0x00004C2C File Offset: 0x00002E2C
	public static void smethod_4(Array array_0, int int_2, int int_3)
	{
		Array.Clear(array_0, int_2, int_3);
	}

	// Token: 0x06000461 RID: 1121 RVA: 0x00004C36 File Offset: 0x00002E36
	public static void smethod_5(Array array_0)
	{
		Class83.smethod_4(array_0, 0, array_0.GetLength(0));
	}

	// Token: 0x040001D7 RID: 471
	private static int int_0;

	// Token: 0x040001D8 RID: 472
	private static int int_1;
}
