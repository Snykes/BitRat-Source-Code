﻿using System;
using System.Runtime.InteropServices;

// Token: 0x0200010E RID: 270
internal sealed class Class132
{
	// Token: 0x040005B1 RID: 1457 RVA: 0x00002B88 File Offset: 0x00000D88
	internal static readonly Class132.Struct22 struct22_0;

	// Token: 0x0200010F RID: 271
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 5)]
	private struct Struct22
	{
	}
}
