﻿using System;
using System.IO;

// Token: 0x02000063 RID: 99
internal sealed class Class51 : Class50
{
	// Token: 0x0600035C RID: 860 RVA: 0x0000434D File Offset: 0x0000254D
	public Class51(Stream stream_1, int int_1)
	{
		this.stream_0 = stream_1;
		this.int_0 = int_1;
	}

	// Token: 0x0600035D RID: 861 RVA: 0x00004363 File Offset: 0x00002563
	public Stream method_0()
	{
		return this.stream_0;
	}

	// Token: 0x0600035E RID: 862 RVA: 0x0000436B File Offset: 0x0000256B
	public override bool vmethod_0()
	{
		return this.method_0().CanRead;
	}

	// Token: 0x0600035F RID: 863 RVA: 0x00004378 File Offset: 0x00002578
	public override bool vmethod_2()
	{
		return this.method_0().CanSeek;
	}

	// Token: 0x06000360 RID: 864 RVA: 0x00004385 File Offset: 0x00002585
	public override bool vmethod_1()
	{
		return this.method_0().CanWrite;
	}

	// Token: 0x06000361 RID: 865 RVA: 0x00004392 File Offset: 0x00002592
	public override void vmethod_8()
	{
		this.method_0().Flush();
	}

	// Token: 0x06000362 RID: 866 RVA: 0x0000439F File Offset: 0x0000259F
	public override long vmethod_3()
	{
		return this.method_0().Length;
	}

	// Token: 0x06000363 RID: 867 RVA: 0x000043AC File Offset: 0x000025AC
	public override long vmethod_4()
	{
		return this.method_0().Position;
	}

	// Token: 0x06000364 RID: 868 RVA: 0x000043B9 File Offset: 0x000025B9
	public override void vmethod_5(long long_0)
	{
		this.method_0().Position = long_0;
	}

	// Token: 0x06000365 RID: 869 RVA: 0x0001FB5C File Offset: 0x0001DD5C
	private byte method_1(byte byte_0, long long_0)
	{
		byte b = (byte)(this.int_0 ^ -559030707 ^ (int)((uint)long_0));
		return byte_0 ^ b;
	}

	// Token: 0x06000366 RID: 870 RVA: 0x0001FB80 File Offset: 0x0001DD80
	public override void vmethod_13(byte[] byte_0, int int_1, int int_2)
	{
		long num = this.vmethod_4();
		byte[] array = new byte[int_2];
		for (int i = 0; i < int_2; i++)
		{
			array[i] = this.method_1(byte_0[i + int_1], num + (long)i);
		}
		this.method_0().Write(array, 0, int_2);
	}

	// Token: 0x06000367 RID: 871 RVA: 0x0001FBC8 File Offset: 0x0001DDC8
	public override int vmethod_11(byte[] byte_0, int int_1, int int_2)
	{
		long num = this.vmethod_4();
		byte[] array = new byte[int_2];
		int num2 = this.method_0().Read(array, 0, int_2);
		for (int i = 0; i < num2; i++)
		{
			byte_0[i + int_1] = this.method_1(array[i], num + (long)i);
		}
		return num2;
	}

	// Token: 0x06000368 RID: 872 RVA: 0x0001FC14 File Offset: 0x0001DE14
	public override long vmethod_9(long long_0, int int_1)
	{
		SeekOrigin origin;
		switch (int_1)
		{
		case 0:
			origin = SeekOrigin.Begin;
			break;
		case 1:
			origin = SeekOrigin.Current;
			break;
		case 2:
			origin = SeekOrigin.End;
			break;
		default:
			throw new ArgumentException();
		}
		return this.method_0().Seek(long_0, origin);
	}

	// Token: 0x06000369 RID: 873 RVA: 0x000043C7 File Offset: 0x000025C7
	public override void vmethod_10(long long_0)
	{
		this.method_0().SetLength(long_0);
	}

	// Token: 0x040001A5 RID: 421
	private readonly int int_0;

	// Token: 0x040001A6 RID: 422
	private readonly Stream stream_0;
}
