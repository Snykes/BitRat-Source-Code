﻿using System;
using System.IO;

// Token: 0x02000072 RID: 114
internal sealed class Class67
{
	// Token: 0x060003BA RID: 954 RVA: 0x000046C7 File Offset: 0x000028C7
	private static Stream smethod_0()
	{
		return (Stream)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O<3*?8T2", null);
	}

	// Token: 0x060003BB RID: 955 RVA: 0x000046E3 File Offset: 0x000028E3
	private static int smethod_1()
	{
		return (int)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O=F*?:.^", null);
	}

	// Token: 0x060003BC RID: 956 RVA: 0x00004704 File Offset: 0x00002904
	private static byte[] smethod_2()
	{
		return (byte[])Class149.smethod_0().method_256(Class149.smethod_1(), ")&O=\"*?;a6", null);
	}

	// Token: 0x060003BD RID: 957 RVA: 0x00004720 File Offset: 0x00002920
	private static byte[] smethod_3()
	{
		return (byte[])Class149.smethod_0().method_256(Class149.smethod_1(), ")&O=R*?:su", null);
	}

	// Token: 0x060003BE RID: 958 RVA: 0x0000473C File Offset: 0x0000293C
	public static void smethod_4(string string_0, byte[] byte_0, int int_0, int int_1)
	{
		if (Class67.stream_0 == null)
		{
			Class67.stream_0 = Class67.smethod_0();
		}
		Class67.smethod_9(Class67.smethod_11(string_0), byte_0, int_0, int_1);
	}

	// Token: 0x060003BF RID: 959 RVA: 0x00020678 File Offset: 0x0001E878
	public static byte[] smethod_5(string string_0)
	{
		if (Class67.stream_0 == null)
		{
			Class67.stream_0 = Class67.smethod_0();
		}
		long num = Class67.smethod_11(string_0);
		byte[] array = new byte[4];
		Class67.smethod_9(num, array, 0, 4);
		int num2 = Class66.smethod_4(array, 0);
		Array.Clear(array, 0, array.Length);
		byte[] array2 = new byte[num2];
		Class67.smethod_9(num + 4L, array2, 0, num2);
		return array2;
	}

	// Token: 0x060003C0 RID: 960 RVA: 0x000206D8 File Offset: 0x0001E8D8
	private static Class91 smethod_6(out bool bool_0)
	{
		bool_0 = true;
		if (Class67.class91_0 != null)
		{
			return Class67.class91_0;
		}
		if (Class67.class87_0 != null)
		{
			bool_0 = false;
			return Class67.class87_0.method_8();
		}
		Class87 @class = Class67.smethod_8();
		Class91 class2 = @class.method_8();
		if (class2.vmethod_0())
		{
			Class67.class91_0 = class2;
			@class.Dispose();
		}
		else
		{
			Class67.class87_0 = @class;
			bool_0 = false;
		}
		return class2;
	}

	// Token: 0x060003C1 RID: 961 RVA: 0x00020738 File Offset: 0x0001E938
	private static int smethod_7()
	{
		if (Class67.nullable_0 != null)
		{
			return Class67.nullable_0.Value;
		}
		bool flag;
		Class91 @class = Class67.smethod_6(out flag);
		Class67.nullable_0 = new int?(@class.vmethod_1());
		if (!flag)
		{
			@class.Dispose();
		}
		return Class67.nullable_0.Value;
	}

	// Token: 0x060003C2 RID: 962 RVA: 0x0000475D File Offset: 0x0000295D
	private static Class87 smethod_8()
	{
		return (Class87)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O<G*?<ZP", null);
	}

	// Token: 0x060003C3 RID: 963 RVA: 0x00020788 File Offset: 0x0001E988
	private static void smethod_9(long long_0, byte[] byte_0, int int_0, int int_1)
	{
		object[] object_ = new object[]
		{
			long_0,
			byte_0,
			int_0,
			int_1
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O<P*?;j9", object_);
	}

	// Token: 0x060003C4 RID: 964 RVA: 0x000207D0 File Offset: 0x0001E9D0
	private static void smethod_10(long long_0, byte[] byte_0)
	{
		object[] object_ = new object[]
		{
			long_0,
			byte_0
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O;/*?=Pi", object_);
	}

	// Token: 0x060003C5 RID: 965 RVA: 0x00020808 File Offset: 0x0001EA08
	private static long smethod_11(string string_0)
	{
		object[] object_ = new object[]
		{
			string_0
		};
		return (long)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O<J*?=&[", object_);
	}

	// Token: 0x040001B2 RID: 434
	[ThreadStatic]
	private static Stream stream_0;

	// Token: 0x040001B3 RID: 435
	[ThreadStatic]
	private static Class87 class87_0;

	// Token: 0x040001B4 RID: 436
	[ThreadStatic]
	private static Class91 class91_0;

	// Token: 0x040001B5 RID: 437
	private static int? nullable_0;
}
