﻿using System;

// Token: 0x0200007D RID: 125
internal sealed class Class117 : Class94
{
	// Token: 0x060003F0 RID: 1008 RVA: 0x00004899 File Offset: 0x00002A99
	public double method_2()
	{
		return this.double_0;
	}

	// Token: 0x060003F1 RID: 1009 RVA: 0x000048A1 File Offset: 0x00002AA1
	public void method_3(double double_1)
	{
		this.double_0 = double_1;
	}

	// Token: 0x060003F2 RID: 1010 RVA: 0x000048AA File Offset: 0x00002AAA
	public override object vmethod_0()
	{
		return this.method_2();
	}

	// Token: 0x060003F3 RID: 1011 RVA: 0x000048B7 File Offset: 0x00002AB7
	public override void vmethod_1(object object_0)
	{
		this.method_3(Convert.ToDouble(object_0));
	}

	// Token: 0x060003F4 RID: 1012 RVA: 0x000048C5 File Offset: 0x00002AC5
	public override Class94 vmethod_4()
	{
		Class117 @class = new Class117();
		@class.method_3(this.double_0);
		@class.method_1(base.method_0());
		return @class;
	}

	// Token: 0x060003F5 RID: 1013 RVA: 0x000048E4 File Offset: 0x00002AE4
	public override int vmethod_2()
	{
		return 17;
	}

	// Token: 0x060003F6 RID: 1014 RVA: 0x00020DFC File Offset: 0x0001EFFC
	public override Class94 vmethod_3(Class94 class94_0)
	{
		base.method_1(class94_0.method_0());
		int num = class94_0.vmethod_2();
		if (num != 0)
		{
			switch (num)
			{
			case 4:
				this.method_3((double)((Class102)class94_0).method_2());
				return this;
			case 7:
				this.method_3((double)((Class118)class94_0).method_2());
				return this;
			case 9:
				this.method_3((double)((Class115)class94_0).method_2());
				return this;
			case 10:
				this.method_3((double)((Class114)class94_0).method_2());
				return this;
			case 11:
				this.method_3((double)((Class99)class94_0).method_2());
				return this;
			case 15:
				this.method_3((double)((Class101)class94_0).method_2());
				return this;
			case 17:
				this.method_3(((Class117)class94_0).method_2());
				return this;
			case 19:
				this.method_3(((Class120)class94_0).method_2());
				return this;
			case 21:
				this.method_3(((Class104)class94_0).method_2());
				return this;
			case 22:
				this.method_3((double)((Class121)class94_0).method_2());
				return this;
			}
			throw new ArgumentOutOfRangeException();
		}
		this.method_3((double)((Class119)class94_0).method_2());
		return this;
	}

	// Token: 0x040001C2 RID: 450
	private double double_0;
}
