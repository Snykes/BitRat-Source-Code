﻿using System;

// Token: 0x0200009B RID: 155
internal sealed class Class89 : Interface6
{
	// Token: 0x060004BA RID: 1210 RVA: 0x00002F44 File Offset: 0x00001144
	public void imethod_0()
	{
	}

	// Token: 0x060004BB RID: 1211 RVA: 0x00004F7A File Offset: 0x0000317A
	public string imethod_1()
	{
		return "PKCS7";
	}

	// Token: 0x060004BC RID: 1212 RVA: 0x00022FF0 File Offset: 0x000211F0
	public int imethod_2(byte[] byte_0, int int_0)
	{
		byte b = (byte)(byte_0.Length - int_0);
		while (int_0 < byte_0.Length)
		{
			byte_0[int_0] = b;
			int_0++;
		}
		return (int)b;
	}

	// Token: 0x060004BD RID: 1213 RVA: 0x00023018 File Offset: 0x00021218
	public int imethod_3(byte[] byte_0)
	{
		int num = (int)byte_0[byte_0.Length - 1];
		if (num >= 1 && num <= byte_0.Length)
		{
			for (int i = 1; i <= num; i++)
			{
				if ((int)byte_0[byte_0.Length - i] != num)
				{
					throw new Exception2("pad block corrupted");
				}
			}
			return num;
		}
		throw new Exception2("pad block corrupted");
	}
}
