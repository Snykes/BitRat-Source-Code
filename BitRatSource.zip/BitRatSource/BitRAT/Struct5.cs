﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000030 RID: 48
[StructLayout(LayoutKind.Explicit)]
internal struct Struct5
{
	// Token: 0x0400014E RID: 334
	public static bool bool_0 = new Struct5
	{
		double_0 = 2.584282340946878E+43
	}.ulong_0 == 5256416082139472972UL;

	// Token: 0x0400014F RID: 335
	[FieldOffset(0)]
	private ulong ulong_0;

	// Token: 0x04000150 RID: 336
	[FieldOffset(0)]
	private double double_0;
}
