﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using Zeroit.Framework.Progress;

// Token: 0x0200012E RID: 302
[DesignerGenerated]
public sealed partial class fPaymentHVNC : Form
{
	// Token: 0x060010BE RID: 4286 RVA: 0x000099C6 File Offset: 0x00007BC6
	public fPaymentHVNC()
	{
		base.Load += this.fPaymentHVNC_Load;
		base.Closing += this.fPaymentHVNC_Closing;
		this.InitializeComponent();
	}

	// Token: 0x060010C1 RID: 4289 RVA: 0x000099F8 File Offset: 0x00007BF8
	internal PictureBox vmethod_0()
	{
		return this.pictureBox_0;
	}

	// Token: 0x060010C2 RID: 4290 RVA: 0x0007D8F4 File Offset: 0x0007BAF4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_1(PictureBox pictureBox_7)
	{
		EventHandler value = new EventHandler(this.method_11);
		PictureBox pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_0 = pictureBox_7;
		pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x060010C3 RID: 4291 RVA: 0x00009A00 File Offset: 0x00007C00
	internal PictureBox vmethod_2()
	{
		return this.pictureBox_1;
	}

	// Token: 0x060010C4 RID: 4292 RVA: 0x0007D938 File Offset: 0x0007BB38
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_3(PictureBox pictureBox_7)
	{
		EventHandler value = new EventHandler(this.method_13);
		PictureBox pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_1 = pictureBox_7;
		pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x060010C5 RID: 4293 RVA: 0x00009A08 File Offset: 0x00007C08
	internal BackgroundWorker vmethod_4()
	{
		return this.backgroundWorker_0;
	}

	// Token: 0x060010C6 RID: 4294 RVA: 0x0007D97C File Offset: 0x0007BB7C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_5(BackgroundWorker backgroundWorker_3)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_4);
		BackgroundWorker backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_0 = backgroundWorker_3;
		backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x060010C7 RID: 4295 RVA: 0x00009A10 File Offset: 0x00007C10
	internal Label vmethod_6()
	{
		return this.label_0;
	}

	// Token: 0x060010C8 RID: 4296 RVA: 0x00009A18 File Offset: 0x00007C18
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_7(Label label_14)
	{
		this.label_0 = label_14;
	}

	// Token: 0x060010C9 RID: 4297 RVA: 0x00009A21 File Offset: 0x00007C21
	internal Label vmethod_8()
	{
		return this.label_1;
	}

	// Token: 0x060010CA RID: 4298 RVA: 0x00009A29 File Offset: 0x00007C29
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_9(Label label_14)
	{
		this.label_1 = label_14;
	}

	// Token: 0x060010CB RID: 4299 RVA: 0x00009A32 File Offset: 0x00007C32
	internal ToolStripStatusLabel vmethod_10()
	{
		return this.toolStripStatusLabel_0;
	}

	// Token: 0x060010CC RID: 4300 RVA: 0x00009A3A File Offset: 0x00007C3A
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_11(ToolStripStatusLabel toolStripStatusLabel_1)
	{
		this.toolStripStatusLabel_0 = toolStripStatusLabel_1;
	}

	// Token: 0x060010CD RID: 4301 RVA: 0x00009A43 File Offset: 0x00007C43
	internal Label vmethod_12()
	{
		return this.label_2;
	}

	// Token: 0x060010CE RID: 4302 RVA: 0x00009A4B File Offset: 0x00007C4B
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_13(Label label_14)
	{
		this.label_2 = label_14;
	}

	// Token: 0x060010CF RID: 4303 RVA: 0x00009A54 File Offset: 0x00007C54
	internal Label vmethod_14()
	{
		return this.label_3;
	}

	// Token: 0x060010D0 RID: 4304 RVA: 0x00009A5C File Offset: 0x00007C5C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_15(Label label_14)
	{
		this.label_3 = label_14;
	}

	// Token: 0x060010D1 RID: 4305 RVA: 0x00009A65 File Offset: 0x00007C65
	internal PictureBox vmethod_16()
	{
		return this.pictureBox_2;
	}

	// Token: 0x060010D2 RID: 4306 RVA: 0x0007D9C0 File Offset: 0x0007BBC0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_17(PictureBox pictureBox_7)
	{
		EventHandler value = new EventHandler(this.method_14);
		PictureBox pictureBox = this.pictureBox_2;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_2 = pictureBox_7;
		pictureBox = this.pictureBox_2;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x060010D3 RID: 4307 RVA: 0x00009A6D File Offset: 0x00007C6D
	internal System.Windows.Forms.Timer vmethod_18()
	{
		return this.timer_0;
	}

	// Token: 0x060010D4 RID: 4308 RVA: 0x00009A75 File Offset: 0x00007C75
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_19(System.Windows.Forms.Timer timer_1)
	{
		this.timer_0 = timer_1;
	}

	// Token: 0x060010D5 RID: 4309 RVA: 0x00009A7E File Offset: 0x00007C7E
	internal Label vmethod_20()
	{
		return this.label_4;
	}

	// Token: 0x060010D6 RID: 4310 RVA: 0x00009A86 File Offset: 0x00007C86
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_21(Label label_14)
	{
		this.label_4 = label_14;
	}

	// Token: 0x060010D7 RID: 4311 RVA: 0x00009A8F File Offset: 0x00007C8F
	internal Label vmethod_22()
	{
		return this.label_5;
	}

	// Token: 0x060010D8 RID: 4312 RVA: 0x00009A97 File Offset: 0x00007C97
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_23(Label label_14)
	{
		this.label_5 = label_14;
	}

	// Token: 0x060010D9 RID: 4313 RVA: 0x00009AA0 File Offset: 0x00007CA0
	internal Label vmethod_24()
	{
		return this.label_6;
	}

	// Token: 0x060010DA RID: 4314 RVA: 0x00009AA8 File Offset: 0x00007CA8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_25(Label label_14)
	{
		this.label_6 = label_14;
	}

	// Token: 0x060010DB RID: 4315 RVA: 0x00009AB1 File Offset: 0x00007CB1
	internal BackgroundWorker vmethod_26()
	{
		return this.backgroundWorker_1;
	}

	// Token: 0x060010DC RID: 4316 RVA: 0x0007DA04 File Offset: 0x0007BC04
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_27(BackgroundWorker backgroundWorker_3)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_5);
		BackgroundWorker backgroundWorker = this.backgroundWorker_1;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_1 = backgroundWorker_3;
		backgroundWorker = this.backgroundWorker_1;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x060010DD RID: 4317 RVA: 0x00009AB9 File Offset: 0x00007CB9
	internal Label vmethod_28()
	{
		return this.label_7;
	}

	// Token: 0x060010DE RID: 4318 RVA: 0x00009AC1 File Offset: 0x00007CC1
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_29(Label label_14)
	{
		this.label_7 = label_14;
	}

	// Token: 0x060010DF RID: 4319 RVA: 0x00009ACA File Offset: 0x00007CCA
	internal PictureBox vmethod_30()
	{
		return this.pictureBox_3;
	}

	// Token: 0x060010E0 RID: 4320 RVA: 0x0007DA48 File Offset: 0x0007BC48
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_31(PictureBox pictureBox_7)
	{
		EventHandler value = new EventHandler(this.method_12);
		PictureBox pictureBox = this.pictureBox_3;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_3 = pictureBox_7;
		pictureBox = this.pictureBox_3;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x060010E1 RID: 4321 RVA: 0x00009AD2 File Offset: 0x00007CD2
	internal Label vmethod_32()
	{
		return this.label_8;
	}

	// Token: 0x060010E2 RID: 4322 RVA: 0x00009ADA File Offset: 0x00007CDA
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_33(Label label_14)
	{
		this.label_8 = label_14;
	}

	// Token: 0x060010E3 RID: 4323 RVA: 0x00009AE3 File Offset: 0x00007CE3
	internal Label vmethod_34()
	{
		return this.label_9;
	}

	// Token: 0x060010E4 RID: 4324 RVA: 0x0007DA8C File Offset: 0x0007BC8C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_35(Label label_14)
	{
		EventHandler value = new EventHandler(this.method_16);
		Label label = this.label_9;
		if (label != null)
		{
			label.Click -= value;
		}
		this.label_9 = label_14;
		label = this.label_9;
		if (label != null)
		{
			label.Click += value;
		}
	}

	// Token: 0x060010E5 RID: 4325 RVA: 0x00009AEB File Offset: 0x00007CEB
	internal Label vmethod_36()
	{
		return this.label_10;
	}

	// Token: 0x060010E6 RID: 4326 RVA: 0x0007DAD0 File Offset: 0x0007BCD0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_37(Label label_14)
	{
		EventHandler value = new EventHandler(this.method_15);
		Label label = this.label_10;
		if (label != null)
		{
			label.Click -= value;
		}
		this.label_10 = label_14;
		label = this.label_10;
		if (label != null)
		{
			label.Click += value;
		}
	}

	// Token: 0x060010E7 RID: 4327 RVA: 0x00009AF3 File Offset: 0x00007CF3
	internal Label vmethod_38()
	{
		return this.label_11;
	}

	// Token: 0x060010E8 RID: 4328 RVA: 0x00009AFB File Offset: 0x00007CFB
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_39(Label label_14)
	{
		this.label_11 = label_14;
	}

	// Token: 0x060010E9 RID: 4329 RVA: 0x00009B04 File Offset: 0x00007D04
	internal StatusStrip vmethod_40()
	{
		return this.statusStrip_0;
	}

	// Token: 0x060010EA RID: 4330 RVA: 0x00009B0C File Offset: 0x00007D0C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_41(StatusStrip statusStrip_1)
	{
		this.statusStrip_0 = statusStrip_1;
	}

	// Token: 0x060010EB RID: 4331 RVA: 0x00009B15 File Offset: 0x00007D15
	internal Label vmethod_42()
	{
		return this.label_12;
	}

	// Token: 0x060010EC RID: 4332 RVA: 0x00009B1D File Offset: 0x00007D1D
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_43(Label label_14)
	{
		this.label_12 = label_14;
	}

	// Token: 0x060010ED RID: 4333 RVA: 0x00009B26 File Offset: 0x00007D26
	internal ZeroitProgressIndicator vmethod_44()
	{
		return this.zeroitProgressIndicator_0;
	}

	// Token: 0x060010EE RID: 4334 RVA: 0x00009B2E File Offset: 0x00007D2E
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_45(ZeroitProgressIndicator zeroitProgressIndicator_1)
	{
		this.zeroitProgressIndicator_0 = zeroitProgressIndicator_1;
	}

	// Token: 0x060010EF RID: 4335 RVA: 0x00009B37 File Offset: 0x00007D37
	internal PictureBox vmethod_46()
	{
		return this.pictureBox_4;
	}

	// Token: 0x060010F0 RID: 4336 RVA: 0x00009B3F File Offset: 0x00007D3F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_47(PictureBox pictureBox_7)
	{
		this.pictureBox_4 = pictureBox_7;
	}

	// Token: 0x060010F1 RID: 4337 RVA: 0x00009B48 File Offset: 0x00007D48
	internal PictureBox vmethod_48()
	{
		return this.pictureBox_5;
	}

	// Token: 0x060010F2 RID: 4338 RVA: 0x00009B50 File Offset: 0x00007D50
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_49(PictureBox pictureBox_7)
	{
		this.pictureBox_5 = pictureBox_7;
	}

	// Token: 0x060010F3 RID: 4339 RVA: 0x00009B59 File Offset: 0x00007D59
	internal PictureBox vmethod_50()
	{
		return this.pictureBox_6;
	}

	// Token: 0x060010F4 RID: 4340 RVA: 0x00009B61 File Offset: 0x00007D61
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_51(PictureBox pictureBox_7)
	{
		this.pictureBox_6 = pictureBox_7;
	}

	// Token: 0x060010F5 RID: 4341 RVA: 0x00009B6A File Offset: 0x00007D6A
	internal BackgroundWorker vmethod_52()
	{
		return this.backgroundWorker_2;
	}

	// Token: 0x060010F6 RID: 4342 RVA: 0x0007DB14 File Offset: 0x0007BD14
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_53(BackgroundWorker backgroundWorker_3)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_6);
		BackgroundWorker backgroundWorker = this.backgroundWorker_2;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_2 = backgroundWorker_3;
		backgroundWorker = this.backgroundWorker_2;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x060010F7 RID: 4343 RVA: 0x00009B72 File Offset: 0x00007D72
	internal Label vmethod_54()
	{
		return this.label_13;
	}

	// Token: 0x060010F8 RID: 4344 RVA: 0x00009B7A File Offset: 0x00007D7A
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_55(Label label_14)
	{
		this.label_13 = label_14;
	}

	// Token: 0x060010F9 RID: 4345 RVA: 0x0007DB58 File Offset: 0x0007BD58
	private void fPaymentHVNC_Load(object sender, EventArgs e)
	{
		object[] object_ = new object[]
		{
			this,
			sender,
			e
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O70*?5)$", object_);
	}

	// Token: 0x060010FA RID: 4346 RVA: 0x0007DB90 File Offset: 0x0007BD90
	public void method_0(int int_1)
	{
		if (base.InvokeRequired)
		{
			base.Invoke(new fPaymentHVNC.Delegate94(this.method_0), new object[]
			{
				int_1
			});
			return;
		}
		base.Opacity = Conversion.Val((double)this.int_0 / 100.0);
	}

	// Token: 0x060010FB RID: 4347 RVA: 0x0007DBEC File Offset: 0x0007BDEC
	public void method_1(string string_5)
	{
		object[] object_ = new object[]
		{
			this,
			string_5
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O6(*?64D", object_);
	}

	// Token: 0x060010FC RID: 4348 RVA: 0x0007DC20 File Offset: 0x0007BE20
	private void method_2(ref string string_5, ref string string_6, ref string string_7)
	{
		object[] array = new object[]
		{
			this,
			string_5,
			string_6,
			string_7
		};
		Class4 @class = Class149.smethod_0();
		Stream stream_ = Class149.smethod_1();
		try
		{
			@class.method_139(stream_, ")&O5O*?8-%", array);
		}
		finally
		{
			string_5 = (string)array[1];
			string_6 = (string)array[2];
			string_7 = (string)array[3];
		}
	}

	// Token: 0x060010FD RID: 4349 RVA: 0x0007DCB8 File Offset: 0x0007BEB8
	private void method_3()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O8k*?<*@", object_);
	}

	// Token: 0x060010FE RID: 4350 RVA: 0x0007DCE8 File Offset: 0x0007BEE8
	private void method_4(object sender, DoWorkEventArgs e)
	{
		Thread.Sleep(1000);
		this.int_0 = 0;
		while (this.int_0 < 100)
		{
			ref int ptr = ref this.int_0;
			this.int_0 = checked(ptr + 1);
			this.method_0(this.int_0);
			Thread.Sleep(1);
		}
	}

	// Token: 0x060010FF RID: 4351 RVA: 0x0007DD34 File Offset: 0x0007BF34
	private void method_5(object sender, DoWorkEventArgs e)
	{
		object[] object_ = new object[]
		{
			this,
			sender,
			e
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O5.*?7Ni", object_);
	}

	// Token: 0x06001100 RID: 4352 RVA: 0x0007DCE8 File Offset: 0x0007BEE8
	private void method_6(object sender, DoWorkEventArgs e)
	{
		Thread.Sleep(1000);
		this.int_0 = 0;
		while (this.int_0 < 100)
		{
			ref int ptr = ref this.int_0;
			this.int_0 = checked(ptr + 1);
			this.method_0(this.int_0);
			Thread.Sleep(1);
		}
	}

	// Token: 0x06001101 RID: 4353 RVA: 0x0007DD6C File Offset: 0x0007BF6C
	private void method_7(string string_5, string string_6)
	{
		object[] object_ = new object[]
		{
			this,
			string_5,
			string_6
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O6k*?92C", object_);
	}

	// Token: 0x06001102 RID: 4354 RVA: 0x0007DDA4 File Offset: 0x0007BFA4
	public bool method_8()
	{
		object[] object_ = new object[]
		{
			this
		};
		return (bool)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O5.*?:Oi", object_);
	}

	// Token: 0x06001103 RID: 4355 RVA: 0x0007DDDC File Offset: 0x0007BFDC
	public void method_9()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O9M*?;j9", object_);
	}

	// Token: 0x06001104 RID: 4356 RVA: 0x0007DE0C File Offset: 0x0007C00C
	public void method_10()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O8B*?=Vk", object_);
	}

	// Token: 0x06001105 RID: 4357 RVA: 0x00009B83 File Offset: 0x00007D83
	private void method_11(object sender, EventArgs e)
	{
		Clipboard.Clear();
		Clipboard.SetText(this.vmethod_36().Text);
		Interaction.MsgBox("Amount copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06001106 RID: 4358 RVA: 0x00009BAC File Offset: 0x00007DAC
	private void method_12(object sender, EventArgs e)
	{
		Clipboard.Clear();
		Clipboard.SetText(this.vmethod_34().Text);
		Interaction.MsgBox("Address copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06001107 RID: 4359 RVA: 0x00009BD5 File Offset: 0x00007DD5
	private void method_13(object sender, EventArgs e)
	{
		Clipboard.Clear();
		Clipboard.SetText(Conversions.ToString(this.vmethod_42().Tag));
		Interaction.MsgBox("Remaining amount copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06001108 RID: 4360 RVA: 0x0007DE3C File Offset: 0x0007C03C
	private void method_14(object sender, EventArgs e)
	{
		Interaction.MsgBox(string.Concat(new string[]
		{
			"If you've already paid and still seeing this payment form, please close it and wait some minutes before starting ",
			Application.ProductName,
			" again.\r\n\r\nMost likely, your payment is still waiting for a confirmation and your purchased item will automatically become available once confirmed.\r\n\r\nNOTE: ",
			Application.ProductName,
			" uses private nodes in the blockchain to check for confimrations, not public services like blockchain.com.\r\nThis means a confirmation may sometimes take a little longer or sometimes even faster. Do not panic, but allow some more minutes."
		}), MsgBoxStyle.Question, Application.ProductName);
	}

	// Token: 0x06001109 RID: 4361 RVA: 0x00009B83 File Offset: 0x00007D83
	private void method_15(object sender, EventArgs e)
	{
		Clipboard.Clear();
		Clipboard.SetText(this.vmethod_36().Text);
		Interaction.MsgBox("Amount copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x0600110A RID: 4362 RVA: 0x00009BAC File Offset: 0x00007DAC
	private void method_16(object sender, EventArgs e)
	{
		Clipboard.Clear();
		Clipboard.SetText(this.vmethod_34().Text);
		Interaction.MsgBox("Address copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x0600110B RID: 4363 RVA: 0x0007DE8C File Offset: 0x0007C08C
	public void method_17()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O:/*?=5`", object_);
	}

	// Token: 0x0600110C RID: 4364 RVA: 0x0007DEBC File Offset: 0x0007C0BC
	public void method_18(string string_5, bool bool_1, string string_6, decimal decimal_0)
	{
		object[] object_ = new object[]
		{
			this,
			string_5,
			bool_1,
			string_6,
			decimal_0
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O7J*?::b", object_);
	}

	// Token: 0x0600110D RID: 4365 RVA: 0x00007348 File Offset: 0x00005548
	private void fPaymentHVNC_Closing(object sender, CancelEventArgs e)
	{
		base.Visible = false;
		e.Cancel = true;
	}

	// Token: 0x040006A2 RID: 1698
	private PictureBox pictureBox_0;

	// Token: 0x040006A3 RID: 1699
	private PictureBox pictureBox_1;

	// Token: 0x040006A4 RID: 1700
	private BackgroundWorker backgroundWorker_0;

	// Token: 0x040006A5 RID: 1701
	private Label label_0;

	// Token: 0x040006A6 RID: 1702
	private Label label_1;

	// Token: 0x040006A7 RID: 1703
	private ToolStripStatusLabel toolStripStatusLabel_0;

	// Token: 0x040006A8 RID: 1704
	private Label label_2;

	// Token: 0x040006A9 RID: 1705
	private Label label_3;

	// Token: 0x040006AA RID: 1706
	private PictureBox pictureBox_2;

	// Token: 0x040006AB RID: 1707
	private System.Windows.Forms.Timer timer_0;

	// Token: 0x040006AC RID: 1708
	private Label label_4;

	// Token: 0x040006AD RID: 1709
	private Label label_5;

	// Token: 0x040006AE RID: 1710
	private Label label_6;

	// Token: 0x040006AF RID: 1711
	private BackgroundWorker backgroundWorker_1;

	// Token: 0x040006B0 RID: 1712
	private Label label_7;

	// Token: 0x040006B1 RID: 1713
	private PictureBox pictureBox_3;

	// Token: 0x040006B2 RID: 1714
	private Label label_8;

	// Token: 0x040006B3 RID: 1715
	private Label label_9;

	// Token: 0x040006B4 RID: 1716
	private Label label_10;

	// Token: 0x040006B5 RID: 1717
	private Label label_11;

	// Token: 0x040006B6 RID: 1718
	private StatusStrip statusStrip_0;

	// Token: 0x040006B7 RID: 1719
	private Label label_12;

	// Token: 0x040006B8 RID: 1720
	private ZeroitProgressIndicator zeroitProgressIndicator_0;

	// Token: 0x040006B9 RID: 1721
	private PictureBox pictureBox_4;

	// Token: 0x040006BA RID: 1722
	private PictureBox pictureBox_5;

	// Token: 0x040006BB RID: 1723
	private PictureBox pictureBox_6;

	// Token: 0x040006BC RID: 1724
	private BackgroundWorker backgroundWorker_2;

	// Token: 0x040006BD RID: 1725
	private Label label_13;

	// Token: 0x040006BE RID: 1726
	private Struct18 struct18_0;

	// Token: 0x040006BF RID: 1727
	private Struct18 struct18_1;

	// Token: 0x040006C0 RID: 1728
	private Struct16 struct16_0;

	// Token: 0x040006C1 RID: 1729
	private string string_0;

	// Token: 0x040006C2 RID: 1730
	private string string_1;

	// Token: 0x040006C3 RID: 1731
	private string string_2;

	// Token: 0x040006C4 RID: 1732
	private string string_3;

	// Token: 0x040006C5 RID: 1733
	private string string_4;

	// Token: 0x040006C6 RID: 1734
	private bool bool_0;

	// Token: 0x040006C7 RID: 1735
	private TimeSpan timeSpan_0;

	// Token: 0x040006C8 RID: 1736
	private Stopwatch stopwatch_0;

	// Token: 0x040006C9 RID: 1737
	private int int_0;

	// Token: 0x0200012F RID: 303
	// (Invoke) Token: 0x06001115 RID: 4373
	private delegate void Delegate88(ref string string_0, ref string string_1, ref string string_2);

	// Token: 0x02000130 RID: 304
	// (Invoke) Token: 0x06001119 RID: 4377
	private delegate void Delegate89(string string_0);

	// Token: 0x02000131 RID: 305
	// (Invoke) Token: 0x0600111D RID: 4381
	private delegate void Delegate90();

	// Token: 0x02000132 RID: 306
	// (Invoke) Token: 0x06001121 RID: 4385
	private delegate void Delegate91();

	// Token: 0x02000133 RID: 307
	// (Invoke) Token: 0x06001125 RID: 4389
	private delegate void Delegate92(string string_0, bool bool_0, string string_1, decimal decimal_0);

	// Token: 0x02000134 RID: 308
	// (Invoke) Token: 0x06001129 RID: 4393
	private delegate void Delegate93(string string_0, string string_1);

	// Token: 0x02000135 RID: 309
	// (Invoke) Token: 0x0600112D RID: 4397
	private delegate void Delegate94(int int_0);
}
