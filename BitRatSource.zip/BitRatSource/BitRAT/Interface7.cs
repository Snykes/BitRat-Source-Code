﻿using System;

// Token: 0x02000074 RID: 116
internal interface Interface7 : IDisposable
{
	// Token: 0x060003CE RID: 974
	int imethod_0();

	// Token: 0x060003CF RID: 975
	void imethod_1(int int_0, out byte byte_0);

	// Token: 0x060003D0 RID: 976
	void imethod_2(int int_0, ref byte byte_0);

	// Token: 0x060003D1 RID: 977
	void imethod_3();

	// Token: 0x060003D2 RID: 978
	Interface7 imethod_4();
}
