﻿using System;

// Token: 0x02000044 RID: 68
internal sealed class Class48
{
	// Token: 0x04000182 RID: 386
	public readonly object object_0 = new object();

	// Token: 0x04000183 RID: 387
	public byte[] byte_0;

	// Token: 0x04000184 RID: 388
	public bool bool_0;

	// Token: 0x04000185 RID: 389
	public bool bool_1;
}
