﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000060 RID: 96
[StructLayout(LayoutKind.Explicit)]
internal struct Struct14
{
	// Token: 0x040001A0 RID: 416
	public static bool bool_0 = new Struct14
	{
		float_0 = 81679030f
	}.uint_0 == 1285278295U;

	// Token: 0x040001A1 RID: 417
	[FieldOffset(0)]
	private uint uint_0;

	// Token: 0x040001A2 RID: 418
	[FieldOffset(0)]
	private float float_0;
}
