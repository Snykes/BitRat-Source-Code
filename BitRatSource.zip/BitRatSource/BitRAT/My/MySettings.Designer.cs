﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Configuration;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic.CompilerServices;

namespace BitRAT.My
{
	// Token: 0x020001DA RID: 474
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "16.7.0.0")]
	[CompilerGenerated]
	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal sealed partial class MySettings : ApplicationSettingsBase
	{
		// Token: 0x060019ED RID: 6637 RVA: 0x0000CEE3 File Offset: 0x0000B0E3
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		[DebuggerNonUserCode]
		private static void AutoSaveSettings(object sender, EventArgs e)
		{
			if (Class145.smethod_1().SaveMySettingsOnExit)
			{
				Class135.smethod_0().Save();
			}
		}

		// Token: 0x17000021 RID: 33
		// (get) Token: 0x060019EE RID: 6638 RVA: 0x000BA6E0 File Offset: 0x000B88E0
		public static MySettings Default
		{
			get
			{
				if (!MySettings.addedHandler)
				{
					object obj = MySettings.addedHandlerLockObject;
					ObjectFlowControl.CheckForSyncLockOnValueType(obj);
					lock (obj)
					{
						if (!MySettings.addedHandler)
						{
							Class145.smethod_1().Shutdown += MySettings.AutoSaveSettings;
							MySettings.addedHandler = true;
						}
					}
				}
				return MySettings.defaultInstance;
			}
		}

		// Token: 0x17000022 RID: 34
		// (get) Token: 0x060019EF RID: 6639 RVA: 0x0000CEFB File Offset: 0x0000B0FB
		// (set) Token: 0x060019F0 RID: 6640 RVA: 0x0000CF0D File Offset: 0x0000B10D
		[DefaultSettingValue("1234")]
		[DebuggerNonUserCode]
		[UserScopedSetting]
		public int PortMain
		{
			get
			{
				return Conversions.ToInteger(this["PortMain"]);
			}
			set
			{
				this["PortMain"] = value;
			}
		}

		// Token: 0x17000023 RID: 35
		// (get) Token: 0x060019F1 RID: 6641 RVA: 0x0000CF20 File Offset: 0x0000B120
		// (set) Token: 0x060019F2 RID: 6642 RVA: 0x0000CF32 File Offset: 0x0000B132
		[UserScopedSetting]
		[DefaultSettingValue("")]
		[DebuggerNonUserCode]
		public string HostMainIP
		{
			get
			{
				return Conversions.ToString(this["HostMainIP"]);
			}
			set
			{
				this["HostMainIP"] = value;
			}
		}

		// Token: 0x17000024 RID: 36
		// (get) Token: 0x060019F3 RID: 6643 RVA: 0x0000CF40 File Offset: 0x0000B140
		// (set) Token: 0x060019F4 RID: 6644 RVA: 0x0000CF52 File Offset: 0x0000B152
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("False")]
		public bool AutostartMain
		{
			get
			{
				return Conversions.ToBoolean(this["AutostartMain"]);
			}
			set
			{
				this["AutostartMain"] = value;
			}
		}

		// Token: 0x17000025 RID: 37
		// (get) Token: 0x060019F5 RID: 6645 RVA: 0x0000CF65 File Offset: 0x0000B165
		// (set) Token: 0x060019F6 RID: 6646 RVA: 0x0000CF77 File Offset: 0x0000B177
		[DefaultSettingValue("True")]
		[UserScopedSetting]
		[DebuggerNonUserCode]
		public bool ShowGroups
		{
			get
			{
				return Conversions.ToBoolean(this["ShowGroups"]);
			}
			set
			{
				this["ShowGroups"] = value;
			}
		}

		// Token: 0x17000026 RID: 38
		// (get) Token: 0x060019F7 RID: 6647 RVA: 0x0000CF8A File Offset: 0x0000B18A
		// (set) Token: 0x060019F8 RID: 6648 RVA: 0x0000CF9C File Offset: 0x0000B19C
		[DebuggerNonUserCode]
		[DefaultSettingValue("1")]
		[UserScopedSetting]
		public int GroupIndex
		{
			get
			{
				return Conversions.ToInteger(this["GroupIndex"]);
			}
			set
			{
				this["GroupIndex"] = value;
			}
		}

		// Token: 0x17000027 RID: 39
		// (get) Token: 0x060019F9 RID: 6649 RVA: 0x0000CFAF File Offset: 0x0000B1AF
		// (set) Token: 0x060019FA RID: 6650 RVA: 0x0000CFC1 File Offset: 0x0000B1C1
		[DefaultSettingValue("True")]
		[DebuggerNonUserCode]
		[UserScopedSetting]
		public bool GroupSubtitles
		{
			get
			{
				return Conversions.ToBoolean(this["GroupSubtitles"]);
			}
			set
			{
				this["GroupSubtitles"] = value;
			}
		}

		// Token: 0x17000028 RID: 40
		// (get) Token: 0x060019FB RID: 6651 RVA: 0x0000CFD4 File Offset: 0x0000B1D4
		// (set) Token: 0x060019FC RID: 6652 RVA: 0x0000CFE6 File Offset: 0x0000B1E6
		[UserScopedSetting]
		[DefaultSettingValue("True")]
		[DebuggerNonUserCode]
		public bool LayoutAutoRefresh
		{
			get
			{
				return Conversions.ToBoolean(this["LayoutAutoRefresh"]);
			}
			set
			{
				this["LayoutAutoRefresh"] = value;
			}
		}

		// Token: 0x17000029 RID: 41
		// (get) Token: 0x060019FD RID: 6653 RVA: 0x0000CFF9 File Offset: 0x0000B1F9
		// (set) Token: 0x060019FE RID: 6654 RVA: 0x0000D00B File Offset: 0x0000B20B
		[UserScopedSetting]
		[DefaultSettingValue("URL to plugin: http://site.com/xmr.plg")]
		[DebuggerNonUserCode]
		public string PluginsURLXMR
		{
			get
			{
				return Conversions.ToString(this["PluginsURLXMR"]);
			}
			set
			{
				this["PluginsURLXMR"] = value;
			}
		}

		// Token: 0x1700002A RID: 42
		// (get) Token: 0x060019FF RID: 6655 RVA: 0x0000D019 File Offset: 0x0000B219
		// (set) Token: 0x06001A00 RID: 6656 RVA: 0x0000D02B File Offset: 0x0000B22B
		[UserScopedSetting]
		[DefaultSettingValue("URL to plugin: http://site.com/pws.plg")]
		[DebuggerNonUserCode]
		public string PluginsURLPws
		{
			get
			{
				return Conversions.ToString(this["PluginsURLPws"]);
			}
			set
			{
				this["PluginsURLPws"] = value;
			}
		}

		// Token: 0x1700002B RID: 43
		// (get) Token: 0x06001A01 RID: 6657 RVA: 0x0000D039 File Offset: 0x0000B239
		// (set) Token: 0x06001A02 RID: 6658 RVA: 0x0000D04B File Offset: 0x0000B24B
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("8192")]
		public int TransfersRecvBytes
		{
			get
			{
				return Conversions.ToInteger(this["TransfersRecvBytes"]);
			}
			set
			{
				this["TransfersRecvBytes"] = value;
			}
		}

		// Token: 0x1700002C RID: 44
		// (get) Token: 0x06001A03 RID: 6659 RVA: 0x0000D05E File Offset: 0x0000B25E
		// (set) Token: 0x06001A04 RID: 6660 RVA: 0x0000D070 File Offset: 0x0000B270
		[UserScopedSetting]
		[DefaultSettingValue("8192")]
		[DebuggerNonUserCode]
		public int TransfersSendBytes
		{
			get
			{
				return Conversions.ToInteger(this["TransfersSendBytes"]);
			}
			set
			{
				this["TransfersSendBytes"] = value;
			}
		}

		// Token: 0x1700002D RID: 45
		// (get) Token: 0x06001A05 RID: 6661 RVA: 0x0000D083 File Offset: 0x0000B283
		// (set) Token: 0x06001A06 RID: 6662 RVA: 0x0000D095 File Offset: 0x0000B295
		[DefaultSettingValue("True")]
		[UserScopedSetting]
		[DebuggerNonUserCode]
		public bool PreviewEnabled
		{
			get
			{
				return Conversions.ToBoolean(this["PreviewEnabled"]);
			}
			set
			{
				this["PreviewEnabled"] = value;
			}
		}

		// Token: 0x1700002E RID: 46
		// (get) Token: 0x06001A07 RID: 6663 RVA: 0x0000D0A8 File Offset: 0x0000B2A8
		// (set) Token: 0x06001A08 RID: 6664 RVA: 0x0000D0BA File Offset: 0x0000B2BA
		[DebuggerNonUserCode]
		[DefaultSettingValue("True")]
		[UserScopedSetting]
		public bool PreviewSourceScreen
		{
			get
			{
				return Conversions.ToBoolean(this["PreviewSourceScreen"]);
			}
			set
			{
				this["PreviewSourceScreen"] = value;
			}
		}

		// Token: 0x1700002F RID: 47
		// (get) Token: 0x06001A09 RID: 6665 RVA: 0x0000D0CD File Offset: 0x0000B2CD
		// (set) Token: 0x06001A0A RID: 6666 RVA: 0x0000D0DF File Offset: 0x0000B2DF
		[DefaultSettingValue("False")]
		[DebuggerNonUserCode]
		[UserScopedSetting]
		public bool PreviewSourceWebcam
		{
			get
			{
				return Conversions.ToBoolean(this["PreviewSourceWebcam"]);
			}
			set
			{
				this["PreviewSourceWebcam"] = value;
			}
		}

		// Token: 0x17000030 RID: 48
		// (get) Token: 0x06001A0B RID: 6667 RVA: 0x0000D0F2 File Offset: 0x0000B2F2
		// (set) Token: 0x06001A0C RID: 6668 RVA: 0x0000D104 File Offset: 0x0000B304
		[DefaultSettingValue("1")]
		[UserScopedSetting]
		[DebuggerNonUserCode]
		public int PreviewUpdateInterval
		{
			get
			{
				return Conversions.ToInteger(this["PreviewUpdateInterval"]);
			}
			set
			{
				this["PreviewUpdateInterval"] = value;
			}
		}

		// Token: 0x17000031 RID: 49
		// (get) Token: 0x06001A0D RID: 6669 RVA: 0x0000D117 File Offset: 0x0000B317
		// (set) Token: 0x06001A0E RID: 6670 RVA: 0x0000D129 File Offset: 0x0000B329
		[DefaultSettingValue("30")]
		[DebuggerNonUserCode]
		[UserScopedSetting]
		public int PreviewQuality
		{
			get
			{
				return Conversions.ToInteger(this["PreviewQuality"]);
			}
			set
			{
				this["PreviewQuality"] = value;
			}
		}

		// Token: 0x17000032 RID: 50
		// (get) Token: 0x06001A0F RID: 6671 RVA: 0x0000D13C File Offset: 0x0000B33C
		// (set) Token: 0x06001A10 RID: 6672 RVA: 0x0000D14E File Offset: 0x0000B34E
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("380")]
		public int PreviewDefaultX
		{
			get
			{
				return Conversions.ToInteger(this["PreviewDefaultX"]);
			}
			set
			{
				this["PreviewDefaultX"] = value;
			}
		}

		// Token: 0x17000033 RID: 51
		// (get) Token: 0x06001A11 RID: 6673 RVA: 0x0000D161 File Offset: 0x0000B361
		// (set) Token: 0x06001A12 RID: 6674 RVA: 0x0000D173 File Offset: 0x0000B373
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("237")]
		public int PreviewDefaultY
		{
			get
			{
				return Conversions.ToInteger(this["PreviewDefaultY"]);
			}
			set
			{
				this["PreviewDefaultY"] = value;
			}
		}

		// Token: 0x17000034 RID: 52
		// (get) Token: 0x06001A13 RID: 6675 RVA: 0x0000D186 File Offset: 0x0000B386
		// (set) Token: 0x06001A14 RID: 6676 RVA: 0x0000D198 File Offset: 0x0000B398
		[DebuggerNonUserCode]
		[UserScopedSetting]
		[DefaultSettingValue("760")]
		public int PreviewDoubleClickX
		{
			get
			{
				return Conversions.ToInteger(this["PreviewDoubleClickX"]);
			}
			set
			{
				this["PreviewDoubleClickX"] = value;
			}
		}

		// Token: 0x17000035 RID: 53
		// (get) Token: 0x06001A15 RID: 6677 RVA: 0x0000D1AB File Offset: 0x0000B3AB
		// (set) Token: 0x06001A16 RID: 6678 RVA: 0x0000D1BD File Offset: 0x0000B3BD
		[DefaultSettingValue("475")]
		[DebuggerNonUserCode]
		[UserScopedSetting]
		public int PreviewDoubleClickY
		{
			get
			{
				return Conversions.ToInteger(this["PreviewDoubleClickY"]);
			}
			set
			{
				this["PreviewDoubleClickY"] = value;
			}
		}

		// Token: 0x17000036 RID: 54
		// (get) Token: 0x06001A17 RID: 6679 RVA: 0x0000D1D0 File Offset: 0x0000B3D0
		// (set) Token: 0x06001A18 RID: 6680 RVA: 0x0000D1E2 File Offset: 0x0000B3E2
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("100")]
		public int PreviewDefaultSize
		{
			get
			{
				return Conversions.ToInteger(this["PreviewDefaultSize"]);
			}
			set
			{
				this["PreviewDefaultSize"] = value;
			}
		}

		// Token: 0x17000037 RID: 55
		// (get) Token: 0x06001A19 RID: 6681 RVA: 0x0000D1F5 File Offset: 0x0000B3F5
		// (set) Token: 0x06001A1A RID: 6682 RVA: 0x0000D207 File Offset: 0x0000B407
		[DefaultSettingValue("100")]
		[DebuggerNonUserCode]
		[UserScopedSetting]
		public int PreviewDoubleClickSize
		{
			get
			{
				return Conversions.ToInteger(this["PreviewDoubleClickSize"]);
			}
			set
			{
				this["PreviewDoubleClickSize"] = value;
			}
		}

		// Token: 0x17000038 RID: 56
		// (get) Token: 0x06001A1B RID: 6683 RVA: 0x0000D21A File Offset: 0x0000B41A
		// (set) Token: 0x06001A1C RID: 6684 RVA: 0x0000D22C File Offset: 0x0000B42C
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("True")]
		public bool PreviewDisplayFrameData
		{
			get
			{
				return Conversions.ToBoolean(this["PreviewDisplayFrameData"]);
			}
			set
			{
				this["PreviewDisplayFrameData"] = value;
			}
		}

		// Token: 0x17000039 RID: 57
		// (get) Token: 0x06001A1D RID: 6685 RVA: 0x0000D23F File Offset: 0x0000B43F
		// (set) Token: 0x06001A1E RID: 6686 RVA: 0x0000D251 File Offset: 0x0000B451
		[DefaultSettingValue("True")]
		[UserScopedSetting]
		[DebuggerNonUserCode]
		public bool PreviewTransparentFrames
		{
			get
			{
				return Conversions.ToBoolean(this["PreviewTransparentFrames"]);
			}
			set
			{
				this["PreviewTransparentFrames"] = value;
			}
		}

		// Token: 0x1700003A RID: 58
		// (get) Token: 0x06001A1F RID: 6687 RVA: 0x0000D264 File Offset: 0x0000B464
		// (set) Token: 0x06001A20 RID: 6688 RVA: 0x0000D276 File Offset: 0x0000B476
		[DefaultSettingValue("True")]
		[DebuggerNonUserCode]
		[UserScopedSetting]
		public bool PluginsUpload
		{
			get
			{
				return Conversions.ToBoolean(this["PluginsUpload"]);
			}
			set
			{
				this["PluginsUpload"] = value;
			}
		}

		// Token: 0x1700003B RID: 59
		// (get) Token: 0x06001A21 RID: 6689 RVA: 0x0000D289 File Offset: 0x0000B489
		// (set) Token: 0x06001A22 RID: 6690 RVA: 0x0000D29B File Offset: 0x0000B49B
		[DefaultSettingValue("")]
		[UserScopedSetting]
		[DebuggerNonUserCode]
		public string NetworkBandwidth
		{
			get
			{
				return Conversions.ToString(this["NetworkBandwidth"]);
			}
			set
			{
				this["NetworkBandwidth"] = value;
			}
		}

		// Token: 0x1700003C RID: 60
		// (get) Token: 0x06001A23 RID: 6691 RVA: 0x0000D2A9 File Offset: 0x0000B4A9
		// (set) Token: 0x06001A24 RID: 6692 RVA: 0x0000D2BB File Offset: 0x0000B4BB
		[DebuggerNonUserCode]
		[UserScopedSetting]
		[DefaultSettingValue("")]
		public string Password
		{
			get
			{
				return Conversions.ToString(this["Password"]);
			}
			set
			{
				this["Password"] = value;
			}
		}

		// Token: 0x1700003D RID: 61
		// (get) Token: 0x06001A25 RID: 6693 RVA: 0x0000D2C9 File Offset: 0x0000B4C9
		// (set) Token: 0x06001A26 RID: 6694 RVA: 0x0000D2DB File Offset: 0x0000B4DB
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("URL to plugin: http://site.com/loader.plg")]
		public string PluginsURLLoader
		{
			get
			{
				return Conversions.ToString(this["PluginsURLLoader"]);
			}
			set
			{
				this["PluginsURLLoader"] = value;
			}
		}

		// Token: 0x1700003E RID: 62
		// (get) Token: 0x06001A27 RID: 6695 RVA: 0x0000D2E9 File Offset: 0x0000B4E9
		// (set) Token: 0x06001A28 RID: 6696 RVA: 0x0000D2FB File Offset: 0x0000B4FB
		[DefaultSettingValue("URL to plugin: http://site.com/xmr64.plg")]
		[UserScopedSetting]
		[DebuggerNonUserCode]
		public string PluginsURLXMR64
		{
			get
			{
				return Conversions.ToString(this["PluginsURLXMR64"]);
			}
			set
			{
				this["PluginsURLXMR64"] = value;
			}
		}

		// Token: 0x1700003F RID: 63
		// (get) Token: 0x06001A29 RID: 6697 RVA: 0x0000D309 File Offset: 0x0000B509
		// (set) Token: 0x06001A2A RID: 6698 RVA: 0x0000D31B File Offset: 0x0000B51B
		[UserScopedSetting]
		[DefaultSettingValue("1235")]
		[DebuggerNonUserCode]
		public int PortTor
		{
			get
			{
				return Conversions.ToInteger(this["PortTor"]);
			}
			set
			{
				this["PortTor"] = value;
			}
		}

		// Token: 0x17000040 RID: 64
		// (get) Token: 0x06001A2B RID: 6699 RVA: 0x0000D32E File Offset: 0x0000B52E
		// (set) Token: 0x06001A2C RID: 6700 RVA: 0x0000D340 File Offset: 0x0000B540
		[DefaultSettingValue("")]
		[DebuggerNonUserCode]
		[UserScopedSetting]
		public string HostTorIP
		{
			get
			{
				return Conversions.ToString(this["HostTorIP"]);
			}
			set
			{
				this["HostTorIP"] = value;
			}
		}

		// Token: 0x17000041 RID: 65
		// (get) Token: 0x06001A2D RID: 6701 RVA: 0x0000D34E File Offset: 0x0000B54E
		// (set) Token: 0x06001A2E RID: 6702 RVA: 0x0000D360 File Offset: 0x0000B560
		[DebuggerNonUserCode]
		[DefaultSettingValue("False")]
		[UserScopedSetting]
		public bool AutostartTor
		{
			get
			{
				return Conversions.ToBoolean(this["AutostartTor"]);
			}
			set
			{
				this["AutostartTor"] = value;
			}
		}

		// Token: 0x17000042 RID: 66
		// (get) Token: 0x06001A2F RID: 6703 RVA: 0x0000D373 File Offset: 0x0000B573
		// (set) Token: 0x06001A30 RID: 6704 RVA: 0x0000D385 File Offset: 0x0000B585
		[DebuggerNonUserCode]
		[UserScopedSetting]
		[DefaultSettingValue("5")]
		public int TransfersConcurrentMax
		{
			get
			{
				return Conversions.ToInteger(this["TransfersConcurrentMax"]);
			}
			set
			{
				this["TransfersConcurrentMax"] = value;
			}
		}

		// Token: 0x17000043 RID: 67
		// (get) Token: 0x06001A31 RID: 6705 RVA: 0x0000D398 File Offset: 0x0000B598
		// (set) Token: 0x06001A32 RID: 6706 RVA: 0x0000D3AA File Offset: 0x0000B5AA
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("")]
		public string TorConfigUsername
		{
			get
			{
				return Conversions.ToString(this["TorConfigUsername"]);
			}
			set
			{
				this["TorConfigUsername"] = value;
			}
		}

		// Token: 0x17000044 RID: 68
		// (get) Token: 0x06001A33 RID: 6707 RVA: 0x0000D3B8 File Offset: 0x0000B5B8
		// (set) Token: 0x06001A34 RID: 6708 RVA: 0x0000D3CA File Offset: 0x0000B5CA
		[DebuggerNonUserCode]
		[UserScopedSetting]
		[DefaultSettingValue("False")]
		public bool TorConfigAutostart
		{
			get
			{
				return Conversions.ToBoolean(this["TorConfigAutostart"]);
			}
			set
			{
				this["TorConfigAutostart"] = value;
			}
		}

		// Token: 0x17000045 RID: 69
		// (get) Token: 0x06001A35 RID: 6709 RVA: 0x0000D3DD File Offset: 0x0000B5DD
		// (set) Token: 0x06001A36 RID: 6710 RVA: 0x0000D3EF File Offset: 0x0000B5EF
		[UserScopedSetting]
		[DefaultSettingValue("True")]
		[DebuggerNonUserCode]
		public bool ShowGroupsTransfers
		{
			get
			{
				return Conversions.ToBoolean(this["ShowGroupsTransfers"]);
			}
			set
			{
				this["ShowGroupsTransfers"] = value;
			}
		}

		// Token: 0x17000046 RID: 70
		// (get) Token: 0x06001A37 RID: 6711 RVA: 0x0000D402 File Offset: 0x0000B602
		// (set) Token: 0x06001A38 RID: 6712 RVA: 0x0000D414 File Offset: 0x0000B614
		[DebuggerNonUserCode]
		[DefaultSettingValue("True")]
		[UserScopedSetting]
		public bool GroupSubtitlesTransfers
		{
			get
			{
				return Conversions.ToBoolean(this["GroupSubtitlesTransfers"]);
			}
			set
			{
				this["GroupSubtitlesTransfers"] = value;
			}
		}

		// Token: 0x17000047 RID: 71
		// (get) Token: 0x06001A39 RID: 6713 RVA: 0x0000D427 File Offset: 0x0000B627
		// (set) Token: 0x06001A3A RID: 6714 RVA: 0x0000D439 File Offset: 0x0000B639
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("True")]
		public bool GroupSortingTransfersDir
		{
			get
			{
				return Conversions.ToBoolean(this["GroupSortingTransfersDir"]);
			}
			set
			{
				this["GroupSortingTransfersDir"] = value;
			}
		}

		// Token: 0x17000048 RID: 72
		// (get) Token: 0x06001A3B RID: 6715 RVA: 0x0000D44C File Offset: 0x0000B64C
		// (set) Token: 0x06001A3C RID: 6716 RVA: 0x0000D45E File Offset: 0x0000B65E
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("False")]
		public bool GroupSortingTransfersUser
		{
			get
			{
				return Conversions.ToBoolean(this["GroupSortingTransfersUser"]);
			}
			set
			{
				this["GroupSortingTransfersUser"] = value;
			}
		}

		// Token: 0x17000049 RID: 73
		// (get) Token: 0x06001A3D RID: 6717 RVA: 0x0000D471 File Offset: 0x0000B671
		// (set) Token: 0x06001A3E RID: 6718 RVA: 0x0000D483 File Offset: 0x0000B683
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("0")]
		public int MaxBandwidthRateIn
		{
			get
			{
				return Conversions.ToInteger(this["MaxBandwidthRateIn"]);
			}
			set
			{
				this["MaxBandwidthRateIn"] = value;
			}
		}

		// Token: 0x1700004A RID: 74
		// (get) Token: 0x06001A3F RID: 6719 RVA: 0x0000D496 File Offset: 0x0000B696
		// (set) Token: 0x06001A40 RID: 6720 RVA: 0x0000D4A8 File Offset: 0x0000B6A8
		[DebuggerNonUserCode]
		[DefaultSettingValue("0")]
		[UserScopedSetting]
		public int MaxBandwidthRateOut
		{
			get
			{
				return Conversions.ToInteger(this["MaxBandwidthRateOut"]);
			}
			set
			{
				this["MaxBandwidthRateOut"] = value;
			}
		}

		// Token: 0x1700004B RID: 75
		// (get) Token: 0x06001A41 RID: 6721 RVA: 0x0000D4BB File Offset: 0x0000B6BB
		// (set) Token: 0x06001A42 RID: 6722 RVA: 0x0000D4CD File Offset: 0x0000B6CD
		[DebuggerNonUserCode]
		[UserScopedSetting]
		[DefaultSettingValue("True")]
		public bool TransferReplaceExisting
		{
			get
			{
				return Conversions.ToBoolean(this["TransferReplaceExisting"]);
			}
			set
			{
				this["TransferReplaceExisting"] = value;
			}
		}

		// Token: 0x1700004C RID: 76
		// (get) Token: 0x06001A43 RID: 6723 RVA: 0x0000D4E0 File Offset: 0x0000B6E0
		// (set) Token: 0x06001A44 RID: 6724 RVA: 0x0000D4F2 File Offset: 0x0000B6F2
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("True")]
		public bool TransferReplaceFilesModified
		{
			get
			{
				return Conversions.ToBoolean(this["TransferReplaceFilesModified"]);
			}
			set
			{
				this["TransferReplaceFilesModified"] = value;
			}
		}

		// Token: 0x1700004D RID: 77
		// (get) Token: 0x06001A45 RID: 6725 RVA: 0x0000D505 File Offset: 0x0000B705
		// (set) Token: 0x06001A46 RID: 6726 RVA: 0x0000D517 File Offset: 0x0000B717
		[DefaultSettingValue("True")]
		[UserScopedSetting]
		[DebuggerNonUserCode]
		public bool TransferReplaceFilesAll
		{
			get
			{
				return Conversions.ToBoolean(this["TransferReplaceFilesAll"]);
			}
			set
			{
				this["TransferReplaceFilesAll"] = value;
			}
		}

		// Token: 0x1700004E RID: 78
		// (get) Token: 0x06001A47 RID: 6727 RVA: 0x0000D52A File Offset: 0x0000B72A
		// (set) Token: 0x06001A48 RID: 6728 RVA: 0x0000D53C File Offset: 0x0000B73C
		[DebuggerNonUserCode]
		[DefaultSettingValue("True")]
		[UserScopedSetting]
		public bool ConNotifications
		{
			get
			{
				return Conversions.ToBoolean(this["ConNotifications"]);
			}
			set
			{
				this["ConNotifications"] = value;
			}
		}

		// Token: 0x1700004F RID: 79
		// (get) Token: 0x06001A49 RID: 6729 RVA: 0x0000D54F File Offset: 0x0000B74F
		// (set) Token: 0x06001A4A RID: 6730 RVA: 0x0000D561 File Offset: 0x0000B761
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("False")]
		public bool Gridlines
		{
			get
			{
				return Conversions.ToBoolean(this["Gridlines"]);
			}
			set
			{
				this["Gridlines"] = value;
			}
		}

		// Token: 0x17000050 RID: 80
		// (get) Token: 0x06001A4B RID: 6731 RVA: 0x0000D574 File Offset: 0x0000B774
		// (set) Token: 0x06001A4C RID: 6732 RVA: 0x0000D586 File Offset: 0x0000B786
		[DebuggerNonUserCode]
		[DefaultSettingValue("True")]
		[UserScopedSetting]
		public bool ConKlgColors
		{
			get
			{
				return Conversions.ToBoolean(this["ConKlgColors"]);
			}
			set
			{
				this["ConKlgColors"] = value;
			}
		}

		// Token: 0x17000051 RID: 81
		// (get) Token: 0x06001A4D RID: 6733 RVA: 0x0000D599 File Offset: 0x0000B799
		// (set) Token: 0x06001A4E RID: 6734 RVA: 0x0000D5AB File Offset: 0x0000B7AB
		[DefaultSettingValue("True")]
		[DebuggerNonUserCode]
		[UserScopedSetting]
		public bool TorDisableCaching
		{
			get
			{
				return Conversions.ToBoolean(this["TorDisableCaching"]);
			}
			set
			{
				this["TorDisableCaching"] = value;
			}
		}

		// Token: 0x17000052 RID: 82
		// (get) Token: 0x06001A4F RID: 6735 RVA: 0x0000D5BE File Offset: 0x0000B7BE
		// (set) Token: 0x06001A50 RID: 6736 RVA: 0x0000D5D0 File Offset: 0x0000B7D0
		[UserScopedSetting]
		[DefaultSettingValue("True")]
		[DebuggerNonUserCode]
		public bool TorAvoidDiskWrites
		{
			get
			{
				return Conversions.ToBoolean(this["TorAvoidDiskWrites"]);
			}
			set
			{
				this["TorAvoidDiskWrites"] = value;
			}
		}

		// Token: 0x17000053 RID: 83
		// (get) Token: 0x06001A51 RID: 6737 RVA: 0x0000D5E3 File Offset: 0x0000B7E3
		// (set) Token: 0x06001A52 RID: 6738 RVA: 0x0000D5F5 File Offset: 0x0000B7F5
		[DebuggerNonUserCode]
		[UserScopedSetting]
		[DefaultSettingValue("True")]
		public bool TorRejectSingleHop
		{
			get
			{
				return Conversions.ToBoolean(this["TorRejectSingleHop"]);
			}
			set
			{
				this["TorRejectSingleHop"] = value;
			}
		}

		// Token: 0x17000054 RID: 84
		// (get) Token: 0x06001A53 RID: 6739 RVA: 0x0000D608 File Offset: 0x0000B808
		// (set) Token: 0x06001A54 RID: 6740 RVA: 0x0000D61A File Offset: 0x0000B81A
		[UserScopedSetting]
		[DefaultSettingValue("True")]
		[DebuggerNonUserCode]
		public bool TorNoExec
		{
			get
			{
				return Conversions.ToBoolean(this["TorNoExec"]);
			}
			set
			{
				this["TorNoExec"] = value;
			}
		}

		// Token: 0x17000055 RID: 85
		// (get) Token: 0x06001A55 RID: 6741 RVA: 0x0000D62D File Offset: 0x0000B82D
		// (set) Token: 0x06001A56 RID: 6742 RVA: 0x0000D63F File Offset: 0x0000B83F
		[DefaultSettingValue("False")]
		[DebuggerNonUserCode]
		[UserScopedSetting]
		public bool TorUseConstrainedSockets
		{
			get
			{
				return Conversions.ToBoolean(this["TorUseConstrainedSockets"]);
			}
			set
			{
				this["TorUseConstrainedSockets"] = value;
			}
		}

		// Token: 0x17000056 RID: 86
		// (get) Token: 0x06001A57 RID: 6743 RVA: 0x0000D652 File Offset: 0x0000B852
		// (set) Token: 0x06001A58 RID: 6744 RVA: 0x0000D664 File Offset: 0x0000B864
		[DebuggerNonUserCode]
		[DefaultSettingValue("8192")]
		[UserScopedSetting]
		public string TorConstrainedSocketSize
		{
			get
			{
				return Conversions.ToString(this["TorConstrainedSocketSize"]);
			}
			set
			{
				this["TorConstrainedSocketSize"] = value;
			}
		}

		// Token: 0x17000057 RID: 87
		// (get) Token: 0x06001A59 RID: 6745 RVA: 0x0000D672 File Offset: 0x0000B872
		// (set) Token: 0x06001A5A RID: 6746 RVA: 0x0000D684 File Offset: 0x0000B884
		[DebuggerNonUserCode]
		[UserScopedSetting]
		[DefaultSettingValue("True")]
		public bool ConLogColors
		{
			get
			{
				return Conversions.ToBoolean(this["ConLogColors"]);
			}
			set
			{
				this["ConLogColors"] = value;
			}
		}

		// Token: 0x17000058 RID: 88
		// (get) Token: 0x06001A5B RID: 6747 RVA: 0x0000D697 File Offset: 0x0000B897
		// (set) Token: 0x06001A5C RID: 6748 RVA: 0x0000D6A9 File Offset: 0x0000B8A9
		[DefaultSettingValue("1")]
		[UserScopedSetting]
		[DebuggerNonUserCode]
		public int LayoutTheme
		{
			get
			{
				return Conversions.ToInteger(this["LayoutTheme"]);
			}
			set
			{
				this["LayoutTheme"] = value;
			}
		}

		// Token: 0x17000059 RID: 89
		// (get) Token: 0x06001A5D RID: 6749 RVA: 0x0000D6BC File Offset: 0x0000B8BC
		// (set) Token: 0x06001A5E RID: 6750 RVA: 0x0000D6CE File Offset: 0x0000B8CE
		[DebuggerNonUserCode]
		[DefaultSettingValue("")]
		[UserScopedSetting]
		public string BuilderHost
		{
			get
			{
				return Conversions.ToString(this["BuilderHost"]);
			}
			set
			{
				this["BuilderHost"] = value;
			}
		}

		// Token: 0x1700005A RID: 90
		// (get) Token: 0x06001A5F RID: 6751 RVA: 0x0000D6DC File Offset: 0x0000B8DC
		// (set) Token: 0x06001A60 RID: 6752 RVA: 0x0000D6EE File Offset: 0x0000B8EE
		[DefaultSettingValue("")]
		[DebuggerNonUserCode]
		[UserScopedSetting]
		public string BuilderPort
		{
			get
			{
				return Conversions.ToString(this["BuilderPort"]);
			}
			set
			{
				this["BuilderPort"] = value;
			}
		}

		// Token: 0x1700005B RID: 91
		// (get) Token: 0x06001A61 RID: 6753 RVA: 0x0000D6FC File Offset: 0x0000B8FC
		// (set) Token: 0x06001A62 RID: 6754 RVA: 0x0000D70E File Offset: 0x0000B90E
		[DebuggerNonUserCode]
		[DefaultSettingValue("")]
		[UserScopedSetting]
		public string BuilderPass
		{
			get
			{
				return Conversions.ToString(this["BuilderPass"]);
			}
			set
			{
				this["BuilderPass"] = value;
			}
		}

		// Token: 0x1700005C RID: 92
		// (get) Token: 0x06001A63 RID: 6755 RVA: 0x0000D71C File Offset: 0x0000B91C
		// (set) Token: 0x06001A64 RID: 6756 RVA: 0x0000D72E File Offset: 0x0000B92E
		[DebuggerNonUserCode]
		[DefaultSettingValue("")]
		[UserScopedSetting]
		public string BuilderTorPrcname
		{
			get
			{
				return Conversions.ToString(this["BuilderTorPrcname"]);
			}
			set
			{
				this["BuilderTorPrcname"] = value;
			}
		}

		// Token: 0x1700005D RID: 93
		// (get) Token: 0x06001A65 RID: 6757 RVA: 0x0000D73C File Offset: 0x0000B93C
		// (set) Token: 0x06001A66 RID: 6758 RVA: 0x0000D74E File Offset: 0x0000B94E
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("")]
		public string BuilderFilename
		{
			get
			{
				return Conversions.ToString(this["BuilderFilename"]);
			}
			set
			{
				this["BuilderFilename"] = value;
			}
		}

		// Token: 0x1700005E RID: 94
		// (get) Token: 0x06001A67 RID: 6759 RVA: 0x0000D75C File Offset: 0x0000B95C
		// (set) Token: 0x06001A68 RID: 6760 RVA: 0x0000D76E File Offset: 0x0000B96E
		[DefaultSettingValue("")]
		[DebuggerNonUserCode]
		[UserScopedSetting]
		public string BuilderInstallFolder
		{
			get
			{
				return Conversions.ToString(this["BuilderInstallFolder"]);
			}
			set
			{
				this["BuilderInstallFolder"] = value;
			}
		}

		// Token: 0x1700005F RID: 95
		// (get) Token: 0x06001A69 RID: 6761 RVA: 0x0000D77C File Offset: 0x0000B97C
		// (set) Token: 0x06001A6A RID: 6762 RVA: 0x0000D78E File Offset: 0x0000B98E
		[UserScopedSetting]
		[DefaultSettingValue("True")]
		[DebuggerNonUserCode]
		public bool BuilderTLS
		{
			get
			{
				return Conversions.ToBoolean(this["BuilderTLS"]);
			}
			set
			{
				this["BuilderTLS"] = value;
			}
		}

		// Token: 0x17000061 RID: 97
		// (get) Token: 0x06001A6D RID: 6765 RVA: 0x0000D7C1 File Offset: 0x0000B9C1
		// (set) Token: 0x06001A6E RID: 6766 RVA: 0x0000D7D3 File Offset: 0x0000B9D3
		[UserScopedSetting]
		[DefaultSettingValue("True")]
		[DebuggerNonUserCode]
		public bool SettingsTray
		{
			get
			{
				return Conversions.ToBoolean(this["SettingsTray"]);
			}
			set
			{
				this["SettingsTray"] = value;
			}
		}

		// Token: 0x17000062 RID: 98
		// (get) Token: 0x06001A6F RID: 6767 RVA: 0x0000D7E6 File Offset: 0x0000B9E6
		// (set) Token: 0x06001A70 RID: 6768 RVA: 0x0000D7F8 File Offset: 0x0000B9F8
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("False")]
		public bool PluginsSavePws
		{
			get
			{
				return Conversions.ToBoolean(this["PluginsSavePws"]);
			}
			set
			{
				this["PluginsSavePws"] = value;
			}
		}

		// Token: 0x17000063 RID: 99
		// (get) Token: 0x06001A71 RID: 6769 RVA: 0x0000D80B File Offset: 0x0000BA0B
		// (set) Token: 0x06001A72 RID: 6770 RVA: 0x0000D81D File Offset: 0x0000BA1D
		[DebuggerNonUserCode]
		[UserScopedSetting]
		[DefaultSettingValue("False")]
		public bool UIThumbnails
		{
			get
			{
				return Conversions.ToBoolean(this["UIThumbnails"]);
			}
			set
			{
				this["UIThumbnails"] = value;
			}
		}

		// Token: 0x04000A03 RID: 2563
		private static MySettings defaultInstance = (MySettings)SettingsBase.Synchronized(new MySettings());

		// Token: 0x04000A04 RID: 2564
		private static bool addedHandler;

		// Token: 0x04000A05 RID: 2565
		private static object addedHandlerLockObject = RuntimeHelpers.GetObjectValue(new object());
	}
}
