﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Configuration;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic.CompilerServices;

namespace BitRAT.My
{
	// Token: 0x020001DA RID: 474
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "16.7.0.0")]
	[CompilerGenerated]
	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal sealed partial class MySettings : ApplicationSettingsBase
	{
		// Token: 0x17000060 RID: 96
		// (get) Token: 0x06001A6B RID: 6763 RVA: 0x0000D7A1 File Offset: 0x0000B9A1
		// (set) Token: 0x06001A6C RID: 6764 RVA: 0x0000D7B3 File Offset: 0x0000B9B3
		[DebuggerNonUserCode]
		[UserScopedSetting]
		public ArrayList OnJoinCommands
		{
			get
			{
				return (ArrayList)this["OnJoinCommands"];
			}
			set
			{
				this["OnJoinCommands"] = value;
			}
		}
	}
}
