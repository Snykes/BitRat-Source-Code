﻿using System;
using System.Collections.Generic;

// Token: 0x0200001F RID: 31
internal sealed class Class19 : IDisposable, Interface7
{
	// Token: 0x060001F1 RID: 497 RVA: 0x000038D6 File Offset: 0x00001AD6
	public int imethod_0()
	{
		return this.list_0.Count;
	}

	// Token: 0x060001F2 RID: 498 RVA: 0x000038E3 File Offset: 0x00001AE3
	public void imethod_3()
	{
		this.list_0.Clear();
	}

	// Token: 0x060001F3 RID: 499 RVA: 0x000038F0 File Offset: 0x00001AF0
	public Interface7 imethod_4()
	{
		return new Class19();
	}

	// Token: 0x060001F4 RID: 500 RVA: 0x000038F7 File Offset: 0x00001AF7
	public void Dispose()
	{
		this.imethod_3();
		this.list_0 = null;
	}

	// Token: 0x060001F5 RID: 501 RVA: 0x00003906 File Offset: 0x00001B06
	public void imethod_1(int int_0, out byte byte_0)
	{
		byte_0 = this.method_0(this.list_0[int_0], int_0);
	}

	// Token: 0x060001F6 RID: 502 RVA: 0x0001BB28 File Offset: 0x00019D28
	public void imethod_2(int int_0, ref byte byte_0)
	{
		for (int i = this.list_0.Count; i <= int_0; i++)
		{
			if (i == int_0)
			{
				this.list_0.Add(this.method_1(byte_0, i));
				return;
			}
			this.list_0.Add(this.method_1(0, i));
		}
		this.list_0[int_0] = this.method_1(byte_0, int_0);
	}

	// Token: 0x060001F7 RID: 503 RVA: 0x0000391D File Offset: 0x00001B1D
	private byte method_0(byte byte_0, int int_0)
	{
		throw new NotImplementedException();
	}

	// Token: 0x060001F8 RID: 504 RVA: 0x0000391D File Offset: 0x00001B1D
	private byte method_1(byte byte_0, int int_0)
	{
		throw new NotImplementedException();
	}

	// Token: 0x04000130 RID: 304
	private List<byte> list_0 = new List<byte>();
}
