﻿using System;

// Token: 0x02000108 RID: 264
public enum GEnum0
{
	// Token: 0x040005A3 RID: 1443
	SymmetricActive,
	// Token: 0x040005A4 RID: 1444
	SymmetricPassive,
	// Token: 0x040005A5 RID: 1445
	Client,
	// Token: 0x040005A6 RID: 1446
	Server,
	// Token: 0x040005A7 RID: 1447
	Broadcast,
	// Token: 0x040005A8 RID: 1448
	Unknown
}
