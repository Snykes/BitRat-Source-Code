﻿// Token: 0x0200013D RID: 317
[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
public sealed partial class fTorConfig : global::System.Windows.Forms.Form
{
	// Token: 0x060011A9 RID: 4521 RVA: 0x00080F90 File Offset: 0x0007F190
	[global::System.Diagnostics.DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && this.icontainer_0 != null)
			{
				this.icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	// Token: 0x060011AA RID: 4522 RVA: 0x00080FD0 File Offset: 0x0007F1D0
	[global::System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		this.vmethod_1(new global::System.Windows.Forms.CheckBox());
		this.vmethod_3(new global::System.Windows.Forms.Timer(this.icontainer_0));
		this.vmethod_5(new global::System.Windows.Forms.StatusStrip());
		this.vmethod_7(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_11(new global::System.Windows.Forms.TextBox());
		this.vmethod_13(new global::System.Windows.Forms.Label());
		this.vmethod_15(new global::System.Windows.Forms.Label());
		this.vmethod_19(new global::System.Windows.Forms.TextBox());
		this.vmethod_21(new global::System.ComponentModel.BackgroundWorker());
		this.vmethod_23(new global::VisualPlus.Toolkit.Controls.Interactivity.VisualButton());
		this.vmethod_25(new global::VisualPlus.Toolkit.Controls.Interactivity.VisualButton());
		this.vmethod_27(new global::System.Windows.Forms.PictureBox());
		this.vmethod_17(new global::System.Windows.Forms.PictureBox());
		this.vmethod_9(new global::System.Windows.Forms.PictureBox());
		this.vmethod_29(new global::System.Windows.Forms.PictureBox());
		this.vmethod_31(new global::VisualPlus.Toolkit.Controls.Interactivity.VisualButton());
		this.vmethod_33(new global::System.Windows.Forms.Timer(this.icontainer_0));
		this.vmethod_35(new global::System.Windows.Forms.PictureBox());
		this.vmethod_4().SuspendLayout();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_26()).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_16()).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_8()).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_28()).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_34()).BeginInit();
		base.SuspendLayout();
		this.vmethod_0().AutoSize = true;
		this.vmethod_0().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_0().Location = new global::System.Drawing.Point(74, 90);
		this.vmethod_0().Margin = new global::System.Windows.Forms.Padding(1);
		this.vmethod_0().Name = "chkTorConfigAutostart";
		this.vmethod_0().RightToLeft = global::System.Windows.Forms.RightToLeft.Yes;
		this.vmethod_0().Size = new global::System.Drawing.Size(68, 17);
		this.vmethod_0().TabIndex = 34;
		this.vmethod_0().Text = "Autostart";
		this.vmethod_0().UseVisualStyleBackColor = false;
		this.vmethod_2().Enabled = true;
		this.vmethod_2().Interval = 1000;
		this.vmethod_4().AutoSize = false;
		this.vmethod_4().BackColor = global::System.Drawing.SystemColors.Control;
		this.vmethod_4().ImageScalingSize = new global::System.Drawing.Size(28, 28);
		this.vmethod_4().Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_6()
		});
		this.vmethod_4().Location = new global::System.Drawing.Point(0, 113);
		this.vmethod_4().Name = "ssStatus";
		this.vmethod_4().Padding = new global::System.Windows.Forms.Padding(1, 0, 7, 0);
		this.vmethod_4().Size = new global::System.Drawing.Size(478, 21);
		this.vmethod_4().SizingGrip = false;
		this.vmethod_4().Stretch = false;
		this.vmethod_4().TabIndex = 36;
		this.vmethod_4().Text = "stStatus";
		this.vmethod_6().AutoSize = false;
		this.vmethod_6().BackColor = global::System.Drawing.SystemColors.Control;
		this.vmethod_6().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_6().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_6().Margin = new global::System.Windows.Forms.Padding(0, 4, 0, 2);
		this.vmethod_6().Name = "tsStatus";
		this.vmethod_6().Size = new global::System.Drawing.Size(470, 15);
		this.vmethod_6().Spring = true;
		this.vmethod_6().Text = "Status: N/A";
		this.vmethod_6().TextAlign = global::System.Drawing.ContentAlignment.TopLeft;
		this.vmethod_10().Location = new global::System.Drawing.Point(99, 11);
		this.vmethod_10().Margin = new global::System.Windows.Forms.Padding(1);
		this.vmethod_10().MaxLength = 20;
		this.vmethod_10().Name = "txtUsername";
		this.vmethod_10().Size = new global::System.Drawing.Size(121, 20);
		this.vmethod_10().TabIndex = 41;
		this.vmethod_12().AutoSize = true;
		this.vmethod_12().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_12().FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.vmethod_12().Location = new global::System.Drawing.Point(2, 14);
		this.vmethod_12().Margin = new global::System.Windows.Forms.Padding(1, 0, 1, 0);
		this.vmethod_12().Name = "lblNickname";
		this.vmethod_12().Size = new global::System.Drawing.Size(95, 13);
		this.vmethod_12().TabIndex = 40;
		this.vmethod_12().Text = "Service nickname:";
		this.vmethod_12().TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
		this.vmethod_14().AutoSize = true;
		this.vmethod_14().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_14().FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.vmethod_14().Location = new global::System.Drawing.Point(16, 45);
		this.vmethod_14().Margin = new global::System.Windows.Forms.Padding(1, 0, 1, 0);
		this.vmethod_14().Name = "lblHostname";
		this.vmethod_14().Size = new global::System.Drawing.Size(81, 13);
		this.vmethod_14().TabIndex = 43;
		this.vmethod_14().Text = "Your hostname:";
		this.vmethod_14().TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
		this.vmethod_18().Enabled = false;
		this.vmethod_18().Location = new global::System.Drawing.Point(99, 42);
		this.vmethod_18().Margin = new global::System.Windows.Forms.Padding(1);
		this.vmethod_18().MaxLength = 128;
		this.vmethod_18().Multiline = true;
		this.vmethod_18().Name = "txtHostname";
		this.vmethod_18().ReadOnly = true;
		this.vmethod_18().Size = new global::System.Drawing.Size(288, 32);
		this.vmethod_18().TabIndex = 44;
		this.vmethod_18().Text = "N/A";
		this.vmethod_20().WorkerSupportsCancellation = true;
		this.vmethod_22().BackColorState.Disabled = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_22().BackColorState.Enabled = global::System.Drawing.Color.FromArgb(220, 220, 220);
		this.vmethod_22().BackColorState.Hover = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_22().BackColorState.Pressed = global::System.Drawing.Color.FromArgb(192, 192, 192);
		this.vmethod_22().Border.Color = global::System.Drawing.Color.FromArgb(180, 180, 180);
		this.vmethod_22().Border.HoverColor = global::System.Drawing.Color.FromArgb(120, 183, 230);
		this.vmethod_22().Border.HoverVisible = true;
		this.vmethod_22().Border.Rounding = 6;
		this.vmethod_22().Border.Thickness = 1;
		this.vmethod_22().Border.Type = 1;
		this.vmethod_22().Border.Visible = true;
		this.vmethod_22().DialogResult = global::System.Windows.Forms.DialogResult.None;
		this.vmethod_22().ForeColor = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_22().Image = null;
		this.vmethod_22().Location = new global::System.Drawing.Point(5, 88);
		this.vmethod_22().MouseState = 0;
		this.vmethod_22().Name = "btnStartStop";
		this.vmethod_22().Size = new global::System.Drawing.Size(65, 19);
		this.vmethod_22().TabIndex = 49;
		this.vmethod_22().Text = "Start";
		this.vmethod_22().TextImageRelation = global::System.Windows.Forms.TextImageRelation.Overlay;
		this.vmethod_22().TextStyle.Disabled = global::System.Drawing.Color.FromArgb(131, 129, 129);
		this.vmethod_22().TextStyle.Enabled = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_22().TextStyle.Hover = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_22().TextStyle.Pressed = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_22().TextStyle.TextAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_22().TextStyle.TextLineAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_22().TextStyle.TextRenderingHint = global::System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
		this.vmethod_24().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_24().BackColorState.Disabled = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_24().BackColorState.Enabled = global::System.Drawing.Color.FromArgb(220, 220, 220);
		this.vmethod_24().BackColorState.Hover = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_24().BackColorState.Pressed = global::System.Drawing.Color.FromArgb(192, 192, 192);
		this.vmethod_24().Border.Color = global::System.Drawing.Color.FromArgb(180, 180, 180);
		this.vmethod_24().Border.HoverColor = global::System.Drawing.Color.FromArgb(120, 183, 230);
		this.vmethod_24().Border.HoverVisible = true;
		this.vmethod_24().Border.Rounding = 6;
		this.vmethod_24().Border.Thickness = 1;
		this.vmethod_24().Border.Type = 1;
		this.vmethod_24().Border.Visible = true;
		this.vmethod_24().DialogResult = global::System.Windows.Forms.DialogResult.None;
		this.vmethod_24().ForeColor = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_24().Image = null;
		this.vmethod_24().Location = new global::System.Drawing.Point(411, 88);
		this.vmethod_24().MouseState = 0;
		this.vmethod_24().Name = "btnSaveSettings";
		this.vmethod_24().Size = new global::System.Drawing.Size(62, 19);
		this.vmethod_24().TabIndex = 53;
		this.vmethod_24().Text = "Save";
		this.vmethod_24().TextImageRelation = global::System.Windows.Forms.TextImageRelation.Overlay;
		this.vmethod_24().TextStyle.Disabled = global::System.Drawing.Color.FromArgb(131, 129, 129);
		this.vmethod_24().TextStyle.Enabled = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_24().TextStyle.Hover = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_24().TextStyle.Pressed = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_24().TextStyle.TextAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_24().TextStyle.TextLineAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_24().TextStyle.TextRenderingHint = global::System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
		this.vmethod_26().Image = global::Class131.smethod_51();
		this.vmethod_26().Location = new global::System.Drawing.Point(458, 4);
		this.vmethod_26().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_26().Name = "PictureBox1";
		this.vmethod_26().Size = new global::System.Drawing.Size(15, 15);
		this.vmethod_26().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_26().TabIndex = 55;
		this.vmethod_26().TabStop = false;
		this.vmethod_16().Image = global::Class131.smethod_24();
		this.vmethod_16().Location = new global::System.Drawing.Point(411, 51);
		this.vmethod_16().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_16().Name = "pbHostname";
		this.vmethod_16().Size = new global::System.Drawing.Size(15, 15);
		this.vmethod_16().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_16().TabIndex = 45;
		this.vmethod_16().TabStop = false;
		this.vmethod_8().Image = global::Class131.smethod_24();
		this.vmethod_8().Location = new global::System.Drawing.Point(223, 12);
		this.vmethod_8().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_8().Name = "pbInfoNickname";
		this.vmethod_8().Size = new global::System.Drawing.Size(15, 15);
		this.vmethod_8().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_8().TabIndex = 42;
		this.vmethod_8().TabStop = false;
		this.vmethod_28().Enabled = false;
		this.vmethod_28().Image = global::Class131.smethod_33();
		this.vmethod_28().Location = new global::System.Drawing.Point(390, 51);
		this.vmethod_28().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_28().Name = "pbCopyHWID";
		this.vmethod_28().Size = new global::System.Drawing.Size(15, 15);
		this.vmethod_28().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_28().TabIndex = 117;
		this.vmethod_28().TabStop = false;
		this.vmethod_30().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_30().BackColorState.Disabled = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_30().BackColorState.Enabled = global::System.Drawing.Color.FromArgb(220, 220, 220);
		this.vmethod_30().BackColorState.Hover = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_30().BackColorState.Pressed = global::System.Drawing.Color.FromArgb(192, 192, 192);
		this.vmethod_30().Border.Color = global::System.Drawing.Color.FromArgb(180, 180, 180);
		this.vmethod_30().Border.HoverColor = global::System.Drawing.Color.FromArgb(120, 183, 230);
		this.vmethod_30().Border.HoverVisible = true;
		this.vmethod_30().Border.Rounding = 6;
		this.vmethod_30().Border.Thickness = 1;
		this.vmethod_30().Border.Type = 1;
		this.vmethod_30().Border.Visible = true;
		this.vmethod_30().DialogResult = global::System.Windows.Forms.DialogResult.None;
		this.vmethod_30().Enabled = false;
		this.vmethod_30().ForeColor = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_30().Image = null;
		this.vmethod_30().Location = new global::System.Drawing.Point(305, 88);
		this.vmethod_30().MouseState = 0;
		this.vmethod_30().Name = "btnBackup";
		this.vmethod_30().Size = new global::System.Drawing.Size(62, 19);
		this.vmethod_30().TabIndex = 118;
		this.vmethod_30().Text = "Backup";
		this.vmethod_30().TextImageRelation = global::System.Windows.Forms.TextImageRelation.Overlay;
		this.vmethod_30().TextStyle.Disabled = global::System.Drawing.Color.FromArgb(131, 129, 129);
		this.vmethod_30().TextStyle.Enabled = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_30().TextStyle.Hover = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_30().TextStyle.Pressed = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_30().TextStyle.TextAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_30().TextStyle.TextLineAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_30().TextStyle.TextRenderingHint = global::System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
		this.vmethod_32().Enabled = true;
		this.vmethod_32().Interval = 500;
		this.vmethod_34().Enabled = false;
		this.vmethod_34().Image = global::Class131.smethod_24();
		this.vmethod_34().Location = new global::System.Drawing.Point(372, 90);
		this.vmethod_34().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_34().Name = "pbBackupInfo";
		this.vmethod_34().Size = new global::System.Drawing.Size(15, 15);
		this.vmethod_34().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_34().TabIndex = 119;
		this.vmethod_34().TabStop = false;
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = global::System.Drawing.SystemColors.AppWorkspace;
		base.ClientSize = new global::System.Drawing.Size(478, 134);
		base.Controls.Add(this.vmethod_34());
		base.Controls.Add(this.vmethod_30());
		base.Controls.Add(this.vmethod_28());
		base.Controls.Add(this.vmethod_26());
		base.Controls.Add(this.vmethod_24());
		base.Controls.Add(this.vmethod_22());
		base.Controls.Add(this.vmethod_16());
		base.Controls.Add(this.vmethod_18());
		base.Controls.Add(this.vmethod_14());
		base.Controls.Add(this.vmethod_8());
		base.Controls.Add(this.vmethod_10());
		base.Controls.Add(this.vmethod_12());
		base.Controls.Add(this.vmethod_4());
		base.Controls.Add(this.vmethod_0());
		this.DoubleBuffered = true;
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedToolWindow;
		base.IsMdiContainer = true;
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "fTorConfig";
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterParent;
		this.Text = "Tor - Hidden service configuration";
		base.TopMost = true;
		this.vmethod_4().ResumeLayout(false);
		this.vmethod_4().PerformLayout();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_26()).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_16()).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_8()).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_28()).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_34()).EndInit();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x040006F1 RID: 1777
	private global::System.ComponentModel.IContainer icontainer_0;
}
