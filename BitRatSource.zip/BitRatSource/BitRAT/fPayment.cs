﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using VisualPlus.Toolkit.Controls.Interactivity;
using Zeroit.Framework.Progress;

// Token: 0x02000182 RID: 386
[DesignerGenerated]
public sealed partial class fPayment : Form
{
	// Token: 0x06001584 RID: 5508 RVA: 0x0000B186 File Offset: 0x00009386
	public fPayment()
	{
		base.Load += this.fPayment_Load;
		base.Closing += this.fPayment_Closing;
		this.InitializeComponent();
	}

	// Token: 0x06001587 RID: 5511 RVA: 0x0000B1B8 File Offset: 0x000093B8
	internal PictureBox vmethod_0()
	{
		return this.pictureBox_0;
	}

	// Token: 0x06001588 RID: 5512 RVA: 0x0000B1C0 File Offset: 0x000093C0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_1(PictureBox pictureBox_10)
	{
		this.pictureBox_0 = pictureBox_10;
	}

	// Token: 0x06001589 RID: 5513 RVA: 0x0000B1C9 File Offset: 0x000093C9
	internal StatusStrip vmethod_2()
	{
		return this.statusStrip_0;
	}

	// Token: 0x0600158A RID: 5514 RVA: 0x0000B1D1 File Offset: 0x000093D1
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_3(StatusStrip statusStrip_1)
	{
		this.statusStrip_0 = statusStrip_1;
	}

	// Token: 0x0600158B RID: 5515 RVA: 0x0000B1DA File Offset: 0x000093DA
	internal ToolStripStatusLabel vmethod_4()
	{
		return this.toolStripStatusLabel_0;
	}

	// Token: 0x0600158C RID: 5516 RVA: 0x0000B1E2 File Offset: 0x000093E2
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_5(ToolStripStatusLabel toolStripStatusLabel_1)
	{
		this.toolStripStatusLabel_0 = toolStripStatusLabel_1;
	}

	// Token: 0x0600158D RID: 5517 RVA: 0x0000B1EB File Offset: 0x000093EB
	internal BackgroundWorker vmethod_6()
	{
		return this.backgroundWorker_0;
	}

	// Token: 0x0600158E RID: 5518 RVA: 0x000A76F4 File Offset: 0x000A58F4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_7(BackgroundWorker backgroundWorker_3)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_14);
		BackgroundWorker backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_0 = backgroundWorker_3;
		backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x0600158F RID: 5519 RVA: 0x0000B1F3 File Offset: 0x000093F3
	internal ZeroitProgressIndicator vmethod_8()
	{
		return this.zeroitProgressIndicator_0;
	}

	// Token: 0x06001590 RID: 5520 RVA: 0x0000B1FB File Offset: 0x000093FB
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_9(ZeroitProgressIndicator zeroitProgressIndicator_1)
	{
		this.zeroitProgressIndicator_0 = zeroitProgressIndicator_1;
	}

	// Token: 0x06001591 RID: 5521 RVA: 0x0000B204 File Offset: 0x00009404
	internal PictureBox vmethod_10()
	{
		return this.pictureBox_1;
	}

	// Token: 0x06001592 RID: 5522 RVA: 0x000A7738 File Offset: 0x000A5938
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_11(PictureBox pictureBox_10)
	{
		EventHandler value = new EventHandler(this.method_15);
		PictureBox pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_1 = pictureBox_10;
		pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06001593 RID: 5523 RVA: 0x0000B20C File Offset: 0x0000940C
	internal Label vmethod_12()
	{
		return this.label_0;
	}

	// Token: 0x06001594 RID: 5524 RVA: 0x0000B214 File Offset: 0x00009414
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_13(Label label_17)
	{
		this.label_0 = label_17;
	}

	// Token: 0x06001595 RID: 5525 RVA: 0x0000B21D File Offset: 0x0000941D
	internal PictureBox vmethod_14()
	{
		return this.pictureBox_2;
	}

	// Token: 0x06001596 RID: 5526 RVA: 0x000A777C File Offset: 0x000A597C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_15(PictureBox pictureBox_10)
	{
		EventHandler value = new EventHandler(this.method_7);
		PictureBox pictureBox = this.pictureBox_2;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_2 = pictureBox_10;
		pictureBox = this.pictureBox_2;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06001597 RID: 5527 RVA: 0x0000B225 File Offset: 0x00009425
	internal Label vmethod_16()
	{
		return this.label_1;
	}

	// Token: 0x06001598 RID: 5528 RVA: 0x000A77C0 File Offset: 0x000A59C0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_17(Label label_17)
	{
		EventHandler value = new EventHandler(this.method_8);
		Label label = this.label_1;
		if (label != null)
		{
			label.Click -= value;
		}
		this.label_1 = label_17;
		label = this.label_1;
		if (label != null)
		{
			label.Click += value;
		}
	}

	// Token: 0x06001599 RID: 5529 RVA: 0x0000B22D File Offset: 0x0000942D
	internal Label vmethod_18()
	{
		return this.label_2;
	}

	// Token: 0x0600159A RID: 5530 RVA: 0x0000B235 File Offset: 0x00009435
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_19(Label label_17)
	{
		this.label_2 = label_17;
	}

	// Token: 0x0600159B RID: 5531 RVA: 0x0000B23E File Offset: 0x0000943E
	internal Label vmethod_20()
	{
		return this.label_3;
	}

	// Token: 0x0600159C RID: 5532 RVA: 0x0000B246 File Offset: 0x00009446
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_21(Label label_17)
	{
		this.label_3 = label_17;
	}

	// Token: 0x0600159D RID: 5533 RVA: 0x0000B24F File Offset: 0x0000944F
	internal Label vmethod_22()
	{
		return this.label_4;
	}

	// Token: 0x0600159E RID: 5534 RVA: 0x0000B257 File Offset: 0x00009457
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_23(Label label_17)
	{
		this.label_4 = label_17;
	}

	// Token: 0x0600159F RID: 5535 RVA: 0x0000B260 File Offset: 0x00009460
	internal Label vmethod_24()
	{
		return this.label_5;
	}

	// Token: 0x060015A0 RID: 5536 RVA: 0x0000B268 File Offset: 0x00009468
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_25(Label label_17)
	{
		this.label_5 = label_17;
	}

	// Token: 0x060015A1 RID: 5537 RVA: 0x0000B271 File Offset: 0x00009471
	internal Label vmethod_26()
	{
		return this.label_6;
	}

	// Token: 0x060015A2 RID: 5538 RVA: 0x000A7804 File Offset: 0x000A5A04
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_27(Label label_17)
	{
		EventHandler value = new EventHandler(this.method_16);
		Label label = this.label_6;
		if (label != null)
		{
			label.Click -= value;
		}
		this.label_6 = label_17;
		label = this.label_6;
		if (label != null)
		{
			label.Click += value;
		}
	}

	// Token: 0x060015A3 RID: 5539 RVA: 0x0000B279 File Offset: 0x00009479
	internal Label vmethod_28()
	{
		return this.label_7;
	}

	// Token: 0x060015A4 RID: 5540 RVA: 0x000A7848 File Offset: 0x000A5A48
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_29(Label label_17)
	{
		EventHandler value = new EventHandler(this.method_10);
		Label label = this.label_7;
		if (label != null)
		{
			label.Click -= value;
		}
		this.label_7 = label_17;
		label = this.label_7;
		if (label != null)
		{
			label.Click += value;
		}
	}

	// Token: 0x060015A5 RID: 5541 RVA: 0x0000B281 File Offset: 0x00009481
	internal Label vmethod_30()
	{
		return this.label_8;
	}

	// Token: 0x060015A6 RID: 5542 RVA: 0x0000B289 File Offset: 0x00009489
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_31(Label label_17)
	{
		this.label_8 = label_17;
	}

	// Token: 0x060015A7 RID: 5543 RVA: 0x0000B292 File Offset: 0x00009492
	internal PictureBox vmethod_32()
	{
		return this.pictureBox_3;
	}

	// Token: 0x060015A8 RID: 5544 RVA: 0x000A788C File Offset: 0x000A5A8C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_33(PictureBox pictureBox_10)
	{
		EventHandler value = new EventHandler(this.method_9);
		PictureBox pictureBox = this.pictureBox_3;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_3 = pictureBox_10;
		pictureBox = this.pictureBox_3;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x060015A9 RID: 5545 RVA: 0x0000B29A File Offset: 0x0000949A
	internal Label vmethod_34()
	{
		return this.label_9;
	}

	// Token: 0x060015AA RID: 5546 RVA: 0x0000B2A2 File Offset: 0x000094A2
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_35(Label label_17)
	{
		this.label_9 = label_17;
	}

	// Token: 0x060015AB RID: 5547 RVA: 0x0000B2AB File Offset: 0x000094AB
	internal Timer vmethod_36()
	{
		return this.timer_0;
	}

	// Token: 0x060015AC RID: 5548 RVA: 0x000A78D0 File Offset: 0x000A5AD0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_37(Timer timer_1)
	{
		EventHandler value = new EventHandler(this.method_11);
		Timer timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_0 = timer_1;
		timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x060015AD RID: 5549 RVA: 0x0000B2B3 File Offset: 0x000094B3
	internal Label vmethod_38()
	{
		return this.label_10;
	}

	// Token: 0x060015AE RID: 5550 RVA: 0x0000B2BB File Offset: 0x000094BB
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_39(Label label_17)
	{
		this.label_10 = label_17;
	}

	// Token: 0x060015AF RID: 5551 RVA: 0x0000B2C4 File Offset: 0x000094C4
	internal BackgroundWorker vmethod_40()
	{
		return this.backgroundWorker_1;
	}

	// Token: 0x060015B0 RID: 5552 RVA: 0x000A7914 File Offset: 0x000A5B14
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_41(BackgroundWorker backgroundWorker_3)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_12);
		BackgroundWorker backgroundWorker = this.backgroundWorker_1;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_1 = backgroundWorker_3;
		backgroundWorker = this.backgroundWorker_1;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x060015B1 RID: 5553 RVA: 0x0000B2CC File Offset: 0x000094CC
	internal PictureBox vmethod_42()
	{
		return this.pictureBox_4;
	}

	// Token: 0x060015B2 RID: 5554 RVA: 0x0000B2D4 File Offset: 0x000094D4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_43(PictureBox pictureBox_10)
	{
		this.pictureBox_4 = pictureBox_10;
	}

	// Token: 0x060015B3 RID: 5555 RVA: 0x0000B2DD File Offset: 0x000094DD
	internal PictureBox vmethod_44()
	{
		return this.pictureBox_5;
	}

	// Token: 0x060015B4 RID: 5556 RVA: 0x0000B2E5 File Offset: 0x000094E5
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_45(PictureBox pictureBox_10)
	{
		this.pictureBox_5 = pictureBox_10;
	}

	// Token: 0x060015B5 RID: 5557 RVA: 0x0000B2EE File Offset: 0x000094EE
	internal Label vmethod_46()
	{
		return this.label_11;
	}

	// Token: 0x060015B6 RID: 5558 RVA: 0x0000B2F6 File Offset: 0x000094F6
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_47(Label label_17)
	{
		this.label_11 = label_17;
	}

	// Token: 0x060015B7 RID: 5559 RVA: 0x0000B2FF File Offset: 0x000094FF
	internal BackgroundWorker vmethod_48()
	{
		return this.backgroundWorker_2;
	}

	// Token: 0x060015B8 RID: 5560 RVA: 0x000A7958 File Offset: 0x000A5B58
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_49(BackgroundWorker backgroundWorker_3)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_18);
		BackgroundWorker backgroundWorker = this.backgroundWorker_2;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_2 = backgroundWorker_3;
		backgroundWorker = this.backgroundWorker_2;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x060015B9 RID: 5561 RVA: 0x0000B307 File Offset: 0x00009507
	internal Label vmethod_50()
	{
		return this.label_12;
	}

	// Token: 0x060015BA RID: 5562 RVA: 0x0000B30F File Offset: 0x0000950F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_51(Label label_17)
	{
		this.label_12 = label_17;
	}

	// Token: 0x060015BB RID: 5563 RVA: 0x0000B318 File Offset: 0x00009518
	internal Label vmethod_52()
	{
		return this.label_13;
	}

	// Token: 0x060015BC RID: 5564 RVA: 0x0000B320 File Offset: 0x00009520
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_53(Label label_17)
	{
		this.label_13 = label_17;
	}

	// Token: 0x060015BD RID: 5565 RVA: 0x0000B329 File Offset: 0x00009529
	internal Label vmethod_54()
	{
		return this.label_14;
	}

	// Token: 0x060015BE RID: 5566 RVA: 0x000A799C File Offset: 0x000A5B9C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_55(Label label_17)
	{
		EventHandler value = new EventHandler(this.method_20);
		Label label = this.label_14;
		if (label != null)
		{
			label.Click -= value;
		}
		this.label_14 = label_17;
		label = this.label_14;
		if (label != null)
		{
			label.Click += value;
		}
	}

	// Token: 0x060015BF RID: 5567 RVA: 0x0000B331 File Offset: 0x00009531
	internal Label vmethod_56()
	{
		return this.label_15;
	}

	// Token: 0x060015C0 RID: 5568 RVA: 0x0000B339 File Offset: 0x00009539
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_57(Label label_17)
	{
		this.label_15 = label_17;
	}

	// Token: 0x060015C1 RID: 5569 RVA: 0x0000B342 File Offset: 0x00009542
	internal PictureBox vmethod_58()
	{
		return this.pictureBox_6;
	}

	// Token: 0x060015C2 RID: 5570 RVA: 0x000A79E0 File Offset: 0x000A5BE0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_59(PictureBox pictureBox_10)
	{
		EventHandler value = new EventHandler(this.method_21);
		PictureBox pictureBox = this.pictureBox_6;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_6 = pictureBox_10;
		pictureBox = this.pictureBox_6;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x060015C3 RID: 5571 RVA: 0x0000B34A File Offset: 0x0000954A
	internal PictureBox vmethod_60()
	{
		return this.pictureBox_7;
	}

	// Token: 0x060015C4 RID: 5572 RVA: 0x000A7A24 File Offset: 0x000A5C24
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_61(PictureBox pictureBox_10)
	{
		EventHandler value = new EventHandler(this.method_24);
		PictureBox pictureBox = this.pictureBox_7;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_7 = pictureBox_10;
		pictureBox = this.pictureBox_7;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x060015C5 RID: 5573 RVA: 0x0000B352 File Offset: 0x00009552
	internal PictureBox vmethod_62()
	{
		return this.pictureBox_8;
	}

	// Token: 0x060015C6 RID: 5574 RVA: 0x000A7A68 File Offset: 0x000A5C68
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_63(PictureBox pictureBox_10)
	{
		EventHandler value = new EventHandler(this.method_22);
		PictureBox pictureBox = this.pictureBox_8;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_8 = pictureBox_10;
		pictureBox = this.pictureBox_8;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x060015C7 RID: 5575 RVA: 0x0000B35A File Offset: 0x0000955A
	internal VisualButton vmethod_64()
	{
		return this.visualButton_0;
	}

	// Token: 0x060015C8 RID: 5576 RVA: 0x000A7AAC File Offset: 0x000A5CAC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_65(VisualButton visualButton_1)
	{
		EventHandler value = new EventHandler(this.method_23);
		VisualButton visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_0 = visualButton_1;
		visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x060015C9 RID: 5577 RVA: 0x0000B362 File Offset: 0x00009562
	internal Label vmethod_66()
	{
		return this.label_16;
	}

	// Token: 0x060015CA RID: 5578 RVA: 0x0000B36A File Offset: 0x0000956A
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_67(Label label_17)
	{
		this.label_16 = label_17;
	}

	// Token: 0x060015CB RID: 5579 RVA: 0x0000B373 File Offset: 0x00009573
	internal PictureBox vmethod_68()
	{
		return this.pictureBox_9;
	}

	// Token: 0x060015CC RID: 5580 RVA: 0x000A7AF0 File Offset: 0x000A5CF0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_69(PictureBox pictureBox_10)
	{
		EventHandler value = new EventHandler(this.method_13);
		PictureBox pictureBox = this.pictureBox_9;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_9 = pictureBox_10;
		pictureBox = this.pictureBox_9;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x060015CD RID: 5581 RVA: 0x000A7B34 File Offset: 0x000A5D34
	private void fPayment_Load(object sender, EventArgs e)
	{
		object[] object_ = new object[]
		{
			this,
			sender,
			e
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O<\\*?7ir", object_);
	}

	// Token: 0x060015CE RID: 5582 RVA: 0x000A7B6C File Offset: 0x000A5D6C
	private void method_0(ref string string_5, ref string string_6, ref string string_7)
	{
		object[] array = new object[]
		{
			this,
			string_5,
			string_6,
			string_7
		};
		Class4 @class = Class149.smethod_0();
		Stream stream_ = Class149.smethod_1();
		try
		{
			@class.method_139(stream_, ")&O<W*?:Ce", array);
		}
		finally
		{
			string_5 = (string)array[1];
			string_6 = (string)array[2];
			string_7 = (string)array[3];
		}
	}

	// Token: 0x060015CF RID: 5583 RVA: 0x000A7C04 File Offset: 0x000A5E04
	private void method_1()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O5'*?7Tk", object_);
	}

	// Token: 0x060015D0 RID: 5584 RVA: 0x000A7C34 File Offset: 0x000A5E34
	private void method_2(string string_5, string string_6)
	{
		object[] object_ = new object[]
		{
			this,
			string_5,
			string_6
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O;p*?9SN", object_);
	}

	// Token: 0x060015D1 RID: 5585 RVA: 0x000A7C6C File Offset: 0x000A5E6C
	public bool method_3()
	{
		object[] object_ = new object[]
		{
			this
		};
		return (bool)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O<+*?;1&", object_);
	}

	// Token: 0x060015D2 RID: 5586 RVA: 0x000A7CA4 File Offset: 0x000A5EA4
	public void method_4()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O79*?9ML", object_);
	}

	// Token: 0x060015D3 RID: 5587 RVA: 0x000A7CD4 File Offset: 0x000A5ED4
	public void method_5()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O7a*?8W3", object_);
	}

	// Token: 0x060015D4 RID: 5588 RVA: 0x000A7D04 File Offset: 0x000A5F04
	public void method_6()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O=C*?6CI", object_);
	}

	// Token: 0x060015D5 RID: 5589 RVA: 0x0000B37B File Offset: 0x0000957B
	private void method_7(object sender, EventArgs e)
	{
		Clipboard.Clear();
		Clipboard.SetText(this.vmethod_16().Text);
		Interaction.MsgBox("HWID copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x060015D6 RID: 5590 RVA: 0x0000B37B File Offset: 0x0000957B
	private void method_8(object sender, EventArgs e)
	{
		Clipboard.Clear();
		Clipboard.SetText(this.vmethod_16().Text);
		Interaction.MsgBox("HWID copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x060015D7 RID: 5591 RVA: 0x0000B3A4 File Offset: 0x000095A4
	private void method_9(object sender, EventArgs e)
	{
		Clipboard.Clear();
		Clipboard.SetText(this.vmethod_28().Text);
		Interaction.MsgBox("Address copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x060015D8 RID: 5592 RVA: 0x0000B3A4 File Offset: 0x000095A4
	private void method_10(object sender, EventArgs e)
	{
		Clipboard.Clear();
		Clipboard.SetText(this.vmethod_28().Text);
		Interaction.MsgBox("Address copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x060015D9 RID: 5593 RVA: 0x000A7D34 File Offset: 0x000A5F34
	private void method_11(object sender, EventArgs e)
	{
		object[] object_ = new object[]
		{
			this,
			sender,
			e
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O=a*?7?d", object_);
	}

	// Token: 0x060015DA RID: 5594 RVA: 0x000A7D6C File Offset: 0x000A5F6C
	private void method_12(object sender, DoWorkEventArgs e)
	{
		object[] object_ = new object[]
		{
			this,
			sender,
			e
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O<\\*?<rX", object_);
	}

	// Token: 0x060015DB RID: 5595 RVA: 0x000A7DA4 File Offset: 0x000A5FA4
	private void method_13(object sender, EventArgs e)
	{
		Interaction.MsgBox(string.Concat(new string[]
		{
			"If you've already paid and still seeing this payment form, please close it and wait some minutes before starting ",
			Application.ProductName,
			" again.\r\n\r\nMost likely, your payment is still waiting for a confirmation and your license will automatically be activated once confirmed.\r\n\r\nNOTE: ",
			Application.ProductName,
			" uses private nodes in the blockchain to check for confimrations, not public services like blockchain.com.\r\nThis means a confirmation may sometimes take a little longer or sometimes even faster. Do not panic, but allow some more minutes.\r\n\r\nIf you have used BitRAT on this system before or already own a license and seeing this payment window, you may need to update your HWID by clicking the \"Update HWID\" button.\r\n\r\nThank you for your patience and understanding!"
		}), MsgBoxStyle.Question, Application.ProductName);
	}

	// Token: 0x060015DC RID: 5596 RVA: 0x000A7DF4 File Offset: 0x000A5FF4
	private void method_14(object sender, DoWorkEventArgs e)
	{
		object[] object_ = new object[]
		{
			this,
			sender,
			e
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O;?*?<QM", object_);
	}

	// Token: 0x060015DD RID: 5597 RVA: 0x0000B3CD File Offset: 0x000095CD
	private void method_15(object sender, EventArgs e)
	{
		Interaction.MsgBox("Save your HWID safely and don't lose it!\r\nYour HWID is needed i.e. if you ever need to move BitRAT to another PC or reinstall your Windows.\r\nThere is no way to recover or validate license without it.", MsgBoxStyle.Exclamation, Application.ProductName);
	}

	// Token: 0x060015DE RID: 5598 RVA: 0x0000B3E1 File Offset: 0x000095E1
	private void method_16(object sender, EventArgs e)
	{
		Clipboard.Clear();
		Clipboard.SetText(this.vmethod_26().Text);
		Interaction.MsgBox("Amount copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x060015DF RID: 5599 RVA: 0x000A7E2C File Offset: 0x000A602C
	public void method_17(int int_1)
	{
		if (base.InvokeRequired)
		{
			base.Invoke(new fPayment.Delegate156(this.method_17), new object[]
			{
				int_1
			});
			return;
		}
		base.Opacity = Conversion.Val((double)this.int_0 / 100.0);
	}

	// Token: 0x060015E0 RID: 5600 RVA: 0x000A7E88 File Offset: 0x000A6088
	private void method_18(object sender, DoWorkEventArgs e)
	{
		object[] object_ = new object[]
		{
			this,
			sender,
			e
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O<h*?=bo", object_);
	}

	// Token: 0x060015E1 RID: 5601 RVA: 0x000A7EC0 File Offset: 0x000A60C0
	public void method_19(string string_5)
	{
		object[] object_ = new object[]
		{
			this,
			string_5
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O<d*?=8a", object_);
	}

	// Token: 0x060015E2 RID: 5602 RVA: 0x0000B40A File Offset: 0x0000960A
	private void method_20(object sender, EventArgs e)
	{
		Clipboard.Clear();
		Clipboard.SetText(Conversions.ToString(this.vmethod_54().Tag));
		Interaction.MsgBox("Remaining amount copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x060015E3 RID: 5603 RVA: 0x0000B40A File Offset: 0x0000960A
	private void method_21(object sender, EventArgs e)
	{
		Clipboard.Clear();
		Clipboard.SetText(Conversions.ToString(this.vmethod_54().Tag));
		Interaction.MsgBox("Remaining amount copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x060015E4 RID: 5604 RVA: 0x0000B438 File Offset: 0x00009638
	private void method_22(object sender, EventArgs e)
	{
		Interaction.MsgBox("If you've already paid and have a license, then you may simply update your HWID and restart BitRAT.\r\n\r\nThe reason you are seeing is this window is probably due to a HWID change.\r\nThis can also happen if you've just updated " + Application.ProductName + " and a change in the HWID alrgorithm was made in the updated version.", MsgBoxStyle.Question, Application.ProductName);
	}

	// Token: 0x060015E5 RID: 5605 RVA: 0x000A7EF4 File Offset: 0x000A60F4
	private void method_23(object sender, EventArgs e)
	{
		base.TopMost = false;
		Class130.fHWIDUpdate_0.Visible = true;
		Form fHWIDUpdate_ = Class130.fHWIDUpdate_0;
		bool flag = false;
		Form form = fHWIDUpdate_;
		Rectangle rectangle;
		if (this != null)
		{
			rectangle = this.RectangleToScreen(this.ClientRectangle);
		}
		else
		{
			rectangle = Screen.FromPoint(form.Location).WorkingArea;
		}
		checked
		{
			int x = rectangle.Left + (rectangle.Width - form.Width) / 2;
			int y = rectangle.Top + (rectangle.Height - form.Height) / 2;
			form.Location = new Point(x, y);
			if (flag)
			{
				form.Visible = true;
			}
			Class130.fHWIDUpdate_0.Opacity = 100.0;
			Class130.fHWIDUpdate_0.Activate();
		}
	}

	// Token: 0x060015E6 RID: 5606 RVA: 0x0000B3E1 File Offset: 0x000095E1
	private void method_24(object sender, EventArgs e)
	{
		Clipboard.Clear();
		Clipboard.SetText(this.vmethod_26().Text);
		Interaction.MsgBox("Amount copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x060015E7 RID: 5607 RVA: 0x000A7FAC File Offset: 0x000A61AC
	public void method_25(string string_5, bool bool_1, string string_6, decimal decimal_0)
	{
		object[] object_ = new object[]
		{
			this,
			string_5,
			bool_1,
			string_6,
			decimal_0
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O:c*?5V3", object_);
	}

	// Token: 0x060015E8 RID: 5608 RVA: 0x0000B3CD File Offset: 0x000095CD
	private void method_26(object sender, EventArgs e)
	{
		Interaction.MsgBox("Save your HWID safely and don't lose it!\r\nYour HWID is needed i.e. if you ever need to move BitRAT to another PC or reinstall your Windows.\r\nThere is no way to recover or validate license without it.", MsgBoxStyle.Exclamation, Application.ProductName);
	}

	// Token: 0x060015E9 RID: 5609 RVA: 0x000A7FF4 File Offset: 0x000A61F4
	private void fPayment_Closing(object sender, CancelEventArgs e)
	{
		object[] object_ = new object[]
		{
			this,
			sender,
			e
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O7q*?7!Z", object_);
	}

	// Token: 0x04000826 RID: 2086
	private PictureBox pictureBox_0;

	// Token: 0x04000827 RID: 2087
	private StatusStrip statusStrip_0;

	// Token: 0x04000828 RID: 2088
	private ToolStripStatusLabel toolStripStatusLabel_0;

	// Token: 0x04000829 RID: 2089
	private BackgroundWorker backgroundWorker_0;

	// Token: 0x0400082A RID: 2090
	private ZeroitProgressIndicator zeroitProgressIndicator_0;

	// Token: 0x0400082B RID: 2091
	private PictureBox pictureBox_1;

	// Token: 0x0400082C RID: 2092
	private Label label_0;

	// Token: 0x0400082D RID: 2093
	private PictureBox pictureBox_2;

	// Token: 0x0400082E RID: 2094
	private Label label_1;

	// Token: 0x0400082F RID: 2095
	private Label label_2;

	// Token: 0x04000830 RID: 2096
	private Label label_3;

	// Token: 0x04000831 RID: 2097
	private Label label_4;

	// Token: 0x04000832 RID: 2098
	private Label label_5;

	// Token: 0x04000833 RID: 2099
	private Label label_6;

	// Token: 0x04000834 RID: 2100
	private Label label_7;

	// Token: 0x04000835 RID: 2101
	private Label label_8;

	// Token: 0x04000836 RID: 2102
	private PictureBox pictureBox_3;

	// Token: 0x04000837 RID: 2103
	private Label label_9;

	// Token: 0x04000838 RID: 2104
	private Timer timer_0;

	// Token: 0x04000839 RID: 2105
	private Label label_10;

	// Token: 0x0400083A RID: 2106
	private BackgroundWorker backgroundWorker_1;

	// Token: 0x0400083B RID: 2107
	private PictureBox pictureBox_4;

	// Token: 0x0400083C RID: 2108
	private PictureBox pictureBox_5;

	// Token: 0x0400083D RID: 2109
	private Label label_11;

	// Token: 0x0400083E RID: 2110
	private BackgroundWorker backgroundWorker_2;

	// Token: 0x0400083F RID: 2111
	private Label label_12;

	// Token: 0x04000840 RID: 2112
	private Label label_13;

	// Token: 0x04000841 RID: 2113
	private Label label_14;

	// Token: 0x04000842 RID: 2114
	private Label label_15;

	// Token: 0x04000843 RID: 2115
	private PictureBox pictureBox_6;

	// Token: 0x04000844 RID: 2116
	private PictureBox pictureBox_7;

	// Token: 0x04000845 RID: 2117
	private PictureBox pictureBox_8;

	// Token: 0x04000846 RID: 2118
	private VisualButton visualButton_0;

	// Token: 0x04000847 RID: 2119
	private Label label_16;

	// Token: 0x04000848 RID: 2120
	private PictureBox pictureBox_9;

	// Token: 0x04000849 RID: 2121
	private Struct18 struct18_0;

	// Token: 0x0400084A RID: 2122
	private Struct18 struct18_1;

	// Token: 0x0400084B RID: 2123
	private Struct16 struct16_0;

	// Token: 0x0400084C RID: 2124
	private string string_0;

	// Token: 0x0400084D RID: 2125
	private string string_1;

	// Token: 0x0400084E RID: 2126
	private string string_2;

	// Token: 0x0400084F RID: 2127
	private string string_3;

	// Token: 0x04000850 RID: 2128
	private string string_4;

	// Token: 0x04000851 RID: 2129
	private bool bool_0;

	// Token: 0x04000852 RID: 2130
	private TimeSpan timeSpan_0;

	// Token: 0x04000853 RID: 2131
	private Stopwatch stopwatch_0;

	// Token: 0x04000854 RID: 2132
	private int int_0;

	// Token: 0x02000183 RID: 387
	// (Invoke) Token: 0x060015F1 RID: 5617
	private delegate void Delegate150(ref string string_0, ref string string_1, ref string string_2);

	// Token: 0x02000184 RID: 388
	// (Invoke) Token: 0x060015F5 RID: 5621
	private delegate void Delegate151(string string_0);

	// Token: 0x02000185 RID: 389
	// (Invoke) Token: 0x060015F9 RID: 5625
	private delegate void Delegate152();

	// Token: 0x02000186 RID: 390
	// (Invoke) Token: 0x060015FD RID: 5629
	private delegate void Delegate153();

	// Token: 0x02000187 RID: 391
	// (Invoke) Token: 0x06001601 RID: 5633
	private delegate void Delegate154(string string_0, bool bool_0, string string_1, decimal decimal_0);

	// Token: 0x02000188 RID: 392
	// (Invoke) Token: 0x06001605 RID: 5637
	private delegate void Delegate155(string string_0, string string_1);

	// Token: 0x02000189 RID: 393
	// (Invoke) Token: 0x06001609 RID: 5641
	private delegate void Delegate156(int int_0);
}
