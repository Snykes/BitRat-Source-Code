﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Threading;

// Token: 0x0200001C RID: 28
internal sealed class Class16
{
	// Token: 0x060001E0 RID: 480 RVA: 0x0001AA74 File Offset: 0x00018C74
	public Class16()
	{
		this.class33_11 = new Class33(179172984, 10);
		this.class33_197 = new Class33(1455045999, 10);
		this.class33_87 = new Class33(1915621937, 8);
		this.class33_173 = new Class33(2010611318, 10);
		this.class33_145 = new Class33(-1936741949, 10);
		this.class33_93 = new Class33(-381068917, 10);
		this.class33_55 = new Class33(1275084507, 10);
		this.class33_137 = new Class33(-1967122305, 2);
		this.class33_152 = new Class33(648987917, 10);
		this.class33_77 = new Class33(-1021389762, 10);
		this.class33_96 = new Class33(1085451942, 10);
		this.class33_79 = new Class33(1061549002, 10);
		this.class33_73 = new Class33(531914139, 2);
		this.class33_107 = new Class33(-1058882580, 10);
		this.class33_23 = new Class33(1586023215, 10);
		this.class33_183 = new Class33(-2144584300, 10);
		this.class33_50 = new Class33(1466120441, 10);
		this.class33_4 = new Class33(-1430168795, 12);
		this.class33_133 = new Class33(-1811821847, 10);
		this.class33_202 = new Class33(-1342394088, 10);
		this.class33_39 = new Class33(-240847514, 9);
		this.class33_43 = new Class33(3666101, 10);
		this.class33_213 = new Class33(-1398465799, 2);
		this.class33_24 = new Class33(-745642527, 10);
		this.class33_41 = new Class33(2104578519, 2);
		this.class33_186 = new Class33(-1443668454, 10);
		this.class33_182 = new Class33(-1529369506, 10);
		this.class33_134 = new Class33(-1245697240, 10);
		this.class33_66 = new Class33(-711203786, 10);
		this.class33_25 = new Class33(869334544, 10);
		this.class33_44 = new Class33(-957812176, 10);
		this.class33_159 = new Class33(1982859918, 8);
		this.class33_112 = new Class33(425932634, 10);
		this.class33_64 = new Class33(-2094542096, 11);
		this.class33_143 = new Class33(-1185981238, 2);
		this.class33_115 = new Class33(892005923, 2);
		this.class33_162 = new Class33(-1084480005, 10);
		this.class33_85 = new Class33(-1314341727, 2);
		this.class33_40 = new Class33(-1203364073, 10);
		this.class33_76 = new Class33(-1737052225, 10);
		this.class33_192 = new Class33(1104354059, 10);
		this.class33_14 = new Class33(-639857997, 9);
		this.class33_210 = new Class33(-1800455349, 10);
		this.class33_187 = new Class33(9095172, 10);
		this.class33_209 = new Class33(269325038, 10);
		this.class33_113 = new Class33(-1742352633, 10);
		this.class33_52 = new Class33(-1376452137, 9);
		this.class33_89 = new Class33(1219042313, 2);
		this.class33_172 = new Class33(1243999531, 6);
		this.class33_122 = new Class33(-1226593428, 10);
		this.class33_151 = new Class33(334869153, 11);
		this.class33_83 = new Class33(-1355282220, 10);
		this.class33_18 = new Class33(104804749, 10);
		this.class33_16 = new Class33(723432263, 10);
		this.class33_127 = new Class33(-1061766621, 10);
		this.class33_111 = new Class33(-1684870423, 10);
		this.class33_63 = new Class33(482106774, 10);
		this.class33_31 = new Class33(-1421617972, 2);
		this.class33_38 = new Class33(1299580474, 1);
		this.class33_48 = new Class33(640670393, 10);
		this.class33_59 = new Class33(-1781207118, 10);
		this.class33_12 = new Class33(-1583444599, 10);
		this.class33_206 = new Class33(1017484805, 10);
		this.class33_69 = new Class33(-1067599509, 10);
		this.class33_61 = new Class33(-1432653780, 10);
		this.class33_19 = new Class33(1347311160, 10);
		this.class33_71 = new Class33(904471725, 10);
		this.class33_204 = new Class33(819352291, 10);
		this.class33_167 = new Class33(2124540173, 7);
		this.class33_84 = new Class33(1560246763, 10);
		this.class33_46 = new Class33(-583397345, 10);
		this.class33_65 = new Class33(1859934374, 10);
		this.class33_56 = new Class33(680696965, 2);
		this.class33_207 = new Class33(746056427, 10);
		this.class33_105 = new Class33(2055020955, 2);
		this.class33_155 = new Class33(2077706260, 4);
		this.class33_125 = new Class33(-114988973, 9);
		this.class33_154 = new Class33(-1294446564, 10);
		this.class33_157 = new Class33(-439264573, 10);
		this.class33_158 = new Class33(-266252196, 10);
		this.class33_7 = new Class33(17828493, 10);
		this.class33_144 = new Class33(-2102092545, 2);
		this.class33_86 = new Class33(-1302985347, 10);
		this.class33_95 = new Class33(322578931, 10);
		this.class33_29 = new Class33(-328288691, 10);
		this.class33_149 = new Class33(-448174682, 10);
		this.class33_36 = new Class33(457333005, 10);
		this.class33_170 = new Class33(-1600894623, 4);
		this.class33_180 = new Class33(-1853466064, 2);
		this.class33_140 = new Class33(1130085028, 10);
		this.class33_153 = new Class33(-1016861655, 10);
		this.class33_20 = new Class33(596336068, 10);
		this.class33_91 = new Class33(1215913401, 10);
		this.class33_123 = new Class33(-1897509078, 9);
		this.class33_70 = new Class33(1916058918, 2);
		this.class33_57 = new Class33(-539605913, 2);
		this.class33_185 = new Class33(-1206090133, 10);
		this.class33_8 = new Class33(-289882345, 10);
		this.class33_169 = new Class33(-377357638, 10);
		this.class33_2 = new Class33(1216481811, 10);
		this.class33_120 = new Class33(2015766728, 10);
		this.class33_82 = new Class33(894557820, 9);
		this.class33_72 = new Class33(-203280442, 10);
		this.class33_1 = new Class33(366889771, 10);
		this.class33_60 = new Class33(-1027123539, 12);
		this.class33_106 = new Class33(2122564918, 10);
		this.class33_203 = new Class33(1401214668, 5);
		this.class33_58 = new Class33(549946172, 9);
		this.class33_171 = new Class33(-1454472157, 10);
		this.class33_119 = new Class33(548231177, 10);
		this.class33_49 = new Class33(-1648478077, 10);
		this.class33_191 = new Class33(-1550453778, 2);
		this.class33_42 = new Class33(-484977883, 10);
		this.class33_184 = new Class33(1541889395, 10);
		this.class33_178 = new Class33(-2029481984, 10);
		this.class33_188 = new Class33(-54462014, 10);
		this.class33_194 = new Class33(-756584685, 10);
		this.class33_128 = new Class33(-1000513042, 10);
		this.class33_131 = new Class33(-738447984, 10);
		this.class33_27 = new Class33(-154790295, 10);
		this.class33_208 = new Class33(-1621098574, 2);
		this.class33_116 = new Class33(243719793, 8);
		this.class33_174 = new Class33(-1793565308, 10);
		this.class33_148 = new Class33(-1478090996, 10);
		this.class33_189 = new Class33(376999363, 10);
		this.class33_165 = new Class33(603497942, 10);
		this.class33_117 = new Class33(1289000410, 10);
		this.class33_45 = new Class33(-1657963104, 10);
		this.class33_21 = new Class33(259523800, 10);
		this.class33_141 = new Class33(1984572135, 10);
		this.class33_160 = new Class33(-1719858177, 2);
		this.class33_198 = new Class33(-182697603, 4);
		this.class33_136 = new Class33(796175608, 2);
		this.class33_22 = new Class33(2066297896, 10);
		this.class33_130 = new Class33(1426199819, 10);
		this.class33_9 = new Class33(-838977618, 2);
		this.class33_102 = new Class33(-1326824001, 10);
		this.class33_17 = new Class33(567134472, 10);
		this.class33_103 = new Class33(886088427, 10);
		this.class33_196 = new Class33(-2514798, 10);
		this.class33_101 = new Class33(1917693837, 2);
		this.class33_195 = new Class33(95903226, 10);
		this.class33_30 = new Class33(-1371866470, 10);
		this.class33_129 = new Class33(667937633, 10);
		this.class33_132 = new Class33(670813536, 10);
		this.class33_99 = new Class33(-134358794, 10);
		this.class33_166 = new Class33(2094697199, 10);
		this.class33_34 = new Class33(1265388412, 10);
		this.class33_75 = new Class33(-214417301, 10);
		this.class33_142 = new Class33(140009394, 10);
		this.class33_110 = new Class33(-1392103904, 2);
		this.class33_176 = new Class33(2145185159, 10);
		this.class33_138 = new Class33(532229713, 10);
		this.class33_0 = new Class33(598562320, 9);
		this.class33_74 = new Class33(2142496951, 8);
		this.class33_200 = new Class33(-791500484, 10);
		this.class33_179 = new Class33(172216413, 9);
		this.class33_80 = new Class33(1036116514, 10);
		this.class33_118 = new Class33(-1239717344, 10);
		this.class33_15 = new Class33(-2062375476, 4);
		this.class33_26 = new Class33(-1638815350, 2);
		this.class33_139 = new Class33(-984480955, 2);
		this.class33_62 = new Class33(1467445498, 10);
		this.class33_98 = new Class33(837625403, 2);
		this.class33_121 = new Class33(-1767732940, 9);
		this.class33_88 = new Class33(-357261539, 10);
		this.class33_104 = new Class33(-866072610, 10);
		this.class33_94 = new Class33(1391439656, 10);
		this.class33_212 = new Class33(1040641080, 10);
		this.class33_109 = new Class33(745153297, 10);
		this.class33_190 = new Class33(-282098288, 2);
		this.class33_114 = new Class33(-1740866013, 8);
		this.class33_146 = new Class33(-254935461, 10);
		this.class33_68 = new Class33(448286613, 9);
		this.class33_135 = new Class33(1481554677, 10);
		this.class33_67 = new Class33(-1847212807, 10);
		this.class33_90 = new Class33(363081472, 10);
		this.class33_5 = new Class33(1281302798, 2);
		this.class33_163 = new Class33(2054401092, 10);
		this.class33_37 = new Class33(661590549, 10);
		this.class33_193 = new Class33(-1882059562, 10);
		this.class33_6 = new Class33(-1698180648, 10);
		this.class33_108 = new Class33(1322901485, 10);
		this.class33_211 = new Class33(-2018197899, 10);
		this.class33_53 = new Class33(817756103, 10);
		this.class33_47 = new Class33(-1410971792, 9);
		this.class33_33 = new Class33(-1499727640, 8);
		this.class33_54 = new Class33(160880578, 10);
		this.class33_156 = new Class33(595960214, 10);
		this.class33_97 = new Class33(1171676314, 9);
		this.class33_161 = new Class33(-206734566, 10);
		this.class33_168 = new Class33(1106573547, 2);
		this.class33_175 = new Class33(723382497, 10);
		this.class33_201 = new Class33(-1368505744, 9);
		this.class33_28 = new Class33(1708256366, 2);
		this.class33_13 = new Class33(1328309173, 10);
		this.class33_181 = new Class33(-1112785331, 2);
		this.class33_92 = new Class33(1729322799, 10);
		this.class33_124 = new Class33(690123636, 2);
		this.class33_100 = new Class33(2098403994, 10);
		this.class33_177 = new Class33(-1432866349, 10);
		this.class33_81 = new Class33(391754501, 10);
		this.class33_10 = new Class33(-552871191, 10);
		this.class33_205 = new Class33(-1972236479, 10);
		this.class33_199 = new Class33(1155284345, 10);
		this.class33_78 = new Class33(-1216233993, 10);
		this.class33_3 = new Class33(533670555, 4);
		this.class33_150 = new Class33(716984535, 10);
		this.class33_147 = new Class33(-617032759, 10);
		this.class33_126 = new Class33(-1815993426, 4);
		this.class33_164 = new Class33(163447402, 10);
		this.class33_32 = new Class33(-1859728989, 10);
		base..ctor();
	}

	// Token: 0x060001E1 RID: 481 RVA: 0x00003860 File Offset: 0x00001A60
	public IEnumerable<Class33> method_0()
	{
		return new Class16.Class18(-2)
		{
			class16_0 = this
		};
	}

	// Token: 0x060001E2 RID: 482 RVA: 0x00003870 File Offset: 0x00001A70
	public bool method_1()
	{
		return this.bool_0;
	}

	// Token: 0x060001E3 RID: 483 RVA: 0x00003878 File Offset: 0x00001A78
	public void method_2(bool bool_1)
	{
		this.bool_0 = bool_1;
	}

	// Token: 0x060001E4 RID: 484 RVA: 0x0001B954 File Offset: 0x00019B54
	public Class33[] method_3()
	{
		if (this.class33_51 == null)
		{
			lock (this)
			{
				if (this.class33_51 == null)
				{
					List<Class33> list = new List<Class33>(256);
					foreach (Class33 item in this.method_0())
					{
						list.Add(item);
					}
					list.Sort(new Comparison<Class33>(Class16.Class17.class17_0.method_0));
					this.class33_51 = list.ToArray();
				}
			}
		}
		return this.class33_51;
	}

	// Token: 0x04000051 RID: 81
	public readonly Class33 class33_0;

	// Token: 0x04000052 RID: 82
	public readonly Class33 class33_1;

	// Token: 0x04000053 RID: 83
	public readonly Class33 class33_2;

	// Token: 0x04000054 RID: 84
	public readonly Class33 class33_3;

	// Token: 0x04000055 RID: 85
	public readonly Class33 class33_4;

	// Token: 0x04000056 RID: 86
	public readonly Class33 class33_5;

	// Token: 0x04000057 RID: 87
	public readonly Class33 class33_6;

	// Token: 0x04000058 RID: 88
	public readonly Class33 class33_7;

	// Token: 0x04000059 RID: 89
	public readonly Class33 class33_8;

	// Token: 0x0400005A RID: 90
	public readonly Class33 class33_9;

	// Token: 0x0400005B RID: 91
	public readonly Class33 class33_10;

	// Token: 0x0400005C RID: 92
	public readonly Class33 class33_11;

	// Token: 0x0400005D RID: 93
	public readonly Class33 class33_12;

	// Token: 0x0400005E RID: 94
	public readonly Class33 class33_13;

	// Token: 0x0400005F RID: 95
	public readonly Class33 class33_14;

	// Token: 0x04000060 RID: 96
	public readonly Class33 class33_15;

	// Token: 0x04000061 RID: 97
	public readonly Class33 class33_16;

	// Token: 0x04000062 RID: 98
	public readonly Class33 class33_17;

	// Token: 0x04000063 RID: 99
	public readonly Class33 class33_18;

	// Token: 0x04000064 RID: 100
	public readonly Class33 class33_19;

	// Token: 0x04000065 RID: 101
	public readonly Class33 class33_20;

	// Token: 0x04000066 RID: 102
	public readonly Class33 class33_21;

	// Token: 0x04000067 RID: 103
	public readonly Class33 class33_22;

	// Token: 0x04000068 RID: 104
	public readonly Class33 class33_23;

	// Token: 0x04000069 RID: 105
	public readonly Class33 class33_24;

	// Token: 0x0400006A RID: 106
	public readonly Class33 class33_25;

	// Token: 0x0400006B RID: 107
	public readonly Class33 class33_26;

	// Token: 0x0400006C RID: 108
	public readonly Class33 class33_27;

	// Token: 0x0400006D RID: 109
	public readonly Class33 class33_28;

	// Token: 0x0400006E RID: 110
	public readonly Class33 class33_29;

	// Token: 0x0400006F RID: 111
	public readonly Class33 class33_30;

	// Token: 0x04000070 RID: 112
	public readonly Class33 class33_31;

	// Token: 0x04000071 RID: 113
	public readonly Class33 class33_32;

	// Token: 0x04000072 RID: 114
	public readonly Class33 class33_33;

	// Token: 0x04000073 RID: 115
	public readonly Class33 class33_34;

	// Token: 0x04000074 RID: 116
	public readonly Class33 class33_35 = new Class33(1284135881, 2);

	// Token: 0x04000075 RID: 117
	public readonly Class33 class33_36;

	// Token: 0x04000076 RID: 118
	public readonly Class33 class33_37;

	// Token: 0x04000077 RID: 119
	public readonly Class33 class33_38;

	// Token: 0x04000078 RID: 120
	public readonly Class33 class33_39;

	// Token: 0x04000079 RID: 121
	public readonly Class33 class33_40;

	// Token: 0x0400007A RID: 122
	public readonly Class33 class33_41;

	// Token: 0x0400007B RID: 123
	public readonly Class33 class33_42;

	// Token: 0x0400007C RID: 124
	public readonly Class33 class33_43;

	// Token: 0x0400007D RID: 125
	public readonly Class33 class33_44;

	// Token: 0x0400007E RID: 126
	public readonly Class33 class33_45;

	// Token: 0x0400007F RID: 127
	public readonly Class33 class33_46;

	// Token: 0x04000080 RID: 128
	public readonly Class33 class33_47;

	// Token: 0x04000081 RID: 129
	public readonly Class33 class33_48;

	// Token: 0x04000082 RID: 130
	public readonly Class33 class33_49;

	// Token: 0x04000083 RID: 131
	public readonly Class33 class33_50;

	// Token: 0x04000084 RID: 132
	private Class33[] class33_51;

	// Token: 0x04000085 RID: 133
	public readonly Class33 class33_52;

	// Token: 0x04000086 RID: 134
	public readonly Class33 class33_53;

	// Token: 0x04000087 RID: 135
	public readonly Class33 class33_54;

	// Token: 0x04000088 RID: 136
	public readonly Class33 class33_55;

	// Token: 0x04000089 RID: 137
	public readonly Class33 class33_56;

	// Token: 0x0400008A RID: 138
	public readonly Class33 class33_57;

	// Token: 0x0400008B RID: 139
	public readonly Class33 class33_58;

	// Token: 0x0400008C RID: 140
	public readonly Class33 class33_59;

	// Token: 0x0400008D RID: 141
	public readonly Class33 class33_60;

	// Token: 0x0400008E RID: 142
	public readonly Class33 class33_61;

	// Token: 0x0400008F RID: 143
	public readonly Class33 class33_62;

	// Token: 0x04000090 RID: 144
	public readonly Class33 class33_63;

	// Token: 0x04000091 RID: 145
	public readonly Class33 class33_64;

	// Token: 0x04000092 RID: 146
	public readonly Class33 class33_65;

	// Token: 0x04000093 RID: 147
	public readonly Class33 class33_66;

	// Token: 0x04000094 RID: 148
	public readonly Class33 class33_67;

	// Token: 0x04000095 RID: 149
	public readonly Class33 class33_68;

	// Token: 0x04000096 RID: 150
	public readonly Class33 class33_69;

	// Token: 0x04000097 RID: 151
	public readonly Class33 class33_70;

	// Token: 0x04000098 RID: 152
	public readonly Class33 class33_71;

	// Token: 0x04000099 RID: 153
	public readonly Class33 class33_72;

	// Token: 0x0400009A RID: 154
	public readonly Class33 class33_73;

	// Token: 0x0400009B RID: 155
	public readonly Class33 class33_74;

	// Token: 0x0400009C RID: 156
	public readonly Class33 class33_75;

	// Token: 0x0400009D RID: 157
	public readonly Class33 class33_76;

	// Token: 0x0400009E RID: 158
	public readonly Class33 class33_77;

	// Token: 0x0400009F RID: 159
	public readonly Class33 class33_78;

	// Token: 0x040000A0 RID: 160
	public readonly Class33 class33_79;

	// Token: 0x040000A1 RID: 161
	public readonly Class33 class33_80;

	// Token: 0x040000A2 RID: 162
	public readonly Class33 class33_81;

	// Token: 0x040000A3 RID: 163
	public readonly Class33 class33_82;

	// Token: 0x040000A4 RID: 164
	public readonly Class33 class33_83;

	// Token: 0x040000A5 RID: 165
	public readonly Class33 class33_84;

	// Token: 0x040000A6 RID: 166
	public readonly Class33 class33_85;

	// Token: 0x040000A7 RID: 167
	public readonly Class33 class33_86;

	// Token: 0x040000A8 RID: 168
	public readonly Class33 class33_87;

	// Token: 0x040000A9 RID: 169
	public readonly Class33 class33_88;

	// Token: 0x040000AA RID: 170
	public readonly Class33 class33_89;

	// Token: 0x040000AB RID: 171
	public readonly Class33 class33_90;

	// Token: 0x040000AC RID: 172
	public readonly Class33 class33_91;

	// Token: 0x040000AD RID: 173
	public readonly Class33 class33_92;

	// Token: 0x040000AE RID: 174
	public readonly Class33 class33_93;

	// Token: 0x040000AF RID: 175
	public readonly Class33 class33_94;

	// Token: 0x040000B0 RID: 176
	private bool bool_0;

	// Token: 0x040000B1 RID: 177
	public readonly Class33 class33_95;

	// Token: 0x040000B2 RID: 178
	public readonly Class33 class33_96;

	// Token: 0x040000B3 RID: 179
	public readonly Class33 class33_97;

	// Token: 0x040000B4 RID: 180
	public readonly Class33 class33_98;

	// Token: 0x040000B5 RID: 181
	public readonly Class33 class33_99;

	// Token: 0x040000B6 RID: 182
	public readonly Class33 class33_100;

	// Token: 0x040000B7 RID: 183
	public readonly Class33 class33_101;

	// Token: 0x040000B8 RID: 184
	public readonly Class33 class33_102;

	// Token: 0x040000B9 RID: 185
	public readonly Class33 class33_103;

	// Token: 0x040000BA RID: 186
	public readonly Class33 class33_104;

	// Token: 0x040000BB RID: 187
	public readonly Class33 class33_105;

	// Token: 0x040000BC RID: 188
	public readonly Class33 class33_106;

	// Token: 0x040000BD RID: 189
	public readonly Class33 class33_107;

	// Token: 0x040000BE RID: 190
	public readonly Class33 class33_108;

	// Token: 0x040000BF RID: 191
	public readonly Class33 class33_109;

	// Token: 0x040000C0 RID: 192
	public readonly Class33 class33_110;

	// Token: 0x040000C1 RID: 193
	public readonly Class33 class33_111;

	// Token: 0x040000C2 RID: 194
	public readonly Class33 class33_112;

	// Token: 0x040000C3 RID: 195
	public readonly Class33 class33_113;

	// Token: 0x040000C4 RID: 196
	public readonly Class33 class33_114;

	// Token: 0x040000C5 RID: 197
	public readonly Class33 class33_115;

	// Token: 0x040000C6 RID: 198
	public readonly Class33 class33_116;

	// Token: 0x040000C7 RID: 199
	public readonly Class33 class33_117;

	// Token: 0x040000C8 RID: 200
	public readonly Class33 class33_118;

	// Token: 0x040000C9 RID: 201
	public readonly Class33 class33_119;

	// Token: 0x040000CA RID: 202
	public readonly Class33 class33_120;

	// Token: 0x040000CB RID: 203
	public readonly Class33 class33_121;

	// Token: 0x040000CC RID: 204
	public readonly Class33 class33_122;

	// Token: 0x040000CD RID: 205
	public readonly Class33 class33_123;

	// Token: 0x040000CE RID: 206
	public readonly Class33 class33_124;

	// Token: 0x040000CF RID: 207
	public readonly Class33 class33_125;

	// Token: 0x040000D0 RID: 208
	public readonly Class33 class33_126;

	// Token: 0x040000D1 RID: 209
	public readonly Class33 class33_127;

	// Token: 0x040000D2 RID: 210
	public readonly Class33 class33_128;

	// Token: 0x040000D3 RID: 211
	public readonly Class33 class33_129;

	// Token: 0x040000D4 RID: 212
	public readonly Class33 class33_130;

	// Token: 0x040000D5 RID: 213
	public readonly Class33 class33_131;

	// Token: 0x040000D6 RID: 214
	public readonly Class33 class33_132;

	// Token: 0x040000D7 RID: 215
	public readonly Class33 class33_133;

	// Token: 0x040000D8 RID: 216
	public readonly Class33 class33_134;

	// Token: 0x040000D9 RID: 217
	public readonly Class33 class33_135;

	// Token: 0x040000DA RID: 218
	public readonly Class33 class33_136;

	// Token: 0x040000DB RID: 219
	public readonly Class33 class33_137;

	// Token: 0x040000DC RID: 220
	public readonly Class33 class33_138;

	// Token: 0x040000DD RID: 221
	public readonly Class33 class33_139;

	// Token: 0x040000DE RID: 222
	public readonly Class33 class33_140;

	// Token: 0x040000DF RID: 223
	public readonly Class33 class33_141;

	// Token: 0x040000E0 RID: 224
	public readonly Class33 class33_142;

	// Token: 0x040000E1 RID: 225
	public readonly Class33 class33_143;

	// Token: 0x040000E2 RID: 226
	public readonly Class33 class33_144;

	// Token: 0x040000E3 RID: 227
	public readonly Class33 class33_145;

	// Token: 0x040000E4 RID: 228
	public readonly Class33 class33_146;

	// Token: 0x040000E5 RID: 229
	public readonly Class33 class33_147;

	// Token: 0x040000E6 RID: 230
	public readonly Class33 class33_148;

	// Token: 0x040000E7 RID: 231
	public readonly Class33 class33_149;

	// Token: 0x040000E8 RID: 232
	public readonly Class33 class33_150;

	// Token: 0x040000E9 RID: 233
	public readonly Class33 class33_151;

	// Token: 0x040000EA RID: 234
	public readonly Class33 class33_152;

	// Token: 0x040000EB RID: 235
	public readonly Class33 class33_153;

	// Token: 0x040000EC RID: 236
	public readonly Class33 class33_154;

	// Token: 0x040000ED RID: 237
	public readonly Class33 class33_155;

	// Token: 0x040000EE RID: 238
	public readonly Class33 class33_156;

	// Token: 0x040000EF RID: 239
	public readonly Class33 class33_157;

	// Token: 0x040000F0 RID: 240
	public readonly Class33 class33_158;

	// Token: 0x040000F1 RID: 241
	public readonly Class33 class33_159;

	// Token: 0x040000F2 RID: 242
	public readonly Class33 class33_160;

	// Token: 0x040000F3 RID: 243
	public readonly Class33 class33_161;

	// Token: 0x040000F4 RID: 244
	public readonly Class33 class33_162;

	// Token: 0x040000F5 RID: 245
	public readonly Class33 class33_163;

	// Token: 0x040000F6 RID: 246
	public readonly Class33 class33_164;

	// Token: 0x040000F7 RID: 247
	public readonly Class33 class33_165;

	// Token: 0x040000F8 RID: 248
	public readonly Class33 class33_166;

	// Token: 0x040000F9 RID: 249
	public readonly Class33 class33_167;

	// Token: 0x040000FA RID: 250
	public readonly Class33 class33_168;

	// Token: 0x040000FB RID: 251
	public readonly Class33 class33_169;

	// Token: 0x040000FC RID: 252
	public readonly Class33 class33_170;

	// Token: 0x040000FD RID: 253
	public readonly Class33 class33_171;

	// Token: 0x040000FE RID: 254
	public readonly Class33 class33_172;

	// Token: 0x040000FF RID: 255
	public readonly Class33 class33_173;

	// Token: 0x04000100 RID: 256
	public readonly Class33 class33_174;

	// Token: 0x04000101 RID: 257
	public readonly Class33 class33_175;

	// Token: 0x04000102 RID: 258
	public readonly Class33 class33_176;

	// Token: 0x04000103 RID: 259
	public readonly Class33 class33_177;

	// Token: 0x04000104 RID: 260
	public readonly Class33 class33_178;

	// Token: 0x04000105 RID: 261
	public readonly Class33 class33_179;

	// Token: 0x04000106 RID: 262
	public readonly Class33 class33_180;

	// Token: 0x04000107 RID: 263
	public readonly Class33 class33_181;

	// Token: 0x04000108 RID: 264
	public readonly Class33 class33_182;

	// Token: 0x04000109 RID: 265
	public readonly Class33 class33_183;

	// Token: 0x0400010A RID: 266
	public readonly Class33 class33_184;

	// Token: 0x0400010B RID: 267
	public readonly Class33 class33_185;

	// Token: 0x0400010C RID: 268
	public readonly Class33 class33_186;

	// Token: 0x0400010D RID: 269
	public readonly Class33 class33_187;

	// Token: 0x0400010E RID: 270
	public readonly Class33 class33_188;

	// Token: 0x0400010F RID: 271
	public readonly Class33 class33_189;

	// Token: 0x04000110 RID: 272
	public readonly Class33 class33_190;

	// Token: 0x04000111 RID: 273
	public readonly Class33 class33_191;

	// Token: 0x04000112 RID: 274
	public readonly Class33 class33_192;

	// Token: 0x04000113 RID: 275
	public readonly Class33 class33_193;

	// Token: 0x04000114 RID: 276
	public readonly Class33 class33_194;

	// Token: 0x04000115 RID: 277
	public readonly Class33 class33_195;

	// Token: 0x04000116 RID: 278
	public readonly Class33 class33_196;

	// Token: 0x04000117 RID: 279
	public readonly Class33 class33_197;

	// Token: 0x04000118 RID: 280
	public readonly Class33 class33_198;

	// Token: 0x04000119 RID: 281
	public readonly Class33 class33_199;

	// Token: 0x0400011A RID: 282
	public readonly Class33 class33_200;

	// Token: 0x0400011B RID: 283
	public readonly Class33 class33_201;

	// Token: 0x0400011C RID: 284
	public readonly Class33 class33_202;

	// Token: 0x0400011D RID: 285
	public readonly Class33 class33_203;

	// Token: 0x0400011E RID: 286
	public readonly Class33 class33_204;

	// Token: 0x0400011F RID: 287
	public readonly Class33 class33_205;

	// Token: 0x04000120 RID: 288
	public readonly Class33 class33_206;

	// Token: 0x04000121 RID: 289
	public readonly Class33 class33_207;

	// Token: 0x04000122 RID: 290
	public readonly Class33 class33_208;

	// Token: 0x04000123 RID: 291
	public readonly Class33 class33_209;

	// Token: 0x04000124 RID: 292
	public readonly Class33 class33_210;

	// Token: 0x04000125 RID: 293
	public readonly Class33 class33_211;

	// Token: 0x04000126 RID: 294
	public readonly Class33 class33_212;

	// Token: 0x04000127 RID: 295
	public readonly Class33 class33_213;

	// Token: 0x0200001D RID: 29
	[Serializable]
	private sealed class Class17
	{
		// Token: 0x060001E7 RID: 487 RVA: 0x0001BA14 File Offset: 0x00019C14
		internal int method_0(Class33 class33_0, Class33 class33_1)
		{
			return class33_0.method_0().CompareTo(class33_1.method_0());
		}

		// Token: 0x04000128 RID: 296
		public static readonly Class16.Class17 class17_0 = new Class16.Class17();

		// Token: 0x04000129 RID: 297
		public static Comparison<Class33> comparison_0;
	}

	// Token: 0x0200001E RID: 30
	private sealed class Class18 : IEnumerable<Class33>, IEnumerator<Class33>, IEnumerable, IDisposable, IEnumerator
	{
		// Token: 0x060001E8 RID: 488 RVA: 0x0000388D File Offset: 0x00001A8D
		[DebuggerHidden]
		public Class18(int int_3)
		{
			this.int_0 = int_3;
			this.int_1 = Thread.CurrentThread.ManagedThreadId;
		}

		// Token: 0x060001E9 RID: 489 RVA: 0x00002F44 File Offset: 0x00001144
		[DebuggerHidden]
		void IDisposable.Dispose()
		{
		}

		// Token: 0x060001EA RID: 490 RVA: 0x0001BA38 File Offset: 0x00019C38
		bool IEnumerator.MoveNext()
		{
			int num = this.int_0;
			Class16 obj = this.class16_0;
			if (num != 0)
			{
				if (num != 1)
				{
					return false;
				}
				this.int_0 = -1;
				this.int_2++;
			}
			else
			{
				this.int_0 = -1;
				FieldInfo[] fields = typeof(Class16).GetFields(BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Public);
				this.fieldInfo_0 = fields;
				this.int_2 = 0;
			}
			if (this.int_2 >= this.fieldInfo_0.Length)
			{
				this.fieldInfo_0 = null;
				return false;
			}
			Class33 @class = (Class33)this.fieldInfo_0[this.int_2].GetValue(obj);
			this.class33_0 = @class;
			this.int_0 = 1;
			return true;
		}

		// Token: 0x170000AD RID: 173
		// (get) Token: 0x060001EB RID: 491 RVA: 0x000038AC File Offset: 0x00001AAC
		Class33 IEnumerator<Class33>.Current
		{
			[DebuggerHidden]
			get
			{
				return this.class33_0;
			}
		}

		// Token: 0x060001EC RID: 492 RVA: 0x000038B4 File Offset: 0x00001AB4
		[DebuggerHidden]
		void IEnumerator.Reset()
		{
			throw new NotSupportedException();
		}

		// Token: 0x170000AE RID: 174
		// (get) Token: 0x060001ED RID: 493 RVA: 0x000038AC File Offset: 0x00001AAC
		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return this.class33_0;
			}
		}

		// Token: 0x060001EE RID: 494 RVA: 0x0001BAE0 File Offset: 0x00019CE0
		[DebuggerHidden]
		IEnumerator<Class33> IEnumerable<Class33>.GetEnumerator()
		{
			Class16.Class18 @class;
			if (this.int_0 == -2 && this.int_1 == Thread.CurrentThread.ManagedThreadId)
			{
				this.int_0 = 0;
				@class = this;
			}
			else
			{
				@class = new Class16.Class18(0);
				@class.class16_0 = this.class16_0;
			}
			return @class;
		}

		// Token: 0x060001EF RID: 495 RVA: 0x000038BB File Offset: 0x00001ABB
		[DebuggerHidden]
		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.System.Collections.Generic.IEnumerable<Class33>.GetEnumerator();
		}

		// Token: 0x0400012A RID: 298
		private int int_0;

		// Token: 0x0400012B RID: 299
		private Class33 class33_0;

		// Token: 0x0400012C RID: 300
		private int int_1;

		// Token: 0x0400012D RID: 301
		public Class16 class16_0;

		// Token: 0x0400012E RID: 302
		private FieldInfo[] fieldInfo_0;

		// Token: 0x0400012F RID: 303
		private int int_2;
	}
}
