﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

// Token: 0x020000EA RID: 234
[DesignerGenerated]
public sealed partial class fKeylogOnline : Form
{
	// Token: 0x06000B7C RID: 2940 RVA: 0x00007534 File Offset: 0x00005734
	public fKeylogOnline()
	{
		base.Closing += this.fKeylogOnline_Closing;
		this.InitializeComponent();
	}

	// Token: 0x06000B7F RID: 2943 RVA: 0x00007554 File Offset: 0x00005754
	internal RichTextBox vmethod_0()
	{
		return this.richTextBox_0;
	}

	// Token: 0x06000B80 RID: 2944 RVA: 0x0000755C File Offset: 0x0000575C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_1(RichTextBox richTextBox_1)
	{
		this.richTextBox_0 = richTextBox_1;
	}

	// Token: 0x06000B81 RID: 2945 RVA: 0x00007348 File Offset: 0x00005548
	private void fKeylogOnline_Closing(object sender, CancelEventArgs e)
	{
		base.Visible = false;
		e.Cancel = true;
	}

	// Token: 0x04000455 RID: 1109
	private RichTextBox richTextBox_0;
}
