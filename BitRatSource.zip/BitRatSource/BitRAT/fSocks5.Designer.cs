﻿// Token: 0x02000136 RID: 310
[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
public sealed partial class fSocks5 : global::System.Windows.Forms.Form
{
	// Token: 0x0600112F RID: 4399 RVA: 0x0007DF64 File Offset: 0x0007C164
	[global::System.Diagnostics.DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && this.icontainer_0 != null)
			{
				this.icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	// Token: 0x06001130 RID: 4400 RVA: 0x0007DFA4 File Offset: 0x0007C1A4
	[global::System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		this.vmethod_1(new global::System.Windows.Forms.Timer(this.icontainer_0));
		this.vmethod_3(new global::System.Windows.Forms.TextBox());
		this.vmethod_5(new global::System.Windows.Forms.Label());
		this.vmethod_7(new global::System.Windows.Forms.RadioButton());
		this.vmethod_9(new global::System.Windows.Forms.RadioButton());
		this.vmethod_11(new global::System.Windows.Forms.StatusStrip());
		this.vmethod_13(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_15(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_17(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_19(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_21(new global::BrightIdeasSoftware.FastObjectListView());
		this.vmethod_41(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_45(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_47(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_49(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_51(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_53(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_43(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_23(new global::System.Windows.Forms.ContextMenuStrip(this.icontainer_0));
		this.vmethod_25(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_27(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_67(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_69(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_29(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_31(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_59(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_61(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_33(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_35(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_37(new global::System.Windows.Forms.PictureBox());
		this.vmethod_39(new global::System.ComponentModel.BackgroundWorker());
		this.vmethod_55(new global::System.Windows.Forms.PictureBox());
		this.vmethod_57(new global::System.Windows.Forms.CheckBox());
		this.vmethod_63(new global::VisualPlus.Toolkit.Controls.Interactivity.VisualButton());
		this.vmethod_65(new global::VisualPlus.Toolkit.Controls.Interactivity.VisualButton());
		this.vmethod_10().SuspendLayout();
		this.vmethod_20().BeginInit();
		this.vmethod_22().SuspendLayout();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_36()).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_54()).BeginInit();
		base.SuspendLayout();
		this.vmethod_0().Enabled = true;
		this.vmethod_0().Interval = 1000;
		this.vmethod_2().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_2().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_2().ForeColor = global::System.Drawing.SystemColors.WindowText;
		this.vmethod_2().Location = new global::System.Drawing.Point(178, 315);
		this.vmethod_2().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_2().MaxLength = 5;
		this.vmethod_2().Name = "txtPort";
		this.vmethod_2().Size = new global::System.Drawing.Size(57, 20);
		this.vmethod_2().TabIndex = 88;
		this.vmethod_2().Text = "1080";
		this.vmethod_4().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_4().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_4().Location = new global::System.Drawing.Point(142, 318);
		this.vmethod_4().Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
		this.vmethod_4().Name = "lblPort";
		this.vmethod_4().Size = new global::System.Drawing.Size(32, 13);
		this.vmethod_4().TabIndex = 87;
		this.vmethod_4().Text = "Port:";
		this.vmethod_4().TextAlign = global::System.Drawing.ContentAlignment.TopRight;
		this.vmethod_6().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_6().AutoSize = true;
		this.vmethod_6().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_6().Location = new global::System.Drawing.Point(737, 316);
		this.vmethod_6().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_6().Name = "rbSelected";
		this.vmethod_6().Size = new global::System.Drawing.Size(122, 17);
		this.vmethod_6().TabIndex = 86;
		this.vmethod_6().Text = "Only selected clients";
		this.vmethod_6().UseVisualStyleBackColor = false;
		this.vmethod_8().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_8().AutoSize = true;
		this.vmethod_8().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_8().Checked = true;
		this.vmethod_8().Location = new global::System.Drawing.Point(697, 315);
		this.vmethod_8().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_8().Name = "rbAll";
		this.vmethod_8().Size = new global::System.Drawing.Size(36, 17);
		this.vmethod_8().TabIndex = 85;
		this.vmethod_8().TabStop = true;
		this.vmethod_8().Text = "All";
		this.vmethod_8().UseVisualStyleBackColor = false;
		this.vmethod_10().AutoSize = false;
		this.vmethod_10().BackColor = global::System.Drawing.Color.FromArgb(235, 237, 239);
		this.vmethod_10().ImageScalingSize = new global::System.Drawing.Size(28, 28);
		this.vmethod_10().Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_12(),
			this.vmethod_14()
		});
		this.vmethod_10().Location = new global::System.Drawing.Point(0, 342);
		this.vmethod_10().Name = "ssTransferStatus";
		this.vmethod_10().Padding = new global::System.Windows.Forms.Padding(1, 0, 7, 0);
		this.vmethod_10().Size = new global::System.Drawing.Size(885, 19);
		this.vmethod_10().SizingGrip = false;
		this.vmethod_10().Stretch = false;
		this.vmethod_10().TabIndex = 82;
		this.vmethod_10().Text = "stStatus";
		this.vmethod_12().AutoSize = false;
		this.vmethod_12().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_12().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_12().Margin = new global::System.Windows.Forms.Padding(0, 3, 0, 0);
		this.vmethod_12().Name = "tsSocks5Count";
		this.vmethod_12().Size = new global::System.Drawing.Size(140, 16);
		this.vmethod_12().Text = "Socks5 servers: 0";
		this.vmethod_12().TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
		this.vmethod_14().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_14().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_14().Margin = new global::System.Windows.Forms.Padding(0, 3, -4, 0);
		this.vmethod_14().Name = "tsClientsSelected";
		this.vmethod_14().Size = new global::System.Drawing.Size(741, 16);
		this.vmethod_14().Spring = true;
		this.vmethod_14().Text = "Selected clients: 0";
		this.vmethod_14().TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
		this.vmethod_16().AspectName = "IP";
		this.vmethod_16().Hideable = false;
		this.vmethod_16().Text = "IP";
		this.vmethod_18().AspectName = "USER";
		this.vmethod_18().Hideable = false;
		this.vmethod_18().Text = "User";
		this.vmethod_20().Alignment = global::System.Windows.Forms.ListViewAlignment.Left;
		this.vmethod_20().AllColumns.Add(this.vmethod_18());
		this.vmethod_20().AllColumns.Add(this.vmethod_16());
		this.vmethod_20().AllColumns.Add(this.vmethod_40());
		this.vmethod_20().AllColumns.Add(this.vmethod_44());
		this.vmethod_20().AllColumns.Add(this.vmethod_46());
		this.vmethod_20().AllColumns.Add(this.vmethod_48());
		this.vmethod_20().AllColumns.Add(this.vmethod_50());
		this.vmethod_20().AllColumns.Add(this.vmethod_52());
		this.vmethod_20().AllColumns.Add(this.vmethod_42());
		this.vmethod_20().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_20().AutoArrange = false;
		this.vmethod_20().BorderStyle = global::System.Windows.Forms.BorderStyle.None;
		this.vmethod_20().CellEditUseWholeCell = false;
		this.vmethod_20().Columns.AddRange(new global::System.Windows.Forms.ColumnHeader[]
		{
			this.vmethod_18(),
			this.vmethod_16(),
			this.vmethod_40(),
			this.vmethod_44(),
			this.vmethod_46(),
			this.vmethod_48(),
			this.vmethod_50(),
			this.vmethod_52(),
			this.vmethod_42()
		});
		this.vmethod_20().ContextMenuStrip = this.vmethod_22();
		this.vmethod_20().Cursor = global::System.Windows.Forms.Cursors.Default;
		this.vmethod_20().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.142858f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_20().FullRowSelect = true;
		this.vmethod_20().HeaderStyle = global::System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
		this.vmethod_20().HideSelection = false;
		this.vmethod_20().Location = new global::System.Drawing.Point(0, 0);
		this.vmethod_20().Margin = new global::System.Windows.Forms.Padding(1);
		this.vmethod_20().Name = "lvSocks5Servers";
		this.vmethod_20().ShowGroups = false;
		this.vmethod_20().Size = new global::System.Drawing.Size(885, 306);
		this.vmethod_20().TabIndex = 81;
		this.vmethod_20().UseCompatibleStateImageBehavior = false;
		this.vmethod_20().UseHotControls = false;
		this.vmethod_20().UseOverlays = false;
		this.vmethod_20().View = global::System.Windows.Forms.View.Details;
		this.vmethod_20().VirtualMode = true;
		this.vmethod_40().AspectName = "PORT";
		this.vmethod_40().Hideable = false;
		this.vmethod_40().Text = "Port";
		this.vmethod_44().AspectName = "SENT";
		this.vmethod_44().Hideable = false;
		this.vmethod_44().Text = "Sent";
		this.vmethod_46().AspectName = "RECV";
		this.vmethod_46().Hideable = false;
		this.vmethod_46().Text = "Received";
		this.vmethod_48().AspectName = "SPEED_DL";
		this.vmethod_48().Hideable = false;
		this.vmethod_48().Text = "DL";
		this.vmethod_50().AspectName = "SPEED_UL";
		this.vmethod_50().Hideable = false;
		this.vmethod_50().Text = "UL";
		this.vmethod_52().AspectName = "TARGET";
		this.vmethod_52().Hideable = false;
		this.vmethod_52().Text = "Target";
		this.vmethod_42().AspectName = "DURATION";
		this.vmethod_42().Hideable = false;
		this.vmethod_42().Text = "Duration";
		this.vmethod_22().ImageScalingSize = new global::System.Drawing.Size(24, 24);
		this.vmethod_22().Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_24(),
			this.vmethod_28(),
			this.vmethod_30()
		});
		this.vmethod_22().Name = "ContextMenuStrip1";
		this.vmethod_22().Size = new global::System.Drawing.Size(170, 54);
		this.vmethod_24().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_26(),
			this.vmethod_66(),
			this.vmethod_68()
		});
		this.vmethod_24().Name = "OperationsToolStripMenuItem";
		this.vmethod_24().Size = new global::System.Drawing.Size(169, 22);
		this.vmethod_24().Text = "Operations";
		this.vmethod_26().Name = "StopToolStripMenuItem";
		this.vmethod_26().Size = new global::System.Drawing.Size(150, 22);
		this.vmethod_26().Text = "Stop";
		this.vmethod_66().Name = "ToolStripMenuItem3";
		this.vmethod_66().Size = new global::System.Drawing.Size(147, 6);
		this.vmethod_68().Name = "ResetStatisticsToolStripMenuItem";
		this.vmethod_68().Size = new global::System.Drawing.Size(150, 22);
		this.vmethod_68().Text = "Reset statistics";
		this.vmethod_28().Name = "ToolStripMenuItem2";
		this.vmethod_28().Size = new global::System.Drawing.Size(166, 6);
		this.vmethod_30().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_58(),
			this.vmethod_60(),
			this.vmethod_32(),
			this.vmethod_34()
		});
		this.vmethod_30().Name = "CopyToClipboardToolStripMenuItem";
		this.vmethod_30().Size = new global::System.Drawing.Size(169, 22);
		this.vmethod_30().Text = "Copy to clipboard";
		this.vmethod_58().Name = "IPPortToolStripMenuItem";
		this.vmethod_58().Size = new global::System.Drawing.Size(118, 22);
		this.vmethod_58().Text = "IP:Port";
		this.vmethod_60().Name = "ToolStripMenuItem1";
		this.vmethod_60().Size = new global::System.Drawing.Size(115, 6);
		this.vmethod_32().Name = "SelectedToolStripMenuItem";
		this.vmethod_32().Size = new global::System.Drawing.Size(118, 22);
		this.vmethod_32().Text = "Selected";
		this.vmethod_34().Name = "AllToolStripMenuItem";
		this.vmethod_34().Size = new global::System.Drawing.Size(118, 22);
		this.vmethod_34().Text = "All";
		this.vmethod_36().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_36().Image = global::Class131.smethod_24();
		this.vmethod_36().Location = new global::System.Drawing.Point(863, 317);
		this.vmethod_36().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_36().Name = "pbInfo";
		this.vmethod_36().Size = new global::System.Drawing.Size(15, 15);
		this.vmethod_36().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_36().TabIndex = 89;
		this.vmethod_36().TabStop = false;
		this.vmethod_54().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_54().Image = global::Class131.smethod_24();
		this.vmethod_54().Location = new global::System.Drawing.Point(307, 317);
		this.vmethod_54().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_54().Name = "pbInfoRandom";
		this.vmethod_54().Size = new global::System.Drawing.Size(15, 15);
		this.vmethod_54().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_54().TabIndex = 91;
		this.vmethod_54().TabStop = false;
		this.vmethod_56().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_56().AutoSize = true;
		this.vmethod_56().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_56().Location = new global::System.Drawing.Point(238, 317);
		this.vmethod_56().Margin = new global::System.Windows.Forms.Padding(1);
		this.vmethod_56().Name = "chkRandom";
		this.vmethod_56().RightToLeft = global::System.Windows.Forms.RightToLeft.Yes;
		this.vmethod_56().Size = new global::System.Drawing.Size(66, 17);
		this.vmethod_56().TabIndex = 90;
		this.vmethod_56().Text = "Random";
		this.vmethod_56().UseVisualStyleBackColor = false;
		this.vmethod_62().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_62().BackColorState.Disabled = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_62().BackColorState.Enabled = global::System.Drawing.Color.FromArgb(220, 220, 220);
		this.vmethod_62().BackColorState.Hover = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_62().BackColorState.Pressed = global::System.Drawing.Color.FromArgb(192, 192, 192);
		this.vmethod_62().Border.Color = global::System.Drawing.Color.FromArgb(180, 180, 180);
		this.vmethod_62().Border.HoverColor = global::System.Drawing.Color.FromArgb(120, 183, 230);
		this.vmethod_62().Border.HoverVisible = true;
		this.vmethod_62().Border.Rounding = 6;
		this.vmethod_62().Border.Thickness = 1;
		this.vmethod_62().Border.Type = 1;
		this.vmethod_62().Border.Visible = true;
		this.vmethod_62().DialogResult = global::System.Windows.Forms.DialogResult.None;
		this.vmethod_62().ForeColor = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_62().Image = null;
		this.vmethod_62().Location = new global::System.Drawing.Point(10, 310);
		this.vmethod_62().MouseState = 0;
		this.vmethod_62().Name = "btnStart";
		this.vmethod_62().Size = new global::System.Drawing.Size(61, 30);
		this.vmethod_62().TabIndex = 92;
		this.vmethod_62().Text = "Start";
		this.vmethod_62().TextImageRelation = global::System.Windows.Forms.TextImageRelation.Overlay;
		this.vmethod_62().TextStyle.Disabled = global::System.Drawing.Color.FromArgb(131, 129, 129);
		this.vmethod_62().TextStyle.Enabled = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_62().TextStyle.Hover = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_62().TextStyle.Pressed = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_62().TextStyle.TextAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_62().TextStyle.TextLineAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_62().TextStyle.TextRenderingHint = global::System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
		this.vmethod_64().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_64().BackColorState.Disabled = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_64().BackColorState.Enabled = global::System.Drawing.Color.FromArgb(220, 220, 220);
		this.vmethod_64().BackColorState.Hover = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_64().BackColorState.Pressed = global::System.Drawing.Color.FromArgb(192, 192, 192);
		this.vmethod_64().Border.Color = global::System.Drawing.Color.FromArgb(180, 180, 180);
		this.vmethod_64().Border.HoverColor = global::System.Drawing.Color.FromArgb(120, 183, 230);
		this.vmethod_64().Border.HoverVisible = true;
		this.vmethod_64().Border.Rounding = 6;
		this.vmethod_64().Border.Thickness = 1;
		this.vmethod_64().Border.Type = 1;
		this.vmethod_64().Border.Visible = true;
		this.vmethod_64().DialogResult = global::System.Windows.Forms.DialogResult.None;
		this.vmethod_64().ForeColor = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_64().Image = null;
		this.vmethod_64().Location = new global::System.Drawing.Point(76, 310);
		this.vmethod_64().MouseState = 0;
		this.vmethod_64().Name = "btnStop";
		this.vmethod_64().Size = new global::System.Drawing.Size(61, 30);
		this.vmethod_64().TabIndex = 93;
		this.vmethod_64().Text = "Stop";
		this.vmethod_64().TextImageRelation = global::System.Windows.Forms.TextImageRelation.Overlay;
		this.vmethod_64().TextStyle.Disabled = global::System.Drawing.Color.FromArgb(131, 129, 129);
		this.vmethod_64().TextStyle.Enabled = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_64().TextStyle.Hover = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_64().TextStyle.Pressed = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_64().TextStyle.TextAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_64().TextStyle.TextLineAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_64().TextStyle.TextRenderingHint = global::System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new global::System.Drawing.Size(885, 361);
		base.Controls.Add(this.vmethod_64());
		base.Controls.Add(this.vmethod_62());
		base.Controls.Add(this.vmethod_54());
		base.Controls.Add(this.vmethod_56());
		base.Controls.Add(this.vmethod_36());
		base.Controls.Add(this.vmethod_2());
		base.Controls.Add(this.vmethod_4());
		base.Controls.Add(this.vmethod_6());
		base.Controls.Add(this.vmethod_8());
		base.Controls.Add(this.vmethod_10());
		base.Controls.Add(this.vmethod_20());
		this.DoubleBuffered = true;
		base.Name = "fSocks5";
		base.Opacity = 0.0;
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterParent;
		this.Text = "SOCKS5 Manager";
		this.vmethod_10().ResumeLayout(false);
		this.vmethod_10().PerformLayout();
		this.vmethod_20().EndInit();
		this.vmethod_22().ResumeLayout(false);
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_36()).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_54()).EndInit();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x040006CA RID: 1738
	private global::System.ComponentModel.IContainer icontainer_0;
}
