﻿using System;
using System.Reflection;

// Token: 0x02000013 RID: 19
internal sealed class Class96 : Class94
{
	// Token: 0x0600019D RID: 413 RVA: 0x00003628 File Offset: 0x00001828
	public Class96(object object_1)
	{
		if (object_1 != null && !(object_1 is ValueType))
		{
			throw new ArgumentException();
		}
		this.object_0 = object_1;
	}

	// Token: 0x0600019E RID: 414 RVA: 0x00003648 File Offset: 0x00001848
	public object method_2()
	{
		return this.object_0;
	}

	// Token: 0x0600019F RID: 415 RVA: 0x00003650 File Offset: 0x00001850
	public void method_3(object object_1)
	{
		if (object_1 != null && !(object_1 is ValueType))
		{
			throw new ArgumentException();
		}
		this.object_0 = object_1;
	}

	// Token: 0x060001A0 RID: 416 RVA: 0x0000366A File Offset: 0x0000186A
	public override object vmethod_0()
	{
		return this.method_2();
	}

	// Token: 0x060001A1 RID: 417 RVA: 0x00003672 File Offset: 0x00001872
	public override void vmethod_1(object object_1)
	{
		this.method_3(object_1);
	}

	// Token: 0x060001A2 RID: 418 RVA: 0x0000367B File Offset: 0x0000187B
	public override int vmethod_2()
	{
		return 20;
	}

	// Token: 0x060001A3 RID: 419 RVA: 0x00019410 File Offset: 0x00017610
	public override Class94 vmethod_3(Class94 class94_0)
	{
		base.method_1(class94_0.method_0());
		int num = class94_0.vmethod_2();
		if (num != 4)
		{
			if (num == 20)
			{
				if (this.method_2() != null)
				{
					object obj = ((Class96)class94_0).method_2();
					Type type = this.method_2().GetType();
					if (obj != null && !type.IsPrimitive && !type.IsEnum && type.IsAssignableFrom(obj.GetType()))
					{
						foreach (FieldInfo fieldInfo in type.GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.FlattenHierarchy | BindingFlags.GetField | BindingFlags.SetField))
						{
							fieldInfo.SetValue(this.method_2(), fieldInfo.GetValue(obj));
						}
					}
					else
					{
						this.method_3(obj);
					}
				}
				else
				{
					this.method_3(((Class96)class94_0).method_2());
				}
			}
			else
			{
				this.method_3(class94_0.vmethod_0());
			}
		}
		else
		{
			this.method_3(((Class102)class94_0).method_2());
		}
		return this;
	}

	// Token: 0x060001A4 RID: 420 RVA: 0x0000367F File Offset: 0x0000187F
	public override Class94 vmethod_4()
	{
		Class96 @class = new Class96(this.object_0);
		@class.method_1(base.method_0());
		return @class;
	}

	// Token: 0x0400003D RID: 61
	private object object_0;
}
