﻿using System;

// Token: 0x0200009D RID: 157
internal sealed class Class111 : Class109
{
	// Token: 0x060004C5 RID: 1221 RVA: 0x00004FB5 File Offset: 0x000031B5
	public Array method_4()
	{
		return this.array_0;
	}

	// Token: 0x060004C6 RID: 1222 RVA: 0x00004FBD File Offset: 0x000031BD
	public void method_5(Array array_1)
	{
		this.array_0 = array_1;
	}

	// Token: 0x060004C7 RID: 1223 RVA: 0x00004FC6 File Offset: 0x000031C6
	public int[] method_6()
	{
		return this.int_0;
	}

	// Token: 0x060004C8 RID: 1224 RVA: 0x00004FCE File Offset: 0x000031CE
	public void method_7(int[] int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x060004C9 RID: 1225 RVA: 0x00004FD7 File Offset: 0x000031D7
	public override object vmethod_5()
	{
		return this.method_4().GetValue(this.method_6());
	}

	// Token: 0x060004CA RID: 1226 RVA: 0x00004FEA File Offset: 0x000031EA
	public override void vmethod_6(object object_0)
	{
		this.method_4().SetValue(object_0, this.method_6());
	}

	// Token: 0x060004CB RID: 1227 RVA: 0x00004FFE File Offset: 0x000031FE
	public override Class94 vmethod_4()
	{
		Class111 @class = new Class111();
		@class.method_5(this.method_4());
		@class.method_7(this.method_6());
		@class.method_3(base.method_2());
		@class.method_1(base.method_0());
		return @class;
	}

	// Token: 0x060004CC RID: 1228 RVA: 0x000036C9 File Offset: 0x000018C9
	public override int vmethod_2()
	{
		return 16;
	}

	// Token: 0x060004CD RID: 1229 RVA: 0x000230A8 File Offset: 0x000212A8
	public override Class94 vmethod_3(Class94 class94_0)
	{
		base.method_1(class94_0.method_0());
		int num = class94_0.vmethod_2();
		if (num == 16)
		{
			Class111 @class = (Class111)class94_0;
			this.method_5(@class.method_4());
			this.method_7(@class.method_6());
			base.method_3(@class.method_2());
			return this;
		}
		throw new ArgumentOutOfRangeException();
	}

	// Token: 0x060004CE RID: 1230 RVA: 0x00023104 File Offset: 0x00021304
	public override bool vmethod_7(Class109 class109_0)
	{
		Class111 @class = (Class111)class109_0;
		return this.method_4() == @class.method_4() && Class68.smethod_0(this.method_6(), @class.method_6());
	}

	// Token: 0x040001EF RID: 495
	private Array array_0;

	// Token: 0x040001F0 RID: 496
	private int[] int_0;
}
