﻿using System;
using System.Runtime.InteropServices;
using System.Security;

// Token: 0x0200008C RID: 140
internal sealed class Class81 : IDisposable, Interface7
{
	// Token: 0x0600044A RID: 1098 RVA: 0x00004B4B File Offset: 0x00002D4B
	public int imethod_0()
	{
		return this.secureString_0.Length;
	}

	// Token: 0x0600044B RID: 1099 RVA: 0x00004B58 File Offset: 0x00002D58
	public Interface7 imethod_4()
	{
		return new Class81();
	}

	// Token: 0x0600044C RID: 1100 RVA: 0x0002202C File Offset: 0x0002022C
	public void imethod_1(int int_0, out byte byte_0)
	{
		if (int_0 >= 0 && int_0 < this.imethod_0())
		{
			IntPtr intPtr = IntPtr.Zero;
			char char_ = '\0';
			try
			{
				intPtr = Marshal.SecureStringToGlobalAllocUnicode(this.secureString_0);
				char_ = (char)Marshal.ReadInt16(intPtr, int_0 * 2);
				byte_0 = Class81.smethod_1(char_, int_0);
				return;
			}
			finally
			{
				Class83.smethod_3(ref char_);
				if (intPtr != IntPtr.Zero)
				{
					Marshal.ZeroFreeGlobalAllocUnicode(intPtr);
				}
			}
		}
		throw new ArgumentOutOfRangeException();
	}

	// Token: 0x0600044D RID: 1101 RVA: 0x000220A4 File Offset: 0x000202A4
	public void imethod_2(int int_0, ref byte byte_0)
	{
		for (int i = this.secureString_0.Length; i <= int_0; i++)
		{
			if (i == int_0)
			{
				this.secureString_0.AppendChar(Class81.smethod_0(byte_0, i));
				return;
			}
			this.secureString_0.AppendChar(Class81.smethod_0(0, i));
		}
		this.secureString_0.SetAt(int_0, Class81.smethod_0(byte_0, int_0));
	}

	// Token: 0x0600044E RID: 1102 RVA: 0x00004B5F File Offset: 0x00002D5F
	private static char smethod_0(byte byte_0, int int_0)
	{
		return (char)(byte_0 + 1);
	}

	// Token: 0x0600044F RID: 1103 RVA: 0x00004B65 File Offset: 0x00002D65
	private static byte smethod_1(char char_0, int int_0)
	{
		return (byte)(char_0 - '\u0001');
	}

	// Token: 0x06000450 RID: 1104 RVA: 0x00004B6B File Offset: 0x00002D6B
	public void imethod_3()
	{
		this.secureString_0.Clear();
	}

	// Token: 0x06000451 RID: 1105 RVA: 0x00004B78 File Offset: 0x00002D78
	public void Dispose()
	{
		this.secureString_0.Dispose();
		this.secureString_0 = null;
	}

	// Token: 0x040001D4 RID: 468
	private SecureString secureString_0 = new SecureString();
}
