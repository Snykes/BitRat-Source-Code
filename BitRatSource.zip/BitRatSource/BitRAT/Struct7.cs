﻿using System;
using System.Threading;

// Token: 0x02000047 RID: 71
internal struct Struct7
{
	// Token: 0x060002ED RID: 749 RVA: 0x000040B6 File Offset: 0x000022B6
	public Struct7(string string_0)
	{
		this.nullable_0 = new long?(Class56.smethod_0(string_0));
	}

	// Token: 0x060002EE RID: 750 RVA: 0x000040C9 File Offset: 0x000022C9
	public long method_0()
	{
		return Class56.smethod_2(this.nullable_0);
	}

	// Token: 0x060002EF RID: 751 RVA: 0x000040D6 File Offset: 0x000022D6
	public void method_1(long long_0)
	{
		this.nullable_0 = new long?(Class56.smethod_1(long_0));
	}

	// Token: 0x060002F0 RID: 752 RVA: 0x000040E9 File Offset: 0x000022E9
	public void method_2()
	{
		this.nullable_0 = new long?(Class56.smethod_1(0L));
	}

	// Token: 0x060002F1 RID: 753 RVA: 0x0001F058 File Offset: 0x0001D258
	public int method_3()
	{
		return Class56.smethod_2(this.nullable_0).GetHashCode();
	}

	// Token: 0x060002F2 RID: 754 RVA: 0x0001F078 File Offset: 0x0001D278
	public bool method_4(long long_0)
	{
		return Class56.smethod_2(this.nullable_0).Equals(long_0);
	}

	// Token: 0x060002F3 RID: 755 RVA: 0x0001F09C File Offset: 0x0001D29C
	public bool method_5(object object_0)
	{
		return Class56.smethod_2(this.nullable_0).Equals(object_0);
	}

	// Token: 0x060002F4 RID: 756 RVA: 0x0001F0C0 File Offset: 0x0001D2C0
	public int method_6(long long_0)
	{
		return Class56.smethod_2(this.nullable_0).CompareTo(long_0);
	}

	// Token: 0x060002F5 RID: 757 RVA: 0x0001F0E4 File Offset: 0x0001D2E4
	public int method_7(object object_0)
	{
		return Class56.smethod_2(this.nullable_0).CompareTo(object_0);
	}

	// Token: 0x060002F6 RID: 758 RVA: 0x00003BBC File Offset: 0x00001DBC
	public TypeCode method_8()
	{
		return TypeCode.Int64;
	}

	// Token: 0x060002F7 RID: 759 RVA: 0x0001F108 File Offset: 0x0001D308
	public string method_9()
	{
		return Class56.smethod_2(this.nullable_0).ToString();
	}

	// Token: 0x060002F8 RID: 760 RVA: 0x0001F128 File Offset: 0x0001D328
	public string method_10(string string_0)
	{
		return Class56.smethod_2(this.nullable_0).ToString(string_0);
	}

	// Token: 0x060002F9 RID: 761 RVA: 0x0001F14C File Offset: 0x0001D34C
	public string method_11(IFormatProvider iformatProvider_0)
	{
		return Class56.smethod_2(this.nullable_0).ToString(iformatProvider_0);
	}

	// Token: 0x060002FA RID: 762 RVA: 0x0001F170 File Offset: 0x0001D370
	public string method_12(string string_0, IFormatProvider iformatProvider_0)
	{
		return Class56.smethod_2(this.nullable_0).ToString(string_0, iformatProvider_0);
	}

	// Token: 0x060002FB RID: 763 RVA: 0x00004104 File Offset: 0x00002304
	public long method_13()
	{
		long result = Class56.smethod_2(this.nullable_0);
		Thread.MemoryBarrier();
		return result;
	}

	// Token: 0x060002FC RID: 764 RVA: 0x00004116 File Offset: 0x00002316
	public void method_14(long long_0)
	{
		Thread.MemoryBarrier();
		this.nullable_0 = new long?(Class56.smethod_1(long_0));
	}

	// Token: 0x060002FD RID: 765 RVA: 0x0001F194 File Offset: 0x0001D394
	public long method_15()
	{
		object object_ = Class82.object_0;
		long result;
		lock (object_)
		{
			long num = Class56.smethod_2(this.nullable_0) + 1L;
			this.nullable_0 = new long?(Class56.smethod_1(num));
			result = num;
		}
		return result;
	}

	// Token: 0x060002FE RID: 766 RVA: 0x0001F1F8 File Offset: 0x0001D3F8
	public long method_16()
	{
		object object_ = Class82.object_0;
		long result;
		lock (object_)
		{
			long num = Class56.smethod_2(this.nullable_0) - 1L;
			this.nullable_0 = new long?(Class56.smethod_1(num));
			result = num;
		}
		return result;
	}

	// Token: 0x060002FF RID: 767 RVA: 0x0001F25C File Offset: 0x0001D45C
	public long method_17(long long_0)
	{
		object object_ = Class82.object_0;
		long result;
		lock (object_)
		{
			long num = Class56.smethod_2(this.nullable_0) + long_0;
			this.nullable_0 = new long?(Class56.smethod_1(num));
			result = num;
		}
		return result;
	}

	// Token: 0x06000300 RID: 768 RVA: 0x0001F2B8 File Offset: 0x0001D4B8
	public long method_18(long long_0)
	{
		object object_ = Class82.object_0;
		long result;
		lock (object_)
		{
			long num = Class56.smethod_2(this.nullable_0);
			this.nullable_0 = new long?(Class56.smethod_1(long_0));
			result = num;
		}
		return result;
	}

	// Token: 0x06000301 RID: 769 RVA: 0x0001F310 File Offset: 0x0001D510
	public long method_19(long long_0, long long_1)
	{
		object object_ = Class82.object_0;
		long result;
		lock (object_)
		{
			long num = Class56.smethod_2(this.nullable_0);
			if (num == long_1)
			{
				this.nullable_0 = new long?(Class56.smethod_1(long_0));
			}
			result = num;
		}
		return result;
	}

	// Token: 0x04000187 RID: 391
	private long? nullable_0;
}
