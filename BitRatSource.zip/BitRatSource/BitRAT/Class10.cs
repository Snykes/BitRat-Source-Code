﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;

// Token: 0x02000015 RID: 21
internal static class Class10
{
	// Token: 0x060001B6 RID: 438 RVA: 0x00003747 File Offset: 0x00001947
	public static void smethod_0(Array array_0, RuntimeFieldHandle runtimeFieldHandle_0)
	{
		if (Class23.smethod_0())
		{
			int metadataToken = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0).MetadataToken;
		}
		RuntimeHelpers.InitializeArray(array_0, runtimeFieldHandle_0);
	}
}
