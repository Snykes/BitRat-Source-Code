﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using Microsoft.VisualBasic.Devices;

// Token: 0x020000EE RID: 238
[GeneratedCode("MyTemplate", "11.0.0.0")]
[EditorBrowsable(EditorBrowsableState.Never)]
internal sealed class Class129 : Computer
{
	// Token: 0x06000BA9 RID: 2985 RVA: 0x00007632 File Offset: 0x00005832
	[DebuggerHidden]
	[EditorBrowsable(EditorBrowsableState.Never)]
	public Class129()
	{
	}
}
