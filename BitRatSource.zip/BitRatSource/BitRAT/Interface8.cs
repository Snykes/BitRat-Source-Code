﻿using System;

// Token: 0x02000077 RID: 119
internal interface Interface8
{
	// Token: 0x060003D4 RID: 980
	Interface5 imethod_0();
}
