﻿using System;
using System.Security.Cryptography;

// Token: 0x02000012 RID: 18
internal sealed class Class92 : Class91
{
	// Token: 0x06000197 RID: 407 RVA: 0x000035CE File Offset: 0x000017CE
	public Class92(ICryptoTransform icryptoTransform_1)
	{
		this.icryptoTransform_0 = icryptoTransform_1;
	}

	// Token: 0x06000198 RID: 408 RVA: 0x000035DD File Offset: 0x000017DD
	public override void Dispose()
	{
		this.icryptoTransform_0.Dispose();
	}

	// Token: 0x06000199 RID: 409 RVA: 0x000035EA File Offset: 0x000017EA
	public override bool vmethod_0()
	{
		return this.icryptoTransform_0.CanReuseTransform;
	}

	// Token: 0x0600019A RID: 410 RVA: 0x000035F7 File Offset: 0x000017F7
	public override int vmethod_1()
	{
		return this.icryptoTransform_0.InputBlockSize;
	}

	// Token: 0x0600019B RID: 411 RVA: 0x00003604 File Offset: 0x00001804
	public override int vmethod_2(byte[] byte_0, int int_0, int int_1, byte[] byte_1, int int_2)
	{
		return this.icryptoTransform_0.TransformBlock(byte_0, int_0, int_1, byte_1, int_2);
	}

	// Token: 0x0600019C RID: 412 RVA: 0x00003618 File Offset: 0x00001818
	public override byte[] vmethod_3(byte[] byte_0, int int_0, int int_1)
	{
		return this.icryptoTransform_0.TransformFinalBlock(byte_0, int_0, int_1);
	}

	// Token: 0x0400003C RID: 60
	private ICryptoTransform icryptoTransform_0;
}
