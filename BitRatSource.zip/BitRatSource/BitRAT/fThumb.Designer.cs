﻿// Token: 0x02000110 RID: 272
[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
public sealed partial class fThumb : global::System.Windows.Forms.Form
{
	// Token: 0x06000E74 RID: 3700 RVA: 0x0006D168 File Offset: 0x0006B368
	[global::System.Diagnostics.DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && this.icontainer_0 != null)
			{
				this.icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	// Token: 0x06000E75 RID: 3701 RVA: 0x0006D1A8 File Offset: 0x0006B3A8
	[global::System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		this.vmethod_3(new global::System.Windows.Forms.Timer(this.icontainer_0));
		this.vmethod_5(new global::System.Windows.Forms.Timer(this.icontainer_0));
		this.vmethod_7(new global::Zeroit.Framework.Progress.ZeroitWin8ProgressRing());
		this.vmethod_1(new global::System.Windows.Forms.PictureBox());
		this.vmethod_9(new global::System.Windows.Forms.Label());
		this.vmethod_11(new global::System.Windows.Forms.Timer(this.icontainer_0));
		this.vmethod_13(new global::System.Windows.Forms.Label());
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_0()).BeginInit();
		base.SuspendLayout();
		this.vmethod_2().Interval = 1;
		this.vmethod_4().Interval = 1;
		this.vmethod_6().Animate = false;
		this.vmethod_6().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_6().ControlHeight = 80;
		this.vmethod_6().Location = new global::System.Drawing.Point(58, 37);
		this.vmethod_6().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_6().Name = "ziLoader";
		this.vmethod_6().RefreshRate = 100;
		this.vmethod_6().Size = new global::System.Drawing.Size(80, 80);
		this.vmethod_6().TabIndex = 31;
		this.vmethod_0().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_0().BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
		this.vmethod_0().Location = new global::System.Drawing.Point(0, 0);
		this.vmethod_0().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_0().Name = "pbThumb";
		this.vmethod_0().Size = new global::System.Drawing.Size(197, 138);
		this.vmethod_0().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_0().TabIndex = 30;
		this.vmethod_0().TabStop = false;
		this.vmethod_8().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_8().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_8().ForeColor = global::System.Drawing.Color.Black;
		this.vmethod_8().Location = new global::System.Drawing.Point(0, 0);
		this.vmethod_8().Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
		this.vmethod_8().Name = "lblCaption";
		this.vmethod_8().Size = new global::System.Drawing.Size(197, 14);
		this.vmethod_8().TabIndex = 32;
		this.vmethod_8().TextAlign = global::System.Drawing.ContentAlignment.TopCenter;
		this.vmethod_10().Interval = 1;
		this.vmethod_12().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_12().Dock = global::System.Windows.Forms.DockStyle.Bottom;
		this.vmethod_12().ForeColor = global::System.Drawing.Color.Black;
		this.vmethod_12().Location = new global::System.Drawing.Point(0, 140);
		this.vmethod_12().Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
		this.vmethod_12().Name = "lblData";
		this.vmethod_12().Size = new global::System.Drawing.Size(197, 14);
		this.vmethod_12().TabIndex = 33;
		this.vmethod_12().TextAlign = global::System.Drawing.ContentAlignment.TopRight;
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = global::System.Drawing.Color.SkyBlue;
		base.ClientSize = new global::System.Drawing.Size(197, 154);
		base.ControlBox = false;
		base.Controls.Add(this.vmethod_12());
		base.Controls.Add(this.vmethod_8());
		base.Controls.Add(this.vmethod_6());
		base.Controls.Add(this.vmethod_0());
		this.DoubleBuffered = true;
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "fThumb";
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		base.SizeGripStyle = global::System.Windows.Forms.SizeGripStyle.Hide;
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_0()).EndInit();
		base.ResumeLayout(false);
	}

	// Token: 0x040005B2 RID: 1458
	private global::System.ComponentModel.IContainer icontainer_0;
}
