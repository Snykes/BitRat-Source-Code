﻿using System;

// Token: 0x02000035 RID: 53
internal sealed class Class102 : Class94
{
	// Token: 0x06000296 RID: 662 RVA: 0x00003E04 File Offset: 0x00002004
	public object method_2()
	{
		return this.object_0;
	}

	// Token: 0x06000297 RID: 663 RVA: 0x00003E0C File Offset: 0x0000200C
	public void method_3(object object_1)
	{
		this.object_0 = object_1;
	}

	// Token: 0x06000298 RID: 664 RVA: 0x00003E15 File Offset: 0x00002015
	public override object vmethod_0()
	{
		return this.method_2();
	}

	// Token: 0x06000299 RID: 665 RVA: 0x00003E1D File Offset: 0x0000201D
	public override void vmethod_1(object object_1)
	{
		this.method_3(object_1);
	}

	// Token: 0x0600029A RID: 666 RVA: 0x00003E26 File Offset: 0x00002026
	public override int vmethod_2()
	{
		return 4;
	}

	// Token: 0x0600029B RID: 667 RVA: 0x00003E29 File Offset: 0x00002029
	public override Class94 vmethod_3(Class94 class94_0)
	{
		base.method_1(class94_0.method_0());
		this.method_3(class94_0.vmethod_0());
		return this;
	}

	// Token: 0x0600029C RID: 668 RVA: 0x00003E44 File Offset: 0x00002044
	public override Class94 vmethod_4()
	{
		Class102 @class = new Class102();
		@class.method_3(this.object_0);
		@class.method_1(base.method_0());
		return @class;
	}

	// Token: 0x0400015D RID: 349
	private object object_0;
}
