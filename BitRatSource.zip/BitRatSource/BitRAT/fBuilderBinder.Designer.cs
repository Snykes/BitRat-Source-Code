﻿// Token: 0x02000123 RID: 291
[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
public sealed partial class fBuilderBinder : global::System.Windows.Forms.Form
{
	// Token: 0x0600104F RID: 4175 RVA: 0x00079704 File Offset: 0x00077904
	[global::System.Diagnostics.DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && this.icontainer_0 != null)
			{
				this.icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	// Token: 0x06001050 RID: 4176 RVA: 0x00079744 File Offset: 0x00077944
	[global::System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		this.vmethod_3(new global::VisualPlus.Toolkit.Controls.Interactivity.VisualButton());
		this.vmethod_5(new global::System.Windows.Forms.RadioButton());
		this.vmethod_7(new global::System.Windows.Forms.RadioButton());
		this.vmethod_13(new global::VisualPlus.Toolkit.Controls.Interactivity.VisualButton());
		this.vmethod_15(new global::System.Windows.Forms.ContextMenuStrip(this.icontainer_0));
		this.vmethod_17(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_19(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_21(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_23(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_25(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_27(new global::System.Windows.Forms.CheckBox());
		this.vmethod_9(new global::System.Windows.Forms.PictureBox());
		this.vmethod_11(new global::System.Windows.Forms.PictureBox());
		this.vmethod_1(new global::GClass7());
		this.vmethod_29(new global::VisualPlus.Toolkit.Controls.Interactivity.VisualButton());
		this.vmethod_14().SuspendLayout();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_8()).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_10()).BeginInit();
		base.SuspendLayout();
		this.vmethod_2().BackColorState.Disabled = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_2().BackColorState.Enabled = global::System.Drawing.Color.FromArgb(220, 220, 220);
		this.vmethod_2().BackColorState.Hover = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_2().BackColorState.Pressed = global::System.Drawing.Color.FromArgb(192, 192, 192);
		this.vmethod_2().Border.Color = global::System.Drawing.Color.FromArgb(180, 180, 180);
		this.vmethod_2().Border.HoverColor = global::System.Drawing.Color.FromArgb(120, 183, 230);
		this.vmethod_2().Border.HoverVisible = true;
		this.vmethod_2().Border.Rounding = 6;
		this.vmethod_2().Border.Thickness = 1;
		this.vmethod_2().Border.Type = 1;
		this.vmethod_2().Border.Visible = true;
		this.vmethod_2().DialogResult = global::System.Windows.Forms.DialogResult.None;
		this.vmethod_2().ForeColor = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_2().Image = null;
		this.vmethod_2().Location = new global::System.Drawing.Point(355, 12);
		this.vmethod_2().MouseState = 0;
		this.vmethod_2().Name = "btnAdd";
		this.vmethod_2().Size = new global::System.Drawing.Size(63, 19);
		this.vmethod_2().TabIndex = 112;
		this.vmethod_2().Text = "Add file";
		this.vmethod_2().TextImageRelation = global::System.Windows.Forms.TextImageRelation.Overlay;
		this.vmethod_2().TextStyle.Disabled = global::System.Drawing.Color.FromArgb(131, 129, 129);
		this.vmethod_2().TextStyle.Enabled = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_2().TextStyle.Hover = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_2().TextStyle.Pressed = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_2().TextStyle.TextAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_2().TextStyle.TextLineAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_2().TextStyle.TextRenderingHint = global::System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
		this.vmethod_4().AutoSize = true;
		this.vmethod_4().Location = new global::System.Drawing.Point(130, 12);
		this.vmethod_4().Name = "rbMem";
		this.vmethod_4().Size = new global::System.Drawing.Size(114, 17);
		this.vmethod_4().TabIndex = 115;
		this.vmethod_4().Text = "Execute in memory";
		this.vmethod_4().UseVisualStyleBackColor = true;
		this.vmethod_6().AutoSize = true;
		this.vmethod_6().Checked = true;
		this.vmethod_6().Location = new global::System.Drawing.Point(12, 12);
		this.vmethod_6().Name = "rbDisk";
		this.vmethod_6().Size = new global::System.Drawing.Size(90, 17);
		this.vmethod_6().TabIndex = 114;
		this.vmethod_6().TabStop = true;
		this.vmethod_6().Text = "Run from disk";
		this.vmethod_6().UseVisualStyleBackColor = true;
		this.vmethod_12().Anchor = global::System.Windows.Forms.AnchorStyles.Top;
		this.vmethod_12().BackColorState.Disabled = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_12().BackColorState.Enabled = global::System.Drawing.Color.FromArgb(220, 220, 220);
		this.vmethod_12().BackColorState.Hover = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_12().BackColorState.Pressed = global::System.Drawing.Color.FromArgb(192, 192, 192);
		this.vmethod_12().Border.Color = global::System.Drawing.Color.FromArgb(180, 180, 180);
		this.vmethod_12().Border.HoverColor = global::System.Drawing.Color.FromArgb(120, 183, 230);
		this.vmethod_12().Border.HoverVisible = true;
		this.vmethod_12().Border.Rounding = 6;
		this.vmethod_12().Border.Thickness = 1;
		this.vmethod_12().Border.Type = 1;
		this.vmethod_12().Border.Visible = true;
		this.vmethod_12().DialogResult = global::System.Windows.Forms.DialogResult.None;
		this.vmethod_12().ForeColor = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_12().Image = null;
		this.vmethod_12().Location = new global::System.Drawing.Point(549, 8);
		this.vmethod_12().MouseState = 0;
		this.vmethod_12().Name = "btnBuild";
		this.vmethod_12().Size = new global::System.Drawing.Size(80, 26);
		this.vmethod_12().TabIndex = 118;
		this.vmethod_12().Text = "Build";
		this.vmethod_12().TextImageRelation = global::System.Windows.Forms.TextImageRelation.Overlay;
		this.vmethod_12().TextStyle.Disabled = global::System.Drawing.Color.FromArgb(131, 129, 129);
		this.vmethod_12().TextStyle.Enabled = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_12().TextStyle.Hover = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_12().TextStyle.Pressed = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_12().TextStyle.TextAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_12().TextStyle.TextLineAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_12().TextStyle.TextRenderingHint = global::System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
		this.vmethod_14().Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_16(),
			this.vmethod_18(),
			this.vmethod_20(),
			this.vmethod_22(),
			this.vmethod_24()
		});
		this.vmethod_14().Name = "cmsFiles";
		this.vmethod_14().Size = new global::System.Drawing.Size(164, 82);
		this.vmethod_16().Name = "AddToolStripMenuItem";
		this.vmethod_16().Size = new global::System.Drawing.Size(163, 22);
		this.vmethod_16().Text = "Add";
		this.vmethod_18().Name = "ToolStripMenuItem1";
		this.vmethod_18().Size = new global::System.Drawing.Size(160, 6);
		this.vmethod_20().Name = "RemoveSelectedToolStripMenuItem";
		this.vmethod_20().Size = new global::System.Drawing.Size(163, 22);
		this.vmethod_20().Text = "Remove selected";
		this.vmethod_22().Name = "ToolStripMenuItem2";
		this.vmethod_22().Size = new global::System.Drawing.Size(160, 6);
		this.vmethod_24().Name = "ClearToolStripMenuItem";
		this.vmethod_24().Size = new global::System.Drawing.Size(163, 22);
		this.vmethod_24().Text = "Clear";
		this.vmethod_26().AutoSize = true;
		this.vmethod_26().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_26().Location = new global::System.Drawing.Point(278, 14);
		this.vmethod_26().Margin = new global::System.Windows.Forms.Padding(1);
		this.vmethod_26().Name = "chkRunOnce";
		this.vmethod_26().Size = new global::System.Drawing.Size(73, 17);
		this.vmethod_26().TabIndex = 119;
		this.vmethod_26().Text = "Run once";
		this.vmethod_26().UseVisualStyleBackColor = false;
		this.vmethod_8().Image = global::Class131.smethod_24();
		this.vmethod_8().Location = new global::System.Drawing.Point(244, 14);
		this.vmethod_8().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_8().Name = "pbMem";
		this.vmethod_8().Size = new global::System.Drawing.Size(15, 15);
		this.vmethod_8().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_8().TabIndex = 117;
		this.vmethod_8().TabStop = false;
		this.vmethod_10().Image = global::Class131.smethod_24();
		this.vmethod_10().Location = new global::System.Drawing.Point(102, 14);
		this.vmethod_10().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_10().Name = "pbDisk";
		this.vmethod_10().Size = new global::System.Drawing.Size(15, 15);
		this.vmethod_10().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_10().TabIndex = 116;
		this.vmethod_10().TabStop = false;
		this.vmethod_0().Alignment = global::System.Windows.Forms.ListViewAlignment.Left;
		this.vmethod_0().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_0().AutoArrange = false;
		this.vmethod_0().BackColor = global::System.Drawing.Color.White;
		this.vmethod_0().ContextMenuStrip = this.vmethod_14();
		this.vmethod_0().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.142858f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_0().ForeColor = global::System.Drawing.Color.Black;
		this.vmethod_0().FullRowSelect = true;
		this.vmethod_0().HideSelection = false;
		this.vmethod_0().Location = new global::System.Drawing.Point(1, 42);
		this.vmethod_0().Margin = new global::System.Windows.Forms.Padding(1);
		this.vmethod_0().Name = "lvFiles";
		this.vmethod_0().ShowGroups = false;
		this.vmethod_0().Size = new global::System.Drawing.Size(631, 193);
		this.vmethod_0().TabIndex = 110;
		this.vmethod_0().UseCompatibleStateImageBehavior = false;
		this.vmethod_0().View = global::System.Windows.Forms.View.Details;
		this.vmethod_28().BackColorState.Disabled = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_28().BackColorState.Enabled = global::System.Drawing.Color.FromArgb(220, 220, 220);
		this.vmethod_28().BackColorState.Hover = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_28().BackColorState.Pressed = global::System.Drawing.Color.FromArgb(192, 192, 192);
		this.vmethod_28().Border.Color = global::System.Drawing.Color.FromArgb(180, 180, 180);
		this.vmethod_28().Border.HoverColor = global::System.Drawing.Color.FromArgb(120, 183, 230);
		this.vmethod_28().Border.HoverVisible = true;
		this.vmethod_28().Border.Rounding = 6;
		this.vmethod_28().Border.Thickness = 1;
		this.vmethod_28().Border.Type = 1;
		this.vmethod_28().Border.Visible = true;
		this.vmethod_28().DialogResult = global::System.Windows.Forms.DialogResult.None;
		this.vmethod_28().ForeColor = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_28().Image = null;
		this.vmethod_28().Location = new global::System.Drawing.Point(433, 12);
		this.vmethod_28().MouseState = 0;
		this.vmethod_28().Name = "btnIconChanger";
		this.vmethod_28().Size = new global::System.Drawing.Size(88, 19);
		this.vmethod_28().TabIndex = 120;
		this.vmethod_28().Text = "Icon changer";
		this.vmethod_28().TextImageRelation = global::System.Windows.Forms.TextImageRelation.Overlay;
		this.vmethod_28().TextStyle.Disabled = global::System.Drawing.Color.FromArgb(131, 129, 129);
		this.vmethod_28().TextStyle.Enabled = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_28().TextStyle.Hover = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_28().TextStyle.Pressed = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_28().TextStyle.TextAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_28().TextStyle.TextLineAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_28().TextStyle.TextRenderingHint = global::System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = global::System.Drawing.SystemColors.AppWorkspace;
		base.ClientSize = new global::System.Drawing.Size(633, 236);
		base.Controls.Add(this.vmethod_28());
		base.Controls.Add(this.vmethod_26());
		base.Controls.Add(this.vmethod_12());
		base.Controls.Add(this.vmethod_4());
		base.Controls.Add(this.vmethod_6());
		base.Controls.Add(this.vmethod_8());
		base.Controls.Add(this.vmethod_10());
		base.Controls.Add(this.vmethod_2());
		base.Controls.Add(this.vmethod_0());
		this.DoubleBuffered = true;
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedToolWindow;
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "fBuilderBinder";
		base.Opacity = 0.0;
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "Builder - Binder";
		this.vmethod_14().ResumeLayout(false);
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_8()).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_10()).EndInit();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x0400065A RID: 1626
	private global::System.ComponentModel.IContainer icontainer_0;
}
