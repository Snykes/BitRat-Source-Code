﻿using System;

// Token: 0x02000026 RID: 38
internal static class Class23
{
	// Token: 0x06000221 RID: 545 RVA: 0x0001C3E0 File Offset: 0x0001A5E0
	static Class23()
	{
		try
		{
			Class23.bool_0 = (Type.GetType("Mono.Runtime") != null);
		}
		catch
		{
			Class23.bool_0 = false;
		}
	}

	// Token: 0x06000222 RID: 546 RVA: 0x00003B78 File Offset: 0x00001D78
	public static bool smethod_0()
	{
		return Class23.bool_0;
	}

	// Token: 0x0400013D RID: 317
	private static readonly bool bool_0;
}
