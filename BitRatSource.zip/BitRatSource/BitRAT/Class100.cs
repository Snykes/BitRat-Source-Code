﻿using System;

// Token: 0x0200002A RID: 42
internal sealed class Class100 : Class94
{
	// Token: 0x06000234 RID: 564 RVA: 0x00003BD2 File Offset: 0x00001DD2
	public UIntPtr method_2()
	{
		return this.uintptr_0;
	}

	// Token: 0x06000235 RID: 565 RVA: 0x00003BDA File Offset: 0x00001DDA
	public void method_3(UIntPtr uintptr_1)
	{
		this.uintptr_0 = uintptr_1;
	}

	// Token: 0x06000236 RID: 566 RVA: 0x00003BE3 File Offset: 0x00001DE3
	public override Class94 vmethod_4()
	{
		Class100 @class = new Class100();
		@class.method_3(this.uintptr_0);
		@class.method_1(base.method_0());
		return @class;
	}

	// Token: 0x06000237 RID: 567 RVA: 0x00003C02 File Offset: 0x00001E02
	public override object vmethod_0()
	{
		return this.method_2();
	}

	// Token: 0x06000238 RID: 568 RVA: 0x00003C0F File Offset: 0x00001E0F
	public override void vmethod_1(object object_0)
	{
		this.method_3((UIntPtr)object_0);
	}

	// Token: 0x06000239 RID: 569 RVA: 0x00003C1D File Offset: 0x00001E1D
	public override int vmethod_2()
	{
		return 8;
	}

	// Token: 0x0600023A RID: 570 RVA: 0x0001C664 File Offset: 0x0001A864
	public override Class94 vmethod_3(Class94 class94_0)
	{
		base.method_1(class94_0.method_0());
		int num = class94_0.vmethod_2();
		if (num != 0)
		{
			switch (num)
			{
			case 4:
				this.method_3((UIntPtr)((Class102)class94_0).method_2());
				return this;
			case 5:
			case 6:
			case 9:
				break;
			case 7:
				this.method_3((UIntPtr)((ulong)((long)((Class118)class94_0).method_2())));
				return this;
			case 8:
				this.method_3(((Class100)class94_0).method_2());
				return this;
			case 10:
				this.method_3((UIntPtr)((ulong)((Class114)class94_0).method_2()));
				return this;
			case 11:
				this.method_3((UIntPtr)((ulong)((Class99)class94_0).method_2()));
				return this;
			default:
				switch (num)
				{
				case 17:
					this.method_3((UIntPtr)((ulong)((Class117)class94_0).method_2()));
					return this;
				case 19:
					this.method_3((UIntPtr)((Class120)class94_0).method_2());
					return this;
				case 21:
					this.method_3((UIntPtr)((Class104)class94_0).method_2());
					return this;
				case 22:
					this.method_3((UIntPtr)((uint)((Class121)class94_0).method_2()));
					return this;
				case 24:
					this.method_3(new UIntPtr(Convert.ToUInt64(((Class98)class94_0).method_2())));
					return this;
				}
				break;
			}
			throw new ArgumentOutOfRangeException();
		}
		this.method_3((UIntPtr)((uint)((Class119)class94_0).method_2()));
		return this;
	}

	// Token: 0x04000140 RID: 320
	private UIntPtr uintptr_0;
}
