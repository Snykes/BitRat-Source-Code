﻿using System;

// Token: 0x0200006F RID: 111
internal sealed class Class113 : Class94
{
	// Token: 0x060003A2 RID: 930 RVA: 0x000045DD File Offset: 0x000027DD
	public string method_2()
	{
		return this.string_0;
	}

	// Token: 0x060003A3 RID: 931 RVA: 0x000045E5 File Offset: 0x000027E5
	public void method_3(string string_1)
	{
		this.string_0 = string_1;
	}

	// Token: 0x060003A4 RID: 932 RVA: 0x000045EE File Offset: 0x000027EE
	public override object vmethod_0()
	{
		return this.method_2();
	}

	// Token: 0x060003A5 RID: 933 RVA: 0x000045F6 File Offset: 0x000027F6
	public override void vmethod_1(object object_0)
	{
		this.method_3((string)object_0);
	}

	// Token: 0x060003A6 RID: 934 RVA: 0x00004604 File Offset: 0x00002804
	public override int vmethod_2()
	{
		return 5;
	}

	// Token: 0x060003A7 RID: 935 RVA: 0x000202F0 File Offset: 0x0001E4F0
	public override Class94 vmethod_3(Class94 class94_0)
	{
		base.method_1(class94_0.method_0());
		int num = class94_0.vmethod_2();
		if (num != 4)
		{
			if (num != 5)
			{
				throw new ArgumentOutOfRangeException();
			}
			this.method_3(((Class113)class94_0).method_2());
		}
		else
		{
			this.method_3((string)((Class102)class94_0).method_2());
		}
		return this;
	}

	// Token: 0x060003A8 RID: 936 RVA: 0x00004607 File Offset: 0x00002807
	public override Class94 vmethod_4()
	{
		Class113 @class = new Class113();
		@class.method_3(this.string_0);
		@class.method_1(base.method_0());
		return @class;
	}

	// Token: 0x040001B0 RID: 432
	private string string_0;
}
