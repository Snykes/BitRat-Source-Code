﻿using System;

// Token: 0x02000001 RID: 1
internal class <Module>
{
	// Token: 0x06000001 RID: 1 RVA: 0x00002B90 File Offset: 0x00000D90
	static <Module>()
	{
		Class41.smethod_2();
	}
}
