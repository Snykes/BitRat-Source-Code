﻿using System;

// Token: 0x0200007E RID: 126
internal static class Class71<T>
{
	// Token: 0x040001C3 RID: 451
	public static readonly T[] gparam_0 = new T[0];
}
