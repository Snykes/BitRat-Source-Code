﻿using System;
using System.Collections;
using System.Globalization;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

// Token: 0x020001B7 RID: 439
public sealed class GClass9 : IComparer
{
	// Token: 0x0600182B RID: 6187 RVA: 0x0000C460 File Offset: 0x0000A660
	public GClass9()
	{
		this.iformatProvider_0 = new CultureInfo("en-US", true);
	}

	// Token: 0x0600182C RID: 6188 RVA: 0x000B09C0 File Offset: 0x000AEBC0
	public int Compare(object x, object y)
	{
		int num;
		int result;
		int num4;
		object obj;
		try
		{
			IL_00:
			ProjectData.ClearProjectError();
			num = 1;
			IL_07:
			int num2 = 2;
			ListViewItem listViewItem = (ListViewItem)x;
			IL_11:
			num2 = 3;
			ListViewItem listViewItem2 = (ListViewItem)y;
			IL_1B:
			num2 = 4;
			DateTime value = DateTime.ParseExact(listViewItem.Text, "dd-MM-yyyy", CultureInfo.InvariantCulture);
			IL_35:
			num2 = 5;
			DateTime value2 = DateTime.ParseExact(listViewItem2.Text, "dd-MM-yyyy", CultureInfo.InvariantCulture);
			IL_4F:
			num2 = 6;
			if (this.sortOrder_0 != SortOrder.Ascending)
			{
				goto IL_68;
			}
			IL_5A:
			num2 = 7;
			result = value.CompareTo(value2);
			goto IL_75;
			IL_68:
			num2 = 9;
			result = value2.CompareTo(value);
			IL_75:
			goto IL_EC;
			IL_77:
			int num3 = num4 + 1;
			num4 = 0;
			@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
			IL_AD:
			goto IL_E1;
			IL_AF:
			num4 = num2;
			@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num);
			IL_BF:;
		}
		catch when (endfilter(obj is Exception & num != 0 & num4 == 0))
		{
			Exception ex = (Exception)obj2;
			goto IL_AF;
		}
		IL_E1:
		throw ProjectData.CreateProjectError(-2146828237);
		IL_EC:
		if (num4 != 0)
		{
			ProjectData.ClearProjectError();
		}
		return result;
	}

	// Token: 0x0600182D RID: 6189 RVA: 0x0000C479 File Offset: 0x0000A679
	public SortOrder method_0()
	{
		return this.sortOrder_0;
	}

	// Token: 0x0600182E RID: 6190 RVA: 0x0000C481 File Offset: 0x0000A681
	public void method_1(SortOrder sortOrder_1)
	{
		this.sortOrder_0 = sortOrder_1;
	}

	// Token: 0x040008FD RID: 2301
	private SortOrder sortOrder_0;

	// Token: 0x040008FE RID: 2302
	private IFormatProvider iformatProvider_0;
}
