﻿using System;
using System.Reflection;

// Token: 0x0200005D RID: 93
internal static class Class60
{
	// Token: 0x06000343 RID: 835 RVA: 0x0000427C File Offset: 0x0000247C
	public static bool smethod_0(Type type_4)
	{
		return type_4.IsGenericType && type_4.GetGenericTypeDefinition() == Class60.type_1;
	}

	// Token: 0x0400019A RID: 410
	public static readonly Type type_0 = typeof(object);

	// Token: 0x0400019B RID: 411
	public static readonly Type type_1 = typeof(Nullable<>);

	// Token: 0x0400019C RID: 412
	public static readonly Type type_2 = typeof(Enum);

	// Token: 0x0400019D RID: 413
	public static readonly Type type_3 = typeof(ValueType);

	// Token: 0x0400019E RID: 414
	public static readonly Assembly assembly_0 = typeof(Class60).Assembly;
}
