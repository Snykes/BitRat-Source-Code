﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

// Token: 0x0200003B RID: 59
internal static class Class41
{
	// Token: 0x060002AF RID: 687 RVA: 0x00003EDF File Offset: 0x000020DF
	private static bool smethod_0()
	{
		return Class41.smethod_1();
	}

	// Token: 0x060002B0 RID: 688 RVA: 0x0001E174 File Offset: 0x0001C374
	private static bool smethod_1()
	{
		StackTrace stackTrace = new StackTrace();
		StackFrame frame = stackTrace.GetFrame(3);
		MethodBase methodBase = (frame == null) ? null : frame.GetMethod();
		Type type = (methodBase == null) ? null : methodBase.DeclaringType;
		return type != typeof(RuntimeMethodHandle) && type != null && type.Assembly == typeof(Class41).Assembly;
	}

	// Token: 0x060002B1 RID: 689 RVA: 0x00003EEB File Offset: 0x000020EB
	internal static void smethod_2()
	{
		Class41.smethod_11();
		AppDomain.CurrentDomain.AssemblyResolve += Class41.smethod_4;
	}

	// Token: 0x060002B2 RID: 690 RVA: 0x0001E1D8 File Offset: 0x0001C3D8
	internal static Assembly smethod_3(string string_0)
	{
		return Class41.smethod_5(string_0);
	}

	// Token: 0x060002B3 RID: 691 RVA: 0x0001E1F0 File Offset: 0x0001C3F0
	private static Assembly smethod_4(object object_0, ResolveEventArgs resolveEventArgs_0)
	{
		Assembly assembly = Class41.smethod_5(resolveEventArgs_0.Name);
		if (assembly == null)
		{
			assembly = Class41.smethod_10(resolveEventArgs_0);
		}
		return assembly;
	}

	// Token: 0x060002B4 RID: 692 RVA: 0x0001E214 File Offset: 0x0001C414
	private static Assembly smethod_5(string string_0)
	{
		Class41.Struct6 @struct = new Class41.Struct6(string_0.ToUpperInvariant());
		Class41.Class45.Class47 @class = null;
		bool flag = false;
		if (!@struct.bool_2 || @struct.string_2 != null)
		{
			foreach (Class41.Class45.Class47 class2 in Class41.Class45.smethod_0(null))
			{
				if (class2.method_0().StartsWith("#A,A,", StringComparison.Ordinal))
				{
					Class41.Struct6 struct2 = new Class41.Struct6(class2.method_0().Substring(5));
					if (!(struct2.string_0 != @struct.string_0) && !(struct2.string_1 != @struct.string_1) && (!@struct.bool_2 || !(struct2.string_2 != @struct.string_2)))
					{
						if (!@struct.bool_0 || !(struct2.version_0 != @struct.version_0))
						{
							@class = class2;
							break;
						}
						flag = true;
					}
				}
			}
		}
		if (@class == null && !flag)
		{
			string s = @struct.method_0(false);
			string string_ = Convert.ToBase64String(Encoding.UTF8.GetBytes(s));
			using (IEnumerator<Class41.Class45.Class47> enumerator2 = Class41.Class45.smethod_0(string_).GetEnumerator())
			{
				if (enumerator2.MoveNext())
				{
					Class41.Class45.Class47 class3 = enumerator2.Current;
					@class = class3;
				}
			}
		}
		if (@class == null)
		{
			return null;
		}
		Dictionary<string, Assembly> dictionary_ = Class41.Class43.dictionary_0;
		Dictionary<string, Assembly> obj = dictionary_;
		Assembly assembly;
		lock (obj)
		{
			if (!dictionary_.TryGetValue(@class.string_2, out assembly))
			{
				byte[] array = Class41.Class45.smethod_1(@class);
				if (array == null)
				{
					return null;
				}
				bool flag2;
				if (!(flag2 = @class.bool_2))
				{
					try
					{
						assembly = Assembly.Load(array);
					}
					catch (FileLoadException)
					{
						flag2 = true;
					}
					catch (BadImageFormatException)
					{
						flag2 = true;
					}
				}
				if (flag2)
				{
					try
					{
						string assemblyFile = Class41.Class45.smethod_2(@class, true, array);
						assembly = Assembly.LoadFrom(assemblyFile);
					}
					catch
					{
					}
				}
				dictionary_.Add(@class.string_2, assembly);
			}
		}
		return assembly;
	}

	// Token: 0x060002B5 RID: 693 RVA: 0x00003F08 File Offset: 0x00002108
	private static int smethod_6(byte[] byte_0, int int_0)
	{
		return (int)byte_0[int_0] | (int)byte_0[int_0 + 1] << 24 | (int)byte_0[int_0 + 2] << 8 | (int)byte_0[int_0 + 3] << 16;
	}

	// Token: 0x060002B6 RID: 694 RVA: 0x00003F27 File Offset: 0x00002127
	private static int smethod_7(byte[] byte_0, int int_0)
	{
		return (int)byte_0[int_0] << 16 | (int)byte_0[int_0 + 1] << 8 | (int)byte_0[int_0 + 2] << 24 | (int)byte_0[int_0 + 3];
	}

	// Token: 0x060002B7 RID: 695 RVA: 0x0001E43C File Offset: 0x0001C63C
	private static byte[] smethod_8(byte[] byte_0)
	{
		int num = Class41.smethod_6(byte_0, 0);
		if (num != -1686991929)
		{
			throw new Exception();
		}
		int num2 = Class41.smethod_7(byte_0, 4);
		Stream stream = new DeflateStream(new MemoryStream(byte_0, false)
		{
			Position = 8L
		}, CompressionMode.Decompress);
		byte_0 = new byte[num2];
		int num3 = stream.Read(byte_0, 0, num2);
		if (num3 != num2)
		{
			throw new Exception();
		}
		return byte_0;
	}

	// Token: 0x060002B8 RID: 696 RVA: 0x0001E4A8 File Offset: 0x0001C6A8
	private static byte[] smethod_9(byte[] byte_0)
	{
		string s = "uVV3SRG3zklj18W1oZX5IdUM8FaKGBm3cLRysvQaf527HiVV2RzSyCKmC0qLbojTZ2uPjhjXjFEhAh14neTGVwJTQjrfLxCrVXLb";
		byte[] array = Convert.FromBase64String(s);
		Class72.smethod_1(array);
		Class41.Class44 @class = new Class41.Class44(array);
		int num = byte_0.Length;
		byte b = 0;
		byte b2 = 121;
		byte[] array2 = new byte[]
		{
			148,
			68,
			208,
			52,
			241,
			93,
			195,
			220
		};
		for (int num2 = 0; num2 != num; num2++)
		{
			if (b == 0)
			{
				b2 = @class.method_1();
			}
			b += 1;
			if (b == 32)
			{
				b = 0;
			}
			int num3 = num2;
			byte_0[num3] ^= (b2 ^ array2[num2 >> 2 & 3] ^ array2[(int)(b & 3)]);
		}
		return byte_0;
	}

	// Token: 0x060002B9 RID: 697
	[DllImport("kernel32.dll")]
	private static extern bool MoveFileEx(string string_0, string string_1, int int_0);

	// Token: 0x060002BA RID: 698 RVA: 0x0001E560 File Offset: 0x0001C760
	private static Assembly smethod_10(ResolveEventArgs resolveEventArgs_0)
	{
		Assembly requestingAssembly = resolveEventArgs_0.RequestingAssembly;
		if (requestingAssembly == null)
		{
			return null;
		}
		AssemblyName assemblyName = new AssemblyName(resolveEventArgs_0.Name);
		if ((assemblyName.Flags & AssemblyNameFlags.Retargetable) == AssemblyNameFlags.None)
		{
			return null;
		}
		if (requestingAssembly == typeof(Class41).Assembly)
		{
			return null;
		}
		bool flag = false;
		Dictionary<string, Assembly> dictionary_ = Class41.Class43.dictionary_0;
		Dictionary<string, Assembly> obj = dictionary_;
		lock (obj)
		{
			foreach (KeyValuePair<string, Assembly> keyValuePair in dictionary_)
			{
				if (keyValuePair.Value == requestingAssembly)
				{
					flag = true;
					break;
				}
			}
		}
		if (!flag)
		{
			return null;
		}
		return Assembly.Load(resolveEventArgs_0.Name);
	}

	// Token: 0x060002BB RID: 699 RVA: 0x00003F46 File Offset: 0x00002146
	private static void smethod_11()
	{
		Class41.smethod_12();
	}

	// Token: 0x060002BC RID: 700 RVA: 0x0001E62C File Offset: 0x0001C82C
	private static void smethod_12()
	{
		foreach (Class41.Class45.Class47 @class in Class41.Class45.smethod_0(null))
		{
			if (@class.method_0().StartsWith("#N,S,", StringComparison.Ordinal) && Class41.Class42.smethod_1(@class))
			{
				string text = Class41.Class45.smethod_2(@class, true, null);
				IntPtr value = Class41.LoadLibrary(text);
				if (value == IntPtr.Zero)
				{
					try
					{
						File.Delete(text);
					}
					catch
					{
					}
				}
			}
		}
	}

	// Token: 0x060002BD RID: 701
	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern IntPtr LoadLibrary(string string_0);

	// Token: 0x0200003C RID: 60
	private struct Struct6
	{
		// Token: 0x060002BE RID: 702 RVA: 0x0001E6C4 File Offset: 0x0001C8C4
		public Struct6(string string_3)
		{
			this = default(Class41.Struct6);
			this.version_0 = new Version();
			this.string_0 = string.Empty;
			foreach (string text in string_3.Split(new char[]
			{
				','
			}))
			{
				string text2 = text.Trim();
				if (text2.StartsWith("Version=", StringComparison.OrdinalIgnoreCase))
				{
					this.version_0 = new Version(text2.Substring("Version=".Length));
					this.bool_0 = true;
				}
				else if (text2.StartsWith("Culture=", StringComparison.OrdinalIgnoreCase))
				{
					this.string_1 = text2.Substring("Culture=".Length);
					if (this.string_1.Equals("neutral", StringComparison.OrdinalIgnoreCase))
					{
						this.string_1 = null;
					}
					this.bool_1 = true;
				}
				else if (text2.StartsWith("PublicKeyToken=", StringComparison.OrdinalIgnoreCase))
				{
					this.string_2 = text2.Substring("PublicKeyToken=".Length);
					if (this.string_2.Equals("null", StringComparison.OrdinalIgnoreCase))
					{
						this.string_2 = null;
					}
					this.bool_2 = true;
				}
				else
				{
					this.string_0 = text2;
				}
			}
		}

		// Token: 0x060002BF RID: 703 RVA: 0x0001E7EC File Offset: 0x0001C9EC
		public string method_0(bool bool_3)
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append(this.string_0);
			if (bool_3)
			{
				stringBuilder.Append(", VERSION=").Append(this.version_0);
			}
			stringBuilder.Append(", CULTURE=").Append(this.string_1 ?? "NEUTRAL").Append(", PUBLICKEYTOKEN=").Append(this.string_2 ?? "NULL");
			return stringBuilder.ToString();
		}

		// Token: 0x04000162 RID: 354
		public Version version_0;

		// Token: 0x04000163 RID: 355
		public bool bool_0;

		// Token: 0x04000164 RID: 356
		public string string_0;

		// Token: 0x04000165 RID: 357
		public string string_1;

		// Token: 0x04000166 RID: 358
		public bool bool_1;

		// Token: 0x04000167 RID: 359
		public string string_2;

		// Token: 0x04000168 RID: 360
		public bool bool_2;
	}

	// Token: 0x0200003D RID: 61
	private static class Class42
	{
		// Token: 0x060002C0 RID: 704 RVA: 0x0001E86C File Offset: 0x0001CA6C
		private static int smethod_0()
		{
			int size = IntPtr.Size;
			int result;
			if (size != 4)
			{
				if (size != 8)
				{
					result = 255;
				}
				else
				{
					result = 2;
				}
			}
			else
			{
				result = 1;
			}
			return result;
		}

		// Token: 0x060002C1 RID: 705 RVA: 0x0001E898 File Offset: 0x0001CA98
		public static bool smethod_1(Class41.Class45.Class47 class47_0)
		{
			if (class47_0.int_0 == 0)
			{
				return true;
			}
			int num = Class41.Class42.smethod_0();
			return (num & class47_0.int_0) != 0;
		}
	}

	// Token: 0x0200003E RID: 62
	private static class Class43
	{
		// Token: 0x04000169 RID: 361
		internal static readonly Dictionary<string, Assembly> dictionary_0 = new Dictionary<string, Assembly>(StringComparer.Ordinal);
	}

	// Token: 0x0200003F RID: 63
	private sealed class Class44
	{
		// Token: 0x060002C3 RID: 707 RVA: 0x0001E8C0 File Offset: 0x0001CAC0
		public Class44(byte[] byte_1)
		{
			int num = byte_1.Length;
			this.int_0 = 0;
			while (this.int_0 < 256)
			{
				this.byte_0[this.int_0] = (byte)this.int_0;
				this.int_0++;
			}
			this.int_1 = 0;
			this.int_0 = 0;
			while (this.int_0 < 256)
			{
				this.int_1 = (this.int_1 + (int)byte_1[this.int_0 % num] + (int)this.byte_0[this.int_0] & 255);
				this.method_0(this.int_0, this.int_1);
				this.int_0++;
			}
		}

		// Token: 0x060002C4 RID: 708 RVA: 0x0001E988 File Offset: 0x0001CB88
		private void method_0(int int_2, int int_3)
		{
			byte b = this.byte_0[int_2];
			this.byte_0[int_2] = this.byte_0[int_3];
			this.byte_0[int_3] = b;
		}

		// Token: 0x060002C5 RID: 709 RVA: 0x0001E9B8 File Offset: 0x0001CBB8
		public byte method_1()
		{
			this.int_0 = (this.int_0 + 1 & 255);
			this.int_1 = (this.int_1 + (int)this.byte_0[this.int_0] & 255);
			this.method_0(this.int_0, this.int_1);
			return this.byte_0[(int)(this.byte_0[this.int_0] + this.byte_0[this.int_1])];
		}

		// Token: 0x0400016A RID: 362
		private byte[] byte_0 = new byte[256];

		// Token: 0x0400016B RID: 363
		private int int_0;

		// Token: 0x0400016C RID: 364
		private int int_1;
	}

	// Token: 0x02000040 RID: 64
	private static class Class45
	{
		// Token: 0x060002C6 RID: 710 RVA: 0x00003F5E File Offset: 0x0000215E
		internal static IEnumerable<Class41.Class45.Class47> smethod_0(string string_0)
		{
			return new Class41.Class45.Class46(-2)
			{
				string_1 = string_0
			};
		}

		// Token: 0x060002C7 RID: 711 RVA: 0x0001EA30 File Offset: 0x0001CC30
		internal static byte[] smethod_1(Class41.Class45.Class47 class47_0)
		{
			Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(class47_0.string_2);
			if (manifestResourceStream == null)
			{
				return null;
			}
			int num = (int)manifestResourceStream.Length;
			byte[] array = new byte[num];
			manifestResourceStream.Read(array, 0, num);
			manifestResourceStream.Dispose();
			if (class47_0.bool_0)
			{
				array = Class41.smethod_9(array);
			}
			if (class47_0.bool_1)
			{
				array = Class41.smethod_8(array);
			}
			return array;
		}

		// Token: 0x060002C8 RID: 712 RVA: 0x0001EA94 File Offset: 0x0001CC94
		internal static string smethod_2(Class41.Class45.Class47 class47_0, bool bool_0, byte[] byte_0)
		{
			string text = Path.Combine(Path.GetTempPath(), class47_0.string_2);
			try
			{
				Directory.CreateDirectory(text);
			}
			catch
			{
				text = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
				text = Path.Combine(text, "clrldr");
				text = Path.Combine(text, class47_0.string_2);
				Directory.CreateDirectory(text);
				if (text == null)
				{
					throw;
				}
			}
			string text2 = Path.Combine(text, class47_0.method_1());
			if (!File.Exists(text2))
			{
				if (byte_0 == null)
				{
					byte_0 = Class41.Class45.smethod_1(class47_0);
				}
				File.WriteAllBytes(text2, byte_0);
				if (bool_0)
				{
					try
					{
						Class41.MoveFileEx(text2, null, 4);
						Class41.MoveFileEx(text, null, 4);
					}
					catch
					{
					}
				}
			}
			return text2;
		}

		// Token: 0x060002C9 RID: 713 RVA: 0x0001EB4C File Offset: 0x0001CD4C
		internal static void smethod_3(string string_0, bool bool_0)
		{
			bool flag = false;
			try
			{
				File.Delete(string_0);
				flag = true;
			}
			catch
			{
			}
			string directoryName = Path.GetDirectoryName(string_0);
			bool flag2 = false;
			try
			{
				Directory.Delete(directoryName);
				flag = true;
			}
			catch
			{
			}
			if (bool_0)
			{
				if (!flag)
				{
					try
					{
						Class41.MoveFileEx(string_0, null, 4);
					}
					catch
					{
					}
				}
				if (!flag2)
				{
					try
					{
						Class41.MoveFileEx(directoryName, null, 4);
					}
					catch
					{
					}
				}
			}
		}

		// Token: 0x02000041 RID: 65
		private sealed class Class46 : IEnumerable<Class41.Class45.Class47>, IEnumerator<Class41.Class45.Class47>, IEnumerable, IDisposable, IEnumerator
		{
			// Token: 0x060002CA RID: 714 RVA: 0x00003F6E File Offset: 0x0000216E
			[DebuggerHidden]
			public Class46(int int_3)
			{
				this.int_0 = int_3;
				this.int_1 = Thread.CurrentThread.ManagedThreadId;
			}

			// Token: 0x060002CB RID: 715 RVA: 0x00002F44 File Offset: 0x00001144
			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			// Token: 0x060002CC RID: 716 RVA: 0x0001EBD8 File Offset: 0x0001CDD8
			bool IEnumerator.MoveNext()
			{
				int num = this.int_0;
				if (num != 0)
				{
					if (num != 1)
					{
						return false;
					}
					this.int_0 = -1;
				}
				else
				{
					this.int_0 = -1;
					string text = "WlhfMkQ5MzA5QzQ5NEVFNDdBRjg2NDJFQkQxRDVFQjVGQTYsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49TlVMTA==,ab|c57e60c3147843f39af3ff714140bd0a,enhfMmQ5MzA5YzQ5NGVlNDdhZjg2NDJlYmQxZDVlYjVmYTYuZGxs,,Q0lSQ0xFX1BST0dSRVNTQkFSLCBDVUxUVVJFPU5FVVRSQUwsIFBVQkxJQ0tFWVRPS0VOPU5VTEw=,ab|4fe90a0540cd4887b332bf69fc976ec5,Y2lyY2xlX3Byb2dyZXNzYmFyLmRsbA==,,I04sUywxLGxpYm1wM2xhbWUuMzI=,ab|8d1aa588907342699c8c3309b3bc14e4,bGlibXAzbGFtZS4zMi5kbGw=,1,I04sUywyLGxpYm1wM2xhbWUuNjQ=,ab|1f0d3a86aa8447b1a0cfb6e296cc3a27,bGlibXAzbGFtZS42NC5kbGw=,2,TUlDUk9TT0ZULlRIUkVBRElORy5UQVNLUywgQ1VMVFVSRT1ORVVUUkFMLCBQVUJMSUNLRVlUT0tFTj1CMDNGNUY3RjExRDUwQTNB,ab|6264aee43400493ba5a83d12052207c6,TWljcm9zb2Z0LlRocmVhZGluZy5UYXNrcy5kbGw=,,I0EsQSxNSUNST1NPRlQuVEhSRUFESU5HLlRBU0tTLCBWRVJTSU9OPTEuMC4xMi4wLCBDVUxUVVJFPU5FVVRSQUwsIFBVQkxJQ0tFWVRPS0VOPUIwM0Y1RjdGMTFENTBBM0E=,ab|6264aee43400493ba5a83d12052207c6,TWljcm9zb2Z0LlRocmVhZGluZy5UYXNrcy5kbGw=,,TUlDUk9TT0ZULlRIUkVBRElORy5UQVNLUy5FWFRFTlNJT05TLkRFU0tUT1AsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49QjAzRjVGN0YxMUQ1MEEzQQ==,ab|42feaac15b0a4239a5d10a8a07159229,TWljcm9zb2Z0LlRocmVhZGluZy5UYXNrcy5FeHRlbnNpb25zLkRlc2t0b3AuZGxs,,I0EsQSxNSUNST1NPRlQuVEhSRUFESU5HLlRBU0tTLkVYVEVOU0lPTlMuREVTS1RPUCwgVkVSU0lPTj0xLjAuMTY4LjAsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49QjAzRjVGN0YxMUQ1MEEzQQ==,ab|42feaac15b0a4239a5d10a8a07159229,TWljcm9zb2Z0LlRocmVhZGluZy5UYXNrcy5FeHRlbnNpb25zLkRlc2t0b3AuZGxs,,TUlDUk9TT0ZULlRIUkVBRElORy5UQVNLUy5FWFRFTlNJT05TLCBDVUxUVVJFPU5FVVRSQUwsIFBVQkxJQ0tFWVRPS0VOPUIwM0Y1RjdGMTFENTBBM0E=,ab|71d08c0140074379823066654901e1e7,TWljcm9zb2Z0LlRocmVhZGluZy5UYXNrcy5FeHRlbnNpb25zLmRsbA==,,I0EsQSxNSUNST1NPRlQuVEhSRUFESU5HLlRBU0tTLkVYVEVOU0lPTlMsIFZFUlNJT049MS4wLjEyLjAsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49QjAzRjVGN0YxMUQ1MEEzQQ==,ab|71d08c0140074379823066654901e1e7,TWljcm9zb2Z0LlRocmVhZGluZy5UYXNrcy5FeHRlbnNpb25zLmRsbA==,,TUVUUk9GUkFNRVdPUksuREVTSUdOLCBDVUxUVVJFPU5FVVRSQUwsIFBVQkxJQ0tFWVRPS0VOPTVGOTFBODQ3NTlCRjU4NEE=,ab|f304bc27d16945e69aaab7369f4268a2,TWV0cm9GcmFtZXdvcmsuRGVzaWduLmRsbA==,,I0EsQSxNRVRST0ZSQU1FV09SSy5ERVNJR04sIFZFUlNJT049MS40LjAuMCwgQ1VMVFVSRT1ORVVUUkFMLCBQVUJMSUNLRVlUT0tFTj01RjkxQTg0NzU5QkY1ODRB,ab|f304bc27d16945e69aaab7369f4268a2,TWV0cm9GcmFtZXdvcmsuRGVzaWduLmRsbA==,,TUVUUk9GUkFNRVdPUkssIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49NUY5MUE4NDc1OUJGNTg0QQ==,ab|4387107a2694444190a0c5f5bb03847d,TWV0cm9GcmFtZXdvcmsuZGxs,,I0EsQSxNRVRST0ZSQU1FV09SSywgVkVSU0lPTj0xLjQuMC4wLCBDVUxUVVJFPU5FVVRSQUwsIFBVQkxJQ0tFWVRPS0VOPTVGOTFBODQ3NTlCRjU4NEE=,ab|4387107a2694444190a0c5f5bb03847d,TWV0cm9GcmFtZXdvcmsuZGxs,,TUVUUk9GUkFNRVdPUksuRk9OVFMsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49NUY5MUE4NDc1OUJGNTg0QQ==,ab|2631f76cfbaa4db2ba493ef6fe2636f0,TWV0cm9GcmFtZXdvcmsuRm9udHMuZGxs,,I0EsQSxNRVRST0ZSQU1FV09SSy5GT05UUywgVkVSU0lPTj0xLjQuMC4wLCBDVUxUVVJFPU5FVVRSQUwsIFBVQkxJQ0tFWVRPS0VOPTVGOTFBODQ3NTlCRjU4NEE=,ab|2631f76cfbaa4db2ba493ef6fe2636f0,TWV0cm9GcmFtZXdvcmsuRm9udHMuZGxs,,TkFVRElPLCBDVUxUVVJFPU5FVVRSQUwsIFBVQkxJQ0tFWVRPS0VOPU5VTEw=,ab|f41c36dc09d14bd6bb959faacedef4c6,TkF1ZGlvLmRsbA==,,TkFVRElPLkxBTUUsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49TlVMTA==,ab|e78009d2551c440f846b5e8c7755b88a,TkF1ZGlvLkxhbWUuZGxs,,TkVXVE9OU09GVC5KU09OLCBDVUxUVVJFPU5FVVRSQUwsIFBVQkxJQ0tFWVRPS0VOPTMwQUQ0RkU2QjJBNkFFRUQ=,ab|e203f266de75474da28adf801155f74b,TmV3dG9uc29mdC5Kc29uLmRsbA==,,I0EsQSxORVdUT05TT0ZULkpTT04sIFZFUlNJT049MTIuMC4wLjAsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49MzBBRDRGRTZCMkE2QUVFRA==,ab|e203f266de75474da28adf801155f74b,TmV3dG9uc29mdC5Kc29uLmRsbA==,,TklUTy5BU1lOQ0VYLkNPT1JESU5BVElPTiwgQ1VMVFVSRT1ORVVUUkFMLCBQVUJMSUNLRVlUT0tFTj1OVUxM,ab|3a57e4dcd6654ca1b36ee125a84dd3fb,Tml0by5Bc3luY0V4LkNvb3JkaW5hdGlvbi5kbGw=,,TklUTy5BU1lOQ0VYLklOVEVST1AuV0FJVEhBTkRMRVMsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49TlVMTA==,ab|7555edd2c31642ef843b7b3ef9e6b9ec,Tml0by5Bc3luY0V4LkludGVyb3AuV2FpdEhhbmRsZXMuZGxs,,TklUTy5BU1lOQ0VYLlRBU0tTLCBDVUxUVVJFPU5FVVRSQUwsIFBVQkxJQ0tFWVRPS0VOPU5VTEw=,ab|17dc047006e84c0183b68979edc51a60,Tml0by5Bc3luY0V4LlRhc2tzLmRsbA==,,TklUTy5BU1lOQ0VYLk9PUCwgQ1VMVFVSRT1ORVVUUkFMLCBQVUJMSUNLRVlUT0tFTj1OVUxM,ab|d4773934400f4f229d0722988dc2ed5b,Tml0by5Bc3luY0V4Lk9vcC5kbGw=,,TklUTy5DQU5DRUxMQVRJT04sIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49TlVMTA==,ab|1e6b7b67b43d4db08f35a6ad42609e06,Tml0by5DYW5jZWxsYXRpb24uZGxs,,TklUTy5DT0xMRUNUSU9OUy5ERVFVRSwgQ1VMVFVSRT1ORVVUUkFMLCBQVUJMSUNLRVlUT0tFTj1OVUxM,ab|d8e955afd7c349a1824b215312453c09,Tml0by5Db2xsZWN0aW9ucy5EZXF1ZS5kbGw=,,TklUTy5ESVNQT1NBQkxFUywgQ1VMVFVSRT1ORVVUUkFMLCBQVUJMSUNLRVlUT0tFTj1OVUxM,ab|875c35266c50425ebb1fe0f40218e1bf,Tml0by5EaXNwb3NhYmxlcy5kbGw=,,TklUTy5BU1lOQ0VYLkNPTlRFWFQsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49TlVMTA==,ab|7799fa9cff134036a1c0a04005e2fdc1,Tml0by5Bc3luY0V4LkNvbnRleHQuZGxs,,T0JKRUNUTElTVFZJRVcsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49QjFDNUJGNTgxNDgxQkNENA==,ab|2e51a42fc565402d99fc8e534ed5c95b,T2JqZWN0TGlzdFZpZXcuZGxs,,I0EsQSxPQkpFQ1RMSVNUVklFVywgVkVSU0lPTj0yLjkuMS4yNTQxMCwgQ1VMVFVSRT1ORVVUUkFMLCBQVUJMSUNLRVlUT0tFTj1CMUM1QkY1ODE0ODFCQ0Q0,ab|2e51a42fc565402d99fc8e534ed5c95b,T2JqZWN0TGlzdFZpZXcuZGxs,,UVJDT0RFUiwgQ1VMVFVSRT1ORVVUUkFMLCBQVUJMSUNLRVlUT0tFTj1OVUxM,ab|c1533f5cda9940c3b28c92ad6d3ba906,UVJDb2Rlci5kbGw=,,U1lTVEVNLkJVRkZFUlMsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49Q0M3QjEzRkZDRDJEREQ1MQ==,ab|116bb25c7c634e3cbecdedd0b9e1fe01,U3lzdGVtLkJ1ZmZlcnMuZGxs,,I0EsQSxTWVNURU0uQlVGRkVSUywgVkVSU0lPTj00LjAuMy4wLCBDVUxUVVJFPU5FVVRSQUwsIFBVQkxJQ0tFWVRPS0VOPUNDN0IxM0ZGQ0QyRERENTE=,ab|116bb25c7c634e3cbecdedd0b9e1fe01,U3lzdGVtLkJ1ZmZlcnMuZGxs,,U1lTVEVNLkRBVEEuSEFTSEZVTkNUSU9OLkNPUkUsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49ODBDOTI4OEUzOTRDMTMyMg==,ab|6845599238cf4d439dac9f185e98cde6,U3lzdGVtLkRhdGEuSGFzaEZ1bmN0aW9uLkNvcmUuZGxs,,I0EsQSxTWVNURU0uREFUQS5IQVNIRlVOQ1RJT04uQ09SRSwgVkVSU0lPTj0yLjAuMC4wLCBDVUxUVVJFPU5FVVRSQUwsIFBVQkxJQ0tFWVRPS0VOPTgwQzkyODhFMzk0QzEzMjI=,ab|6845599238cf4d439dac9f185e98cde6,U3lzdGVtLkRhdGEuSGFzaEZ1bmN0aW9uLkNvcmUuZGxs,,U1lTVEVNLkRBVEEuSEFTSEZVTkNUSU9OLklOVEVSRkFDRVMsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49ODBDOTI4OEUzOTRDMTMyMg==,ab|64381fcd12954710931ba2b7ad6ea742,U3lzdGVtLkRhdGEuSGFzaEZ1bmN0aW9uLkludGVyZmFjZXMuZGxs,,I0EsQSxTWVNURU0uREFUQS5IQVNIRlVOQ1RJT04uSU5URVJGQUNFUywgVkVSU0lPTj0yLjAuMC4wLCBDVUxUVVJFPU5FVVRSQUwsIFBVQkxJQ0tFWVRPS0VOPTgwQzkyODhFMzk0QzEzMjI=,ab|64381fcd12954710931ba2b7ad6ea742,U3lzdGVtLkRhdGEuSGFzaEZ1bmN0aW9uLkludGVyZmFjZXMuZGxs,,U1lTVEVNLk5VTUVSSUNTLlZFQ1RPUlMsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49QjAzRjVGN0YxMUQ1MEEzQQ==,ab|26f4684d6ccb4790907c74654660550c,U3lzdGVtLk51bWVyaWNzLlZlY3RvcnMuZGxs,,I0EsQSxTWVNURU0uTlVNRVJJQ1MuVkVDVE9SUywgVkVSU0lPTj00LjEuNC4wLCBDVUxUVVJFPU5FVVRSQUwsIFBVQkxJQ0tFWVRPS0VOPUIwM0Y1RjdGMTFENTBBM0E=,ab|26f4684d6ccb4790907c74654660550c,U3lzdGVtLk51bWVyaWNzLlZlY3RvcnMuZGxs,,V0lORk9STUFOSU1BVElPTiwgQ1VMVFVSRT1ORVVUUkFMLCBQVUJMSUNLRVlUT0tFTj0zMTBGRDA3QjI1REY3OUIz,ab|520640872efc477285f9eb2f15c8399e,V2luRm9ybUFuaW1hdGlvbi5kbGw=,,I0EsQSxXSU5GT1JNQU5JTUFUSU9OLCBWRVJTSU9OPTEuNi4wLjQsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49MzEwRkQwN0IyNURGNzlCMw==,ab|520640872efc477285f9eb2f15c8399e,V2luRm9ybUFuaW1hdGlvbi5kbGw=,,VklTVUFMUExVUywgQ1VMVFVSRT1ORVVUUkFMLCBQVUJMSUNLRVlUT0tFTj1OVUxM,ab|208c756db94949d491356be98c76cc9e,VmlzdWFsUGx1cy5kbGw=,,U0tJTlNPRlQuVklTVUFMU1RZTEVSLCBDVUxUVVJFPU5FVVRSQUwsIFBVQkxJQ0tFWVRPS0VOPTBGREE5RjQyM0UxRDk4MzA=,ab|16426fb571464b7fac3ab4297e185291,U2tpblNvZnQuVmlzdWFsU3R5bGVyLmRsbA==,,I0EsQSxTS0lOU09GVC5WSVNVQUxTVFlMRVIsIFZFUlNJT049Mi40LjAuMCwgQ1VMVFVSRT1ORVVUUkFMLCBQVUJMSUNLRVlUT0tFTj0wRkRBOUY0MjNFMUQ5ODMw,ab|16426fb571464b7fac3ab4297e185291,U2tpblNvZnQuVmlzdWFsU3R5bGVyLmRsbA==,,WkVST0lULkZSQU1FV09SSy5QUk9HUkVTUywgQ1VMVFVSRT1ORVVUUkFMLCBQVUJMSUNLRVlUT0tFTj1BMENFRTFCRkExMjBCOTUz,ab|af7ed5c0d14244eaa91a2a0bcb3608e5,WmVyb2l0LkZyYW1ld29yay5Qcm9ncmVzcy5kbGw=,,I0EsQSxaRVJPSVQuRlJBTUVXT1JLLlBST0dSRVNTLCBWRVJTSU9OPTEuMC4wLjAsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49QTBDRUUxQkZBMTIwQjk1Mw==,ab|af7ed5c0d14244eaa91a2a0bcb3608e5,WmVyb2l0LkZyYW1ld29yay5Qcm9ncmVzcy5kbGw=,,TUlIQVpVUEFOLkhUVFBUT1NPQ0tTNVBST1hZLCBDVUxUVVJFPU5FVVRSQUwsIFBVQkxJQ0tFWVRPS0VOPU5VTEw=,ab|2365d29c303040b1b48f06b3e9bb23c4,TWloYVp1cGFuLkh0dHBUb1NvY2tzNVByb3h5LmRsbA==,,Qk9VTkNZQ0FTVExFLkNSWVBUTywgQ1VMVFVSRT1ORVVUUkFMLCBQVUJMSUNLRVlUT0tFTj0wRTk5Mzc1RTU0NzY5OTQy,ab|c8f7ec7b41814ab7aceba45ae5a07509,Qm91bmN5Q2FzdGxlLkNyeXB0by5kbGw=,,I0EsQSxCT1VOQ1lDQVNUTEUuQ1JZUFRPLCBWRVJTSU9OPTEuOC42LjAsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49MEU5OTM3NUU1NDc2OTk0Mg==,ab|c8f7ec7b41814ab7aceba45ae5a07509,Qm91bmN5Q2FzdGxlLkNyeXB0by5kbGw=,";
					this.string_2 = text.Split(new char[]
					{
						','
					});
					if (this.string_0 == null && !Class41.smethod_0())
					{
						return false;
					}
					this.int_2 = 0;
					goto IL_91;
				}
				IL_83:
				this.int_2 += 4;
				IL_91:
				if (this.int_2 >= this.string_2.Length)
				{
					return false;
				}
				string text2 = this.string_2[this.int_2];
				if (this.string_0 != null && !text2.Equals(this.string_0, StringComparison.Ordinal))
				{
					goto IL_83;
				}
				Class41.Class45.Class47 @class = new Class41.Class45.Class47();
				@class.string_0 = text2;
				string text3 = this.string_2[this.int_2 + 1];
				int num2 = text3.IndexOf('|');
				if (num2 >= 0)
				{
					string text4 = text3.Substring(0, num2);
					text3 = text3.Substring(num2 + 1);
					@class.bool_0 = (text4.IndexOf('a') != -1);
					@class.bool_1 = (text4.IndexOf('b') != -1);
					@class.bool_2 = (text4.IndexOf('c') != -1);
				}
				@class.string_2 = text3;
				@class.string_3 = this.string_2[this.int_2 + 2];
				string text5 = this.string_2[this.int_2 + 3];
				if (text5.Length != 0)
				{
					@class.int_0 = int.Parse(text5, NumberStyles.AllowHexSpecifier, NumberFormatInfo.InvariantInfo);
				}
				this.class47_0 = @class;
				this.int_0 = 1;
				return true;
			}

			// Token: 0x170000B2 RID: 178
			// (get) Token: 0x060002CD RID: 717 RVA: 0x00003F8D File Offset: 0x0000218D
			Class41.Class45.Class47 IEnumerator<Class41.Class45.Class47>.Current
			{
				[DebuggerHidden]
				get
				{
					return this.class47_0;
				}
			}

			// Token: 0x060002CE RID: 718 RVA: 0x000038B4 File Offset: 0x00001AB4
			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}

			// Token: 0x170000B3 RID: 179
			// (get) Token: 0x060002CF RID: 719 RVA: 0x00003F8D File Offset: 0x0000218D
			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return this.class47_0;
				}
			}

			// Token: 0x060002D0 RID: 720 RVA: 0x0001ED60 File Offset: 0x0001CF60
			[DebuggerHidden]
			IEnumerator<Class41.Class45.Class47> IEnumerable<Class41.Class45.Class47>.GetEnumerator()
			{
				Class41.Class45.Class46 @class;
				if (this.int_0 == -2 && this.int_1 == Thread.CurrentThread.ManagedThreadId)
				{
					this.int_0 = 0;
					@class = this;
				}
				else
				{
					@class = new Class41.Class45.Class46(0);
				}
				@class.string_0 = this.string_1;
				return @class;
			}

			// Token: 0x060002D1 RID: 721 RVA: 0x00003F95 File Offset: 0x00002195
			[DebuggerHidden]
			IEnumerator IEnumerable.GetEnumerator()
			{
				return this.System.Collections.Generic.IEnumerable<Class41.Class45.Class47>.GetEnumerator();
			}

			// Token: 0x0400016D RID: 365
			private int int_0;

			// Token: 0x0400016E RID: 366
			private Class41.Class45.Class47 class47_0;

			// Token: 0x0400016F RID: 367
			private int int_1;

			// Token: 0x04000170 RID: 368
			private string string_0;

			// Token: 0x04000171 RID: 369
			public string string_1;

			// Token: 0x04000172 RID: 370
			private string[] string_2;

			// Token: 0x04000173 RID: 371
			private int int_2;
		}

		// Token: 0x02000042 RID: 66
		internal sealed class Class47
		{
			// Token: 0x060002D3 RID: 723 RVA: 0x0001EDA8 File Offset: 0x0001CFA8
			public string method_0()
			{
				if (this.string_1 == null)
				{
					byte[] array = Convert.FromBase64String(this.string_0);
					this.string_1 = Encoding.UTF8.GetString(array, 0, array.Length);
				}
				return this.string_1;
			}

			// Token: 0x060002D4 RID: 724 RVA: 0x0001EDE4 File Offset: 0x0001CFE4
			public string method_1()
			{
				if (this.string_4 == null)
				{
					byte[] array = Convert.FromBase64String(this.string_3);
					this.string_4 = Encoding.UTF8.GetString(array, 0, array.Length);
				}
				return this.string_4;
			}

			// Token: 0x04000174 RID: 372
			public string string_0;

			// Token: 0x04000175 RID: 373
			private string string_1;

			// Token: 0x04000176 RID: 374
			public string string_2;

			// Token: 0x04000177 RID: 375
			public bool bool_0;

			// Token: 0x04000178 RID: 376
			public bool bool_1;

			// Token: 0x04000179 RID: 377
			public bool bool_2;

			// Token: 0x0400017A RID: 378
			public bool bool_3;

			// Token: 0x0400017B RID: 379
			public bool bool_4;

			// Token: 0x0400017C RID: 380
			public string string_3;

			// Token: 0x0400017D RID: 381
			private string string_4;

			// Token: 0x0400017E RID: 382
			public int int_0;
		}
	}
}
