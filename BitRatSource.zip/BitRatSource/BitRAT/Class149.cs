﻿using System;
using System.IO;
using System.Runtime.CompilerServices;

// Token: 0x020001BC RID: 444
internal static class Class149
{
	// Token: 0x0600185F RID: 6239 RVA: 0x0000C5A9 File Offset: 0x0000A7A9
	[MethodImpl(MethodImplOptions.Synchronized)]
	public static Class4 smethod_0()
	{
		if (Class149.class16_0 == null)
		{
			Class149.class16_0 = new Class16();
		}
		return new Class4(Class149.class16_0);
	}

	// Token: 0x06001860 RID: 6240 RVA: 0x0000C5C6 File Offset: 0x0000A7C6
	public static Stream smethod_1()
	{
		if (Class149.stream_0 == null)
		{
			Class149.stream_0 = typeof(Class149).Assembly.GetManifestResourceStream("b323c5b50fd548968397f98385d62b0d");
		}
		return Class149.stream_0;
	}

	// Token: 0x04000912 RID: 2322
	private static Class16 class16_0;

	// Token: 0x04000913 RID: 2323
	[ThreadStatic]
	private static Stream stream_0;
}
