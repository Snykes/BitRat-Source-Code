﻿using System;
using System.Collections;
using System.Runtime.InteropServices;

// Token: 0x0200018C RID: 396
internal sealed class Class144
{
	// Token: 0x06001616 RID: 5654 RVA: 0x0000B49A File Offset: 0x0000969A
	private static T smethod_0<T>(string string_0)
	{
		return (T)((object)Activator.CreateInstance(Type.GetTypeFromProgID(string_0)));
	}

	// Token: 0x06001617 RID: 5655 RVA: 0x0000B4AC File Offset: 0x000096AC
	private static Class144.Interface11 smethod_1()
	{
		if (Class144.interface14_0 == null)
		{
			Class144.interface14_0 = Class144.smethod_0<Class144.Interface14>("HNetCfg.FwMgr");
		}
		return Class144.interface14_0.imethod_0().imethod_0();
	}

	// Token: 0x06001618 RID: 5656 RVA: 0x000A8314 File Offset: 0x000A6514
	internal static bool smethod_2()
	{
		try
		{
			return Class144.smethod_1().imethod_1();
		}
		catch (Exception ex)
		{
		}
		return false;
	}

	// Token: 0x06001619 RID: 5657 RVA: 0x000A8350 File Offset: 0x000A6550
	internal static bool smethod_3(string string_0)
	{
		try
		{
			return Class144.smethod_1().imethod_13().imethod_3(string_0).imethod_10();
		}
		catch (Exception ex)
		{
		}
		return false;
	}

	// Token: 0x0600161A RID: 5658 RVA: 0x000A8398 File Offset: 0x000A6598
	internal static bool smethod_4(string string_0, string string_1)
	{
		try
		{
			if (Class144.smethod_2() && Class144.smethod_3(string_1))
			{
				return true;
			}
			Class144.Interface12 @interface = Class144.smethod_0<Class144.Interface12>("HNetCfg.FwAuthorizedApplication");
			if (@interface != null)
			{
				@interface.imethod_1(string_0);
				@interface.imethod_3(string_1);
				@interface.imethod_7((Class144.Enum4)0);
				@interface.imethod_5((Class144.Enum5)2);
				@interface.imethod_11(true);
				Class144.smethod_1().imethod_13().imethod_1(@interface);
				return Class144.smethod_3(string_1);
			}
		}
		catch (Exception ex)
		{
		}
		return false;
	}

	// Token: 0x0400085B RID: 2139
	private static Class144.Interface14 interface14_0;

	// Token: 0x0200018D RID: 397
	[TypeLibType(4160)]
	[Guid("D46D2478-9AC9-4008-9DC7-5563CE5536CC")]
	internal interface Interface10
	{
		// Token: 0x0600161B RID: 5659
		[return: MarshalAs(UnmanagedType.Interface)]
		Class144.Interface11 imethod_0();

		// Token: 0x0600161C RID: 5660
		[return: MarshalAs(UnmanagedType.Interface)]
		Class144.Interface11 imethod_1([In] Class144.Enum7 enum7_0);
	}

	// Token: 0x0200018E RID: 398
	internal enum Enum4
	{

	}

	// Token: 0x0200018F RID: 399
	internal enum Enum5
	{

	}

	// Token: 0x02000190 RID: 400
	internal enum Enum6
	{

	}

	// Token: 0x02000191 RID: 401
	[Guid("174A0DDA-E9F9-449D-993B-21AB667CA456")]
	[TypeLibType(4160)]
	internal interface Interface11
	{
		// Token: 0x0600161D RID: 5661
		Class144.Enum7 imethod_0();

		// Token: 0x0600161E RID: 5662
		bool imethod_1();

		// Token: 0x0600161F RID: 5663
		void imethod_2(bool bool_0);

		// Token: 0x06001620 RID: 5664
		bool imethod_3();

		// Token: 0x06001621 RID: 5665
		void imethod_4(bool bool_0);

		// Token: 0x06001622 RID: 5666
		bool imethod_5();

		// Token: 0x06001623 RID: 5667
		void imethod_6(bool bool_0);

		// Token: 0x06001624 RID: 5668
		bool imethod_7();

		// Token: 0x06001625 RID: 5669
		void imethod_8(bool bool_0);

		// Token: 0x06001626 RID: 5670
		object imethod_9();

		// Token: 0x06001627 RID: 5671
		object imethod_10();

		// Token: 0x06001628 RID: 5672
		object imethod_11();

		// Token: 0x06001629 RID: 5673
		object imethod_12();

		// Token: 0x0600162A RID: 5674
		[return: MarshalAs(UnmanagedType.Interface)]
		Class144.Interface13 imethod_13();
	}

	// Token: 0x02000192 RID: 402
	[Guid("B5E64FFA-C2C5-444E-A301-FB5E00018050")]
	[TypeLibType(4160)]
	internal interface Interface12
	{
		// Token: 0x0600162B RID: 5675
		[return: MarshalAs(UnmanagedType.BStr)]
		string imethod_0();

		// Token: 0x0600162C RID: 5676
		void imethod_1([MarshalAs(UnmanagedType.BStr)] string string_0);

		// Token: 0x0600162D RID: 5677
		[return: MarshalAs(UnmanagedType.BStr)]
		string imethod_2();

		// Token: 0x0600162E RID: 5678
		void imethod_3([MarshalAs(UnmanagedType.BStr)] string string_0);

		// Token: 0x0600162F RID: 5679
		Class144.Enum5 imethod_4();

		// Token: 0x06001630 RID: 5680
		void imethod_5(Class144.Enum5 enum5_0);

		// Token: 0x06001631 RID: 5681
		Class144.Enum4 imethod_6();

		// Token: 0x06001632 RID: 5682
		void imethod_7(Class144.Enum4 enum4_0);

		// Token: 0x06001633 RID: 5683
		[return: MarshalAs(UnmanagedType.BStr)]
		string imethod_8();

		// Token: 0x06001634 RID: 5684
		void imethod_9([MarshalAs(UnmanagedType.BStr)] string string_0);

		// Token: 0x06001635 RID: 5685
		bool imethod_10();

		// Token: 0x06001636 RID: 5686
		void imethod_11(bool bool_0);
	}

	// Token: 0x02000193 RID: 403
	internal enum Enum7
	{

	}

	// Token: 0x02000194 RID: 404
	[TypeLibType(4160)]
	[Guid("644EFD52-CCF9-486C-97A2-39F352570B30")]
	internal interface Interface13 : IEnumerable
	{
		// Token: 0x06001637 RID: 5687
		int imethod_0();

		// Token: 0x06001638 RID: 5688
		void imethod_1([MarshalAs(UnmanagedType.Interface)] [In] Class144.Interface12 interface12_0);

		// Token: 0x06001639 RID: 5689
		void imethod_2([MarshalAs(UnmanagedType.BStr)] [In] string string_0);

		// Token: 0x0600163A RID: 5690
		[return: MarshalAs(UnmanagedType.Interface)]
		Class144.Interface12 imethod_3([MarshalAs(UnmanagedType.BStr)] [In] string string_0);
	}

	// Token: 0x02000195 RID: 405
	[TypeLibType(4160)]
	[Guid("F7898AF5-CAC4-4632-A2EC-DA06E5111AF2")]
	internal interface Interface14
	{
		// Token: 0x0600163B RID: 5691
		[return: MarshalAs(UnmanagedType.Interface)]
		Class144.Interface10 imethod_0();

		// Token: 0x0600163C RID: 5692
		Class144.Enum7 imethod_1();

		// Token: 0x0600163D RID: 5693
		void imethod_2();

		// Token: 0x0600163E RID: 5694
		void imethod_3([MarshalAs(UnmanagedType.BStr)] [In] string string_0, [In] Class144.Enum5 enum5_0, [In] int int_0, [MarshalAs(UnmanagedType.BStr)] [In] string string_1, [In] Class144.Enum6 enum6_0, [MarshalAs(UnmanagedType.Struct)] out object object_0, [MarshalAs(UnmanagedType.Struct)] out object object_1);

		// Token: 0x0600163F RID: 5695
		void imethod_4([In] Class144.Enum5 enum5_0, [MarshalAs(UnmanagedType.BStr)] [In] string string_0, [In] byte byte_0, [MarshalAs(UnmanagedType.Struct)] out object object_0, [MarshalAs(UnmanagedType.Struct)] out object object_1);
	}
}
