﻿// Token: 0x02000119 RID: 281
[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
public sealed partial class fAbout : global::System.Windows.Forms.Form
{
	// Token: 0x06000F53 RID: 3923 RVA: 0x00072358 File Offset: 0x00070558
	[global::System.Diagnostics.DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && this.icontainer_0 != null)
			{
				this.icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	// Token: 0x06000F54 RID: 3924 RVA: 0x00072398 File Offset: 0x00070598
	[global::System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::fAbout));
		this.vmethod_7(new global::System.Windows.Forms.Label());
		this.vmethod_9(new global::System.Windows.Forms.Label());
		this.vmethod_3(new global::System.Windows.Forms.PictureBox());
		this.vmethod_5(new global::System.Windows.Forms.PictureBox());
		this.vmethod_1(new global::System.Windows.Forms.PictureBox());
		this.vmethod_11(new global::System.Windows.Forms.Label());
		this.vmethod_13(new global::System.Windows.Forms.Label());
		this.vmethod_15(new global::System.Windows.Forms.Label());
		this.vmethod_17(new global::System.Windows.Forms.Label());
		this.vmethod_19(new global::System.Windows.Forms.PictureBox());
		this.vmethod_21(new global::System.Windows.Forms.Label());
		this.vmethod_23(new global::System.Windows.Forms.Label());
		this.vmethod_25(new global::System.Windows.Forms.Label());
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_2()).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_4()).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_0()).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_18()).BeginInit();
		base.SuspendLayout();
		this.vmethod_6().AutoSize = true;
		this.vmethod_6().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_6().ForeColor = global::System.Drawing.Color.RoyalBlue;
		this.vmethod_6().Location = new global::System.Drawing.Point(34, 158);
		this.vmethod_6().Name = "lblURL";
		this.vmethod_6().Size = new global::System.Drawing.Size(27, 13);
		this.vmethod_6().TabIndex = 51;
		this.vmethod_6().Text = "N/A";
		this.vmethod_8().AutoSize = true;
		this.vmethod_8().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_8().Location = new global::System.Drawing.Point(8, 158);
		this.vmethod_8().Name = "lblVisit";
		this.vmethod_8().Size = new global::System.Drawing.Size(32, 13);
		this.vmethod_8().TabIndex = 50;
		this.vmethod_8().Text = "Visit: ";
		this.vmethod_2().Image = global::Class131.smethod_50();
		this.vmethod_2().Location = new global::System.Drawing.Point(85, 158);
		this.vmethod_2().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_2().Name = "pbInfo";
		this.vmethod_2().Size = new global::System.Drawing.Size(15, 15);
		this.vmethod_2().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_2().TabIndex = 53;
		this.vmethod_2().TabStop = false;
		this.vmethod_4().Image = global::Class131.smethod_33();
		this.vmethod_4().Location = new global::System.Drawing.Point(66, 158);
		this.vmethod_4().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_4().Name = "pbCopy";
		this.vmethod_4().Size = new global::System.Drawing.Size(15, 15);
		this.vmethod_4().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_4().TabIndex = 52;
		this.vmethod_4().TabStop = false;
		this.vmethod_0().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_0().Image = global::Class131.smethod_30();
		this.vmethod_0().Location = new global::System.Drawing.Point(11, 11);
		this.vmethod_0().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_0().Name = "pbMainPort";
		this.vmethod_0().Size = new global::System.Drawing.Size(50, 50);
		this.vmethod_0().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_0().TabIndex = 41;
		this.vmethod_0().TabStop = false;
		this.vmethod_10().AutoSize = true;
		this.vmethod_10().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_10().Location = new global::System.Drawing.Point(141, 62);
		this.vmethod_10().Name = "lblCurrVersionPre";
		this.vmethod_10().Size = new global::System.Drawing.Size(45, 13);
		this.vmethod_10().TabIndex = 54;
		this.vmethod_10().Text = "Version:";
		this.vmethod_12().AutoSize = true;
		this.vmethod_12().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_12().Location = new global::System.Drawing.Point(121, 86);
		this.vmethod_12().Name = "lblHWIDPre";
		this.vmethod_12().Size = new global::System.Drawing.Size(65, 13);
		this.vmethod_12().TabIndex = 55;
		this.vmethod_12().Text = "Your HWID:";
		this.vmethod_14().AutoSize = true;
		this.vmethod_14().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_14().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_14().ForeColor = global::System.Drawing.Color.RoyalBlue;
		this.vmethod_14().Location = new global::System.Drawing.Point(185, 86);
		this.vmethod_14().Name = "lblHWID";
		this.vmethod_14().Size = new global::System.Drawing.Size(30, 13);
		this.vmethod_14().TabIndex = 56;
		this.vmethod_14().Text = "N/A";
		this.vmethod_16().AutoSize = true;
		this.vmethod_16().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_16().Location = new global::System.Drawing.Point(185, 62);
		this.vmethod_16().Name = "lblVersion";
		this.vmethod_16().Size = new global::System.Drawing.Size(27, 13);
		this.vmethod_16().TabIndex = 57;
		this.vmethod_16().Text = "N/A";
		this.vmethod_18().Image = global::Class131.smethod_33();
		this.vmethod_18().Location = new global::System.Drawing.Point(220, 85);
		this.vmethod_18().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_18().Name = "pbCopyHWID";
		this.vmethod_18().Size = new global::System.Drawing.Size(15, 15);
		this.vmethod_18().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_18().TabIndex = 58;
		this.vmethod_18().TabStop = false;
		this.vmethod_20().AutoSize = true;
		this.vmethod_20().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_20().Location = new global::System.Drawing.Point(108, 110);
		this.vmethod_20().Name = "Label1";
		this.vmethod_20().Size = new global::System.Drawing.Size(78, 13);
		this.vmethod_20().TabIndex = 59;
		this.vmethod_20().Text = "License status:";
		this.vmethod_22().AutoSize = true;
		this.vmethod_22().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_22().ForeColor = global::System.Drawing.Color.Green;
		this.vmethod_22().Location = new global::System.Drawing.Point(185, 110);
		this.vmethod_22().Name = "lblLicenseStatus";
		this.vmethod_22().Size = new global::System.Drawing.Size(27, 13);
		this.vmethod_22().TabIndex = 60;
		this.vmethod_22().Text = "N/A";
		this.vmethod_24().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_24().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_24().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_24().Location = new global::System.Drawing.Point(11, 11);
		this.vmethod_24().Name = "lblTitle";
		this.vmethod_24().Size = new global::System.Drawing.Size(360, 23);
		this.vmethod_24().TabIndex = 61;
		this.vmethod_24().Text = "About";
		this.vmethod_24().TextAlign = global::System.Drawing.ContentAlignment.TopCenter;
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = global::System.Drawing.SystemColors.AppWorkspace;
		base.ClientSize = new global::System.Drawing.Size(383, 179);
		base.Controls.Add(this.vmethod_22());
		base.Controls.Add(this.vmethod_20());
		base.Controls.Add(this.vmethod_18());
		base.Controls.Add(this.vmethod_16());
		base.Controls.Add(this.vmethod_14());
		base.Controls.Add(this.vmethod_12());
		base.Controls.Add(this.vmethod_10());
		base.Controls.Add(this.vmethod_2());
		base.Controls.Add(this.vmethod_4());
		base.Controls.Add(this.vmethod_6());
		base.Controls.Add(this.vmethod_8());
		base.Controls.Add(this.vmethod_0());
		base.Controls.Add(this.vmethod_24());
		this.DoubleBuffered = true;
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedToolWindow;
		base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "fAbout";
		base.Opacity = 0.0;
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterParent;
		this.Text = "About";
		base.TopMost = true;
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_2()).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_4()).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_0()).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_18()).EndInit();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x04000601 RID: 1537
	private global::System.ComponentModel.IContainer icontainer_0;
}
