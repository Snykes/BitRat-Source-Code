﻿using System;

// Token: 0x02000096 RID: 150
internal sealed class Class120 : Class94
{
	// Token: 0x06000497 RID: 1175 RVA: 0x00004E1B File Offset: 0x0000301B
	public ulong method_2()
	{
		return this.ulong_0;
	}

	// Token: 0x06000498 RID: 1176 RVA: 0x00004E23 File Offset: 0x00003023
	public void method_3(ulong ulong_1)
	{
		this.ulong_0 = ulong_1;
	}

	// Token: 0x06000499 RID: 1177 RVA: 0x00004E2C File Offset: 0x0000302C
	public override object vmethod_0()
	{
		return this.method_2();
	}

	// Token: 0x0600049A RID: 1178 RVA: 0x0002287C File Offset: 0x00020A7C
	public override void vmethod_1(object object_0)
	{
		if (object_0 is short)
		{
			this.method_3((ulong)((long)((short)object_0)));
			return;
		}
		if (object_0 is int)
		{
			this.method_3((ulong)((long)((int)object_0)));
			return;
		}
		if (object_0 is long)
		{
			this.method_3((ulong)((long)object_0));
			return;
		}
		if (object_0 is float)
		{
			this.method_3((ulong)((float)object_0));
			return;
		}
		if (object_0 is double)
		{
			this.method_3((ulong)((double)object_0));
			return;
		}
		this.method_3(Convert.ToUInt64(object_0));
	}

	// Token: 0x0600049B RID: 1179 RVA: 0x00004E39 File Offset: 0x00003039
	public override Class94 vmethod_4()
	{
		Class120 @class = new Class120();
		@class.method_3(this.ulong_0);
		@class.method_1(base.method_0());
		return @class;
	}

	// Token: 0x0600049C RID: 1180 RVA: 0x00004E58 File Offset: 0x00003058
	public override int vmethod_2()
	{
		return 19;
	}

	// Token: 0x0600049D RID: 1181 RVA: 0x00022904 File Offset: 0x00020B04
	public override Class94 vmethod_3(Class94 class94_0)
	{
		base.method_1(class94_0.method_0());
		switch (class94_0.vmethod_2())
		{
		case 0:
			this.method_3((ulong)((Class119)class94_0).method_2());
			return this;
		case 2:
			this.method_3((ulong)Convert.ToByte(((Class103)class94_0).method_2()));
			return this;
		case 4:
			this.method_3(Convert.ToUInt64(((Class102)class94_0).method_2()));
			return this;
		case 7:
			this.method_3((ulong)((long)((Class118)class94_0).method_2()));
			return this;
		case 8:
			this.method_3((ulong)((Class100)class94_0).method_2());
			return this;
		case 9:
			this.method_3((ulong)((long)((Class115)class94_0).method_2()));
			return this;
		case 10:
			this.method_3((ulong)((Class114)class94_0).method_2());
			return this;
		case 11:
			this.method_3((ulong)((Class99)class94_0).method_2());
			return this;
		case 14:
			this.method_3((ulong)((long)((Class105)class94_0).method_2()));
			return this;
		case 15:
			this.method_3((ulong)((long)((Class101)class94_0).method_2()));
			return this;
		case 17:
			this.method_3((ulong)((Class117)class94_0).method_2());
			return this;
		case 19:
			this.method_3(((Class120)class94_0).method_2());
			return this;
		case 21:
			this.method_3((ulong)((Class104)class94_0).method_2());
			return this;
		case 22:
			this.method_3((ulong)((Class121)class94_0).method_2());
			return this;
		case 24:
			this.method_3(Convert.ToUInt64(((Class98)class94_0).method_2()));
			return this;
		}
		throw new ArgumentOutOfRangeException();
	}

	// Token: 0x040001E4 RID: 484
	private ulong ulong_0;
}
