﻿using System;

// Token: 0x0200004E RID: 78
internal sealed class Class35 : Class34
{
	// Token: 0x0600030B RID: 779 RVA: 0x00004177 File Offset: 0x00002377
	public string method_0()
	{
		return this.string_0;
	}

	// Token: 0x0600030C RID: 780 RVA: 0x0000417F File Offset: 0x0000237F
	public void method_1(string string_1)
	{
		this.string_0 = string_1;
	}

	// Token: 0x0600030D RID: 781 RVA: 0x00004094 File Offset: 0x00002294
	public override byte vmethod_0()
	{
		return 2;
	}

	// Token: 0x0400018F RID: 399
	private string string_0;
}
