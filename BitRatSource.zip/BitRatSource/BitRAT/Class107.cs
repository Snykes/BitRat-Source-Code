﻿using System;
using System.Reflection;

// Token: 0x02000043 RID: 67
internal sealed class Class107 : Class106
{
	// Token: 0x060002D5 RID: 725 RVA: 0x00003F9D File Offset: 0x0000219D
	public Class107(FieldInfo fieldInfo_1, object object_1)
	{
		this.method_5(fieldInfo_1);
		this.method_3(object_1);
	}

	// Token: 0x060002D6 RID: 726 RVA: 0x00003FB3 File Offset: 0x000021B3
	public Class107(FieldInfo fieldInfo_1, object object_1, Class106 class106_1) : this(fieldInfo_1, object_1)
	{
		this.method_7(class106_1);
	}

	// Token: 0x060002D7 RID: 727 RVA: 0x00003FC4 File Offset: 0x000021C4
	private Class107()
	{
	}

	// Token: 0x060002D8 RID: 728 RVA: 0x00003FCC File Offset: 0x000021CC
	public object method_2()
	{
		return this.object_0;
	}

	// Token: 0x060002D9 RID: 729 RVA: 0x00003FD4 File Offset: 0x000021D4
	private void method_3(object object_1)
	{
		this.object_0 = object_1;
	}

	// Token: 0x060002DA RID: 730 RVA: 0x00003FDD File Offset: 0x000021DD
	public FieldInfo method_4()
	{
		return this.fieldInfo_0;
	}

	// Token: 0x060002DB RID: 731 RVA: 0x00003FE5 File Offset: 0x000021E5
	private void method_5(FieldInfo fieldInfo_1)
	{
		this.fieldInfo_0 = fieldInfo_1;
	}

	// Token: 0x060002DC RID: 732 RVA: 0x00003FEE File Offset: 0x000021EE
	public Class106 method_6()
	{
		return this.class106_0;
	}

	// Token: 0x060002DD RID: 733 RVA: 0x00003FF6 File Offset: 0x000021F6
	private void method_7(Class106 class106_1)
	{
		this.class106_0 = class106_1;
	}

	// Token: 0x060002DE RID: 734 RVA: 0x00003FFF File Offset: 0x000021FF
	public override int vmethod_2()
	{
		return 18;
	}

	// Token: 0x060002DF RID: 735 RVA: 0x0001EE20 File Offset: 0x0001D020
	public override Class94 vmethod_3(Class94 class94_0)
	{
		base.method_1(class94_0.method_0());
		int num = class94_0.vmethod_2();
		if (num == 18)
		{
			Class107 @class = (Class107)class94_0;
			this.method_3(@class.method_2());
			this.method_5(@class.method_4());
			return this;
		}
		throw new ArgumentOutOfRangeException();
	}

	// Token: 0x060002E0 RID: 736 RVA: 0x00004003 File Offset: 0x00002203
	public override Class94 vmethod_4()
	{
		Class107 @class = new Class107();
		@class.method_3(this.method_2());
		@class.method_5(this.method_4());
		@class.method_7(this.method_6());
		@class.method_1(base.method_0());
		return @class;
	}

	// Token: 0x0400017F RID: 383
	private object object_0;

	// Token: 0x04000180 RID: 384
	private FieldInfo fieldInfo_0;

	// Token: 0x04000181 RID: 385
	private Class106 class106_0;
}
