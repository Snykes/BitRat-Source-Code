﻿using System;
using System.Threading;

// Token: 0x0200008A RID: 138
internal struct Struct16
{
	// Token: 0x06000434 RID: 1076 RVA: 0x00004AC8 File Offset: 0x00002CC8
	public Struct16(string string_0)
	{
		this.nullable_0 = new int?(Class57.smethod_0(string_0));
	}

	// Token: 0x06000435 RID: 1077 RVA: 0x00004ADB File Offset: 0x00002CDB
	public int method_0()
	{
		return Class57.smethod_2(this.nullable_0);
	}

	// Token: 0x06000436 RID: 1078 RVA: 0x00004AE8 File Offset: 0x00002CE8
	public void method_1(int int_0)
	{
		this.nullable_0 = new int?(Class57.smethod_1(int_0));
	}

	// Token: 0x06000437 RID: 1079 RVA: 0x00004AFB File Offset: 0x00002CFB
	public void method_2()
	{
		this.nullable_0 = new int?(Class57.smethod_1(0));
	}

	// Token: 0x06000438 RID: 1080 RVA: 0x00021D28 File Offset: 0x0001FF28
	public int method_3()
	{
		return Class57.smethod_2(this.nullable_0).GetHashCode();
	}

	// Token: 0x06000439 RID: 1081 RVA: 0x00021D48 File Offset: 0x0001FF48
	public bool method_4(int int_0)
	{
		return Class57.smethod_2(this.nullable_0).Equals(int_0);
	}

	// Token: 0x0600043A RID: 1082 RVA: 0x00021D6C File Offset: 0x0001FF6C
	public bool method_5(object object_0)
	{
		return Class57.smethod_2(this.nullable_0).Equals(object_0);
	}

	// Token: 0x0600043B RID: 1083 RVA: 0x00021D90 File Offset: 0x0001FF90
	public int method_6(int int_0)
	{
		return Class57.smethod_2(this.nullable_0).CompareTo(int_0);
	}

	// Token: 0x0600043C RID: 1084 RVA: 0x00021DB4 File Offset: 0x0001FFB4
	public int method_7(object object_0)
	{
		return Class57.smethod_2(this.nullable_0).CompareTo(object_0);
	}

	// Token: 0x0600043D RID: 1085 RVA: 0x000047B6 File Offset: 0x000029B6
	public TypeCode method_8()
	{
		return TypeCode.Int32;
	}

	// Token: 0x0600043E RID: 1086 RVA: 0x00021DD8 File Offset: 0x0001FFD8
	public string method_9()
	{
		return Class57.smethod_2(this.nullable_0).ToString();
	}

	// Token: 0x0600043F RID: 1087 RVA: 0x00021DF8 File Offset: 0x0001FFF8
	public string method_10(string string_0)
	{
		return Class57.smethod_2(this.nullable_0).ToString(string_0);
	}

	// Token: 0x06000440 RID: 1088 RVA: 0x00021E1C File Offset: 0x0002001C
	public string method_11(IFormatProvider iformatProvider_0)
	{
		return Class57.smethod_2(this.nullable_0).ToString(iformatProvider_0);
	}

	// Token: 0x06000441 RID: 1089 RVA: 0x00021E40 File Offset: 0x00020040
	public string method_12(string string_0, IFormatProvider iformatProvider_0)
	{
		return Class57.smethod_2(this.nullable_0).ToString(string_0, iformatProvider_0);
	}

	// Token: 0x06000442 RID: 1090 RVA: 0x00004B0E File Offset: 0x00002D0E
	public int method_13()
	{
		int result = Class57.smethod_2(this.nullable_0);
		Thread.MemoryBarrier();
		return result;
	}

	// Token: 0x06000443 RID: 1091 RVA: 0x00004B20 File Offset: 0x00002D20
	public void method_14(int int_0)
	{
		Thread.MemoryBarrier();
		this.nullable_0 = new int?(Class57.smethod_1(int_0));
	}

	// Token: 0x06000444 RID: 1092 RVA: 0x00021E64 File Offset: 0x00020064
	public int method_15()
	{
		object object_ = Class82.object_0;
		int result;
		lock (object_)
		{
			int num = Class57.smethod_2(this.nullable_0) + 1;
			this.nullable_0 = new int?(Class57.smethod_1(num));
			result = num;
		}
		return result;
	}

	// Token: 0x06000445 RID: 1093 RVA: 0x00021EC0 File Offset: 0x000200C0
	public int method_16()
	{
		object object_ = Class82.object_0;
		int result;
		lock (object_)
		{
			int num = Class57.smethod_2(this.nullable_0) - 1;
			this.nullable_0 = new int?(Class57.smethod_1(num));
			result = num;
		}
		return result;
	}

	// Token: 0x06000446 RID: 1094 RVA: 0x00021F1C File Offset: 0x0002011C
	public int method_17(int int_0)
	{
		object object_ = Class82.object_0;
		int result;
		lock (object_)
		{
			int num = Class57.smethod_2(this.nullable_0) + int_0;
			this.nullable_0 = new int?(Class57.smethod_1(num));
			result = num;
		}
		return result;
	}

	// Token: 0x06000447 RID: 1095 RVA: 0x00021F78 File Offset: 0x00020178
	public int method_18(int int_0)
	{
		object object_ = Class82.object_0;
		int result;
		lock (object_)
		{
			int num = Class57.smethod_2(this.nullable_0);
			this.nullable_0 = new int?(Class57.smethod_1(int_0));
			result = num;
		}
		return result;
	}

	// Token: 0x06000448 RID: 1096 RVA: 0x00021FD0 File Offset: 0x000201D0
	public int method_19(int int_0, int int_1)
	{
		object object_ = Class82.object_0;
		int result;
		lock (object_)
		{
			int num = Class57.smethod_2(this.nullable_0);
			if (num == int_1)
			{
				this.nullable_0 = new int?(Class57.smethod_1(int_0));
			}
			result = num;
		}
		return result;
	}

	// Token: 0x040001D1 RID: 465
	private int? nullable_0;
}
