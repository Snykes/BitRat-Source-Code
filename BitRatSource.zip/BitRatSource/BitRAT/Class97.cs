﻿using System;
using System.Reflection;

// Token: 0x02000018 RID: 24
internal sealed class Class97 : Class94
{
	// Token: 0x060001BC RID: 444 RVA: 0x00003788 File Offset: 0x00001988
	public MethodBase method_2()
	{
		return this.methodBase_0;
	}

	// Token: 0x060001BD RID: 445 RVA: 0x00003790 File Offset: 0x00001990
	public void method_3(MethodBase methodBase_1)
	{
		this.methodBase_0 = methodBase_1;
	}

	// Token: 0x060001BE RID: 446 RVA: 0x0001A748 File Offset: 0x00018948
	public IntPtr method_4()
	{
		return this.method_2().MethodHandle.GetFunctionPointer();
	}

	// Token: 0x060001BF RID: 447 RVA: 0x00003799 File Offset: 0x00001999
	public override object vmethod_0()
	{
		return this.method_2();
	}

	// Token: 0x060001C0 RID: 448 RVA: 0x000037A1 File Offset: 0x000019A1
	public override void vmethod_1(object object_0)
	{
		this.method_3((MethodBase)object_0);
	}

	// Token: 0x060001C1 RID: 449 RVA: 0x000037AF File Offset: 0x000019AF
	public override int vmethod_2()
	{
		return 23;
	}

	// Token: 0x060001C2 RID: 450 RVA: 0x0001A768 File Offset: 0x00018968
	public override Class94 vmethod_3(Class94 class94_0)
	{
		base.method_1(class94_0.method_0());
		int num = class94_0.vmethod_2();
		if (num == 23)
		{
			this.method_3(((Class97)class94_0).method_2());
			return this;
		}
		throw new ArgumentOutOfRangeException();
	}

	// Token: 0x060001C3 RID: 451 RVA: 0x000037B3 File Offset: 0x000019B3
	public override Class94 vmethod_4()
	{
		Class97 @class = new Class97();
		@class.method_3(this.methodBase_0);
		@class.method_1(base.method_0());
		return @class;
	}

	// Token: 0x0400004B RID: 75
	private MethodBase methodBase_0;
}
