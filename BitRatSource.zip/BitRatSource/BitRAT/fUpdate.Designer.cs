﻿// Token: 0x020000E0 RID: 224
[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
public sealed partial class fUpdate : global::System.Windows.Forms.Form
{
	// Token: 0x06000A86 RID: 2694 RVA: 0x00052E14 File Offset: 0x00051014
	[global::System.Diagnostics.DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && this.icontainer_0 != null)
			{
				this.icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	// Token: 0x06000A87 RID: 2695 RVA: 0x00052E54 File Offset: 0x00051054
	[global::System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		this.vmethod_1(new global::System.ComponentModel.BackgroundWorker());
		this.vmethod_3(new global::System.Windows.Forms.Label());
		this.vmethod_7(new global::System.Windows.Forms.Label());
		this.vmethod_9(new global::System.Windows.Forms.Label());
		this.vmethod_11(new global::System.Windows.Forms.Label());
		this.vmethod_13(new global::System.Windows.Forms.Label());
		this.vmethod_15(new global::System.Windows.Forms.RichTextBox());
		this.vmethod_17(new global::VisualPlus.Toolkit.Controls.Interactivity.VisualButton());
		this.vmethod_19(new global::System.Windows.Forms.Label());
		this.vmethod_21(new global::System.Windows.Forms.Label());
		this.vmethod_27(new global::System.Windows.Forms.StatusStrip());
		this.vmethod_29(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_31(new global::System.ComponentModel.BackgroundWorker());
		this.vmethod_25(new global::System.Windows.Forms.PictureBox());
		this.vmethod_23(new global::System.Windows.Forms.PictureBox());
		this.vmethod_5(new global::System.Windows.Forms.PictureBox());
		this.vmethod_33(new global::System.Windows.Forms.PictureBox());
		this.vmethod_35(new global::System.Windows.Forms.Label());
		this.vmethod_37(new global::System.Windows.Forms.Label());
		this.vmethod_39(new global::System.Windows.Forms.Label());
		this.vmethod_26().SuspendLayout();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_24()).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_22()).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_4()).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_32()).BeginInit();
		base.SuspendLayout();
		this.vmethod_2().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_2().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_2().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_2().Location = new global::System.Drawing.Point(3, 9);
		this.vmethod_2().Name = "lblTitle";
		this.vmethod_2().Size = new global::System.Drawing.Size(416, 23);
		this.vmethod_2().TabIndex = 0;
		this.vmethod_2().Text = "BitRAT - New update available";
		this.vmethod_2().TextAlign = global::System.Drawing.ContentAlignment.TopCenter;
		this.vmethod_6().AutoSize = true;
		this.vmethod_6().Location = new global::System.Drawing.Point(12, 80);
		this.vmethod_6().Name = "lblCurrVersion";
		this.vmethod_6().Size = new global::System.Drawing.Size(104, 13);
		this.vmethod_6().TabIndex = 21;
		this.vmethod_6().Text = "Current version: N/A";
		this.vmethod_8().AutoSize = true;
		this.vmethod_8().Location = new global::System.Drawing.Point(23, 58);
		this.vmethod_8().Name = "lblNewVersion";
		this.vmethod_8().Size = new global::System.Drawing.Size(69, 13);
		this.vmethod_8().TabIndex = 22;
		this.vmethod_8().Text = "New version:";
		this.vmethod_10().AutoSize = true;
		this.vmethod_10().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_10().ForeColor = global::System.Drawing.Color.LimeGreen;
		this.vmethod_10().Location = new global::System.Drawing.Point(91, 58);
		this.vmethod_10().Name = "lblVersion";
		this.vmethod_10().Size = new global::System.Drawing.Size(30, 13);
		this.vmethod_10().TabIndex = 23;
		this.vmethod_10().Text = "N/A";
		this.vmethod_12().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_12().Location = new global::System.Drawing.Point(3, 120);
		this.vmethod_12().Name = "lblRelTitle";
		this.vmethod_12().Size = new global::System.Drawing.Size(416, 13);
		this.vmethod_12().TabIndex = 24;
		this.vmethod_12().Text = "What's new";
		this.vmethod_12().TextAlign = global::System.Drawing.ContentAlignment.TopCenter;
		this.vmethod_14().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_14().BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
		this.vmethod_14().Location = new global::System.Drawing.Point(2, 136);
		this.vmethod_14().Name = "rtNews";
		this.vmethod_14().ScrollBars = global::System.Windows.Forms.RichTextBoxScrollBars.Vertical;
		this.vmethod_14().Size = new global::System.Drawing.Size(420, 329);
		this.vmethod_14().TabIndex = 25;
		this.vmethod_14().Text = string.Empty;
		this.vmethod_16().BackColorState.Disabled = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_16().BackColorState.Enabled = global::System.Drawing.Color.FromArgb(220, 220, 220);
		this.vmethod_16().BackColorState.Hover = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_16().BackColorState.Pressed = global::System.Drawing.Color.FromArgb(192, 192, 192);
		this.vmethod_16().Border.Color = global::System.Drawing.Color.FromArgb(180, 180, 180);
		this.vmethod_16().Border.HoverColor = global::System.Drawing.Color.FromArgb(120, 183, 230);
		this.vmethod_16().Border.HoverVisible = true;
		this.vmethod_16().Border.Rounding = 6;
		this.vmethod_16().Border.Thickness = 1;
		this.vmethod_16().Border.Type = 1;
		this.vmethod_16().Border.Visible = true;
		this.vmethod_16().DialogResult = global::System.Windows.Forms.DialogResult.None;
		this.vmethod_16().ForeColor = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_16().Image = null;
		this.vmethod_16().Location = new global::System.Drawing.Point(2, 471);
		this.vmethod_16().MouseState = 0;
		this.vmethod_16().Name = "btnDownload";
		this.vmethod_16().Size = new global::System.Drawing.Size(81, 19);
		this.vmethod_16().TabIndex = 45;
		this.vmethod_16().Text = "Download";
		this.vmethod_16().TextImageRelation = global::System.Windows.Forms.TextImageRelation.Overlay;
		this.vmethod_16().TextStyle.Disabled = global::System.Drawing.Color.FromArgb(131, 129, 129);
		this.vmethod_16().TextStyle.Enabled = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_16().TextStyle.Hover = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_16().TextStyle.Pressed = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_16().TextStyle.TextAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_16().TextStyle.TextLineAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_16().TextStyle.TextRenderingHint = global::System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
		this.vmethod_18().AutoSize = true;
		this.vmethod_18().Location = new global::System.Drawing.Point(88, 474);
		this.vmethod_18().Name = "lblVisit";
		this.vmethod_18().Size = new global::System.Drawing.Size(45, 13);
		this.vmethod_18().TabIndex = 46;
		this.vmethod_18().Text = "Or visit: ";
		this.vmethod_20().AutoSize = true;
		this.vmethod_20().ForeColor = global::System.Drawing.Color.RoyalBlue;
		this.vmethod_20().Location = new global::System.Drawing.Point(129, 474);
		this.vmethod_20().Name = "lblURL";
		this.vmethod_20().Size = new global::System.Drawing.Size(27, 13);
		this.vmethod_20().TabIndex = 47;
		this.vmethod_20().Text = "N/A";
		this.vmethod_26().AutoSize = false;
		this.vmethod_26().BackColor = global::System.Drawing.Color.FromArgb(235, 237, 239);
		this.vmethod_26().ImageScalingSize = new global::System.Drawing.Size(28, 28);
		this.vmethod_26().Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_28()
		});
		this.vmethod_26().Location = new global::System.Drawing.Point(0, 494);
		this.vmethod_26().Name = "ssMain";
		this.vmethod_26().Padding = new global::System.Windows.Forms.Padding(1, 0, 7, 0);
		this.vmethod_26().Size = new global::System.Drawing.Size(423, 19);
		this.vmethod_26().SizingGrip = false;
		this.vmethod_26().Stretch = false;
		this.vmethod_26().TabIndex = 109;
		this.vmethod_26().Text = "stStatus";
		this.vmethod_28().AutoSize = false;
		this.vmethod_28().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_28().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_28().Margin = new global::System.Windows.Forms.Padding(0, 3, -6, 0);
		this.vmethod_28().Name = "tsStatus";
		this.vmethod_28().Size = new global::System.Drawing.Size(421, 16);
		this.vmethod_28().Spring = true;
		this.vmethod_28().Text = "Status: N/A";
		this.vmethod_28().TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
		this.vmethod_30().WorkerSupportsCancellation = true;
		this.vmethod_24().Location = new global::System.Drawing.Point(180, 474);
		this.vmethod_24().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_24().Name = "pbInfo";
		this.vmethod_24().Size = new global::System.Drawing.Size(15, 15);
		this.vmethod_24().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_24().TabIndex = 49;
		this.vmethod_24().TabStop = false;
		this.vmethod_22().Location = new global::System.Drawing.Point(161, 474);
		this.vmethod_22().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_22().Name = "pbCopy";
		this.vmethod_22().Size = new global::System.Drawing.Size(15, 15);
		this.vmethod_22().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_22().TabIndex = 48;
		this.vmethod_22().TabStop = false;
		this.vmethod_4().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_4().Location = new global::System.Drawing.Point(395, 5);
		this.vmethod_4().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_4().Name = "pIcon";
		this.vmethod_4().Size = new global::System.Drawing.Size(24, 24);
		this.vmethod_4().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_4().TabIndex = 20;
		this.vmethod_4().TabStop = false;
		this.vmethod_32().Location = new global::System.Drawing.Point(124, 57);
		this.vmethod_32().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_32().Name = "pbWarning";
		this.vmethod_32().Size = new global::System.Drawing.Size(15, 15);
		this.vmethod_32().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_32().TabIndex = 110;
		this.vmethod_32().TabStop = false;
		this.vmethod_32().Visible = false;
		this.vmethod_34().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_34().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_34().ForeColor = global::System.Drawing.Color.RoyalBlue;
		this.vmethod_34().Location = new global::System.Drawing.Point(103, 30);
		this.vmethod_34().Name = "lblMandatory";
		this.vmethod_34().Size = new global::System.Drawing.Size(213, 13);
		this.vmethod_34().TabIndex = 111;
		this.vmethod_34().Text = "This update is mandatory";
		this.vmethod_34().TextAlign = global::System.Drawing.ContentAlignment.TopCenter;
		this.vmethod_34().Visible = false;
		this.vmethod_36().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_36().AutoSize = true;
		this.vmethod_36().Location = new global::System.Drawing.Point(271, 80);
		this.vmethod_36().Name = "lblRARtitle";
		this.vmethod_36().Size = new global::System.Drawing.Size(82, 13);
		this.vmethod_36().TabIndex = 112;
		this.vmethod_36().Text = "RAR-Password:";
		this.vmethod_36().TextAlign = global::System.Drawing.ContentAlignment.TopRight;
		this.vmethod_38().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_38().AutoSize = true;
		this.vmethod_38().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_38().ForeColor = global::System.Drawing.Color.Black;
		this.vmethod_38().Location = new global::System.Drawing.Point(352, 80);
		this.vmethod_38().Name = "lblRARPassword";
		this.vmethod_38().Size = new global::System.Drawing.Size(58, 13);
		this.vmethod_38().TabIndex = 113;
		this.vmethod_38().Text = "unknown";
		this.vmethod_38().TextAlign = global::System.Drawing.ContentAlignment.TopRight;
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = global::System.Drawing.SystemColors.AppWorkspace;
		base.ClientSize = new global::System.Drawing.Size(423, 513);
		base.Controls.Add(this.vmethod_38());
		base.Controls.Add(this.vmethod_36());
		base.Controls.Add(this.vmethod_34());
		base.Controls.Add(this.vmethod_32());
		base.Controls.Add(this.vmethod_26());
		base.Controls.Add(this.vmethod_24());
		base.Controls.Add(this.vmethod_22());
		base.Controls.Add(this.vmethod_20());
		base.Controls.Add(this.vmethod_18());
		base.Controls.Add(this.vmethod_16());
		base.Controls.Add(this.vmethod_14());
		base.Controls.Add(this.vmethod_12());
		base.Controls.Add(this.vmethod_10());
		base.Controls.Add(this.vmethod_8());
		base.Controls.Add(this.vmethod_6());
		base.Controls.Add(this.vmethod_4());
		base.Controls.Add(this.vmethod_2());
		this.DoubleBuffered = true;
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedToolWindow;
		base.Name = "fUpdate";
		base.Opacity = 0.0;
		base.ShowInTaskbar = false;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterParent;
		this.Text = "BitRAT - Update notice";
		base.TopMost = true;
		this.vmethod_26().ResumeLayout(false);
		this.vmethod_26().PerformLayout();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_24()).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_22()).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_4()).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_32()).EndInit();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x040003FB RID: 1019
	private global::System.ComponentModel.IContainer icontainer_0;
}
