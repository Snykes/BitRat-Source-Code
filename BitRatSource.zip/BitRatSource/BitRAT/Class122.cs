﻿using System;

// Token: 0x020000A1 RID: 161
internal static class Class122
{
	// Token: 0x060004E7 RID: 1255 RVA: 0x000050CF File Offset: 0x000032CF
	public static int smethod_0()
	{
		return (int)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O:+*?5D-", null);
	}

	// Token: 0x060004E8 RID: 1256 RVA: 0x000050F0 File Offset: 0x000032F0
	public static int smethod_1()
	{
		return (int)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O:V*?6dT", null);
	}

	// Token: 0x060004E9 RID: 1257 RVA: 0x00005111 File Offset: 0x00003311
	public static int smethod_2()
	{
		return (int)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O7n*?8E-", null);
	}

	// Token: 0x060004EA RID: 1258 RVA: 0x00005132 File Offset: 0x00003332
	public static int smethod_3()
	{
		return (int)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O9F*?7ls", null);
	}

	// Token: 0x060004EB RID: 1259 RVA: 0x00005153 File Offset: 0x00003353
	public static int smethod_4()
	{
		return (int)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O9^*?9>G", null);
	}

	// Token: 0x060004EC RID: 1260 RVA: 0x00005174 File Offset: 0x00003374
	public static long smethod_5()
	{
		return (long)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O9M*?8r<", null);
	}

	// Token: 0x060004ED RID: 1261 RVA: 0x00005195 File Offset: 0x00003395
	public static long smethod_6()
	{
		return (long)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O:d*?8Q1", null);
	}

	// Token: 0x060004EE RID: 1262 RVA: 0x000051B6 File Offset: 0x000033B6
	public static Struct15 smethod_7()
	{
		return (Struct15)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O8**?:Ce", null);
	}
}
