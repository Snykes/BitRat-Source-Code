﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using VisualPlus.Toolkit.Controls.Interactivity;

// Token: 0x020001BF RID: 447
[DesignerGenerated]
public sealed partial class fSplash : Form
{
	// Token: 0x06001863 RID: 6243 RVA: 0x000B199C File Offset: 0x000AFB9C
	public fSplash()
	{
		base.MouseMove += this.fSplash_MouseMove;
		base.MouseLeave += this.fSplash_MouseLeave;
		base.Paint += this.fSplash_Paint;
		base.Resize += this.fSplash_Resize;
		base.Load += this.fSplash_Load;
		base.MouseDown += this.fSplash_MouseDown;
		base.MouseUp += this.fSplash_MouseUp;
		this.collection_0 = new Collection();
		this.collection_1 = new Collection();
		this.InitializeComponent();
	}

	// Token: 0x06001866 RID: 6246 RVA: 0x0000C655 File Offset: 0x0000A855
	internal System.Windows.Forms.Timer vmethod_0()
	{
		return this.timer_0;
	}

	// Token: 0x06001867 RID: 6247 RVA: 0x000B27E0 File Offset: 0x000B09E0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_1(System.Windows.Forms.Timer timer_2)
	{
		EventHandler value = new EventHandler(this.method_3);
		System.Windows.Forms.Timer timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_0 = timer_2;
		timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x06001868 RID: 6248 RVA: 0x0000C65D File Offset: 0x0000A85D
	internal BackgroundWorker vmethod_2()
	{
		return this.backgroundWorker_0;
	}

	// Token: 0x06001869 RID: 6249 RVA: 0x000B2824 File Offset: 0x000B0A24
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_3(BackgroundWorker backgroundWorker_3)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_6);
		BackgroundWorker backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_0 = backgroundWorker_3;
		backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x0600186A RID: 6250 RVA: 0x0000C665 File Offset: 0x0000A865
	internal VisualLabel vmethod_4()
	{
		return this.visualLabel_0;
	}

	// Token: 0x0600186B RID: 6251 RVA: 0x000B2868 File Offset: 0x000B0A68
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_5(VisualLabel visualLabel_5)
	{
		MouseEventHandler value = new MouseEventHandler(this.method_12);
		MouseEventHandler value2 = new MouseEventHandler(this.method_13);
		VisualLabel visualLabel = this.visualLabel_0;
		if (visualLabel != null)
		{
			visualLabel.MouseUp -= value;
			visualLabel.MouseDown -= value2;
		}
		this.visualLabel_0 = visualLabel_5;
		visualLabel = this.visualLabel_0;
		if (visualLabel != null)
		{
			visualLabel.MouseUp += value;
			visualLabel.MouseDown += value2;
		}
	}

	// Token: 0x0600186C RID: 6252 RVA: 0x0000C66D File Offset: 0x0000A86D
	internal VisualLabel vmethod_6()
	{
		return this.visualLabel_1;
	}

	// Token: 0x0600186D RID: 6253 RVA: 0x000B28C8 File Offset: 0x000B0AC8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_7(VisualLabel visualLabel_5)
	{
		MouseEventHandler value = new MouseEventHandler(this.method_14);
		MouseEventHandler value2 = new MouseEventHandler(this.method_16);
		VisualLabel visualLabel = this.visualLabel_1;
		if (visualLabel != null)
		{
			visualLabel.MouseDown -= value;
			visualLabel.MouseUp -= value2;
		}
		this.visualLabel_1 = visualLabel_5;
		visualLabel = this.visualLabel_1;
		if (visualLabel != null)
		{
			visualLabel.MouseDown += value;
			visualLabel.MouseUp += value2;
		}
	}

	// Token: 0x0600186E RID: 6254 RVA: 0x0000C675 File Offset: 0x0000A875
	internal PictureBox vmethod_8()
	{
		return this.pictureBox_0;
	}

	// Token: 0x0600186F RID: 6255 RVA: 0x000B2928 File Offset: 0x000B0B28
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_9(PictureBox pictureBox_2)
	{
		EventHandler value = new EventHandler(this.method_10);
		PictureBox pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_0 = pictureBox_2;
		pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06001870 RID: 6256 RVA: 0x0000C67D File Offset: 0x0000A87D
	internal System.Windows.Forms.Timer vmethod_10()
	{
		return this.timer_1;
	}

	// Token: 0x06001871 RID: 6257 RVA: 0x000B296C File Offset: 0x000B0B6C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_11(System.Windows.Forms.Timer timer_2)
	{
		EventHandler value = new EventHandler(this.method_11);
		System.Windows.Forms.Timer timer = this.timer_1;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_1 = timer_2;
		timer = this.timer_1;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x06001872 RID: 6258 RVA: 0x0000C685 File Offset: 0x0000A885
	internal PictureBox vmethod_12()
	{
		return this.pictureBox_1;
	}

	// Token: 0x06001873 RID: 6259 RVA: 0x000B29B0 File Offset: 0x000B0BB0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_13(PictureBox pictureBox_2)
	{
		EventHandler value = new EventHandler(this.method_15);
		MouseEventHandler value2 = new MouseEventHandler(this.method_17);
		MouseEventHandler value3 = new MouseEventHandler(this.method_18);
		PictureBox pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
			pictureBox.MouseDown -= value2;
			pictureBox.MouseUp -= value3;
		}
		this.pictureBox_1 = pictureBox_2;
		pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
			pictureBox.MouseDown += value2;
			pictureBox.MouseUp += value3;
		}
	}

	// Token: 0x06001874 RID: 6260 RVA: 0x0000C68D File Offset: 0x0000A88D
	internal VisualLabel vmethod_14()
	{
		return this.visualLabel_2;
	}

	// Token: 0x06001875 RID: 6261 RVA: 0x000B2A2C File Offset: 0x000B0C2C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_15(VisualLabel visualLabel_5)
	{
		MouseEventHandler value = new MouseEventHandler(this.method_19);
		MouseEventHandler value2 = new MouseEventHandler(this.method_20);
		VisualLabel visualLabel = this.visualLabel_2;
		if (visualLabel != null)
		{
			visualLabel.MouseDown -= value;
			visualLabel.MouseUp -= value2;
		}
		this.visualLabel_2 = visualLabel_5;
		visualLabel = this.visualLabel_2;
		if (visualLabel != null)
		{
			visualLabel.MouseDown += value;
			visualLabel.MouseUp += value2;
		}
	}

	// Token: 0x06001876 RID: 6262 RVA: 0x0000C695 File Offset: 0x0000A895
	internal BackgroundWorker vmethod_16()
	{
		return this.backgroundWorker_1;
	}

	// Token: 0x06001877 RID: 6263 RVA: 0x000B2A8C File Offset: 0x000B0C8C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_17(BackgroundWorker backgroundWorker_3)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_21);
		BackgroundWorker backgroundWorker = this.backgroundWorker_1;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_1 = backgroundWorker_3;
		backgroundWorker = this.backgroundWorker_1;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x06001878 RID: 6264 RVA: 0x0000C69D File Offset: 0x0000A89D
	internal BackgroundWorker vmethod_18()
	{
		return this.backgroundWorker_2;
	}

	// Token: 0x06001879 RID: 6265 RVA: 0x000B2AD0 File Offset: 0x000B0CD0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_19(BackgroundWorker backgroundWorker_3)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_22);
		BackgroundWorker backgroundWorker = this.backgroundWorker_2;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_2 = backgroundWorker_3;
		backgroundWorker = this.backgroundWorker_2;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x0600187A RID: 6266 RVA: 0x0000C6A5 File Offset: 0x0000A8A5
	internal VisualLabel vmethod_20()
	{
		return this.visualLabel_3;
	}

	// Token: 0x0600187B RID: 6267 RVA: 0x000B2B14 File Offset: 0x000B0D14
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_21(VisualLabel visualLabel_5)
	{
		EventHandler value = new EventHandler(this.method_24);
		MouseEventHandler value2 = new MouseEventHandler(this.method_27);
		MouseEventHandler value3 = new MouseEventHandler(this.method_29);
		VisualLabel visualLabel = this.visualLabel_3;
		if (visualLabel != null)
		{
			visualLabel.Click -= value;
			visualLabel.MouseDown -= value2;
			visualLabel.MouseUp -= value3;
		}
		this.visualLabel_3 = visualLabel_5;
		visualLabel = this.visualLabel_3;
		if (visualLabel != null)
		{
			visualLabel.Click += value;
			visualLabel.MouseDown += value2;
			visualLabel.MouseUp += value3;
		}
	}

	// Token: 0x0600187C RID: 6268 RVA: 0x0000C6AD File Offset: 0x0000A8AD
	internal VisualLabel vmethod_22()
	{
		return this.visualLabel_4;
	}

	// Token: 0x0600187D RID: 6269 RVA: 0x000B2B90 File Offset: 0x000B0D90
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_23(VisualLabel visualLabel_5)
	{
		EventHandler value = new EventHandler(this.method_25);
		MouseEventHandler value2 = new MouseEventHandler(this.method_28);
		MouseEventHandler value3 = new MouseEventHandler(this.method_30);
		VisualLabel visualLabel = this.visualLabel_4;
		if (visualLabel != null)
		{
			visualLabel.Click -= value;
			visualLabel.MouseDown -= value2;
			visualLabel.MouseUp -= value3;
		}
		this.visualLabel_4 = visualLabel_5;
		visualLabel = this.visualLabel_4;
		if (visualLabel != null)
		{
			visualLabel.Click += value;
			visualLabel.MouseDown += value2;
			visualLabel.MouseUp += value3;
		}
	}

	// Token: 0x0600187E RID: 6270
	[DllImport("Ntdll.dll")]
	public static extern uint NtSetInformationThread(IntPtr intptr_0, int int_1, IntPtr intptr_1, uint uint_0);

	// Token: 0x0600187F RID: 6271
	[DllImport("Kernel32.dll")]
	public static extern IntPtr GetCurrentThread();

	// Token: 0x06001880 RID: 6272
	[DllImport("kernel32.dll")]
	private static extern bool IsDebuggerPresent();

	// Token: 0x06001881 RID: 6273 RVA: 0x000B2C0C File Offset: 0x000B0E0C
	private void method_0()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O5]*?:\"Z", object_);
	}

	// Token: 0x06001882 RID: 6274 RVA: 0x000B2C3C File Offset: 0x000B0E3C
	private void method_1()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O=B*?8<*", object_);
	}

	// Token: 0x06001883 RID: 6275 RVA: 0x0000C6B5 File Offset: 0x0000A8B5
	public static uint smethod_0()
	{
		return (uint)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O=9*?7`o", null);
	}

	// Token: 0x06001884 RID: 6276 RVA: 0x000B2C6C File Offset: 0x000B0E6C
	private void method_2()
	{
		this.rectangle_0 = this.DisplayRectangle;
		checked
		{
			int num = fSplash.class150_0.Count<fSplash.Class150>() - 1;
			for (int i = 0; i <= num; i++)
			{
				fSplash.class150_0[i] = new fSplash.Class150(this.rectangle_0);
			}
		}
	}

	// Token: 0x06001885 RID: 6277 RVA: 0x000B2CB0 File Offset: 0x000B0EB0
	public static float smethod_1(Point point_1, Point point_2)
	{
		return (float)Math.Sqrt(Math.Pow((double)Math.Abs(checked(point_2.X - point_1.X)), 2.0) + Math.Pow((double)Math.Abs(checked(point_2.Y - point_1.Y)), 2.0));
	}

	// Token: 0x06001886 RID: 6278 RVA: 0x000B2D0C File Offset: 0x000B0F0C
	private static decimal smethod_2(decimal decimal_1, decimal decimal_2, int int_1)
	{
		return new decimal(Convert.ToDouble(decimal_1) + Convert.ToDouble(decimal_2) * Math.Cos((double)(checked((int_1 - 90 < 0) ? (360 + (int_1 - 90)) : (int_1 - 90))) * 3.141592653589793 / 180.0));
	}

	// Token: 0x06001887 RID: 6279 RVA: 0x000B2D60 File Offset: 0x000B0F60
	private static decimal smethod_3(decimal decimal_1, decimal decimal_2, int int_1)
	{
		return new decimal(Convert.ToDouble(decimal_1) + Convert.ToDouble(decimal_2) * Math.Sin((double)(checked((int_1 - 90 < 0) ? (360 + (int_1 - 90)) : (int_1 - 90))) * 3.141592653589793 / 180.0));
	}

	// Token: 0x06001888 RID: 6280 RVA: 0x0000C6D6 File Offset: 0x0000A8D6
	private void fSplash_MouseMove(object sender, MouseEventArgs e)
	{
		fSplash.mouseEventArgs_0 = e;
	}

	// Token: 0x06001889 RID: 6281 RVA: 0x0000C6DE File Offset: 0x0000A8DE
	private void fSplash_MouseLeave(object sender, EventArgs e)
	{
		fSplash.mouseEventArgs_0 = null;
	}

	// Token: 0x0600188A RID: 6282 RVA: 0x000B2DB4 File Offset: 0x000B0FB4
	private void fSplash_Paint(object sender, PaintEventArgs e)
	{
		Graphics graphics = e.Graphics;
		graphics.SmoothingMode = SmoothingMode.AntiAlias;
		checked
		{
			int num = fSplash.class150_0.Count<fSplash.Class150>() - 1;
			for (int i = 0; i <= num; i++)
			{
				if (!Information.IsNothing(fSplash.mouseEventArgs_0))
				{
					int x = fSplash.mouseEventArgs_0.X;
					int y = fSplash.mouseEventArgs_0.Y;
					int num2 = Convert.ToInt32(fSplash.class150_0[i].decimal_3);
					int num3 = Convert.ToInt32(fSplash.class150_0[i].decimal_4);
					if (unchecked(Math.Pow((double)(checked(x - num2)), 2.0) + Math.Pow((double)(checked(y - num3)), 2.0)) < 10000.0)
					{
						new Point(num2, num3);
						new Point(x, y);
						int int_ = (int)Math.Round(unchecked(checked(Math.Atan2((double)(num2 - x), (double)(y - num3))) * 57.29577951308232 + 360.0) % 360.0);
						int num4 = (int)Math.Round((double)fSplash.smethod_1(new Point(x, y), new Point(num2, num3)));
						Point point = new Point(Convert.ToInt32(fSplash.smethod_2(new decimal(num2), new decimal(100 - num4), int_)), Convert.ToInt32(fSplash.smethod_3(new decimal(num3), new decimal(100 - num4), int_)));
						fSplash.class150_0[i].decimal_3 = new decimal(point.X);
						fSplash.class150_0[i].decimal_4 = new decimal(point.Y);
					}
				}
				fSplash.class150_0[i].method_1(graphics);
				fSplash.class150_0[i].method_2();
			}
		}
	}

	// Token: 0x0600188B RID: 6283 RVA: 0x0000C6E6 File Offset: 0x0000A8E6
	private void method_3(object sender, EventArgs e)
	{
		base.Invalidate();
	}

	// Token: 0x0600188C RID: 6284 RVA: 0x0000C6EE File Offset: 0x0000A8EE
	private void fSplash_Resize(object sender, EventArgs e)
	{
		this.method_2();
	}

	// Token: 0x0600188D RID: 6285 RVA: 0x000B2F5C File Offset: 0x000B115C
	private void fSplash_Load(object sender, EventArgs e)
	{
		object[] object_ = new object[]
		{
			this,
			sender,
			e
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O<2*?9GJ", object_);
	}

	// Token: 0x0600188E RID: 6286 RVA: 0x0000C6F6 File Offset: 0x0000A8F6
	private int method_4(int int_1, int int_2)
	{
		return new Random().Next(int_1, int_2);
	}

	// Token: 0x0600188F RID: 6287 RVA: 0x000B2F94 File Offset: 0x000B1194
	public void method_5(int int_1)
	{
		if (base.InvokeRequired)
		{
			base.Invoke(new fSplash.Delegate189(this.method_5), new object[]
			{
				int_1
			});
			return;
		}
		base.Opacity = Conversion.Val((double)this.int_0 / 100.0);
	}

	// Token: 0x06001890 RID: 6288 RVA: 0x000B2FF0 File Offset: 0x000B11F0
	private void method_6(object sender, DoWorkEventArgs e)
	{
		this.int_0 = 0;
		while (this.int_0 < 85)
		{
			ref int ptr = ref this.int_0;
			this.int_0 = checked(ptr + 1);
			this.method_5(this.int_0);
			Application.DoEvents();
		}
	}

	// Token: 0x06001891 RID: 6289 RVA: 0x000B3030 File Offset: 0x000B1230
	private void fSplash_MouseDown(object sender, MouseEventArgs e)
	{
		this.method_1();
		MouseButtons button = e.Button;
		if (button == MouseButtons.Left)
		{
			this.vmethod_10().Enabled = true;
		}
	}

	// Token: 0x06001892 RID: 6290 RVA: 0x0000C704 File Offset: 0x0000A904
	public void method_7(ref string string_0)
	{
		if (this.vmethod_4().InvokeRequired)
		{
			this.vmethod_4().Invoke(new fSplash.Delegate185(this.method_7), new object[]
			{
				string_0
			});
			return;
		}
		this.vmethod_4().Text = string_0;
	}

	// Token: 0x06001893 RID: 6291 RVA: 0x000B3060 File Offset: 0x000B1260
	public void method_8(Color color_0)
	{
		if (this.vmethod_4().InvokeRequired)
		{
			this.vmethod_4().Invoke(new fSplash.Delegate187(this.method_8), new object[]
			{
				color_0
			});
			return;
		}
		this.vmethod_4().ForeColor = color_0;
	}

	// Token: 0x06001894 RID: 6292 RVA: 0x000B30B0 File Offset: 0x000B12B0
	public void method_9(ref string string_0, Color color_0)
	{
		object[] array = new object[]
		{
			this,
			string_0,
			color_0
		};
		Class4 @class = Class149.smethod_0();
		Stream stream_ = Class149.smethod_1();
		try
		{
			@class.method_139(stream_, ")&O<E*?:1_", array);
		}
		finally
		{
			string_0 = (string)array[1];
		}
	}

	// Token: 0x06001895 RID: 6293 RVA: 0x000B3118 File Offset: 0x000B1318
	private void method_10(object sender, EventArgs e)
	{
		string text = "Exiting...";
		this.method_7(ref text);
		Class130.fMain_0.method_50();
	}

	// Token: 0x06001896 RID: 6294 RVA: 0x0000C744 File Offset: 0x0000A944
	private void method_11(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x06001897 RID: 6295 RVA: 0x000B3140 File Offset: 0x000B1340
	private void fSplash_MouseUp(object sender, MouseEventArgs e)
	{
		MouseButtons button = e.Button;
		if (button == MouseButtons.Left)
		{
			this.vmethod_10().Enabled = false;
		}
	}

	// Token: 0x06001898 RID: 6296 RVA: 0x000B3140 File Offset: 0x000B1340
	private void method_12(object sender, MouseEventArgs e)
	{
		MouseButtons button = e.Button;
		if (button == MouseButtons.Left)
		{
			this.vmethod_10().Enabled = false;
		}
	}

	// Token: 0x06001899 RID: 6297 RVA: 0x000B3030 File Offset: 0x000B1230
	private void method_13(object sender, MouseEventArgs e)
	{
		this.method_1();
		MouseButtons button = e.Button;
		if (button == MouseButtons.Left)
		{
			this.vmethod_10().Enabled = true;
		}
	}

	// Token: 0x0600189A RID: 6298 RVA: 0x000B3030 File Offset: 0x000B1230
	private void method_14(object sender, MouseEventArgs e)
	{
		this.method_1();
		MouseButtons button = e.Button;
		if (button == MouseButtons.Left)
		{
			this.vmethod_10().Enabled = true;
		}
	}

	// Token: 0x0600189B RID: 6299 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_15(object sender, EventArgs e)
	{
	}

	// Token: 0x0600189C RID: 6300 RVA: 0x000B3140 File Offset: 0x000B1340
	private void method_16(object sender, MouseEventArgs e)
	{
		MouseButtons button = e.Button;
		if (button == MouseButtons.Left)
		{
			this.vmethod_10().Enabled = false;
		}
	}

	// Token: 0x0600189D RID: 6301 RVA: 0x000B3030 File Offset: 0x000B1230
	private void method_17(object sender, MouseEventArgs e)
	{
		this.method_1();
		MouseButtons button = e.Button;
		if (button == MouseButtons.Left)
		{
			this.vmethod_10().Enabled = true;
		}
	}

	// Token: 0x0600189E RID: 6302 RVA: 0x000B3140 File Offset: 0x000B1340
	private void method_18(object sender, MouseEventArgs e)
	{
		MouseButtons button = e.Button;
		if (button == MouseButtons.Left)
		{
			this.vmethod_10().Enabled = false;
		}
	}

	// Token: 0x0600189F RID: 6303 RVA: 0x000B3030 File Offset: 0x000B1230
	private void method_19(object sender, MouseEventArgs e)
	{
		this.method_1();
		MouseButtons button = e.Button;
		if (button == MouseButtons.Left)
		{
			this.vmethod_10().Enabled = true;
		}
	}

	// Token: 0x060018A0 RID: 6304 RVA: 0x000B3140 File Offset: 0x000B1340
	private void method_20(object sender, MouseEventArgs e)
	{
		MouseButtons button = e.Button;
		if (button == MouseButtons.Left)
		{
			this.vmethod_10().Enabled = false;
		}
	}

	// Token: 0x060018A1 RID: 6305 RVA: 0x000B3168 File Offset: 0x000B1368
	private void method_21(object sender, DoWorkEventArgs e)
	{
		Thread.Sleep(2000);
		this.method_26(this.vmethod_20(), 0, Color.Orange);
		this.method_23(this.vmethod_20(), true);
		int num = 1;
		checked
		{
			do
			{
				Thread.Sleep(1);
				this.method_26(this.vmethod_20(), num, Color.Orange);
				num++;
			}
			while (num <= 255);
			this.vmethod_18().RunWorkerAsync();
		}
	}

	// Token: 0x060018A2 RID: 6306 RVA: 0x000B31D0 File Offset: 0x000B13D0
	private void method_22(object sender, DoWorkEventArgs e)
	{
		this.method_26(this.vmethod_22(), 0, Color.White);
		this.method_23(this.vmethod_22(), true);
		int num = 1;
		checked
		{
			do
			{
				Thread.Sleep(1);
				this.method_26(this.vmethod_22(), num, Color.White);
				num++;
			}
			while (num <= 200);
		}
	}

	// Token: 0x060018A3 RID: 6307 RVA: 0x000B3224 File Offset: 0x000B1424
	private void method_23(VisualLabel visualLabel_5, bool bool_0)
	{
		object[] object_ = new object[]
		{
			this,
			visualLabel_5,
			bool_0
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O=d*?;d7", object_);
	}

	// Token: 0x060018A4 RID: 6308 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_24(object sender, EventArgs e)
	{
	}

	// Token: 0x060018A5 RID: 6309 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_25(object sender, EventArgs e)
	{
	}

	// Token: 0x060018A6 RID: 6310 RVA: 0x000B3260 File Offset: 0x000B1460
	private void method_26(VisualLabel visualLabel_5, int int_1, Color color_0)
	{
		if (visualLabel_5.InvokeRequired)
		{
			visualLabel_5.Invoke(new fSplash.Delegate188(this.method_26), new object[]
			{
				visualLabel_5,
				int_1,
				color_0
			});
			return;
		}
		visualLabel_5.ForeColor = Color.FromArgb(int_1, color_0);
		visualLabel_5.Update();
	}

	// Token: 0x060018A7 RID: 6311 RVA: 0x000B3030 File Offset: 0x000B1230
	private void method_27(object sender, MouseEventArgs e)
	{
		this.method_1();
		MouseButtons button = e.Button;
		if (button == MouseButtons.Left)
		{
			this.vmethod_10().Enabled = true;
		}
	}

	// Token: 0x060018A8 RID: 6312 RVA: 0x000B3030 File Offset: 0x000B1230
	private void method_28(object sender, MouseEventArgs e)
	{
		this.method_1();
		MouseButtons button = e.Button;
		if (button == MouseButtons.Left)
		{
			this.vmethod_10().Enabled = true;
		}
	}

	// Token: 0x060018A9 RID: 6313 RVA: 0x000B3140 File Offset: 0x000B1340
	private void method_29(object sender, MouseEventArgs e)
	{
		MouseButtons button = e.Button;
		if (button == MouseButtons.Left)
		{
			this.vmethod_10().Enabled = false;
		}
	}

	// Token: 0x060018AA RID: 6314 RVA: 0x000B3140 File Offset: 0x000B1340
	private void method_30(object sender, MouseEventArgs e)
	{
		MouseButtons button = e.Button;
		if (button == MouseButtons.Left)
		{
			this.vmethod_10().Enabled = false;
		}
	}

	// Token: 0x0400091A RID: 2330
	private System.Windows.Forms.Timer timer_0;

	// Token: 0x0400091B RID: 2331
	private BackgroundWorker backgroundWorker_0;

	// Token: 0x0400091C RID: 2332
	private VisualLabel visualLabel_0;

	// Token: 0x0400091D RID: 2333
	private VisualLabel visualLabel_1;

	// Token: 0x0400091E RID: 2334
	private PictureBox pictureBox_0;

	// Token: 0x0400091F RID: 2335
	private System.Windows.Forms.Timer timer_1;

	// Token: 0x04000920 RID: 2336
	private PictureBox pictureBox_1;

	// Token: 0x04000921 RID: 2337
	private VisualLabel visualLabel_2;

	// Token: 0x04000922 RID: 2338
	private BackgroundWorker backgroundWorker_1;

	// Token: 0x04000923 RID: 2339
	private BackgroundWorker backgroundWorker_2;

	// Token: 0x04000924 RID: 2340
	private VisualLabel visualLabel_3;

	// Token: 0x04000925 RID: 2341
	private VisualLabel visualLabel_4;

	// Token: 0x04000926 RID: 2342
	private Rectangle rectangle_0;

	// Token: 0x04000927 RID: 2343
	private static Random random_0 = new Random();

	// Token: 0x04000928 RID: 2344
	private static fSplash.Class150[] class150_0 = new fSplash.Class150[41];

	// Token: 0x04000929 RID: 2345
	private static decimal decimal_0 = 100m;

	// Token: 0x0400092A RID: 2346
	private static MouseEventArgs mouseEventArgs_0;

	// Token: 0x0400092B RID: 2347
	private int int_0;

	// Token: 0x0400092C RID: 2348
	public Point point_0;

	// Token: 0x0400092D RID: 2349
	private long long_0;

	// Token: 0x0400092E RID: 2350
	private long long_1;

	// Token: 0x0400092F RID: 2351
	private Collection collection_0;

	// Token: 0x04000930 RID: 2352
	private Collection collection_1;

	// Token: 0x020001C0 RID: 448
	// (Invoke) Token: 0x060018AE RID: 6318
	private delegate void Delegate185(ref string string_0);

	// Token: 0x020001C1 RID: 449
	// (Invoke) Token: 0x060018B2 RID: 6322
	private delegate void Delegate186(ref string string_0, Color color_0);

	// Token: 0x020001C2 RID: 450
	// (Invoke) Token: 0x060018B6 RID: 6326
	private delegate void Delegate187(Color color_0);

	// Token: 0x020001C3 RID: 451
	// (Invoke) Token: 0x060018BA RID: 6330
	private delegate void Delegate188(VisualLabel visualLabel_0, int int_0, Color color_0);

	// Token: 0x020001C4 RID: 452
	// (Invoke) Token: 0x060018BE RID: 6334
	private delegate void Delegate189(int int_0);

	// Token: 0x020001C5 RID: 453
	// (Invoke) Token: 0x060018C2 RID: 6338
	private delegate void Delegate190(VisualLabel visualLabel_0, bool bool_0);

	// Token: 0x020001C6 RID: 454
	internal sealed class Class150
	{
		// Token: 0x060018C3 RID: 6339 RVA: 0x0000C74C File Offset: 0x0000A94C
		public Class150(Rectangle rectangle_1)
		{
			this.rectangle_0 = rectangle_1;
			this.method_0();
		}

		// Token: 0x060018C4 RID: 6340 RVA: 0x000B32B8 File Offset: 0x000B14B8
		private void method_0()
		{
			this.decimal_0 = new decimal(fSplash.random_0.Next(0, 360));
			this.decimal_1 = new decimal(fSplash.random_0.Next(2, 2));
			this.decimal_2 = new decimal(fSplash.random_0.Next(2, 10));
			this.decimal_3 = new decimal(fSplash.random_0.Next(0, this.rectangle_0.Width));
			this.decimal_4 = new decimal(fSplash.random_0.Next(0, this.rectangle_0.Height));
		}

		// Token: 0x060018C5 RID: 6341 RVA: 0x000B3354 File Offset: 0x000B1554
		public void method_1(Graphics graphics_0)
		{
			int num;
			int num6;
			object obj;
			try
			{
				IL_00:
				ProjectData.ClearProjectError();
				num = 1;
				IL_07:
				int num2 = 2;
				Point point = new Point(Convert.ToInt32(this.decimal_3), Convert.ToInt32(this.decimal_4));
				IL_26:
				num2 = 3;
				checked
				{
					int num3 = fSplash.class150_0.Count<fSplash.Class150>() - 1;
					for (int i = 0; i <= num3; i++)
					{
						IL_3D:
						num2 = 4;
						Point point2 = new Point(Convert.ToInt32(fSplash.class150_0[i].decimal_3), Convert.ToInt32(fSplash.class150_0[i].decimal_4));
						IL_68:
						num2 = 5;
						if (decimal.Compare(fSplash.class150_0[i].decimal_3, this.decimal_3) != 0 & decimal.Compare(fSplash.class150_0[i].decimal_4, this.decimal_4) != 0)
						{
							IL_A4:
							num2 = 6;
							int value = (int)Math.Round((double)fSplash.smethod_1(point, point2));
							IL_B8:
							num2 = 7;
							if (decimal.Compare(new decimal(value), fSplash.decimal_0) < 0)
							{
								IL_CE:
								num2 = 8;
								int num4 = Convert.ToInt32(decimal.Multiply(decimal.Divide(new decimal(value), fSplash.decimal_0), 20m));
								IL_FB:
								num2 = 9;
								Pen pen = new Pen(Color.FromArgb(50 - num4, 255, 179, 4), 0.5f);
								IL_11F:
								num2 = 10;
								graphics_0.DrawLine(pen, point, point2);
							}
						}
						IL_12E:
						num2 = 11;
					}
					IL_13D:
					num2 = 12;
					graphics_0.FillEllipse(new SolidBrush(Color.FromArgb(100, 250, 250, 250)), new Rectangle(Convert.ToInt32(decimal.Subtract(this.decimal_3, decimal.Divide(this.decimal_2, 2m))), Convert.ToInt32(decimal.Subtract(this.decimal_4, decimal.Divide(this.decimal_2, 2m))), Convert.ToInt32(this.decimal_2), Convert.ToInt32(this.decimal_2)));
					IL_1CE:
					goto IL_254;
					IL_1D3:;
				}
				int num5 = num6 + 1;
				num6 = 0;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num5);
				IL_215:
				goto IL_249;
				IL_217:
				num6 = num2;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num);
				IL_227:;
			}
			catch when (endfilter(obj is Exception & num != 0 & num6 == 0))
			{
				Exception ex = (Exception)obj2;
				goto IL_217;
			}
			IL_249:
			throw ProjectData.CreateProjectError(-2146828237);
			IL_254:
			if (num6 != 0)
			{
				ProjectData.ClearProjectError();
			}
		}

		// Token: 0x060018C6 RID: 6342 RVA: 0x000B35DC File Offset: 0x000B17DC
		public void method_2()
		{
			this.decimal_3 = fSplash.smethod_2(this.decimal_3, this.decimal_1, Convert.ToInt32(this.decimal_0));
			this.decimal_4 = fSplash.smethod_3(this.decimal_4, this.decimal_1, Convert.ToInt32(this.decimal_0));
			if (checked(decimal.Compare(this.decimal_3, -20m) < 0 | decimal.Compare(this.decimal_4, -20m) < 0 | decimal.Compare(this.decimal_3, new decimal(this.rectangle_0.Width + 20)) > 0 | decimal.Compare(this.decimal_4, new decimal(this.rectangle_0.Height + 20)) > 0))
			{
				this.method_0();
			}
		}

		// Token: 0x04000931 RID: 2353
		public decimal decimal_0;

		// Token: 0x04000932 RID: 2354
		public decimal decimal_1;

		// Token: 0x04000933 RID: 2355
		public decimal decimal_2;

		// Token: 0x04000934 RID: 2356
		public decimal decimal_3;

		// Token: 0x04000935 RID: 2357
		public decimal decimal_4;

		// Token: 0x04000936 RID: 2358
		private Rectangle rectangle_0;
	}
}
