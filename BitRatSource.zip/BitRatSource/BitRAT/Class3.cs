﻿using System;

// Token: 0x02000007 RID: 7
internal sealed class Class3
{
	// Token: 0x06000024 RID: 36 RVA: 0x00002D81 File Offset: 0x00000F81
	public byte method_0()
	{
		return this.byte_0;
	}

	// Token: 0x06000025 RID: 37 RVA: 0x00002D89 File Offset: 0x00000F89
	public void method_1(byte byte_1)
	{
		this.byte_0 = byte_1;
	}

	// Token: 0x06000026 RID: 38 RVA: 0x00002D92 File Offset: 0x00000F92
	public int method_2()
	{
		return this.int_0;
	}

	// Token: 0x06000027 RID: 39 RVA: 0x00002D9A File Offset: 0x00000F9A
	public void method_3(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x06000028 RID: 40 RVA: 0x00002DA3 File Offset: 0x00000FA3
	public Class34 method_4()
	{
		return this.class34_0;
	}

	// Token: 0x06000029 RID: 41 RVA: 0x00002DAB File Offset: 0x00000FAB
	public void method_5(Class34 class34_1)
	{
		this.class34_0 = class34_1;
	}

	// Token: 0x0400000B RID: 11
	private byte byte_0;

	// Token: 0x0400000C RID: 12
	private int int_0;

	// Token: 0x0400000D RID: 13
	private Class34 class34_0;
}
