﻿using System;

// Token: 0x02000059 RID: 89
internal static class Class56
{
	// Token: 0x0600033B RID: 827 RVA: 0x0001F7C0 File Offset: 0x0001D9C0
	public static long smethod_0(string string_0)
	{
		object[] object_ = new object[]
		{
			string_0
		};
		return (long)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O=/*?7'\\", object_);
	}

	// Token: 0x0600033C RID: 828 RVA: 0x0001F7F8 File Offset: 0x0001D9F8
	public static long smethod_1(long long_0)
	{
		object[] object_ = new object[]
		{
			long_0
		};
		return (long)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O=%*?89)", object_);
	}

	// Token: 0x0600033D RID: 829 RVA: 0x0001F834 File Offset: 0x0001DA34
	public static long smethod_2(long? nullable_0)
	{
		object[] object_ = new object[]
		{
			nullable_0
		};
		return (long)Class149.smethod_0().method_256(Class149.smethod_1(), ")&O;6*?7Zm", object_);
	}
}
