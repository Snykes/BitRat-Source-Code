﻿using System;
using System.Collections;
using System.Runtime.CompilerServices;
using System.Threading;

// Token: 0x02000109 RID: 265
public sealed class GClass5
{
	// Token: 0x06000E1B RID: 3611 RVA: 0x00008504 File Offset: 0x00006704
	public GClass5(int int_1, bool bool_0)
	{
		this.sortedList_0 = new SortedList();
		this.int_0 = int_1;
		this.vmethod_1(new GClass8(int_1, bool_0));
	}

	// Token: 0x06000E1C RID: 3612 RVA: 0x0000852B File Offset: 0x0000672B
	private GClass8 vmethod_0()
	{
		return this.gclass8_0;
	}

	// Token: 0x06000E1D RID: 3613 RVA: 0x0006CEDC File Offset: 0x0006B0DC
	[MethodImpl(MethodImplOptions.Synchronized)]
	private void vmethod_1(GClass8 gclass8_1)
	{
		GClass8.GDelegate8 gdelegate8_ = new GClass8.GDelegate8(this.method_14);
		GClass8 gclass = this.gclass8_0;
		if (gclass != null)
		{
			gclass.method_1(gdelegate8_);
		}
		this.gclass8_0 = gclass8_1;
		gclass = this.gclass8_0;
		if (gclass != null)
		{
			gclass.method_0(gdelegate8_);
		}
	}

	// Token: 0x06000E1E RID: 3614 RVA: 0x0006CF20 File Offset: 0x0006B120
	public void method_0(GClass5.GDelegate5 gdelegate5_1)
	{
		GClass5.GDelegate5 gdelegate = this.gdelegate5_0;
		GClass5.GDelegate5 gdelegate2;
		do
		{
			gdelegate2 = gdelegate;
			GClass5.GDelegate5 value = (GClass5.GDelegate5)Delegate.Combine(gdelegate2, gdelegate5_1);
			gdelegate = Interlocked.CompareExchange<GClass5.GDelegate5>(ref this.gdelegate5_0, value, gdelegate2);
		}
		while (gdelegate != gdelegate2);
	}

	// Token: 0x06000E1F RID: 3615 RVA: 0x0006CF58 File Offset: 0x0006B158
	public void method_1(GClass5.GDelegate5 gdelegate5_1)
	{
		GClass5.GDelegate5 gdelegate = this.gdelegate5_0;
		GClass5.GDelegate5 gdelegate2;
		do
		{
			gdelegate2 = gdelegate;
			GClass5.GDelegate5 value = (GClass5.GDelegate5)Delegate.Remove(gdelegate2, gdelegate5_1);
			gdelegate = Interlocked.CompareExchange<GClass5.GDelegate5>(ref this.gdelegate5_0, value, gdelegate2);
		}
		while (gdelegate != gdelegate2);
	}

	// Token: 0x06000E20 RID: 3616 RVA: 0x0006CF90 File Offset: 0x0006B190
	public void method_2(GClass5.GDelegate7 gdelegate7_1)
	{
		GClass5.GDelegate7 gdelegate = this.gdelegate7_0;
		GClass5.GDelegate7 gdelegate2;
		do
		{
			gdelegate2 = gdelegate;
			GClass5.GDelegate7 value = (GClass5.GDelegate7)Delegate.Combine(gdelegate2, gdelegate7_1);
			gdelegate = Interlocked.CompareExchange<GClass5.GDelegate7>(ref this.gdelegate7_0, value, gdelegate2);
		}
		while (gdelegate != gdelegate2);
	}

	// Token: 0x06000E21 RID: 3617 RVA: 0x0006CFC8 File Offset: 0x0006B1C8
	public void method_3(GClass5.GDelegate7 gdelegate7_1)
	{
		GClass5.GDelegate7 gdelegate = this.gdelegate7_0;
		GClass5.GDelegate7 gdelegate2;
		do
		{
			gdelegate2 = gdelegate;
			GClass5.GDelegate7 value = (GClass5.GDelegate7)Delegate.Remove(gdelegate2, gdelegate7_1);
			gdelegate = Interlocked.CompareExchange<GClass5.GDelegate7>(ref this.gdelegate7_0, value, gdelegate2);
		}
		while (gdelegate != gdelegate2);
	}

	// Token: 0x06000E22 RID: 3618 RVA: 0x0006D000 File Offset: 0x0006B200
	public void method_4(GClass5.GDelegate6 gdelegate6_1)
	{
		GClass5.GDelegate6 gdelegate = this.gdelegate6_0;
		GClass5.GDelegate6 gdelegate2;
		do
		{
			gdelegate2 = gdelegate;
			GClass5.GDelegate6 value = (GClass5.GDelegate6)Delegate.Combine(gdelegate2, gdelegate6_1);
			gdelegate = Interlocked.CompareExchange<GClass5.GDelegate6>(ref this.gdelegate6_0, value, gdelegate2);
		}
		while (gdelegate != gdelegate2);
	}

	// Token: 0x06000E23 RID: 3619 RVA: 0x0006D038 File Offset: 0x0006B238
	public void method_5(GClass5.GDelegate6 gdelegate6_1)
	{
		GClass5.GDelegate6 gdelegate = this.gdelegate6_0;
		GClass5.GDelegate6 gdelegate2;
		do
		{
			gdelegate2 = gdelegate;
			GClass5.GDelegate6 value = (GClass5.GDelegate6)Delegate.Remove(gdelegate2, gdelegate6_1);
			gdelegate = Interlocked.CompareExchange<GClass5.GDelegate6>(ref this.gdelegate6_0, value, gdelegate2);
		}
		while (gdelegate != gdelegate2);
	}

	// Token: 0x06000E24 RID: 3620 RVA: 0x00008533 File Offset: 0x00006733
	public void method_6()
	{
		this.vmethod_0().method_2();
	}

	// Token: 0x06000E25 RID: 3621 RVA: 0x00008540 File Offset: 0x00006740
	public void method_7()
	{
		this.vmethod_0().method_3();
	}

	// Token: 0x06000E26 RID: 3622 RVA: 0x0006D070 File Offset: 0x0006B270
	public void method_8(string string_0)
	{
		try
		{
			if (this.sortedList_0.ContainsKey(string_0))
			{
				((GClass1)this.sortedList_0[string_0]).method_7();
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x06000E27 RID: 3623 RVA: 0x0000854D File Offset: 0x0000674D
	public void method_9(GClass1 gclass1_0)
	{
		this.sortedList_0.Add(gclass1_0.method_13(), gclass1_0);
		gclass1_0.method_0(new GClass1.GDelegate1(this.method_15));
		gclass1_0.method_2(new GClass1.GDelegate2(this.method_16));
	}

	// Token: 0x06000E28 RID: 3624 RVA: 0x00008585 File Offset: 0x00006785
	public GClass1 method_10(string string_0)
	{
		return (GClass1)this.sortedList_0[string_0];
	}

	// Token: 0x06000E29 RID: 3625 RVA: 0x00008598 File Offset: 0x00006798
	public GClass1 method_11(int int_1)
	{
		return (GClass1)this.sortedList_0[RuntimeHelpers.GetObjectValue(this.sortedList_0.GetKey(int_1))];
	}

	// Token: 0x06000E2A RID: 3626 RVA: 0x0006D0C4 File Offset: 0x0006B2C4
	public bool method_12(string string_0)
	{
		return this.method_10(string_0) != null;
	}

	// Token: 0x06000E2B RID: 3627 RVA: 0x000085BB File Offset: 0x000067BB
	public object method_13()
	{
		return this.sortedList_0.Count;
	}

	// Token: 0x06000E2C RID: 3628 RVA: 0x0006D0E4 File Offset: 0x0006B2E4
	private void method_14(GClass1 gclass1_0)
	{
		this.method_9(gclass1_0);
		GClass5.GDelegate5 gdelegate = this.gdelegate5_0;
		if (gdelegate != null)
		{
			gdelegate(gclass1_0.method_13());
		}
	}

	// Token: 0x06000E2D RID: 3629 RVA: 0x0006D110 File Offset: 0x0006B310
	private void method_15(string string_0, string string_1, string string_2, bool bool_0)
	{
		GClass5.GDelegate7 gdelegate = this.gdelegate7_0;
		if (gdelegate != null)
		{
			gdelegate(string_0, string_1, string_2, bool_0);
		}
		this.method_8(string_0);
		this.sortedList_0.Remove(string_0);
	}

	// Token: 0x06000E2E RID: 3630 RVA: 0x0006D148 File Offset: 0x0006B348
	private void method_16(string string_0, byte[] byte_0)
	{
		GClass5.GDelegate6 gdelegate = this.gdelegate6_0;
		if (gdelegate != null)
		{
			gdelegate(string_0, byte_0);
		}
	}

	// Token: 0x040005A9 RID: 1449
	public int int_0;

	// Token: 0x040005AA RID: 1450
	private readonly SortedList sortedList_0;

	// Token: 0x040005AB RID: 1451
	private GClass8 gclass8_0;

	// Token: 0x040005AC RID: 1452
	private GClass5.GDelegate5 gdelegate5_0;

	// Token: 0x040005AD RID: 1453
	private GClass5.GDelegate7 gdelegate7_0;

	// Token: 0x040005AE RID: 1454
	private GClass5.GDelegate6 gdelegate6_0;

	// Token: 0x0200010A RID: 266
	// (Invoke) Token: 0x06000E32 RID: 3634
	public delegate void GDelegate5(string string_0);

	// Token: 0x0200010B RID: 267
	// (Invoke) Token: 0x06000E36 RID: 3638
	public delegate void GDelegate6(string string_0, byte[] byte_0);

	// Token: 0x0200010C RID: 268
	// (Invoke) Token: 0x06000E3A RID: 3642
	public delegate void GDelegate7(string string_0, string string_1, string string_2, bool bool_0);
}
