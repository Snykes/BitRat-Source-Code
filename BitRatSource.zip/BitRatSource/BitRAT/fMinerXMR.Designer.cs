﻿// Token: 0x0200011B RID: 283
[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
public sealed partial class fMinerXMR : global::System.Windows.Forms.Form
{
	// Token: 0x06000F93 RID: 3987 RVA: 0x00073E38 File Offset: 0x00072038
	[global::System.Diagnostics.DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && this.icontainer_0 != null)
			{
				this.icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	// Token: 0x06000F94 RID: 3988 RVA: 0x00073E78 File Offset: 0x00072078
	[global::System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		this.vmethod_1(new global::System.Windows.Forms.StatusStrip());
		this.vmethod_3(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_5(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_25(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_7(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_9(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_11(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_13(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_15(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_17(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_19(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_21(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_23(new global::BrightIdeasSoftware.FastObjectListView());
		this.vmethod_49(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_77(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_79(new global::System.Windows.Forms.ContextMenuStrip(this.icontainer_0));
		this.vmethod_81(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_83(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_85(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_87(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_89(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_91(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_93(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_95(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_97(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_99(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_101(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_103(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_27(new global::System.Windows.Forms.Timer(this.icontainer_0));
		this.vmethod_29(new global::System.Windows.Forms.RadioButton());
		this.vmethod_31(new global::System.Windows.Forms.RadioButton());
		this.vmethod_33(new global::System.Windows.Forms.Label());
		this.vmethod_35(new global::System.Windows.Forms.TextBox());
		this.vmethod_37(new global::System.Windows.Forms.TextBox());
		this.vmethod_39(new global::System.Windows.Forms.Label());
		this.vmethod_41(new global::System.Windows.Forms.Label());
		this.vmethod_43(new global::System.Windows.Forms.ComboBox());
		this.vmethod_45(new global::System.Windows.Forms.ComboBox());
		this.vmethod_47(new global::System.Windows.Forms.Label());
		this.vmethod_51(new global::System.Windows.Forms.CheckBox());
		this.vmethod_53(new global::System.Windows.Forms.TextBox());
		this.vmethod_55(new global::System.Windows.Forms.Label());
		this.vmethod_57(new global::System.Windows.Forms.ComboBox());
		this.vmethod_59(new global::System.Windows.Forms.Label());
		this.vmethod_61(new global::System.Windows.Forms.CheckBox());
		this.vmethod_63(new global::System.Windows.Forms.ComboBox());
		this.vmethod_65(new global::System.Windows.Forms.Label());
		this.vmethod_67(new global::System.Windows.Forms.TextBox());
		this.vmethod_69(new global::System.Windows.Forms.Label());
		this.vmethod_71(new global::System.Windows.Forms.CheckBox());
		this.vmethod_73(new global::System.Windows.Forms.TextBox());
		this.vmethod_75(new global::System.Windows.Forms.Label());
		this.vmethod_105(new global::System.Windows.Forms.CheckBox());
		this.vmethod_107(new global::System.Windows.Forms.PictureBox());
		this.vmethod_109(new global::System.ComponentModel.BackgroundWorker());
		this.vmethod_111(new global::VisualPlus.Toolkit.Controls.Interactivity.VisualButton());
		this.vmethod_113(new global::VisualPlus.Toolkit.Controls.Interactivity.VisualButton());
		this.vmethod_115(new global::System.Windows.Forms.PictureBox());
		this.vmethod_0().SuspendLayout();
		this.vmethod_22().BeginInit();
		this.vmethod_78().SuspendLayout();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_106()).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_114()).BeginInit();
		base.SuspendLayout();
		this.vmethod_0().AutoSize = false;
		this.vmethod_0().BackColor = global::System.Drawing.Color.FromArgb(235, 237, 239);
		this.vmethod_0().ImageScalingSize = new global::System.Drawing.Size(28, 28);
		this.vmethod_0().Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_2(),
			this.vmethod_4(),
			this.vmethod_24()
		});
		this.vmethod_0().Location = new global::System.Drawing.Point(0, 488);
		this.vmethod_0().Name = "ssTransferStatus";
		this.vmethod_0().Padding = new global::System.Windows.Forms.Padding(1, 0, 7, 0);
		this.vmethod_0().Size = new global::System.Drawing.Size(1070, 19);
		this.vmethod_0().SizingGrip = false;
		this.vmethod_0().Stretch = false;
		this.vmethod_0().TabIndex = 32;
		this.vmethod_0().Text = "stStatus";
		this.vmethod_2().AutoSize = false;
		this.vmethod_2().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_2().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_2().Margin = new global::System.Windows.Forms.Padding(0, 3, 0, 0);
		this.vmethod_2().Name = "tsMinersCount";
		this.vmethod_2().Size = new global::System.Drawing.Size(140, 16);
		this.vmethod_2().Text = "Miners: 0";
		this.vmethod_2().TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
		this.vmethod_4().AutoSize = false;
		this.vmethod_4().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_4().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_4().Margin = new global::System.Windows.Forms.Padding(0, 3, 0, 0);
		this.vmethod_4().Name = "tsMinersSpeed";
		this.vmethod_4().Overflow = global::System.Windows.Forms.ToolStripItemOverflow.Never;
		this.vmethod_4().Size = new global::System.Drawing.Size(180, 16);
		this.vmethod_4().Text = "Speed: N/A";
		this.vmethod_4().TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
		this.vmethod_24().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_24().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_24().Margin = new global::System.Windows.Forms.Padding(0, 3, -4, 0);
		this.vmethod_24().Name = "tsMinersSelected";
		this.vmethod_24().Size = new global::System.Drawing.Size(746, 16);
		this.vmethod_24().Spring = true;
		this.vmethod_24().Text = "Selected clients: 0";
		this.vmethod_24().TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
		this.vmethod_6().AspectName = "SPEED";
		this.vmethod_6().Hideable = false;
		this.vmethod_6().Text = "Speed";
		this.vmethod_8().AspectName = "SHARES";
		this.vmethod_8().Hideable = false;
		this.vmethod_8().Text = "Shares";
		this.vmethod_10().AspectName = "CPU";
		this.vmethod_10().Hideable = false;
		this.vmethod_10().Text = "CPU";
		this.vmethod_12().AspectName = "OPENCL";
		this.vmethod_12().Hideable = false;
		this.vmethod_12().Text = "OpenCL";
		this.vmethod_14().AspectName = "DONATE";
		this.vmethod_14().Hideable = false;
		this.vmethod_14().Text = "Donate";
		this.vmethod_16().AspectName = "POOL";
		this.vmethod_16().Hideable = false;
		this.vmethod_16().Text = "Pool";
		this.vmethod_18().AspectName = "THREADS";
		this.vmethod_18().Hideable = false;
		this.vmethod_18().Text = "Threads";
		this.vmethod_20().AspectName = "USER";
		this.vmethod_20().Hideable = false;
		this.vmethod_20().Text = "User";
		this.vmethod_22().Alignment = global::System.Windows.Forms.ListViewAlignment.Left;
		this.vmethod_22().AllColumns.Add(this.vmethod_20());
		this.vmethod_22().AllColumns.Add(this.vmethod_18());
		this.vmethod_22().AllColumns.Add(this.vmethod_16());
		this.vmethod_22().AllColumns.Add(this.vmethod_48());
		this.vmethod_22().AllColumns.Add(this.vmethod_12());
		this.vmethod_22().AllColumns.Add(this.vmethod_10());
		this.vmethod_22().AllColumns.Add(this.vmethod_8());
		this.vmethod_22().AllColumns.Add(this.vmethod_14());
		this.vmethod_22().AllColumns.Add(this.vmethod_6());
		this.vmethod_22().AllColumns.Add(this.vmethod_76());
		this.vmethod_22().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_22().AutoArrange = false;
		this.vmethod_22().BorderStyle = global::System.Windows.Forms.BorderStyle.None;
		this.vmethod_22().CellEditUseWholeCell = false;
		this.vmethod_22().Columns.AddRange(new global::System.Windows.Forms.ColumnHeader[]
		{
			this.vmethod_20(),
			this.vmethod_18(),
			this.vmethod_16(),
			this.vmethod_48(),
			this.vmethod_12(),
			this.vmethod_10(),
			this.vmethod_8(),
			this.vmethod_14(),
			this.vmethod_6(),
			this.vmethod_76()
		});
		this.vmethod_22().ContextMenuStrip = this.vmethod_78();
		this.vmethod_22().Cursor = global::System.Windows.Forms.Cursors.Default;
		this.vmethod_22().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.142858f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_22().FullRowSelect = true;
		this.vmethod_22().HeaderStyle = global::System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
		this.vmethod_22().HideSelection = false;
		this.vmethod_22().Location = new global::System.Drawing.Point(0, 1);
		this.vmethod_22().Margin = new global::System.Windows.Forms.Padding(1);
		this.vmethod_22().Name = "lvMiners";
		this.vmethod_22().ShowGroups = false;
		this.vmethod_22().Size = new global::System.Drawing.Size(1070, 415);
		this.vmethod_22().TabIndex = 31;
		this.vmethod_22().UseCellFormatEvents = true;
		this.vmethod_22().UseCompatibleStateImageBehavior = false;
		this.vmethod_22().UseHotControls = false;
		this.vmethod_22().UseOverlays = false;
		this.vmethod_22().View = global::System.Windows.Forms.View.Details;
		this.vmethod_22().VirtualMode = true;
		this.vmethod_48().AspectName = "ALGO";
		this.vmethod_48().Hideable = false;
		this.vmethod_48().Text = "Algorithm";
		this.vmethod_76().AspectName = "DURATION";
		this.vmethod_76().Hideable = false;
		this.vmethod_76().Text = "Duration";
		this.vmethod_78().ImageScalingSize = new global::System.Drawing.Size(24, 24);
		this.vmethod_78().Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_80(),
			this.vmethod_88(),
			this.vmethod_90(),
			this.vmethod_94(),
			this.vmethod_96()
		});
		this.vmethod_78().Name = "ContextMenuStrip1";
		this.vmethod_78().Size = new global::System.Drawing.Size(170, 82);
		this.vmethod_80().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_82(),
			this.vmethod_84(),
			this.vmethod_86()
		});
		this.vmethod_80().Name = "LogsToolStripMenuItem";
		this.vmethod_80().Size = new global::System.Drawing.Size(169, 22);
		this.vmethod_80().Text = "Logs";
		this.vmethod_82().Name = "DownloadToolStripMenuItem";
		this.vmethod_82().Size = new global::System.Drawing.Size(176, 22);
		this.vmethod_82().Text = "Download";
		this.vmethod_84().Name = "ToolStripMenuItem1";
		this.vmethod_84().Size = new global::System.Drawing.Size(173, 6);
		this.vmethod_86().Name = "OpenLogManagerToolStripMenuItem";
		this.vmethod_86().Size = new global::System.Drawing.Size(176, 22);
		this.vmethod_86().Text = "Open Log manager";
		this.vmethod_88().Name = "ToolStripMenuItem3";
		this.vmethod_88().Size = new global::System.Drawing.Size(166, 6);
		this.vmethod_90().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_92()
		});
		this.vmethod_90().Name = "OperationsToolStripMenuItem";
		this.vmethod_90().Size = new global::System.Drawing.Size(169, 22);
		this.vmethod_90().Text = "Operations";
		this.vmethod_92().Name = "StopToolStripMenuItem";
		this.vmethod_92().Size = new global::System.Drawing.Size(98, 22);
		this.vmethod_92().Text = "Stop";
		this.vmethod_94().Name = "ToolStripMenuItem2";
		this.vmethod_94().Size = new global::System.Drawing.Size(166, 6);
		this.vmethod_96().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_98(),
			this.vmethod_100(),
			this.vmethod_102()
		});
		this.vmethod_96().Name = "CopyToClipboardToolStripMenuItem";
		this.vmethod_96().Size = new global::System.Drawing.Size(169, 22);
		this.vmethod_96().Text = "Copy to clipboard";
		this.vmethod_98().Name = "SelectedToolStripMenuItem";
		this.vmethod_98().Size = new global::System.Drawing.Size(118, 22);
		this.vmethod_98().Text = "Selected";
		this.vmethod_100().Name = "ToolStripMenuItem4";
		this.vmethod_100().Size = new global::System.Drawing.Size(115, 6);
		this.vmethod_102().Name = "AllToolStripMenuItem";
		this.vmethod_102().Size = new global::System.Drawing.Size(118, 22);
		this.vmethod_102().Text = "All";
		this.vmethod_26().Enabled = true;
		this.vmethod_26().Interval = 1000;
		this.vmethod_28().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_28().AutoSize = true;
		this.vmethod_28().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_28().Checked = true;
		this.vmethod_28().Location = new global::System.Drawing.Point(8, 461);
		this.vmethod_28().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_28().Name = "rbAll";
		this.vmethod_28().Size = new global::System.Drawing.Size(36, 17);
		this.vmethod_28().TabIndex = 35;
		this.vmethod_28().TabStop = true;
		this.vmethod_28().Text = "All";
		this.vmethod_28().UseVisualStyleBackColor = false;
		this.vmethod_30().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_30().AutoSize = true;
		this.vmethod_30().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_30().Location = new global::System.Drawing.Point(46, 461);
		this.vmethod_30().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_30().Name = "rbSelected";
		this.vmethod_30().Size = new global::System.Drawing.Size(122, 17);
		this.vmethod_30().TabIndex = 36;
		this.vmethod_30().Text = "Only selected clients";
		this.vmethod_30().UseVisualStyleBackColor = false;
		this.vmethod_32().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_32().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_32().Location = new global::System.Drawing.Point(182, 430);
		this.vmethod_32().Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
		this.vmethod_32().Name = "lblPool";
		this.vmethod_32().Size = new global::System.Drawing.Size(57, 13);
		this.vmethod_32().TabIndex = 37;
		this.vmethod_32().Text = "Pool:";
		this.vmethod_32().TextAlign = global::System.Drawing.ContentAlignment.TopRight;
		this.vmethod_34().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_34().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8f, global::System.Drawing.FontStyle.Italic, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_34().ForeColor = global::System.Drawing.Color.Gray;
		this.vmethod_34().Location = new global::System.Drawing.Point(243, 428);
		this.vmethod_34().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_34().Name = "txtPool";
		this.vmethod_34().Size = new global::System.Drawing.Size(191, 20);
		this.vmethod_34().TabIndex = 38;
		this.vmethod_34().Text = "example-pool.com:5555";
		this.vmethod_36().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_36().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8f, global::System.Drawing.FontStyle.Italic, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_36().ForeColor = global::System.Drawing.Color.Gray;
		this.vmethod_36().Location = new global::System.Drawing.Point(243, 448);
		this.vmethod_36().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_36().Name = "txtUsername";
		this.vmethod_36().Size = new global::System.Drawing.Size(191, 20);
		this.vmethod_36().TabIndex = 40;
		this.vmethod_36().Text = "Username/wallet address";
		this.vmethod_38().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_38().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_38().Location = new global::System.Drawing.Point(179, 450);
		this.vmethod_38().Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
		this.vmethod_38().Name = "lblUsername";
		this.vmethod_38().Size = new global::System.Drawing.Size(60, 13);
		this.vmethod_38().TabIndex = 39;
		this.vmethod_38().Text = "Username:";
		this.vmethod_38().TextAlign = global::System.Drawing.ContentAlignment.TopRight;
		this.vmethod_40().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_40().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_40().Location = new global::System.Drawing.Point(435, 427);
		this.vmethod_40().Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
		this.vmethod_40().Name = "lblAlgo";
		this.vmethod_40().Size = new global::System.Drawing.Size(60, 13);
		this.vmethod_40().TabIndex = 41;
		this.vmethod_40().Text = "Algorithm:";
		this.vmethod_40().TextAlign = global::System.Drawing.ContentAlignment.TopRight;
		this.vmethod_42().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_42().BackColor = global::System.Drawing.Color.White;
		this.vmethod_42().DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.vmethod_42().ForeColor = global::System.Drawing.Color.Black;
		this.vmethod_42().FormattingEnabled = true;
		this.vmethod_42().ImeMode = global::System.Windows.Forms.ImeMode.NoControl;
		this.vmethod_42().Location = new global::System.Drawing.Point(499, 425);
		this.vmethod_42().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_42().Name = "cbAlgo";
		this.vmethod_42().Size = new global::System.Drawing.Size(77, 21);
		this.vmethod_42().TabIndex = 43;
		this.vmethod_42().TabStop = false;
		this.vmethod_44().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_44().BackColor = global::System.Drawing.Color.White;
		this.vmethod_44().DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.vmethod_44().ForeColor = global::System.Drawing.Color.Black;
		this.vmethod_44().FormattingEnabled = true;
		this.vmethod_44().ImeMode = global::System.Windows.Forms.ImeMode.NoControl;
		this.vmethod_44().Location = new global::System.Drawing.Point(499, 447);
		this.vmethod_44().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_44().Name = "cbThreads";
		this.vmethod_44().Size = new global::System.Drawing.Size(77, 21);
		this.vmethod_44().TabIndex = 45;
		this.vmethod_44().TabStop = false;
		this.vmethod_46().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_46().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_46().Location = new global::System.Drawing.Point(446, 449);
		this.vmethod_46().Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
		this.vmethod_46().Name = "lblThreads";
		this.vmethod_46().Size = new global::System.Drawing.Size(49, 13);
		this.vmethod_46().TabIndex = 44;
		this.vmethod_46().Text = "Threads:";
		this.vmethod_46().TextAlign = global::System.Drawing.ContentAlignment.TopRight;
		this.vmethod_50().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_50().AutoSize = true;
		this.vmethod_50().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_50().Location = new global::System.Drawing.Point(847, 470);
		this.vmethod_50().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_50().Name = "chkNicehash";
		this.vmethod_50().Size = new global::System.Drawing.Size(71, 17);
		this.vmethod_50().TabIndex = 46;
		this.vmethod_50().TabStop = false;
		this.vmethod_50().Text = "Nicehash";
		this.vmethod_50().UseVisualStyleBackColor = false;
		this.vmethod_52().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_52().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8f, global::System.Drawing.FontStyle.Italic, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_52().ForeColor = global::System.Drawing.Color.Gray;
		this.vmethod_52().Location = new global::System.Drawing.Point(243, 469);
		this.vmethod_52().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_52().Name = "txtPassword";
		this.vmethod_52().Size = new global::System.Drawing.Size(191, 20);
		this.vmethod_52().TabIndex = 48;
		this.vmethod_52().Text = "(Optional)";
		this.vmethod_54().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_54().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_54().Location = new global::System.Drawing.Point(182, 471);
		this.vmethod_54().Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
		this.vmethod_54().Name = "lblPassword";
		this.vmethod_54().Size = new global::System.Drawing.Size(57, 13);
		this.vmethod_54().TabIndex = 47;
		this.vmethod_54().Text = "Password:";
		this.vmethod_54().TextAlign = global::System.Drawing.ContentAlignment.TopRight;
		this.vmethod_56().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_56().BackColor = global::System.Drawing.Color.White;
		this.vmethod_56().DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.vmethod_56().ForeColor = global::System.Drawing.Color.Black;
		this.vmethod_56().FormattingEnabled = true;
		this.vmethod_56().ImeMode = global::System.Windows.Forms.ImeMode.NoControl;
		this.vmethod_56().Location = new global::System.Drawing.Point(499, 469);
		this.vmethod_56().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_56().Name = "cbDonate";
		this.vmethod_56().Size = new global::System.Drawing.Size(77, 21);
		this.vmethod_56().TabIndex = 52;
		this.vmethod_56().TabStop = false;
		this.vmethod_58().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_58().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_58().Location = new global::System.Drawing.Point(446, 471);
		this.vmethod_58().Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
		this.vmethod_58().Name = "lblDonate";
		this.vmethod_58().Size = new global::System.Drawing.Size(49, 13);
		this.vmethod_58().TabIndex = 51;
		this.vmethod_58().Text = "Donate:";
		this.vmethod_58().TextAlign = global::System.Drawing.ContentAlignment.TopRight;
		this.vmethod_60().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_60().AutoSize = true;
		this.vmethod_60().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_60().Checked = true;
		this.vmethod_60().CheckState = global::System.Windows.Forms.CheckState.Checked;
		this.vmethod_60().Location = new global::System.Drawing.Point(675, 470);
		this.vmethod_60().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_60().Name = "chkKeepalive";
		this.vmethod_60().Size = new global::System.Drawing.Size(73, 17);
		this.vmethod_60().TabIndex = 53;
		this.vmethod_60().TabStop = false;
		this.vmethod_60().Text = "Keepalive";
		this.vmethod_60().UseVisualStyleBackColor = false;
		this.vmethod_62().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_62().BackColor = global::System.Drawing.Color.White;
		this.vmethod_62().DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.vmethod_62().ForeColor = global::System.Drawing.Color.Black;
		this.vmethod_62().FormattingEnabled = true;
		this.vmethod_62().ImeMode = global::System.Windows.Forms.ImeMode.NoControl;
		this.vmethod_62().Location = new global::System.Drawing.Point(675, 425);
		this.vmethod_62().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_62().Name = "cbProcessPriority";
		this.vmethod_62().Size = new global::System.Drawing.Size(93, 21);
		this.vmethod_62().TabIndex = 55;
		this.vmethod_62().TabStop = false;
		this.vmethod_64().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_64().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_64().Location = new global::System.Drawing.Point(579, 427);
		this.vmethod_64().Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
		this.vmethod_64().Name = "lblProcessPriority";
		this.vmethod_64().Size = new global::System.Drawing.Size(93, 13);
		this.vmethod_64().TabIndex = 54;
		this.vmethod_64().Text = "Process priority:";
		this.vmethod_64().TextAlign = global::System.Drawing.ContentAlignment.TopRight;
		this.vmethod_66().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_66().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8f, global::System.Drawing.FontStyle.Italic, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_66().ForeColor = global::System.Drawing.Color.Gray;
		this.vmethod_66().Location = new global::System.Drawing.Point(675, 448);
		this.vmethod_66().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_66().Name = "txtUserAgent";
		this.vmethod_66().Size = new global::System.Drawing.Size(348, 20);
		this.vmethod_66().TabIndex = 57;
		this.vmethod_66().Text = "(Optional)";
		this.vmethod_68().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_68().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_68().Location = new global::System.Drawing.Point(605, 451);
		this.vmethod_68().Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
		this.vmethod_68().Name = "lblUserAgent";
		this.vmethod_68().Size = new global::System.Drawing.Size(67, 13);
		this.vmethod_68().TabIndex = 56;
		this.vmethod_68().Text = "User-Agent:";
		this.vmethod_68().TextAlign = global::System.Drawing.ContentAlignment.TopRight;
		this.vmethod_70().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_70().AutoSize = true;
		this.vmethod_70().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_70().Location = new global::System.Drawing.Point(748, 470);
		this.vmethod_70().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_70().Name = "chkHugePages";
		this.vmethod_70().Size = new global::System.Drawing.Size(99, 17);
		this.vmethod_70().TabIndex = 58;
		this.vmethod_70().TabStop = false;
		this.vmethod_70().Text = "No huge pages";
		this.vmethod_70().UseVisualStyleBackColor = false;
		this.vmethod_72().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_72().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8f, global::System.Drawing.FontStyle.Italic, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_72().ForeColor = global::System.Drawing.Color.Gray;
		this.vmethod_72().Location = new global::System.Drawing.Point(826, 428);
		this.vmethod_72().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_72().Name = "txtRigID";
		this.vmethod_72().Size = new global::System.Drawing.Size(197, 20);
		this.vmethod_72().TabIndex = 60;
		this.vmethod_72().Text = "(Optional)";
		this.vmethod_74().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_74().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_74().Location = new global::System.Drawing.Point(783, 430);
		this.vmethod_74().Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
		this.vmethod_74().Name = "lblRigID";
		this.vmethod_74().Size = new global::System.Drawing.Size(39, 13);
		this.vmethod_74().TabIndex = 59;
		this.vmethod_74().Text = "Rig ID:";
		this.vmethod_74().TextAlign = global::System.Drawing.ContentAlignment.TopRight;
		this.vmethod_104().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_104().AutoSize = true;
		this.vmethod_104().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_104().Location = new global::System.Drawing.Point(922, 470);
		this.vmethod_104().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_104().Name = "chk64bit";
		this.vmethod_104().Size = new global::System.Drawing.Size(52, 17);
		this.vmethod_104().TabIndex = 61;
		this.vmethod_104().TabStop = false;
		this.vmethod_104().Text = "64-bit";
		this.vmethod_104().UseVisualStyleBackColor = false;
		this.vmethod_106().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_106().Image = global::Class131.smethod_24();
		this.vmethod_106().Location = new global::System.Drawing.Point(978, 469);
		this.vmethod_106().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_106().Name = "chkMiner64";
		this.vmethod_106().Size = new global::System.Drawing.Size(15, 15);
		this.vmethod_106().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_106().TabIndex = 80;
		this.vmethod_106().TabStop = false;
		this.vmethod_110().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_110().BackColorState.Disabled = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_110().BackColorState.Enabled = global::System.Drawing.Color.FromArgb(220, 220, 220);
		this.vmethod_110().BackColorState.Hover = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_110().BackColorState.Pressed = global::System.Drawing.Color.FromArgb(192, 192, 192);
		this.vmethod_110().Border.Color = global::System.Drawing.Color.FromArgb(180, 180, 180);
		this.vmethod_110().Border.HoverColor = global::System.Drawing.Color.FromArgb(120, 183, 230);
		this.vmethod_110().Border.HoverVisible = true;
		this.vmethod_110().Border.Rounding = 6;
		this.vmethod_110().Border.Thickness = 1;
		this.vmethod_110().Border.Type = 1;
		this.vmethod_110().Border.Visible = true;
		this.vmethod_110().DialogResult = global::System.Windows.Forms.DialogResult.None;
		this.vmethod_110().ForeColor = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_110().Image = null;
		this.vmethod_110().Location = new global::System.Drawing.Point(75, 429);
		this.vmethod_110().MouseState = 0;
		this.vmethod_110().Name = "btnStop";
		this.vmethod_110().Size = new global::System.Drawing.Size(61, 30);
		this.vmethod_110().TabIndex = 95;
		this.vmethod_110().Text = "Stop";
		this.vmethod_110().TextImageRelation = global::System.Windows.Forms.TextImageRelation.Overlay;
		this.vmethod_110().TextStyle.Disabled = global::System.Drawing.Color.FromArgb(131, 129, 129);
		this.vmethod_110().TextStyle.Enabled = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_110().TextStyle.Hover = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_110().TextStyle.Pressed = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_110().TextStyle.TextAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_110().TextStyle.TextLineAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_110().TextStyle.TextRenderingHint = global::System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
		this.vmethod_112().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_112().BackColorState.Disabled = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_112().BackColorState.Enabled = global::System.Drawing.Color.FromArgb(220, 220, 220);
		this.vmethod_112().BackColorState.Hover = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_112().BackColorState.Pressed = global::System.Drawing.Color.FromArgb(192, 192, 192);
		this.vmethod_112().Border.Color = global::System.Drawing.Color.FromArgb(180, 180, 180);
		this.vmethod_112().Border.HoverColor = global::System.Drawing.Color.FromArgb(120, 183, 230);
		this.vmethod_112().Border.HoverVisible = true;
		this.vmethod_112().Border.Rounding = 6;
		this.vmethod_112().Border.Thickness = 1;
		this.vmethod_112().Border.Type = 1;
		this.vmethod_112().Border.Visible = true;
		this.vmethod_112().DialogResult = global::System.Windows.Forms.DialogResult.None;
		this.vmethod_112().ForeColor = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_112().Image = null;
		this.vmethod_112().Location = new global::System.Drawing.Point(8, 429);
		this.vmethod_112().MouseState = 0;
		this.vmethod_112().Name = "btnStart";
		this.vmethod_112().Size = new global::System.Drawing.Size(61, 30);
		this.vmethod_112().TabIndex = 94;
		this.vmethod_112().Text = "Start";
		this.vmethod_112().TextImageRelation = global::System.Windows.Forms.TextImageRelation.Overlay;
		this.vmethod_112().TextStyle.Disabled = global::System.Drawing.Color.FromArgb(131, 129, 129);
		this.vmethod_112().TextStyle.Enabled = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_112().TextStyle.Hover = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_112().TextStyle.Pressed = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_112().TextStyle.TextAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_112().TextStyle.TextLineAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_112().TextStyle.TextRenderingHint = global::System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
		this.vmethod_114().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_114().Image = global::Class131.smethod_24();
		this.vmethod_114().Location = new global::System.Drawing.Point(580, 450);
		this.vmethod_114().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_114().Name = "pbXMRThreads";
		this.vmethod_114().Size = new global::System.Drawing.Size(15, 15);
		this.vmethod_114().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_114().TabIndex = 96;
		this.vmethod_114().TabStop = false;
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new global::System.Drawing.Size(1070, 507);
		base.Controls.Add(this.vmethod_114());
		base.Controls.Add(this.vmethod_110());
		base.Controls.Add(this.vmethod_112());
		base.Controls.Add(this.vmethod_106());
		base.Controls.Add(this.vmethod_104());
		base.Controls.Add(this.vmethod_72());
		base.Controls.Add(this.vmethod_74());
		base.Controls.Add(this.vmethod_70());
		base.Controls.Add(this.vmethod_66());
		base.Controls.Add(this.vmethod_68());
		base.Controls.Add(this.vmethod_62());
		base.Controls.Add(this.vmethod_64());
		base.Controls.Add(this.vmethod_60());
		base.Controls.Add(this.vmethod_56());
		base.Controls.Add(this.vmethod_58());
		base.Controls.Add(this.vmethod_52());
		base.Controls.Add(this.vmethod_54());
		base.Controls.Add(this.vmethod_50());
		base.Controls.Add(this.vmethod_44());
		base.Controls.Add(this.vmethod_46());
		base.Controls.Add(this.vmethod_42());
		base.Controls.Add(this.vmethod_40());
		base.Controls.Add(this.vmethod_36());
		base.Controls.Add(this.vmethod_38());
		base.Controls.Add(this.vmethod_34());
		base.Controls.Add(this.vmethod_32());
		base.Controls.Add(this.vmethod_30());
		base.Controls.Add(this.vmethod_28());
		base.Controls.Add(this.vmethod_0());
		base.Controls.Add(this.vmethod_22());
		this.DoubleBuffered = true;
		base.Margin = new global::System.Windows.Forms.Padding(2);
		base.Name = "fMinerXMR";
		base.Opacity = 0.0;
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterParent;
		this.Text = "XMR Mining";
		this.vmethod_0().ResumeLayout(false);
		this.vmethod_0().PerformLayout();
		this.vmethod_22().EndInit();
		this.vmethod_78().ResumeLayout(false);
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_106()).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_114()).EndInit();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x0400061C RID: 1564
	private global::System.ComponentModel.IContainer icontainer_0;
}
