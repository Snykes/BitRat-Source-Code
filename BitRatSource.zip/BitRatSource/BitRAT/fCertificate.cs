﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using VisualPlus.Toolkit.Controls.Interactivity;

// Token: 0x020001B8 RID: 440
[DesignerGenerated]
public sealed partial class fCertificate : Form
{
	// Token: 0x0600182F RID: 6191 RVA: 0x0000C48A File Offset: 0x0000A68A
	public fCertificate()
	{
		base.Load += this.fCertificate_Load;
		base.Closing += this.fCertificate_Closing;
		this.InitializeComponent();
	}

	// Token: 0x06001832 RID: 6194 RVA: 0x0000C4BC File Offset: 0x0000A6BC
	internal Label vmethod_0()
	{
		return this.label_0;
	}

	// Token: 0x06001833 RID: 6195 RVA: 0x0000C4C4 File Offset: 0x0000A6C4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_1(Label label_6)
	{
		this.label_0 = label_6;
	}

	// Token: 0x06001834 RID: 6196 RVA: 0x0000C4CD File Offset: 0x0000A6CD
	internal Label vmethod_2()
	{
		return this.label_1;
	}

	// Token: 0x06001835 RID: 6197 RVA: 0x0000C4D5 File Offset: 0x0000A6D5
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_3(Label label_6)
	{
		this.label_1 = label_6;
	}

	// Token: 0x06001836 RID: 6198 RVA: 0x0000C4DE File Offset: 0x0000A6DE
	internal ComboBox vmethod_4()
	{
		return this.comboBox_0;
	}

	// Token: 0x06001837 RID: 6199 RVA: 0x0000C4E6 File Offset: 0x0000A6E6
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_5(ComboBox comboBox_2)
	{
		this.comboBox_0 = comboBox_2;
	}

	// Token: 0x06001838 RID: 6200 RVA: 0x0000C4EF File Offset: 0x0000A6EF
	internal Label vmethod_6()
	{
		return this.label_2;
	}

	// Token: 0x06001839 RID: 6201 RVA: 0x0000C4F7 File Offset: 0x0000A6F7
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_7(Label label_6)
	{
		this.label_2 = label_6;
	}

	// Token: 0x0600183A RID: 6202 RVA: 0x0000C500 File Offset: 0x0000A700
	internal ComboBox vmethod_8()
	{
		return this.comboBox_1;
	}

	// Token: 0x0600183B RID: 6203 RVA: 0x0000C508 File Offset: 0x0000A708
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_9(ComboBox comboBox_2)
	{
		this.comboBox_1 = comboBox_2;
	}

	// Token: 0x0600183C RID: 6204 RVA: 0x0000C511 File Offset: 0x0000A711
	internal Label vmethod_10()
	{
		return this.label_3;
	}

	// Token: 0x0600183D RID: 6205 RVA: 0x0000C519 File Offset: 0x0000A719
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_11(Label label_6)
	{
		this.label_3 = label_6;
	}

	// Token: 0x0600183E RID: 6206 RVA: 0x0000C522 File Offset: 0x0000A722
	internal Label vmethod_12()
	{
		return this.label_4;
	}

	// Token: 0x0600183F RID: 6207 RVA: 0x0000C52A File Offset: 0x0000A72A
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_13(Label label_6)
	{
		this.label_4 = label_6;
	}

	// Token: 0x06001840 RID: 6208 RVA: 0x0000C533 File Offset: 0x0000A733
	internal TextBox vmethod_14()
	{
		return this.textBox_0;
	}

	// Token: 0x06001841 RID: 6209 RVA: 0x0000C53B File Offset: 0x0000A73B
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_15(TextBox textBox_1)
	{
		this.textBox_0 = textBox_1;
	}

	// Token: 0x06001842 RID: 6210 RVA: 0x0000C544 File Offset: 0x0000A744
	internal Timer vmethod_16()
	{
		return this.timer_0;
	}

	// Token: 0x06001843 RID: 6211 RVA: 0x000B15B8 File Offset: 0x000AF7B8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_17(Timer timer_2)
	{
		EventHandler value = new EventHandler(this.method_7);
		Timer timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_0 = timer_2;
		timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x06001844 RID: 6212 RVA: 0x0000C54C File Offset: 0x0000A74C
	internal Label vmethod_18()
	{
		return this.label_5;
	}

	// Token: 0x06001845 RID: 6213 RVA: 0x0000C554 File Offset: 0x0000A754
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_19(Label label_6)
	{
		this.label_5 = label_6;
	}

	// Token: 0x06001846 RID: 6214 RVA: 0x0000C55D File Offset: 0x0000A75D
	internal PictureBox vmethod_20()
	{
		return this.pictureBox_0;
	}

	// Token: 0x06001847 RID: 6215 RVA: 0x000B15FC File Offset: 0x000AF7FC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_21(PictureBox pictureBox_1)
	{
		EventHandler value = new EventHandler(this.method_1);
		PictureBox pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_0 = pictureBox_1;
		pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06001848 RID: 6216 RVA: 0x0000C565 File Offset: 0x0000A765
	internal VisualButton vmethod_22()
	{
		return this.visualButton_0;
	}

	// Token: 0x06001849 RID: 6217 RVA: 0x000B1640 File Offset: 0x000AF840
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_23(VisualButton visualButton_1)
	{
		EventHandler value = new EventHandler(this.method_2);
		VisualButton visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_0 = visualButton_1;
		visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x0600184A RID: 6218 RVA: 0x0000C56D File Offset: 0x0000A76D
	internal Timer vmethod_24()
	{
		return this.timer_1;
	}

	// Token: 0x0600184B RID: 6219 RVA: 0x000B1684 File Offset: 0x000AF884
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_25(Timer timer_2)
	{
		EventHandler value = new EventHandler(this.method_6);
		Timer timer = this.timer_1;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_1 = timer_2;
		timer = this.timer_1;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x0600184C RID: 6220 RVA: 0x0000C575 File Offset: 0x0000A775
	private void fCertificate_Load(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x0600184D RID: 6221 RVA: 0x000B16C8 File Offset: 0x000AF8C8
	public void method_0()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O='*?73`", object_);
	}

	// Token: 0x0600184E RID: 6222 RVA: 0x000B16F8 File Offset: 0x000AF8F8
	private void fCertificate_Closing(object sender, CancelEventArgs e)
	{
		if (this.bool_0)
		{
			Interaction.MsgBox("Please wait while " + Application.ProductName + " creates a new certificate!", MsgBoxStyle.Exclamation, Application.ProductName);
			e.Cancel = true;
			return;
		}
		base.Visible = false;
		e.Cancel = true;
	}

	// Token: 0x0600184F RID: 6223 RVA: 0x0000C57D File Offset: 0x0000A77D
	private void method_1(object sender, EventArgs e)
	{
		Interaction.MsgBox("An SSL certificate is a digital certificate that provides authentication for your socket and enables an encrypted connection.\r\nThe SSL certificate ensures that your clients know who they communicate with and keeping the connection secure between you.", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06001850 RID: 6224 RVA: 0x000B1744 File Offset: 0x000AF944
	private void method_2(object sender, EventArgs e)
	{
		object[] object_ = new object[]
		{
			this,
			sender,
			e
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O;e*?8!!", object_);
	}

	// Token: 0x06001851 RID: 6225 RVA: 0x000B177C File Offset: 0x000AF97C
	private void method_3()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O;$*?6pX", object_);
	}

	// Token: 0x06001852 RID: 6226 RVA: 0x000B17AC File Offset: 0x000AF9AC
	public void method_4()
	{
		try
		{
			if (this.vmethod_22().InvokeRequired)
			{
				this.vmethod_22().Invoke(new fCertificate.Delegate184(this.method_4), new object[0]);
			}
			else if (this.bool_0)
			{
				string text = this.vmethod_22().Text;
				if (Operators.CompareString(text, "Please wait", true) == 0)
				{
					this.vmethod_22().Text = "Please wait.";
				}
				else if (Operators.CompareString(text, "Please wait.", true) == 0)
				{
					this.vmethod_22().Text = "Please wait..";
				}
				else if (Operators.CompareString(text, "Please wait..", true) == 0)
				{
					this.vmethod_22().Text = "Please wait...";
				}
				else if (Operators.CompareString(text, "Please wait...", true) == 0)
				{
					this.vmethod_22().Text = "Please wait";
				}
				this.vmethod_22().Refresh();
			}
			else
			{
				this.vmethod_22().Text = "Completed";
				this.vmethod_22().Refresh();
				this.vmethod_24().Enabled = false;
				base.TopMost = false;
				if (Class130.fSettings_0.Visible)
				{
					Class130.fSettings_0.TopMost = false;
				}
				Interaction.MsgBox("Certificate was successfully created!\r\n\r\nYou may now close this window.", MsgBoxStyle.Information, Application.ProductName);
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x06001853 RID: 6227 RVA: 0x000B1910 File Offset: 0x000AFB10
	public void method_5()
	{
		try
		{
			if (this.vmethod_2().InvokeRequired)
			{
				this.vmethod_2().Invoke(new fCertificate.Delegate183(this.method_5), new object[0]);
			}
			else
			{
				this.vmethod_2().Visible = (this.vmethod_8().SelectedIndex == 2);
				this.vmethod_0().Visible = (this.vmethod_4().SelectedIndex == 1);
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x06001854 RID: 6228 RVA: 0x0000C591 File Offset: 0x0000A791
	private void method_6(object sender, EventArgs e)
	{
		this.method_4();
	}

	// Token: 0x06001855 RID: 6229 RVA: 0x0000C599 File Offset: 0x0000A799
	private void method_7(object sender, EventArgs e)
	{
		this.method_5();
	}

	// Token: 0x04000900 RID: 2304
	private Label label_0;

	// Token: 0x04000901 RID: 2305
	private Label label_1;

	// Token: 0x04000902 RID: 2306
	private ComboBox comboBox_0;

	// Token: 0x04000903 RID: 2307
	private Label label_2;

	// Token: 0x04000904 RID: 2308
	private ComboBox comboBox_1;

	// Token: 0x04000905 RID: 2309
	private Label label_3;

	// Token: 0x04000906 RID: 2310
	private Label label_4;

	// Token: 0x04000907 RID: 2311
	private TextBox textBox_0;

	// Token: 0x04000908 RID: 2312
	private Timer timer_0;

	// Token: 0x04000909 RID: 2313
	private Label label_5;

	// Token: 0x0400090A RID: 2314
	private PictureBox pictureBox_0;

	// Token: 0x0400090B RID: 2315
	private VisualButton visualButton_0;

	// Token: 0x0400090C RID: 2316
	private Timer timer_1;

	// Token: 0x0400090D RID: 2317
	private bool bool_0;

	// Token: 0x0400090E RID: 2318
	private string string_0;

	// Token: 0x0400090F RID: 2319
	private string string_1;

	// Token: 0x04000910 RID: 2320
	private int int_0;

	// Token: 0x020001B9 RID: 441
	// (Invoke) Token: 0x0600185A RID: 6234
	private delegate void Delegate183();

	// Token: 0x020001BA RID: 442
	// (Invoke) Token: 0x0600185E RID: 6238
	private delegate void Delegate184();
}
