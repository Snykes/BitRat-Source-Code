﻿// Token: 0x02000100 RID: 256
[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
public sealed partial class fDDOS : global::System.Windows.Forms.Form
{
	// Token: 0x06000D6F RID: 3439 RVA: 0x00067E38 File Offset: 0x00066038
	[global::System.Diagnostics.DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && this.icontainer_0 != null)
			{
				this.icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	// Token: 0x06000D70 RID: 3440 RVA: 0x00067E78 File Offset: 0x00066078
	[global::System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		this.vmethod_1(new global::VisualPlus.Toolkit.Controls.Interactivity.VisualButton());
		this.vmethod_3(new global::VisualPlus.Toolkit.Controls.Interactivity.VisualButton());
		this.vmethod_5(new global::System.ComponentModel.BackgroundWorker());
		this.vmethod_7(new global::System.Windows.Forms.ComboBox());
		this.vmethod_9(new global::System.Windows.Forms.Label());
		this.vmethod_11(new global::System.Windows.Forms.ComboBox());
		this.vmethod_13(new global::System.Windows.Forms.Label());
		this.vmethod_15(new global::System.Windows.Forms.TextBox());
		this.vmethod_17(new global::System.Windows.Forms.Label());
		this.vmethod_19(new global::System.Windows.Forms.TextBox());
		this.vmethod_21(new global::System.Windows.Forms.Label());
		this.vmethod_23(new global::System.Windows.Forms.RadioButton());
		this.vmethod_25(new global::System.Windows.Forms.RadioButton());
		this.vmethod_27(new global::System.Windows.Forms.Timer(this.icontainer_0));
		this.vmethod_29(new global::System.Windows.Forms.StatusStrip());
		this.vmethod_31(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_107(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_33(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_35(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_37(new global::System.Windows.Forms.ToolStripStatusLabel());
		this.vmethod_39(new global::BrightIdeasSoftware.FastObjectListView());
		this.vmethod_41(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_45(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_47(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_49(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_51(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_43(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_105(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_53(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_55(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_75(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_103(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_101(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_57(new global::BrightIdeasSoftware.OLVColumn());
		this.vmethod_59(new global::System.Windows.Forms.ContextMenuStrip(this.icontainer_0));
		this.vmethod_61(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_63(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_65(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_67(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_69(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_71(new global::System.Windows.Forms.ToolStripSeparator());
		this.vmethod_73(new global::System.Windows.Forms.ToolStripMenuItem());
		this.vmethod_77(new global::System.Windows.Forms.ComboBox());
		this.vmethod_79(new global::System.Windows.Forms.Label());
		this.vmethod_81(new global::System.Windows.Forms.Label());
		this.vmethod_83(new global::System.Windows.Forms.TextBox());
		this.vmethod_85(new global::System.Windows.Forms.PictureBox());
		this.vmethod_87(new global::System.Windows.Forms.ComboBox());
		this.vmethod_89(new global::System.Windows.Forms.Label());
		this.vmethod_91(new global::System.Windows.Forms.PictureBox());
		this.vmethod_93(new global::System.Windows.Forms.Label());
		this.vmethod_95(new global::System.Windows.Forms.TextBox());
		this.vmethod_97(new global::System.Windows.Forms.Label());
		this.vmethod_99(new global::System.Windows.Forms.PictureBox());
		this.vmethod_28().SuspendLayout();
		this.vmethod_38().BeginInit();
		this.vmethod_58().SuspendLayout();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_84()).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_90()).BeginInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_98()).BeginInit();
		base.SuspendLayout();
		this.vmethod_0().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_0().BackColorState.Disabled = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_0().BackColorState.Enabled = global::System.Drawing.Color.FromArgb(220, 220, 220);
		this.vmethod_0().BackColorState.Hover = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_0().BackColorState.Pressed = global::System.Drawing.Color.FromArgb(192, 192, 192);
		this.vmethod_0().Border.Color = global::System.Drawing.Color.FromArgb(180, 180, 180);
		this.vmethod_0().Border.HoverColor = global::System.Drawing.Color.FromArgb(120, 183, 230);
		this.vmethod_0().Border.HoverVisible = true;
		this.vmethod_0().Border.Rounding = 6;
		this.vmethod_0().Border.Thickness = 1;
		this.vmethod_0().Border.Type = 1;
		this.vmethod_0().Border.Visible = true;
		this.vmethod_0().DialogResult = global::System.Windows.Forms.DialogResult.None;
		this.vmethod_0().ForeColor = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_0().Image = null;
		this.vmethod_0().Location = new global::System.Drawing.Point(75, 427);
		this.vmethod_0().MouseState = 0;
		this.vmethod_0().Name = "btnStop";
		this.vmethod_0().Size = new global::System.Drawing.Size(61, 30);
		this.vmethod_0().TabIndex = 124;
		this.vmethod_0().Text = "Stop";
		this.vmethod_0().TextImageRelation = global::System.Windows.Forms.TextImageRelation.Overlay;
		this.vmethod_0().TextStyle.Disabled = global::System.Drawing.Color.FromArgb(131, 129, 129);
		this.vmethod_0().TextStyle.Enabled = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_0().TextStyle.Hover = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_0().TextStyle.Pressed = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_0().TextStyle.TextAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_0().TextStyle.TextLineAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_0().TextStyle.TextRenderingHint = global::System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
		this.vmethod_2().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_2().BackColorState.Disabled = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_2().BackColorState.Enabled = global::System.Drawing.Color.FromArgb(220, 220, 220);
		this.vmethod_2().BackColorState.Hover = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_2().BackColorState.Pressed = global::System.Drawing.Color.FromArgb(192, 192, 192);
		this.vmethod_2().Border.Color = global::System.Drawing.Color.FromArgb(180, 180, 180);
		this.vmethod_2().Border.HoverColor = global::System.Drawing.Color.FromArgb(120, 183, 230);
		this.vmethod_2().Border.HoverVisible = true;
		this.vmethod_2().Border.Rounding = 6;
		this.vmethod_2().Border.Thickness = 1;
		this.vmethod_2().Border.Type = 1;
		this.vmethod_2().Border.Visible = true;
		this.vmethod_2().DialogResult = global::System.Windows.Forms.DialogResult.None;
		this.vmethod_2().ForeColor = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_2().Image = null;
		this.vmethod_2().Location = new global::System.Drawing.Point(8, 427);
		this.vmethod_2().MouseState = 0;
		this.vmethod_2().Name = "btnStart";
		this.vmethod_2().Size = new global::System.Drawing.Size(61, 30);
		this.vmethod_2().TabIndex = 123;
		this.vmethod_2().Text = "Start";
		this.vmethod_2().TextImageRelation = global::System.Windows.Forms.TextImageRelation.Overlay;
		this.vmethod_2().TextStyle.Disabled = global::System.Drawing.Color.FromArgb(131, 129, 129);
		this.vmethod_2().TextStyle.Enabled = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_2().TextStyle.Hover = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_2().TextStyle.Pressed = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_2().TextStyle.TextAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_2().TextStyle.TextLineAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_2().TextStyle.TextRenderingHint = global::System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
		this.vmethod_6().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_6().BackColor = global::System.Drawing.Color.White;
		this.vmethod_6().DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.vmethod_6().ForeColor = global::System.Drawing.Color.Black;
		this.vmethod_6().FormattingEnabled = true;
		this.vmethod_6().ImeMode = global::System.Windows.Forms.ImeMode.NoControl;
		this.vmethod_6().Location = new global::System.Drawing.Point(603, 423);
		this.vmethod_6().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_6().Name = "cbThreads";
		this.vmethod_6().Size = new global::System.Drawing.Size(73, 21);
		this.vmethod_6().TabIndex = 107;
		this.vmethod_6().TabStop = false;
		this.vmethod_8().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_8().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_8().Location = new global::System.Drawing.Point(546, 427);
		this.vmethod_8().Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
		this.vmethod_8().Name = "lblThreads";
		this.vmethod_8().Size = new global::System.Drawing.Size(53, 13);
		this.vmethod_8().TabIndex = 106;
		this.vmethod_8().Text = "Threads:";
		this.vmethod_8().TextAlign = global::System.Drawing.ContentAlignment.TopRight;
		this.vmethod_10().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_10().BackColor = global::System.Drawing.Color.White;
		this.vmethod_10().DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.vmethod_10().ForeColor = global::System.Drawing.Color.Black;
		this.vmethod_10().FormattingEnabled = true;
		this.vmethod_10().ImeMode = global::System.Windows.Forms.ImeMode.NoControl;
		this.vmethod_10().Location = new global::System.Drawing.Point(405, 423);
		this.vmethod_10().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_10().Name = "cbMethod";
		this.vmethod_10().Size = new global::System.Drawing.Size(118, 21);
		this.vmethod_10().TabIndex = 105;
		this.vmethod_10().TabStop = false;
		this.vmethod_12().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_12().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_12().Location = new global::System.Drawing.Point(355, 427);
		this.vmethod_12().Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
		this.vmethod_12().Name = "lblMethod";
		this.vmethod_12().Size = new global::System.Drawing.Size(46, 13);
		this.vmethod_12().TabIndex = 104;
		this.vmethod_12().Text = "Method:";
		this.vmethod_12().TextAlign = global::System.Drawing.ContentAlignment.TopRight;
		this.vmethod_14().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_14().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8f, global::System.Drawing.FontStyle.Italic, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_14().ForeColor = global::System.Drawing.Color.Gray;
		this.vmethod_14().Location = new global::System.Drawing.Point(208, 449);
		this.vmethod_14().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_14().MaxLength = 5;
		this.vmethod_14().Name = "txtPort";
		this.vmethod_14().Size = new global::System.Drawing.Size(69, 20);
		this.vmethod_14().TabIndex = 103;
		this.vmethod_14().Text = "12345";
		this.vmethod_16().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_16().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_16().Location = new global::System.Drawing.Point(172, 453);
		this.vmethod_16().Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
		this.vmethod_16().Name = "lblUsername";
		this.vmethod_16().Size = new global::System.Drawing.Size(32, 13);
		this.vmethod_16().TabIndex = 102;
		this.vmethod_16().Text = "Port:";
		this.vmethod_16().TextAlign = global::System.Drawing.ContentAlignment.TopRight;
		this.vmethod_18().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_18().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8f, global::System.Drawing.FontStyle.Italic, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_18().ForeColor = global::System.Drawing.Color.Gray;
		this.vmethod_18().Location = new global::System.Drawing.Point(208, 426);
		this.vmethod_18().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_18().MaxLength = 45;
		this.vmethod_18().Name = "txtTarget";
		this.vmethod_18().Size = new global::System.Drawing.Size(138, 20);
		this.vmethod_18().TabIndex = 101;
		this.vmethod_18().Text = "Target IP or DNS";
		this.vmethod_20().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_20().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_20().Location = new global::System.Drawing.Point(147, 429);
		this.vmethod_20().Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
		this.vmethod_20().Name = "lblTarget";
		this.vmethod_20().Size = new global::System.Drawing.Size(57, 13);
		this.vmethod_20().TabIndex = 100;
		this.vmethod_20().Text = "Target:";
		this.vmethod_20().TextAlign = global::System.Drawing.ContentAlignment.TopRight;
		this.vmethod_22().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_22().AutoSize = true;
		this.vmethod_22().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_22().Location = new global::System.Drawing.Point(46, 459);
		this.vmethod_22().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_22().Name = "rbSelected";
		this.vmethod_22().Size = new global::System.Drawing.Size(122, 17);
		this.vmethod_22().TabIndex = 99;
		this.vmethod_22().Text = "Only selected clients";
		this.vmethod_22().UseVisualStyleBackColor = false;
		this.vmethod_24().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_24().AutoSize = true;
		this.vmethod_24().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_24().Checked = true;
		this.vmethod_24().Location = new global::System.Drawing.Point(8, 459);
		this.vmethod_24().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_24().Name = "rbAll";
		this.vmethod_24().Size = new global::System.Drawing.Size(36, 17);
		this.vmethod_24().TabIndex = 98;
		this.vmethod_24().TabStop = true;
		this.vmethod_24().Text = "All";
		this.vmethod_24().UseVisualStyleBackColor = false;
		this.vmethod_26().Enabled = true;
		this.vmethod_26().Interval = 1000;
		this.vmethod_28().AutoSize = false;
		this.vmethod_28().BackColor = global::System.Drawing.Color.FromArgb(235, 237, 239);
		this.vmethod_28().ImageScalingSize = new global::System.Drawing.Size(28, 28);
		this.vmethod_28().Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_30(),
			this.vmethod_106(),
			this.vmethod_32(),
			this.vmethod_34(),
			this.vmethod_36()
		});
		this.vmethod_28().Location = new global::System.Drawing.Point(0, 482);
		this.vmethod_28().Name = "ssDDOSStatus";
		this.vmethod_28().Padding = new global::System.Windows.Forms.Padding(1, 0, 7, 0);
		this.vmethod_28().Size = new global::System.Drawing.Size(1142, 19);
		this.vmethod_28().SizingGrip = false;
		this.vmethod_28().Stretch = false;
		this.vmethod_28().TabIndex = 97;
		this.vmethod_28().Text = "stStatus";
		this.vmethod_30().AutoSize = false;
		this.vmethod_30().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_30().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_30().Margin = new global::System.Windows.Forms.Padding(0, 3, 0, 0);
		this.vmethod_30().Name = "tsDOSClientsCount";
		this.vmethod_30().Size = new global::System.Drawing.Size(140, 16);
		this.vmethod_30().Text = "DDoS clients: 0";
		this.vmethod_30().TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
		this.vmethod_106().AutoSize = false;
		this.vmethod_106().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_106().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_106().Margin = new global::System.Windows.Forms.Padding(0, 3, 0, 0);
		this.vmethod_106().Name = "tsDDoSThreads";
		this.vmethod_106().Overflow = global::System.Windows.Forms.ToolStripItemOverflow.Never;
		this.vmethod_106().Size = new global::System.Drawing.Size(180, 16);
		this.vmethod_106().Text = "Threads: N/A";
		this.vmethod_106().TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
		this.vmethod_32().AutoSize = false;
		this.vmethod_32().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_32().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_32().Margin = new global::System.Windows.Forms.Padding(0, 3, 0, 0);
		this.vmethod_32().Name = "tsDOSSpeed";
		this.vmethod_32().Overflow = global::System.Windows.Forms.ToolStripItemOverflow.Never;
		this.vmethod_32().Size = new global::System.Drawing.Size(180, 16);
		this.vmethod_32().Text = "Speed: N/A";
		this.vmethod_32().TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
		this.vmethod_34().AutoSize = false;
		this.vmethod_34().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_34().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_34().Margin = new global::System.Windows.Forms.Padding(0, 3, 0, 0);
		this.vmethod_34().Name = "tsDOSPPS";
		this.vmethod_34().Overflow = global::System.Windows.Forms.ToolStripItemOverflow.Never;
		this.vmethod_34().Size = new global::System.Drawing.Size(180, 16);
		this.vmethod_34().Text = "PPS: N/A";
		this.vmethod_34().TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
		this.vmethod_36().BorderSides = global::System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
		this.vmethod_36().BorderStyle = global::System.Windows.Forms.Border3DStyle.SunkenOuter;
		this.vmethod_36().Margin = new global::System.Windows.Forms.Padding(0, 3, -4, 0);
		this.vmethod_36().Name = "tsClientsSelected";
		this.vmethod_36().Size = new global::System.Drawing.Size(458, 16);
		this.vmethod_36().Spring = true;
		this.vmethod_36().Text = "Selected clients: 0";
		this.vmethod_36().TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
		this.vmethod_38().Alignment = global::System.Windows.Forms.ListViewAlignment.Left;
		this.vmethod_38().AllColumns.Add(this.vmethod_40());
		this.vmethod_38().AllColumns.Add(this.vmethod_44());
		this.vmethod_38().AllColumns.Add(this.vmethod_46());
		this.vmethod_38().AllColumns.Add(this.vmethod_48());
		this.vmethod_38().AllColumns.Add(this.vmethod_50());
		this.vmethod_38().AllColumns.Add(this.vmethod_42());
		this.vmethod_38().AllColumns.Add(this.vmethod_104());
		this.vmethod_38().AllColumns.Add(this.vmethod_52());
		this.vmethod_38().AllColumns.Add(this.vmethod_54());
		this.vmethod_38().AllColumns.Add(this.vmethod_74());
		this.vmethod_38().AllColumns.Add(this.vmethod_102());
		this.vmethod_38().AllColumns.Add(this.vmethod_100());
		this.vmethod_38().AllColumns.Add(this.vmethod_56());
		this.vmethod_38().Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_38().AutoArrange = false;
		this.vmethod_38().BorderStyle = global::System.Windows.Forms.BorderStyle.None;
		this.vmethod_38().CellEditUseWholeCell = false;
		this.vmethod_38().Columns.AddRange(new global::System.Windows.Forms.ColumnHeader[]
		{
			this.vmethod_40(),
			this.vmethod_44(),
			this.vmethod_46(),
			this.vmethod_48(),
			this.vmethod_50(),
			this.vmethod_42(),
			this.vmethod_104(),
			this.vmethod_52(),
			this.vmethod_54(),
			this.vmethod_74(),
			this.vmethod_102(),
			this.vmethod_100(),
			this.vmethod_56()
		});
		this.vmethod_38().ContextMenuStrip = this.vmethod_58();
		this.vmethod_38().Cursor = global::System.Windows.Forms.Cursors.Default;
		this.vmethod_38().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.142858f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_38().FullRowSelect = true;
		this.vmethod_38().HeaderStyle = global::System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
		this.vmethod_38().HideSelection = false;
		this.vmethod_38().Location = new global::System.Drawing.Point(0, 0);
		this.vmethod_38().Margin = new global::System.Windows.Forms.Padding(1);
		this.vmethod_38().Name = "lvDOSClients";
		this.vmethod_38().ShowGroups = false;
		this.vmethod_38().Size = new global::System.Drawing.Size(1142, 412);
		this.vmethod_38().TabIndex = 96;
		this.vmethod_38().UseCellFormatEvents = true;
		this.vmethod_38().UseCompatibleStateImageBehavior = false;
		this.vmethod_38().UseHotControls = false;
		this.vmethod_38().UseOverlays = false;
		this.vmethod_38().View = global::System.Windows.Forms.View.Details;
		this.vmethod_38().VirtualMode = true;
		this.vmethod_40().AspectName = "USER";
		this.vmethod_40().Hideable = false;
		this.vmethod_40().Text = "User";
		this.vmethod_44().AspectName = "TARGET_HOST";
		this.vmethod_44().Hideable = false;
		this.vmethod_44().Text = "Target";
		this.vmethod_46().AspectName = "TARGET_PORT";
		this.vmethod_46().Hideable = false;
		this.vmethod_46().Text = "Port";
		this.vmethod_48().AspectName = "PROTOCOL";
		this.vmethod_48().Hideable = false;
		this.vmethod_48().Text = "Protocol";
		this.vmethod_50().AspectName = "METHOD";
		this.vmethod_50().Hideable = false;
		this.vmethod_50().Text = "Method";
		this.vmethod_42().AspectName = "THREADS";
		this.vmethod_42().Hideable = false;
		this.vmethod_42().Text = "Threads";
		this.vmethod_104().AspectName = "BYTES_SENT";
		this.vmethod_104().Hideable = false;
		this.vmethod_104().Text = "Sent";
		this.vmethod_52().AspectName = "SPEED";
		this.vmethod_52().Hideable = false;
		this.vmethod_52().Text = "Speed";
		this.vmethod_54().AspectName = "PPS";
		this.vmethod_54().Hideable = false;
		this.vmethod_54().Text = "PPS";
		this.vmethod_74().AspectName = "PACKET_SIZE";
		this.vmethod_74().Hideable = false;
		this.vmethod_74().Text = "Packet size";
		this.vmethod_102().AspectName = "INTENSITY";
		this.vmethod_102().Hideable = false;
		this.vmethod_102().Text = "Intensity";
		this.vmethod_100().AspectName = "STATUS";
		this.vmethod_100().Hideable = false;
		this.vmethod_100().Text = "Status";
		this.vmethod_56().AspectName = "DURATION";
		this.vmethod_56().Hideable = false;
		this.vmethod_56().Text = "Duration";
		this.vmethod_58().ImageScalingSize = new global::System.Drawing.Size(24, 24);
		this.vmethod_58().Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_60(),
			this.vmethod_64(),
			this.vmethod_66()
		});
		this.vmethod_58().Name = "ContextMenuStrip1";
		this.vmethod_58().Size = new global::System.Drawing.Size(170, 54);
		this.vmethod_60().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_62()
		});
		this.vmethod_60().Name = "OperationsToolStripMenuItem";
		this.vmethod_60().Size = new global::System.Drawing.Size(169, 22);
		this.vmethod_60().Text = "Operations";
		this.vmethod_62().Name = "StopToolStripMenuItem";
		this.vmethod_62().Size = new global::System.Drawing.Size(98, 22);
		this.vmethod_62().Text = "Stop";
		this.vmethod_64().Name = "ToolStripMenuItem2";
		this.vmethod_64().Size = new global::System.Drawing.Size(166, 6);
		this.vmethod_66().DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
		{
			this.vmethod_68(),
			this.vmethod_70(),
			this.vmethod_72()
		});
		this.vmethod_66().Name = "CopyToClipboardToolStripMenuItem";
		this.vmethod_66().Size = new global::System.Drawing.Size(169, 22);
		this.vmethod_66().Text = "Copy to clipboard";
		this.vmethod_68().Name = "SelectedToolStripMenuItem";
		this.vmethod_68().Size = new global::System.Drawing.Size(118, 22);
		this.vmethod_68().Text = "Selected";
		this.vmethod_70().Name = "ToolStripMenuItem4";
		this.vmethod_70().Size = new global::System.Drawing.Size(115, 6);
		this.vmethod_72().Name = "AllToolStripMenuItem";
		this.vmethod_72().Size = new global::System.Drawing.Size(118, 22);
		this.vmethod_72().Text = "All";
		this.vmethod_76().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_76().BackColor = global::System.Drawing.Color.White;
		this.vmethod_76().DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.vmethod_76().Enabled = false;
		this.vmethod_76().ForeColor = global::System.Drawing.Color.Black;
		this.vmethod_76().FormattingEnabled = true;
		this.vmethod_76().ImeMode = global::System.Windows.Forms.ImeMode.NoControl;
		this.vmethod_76().Location = new global::System.Drawing.Point(603, 452);
		this.vmethod_76().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_76().Name = "cbProtocol";
		this.vmethod_76().Size = new global::System.Drawing.Size(73, 21);
		this.vmethod_76().TabIndex = 126;
		this.vmethod_76().TabStop = false;
		this.vmethod_78().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_78().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_78().Location = new global::System.Drawing.Point(550, 456);
		this.vmethod_78().Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
		this.vmethod_78().Name = "lblProto";
		this.vmethod_78().Size = new global::System.Drawing.Size(49, 13);
		this.vmethod_78().TabIndex = 125;
		this.vmethod_78().Text = "Protocol:";
		this.vmethod_78().TextAlign = global::System.Drawing.ContentAlignment.TopRight;
		this.vmethod_80().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_80().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_80().Location = new global::System.Drawing.Point(813, 421);
		this.vmethod_80().Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
		this.vmethod_80().Name = "lblData";
		this.vmethod_80().Size = new global::System.Drawing.Size(34, 13);
		this.vmethod_80().TabIndex = 127;
		this.vmethod_80().Text = "Data:";
		this.vmethod_80().TextAlign = global::System.Drawing.ContentAlignment.TopRight;
		this.vmethod_82().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_82().Enabled = false;
		this.vmethod_82().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8f, global::System.Drawing.FontStyle.Italic, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_82().ForeColor = global::System.Drawing.Color.Gray;
		this.vmethod_82().Location = new global::System.Drawing.Point(851, 421);
		this.vmethod_82().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_82().Multiline = true;
		this.vmethod_82().Name = "txtData";
		this.vmethod_82().Size = new global::System.Drawing.Size(283, 60);
		this.vmethod_82().TabIndex = 128;
		this.vmethod_82().Text = "/site.php?x=val1&y=val2";
		this.vmethod_84().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_84().Image = global::Class131.smethod_24();
		this.vmethod_84().Location = new global::System.Drawing.Point(680, 426);
		this.vmethod_84().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_84().Name = "pbDDOSThreads";
		this.vmethod_84().Size = new global::System.Drawing.Size(15, 15);
		this.vmethod_84().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_84().TabIndex = 129;
		this.vmethod_84().TabStop = false;
		this.vmethod_86().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_86().BackColor = global::System.Drawing.Color.White;
		this.vmethod_86().DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.vmethod_86().ForeColor = global::System.Drawing.Color.Black;
		this.vmethod_86().FormattingEnabled = true;
		this.vmethod_86().ImeMode = global::System.Windows.Forms.ImeMode.NoControl;
		this.vmethod_86().Location = new global::System.Drawing.Point(405, 452);
		this.vmethod_86().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_86().Name = "cbIntensity";
		this.vmethod_86().Size = new global::System.Drawing.Size(118, 21);
		this.vmethod_86().TabIndex = 131;
		this.vmethod_86().TabStop = false;
		this.vmethod_88().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_88().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_88().Location = new global::System.Drawing.Point(349, 456);
		this.vmethod_88().Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
		this.vmethod_88().Name = "lblIntensity";
		this.vmethod_88().Size = new global::System.Drawing.Size(52, 13);
		this.vmethod_88().TabIndex = 130;
		this.vmethod_88().Text = "Intensity:";
		this.vmethod_88().TextAlign = global::System.Drawing.ContentAlignment.TopRight;
		this.vmethod_90().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_90().Image = global::Class131.smethod_24();
		this.vmethod_90().Location = new global::System.Drawing.Point(527, 454);
		this.vmethod_90().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_90().Name = "pbDDOSIntensity";
		this.vmethod_90().Size = new global::System.Drawing.Size(15, 15);
		this.vmethod_90().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_90().TabIndex = 132;
		this.vmethod_90().TabStop = false;
		this.vmethod_92().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_92().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_92().Location = new global::System.Drawing.Point(685, 456);
		this.vmethod_92().Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
		this.vmethod_92().Name = "lblSize";
		this.vmethod_92().Size = new global::System.Drawing.Size(33, 13);
		this.vmethod_92().TabIndex = 133;
		this.vmethod_92().Text = "Size:";
		this.vmethod_92().TextAlign = global::System.Drawing.ContentAlignment.TopRight;
		this.vmethod_94().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_94().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_94().ForeColor = global::System.Drawing.SystemColors.WindowText;
		this.vmethod_94().Location = new global::System.Drawing.Point(722, 453);
		this.vmethod_94().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_94().MaxLength = 5;
		this.vmethod_94().Name = "txtSize";
		this.vmethod_94().Size = new global::System.Drawing.Size(59, 20);
		this.vmethod_94().TabIndex = 134;
		this.vmethod_94().Text = "0";
		this.vmethod_96().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_96().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_96().Location = new global::System.Drawing.Point(783, 456);
		this.vmethod_96().Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
		this.vmethod_96().Name = "lblSizeKB";
		this.vmethod_96().Size = new global::System.Drawing.Size(40, 13);
		this.vmethod_96().TabIndex = 135;
		this.vmethod_96().Text = "Bytes";
		this.vmethod_98().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
		this.vmethod_98().Image = global::Class131.smethod_24();
		this.vmethod_98().Location = new global::System.Drawing.Point(816, 456);
		this.vmethod_98().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_98().Name = "pbDDOSSize";
		this.vmethod_98().Size = new global::System.Drawing.Size(15, 15);
		this.vmethod_98().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_98().TabIndex = 136;
		this.vmethod_98().TabStop = false;
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new global::System.Drawing.Size(1142, 501);
		base.Controls.Add(this.vmethod_98());
		base.Controls.Add(this.vmethod_96());
		base.Controls.Add(this.vmethod_94());
		base.Controls.Add(this.vmethod_92());
		base.Controls.Add(this.vmethod_90());
		base.Controls.Add(this.vmethod_86());
		base.Controls.Add(this.vmethod_88());
		base.Controls.Add(this.vmethod_84());
		base.Controls.Add(this.vmethod_82());
		base.Controls.Add(this.vmethod_80());
		base.Controls.Add(this.vmethod_76());
		base.Controls.Add(this.vmethod_78());
		base.Controls.Add(this.vmethod_0());
		base.Controls.Add(this.vmethod_2());
		base.Controls.Add(this.vmethod_6());
		base.Controls.Add(this.vmethod_8());
		base.Controls.Add(this.vmethod_10());
		base.Controls.Add(this.vmethod_12());
		base.Controls.Add(this.vmethod_14());
		base.Controls.Add(this.vmethod_16());
		base.Controls.Add(this.vmethod_18());
		base.Controls.Add(this.vmethod_20());
		base.Controls.Add(this.vmethod_22());
		base.Controls.Add(this.vmethod_24());
		base.Controls.Add(this.vmethod_28());
		base.Controls.Add(this.vmethod_38());
		this.DoubleBuffered = true;
		base.Name = "fDDOS";
		base.Opacity = 0.0;
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterParent;
		this.Text = "DDoS";
		this.vmethod_28().ResumeLayout(false);
		this.vmethod_28().PerformLayout();
		this.vmethod_38().EndInit();
		this.vmethod_58().ResumeLayout(false);
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_84()).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_90()).EndInit();
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_98()).EndInit();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x04000562 RID: 1378
	private global::System.ComponentModel.IContainer icontainer_0;
}
