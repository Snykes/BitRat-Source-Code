﻿using System;

// Token: 0x0200008D RID: 141
internal static class Class82
{
	// Token: 0x040001D5 RID: 469
	public static readonly object object_0 = new object();
}
