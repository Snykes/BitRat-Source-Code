﻿using System;

// Token: 0x02000016 RID: 22
internal enum Enum0
{

}
