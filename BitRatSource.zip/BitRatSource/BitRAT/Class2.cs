﻿using System;

// Token: 0x02000006 RID: 6
internal sealed class Class2
{
	// Token: 0x06000021 RID: 33 RVA: 0x00002D64 File Offset: 0x00000F64
	public Class2(string string_1, Class0 class0_1, Class48 class48_1)
	{
		this.string_0 = string_1;
		this.class0_0 = class0_1;
		this.class48_0 = class48_1;
	}

	// Token: 0x06000022 RID: 34 RVA: 0x0000E45C File Offset: 0x0000C65C
	protected override void Finalize()
	{
		try
		{
			object object_ = this.class48_0.object_0;
			lock (object_)
			{
				if (!this.class48_0.bool_1)
				{
					this.class48_0.byte_0 = Class65.smethod_1(this.string_0);
					this.class48_0.bool_1 = true;
					Class65.smethod_3(this.string_0);
				}
			}
		}
		finally
		{
			base.Finalize();
		}
	}

	// Token: 0x04000008 RID: 8
	public readonly string string_0;

	// Token: 0x04000009 RID: 9
	public readonly Class0 class0_0;

	// Token: 0x0400000A RID: 10
	public readonly Class48 class48_0;
}
