﻿using System;
using System.Threading;

// Token: 0x02000090 RID: 144
internal struct Struct18
{
	// Token: 0x06000462 RID: 1122 RVA: 0x00004C46 File Offset: 0x00002E46
	public Struct18(string string_0)
	{
		this.nullable_0 = new int?(Class22.smethod_0(string_0));
	}

	// Token: 0x06000463 RID: 1123 RVA: 0x00004C59 File Offset: 0x00002E59
	public bool method_0()
	{
		return Class22.smethod_1(this.nullable_0);
	}

	// Token: 0x06000464 RID: 1124 RVA: 0x00004C66 File Offset: 0x00002E66
	public void method_1(bool bool_0)
	{
		this.nullable_0 = new int?(Class22.smethod_4(bool_0));
	}

	// Token: 0x06000465 RID: 1125 RVA: 0x00004C79 File Offset: 0x00002E79
	public void method_2()
	{
		this.nullable_0 = new int?(Class22.smethod_4(false));
	}

	// Token: 0x06000466 RID: 1126 RVA: 0x00022390 File Offset: 0x00020590
	public int method_3()
	{
		return Class22.smethod_1(this.nullable_0).GetHashCode();
	}

	// Token: 0x06000467 RID: 1127 RVA: 0x000223B0 File Offset: 0x000205B0
	public bool method_4(bool bool_0)
	{
		return Class22.smethod_1(this.nullable_0).Equals(bool_0);
	}

	// Token: 0x06000468 RID: 1128 RVA: 0x000223D4 File Offset: 0x000205D4
	public bool method_5(object object_0)
	{
		return Class22.smethod_1(this.nullable_0).Equals(object_0);
	}

	// Token: 0x06000469 RID: 1129 RVA: 0x000223F8 File Offset: 0x000205F8
	public int method_6(bool bool_0)
	{
		return Class22.smethod_1(this.nullable_0).CompareTo(bool_0);
	}

	// Token: 0x0600046A RID: 1130 RVA: 0x0002241C File Offset: 0x0002061C
	public int method_7(object object_0)
	{
		return Class22.smethod_1(this.nullable_0).CompareTo(object_0);
	}

	// Token: 0x0600046B RID: 1131 RVA: 0x000044B1 File Offset: 0x000026B1
	public TypeCode method_8()
	{
		return TypeCode.Boolean;
	}

	// Token: 0x0600046C RID: 1132 RVA: 0x00022440 File Offset: 0x00020640
	public string method_9()
	{
		return Class22.smethod_1(this.nullable_0).ToString();
	}

	// Token: 0x0600046D RID: 1133 RVA: 0x00022460 File Offset: 0x00020660
	public string method_10(IFormatProvider iformatProvider_0)
	{
		return Class22.smethod_1(this.nullable_0).ToString(iformatProvider_0);
	}

	// Token: 0x0600046E RID: 1134 RVA: 0x00004C8C File Offset: 0x00002E8C
	public bool method_11()
	{
		bool result = Class22.smethod_1(this.nullable_0);
		Thread.MemoryBarrier();
		return result;
	}

	// Token: 0x0600046F RID: 1135 RVA: 0x00004C9E File Offset: 0x00002E9E
	public void method_12(bool bool_0)
	{
		Thread.MemoryBarrier();
		this.nullable_0 = new int?(Class22.smethod_4(bool_0));
	}

	// Token: 0x040001D9 RID: 473
	private int? nullable_0;
}
