﻿using System;

// Token: 0x0200006E RID: 110
internal abstract class Class106 : Class94
{
	// Token: 0x0600039F RID: 927 RVA: 0x000045D6 File Offset: 0x000027D6
	public override object vmethod_0()
	{
		throw new InvalidOperationException();
	}

	// Token: 0x060003A0 RID: 928 RVA: 0x000045D6 File Offset: 0x000027D6
	public override void vmethod_1(object object_0)
	{
		throw new InvalidOperationException();
	}
}
