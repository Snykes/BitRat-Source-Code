﻿using System;

// Token: 0x02000004 RID: 4
internal sealed class Class95 : Class94
{
	// Token: 0x0600000B RID: 11 RVA: 0x00002C0A File Offset: 0x00000E0A
	public char method_2()
	{
		return this.char_0;
	}

	// Token: 0x0600000C RID: 12 RVA: 0x00002C12 File Offset: 0x00000E12
	public void method_3(char char_1)
	{
		this.char_0 = char_1;
	}

	// Token: 0x0600000D RID: 13 RVA: 0x00002C1B File Offset: 0x00000E1B
	public override object vmethod_0()
	{
		return this.method_2();
	}

	// Token: 0x0600000E RID: 14 RVA: 0x00002C28 File Offset: 0x00000E28
	public override void vmethod_1(object object_0)
	{
		this.method_3(Convert.ToChar(object_0));
	}

	// Token: 0x0600000F RID: 15 RVA: 0x00002C36 File Offset: 0x00000E36
	public override int vmethod_2()
	{
		return 6;
	}

	// Token: 0x06000010 RID: 16 RVA: 0x0000E104 File Offset: 0x0000C304
	public override Class94 vmethod_3(Class94 class94_0)
	{
		base.method_1(class94_0.method_0());
		switch (class94_0.vmethod_2())
		{
		case 0:
			this.method_3((char)((Class119)class94_0).method_2());
			return this;
		case 2:
			this.method_3(Convert.ToChar(((Class103)class94_0).method_2()));
			return this;
		case 4:
			this.method_3(Convert.ToChar(((Class102)class94_0).method_2()));
			return this;
		case 6:
			this.method_3(((Class95)class94_0).method_2());
			return this;
		case 7:
			this.method_3((char)((Class118)class94_0).method_2());
			return this;
		case 8:
			this.method_3((char)((uint)((Class100)class94_0).method_2()));
			return this;
		case 9:
			this.method_3((char)((Class115)class94_0).method_2());
			return this;
		case 11:
			this.method_3((char)((Class99)class94_0).method_2());
			return this;
		case 14:
			this.method_3((char)((int)((Class105)class94_0).method_2()));
			return this;
		case 15:
			this.method_3((char)((Class101)class94_0).method_2());
			return this;
		case 19:
			this.method_3((char)((Class120)class94_0).method_2());
			return this;
		case 21:
			this.method_3((char)((Class104)class94_0).method_2());
			return this;
		case 22:
			this.method_3((char)((Class121)class94_0).method_2());
			return this;
		case 24:
			this.method_3(Convert.ToChar(((Class98)class94_0).method_2()));
			return this;
		}
		throw new ArgumentOutOfRangeException();
	}

	// Token: 0x06000011 RID: 17 RVA: 0x00002C39 File Offset: 0x00000E39
	public override Class94 vmethod_4()
	{
		Class95 @class = new Class95();
		@class.method_3(this.char_0);
		@class.method_1(base.method_0());
		return @class;
	}

	// Token: 0x04000005 RID: 5
	private char char_0;
}
