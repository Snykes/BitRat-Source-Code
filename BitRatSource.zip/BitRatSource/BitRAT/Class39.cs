﻿using System;

// Token: 0x020000A2 RID: 162
internal sealed class Class39 : Class34
{
	// Token: 0x060004F0 RID: 1264 RVA: 0x000051ED File Offset: 0x000033ED
	public string method_0()
	{
		return this.string_0;
	}

	// Token: 0x060004F1 RID: 1265 RVA: 0x000051F5 File Offset: 0x000033F5
	public void method_1(string string_1)
	{
		this.string_0 = string_1;
	}

	// Token: 0x060004F2 RID: 1266 RVA: 0x000051FE File Offset: 0x000033FE
	public bool method_2()
	{
		return this.bool_0;
	}

	// Token: 0x060004F3 RID: 1267 RVA: 0x00005206 File Offset: 0x00003406
	public void method_3(bool bool_2)
	{
		this.bool_0 = bool_2;
	}

	// Token: 0x060004F4 RID: 1268 RVA: 0x0000520F File Offset: 0x0000340F
	public bool method_4()
	{
		return this.bool_1;
	}

	// Token: 0x060004F5 RID: 1269 RVA: 0x00005217 File Offset: 0x00003417
	public void method_5(bool bool_2)
	{
		this.bool_1 = bool_2;
	}

	// Token: 0x060004F6 RID: 1270 RVA: 0x00005220 File Offset: 0x00003420
	public Class3[] method_6()
	{
		return this.class3_0;
	}

	// Token: 0x060004F7 RID: 1271 RVA: 0x00005228 File Offset: 0x00003428
	public void method_7(Class3[] class3_1)
	{
		this.class3_0 = class3_1;
	}

	// Token: 0x060004F8 RID: 1272 RVA: 0x00005231 File Offset: 0x00003431
	public int method_8()
	{
		return this.int_0;
	}

	// Token: 0x060004F9 RID: 1273 RVA: 0x00005239 File Offset: 0x00003439
	public void method_9(int int_2)
	{
		this.int_0 = int_2;
	}

	// Token: 0x060004FA RID: 1274 RVA: 0x00005242 File Offset: 0x00003442
	public int method_10()
	{
		return this.int_1;
	}

	// Token: 0x060004FB RID: 1275 RVA: 0x0000524A File Offset: 0x0000344A
	public void method_11(int int_2)
	{
		this.int_1 = int_2;
	}

	// Token: 0x060004FC RID: 1276 RVA: 0x0000440C File Offset: 0x0000260C
	public override byte vmethod_0()
	{
		return 1;
	}

	// Token: 0x040001F8 RID: 504
	private string string_0;

	// Token: 0x040001F9 RID: 505
	private bool bool_0;

	// Token: 0x040001FA RID: 506
	private bool bool_1;

	// Token: 0x040001FB RID: 507
	private Class3[] class3_0;

	// Token: 0x040001FC RID: 508
	private int int_0 = -1;

	// Token: 0x040001FD RID: 509
	private int int_1 = -1;
}
