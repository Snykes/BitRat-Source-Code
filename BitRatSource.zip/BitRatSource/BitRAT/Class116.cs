﻿using System;

// Token: 0x0200007A RID: 122
internal sealed class Class116 : Class94
{
	// Token: 0x060003E3 RID: 995 RVA: 0x00004831 File Offset: 0x00002A31
	public Array method_2()
	{
		return this.array_0;
	}

	// Token: 0x060003E4 RID: 996 RVA: 0x00004839 File Offset: 0x00002A39
	public void method_3(Array array_1)
	{
		this.array_0 = array_1;
	}

	// Token: 0x060003E5 RID: 997 RVA: 0x00004842 File Offset: 0x00002A42
	public override object vmethod_0()
	{
		return this.method_2();
	}

	// Token: 0x060003E6 RID: 998 RVA: 0x0000484A File Offset: 0x00002A4A
	public override void vmethod_1(object object_0)
	{
		this.method_3((Array)object_0);
	}

	// Token: 0x060003E7 RID: 999 RVA: 0x00004858 File Offset: 0x00002A58
	public override Class94 vmethod_4()
	{
		Class116 @class = new Class116();
		@class.method_3(this.array_0);
		@class.method_1(base.method_0());
		return @class;
	}

	// Token: 0x060003E8 RID: 1000 RVA: 0x0000440C File Offset: 0x0000260C
	public override int vmethod_2()
	{
		return 1;
	}

	// Token: 0x060003E9 RID: 1001 RVA: 0x00020DA4 File Offset: 0x0001EFA4
	public override Class94 vmethod_3(Class94 class94_0)
	{
		base.method_1(class94_0.method_0());
		int num = class94_0.vmethod_2();
		if (num != 1)
		{
			if (num != 4)
			{
				throw new ArgumentOutOfRangeException();
			}
			this.method_3((Array)((Class102)class94_0).method_2());
		}
		else
		{
			this.method_3(((Class116)class94_0).method_2());
		}
		return this;
	}

	// Token: 0x040001BB RID: 443
	private Array array_0;
}
