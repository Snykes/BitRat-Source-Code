﻿using System;
using System.Diagnostics;

// Token: 0x02000061 RID: 97
internal sealed class Class62
{
	// Token: 0x0600034C RID: 844 RVA: 0x00002F44 File Offset: 0x00001144
	[Conditional("DEBUG")]
	public static void smethod_0(string string_0)
	{
	}
}
