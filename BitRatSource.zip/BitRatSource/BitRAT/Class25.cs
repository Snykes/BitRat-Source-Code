﻿using System;
using System.Diagnostics;
using System.Threading;

// Token: 0x0200002B RID: 43
internal static class Class25
{
	// Token: 0x0200002C RID: 44
	internal sealed class Class26 : Interface9<int>, Interface4<int>, Interface3, Interface5, Interface8
	{
		// Token: 0x0600023B RID: 571 RVA: 0x00003C20 File Offset: 0x00001E20
		[DebuggerHidden]
		public Class26(int int_5)
		{
			this.int_0 = int_5;
			this.int_2 = Thread.CurrentThread.ManagedThreadId;
		}

		// Token: 0x0600023C RID: 572 RVA: 0x00002F44 File Offset: 0x00001144
		[DebuggerHidden]
		void Interface3.imethod_0()
		{
		}

		// Token: 0x0600023D RID: 573 RVA: 0x0001C800 File Offset: 0x0001AA00
		bool Interface5.imethod_2()
		{
			switch (this.int_0)
			{
			case 0:
				this.int_0 = -1;
				this.int_1 = 1395980637;
				this.int_0 = 1;
				return true;
			case 1:
				this.int_0 = -1;
				this.int_1 = -112083546;
				this.int_0 = 2;
				return true;
			case 2:
				this.int_0 = -1;
				this.int_1 = (this.int_3 ^ -1780847285);
				this.int_0 = 3;
				return true;
			case 3:
				this.int_0 = -1;
				this.int_1 = -1027425236;
				this.int_0 = 4;
				return true;
			case 4:
				this.int_0 = -1;
				this.int_1 = (this.int_3 ^ -2026041324);
				this.int_0 = 5;
				return true;
			case 5:
				this.int_0 = -1;
				this.int_1 = -186117228;
				this.int_0 = 6;
				return true;
			case 6:
				this.int_0 = -1;
				this.int_1 = 1391806242;
				this.int_0 = 7;
				return true;
			case 7:
				this.int_0 = -1;
				return false;
			default:
				return false;
			}
		}

		// Token: 0x0600023E RID: 574 RVA: 0x00003C3F File Offset: 0x00001E3F
		[DebuggerHidden]
		int Interface4<int>.imethod_3()
		{
			return this.int_1;
		}

		// Token: 0x0600023F RID: 575 RVA: 0x000038B4 File Offset: 0x00001AB4
		[DebuggerHidden]
		void Interface5.imethod_1()
		{
			throw new NotSupportedException();
		}

		// Token: 0x06000240 RID: 576 RVA: 0x00003C47 File Offset: 0x00001E47
		[DebuggerHidden]
		object Interface5.imethod_0()
		{
			return this.int_1;
		}

		// Token: 0x06000241 RID: 577 RVA: 0x0001C910 File Offset: 0x0001AB10
		[DebuggerHidden]
		Interface4<int> Interface9<int>.imethod_1()
		{
			Class25.Class26 @class;
			if (this.int_0 == -2 && this.int_2 == Thread.CurrentThread.ManagedThreadId)
			{
				this.int_0 = 0;
				@class = this;
			}
			else
			{
				@class = new Class25.Class26(0);
			}
			@class.int_3 = this.int_4;
			return @class;
		}

		// Token: 0x06000242 RID: 578 RVA: 0x00003C54 File Offset: 0x00001E54
		[DebuggerHidden]
		Interface5 Interface8.imethod_0()
		{
			return this.Interface9<System.Int32>.imethod_1();
		}

		// Token: 0x04000141 RID: 321
		private int int_0;

		// Token: 0x04000142 RID: 322
		private int int_1;

		// Token: 0x04000143 RID: 323
		private int int_2;

		// Token: 0x04000144 RID: 324
		private int int_3;

		// Token: 0x04000145 RID: 325
		public int int_4;
	}
}
