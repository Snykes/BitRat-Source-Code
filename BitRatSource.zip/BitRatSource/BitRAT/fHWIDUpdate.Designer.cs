﻿// Token: 0x020000EB RID: 235
[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
public sealed partial class fHWIDUpdate : global::System.Windows.Forms.Form
{
	// Token: 0x06000B83 RID: 2947 RVA: 0x00059740 File Offset: 0x00057940
	[global::System.Diagnostics.DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && this.icontainer_0 != null)
			{
				this.icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	// Token: 0x06000B84 RID: 2948 RVA: 0x00059780 File Offset: 0x00057980
	[global::System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		this.vmethod_1(new global::System.Windows.Forms.Label());
		this.vmethod_3(new global::VisualPlus.Toolkit.Controls.Interactivity.VisualButton());
		this.vmethod_5(new global::System.Windows.Forms.TextBox());
		this.vmethod_7(new global::System.Windows.Forms.Label());
		this.vmethod_9(new global::System.Windows.Forms.Label());
		this.vmethod_11(new global::System.Windows.Forms.Label());
		this.vmethod_13(new global::System.ComponentModel.BackgroundWorker());
		this.vmethod_15(new global::System.Windows.Forms.PictureBox());
		this.vmethod_17(new global::System.Windows.Forms.Label());
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_14()).BeginInit();
		base.SuspendLayout();
		this.vmethod_0().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_0().Location = new global::System.Drawing.Point(12, 9);
		this.vmethod_0().Name = "lblInfo";
		this.vmethod_0().Size = new global::System.Drawing.Size(545, 146);
		this.vmethod_0().TabIndex = 133;
		this.vmethod_0().TextAlign = global::System.Drawing.ContentAlignment.TopCenter;
		this.vmethod_2().BackColorState.Disabled = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_2().BackColorState.Enabled = global::System.Drawing.Color.FromArgb(220, 220, 220);
		this.vmethod_2().BackColorState.Hover = global::System.Drawing.Color.FromArgb(224, 224, 224);
		this.vmethod_2().BackColorState.Pressed = global::System.Drawing.Color.FromArgb(192, 192, 192);
		this.vmethod_2().Border.Color = global::System.Drawing.Color.FromArgb(180, 180, 180);
		this.vmethod_2().Border.HoverColor = global::System.Drawing.Color.FromArgb(120, 183, 230);
		this.vmethod_2().Border.HoverVisible = true;
		this.vmethod_2().Border.Rounding = 6;
		this.vmethod_2().Border.Thickness = 1;
		this.vmethod_2().Border.Type = 1;
		this.vmethod_2().Border.Visible = true;
		this.vmethod_2().DialogResult = global::System.Windows.Forms.DialogResult.None;
		this.vmethod_2().ForeColor = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_2().Image = null;
		this.vmethod_2().Location = new global::System.Drawing.Point(341, 186);
		this.vmethod_2().MouseState = 0;
		this.vmethod_2().Name = "btnHWIDUpdate";
		this.vmethod_2().Size = new global::System.Drawing.Size(80, 19);
		this.vmethod_2().TabIndex = 136;
		this.vmethod_2().Text = "Update";
		this.vmethod_2().TextImageRelation = global::System.Windows.Forms.TextImageRelation.Overlay;
		this.vmethod_2().TextStyle.Disabled = global::System.Drawing.Color.FromArgb(131, 129, 129);
		this.vmethod_2().TextStyle.Enabled = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_2().TextStyle.Hover = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_2().TextStyle.Pressed = global::System.Drawing.Color.FromArgb(0, 0, 0);
		this.vmethod_2().TextStyle.TextAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_2().TextStyle.TextLineAlignment = global::System.Drawing.StringAlignment.Center;
		this.vmethod_2().TextStyle.TextRenderingHint = global::System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
		this.vmethod_4().Location = new global::System.Drawing.Point(196, 185);
		this.vmethod_4().Margin = new global::System.Windows.Forms.Padding(1);
		this.vmethod_4().MaxLength = 16;
		this.vmethod_4().Name = "txtHWIDOld";
		this.vmethod_4().Size = new global::System.Drawing.Size(141, 20);
		this.vmethod_4().TabIndex = 135;
		this.vmethod_6().AutoSize = true;
		this.vmethod_6().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_6().FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.vmethod_6().Location = new global::System.Drawing.Point(124, 188);
		this.vmethod_6().Margin = new global::System.Windows.Forms.Padding(1, 0, 1, 0);
		this.vmethod_6().Name = "lblHWIDOld";
		this.vmethod_6().Size = new global::System.Drawing.Size(62, 13);
		this.vmethod_6().TabIndex = 134;
		this.vmethod_6().Text = "First HWID:";
		this.vmethod_6().TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
		this.vmethod_8().AutoSize = true;
		this.vmethod_8().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_8().FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.vmethod_8().Location = new global::System.Drawing.Point(121, 166);
		this.vmethod_8().Margin = new global::System.Windows.Forms.Padding(1, 0, 1, 0);
		this.vmethod_8().Name = "lblWIDNew";
		this.vmethod_8().Size = new global::System.Drawing.Size(65, 13);
		this.vmethod_8().TabIndex = 137;
		this.vmethod_8().Text = "New HWID:";
		this.vmethod_8().TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
		this.vmethod_10().AutoSize = true;
		this.vmethod_10().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_10().Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
		this.vmethod_10().ForeColor = global::System.Drawing.Color.RoyalBlue;
		this.vmethod_10().Location = new global::System.Drawing.Point(193, 166);
		this.vmethod_10().Name = "lblHWID";
		this.vmethod_10().Size = new global::System.Drawing.Size(30, 13);
		this.vmethod_10().TabIndex = 138;
		this.vmethod_10().Text = "N/A";
		this.vmethod_12().WorkerSupportsCancellation = true;
		this.vmethod_14().Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Right);
		this.vmethod_14().Image = global::Class131.smethod_17();
		this.vmethod_14().Location = new global::System.Drawing.Point(106, 187);
		this.vmethod_14().Margin = new global::System.Windows.Forms.Padding(2);
		this.vmethod_14().Name = "pbOldHWID";
		this.vmethod_14().Size = new global::System.Drawing.Size(15, 15);
		this.vmethod_14().SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.vmethod_14().TabIndex = 139;
		this.vmethod_14().TabStop = false;
		this.vmethod_16().AutoSize = true;
		this.vmethod_16().BackColor = global::System.Drawing.Color.Transparent;
		this.vmethod_16().FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.vmethod_16().Location = new global::System.Drawing.Point(227, 165);
		this.vmethod_16().Margin = new global::System.Windows.Forms.Padding(1, 0, 1, 0);
		this.vmethod_16().Name = "lblNoSave";
		this.vmethod_16().Size = new global::System.Drawing.Size(149, 13);
		this.vmethod_16().TabIndex = 140;
		this.vmethod_16().Text = "(You do not need to save this)";
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = global::System.Drawing.SystemColors.AppWorkspace;
		base.ClientSize = new global::System.Drawing.Size(569, 212);
		base.Controls.Add(this.vmethod_16());
		base.Controls.Add(this.vmethod_14());
		base.Controls.Add(this.vmethod_10());
		base.Controls.Add(this.vmethod_8());
		base.Controls.Add(this.vmethod_2());
		base.Controls.Add(this.vmethod_4());
		base.Controls.Add(this.vmethod_6());
		base.Controls.Add(this.vmethod_0());
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedToolWindow;
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "fHWIDUpdate";
		base.Opacity = 0.0;
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		this.Text = "HWID Update";
		((global::System.ComponentModel.ISupportInitialize)this.vmethod_14()).EndInit();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x04000456 RID: 1110
	private global::System.ComponentModel.IContainer icontainer_0;
}
