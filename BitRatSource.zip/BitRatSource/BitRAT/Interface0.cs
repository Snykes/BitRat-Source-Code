﻿using System;

// Token: 0x02000028 RID: 40
internal interface Interface0
{
	// Token: 0x0600022B RID: 555
	string imethod_0();

	// Token: 0x0600022C RID: 556
	void imethod_1(bool bool_0, Interface2 interface2_0);

	// Token: 0x0600022D RID: 557
	int imethod_2();

	// Token: 0x0600022E RID: 558
	bool imethod_3();

	// Token: 0x0600022F RID: 559
	int imethod_4(byte[] byte_0, int int_0, byte[] byte_1, int int_1);

	// Token: 0x06000230 RID: 560
	void imethod_5();
}
