﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x0200001A RID: 26
internal struct Struct3
{
	// Token: 0x060001C7 RID: 455 RVA: 0x000037E3 File Offset: 0x000019E3
	public Struct3(string string_0)
	{
		this.class64_0 = new Class64
		{
			class0_0 = Class65.smethod_0(string_0)
		};
	}

	// Token: 0x060001C9 RID: 457 RVA: 0x0001A7A8 File Offset: 0x000189A8
	private bool method_0(out string string_0)
	{
		string_0 = null;
		Class64 @class = this.class64_0;
		Class0 class2 = (@class != null) ? @class.class0_0 : null;
		if (class2 == null)
		{
			return true;
		}
		WeakReference weakReference_ = class2.weakReference_0;
		string_0 = (((weakReference_ != null) ? weakReference_.Target : null) as string);
		return string_0 != null;
	}

	// Token: 0x060001CA RID: 458 RVA: 0x0001A7F0 File Offset: 0x000189F0
	public string method_1()
	{
		string text;
		if (this.method_0(out text))
		{
			return text;
		}
		object obj = Struct3.object_0;
		lock (obj)
		{
			if (this.method_0(out text))
			{
				return text;
			}
			Class48 class48_ = this.class64_0.class0_0.class48_0;
			object obj2 = class48_.object_0;
			byte[] byte_;
			bool bool_;
			lock (obj2)
			{
				byte_ = class48_.byte_0;
				bool_ = class48_.bool_0;
				if (class48_.bool_1)
				{
					if (byte_ == null)
					{
						throw new Exception("Unable to decrypt string data: encrypted value is null");
					}
				}
				else
				{
					WeakReference weakReference_ = this.class64_0.class0_0.weakReference_1;
					string text2 = ((weakReference_ != null) ? weakReference_.Target : null) as string;
					if (text2 == null)
					{
						throw new Exception("Unable to obtain original string data");
					}
					text = string.Copy(text2);
					Class65.smethod_3(text2);
				}
				class48_.bool_1 = true;
			}
			if (text == null)
			{
				text = Class65.smethod_2(byte_, bool_);
			}
			this.method_2(text);
		}
		return text;
	}

	// Token: 0x060001CB RID: 459 RVA: 0x0001A908 File Offset: 0x00018B08
	private void method_2(string string_0)
	{
		Class2 @class;
		if (!Struct3.conditionalWeakTable_0.TryGetValue(string_0, out @class))
		{
			Class0 class2 = new Class0
			{
				class48_0 = new Class48(),
				weakReference_0 = new WeakReference(string_0),
				weakReference_1 = new WeakReference(string_0, true)
			};
			@class = new Class2(string_0, class2, class2.class48_0);
			Struct3.conditionalWeakTable_0.Add(string_0, @class);
		}
		this.class64_0.class0_0 = @class.class0_0;
	}

	// Token: 0x060001CC RID: 460 RVA: 0x0001A97C File Offset: 0x00018B7C
	public void method_3(string string_0)
	{
		object obj = Struct3.object_0;
		lock (obj)
		{
			if (string_0 == null)
			{
				this.class64_0 = null;
			}
			else
			{
				this.class64_0 = new Class64();
				this.method_2(string_0);
			}
		}
	}

	// Token: 0x060001CD RID: 461 RVA: 0x00003812 File Offset: 0x00001A12
	public void method_4()
	{
		this.method_3(null);
	}

	// Token: 0x0400004D RID: 77
	private static readonly ConditionalWeakTable<string, Class2> conditionalWeakTable_0 = new ConditionalWeakTable<string, Class2>();

	// Token: 0x0400004E RID: 78
	private static readonly object object_0 = new object();

	// Token: 0x0400004F RID: 79
	private Class64 class64_0;
}
