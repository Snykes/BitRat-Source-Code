﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using Zeroit.Framework.Progress;

// Token: 0x02000110 RID: 272
[DesignerGenerated]
public sealed partial class fThumb : Form
{
	// Token: 0x06000E73 RID: 3699 RVA: 0x00008CAE File Offset: 0x00006EAE
	public fThumb()
	{
		base.Load += this.fThumb_Load;
		this.InitializeComponent();
	}

	// Token: 0x06000E76 RID: 3702 RVA: 0x00008CCE File Offset: 0x00006ECE
	internal PictureBox vmethod_0()
	{
		return this.pictureBox_0;
	}

	// Token: 0x06000E77 RID: 3703 RVA: 0x0006D56C File Offset: 0x0006B76C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_1(PictureBox pictureBox_1)
	{
		EventHandler value = new EventHandler(this.method_10);
		MouseEventHandler value2 = new MouseEventHandler(this.method_13);
		MouseEventHandler value3 = new MouseEventHandler(this.method_14);
		PictureBox pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click -= value;
			pictureBox.MouseUp -= value2;
			pictureBox.MouseDown -= value3;
		}
		this.pictureBox_0 = pictureBox_1;
		pictureBox = this.pictureBox_0;
		if (pictureBox != null)
		{
			pictureBox.Click += value;
			pictureBox.MouseUp += value2;
			pictureBox.MouseDown += value3;
		}
	}

	// Token: 0x06000E78 RID: 3704 RVA: 0x00008CD6 File Offset: 0x00006ED6
	internal Timer vmethod_2()
	{
		return this.timer_0;
	}

	// Token: 0x06000E79 RID: 3705 RVA: 0x0006D5E8 File Offset: 0x0006B7E8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_3(Timer timer_3)
	{
		EventHandler value = new EventHandler(this.method_12);
		Timer timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_0 = timer_3;
		timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x06000E7A RID: 3706 RVA: 0x00008CDE File Offset: 0x00006EDE
	internal Timer vmethod_4()
	{
		return this.timer_1;
	}

	// Token: 0x06000E7B RID: 3707 RVA: 0x0006D62C File Offset: 0x0006B82C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_5(Timer timer_3)
	{
		EventHandler value = new EventHandler(this.method_8);
		Timer timer = this.timer_1;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_1 = timer_3;
		timer = this.timer_1;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x06000E7C RID: 3708 RVA: 0x00008CE6 File Offset: 0x00006EE6
	internal ZeroitWin8ProgressRing vmethod_6()
	{
		return this.zeroitWin8ProgressRing_0;
	}

	// Token: 0x06000E7D RID: 3709 RVA: 0x0006D670 File Offset: 0x0006B870
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_7(ZeroitWin8ProgressRing zeroitWin8ProgressRing_1)
	{
		EventHandler value = new EventHandler(this.method_11);
		ZeroitWin8ProgressRing zeroitWin8ProgressRing = this.zeroitWin8ProgressRing_0;
		if (zeroitWin8ProgressRing != null)
		{
			zeroitWin8ProgressRing.Click -= value;
		}
		this.zeroitWin8ProgressRing_0 = zeroitWin8ProgressRing_1;
		zeroitWin8ProgressRing = this.zeroitWin8ProgressRing_0;
		if (zeroitWin8ProgressRing != null)
		{
			zeroitWin8ProgressRing.Click += value;
		}
	}

	// Token: 0x06000E7E RID: 3710 RVA: 0x00008CEE File Offset: 0x00006EEE
	internal Label vmethod_8()
	{
		return this.label_0;
	}

	// Token: 0x06000E7F RID: 3711 RVA: 0x00008CF6 File Offset: 0x00006EF6
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_9(Label label_2)
	{
		this.label_0 = label_2;
	}

	// Token: 0x06000E80 RID: 3712 RVA: 0x00008CFF File Offset: 0x00006EFF
	internal Timer vmethod_10()
	{
		return this.timer_2;
	}

	// Token: 0x06000E81 RID: 3713 RVA: 0x0006D6B4 File Offset: 0x0006B8B4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_11(Timer timer_3)
	{
		EventHandler value = new EventHandler(this.method_9);
		Timer timer = this.timer_2;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_2 = timer_3;
		timer = this.timer_2;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x06000E82 RID: 3714 RVA: 0x00008D07 File Offset: 0x00006F07
	internal Label vmethod_12()
	{
		return this.label_1;
	}

	// Token: 0x06000E83 RID: 3715 RVA: 0x00008D0F File Offset: 0x00006F0F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_13(Label label_2)
	{
		this.label_1 = label_2;
	}

	// Token: 0x06000E84 RID: 3716 RVA: 0x0006D6F8 File Offset: 0x0006B8F8
	public void method_0(string string_5, string string_6, string string_7, string string_8, string string_9)
	{
		this.string_4 = string_5;
		this.string_1 = string_6;
		this.string_3 = string_7;
		this.string_2 = string_8;
		this.string_0 = string_9;
		this.vmethod_8().Text = string.Concat(new string[]
		{
			string_6,
			"^",
			string_8,
			" - ",
			string_9
		});
		this.vmethod_12().Text = string_5;
	}

	// Token: 0x06000E85 RID: 3717 RVA: 0x0006D76C File Offset: 0x0006B96C
	private void fThumb_Load(object sender, EventArgs e)
	{
		base.Visible = false;
		checked
		{
			base.Width = (int)Math.Round(Conversion.Val(Class130.fSettings_0.vmethod_92().Text));
			base.Height = (int)Math.Round(Conversion.Val(Class130.fSettings_0.vmethod_86().Text));
			this.vmethod_6().Animate = false;
			this.method_3();
		}
	}

	// Token: 0x06000E86 RID: 3718 RVA: 0x0006D7D4 File Offset: 0x0006B9D4
	public void method_1()
	{
		this.vmethod_0().Image = null;
		this.vmethod_0().BackColor = Color.Empty;
		this.vmethod_0().Invalidate();
		if (this.vmethod_6().InvokeRequired)
		{
			this.vmethod_6().Invoke(new fThumb.Delegate71(this.method_1), new object[0]);
			return;
		}
		this.vmethod_6().Animate = true;
		this.vmethod_6().Visible = true;
	}

	// Token: 0x06000E87 RID: 3719 RVA: 0x0006D84C File Offset: 0x0006BA4C
	public void method_2()
	{
		if (this.vmethod_6().InvokeRequired)
		{
			this.vmethod_6().Invoke(new fThumb.Delegate73(this.method_2), new object[0]);
			return;
		}
		this.vmethod_6().Animate = false;
		this.vmethod_6().Visible = false;
	}

	// Token: 0x06000E88 RID: 3720 RVA: 0x00008D18 File Offset: 0x00006F18
	public void method_3()
	{
		if (base.InvokeRequired)
		{
			base.Invoke(new fThumb.Delegate72(this.method_3), new object[0]);
			return;
		}
		this.method_5();
		this.vmethod_2().Enabled = true;
	}

	// Token: 0x06000E89 RID: 3721 RVA: 0x00008D4E File Offset: 0x00006F4E
	public void method_4()
	{
		if (base.InvokeRequired)
		{
			base.Invoke(new fThumb.Delegate74(this.method_4), new object[0]);
			return;
		}
		this.vmethod_4().Enabled = true;
	}

	// Token: 0x06000E8A RID: 3722 RVA: 0x0006D8A0 File Offset: 0x0006BAA0
	private void method_5()
	{
		checked
		{
			this.vmethod_6().Left = (int)Math.Round(unchecked((double)base.Width / 2.0 - (double)this.vmethod_6().Width / 2.0));
			this.vmethod_6().Top = (int)Math.Round(unchecked((double)base.Height / 2.0 - (double)this.vmethod_6().Height / 2.0));
			this.vmethod_6().Animate = true;
			Point position = Cursor.Position;
			base.Left = (int)Math.Round(unchecked((double)position.X - (double)base.Width / 2.0));
			base.Top = (int)Math.Round(unchecked((double)position.Y - (double)base.Height / 2.0));
		}
	}

	// Token: 0x06000E8B RID: 3723 RVA: 0x0006D980 File Offset: 0x0006BB80
	private void method_6()
	{
		Point position = Cursor.Position;
		checked
		{
			base.Left = (int)(unchecked((long)position.X) - this.long_0);
			base.Top = (int)(unchecked((long)position.Y) - this.long_1);
		}
	}

	// Token: 0x06000E8C RID: 3724 RVA: 0x00008D7E File Offset: 0x00006F7E
	private void method_7()
	{
		this.point_0 = Cursor.Position;
		this.long_0 = (long)(checked(this.point_0.X - base.Left));
		this.long_1 = (long)(checked(this.point_0.Y - base.Top));
	}

	// Token: 0x06000E8D RID: 3725 RVA: 0x0006D9C0 File Offset: 0x0006BBC0
	private void method_8(object sender, EventArgs e)
	{
		if (Class135.smethod_0().PreviewTransparentFrames)
		{
			if (Conversion.Val(RuntimeHelpers.GetObjectValue(this.vmethod_4().Tag)) == 0.0)
			{
				this.vmethod_4().Tag = "80";
				base.Opacity = 80.0;
				base.Visible = true;
			}
			this.vmethod_4().Tag = Conversion.Val(RuntimeHelpers.GetObjectValue(this.vmethod_4().Tag)) - 10.0;
			base.Opacity = Conversion.Val(Operators.DivideObject(this.vmethod_4().Tag, 100));
			this.Refresh();
			if (Conversion.Val(RuntimeHelpers.GetObjectValue(this.vmethod_4().Tag)) == 0.0)
			{
				base.Visible = false;
				this.vmethod_4().Enabled = false;
				return;
			}
		}
		else
		{
			base.Opacity = 0.0;
			this.Refresh();
			this.vmethod_4().Tag = 0;
			base.Visible = false;
			this.vmethod_4().Enabled = false;
		}
	}

	// Token: 0x06000E8E RID: 3726 RVA: 0x00008DBD File Offset: 0x00006FBD
	private void method_9(object sender, EventArgs e)
	{
		this.method_6();
	}

	// Token: 0x06000E8F RID: 3727 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_10(object sender, EventArgs e)
	{
	}

	// Token: 0x06000E90 RID: 3728 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_11(object sender, EventArgs e)
	{
	}

	// Token: 0x06000E91 RID: 3729 RVA: 0x0006DAE8 File Offset: 0x0006BCE8
	private void method_12(object sender, EventArgs e)
	{
		if (Class135.smethod_0().PreviewTransparentFrames)
		{
			if (Conversion.Val(RuntimeHelpers.GetObjectValue(this.vmethod_2().Tag)) == 80.0)
			{
				base.Opacity = 80.0;
				base.Visible = true;
				this.vmethod_2().Tag = "0";
			}
			this.vmethod_2().Tag = Conversion.Val(RuntimeHelpers.GetObjectValue(this.vmethod_2().Tag)) + 10.0;
			base.Opacity = Conversion.Val(Operators.DivideObject(this.vmethod_2().Tag, 100));
			this.Refresh();
			if (Conversion.Val(RuntimeHelpers.GetObjectValue(this.vmethod_2().Tag)) == 80.0)
			{
				this.vmethod_2().Enabled = false;
				return;
			}
		}
		else
		{
			base.Opacity = 100.0;
			base.Visible = true;
			this.Refresh();
			this.vmethod_2().Tag = "0";
			this.vmethod_2().Enabled = false;
		}
	}

	// Token: 0x06000E92 RID: 3730 RVA: 0x0006DC08 File Offset: 0x0006BE08
	private void method_13(object sender, MouseEventArgs e)
	{
		MouseButtons button = e.Button;
		if (button == MouseButtons.Left)
		{
			this.vmethod_10().Enabled = false;
		}
	}

	// Token: 0x06000E93 RID: 3731 RVA: 0x0006DC30 File Offset: 0x0006BE30
	private void method_14(object sender, MouseEventArgs e)
	{
		this.method_7();
		MouseButtons button = e.Button;
		if (button == MouseButtons.Left)
		{
			this.vmethod_10().Enabled = true;
			return;
		}
		if (button != MouseButtons.Right)
		{
			return;
		}
		this.method_4();
	}

	// Token: 0x040005B3 RID: 1459
	private PictureBox pictureBox_0;

	// Token: 0x040005B4 RID: 1460
	private Timer timer_0;

	// Token: 0x040005B5 RID: 1461
	private Timer timer_1;

	// Token: 0x040005B6 RID: 1462
	private ZeroitWin8ProgressRing zeroitWin8ProgressRing_0;

	// Token: 0x040005B7 RID: 1463
	private Label label_0;

	// Token: 0x040005B8 RID: 1464
	private Timer timer_2;

	// Token: 0x040005B9 RID: 1465
	private Label label_1;

	// Token: 0x040005BA RID: 1466
	public string string_0;

	// Token: 0x040005BB RID: 1467
	public string string_1;

	// Token: 0x040005BC RID: 1468
	public string string_2;

	// Token: 0x040005BD RID: 1469
	public string string_3;

	// Token: 0x040005BE RID: 1470
	public string string_4;

	// Token: 0x040005BF RID: 1471
	public Point point_0;

	// Token: 0x040005C0 RID: 1472
	private long long_0;

	// Token: 0x040005C1 RID: 1473
	private long long_1;

	// Token: 0x02000111 RID: 273
	// (Invoke) Token: 0x06000E97 RID: 3735
	private delegate void Delegate71();

	// Token: 0x02000112 RID: 274
	// (Invoke) Token: 0x06000E9B RID: 3739
	private delegate void Delegate72();

	// Token: 0x02000113 RID: 275
	// (Invoke) Token: 0x06000E9F RID: 3743
	private delegate void Delegate73();

	// Token: 0x02000114 RID: 276
	// (Invoke) Token: 0x06000EA3 RID: 3747
	private delegate void Delegate74();
}
