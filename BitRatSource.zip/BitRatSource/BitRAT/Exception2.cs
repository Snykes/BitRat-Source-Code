﻿using System;

// Token: 0x02000067 RID: 103
internal sealed class Exception2 : Exception0
{
	// Token: 0x06000377 RID: 887 RVA: 0x000043D5 File Offset: 0x000025D5
	public Exception2()
	{
	}

	// Token: 0x06000378 RID: 888 RVA: 0x000043DD File Offset: 0x000025DD
	public Exception2(string string_0) : base(string_0)
	{
	}

	// Token: 0x06000379 RID: 889 RVA: 0x000043E6 File Offset: 0x000025E6
	public Exception2(string string_0, Exception exception_0) : base(string_0, exception_0)
	{
	}
}
