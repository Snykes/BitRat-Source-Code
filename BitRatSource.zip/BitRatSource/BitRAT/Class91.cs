﻿using System;

// Token: 0x0200009F RID: 159
internal abstract class Class91 : IDisposable
{
	// Token: 0x060004DA RID: 1242 RVA: 0x00002F44 File Offset: 0x00001144
	public virtual void Dispose()
	{
	}

	// Token: 0x060004DB RID: 1243
	public abstract bool vmethod_0();

	// Token: 0x060004DC RID: 1244
	public abstract int vmethod_1();

	// Token: 0x060004DD RID: 1245
	public abstract int vmethod_2(byte[] byte_0, int int_0, int int_1, byte[] byte_1, int int_2);

	// Token: 0x060004DE RID: 1246
	public abstract byte[] vmethod_3(byte[] byte_0, int int_0, int int_1);
}
