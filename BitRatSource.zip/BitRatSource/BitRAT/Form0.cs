﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.ApplicationServices;

// Token: 0x02000141 RID: 321
[GeneratedCode("MyTemplate", "11.0.0.0")]
[EditorBrowsable(EditorBrowsableState.Never)]
internal sealed class Form0 : WindowsFormsApplicationBase
{
	// Token: 0x060011EC RID: 4588 RVA: 0x0000A04D File Offset: 0x0000824D
	[DebuggerStepThrough]
	public Form0() : base(AuthenticationMode.Windows)
	{
		base.IsSingleInstance = false;
		base.EnableVisualStyles = true;
		base.SaveMySettingsOnExit = true;
		base.ShutdownStyle = ShutdownMode.AfterMainFormCloses;
	}

	// Token: 0x060011ED RID: 4589 RVA: 0x0000A072 File Offset: 0x00008272
	[EditorBrowsable(EditorBrowsableState.Advanced)]
	[STAThread]
	[DebuggerHidden]
	[MethodImpl(MethodImplOptions.NoOptimization)]
	internal static void smethod_0(string[] string_0)
	{
		Application.SetCompatibleTextRenderingDefault(WindowsFormsApplicationBase.UseCompatibleTextRendering);
		Class145.smethod_1().Run(string_0);
	}

	// Token: 0x060011EE RID: 4590 RVA: 0x0000A089 File Offset: 0x00008289
	[DebuggerStepThrough]
	protected override void OnCreateMainForm()
	{
		base.MainForm = Class145.smethod_3().method_28();
	}
}
